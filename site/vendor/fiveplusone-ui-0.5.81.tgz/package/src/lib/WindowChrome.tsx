/** WindowChrome - 从课栈 window/WindowChrome 提取
 *
 * 浮动窗口标题栏：标题在左，附加操作和窗口控制在右。
 * 仅作为视觉外壳，窗口拖拽通过 onDragStart 交给调用方。
 */

import type { PointerEvent, ReactNode } from "react";
import { Maximize2, Minimize2, X, Minus } from "lucide-react";

export interface WindowChromeProps {
  title: string;
  icon?: ReactNode;
  onClose: () => void;
  onMinimize?: () => void;
  onFullscreen?: () => void;
  isFullscreen?: boolean;
  children: ReactNode;
  onDragStart?: (event: PointerEvent<HTMLElement>) => void;
  /** 标题栏右侧附加操作 */
  actions?: ReactNode;
  className?: string;
  /** Fill a frameless native window; the host owns its content view. */
  native?: boolean;
  closeLabel?: string;
  closeShortcut?: string;
}

export function WindowChrome({
  title,
  icon,
  onClose,
  onMinimize,
  onFullscreen,
  isFullscreen = false,
  children,
  onDragStart,
  actions,
  className,
  native = false,
  closeLabel = '关闭窗口',
  closeShortcut,
}: WindowChromeProps) {
  return (
    <div className={`fp-window${native ? ' fp-window-native' : ''} ${className || ""}`}>
      <header
        className="fp-window-bar"
        onPointerDown={(event) => {
          if (
            event.button === 0 &&
            !(event.target as Element).closest(
              "button,a,input,textarea,select,[data-no-drag]",
            )
          ) onDragStart?.(event);
        }}
        data-draggable={onDragStart ? true : undefined}
      >
        <div className="fp-window-title">
          {icon}
          <span data-fp-tooltip={title} data-fp-tooltip-side="left">{title}</span>
        </div>
        {actions && (
          <div className="fp-window-actions" data-no-drag>
            {actions}
          </div>
        )}
        <div className="fp-window-controls" data-no-drag>
          {onMinimize && (
            <button
              type="button"
              className="fp-window-control"
              aria-label="最小化窗口"
              data-fp-tooltip="最小化"
              data-fp-tooltip-side="left"
              onClick={onMinimize}
            >
              <Minus size={16} />
            </button>
          )}
          {onFullscreen && (
            <button
              type="button"
              className="fp-window-control"
              aria-label={isFullscreen ? "退出全屏" : "全屏"}
              data-fp-tooltip={isFullscreen ? "退出全屏" : "全屏"}
              data-fp-tooltip-side="left"
              onClick={onFullscreen}
            >
              {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>
          )}
          <button
            type="button"
            className="fp-window-control fp-window-control-close"
            aria-label={closeLabel}
            data-fp-tooltip={closeShortcut ? `${closeLabel}（${closeShortcut}）` : closeLabel}
            data-fp-tooltip-side="left"
            onClick={onClose}
          >
            <X size={16} />
          </button>
        </div>
      </header>
      <div className="fp-window-body">{children}</div>
    </div>
  );
}
