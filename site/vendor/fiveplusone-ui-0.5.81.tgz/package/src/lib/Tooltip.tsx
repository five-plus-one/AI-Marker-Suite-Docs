import { cloneElement, createContext, isValidElement, useContext, useEffect, useId, useLayoutEffect, useRef, useState, type ReactElement, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { usePortalTheme } from './usePortalTheme';

export type TooltipSide = 'top' | 'bottom' | 'left' | 'right';
const TooltipContext = createContext(false);
const selector = '[data-fp-tooltip],button,[role="button"],a[title],a[aria-label],[tabindex][title]';

/** One immediate, themed hint layer for controls, including legacy native titles. */
export function TooltipProvider({ children }: { children: ReactNode }) {
  const parent = useContext(TooltipContext);
  return parent ? <>{children}</> : <TooltipContext.Provider value><TooltipLayer />{children}</TooltipContext.Provider>;
}
function TooltipLayer({ owner }: { owner?: string }) {
  const [active, setActive] = useState<{ node: HTMLElement; text: string; side: TooltipSide } | null>(null);
  const anchor = useRef<HTMLElement | null>(null), bubble = useRef<HTMLDivElement>(null);
  const id = useId(), theme = usePortalTheme(anchor, !!active, active?.node);
  const [position, setPosition] = useState({ left: 8, top: 8 });
  useEffect(() => {
    let touch = false, pointerFocus = false;
    const hide = () => setActive(null);
    const show = (event: Event) => {
      if ('pointerType' in event) touch = event.pointerType === 'touch';
      if (event.type === 'focusin' && pointerFocus) return;
      if (touch) return;
      const target = event.target instanceof Element ? event.target : null;
      const node = target?.closest<HTMLElement>(selector);
      if (owner && node?.dataset.fpTooltipOwner !== owner) { hide(); return; }
      if (!node || node.closest('[inert],[aria-hidden="true"]') || node.dataset.fpTooltip === 'off' || node.matches('[role="menuitem"],[role="option"],[aria-expanded="true"]')) { hide(); return; }
      // Remove native title before the browser starts its own hover timer.
      for (let element: HTMLElement | null = target as HTMLElement; element; element = element.parentElement) {
        const title = element.getAttribute('title');
        if (title) { element.dataset.fpTooltip ||= title; element.removeAttribute('title'); }
      }
      const text = node.dataset.fpTooltip || node.getAttribute('aria-label') || node.textContent?.trim();
      if (!text) { hide(); return; }
      anchor.current = node;
      const side = node.dataset.fpTooltipSide as TooltipSide || (node.closest('[data-variant="rail"]') ? 'right' : 'bottom');
      setActive(old => old?.node === node && old.text === text ? old : { node, text, side });
    };
    const leave = (event: Event) => {
      const next = (event as MouseEvent).relatedTarget;
      if (!(next instanceof Node) || !anchor.current?.contains(next)) hide();
    };
    const key = (event: KeyboardEvent) => { touch = false; pointerFocus = false; if (event.key === 'Escape') hide(); };
    const down = (event: PointerEvent) => { touch = event.pointerType === 'touch'; pointerFocus = true; hide(); };
    document.addEventListener('pointerover', show, true);
    document.addEventListener('pointerout', leave, true);
    document.addEventListener('focusin', show, true);
    document.addEventListener('focusout', hide, true);
    document.addEventListener('pointerdown', down, true);
    document.addEventListener('keydown', key, true);
    window.addEventListener('blur', hide);
    window.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    return () => {
      document.removeEventListener('pointerover', show, true); document.removeEventListener('pointerout', leave, true);
      document.removeEventListener('focusin', show, true); document.removeEventListener('focusout', hide, true);
      document.removeEventListener('pointerdown', down, true); document.removeEventListener('keydown', key, true);
      window.removeEventListener('blur', hide); window.removeEventListener('scroll', hide, true); window.removeEventListener('resize', hide);
    };
  }, [owner]);
  useLayoutEffect(() => {
    if (!active || !bubble.current) return;
    const node = active.node;
    const previous = node.getAttribute('aria-describedby');
    node.setAttribute('aria-describedby', [previous, id].filter(Boolean).join(' '));
    const r = node.getBoundingClientRect(), b = bubble.current.getBoundingClientRect(), gap = 8, edge = 8;
    let side = active.side;
    if (side === 'bottom' && r.bottom + gap + b.height > innerHeight - edge) side = 'top';
    if (side === 'top' && r.top - gap - b.height < edge) side = 'bottom';
    if (side === 'right' && r.right + gap + b.width > innerWidth - edge) side = 'left';
    if (side === 'left' && r.left - gap - b.width < edge) side = 'right';
    const x = side === 'left' ? r.left - gap - b.width : side === 'right' ? r.right + gap : r.left + (r.width - b.width) / 2;
    const y = side === 'top' ? r.top - gap - b.height : side === 'bottom' ? r.bottom + gap : r.top + (r.height - b.height) / 2;
    setPosition({ left: Math.max(edge, Math.min(x, innerWidth - b.width - edge)), top: Math.max(edge, Math.min(y, innerHeight - b.height - edge)) });
    const observer = new MutationObserver(() => { if (!node.isConnected || node.closest('[inert],[aria-hidden="true"]') || node.getAttribute('aria-expanded') === 'true') setActive(null); });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-expanded','inert','aria-hidden'] });
    return () => { observer.disconnect(); if (previous) node.setAttribute('aria-describedby', previous); else node.removeAttribute('aria-describedby'); };
  }, [active, id]);
  return active && typeof document !== 'undefined' ? createPortal(<div ref={bubble} id={id} role="tooltip" className="fp-tooltip-bubble" style={{ ...theme, color: 'var(--fp-surface)', ...position }}>{active.text}</div>, document.body) : null;
}
export function Tooltip({ text, children, side = 'bottom' }: { text: string; children: ReactNode; side?: TooltipSide }) {
  const parent = useContext(TooltipContext), owner = useId();
  const props = { 'data-fp-tooltip': text, 'data-fp-tooltip-side': side, 'data-fp-tooltip-owner': parent ? undefined : owner, title: undefined };
  const child = isValidElement(children) ? cloneElement(children as ReactElement<Record<string, unknown>>, props) : <span {...props}>{children}</span>;
  return parent ? child : <TooltipContext.Provider value><TooltipLayer owner={owner}/>{child}</TooltipContext.Provider>;
}
