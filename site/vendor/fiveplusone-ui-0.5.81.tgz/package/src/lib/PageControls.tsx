import React,{useRef,useState,useEffect,type ReactNode,type ButtonHTMLAttributes,type HTMLAttributes} from 'react';
import {CollapseTransition} from './CollapseTransition';
export const cx = (...s: (string | false | undefined)[]) =>
  s.filter(Boolean).join(" ");
export function Button({
  variant = "primary",
  size = "md",
  loading,
  multiline = false,
  children,
  className,
  title,
  type = "button",
  ...p
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
  multiline?: boolean;
}) {
  return (
    <button
      {...p}
      data-multiline={multiline || undefined}
      data-fp-tooltip={title || (p as Record<string, unknown>)['data-fp-tooltip'] as string || p['aria-label']}
      type={type}
      disabled={p.disabled || loading}
      className={cx("fp-button", `fp-${variant}`, `fp-${size}`, className)}
      aria-busy={loading}
    >
      {loading && <Spinner size={16} />}
      {children}
    </button>
  );
}
export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning" | "error" | "accent";
}) {
  return <span className={`fp-badge fp-tone-${tone}`}>{children}</span>;
}
export function Card({
  children,
  className,
  ...p
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...p} className={cx("fp-card", className)}>
      {children}
    </div>
  );
}
export function Spinner({ size = 22 }: { size?: number }) {
  return (
    <span
      role="status"
      aria-label="正在处理"
      className="fp-spinner"
      style={{ width: size, height: size }}
    />
  );
}
export function Tabs({
  items,
  value,
  onChange,
}: {
  items: { value: string; label: string }[];
  value: string;
  onChange: (v: string) => void;
}) {
  let ref = useRef<HTMLDivElement>(null);
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });
  const labels = items.map((item) => item.label).join("\u0000");
  useEffect(() => {
    const host = ref.current;
    if (!host) return;
    const update = () => {
      const active = host.querySelector<HTMLElement>('[aria-selected="true"]');
      if (active)
        setIndicator({ left: active.offsetLeft, width: active.offsetWidth });
    };
    update();
    const observer =
      typeof ResizeObserver === "undefined" ? null : new ResizeObserver(update);
    observer?.observe(host);
    host
      .querySelectorAll("button")
      .forEach((button) => observer?.observe(button));
    return () => observer?.disconnect();
  }, [value, labels]);
  return (
    <div
      ref={ref}
      className="fp-tabs"
      role="tablist"
      onKeyDown={(e) => {
        if (!items.length || e.altKey || e.ctrlKey || e.metaKey) return;
        let i = items.findIndex((x) => x.value === value);
        let n =
          e.key === "ArrowRight"
            ? (i + 1) % items.length
            : e.key === "ArrowLeft"
              ? (i - 1 + items.length) % items.length
              : e.key === "Home"
                ? 0
                : e.key === "End"
                  ? items.length - 1
                  : -1;
        if (n >= 0) {
          e.preventDefault();
          onChange(items[n].value);
          (ref.current?.children[n] as HTMLElement)?.focus();
        }
      }}
    >
      {items.map((i) => (
        <button
          type="button"
          role="tab"
          aria-selected={i.value === value}
          tabIndex={i.value === value ? 0 : -1}
          key={i.value}
          onClick={() => onChange(i.value)}
        >
          {i.label}
        </button>
      ))}
      <span
        className="fp-tab-indicator"
        aria-hidden="true"
        style={{
          width: indicator.width,
          transform: `translateX(${indicator.left}px)`,
        }}
      />
    </div>
  );
}
export function Accordion({
  items,
}: {
  items: { title: string; content: ReactNode }[];
}) {
  const [open, setOpen] = React.useState<Set<number>>(new Set());
  const id = React.useId();
  return (
    <div className="fp-accordion">
      {items.map((item, index) => (
        <div className="fp-accordion-item" key={item.title}>
          <button
            className="fp-accordion-trigger"
            type="button"
            aria-expanded={open.has(index)}
            aria-controls={`${id}-${index}`}
            onClick={() =>
              setOpen((previous) => {
                const next = new Set(previous);
                if (next.has(index)) next.delete(index);
                else next.add(index);
                return next;
              })
            }
          >
            {item.title}
            <span aria-hidden="true">＋</span>
          </button>
          <CollapseTransition isOpen={open.has(index)}>
            <div id={`${id}-${index}`} className="fp-accordion-content">
              {item.content}
            </div>
          </CollapseTransition>
        </div>
      ))}
    </div>
  );
}
