import {useEffect,useRef,useState,type ReactNode} from 'react';
import {motion,useReducedMotion} from 'framer-motion';
export interface SlideTransitionProps{index:number;children:ReactNode;className?:string;duration?:number;label?:string}
interface PageState{index:number;direction:number;prior:{index:number;children:ReactNode}|null}
/** Ordered content slides in navigation direction while the viewport remains stable. */
export function SlideTransition({index,children,className='',duration=.26,label}:SlideTransitionProps){
 const [page,setPage]=useState<PageState>({index,direction:1,prior:null});
 const latest=useRef(children),reduced=useReducedMotion();
 if(page.index!==index)setPage({index,direction:index>page.index?1:-1,prior:{index:page.index,children:latest.current}});
 latest.current=children;
 useEffect(()=>{const timer=setTimeout(()=>setPage(current=>current.index===index&&current.prior?{...current,prior:null}:current),reduced?0:duration*1000+30);return()=>clearTimeout(timer)},[index,duration,reduced]);
 const pages=[...(page.prior?[{...page.prior,active:false}]:[]),{index,children,active:true}];
 return <div className={`fp-slide-transition ${className}`} data-direction={page.direction} data-index={index} aria-label={label} style={{position:'relative',height:'100%',width:'100%',minHeight:0,minWidth:0,overflow:'hidden'}}>
 {pages.map(p=><motion.div key={p.index} data-fp-slide-page="" data-active={p.active} inert={!p.active} aria-hidden={!p.active||undefined}
 initial={p.active&&page.prior&&!reduced?{x:`${page.direction*100}%`,opacity:.35}:false}
 animate={{x:p.active||reduced?0:`${-page.direction*100}%`,opacity:p.active||reduced?1:.35}}
 transition={{duration:reduced?0:duration,ease:[.2,0,0,1]}} style={{position:'absolute',inset:0,minWidth:0,minHeight:0,overflow:'hidden',pointerEvents:p.active?'auto':'none'}}>{p.children}</motion.div>)}
 </div>;
}
