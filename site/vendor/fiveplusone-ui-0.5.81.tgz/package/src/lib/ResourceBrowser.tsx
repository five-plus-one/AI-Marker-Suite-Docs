import {useMemo,useRef,useState,type ReactNode} from 'react';
import {ArrowUp,ChevronRight,File,Folder,Search} from 'lucide-react';
import {SelectField} from './SelectField';
import {editorSearchText} from './editor/editorSearch';

export interface BrowserEntry {
  id:string; parentId?:string; label:string; kind:'folder'|'file';
  description?:string; keywords?:string; icon?:ReactNode; disabled?:boolean;
}
export interface ResourceBrowserProps {
  entries:BrowserEntry[]; directoryId:string; onNavigate:(id:string)=>void;
  selectedId?:string; onSelect:(id:string)=>void; rootLabel?:string;
  searchLabel?:string; emptyLabel?:string; disabled?:boolean;
  preview?:ReactNode; loading?:boolean; variant?:'content'|'destination';
}
/** A controlled browser for choosing library content or a destination directory. */
export function ResourceBrowser({entries,directoryId,onNavigate,selectedId,onSelect,rootLabel='全部位置',searchLabel='搜索名称、拼音或英文',emptyLabel='此文件夹为空',disabled=false,preview,loading=false,variant='content'}:ResourceBrowserProps){
 const [query,setQuery]=useState('');
 const list=useRef<HTMLDivElement>(null);
 const byId=useMemo(()=>new Map(entries.map(entry=>[entry.id,entry])),[entries]);
 const path=(id:string)=>{const chain:BrowserEntry[]=[];const seen=new Set<string>();let entry=byId.get(id);while(entry&&!seen.has(entry.id)){seen.add(entry.id);chain.unshift(entry);entry=entry.parentId?byId.get(entry.parentId):undefined;}return chain;};
 const ancestors=path(directoryId),roots=entries.filter(entry=>!entry.parentId&&entry.kind==='folder');
 const searchIndex=useMemo(()=>new Map(entries.map(entry=>[entry.id,editorSearchText(entry.label,entry.description||'',entry.keywords||'',...path(entry.id).map(x=>x.label))])),[entries,byId]);
 const term=query.trim().toLowerCase();
 const shown=entries.filter(entry=>term?searchIndex.get(entry.id)?.includes(term):(entry.parentId||'')===directoryId);
 const navigate=(id:string)=>{setQuery('');onNavigate(id);};
 return <div className="fp-resource-browser" data-variant={variant} aria-busy={loading}>
  {variant==='destination'&&<div className="fp-browser-destination-heading"><span>选择保存位置</span><small>打开文件夹，选择当前位置</small></div>}
  <div className="fp-browser-search"><Search size={17} aria-hidden="true"/><input type="search" aria-label={searchLabel} placeholder={searchLabel} value={query} disabled={disabled} onChange={event=>setQuery(event.target.value)}/></div>
  <div className="fp-browser-body">
   {variant==='content'&&<nav className="fp-browser-locations" aria-label="浏览位置"><button type="button" disabled={disabled} aria-current={!directoryId?'location':undefined} onClick={()=>navigate('')}>{rootLabel}</button>{roots.map(entry=><button key={entry.id} type="button" disabled={disabled||entry.disabled} aria-current={ancestors[0]?.id===entry.id?'location':undefined} onClick={()=>navigate(entry.id)}>{entry.icon||<Folder size={17}/>}<span>{entry.label}</span></button>)}</nav>}
   <section className="fp-browser-main" aria-label="文件夹内容">
    {variant==='destination'&&roots.length>1&&<div className="fp-browser-root-choice"><SelectField label="切换位置" value={ancestors[0]?.id||''} onChange={navigate} options={[{value:'',label:rootLabel},...roots.map(entry=>({value:entry.id,label:entry.label,disabled:entry.disabled}))]}/></div>}
    <div className="fp-browser-path"><button type="button" aria-label="返回上一级" disabled={disabled||!directoryId} onClick={()=>navigate(byId.get(directoryId)?.parentId||'')}><ArrowUp size={17}/></button><nav aria-label="当前位置"><button type="button" disabled={disabled} onClick={()=>navigate('')}>{rootLabel}</button>{ancestors.map(entry=><span key={entry.id}><ChevronRight size={13}/><button type="button" disabled={disabled} aria-current={entry.id===directoryId?'location':undefined} onClick={()=>navigate(entry.id)}>{entry.label}</button></span>)}</nav></div>
    <div className="fp-browser-list" ref={list} role="group" aria-label={term?'搜索结果':'可选内容'} onKeyDown={event=>{
      if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
      const buttons=Array.from(list.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')||[]),index=buttons.indexOf(document.activeElement as HTMLButtonElement);if(index<0)return;
      event.preventDefault();buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:Math.max(0,Math.min(buttons.length-1,index+(event.key==='ArrowDown'?1:-1)))]?.focus();
    }}>
     {loading?<p role="status">正在加载…</p>:shown.length?shown.map(entry=><button className="fp-browser-entry" key={entry.id} type="button" disabled={disabled||entry.disabled} aria-pressed={entry.kind==='file'?selectedId===entry.id:undefined} onClick={()=>entry.kind==='folder'?navigate(entry.id):onSelect(entry.id)}>
      <span className="fp-browser-entry-icon">{entry.icon||(entry.kind==='folder'?<Folder size={22}/>:<File size={22}/>)}</span><span className="fp-browser-entry-text"><strong>{entry.label}</strong>{(term||entry.description||variant==='destination')&&<small>{term?path(entry.id).slice(0,-1).map(x=>x.label).join(' / '):entry.description||(entry.kind==='folder'?`${entries.filter(child=>child.parentId===entry.id&&child.kind==='folder').length} 个文件夹`:'')}</small>}</span>{entry.kind==='folder'&&<ChevronRight size={16}/>}</button>):<p role="status">{term?'没有匹配的内容':emptyLabel}</p>}
    </div>
    <div className="fp-browser-count" aria-live="polite">{shown.length} 项{term?' · 搜索全部位置':''}</div>
   </section>
   {preview&&<aside className="fp-browser-preview" aria-label="所选内容">{preview}</aside>}
  </div>
 </div>;
}
