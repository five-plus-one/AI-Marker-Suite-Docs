import {type ReactNode, useEffect, useId, useState} from 'react';
import {ArrowLeft, BookPlus, Copy, Download, History, Save, Sparkles, Square} from 'lucide-react';
import {ActionToolbar} from './ActionToolbar';
import {SelectField} from './SelectField';
import './experiment-workbench.css';

export interface ExperimentVersionOption {id:string;label:string}
export interface ExperimentWorkbenchProps {
  sessionKey?:string; mode?:'create'|'edit'; generationSummary?:ReactNode;
  title:string; onTitleChange:(value:string)=>void;
  prompt:string; onPromptChange:(value:string)=>void;
  source:string; onSourceChange:(value:string)=>void;
  preview:ReactNode; modelSelector?:ReactNode;
  busy?:boolean; progress?:ReactNode; canGenerate?:boolean;
  saveStatus:string; message?:string;
  versions?:ExperimentVersionOption[]; onRestore?:(id:string)=>void;
  onBack:()=>void; onSave:()=>void; onGenerate:()=>void; onStop:()=>void;
  onDuplicate:()=>void; onExport:()=>void; onInsert:()=>void;
}
/** Controlled creation surface; the host owns durable saves and revision recovery. */
export function ExperimentWorkbench(p:ExperimentWorkbenchProps) {
 const id=useId(),[panel,setPanel]=useState<'edit'|'history'>('edit'),[version,setVersion]=useState('');
 useEffect(()=>{setPanel('edit');setVersion('');},[p.sessionKey]);
 const fresh=p.mode==='create';
 return <section className="fp-experiment" aria-label="实验编辑工作台" onKeyDown={event=>{
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();p.onSave();}
 }}>
  <header className="fp-experiment-header">
   <button type="button" className="fp-experiment-back" onClick={p.onBack}><ArrowLeft size={17}/>我的实验</button>
   <span role="status" className="fp-experiment-save">{p.saveStatus}</span>
   <ActionToolbar label="实验操作" actions={[
    {id:'save',label:'保存实验（Ctrl+S）',icon:<Save size={18}/>,onSelect:p.onSave},
    {id:'insert',label:'加入笔记',icon:<BookPlus size={18}/>,onSelect:p.onInsert,disabled:p.busy||!p.source.trim()},
    {id:'copy',label:'另存为新实验',icon:<Copy size={18}/>,onSelect:p.onDuplicate,disabled:p.busy||!p.source.trim()},
    {id:'download',label:'下载实验',icon:<Download size={18}/>,onSelect:p.onExport,disabled:!p.source.trim()},
   ]}/>
  </header>
  <div className="fp-experiment-layout">
   <aside className="fp-experiment-editor">
    <label htmlFor={`${id}-title`}>实验名称</label>
    <input id={`${id}-title`} value={p.title} placeholder="给实验起个名字" onChange={e=>p.onTitleChange(e.target.value)} maxLength={100} disabled={p.busy}/>
    <div className="fp-experiment-tabs" role="tablist" aria-label="实验编辑" onKeyDown={event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const next=event.key==='Home'?'edit':event.key==='End'?'history':panel==='edit'?'history':'edit';setPanel(next);event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=tab]')[next==='edit'?0:1]?.focus();}}>
     <button type="button" id={`${id}-edit-tab`} role="tab" tabIndex={panel==='edit'?0:-1} aria-selected={panel==='edit'} aria-controls={`${id}-edit`} onClick={()=>setPanel('edit')}><Sparkles size={16}/>{fresh?'创建实验':'继续修改'}</button>
     <button type="button" id={`${id}-history-tab`} role="tab" tabIndex={panel==='history'?0:-1} aria-selected={panel==='history'} aria-controls={`${id}-history`} onClick={()=>setPanel('history')}><History size={16}/>版本记录</button>
    </div>
    {panel==='edit'?<div id={`${id}-edit`} role="tabpanel" aria-labelledby={`${id}-edit-tab`} className="fp-experiment-form">
     {p.modelSelector&&<div className="fp-experiment-model">{p.modelSelector}</div>}
     <label htmlFor={`${id}-prompt`}>描述你的想法</label>
     <textarea id={`${id}-prompt`} value={p.prompt} onChange={e=>p.onPromptChange(e.target.value)} disabled={p.busy} rows={5} placeholder={fresh?'例如：用滑块调整电荷大小，观察电场如何变化。':'例如：保留现有图形，增加一个能调节距离的滑块。'}/>
     <button type="button" className="fp-experiment-primary" onClick={p.busy?p.onStop:p.onGenerate} disabled={!p.busy&&(!p.prompt.trim()||p.canGenerate===false)}>{p.busy?<><Square size={16}/>停止生成</>:<><Sparkles size={17}/>生成实验</>}</button>
     <p className="fp-experiment-hint">{fresh?'描述想探索的概念和操作，AI 会为你创建实验。':'描述要增加或调整的内容，AI 会基于当前实验修改。'}</p>
     <details><summary>编辑实验源代码</summary><label htmlFor={`${id}-source`}>实验内容</label><textarea id={`${id}-source`} aria-label="交互内容" value={p.source} onChange={e=>p.onSourceChange(e.target.value)} disabled={p.busy} rows={14} spellCheck={false}/></details>
    </div>:<div id={`${id}-history`} role="tabpanel" aria-labelledby={`${id}-history-tab`} className="fp-experiment-form">
     <p className="fp-experiment-hint">恢复后会保留当前内容，方便再次找回。</p>
     {p.versions?.length?<><SelectField label="选择实验版本" value={version} onChange={setVersion} options={p.versions.map(item=>({value:item.id,label:item.label}))}/><button type="button" onClick={()=>{p.onRestore?.(version);setVersion('');}} disabled={!version||p.busy}>恢复此版本</button></>:<p>保存或完成一次修改后，可以在这里找回之前的内容。</p>}
    </div>}
    {p.message&&<p role="status" className="fp-experiment-message">{p.message}</p>}
    {p.generationSummary&&<div role="status" className="fp-experiment-hint">{p.generationSummary}</div>}
   </aside>
   <section className="fp-experiment-preview" aria-label="实验预览"><header><strong>{p.title||'未命名实验'}</strong><span>动手探索</span></header>{p.busy&&<div className="fp-experiment-progress" aria-live="polite">{p.progress}</div>}<div className="fp-experiment-canvas">{p.preview}</div></section>
  </div>
 </section>;
}
