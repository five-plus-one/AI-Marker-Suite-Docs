import { lazy, Suspense, type ComponentType } from "react";
function dynamic(
  loader: () => Promise<{ default: ComponentType<any> } | ComponentType<any>>,
  _options?: unknown,
): ComponentType<Record<string, never>> {
  const Component = lazy(async () => {
    const result = await loader();
    return typeof result === "function" ? { default: result } : result;
  });
  return () => (
    <Suspense fallback={<p role="status">正在打开实验…</p>}>
      <Component />
    </Suspense>
  );
}

type SubjectId = string;

export interface InteractiveMeta {
  id: string;
  subjectId: SubjectId;
  chapterId: string;
  sectionId: string;
  title: string;
  description?: string;
  Component: ComponentType<Record<string, never>>;
}

/**
 * 交互组件注册表。每个条目以 id 唯一标识，可被笔记内 ::interactive{id=...}
 * 内联引用，也会出现在右侧「可交互」Tab 中。后续 SOP 子智能体在此追加条目。
 */
export const learningExperiments: InteractiveMeta[] = [
  {
    id: "probability-disk-conditional-lab",
    subjectId: "probability",
    chapterId: "ch03",
    sectionId: "conditional-density",
    title: "圆盘条件密度切片",
    description: "拖动横坐标，比较弦长与归一后的条件密度。",
    Component: dynamic(
      () =>
        import("./probability/ReviewLabs").then((m) => m.DiskConditionalLab),
      { ssr: false },
    ),
  },
  {
    id: "probability-occupancy-lab",
    subjectId: "probability",
    chapterId: "ch01",
    sectionId: "finite-occupancy",
    title: "每个窗口非空的分配",
    description: "调整人数和窗口数，观察条件计数与指定窗口人数分布。",
    Component: dynamic(
      () => import("./probability/ReviewLabs").then((m) => m.OccupancyLab),
      { ssr: false },
    ),
  },
  {
    id: "physics-electrostatics-lab",
    subjectId: "physics",
    chapterId: "learning",
    sectionId: "physics-electrostatics-lab",
    title: "静电场与叠加",
    Component: dynamic(() => import("./physics/ElectrostaticsLab"), {
      ssr: false,
    }),
  },
  {
    id: "discrete-set-counting",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-set-counting",
    title: "集合运算与计数",
    Component: dynamic(
      () =>
        import("./discrete-math/StructureLabs").then((m) => m.SetCountingLab),
      { ssr: false },
    ),
  },
  {
    id: "discrete-order-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-order-lab",
    title: "整除偏序与上下界",
    Component: dynamic(
      () => import("./discrete-math/StructureLabs").then((m) => m.OrderLab),
      { ssr: false },
    ),
  },
  {
    id: "discrete-graph-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-graph-lab",
    title: "图的度数与二染色",
    Component: dynamic(
      () =>
        import("./discrete-math/StructureLabs").then(
          (m) => m.GraphStructureLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "discrete-matching-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-matching-lab",
    title: "图的最大匹配",
    Component: dynamic(
      () => import("./discrete-math/StructureLabs").then((m) => m.MatchingLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-lu-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-lu-lab",
    title: "保存消元乘子的LU分解",
    Component: dynamic(
      () =>
        import("./numerical-methods/FactorizationLabs").then((m) => m.LULab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-cholesky-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-cholesky-lab",
    title: "平方根分解与正定条件",
    Component: dynamic(
      () =>
        import("./numerical-methods/FactorizationLabs").then(
          (m) => m.CholeskyLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-thomas-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-thomas-lab",
    title: "追赶法的递推与回代",
    Component: dynamic(
      () =>
        import("./numerical-methods/FactorizationLabs").then(
          (m) => m.ThomasLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-condition-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-condition-lab",
    title: "条件数与扰动放大",
    Component: dynamic(
      () =>
        import("./numerical-methods/FactorizationLabs").then(
          (m) => m.ConditionLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-divided-difference-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-divided-difference-lab",
    title: "差商与插值曲线",
    Component: dynamic(
      () =>
        import("./numerical-methods/FactorizationLabs").then(
          (m) => m.DividedDifferenceLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "discrete-prop-truth-table",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "propositional-logic",
    title: "真值表实验台",
    description: "切换公式与赋值，观察蕴含、双条件和德摩根律。",
    Component: dynamic(
      () =>
        import("./discrete-math/LogicRelationsLabs").then(
          (m) => m.TruthTableLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "discrete-predicate-quantifier",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "predicate-logic",
    title: "量词作用域实验台",
    description: "调整有限论域和谓词条件，对比全称量词与存在量词。",
    Component: dynamic(
      () =>
        import("./discrete-math/LogicRelationsLabs").then(
          (m) => m.QuantifierScopeLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "discrete-relation-properties",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "binary-relations",
    title: "关系性质实验台",
    description: "编辑三阶关系矩阵，实时判断自反、对称、反对称和传递性。",
    Component: dynamic(
      () =>
        import("./discrete-math/LogicRelationsLabs").then(
          (m) => m.RelationPropertyLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "discrete-function-mapping",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "orders-functions",
    title: "函数映射实验台",
    description: "改变有限函数的映射，实时判断单射、满射与双射。",
    Component: dynamic(
      () =>
        import("./discrete-math/LogicRelationsLabs").then(
          (m) => m.FunctionMappingLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-linear-lab",
    subjectId: "numerical-methods",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "两种线性迭代的计算过程",
    Component: dynamic(
      () =>
        import("./numerical-methods/ExtensionLabs").then((m) => m.LinearLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-interpolation-lab",
    subjectId: "numerical-methods",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "等距高次插值的变化",
    Component: dynamic(
      () =>
        import("./numerical-methods/ExtensionLabs").then(
          (m) => m.InterpolationLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-fitting-lab",
    subjectId: "numerical-methods",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "观测点与最小二乘拟合",
    Component: dynamic(
      () =>
        import("./numerical-methods/ExtensionLabs").then((m) => m.FittingLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-quadrature-lab",
    subjectId: "numerical-methods",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "加密网格与积分精度",
    Component: dynamic(
      () =>
        import("./numerical-methods/ExtensionLabs").then(
          (m) => m.QuadratureLab,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-ode-lab",
    subjectId: "numerical-methods",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "常微分方程的逐步求解",
    Component: dynamic(
      () => import("./numerical-methods/ExtensionLabs").then((m) => m.OdeLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-power-lab",
    subjectId: "numerical-methods",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "幂法收敛过程",
    Component: dynamic(
      () => import("./numerical-methods/ExtensionLabs").then((m) => m.PowerLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-rec-01",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01",
    title: "第一课 · 原始录音",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then((m) => m.RecordingOne),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-rec-02",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02",
    title: "第二课 · 原始录音",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then((m) => m.RecordingTwo),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-slides-03-04",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-03-04",
    title: "课件 · 第三、四章",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then(
          (m) => m.SlidesThreeFour,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-slides-05-06",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-05-06",
    title: "课件 · 第五、六章",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then((m) => m.SlidesFiveSix),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-slides-07-08",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-07-08",
    title: "课件 · 第七、八章",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then(
          (m) => m.SlidesSevenEight,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-slides",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides",
    title: "课件 · 第一、二章",
    Component: dynamic(
      () => import("./numerical-methods/SourceViewer").then((m) => m.Slides),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-textbook-6",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-6",
    title: "教材 · 第六版完整 PDF",
    Component: dynamic(
      () => import("./numerical-methods/SourceViewer").then((m) => m.Textbook),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-textbook-reference",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-reference",
    title: "补充教材 · 完整 PDF",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then(
          (m) => m.ReferenceTextbook,
        ),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-rec-01-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01-transcript",
    title: "第一课 · 原始转录稿",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then((m) => m.TranscriptOne),
      { ssr: false },
    ),
  },
  {
    id: "numerical-source-rec-02-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02-transcript",
    title: "第二课 · 原始转录稿",
    Component: dynamic(
      () =>
        import("./numerical-methods/SourceViewer").then((m) => m.TranscriptTwo),
      { ssr: false },
    ),
  },
  {
    id: "numerical-error-lab",
    subjectId: "numerical-methods",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "面积误差实验",
    Component: dynamic(
      () => import("./numerical-methods/Labs").then((m) => m.ErrorLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-bisection-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二分法实验",
    Component: dynamic(
      () => import("./numerical-methods/Labs").then((m) => m.BisectionLab),
      { ssr: false },
    ),
  },
  {
    id: "numerical-iteration-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "不动点迭代实验",
    Component: dynamic(
      () => import("./numerical-methods/Labs").then((m) => m.IterationLab),
      { ssr: false },
    ),
  },
  {
    subjectId: "probability",
    id: "ch01-1.1-events",
    chapterId: "ch01",
    sectionId: "1.1",
    title: "样本空间构造器",
    description:
      "点击骰子结果归入事件 A / B，实时显示集合表示与并交差补，直观体会「事件=子集」。",
    Component: dynamic(() => import("./probability/ch01/SampleSpaceBuilder"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch01-1.2-venn",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "事件运算 · 维恩图实验台",
    description: "选择并、交、差、补、对称差与德摩根律，实时高亮对应区域。",
    Component: dynamic(() => import("./probability/ch01/VennPlayground"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch01-1.3-frequency",
    chapterId: "ch01",
    sectionId: "1.3",
    title: "频率趋于概率 · 抛硬币模拟",
    description: "批量抛硬币，观察正面频率随试验次数增大向 0.5 收敛。",
    Component: dynamic(
      () => import("./probability/ch01/FrequencyConvergence"),
      { ssr: false },
    ),
  },
  {
    subjectId: "probability",
    id: "ch01-1.4-coins",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "古典概型实验室",
    description:
      "切换掷两骰子之和 / 摸球场景，蒙特卡洛模拟对比理论概率与频率收敛。",
    Component: dynamic(() => import("./probability/ch01/ClassicalProbLab"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch01-1.5-bayes-lab",
    chapterId: "ch01",
    sectionId: "1.5",
    title: "贝叶斯推断可视化",
    description:
      "调患病率 / 灵敏度 / 特异度，用方块图直观显示后验 P(病|阳性) 与基率谬误。",
    Component: dynamic(() => import("./probability/ch01/BayesExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch01-1.6-reliability",
    chapterId: "ch01",
    sectionId: "1.6",
    title: "串/并联系统可靠度探索器",
    description: "拖动各元件可靠度，实时计算系统可靠度并高亮工作/失效路径。",
    Component: dynamic(() => import("./probability/ch01/ReliabilityExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch02-2.1-rv-mapper",
    chapterId: "ch02",
    sectionId: "2.1",
    title: "随机变量映射器",
    description:
      "点击样本点为其指定一个实数值，构造自定义随机变量 X，实时展示 X 的分布律。",
    Component: dynamic(() => import("./probability/ch02/RVMapper"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch02-2.2-binomial-explorer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二项/泊松分布探索器",
    description:
      "滑块调 n、p（或 λ），实时绘制分布律柱状图，切换二项/泊松，直观体会参数变化对形状的影响。",
    Component: dynamic(() => import("./probability/ch02/BinomialExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch02-2.3-cdf-visualizer",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "分布函数可视化",
    description:
      "切换离散/连续分布，拖动 x 轴上的竖线，左侧阴影面积实时显示 F(x)=P(X≤x) 的数值。",
    Component: dynamic(() => import("./probability/ch02/CDFVisualizer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch02-2.4-pdf-explorer",
    chapterId: "ch02",
    sectionId: "2.4",
    title: "连续分布密度函数探索器",
    description:
      "切换均匀/指数/正态分布，调参数，拖动区间端点，实时计算 P(a≤X≤b)（面积）。",
    Component: dynamic(() => import("./probability/ch02/PDFExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch02-2.5-func-dist-demo",
    chapterId: "ch02",
    sectionId: "2.5",
    title: "随机变量函数分布演示",
    description:
      "选 X 的分布，选变换 Y=g(X)，并排展示 X 和 Y 的 PDF/PMF，直观看到「折叠/拉伸」效果。",
    Component: dynamic(() => import("./probability/ch02/FuncDistDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch03-3.1-joint-dist-explorer",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "联合分布律探索器",
    description:
      "3×3 表格可编辑 p(xi,yj)，自动归一化，热力图实时展示联合分布，底部/右侧显示边缘分布。",
    Component: dynamic(() => import("./probability/ch03/JointDistExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch03-3.2-marginal-explorer",
    chapterId: "ch03",
    sectionId: "3.2",
    title: "边缘分布提取演示",
    description:
      "从联合分布热力图中，点击某行/列即「投影」出该边缘分布，直观体会「对另一变量求和」的含义。",
    Component: dynamic(() => import("./probability/ch03/MarginalExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch03-3.3-conditional-explorer",
    chapterId: "ch03",
    sectionId: "3.3",
    title: "条件分布可视化",
    description:
      "点击选定 Y=yj 的行，右侧自动计算并展示归一化后的 P(X|Y=yj)，与边缘 P(X) 并排对比。",
    Component: dynamic(() => import("./probability/ch03/ConditionalExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch03-3.4-independence-checker",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "独立性检验器",
    description:
      "编辑联合分布表，实时检验 p(xi,yj)=pi·qj 是否成立，用颜色高亮违反独立性的格子。",
    Component: dynamic(() => import("./probability/ch03/IndependenceChecker"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch03-3.5-convolution-demo",
    chapterId: "ch03",
    sectionId: "3.5",
    title: "卷积：两独立随机变量之和",
    description:
      "选 X 和 Y 各自的分布类型和参数，用蒙特卡洛模拟 Z=X+Y，展示 Z 的经验分布与理论 PDF。",
    Component: dynamic(() => import("./probability/ch03/ConvolutionDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch04-4.1-expectation-explorer",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "期望：加权重心探索器",
    description:
      "可拖动数轴上的概率质量块，实时看到期望「重心」移动，直观体会期望=加权平均。",
    Component: dynamic(() => import("./probability/ch04/ExpectationExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch04-4.2-variance-explorer",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "方差与分布扩散度可视化",
    description:
      "并排两个正态分布，独立调 μ 和 σ，实时看到曲线形状变化，量化均值/方差/标准差。",
    Component: dynamic(() => import("./probability/ch04/VarianceExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch04-4.3-correlation-explorer",
    chapterId: "ch04",
    sectionId: "4.3",
    title: "相关系数可视化实验室",
    description:
      "拖动 ρ 滑块实时生成对应散点云，展示相关系数的几何意义；额外演示不相关但不独立的案例。",
    Component: dynamic(() => import("./probability/ch04/CorrelationExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch04-4.4-cov-matrix-demo",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "协方差矩阵与等高线椭圆",
    description:
      "调整 2×2 协方差矩阵的四个元素，实时看到二维正态分布等高线椭圆的形状和方向变化。",
    Component: dynamic(() => import("./probability/ch04/CovMatrixDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch05-5.1-chebyshev-demo",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "切比雪夫不等式演示",
    description:
      "调 ε 和 σ，实时看到概率尾部与切比雪夫上界的数值对比，直观体会不等式的松紧程度。",
    Component: dynamic(() => import("./probability/ch05/ChebyshevDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch05-5.2-lln-simulator",
    chapterId: "ch05",
    sectionId: "5.2",
    title: "大数定律模拟器",
    description:
      "选分布、调 ε，批量模拟样本均值折线，可视化展示「n 越大，超出 ε 带的折线比例越小」。",
    Component: dynamic(() => import("./probability/ch05/LLNSimulator"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch05-5.3-clt-simulator",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "中心极限定理模拟实验室",
    description:
      "任选底层分布（均匀/指数/泊松/二项），拖动 n，实时看样本均值的标准化直方图收敛到 N(0,1)。",
    Component: dynamic(() => import("./probability/ch05/CLTSimulator"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch06-6.1-statistic-calculator",
    chapterId: "ch06",
    sectionId: "6.1",
    title: "统计量计算器",
    description:
      "输入或随机生成一组样本数据，实时计算 X̄、S²（n-1）、S、顺序统计量，并展示每步计算过程。",
    Component: dynamic(() => import("./probability/ch06/StatisticCalculator"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch06-6.2-sampling-dist-explorer",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "三大抽样分布探索器",
    description:
      "切换 χ²/t/F 分布，调自由度参数，实时展示 PDF 曲线与临界值（α=0.05/0.01）。",
    Component: dynamic(
      () => import("./probability/ch06/SamplingDistExplorer"),
      { ssr: false },
    ),
  },
  {
    subjectId: "probability",
    id: "ch06-6.3-normal-sampling-demo",
    chapterId: "ch06",
    sectionId: "6.3",
    title: "正态总体抽样分布仿真",
    description:
      "设定正态总体参数和样本量 n，大量重复抽样，实证验证四大定理（X̄、S²、t统计量的分布）。",
    Component: dynamic(() => import("./probability/ch06/NormalSamplingDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch06-6.4-quantile-explorer",
    chapterId: "ch06",
    sectionId: "6.4",
    title: "样本分位数与 Q-Q 图",
    description:
      "生成样本，展示各顺序统计量，绘制 Q-Q 图（与正态理论分位数对比），判断是否来自正态总体。",
    Component: dynamic(() => import("./probability/ch06/QuantileExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch07-7.1-moment-estimator",
    chapterId: "ch07",
    sectionId: "7.1",
    title: "矩估计量计算器",
    description:
      "选分布（指数/正态/均匀），输入样本，自动推导矩估计量公式并代入样本矩给出数值估计。",
    Component: dynamic(() => import("./probability/ch07/MomentEstimator"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch07-7.2-mle-explorer",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "极大似然估计可视化",
    description:
      "输入样本数据，展示对数似然函数曲线，标注 MLE 峰值，并允许用户拖动参数感受似然如何随 θ 变化。",
    Component: dynamic(() => import("./probability/ch07/MLEExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch07-7.3-estimator-comparator",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "估计量性质比较器",
    description:
      "大量重复抽样，可视化比较 X̄（均值估计）、S²（无偏方差）和 Sn²（有偏方差）的分布，验证无偏性和相合性。",
    Component: dynamic(() => import("./probability/ch07/EstimatorComparator"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch07-7.4-conf-interval-explorer",
    chapterId: "ch07",
    sectionId: "7.4",
    title: "置信区间捕获率可视化",
    description:
      "设定置信水平、样本量，批量模拟抽样，可视化每次的置信区间，统计实际覆盖率是否接近声称的 1-α。",
    Component: dynamic(
      () => import("./probability/ch07/ConfidenceIntervalExplorer"),
      { ssr: false },
    ),
  },
  {
    subjectId: "probability",
    id: "ch08-8.1-hyp-test-demo",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "假设检验直觉演示",
    description:
      "调显著性水平 α 和观测到的检验统计量 z，实时看到拒绝域变化和决策结果（拒绝/不拒绝 H0）。",
    Component: dynamic(() => import("./probability/ch08/HypTestDemo"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch08-8.2-mean-test-explorer",
    chapterId: "ch08",
    sectionId: "8.2",
    title: "均值假设检验计算器",
    description:
      "输入样本统计量，选 Z/t 检验和检验方向，自动计算检验统计量和 p 值，判断在给定 α 下是否拒绝 H0。",
    Component: dynamic(() => import("./probability/ch08/MeanTestExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "probability",
    id: "ch08-8.3-variance-test-explorer",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "方差假设检验计算器",
    description:
      "输入样本方差 S²、样本量 n、假设方差 σ₀²，计算 χ² 统计量，在分布图上标注位置，给出检验结论。",
    Component: dynamic(
      () => import("./probability/ch08/VarianceTestExplorer"),
      { ssr: false },
    ),
  },
  {
    subjectId: "probability",
    id: "ch08-8.4-error-type-demo",
    chapterId: "ch08",
    sectionId: "8.4",
    title: "两类错误权衡可视化",
    description:
      "调整显著性水平 α（或等价地移动拒绝域边界），实时看到 α（第一类）和 β（第二类）错误概率的此消彼长。",
    Component: dynamic(() => import("./probability/ch08/ErrorTypeDemo"), {
      ssr: false,
    }),
  },

  // ─── 有机化学交互组件 ───────────────────────────────────────────────────────
  {
    subjectId: "chemistry",
    id: "ch01-1.2-bond-polarity",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "电负性与键极性探索器",
    description:
      "选择两个成键原子，按电负性差 Δχ 判定非极性/极性共价键/离子键，并画出偶极箭头。",
    Component: dynamic(() => import("./chemistry/ch01/BondPolarityExplorer"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch02-2.2-iupac-namer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "IUPAC 命名练习器",
    description:
      "选择支链烷烃结构，逐步演示选主链、编号、列取代基、组合系统名的命名过程。",
    Component: dynamic(() => import("./chemistry/ch02/IUPACNamingPractice"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch03-3.1-boiling-point",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "分子间作用力与沸点比较",
    description:
      "对烷烃同系列/同分异构体/氢键组排序沸点，验证分子间作用力对物理性质的影响。",
    Component: dynamic(
      () => import("./chemistry/ch03/BoilingPointComparator"),
      { ssr: false },
    ),
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.1-newman",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "纽曼投影构象能量",
    description:
      "拖动二面角观察纽曼投影旋转与势能曲线，对比乙烷/丁烷的交叉式与重叠式。",
    Component: dynamic(() => import("./chemistry/ch04/NewmanProjection"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.2-chair-flip",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "环己烷椅式翻转",
    description:
      "演示椅式翻转时直立键 a 与平伏键 e 的互换，体会大取代基偏好赤道键。",
    Component: dynamic(() => import("./chemistry/ch04/ChairFlip"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch05-5.3-carbocation",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "碳正离子稳定性",
    description:
      "比较甲基/伯/仲/叔碳正离子的超共轭数目与稳定性排序，理解电荷分散。",
    Component: dynamic(() => import("./chemistry/ch05/CarbocationStability"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch06-6.2-markovnikov",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "马氏规则加成预测",
    description:
      "选不对称烯烃与 HX，对比两条路径碳正离子稳定性预测主产物；过氧化物切换反马氏。",
    Component: dynamic(() => import("./chemistry/ch06/MarkovnikovPredictor"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch07-7.3-diene",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "共轭二烯 1,2 vs 1,4 加成",
    description:
      "用温度滑块切换动力学（1,2，低温）与热力学（1,4，高温）产物比例。",
    Component: dynamic(() => import("./chemistry/ch07/DieneAddition"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch08-8.3-directing",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "芳环定位效应预测",
    description:
      "选苯环上已有取代基，判定致活/致钝与邻对位/间位定向，高亮下一取代位置。",
    Component: dynamic(() => import("./chemistry/ch08/DirectingEffect"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.1-chirality",
    chapterId: "ch09",
    sectionId: "9.1",
    title: "手性与镜像",
    description:
      "尝试旋转手性分子的镜像使其重叠，体会对映异构体不可重叠即手性。",
    Component: dynamic(() => import("./chemistry/ch09/ChiralityMirror"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.3-rs-config",
    chapterId: "ch09",
    sectionId: "9.3",
    title: "R/S 构型判定",
    description:
      "分步引导：顺序规则排优先级、最小基朝后、看大中小转向判定 R/S。",
    Component: dynamic(() => import("./chemistry/ch09/RSConfigPractice"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.1-sn1-sn2",
    chapterId: "ch10",
    sectionId: "10.1",
    title: "SN1/SN2 机理对比",
    description:
      "选底物/亲核试剂/溶剂，判定倾向 SN1 还是 SN2，演示背面进攻翻转与碳正离子外消旋。",
    Component: dynamic(() => import("./chemistry/ch10/SN1SN2Compare"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.2-elimination",
    chapterId: "ch10",
    sectionId: "10.2",
    title: "E1/E2 与扎伊采夫规则",
    description:
      "选卤代烷展示不同 β-氢消除得到的烯烃，按扎伊采夫规则标出主产物。",
    Component: dynamic(() => import("./chemistry/ch10/EliminationZaitsev"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch11-11.3-epoxide",
    chapterId: "ch11",
    sectionId: "11.3",
    title: "环氧乙烷开环区域选择",
    description:
      "切换酸/碱催化，对比亲核试剂进攻位阻大碳（酸）或位阻小碳（碱）。",
    Component: dynamic(() => import("./chemistry/ch11/EpoxideOpening"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch12-12.1-carbonyl",
    chapterId: "ch12",
    sectionId: "12.1",
    title: "羰基亲核加成",
    description:
      "选不同亲核试剂进攻羰基碳，演示电子流向与对应产物（α-羟基腈/醇/缩醛/亚胺等）。",
    Component: dynamic(() => import("./chemistry/ch12/CarbonylAddition"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch13-13.2-acyl-reactivity",
    chapterId: "ch13",
    sectionId: "13.2",
    title: "羧酸衍生物活性序列",
    description:
      "酰氯>酸酐>酯>酰胺活性排序，点击查看离去能力与电子效应的原因。",
    Component: dynamic(() => import("./chemistry/ch13/AcylReactivity"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.1-diazonium",
    chapterId: "ch14",
    sectionId: "14.1",
    title: "重氮盐转化网络",
    description:
      "点击不同试剂展示重氮盐的桑德迈尔/席曼/还原/水解/偶联等转化产物。",
    Component: dynamic(() => import("./chemistry/ch14/DiazoniumNetwork"), {
      ssr: false,
    }),
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.2-amine-basicity",
    chapterId: "ch14",
    sectionId: "14.2",
    title: "胺碱性比较",
    description:
      "对脂肪胺/氨/芳胺/吡啶/吡咯排序碱性，解释电子效应与芳香共轭的影响。",
    Component: dynamic(() => import("./chemistry/ch14/AmineBasicity"), {
      ssr: false,
    }),
  },
];

// 防御：交互 id 必须全局唯一。getInteractive 与内联 ::interactive{id=...} 均按裸 id
// 查找；若未来跨学科复用同一 id，这里在模块加载时立即抛错，避免静默返回错组件。
(() => {
  const seen = new Set<string>();
  for (const i of learningExperiments) {
    if (seen.has(i.id)) {
      throw new Error(
        `[registry] 重复的交互 id: "${i.id}"（交互 id 必须全局唯一）`,
      );
    }
    seen.add(i.id);
  }
})();

export function getInteractive(
  id?: string | null,
): InteractiveMeta | undefined {
  if (!id) return undefined;
  return learningExperiments.find((i) => i.id === id);
}

export function getInteractivesForSection(
  subjectId: SubjectId,
  chapterId: string,
  sectionId: string,
): InteractiveMeta[] {
  return learningExperiments.filter(
    (i) =>
      i.subjectId === subjectId &&
      i.chapterId === chapterId &&
      i.sectionId === sectionId,
  );
}
