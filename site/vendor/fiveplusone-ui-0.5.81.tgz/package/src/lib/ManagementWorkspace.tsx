import {useState,type ReactNode} from 'react';
import {ArrowLeft,Menu,X} from 'lucide-react';
import {Button,Tabs} from './PageControls';
import './management-workspace.css';
export interface ManagementItem {id:string;label:string;icon?:ReactNode;description?:string;}
export interface ManagementWorkspaceProps {brand:ReactNode;headerActions?:ReactNode;items:ManagementItem[];value:string;onChange:(id:string)=>void;onReturn:()=>void;identity?:ReactNode;children:ReactNode;}
export function ManagementWorkspace({brand,headerActions,items,value,onChange,onReturn,identity,children}:ManagementWorkspaceProps){
 const [open,setOpen]=useState(false);
 return <div className="fp-console"><header className="fp-console-topbar"><div className="fp-console-brand">{brand}</div><div className="fp-console-top-actions"><Button variant="ghost" onClick={onReturn}><ArrowLeft size={17}/>返回工作区</Button>{headerActions}</div></header><div className="fp-console-body"><div className="fp-console-mobile-bar"><Button variant="secondary" aria-expanded={open} aria-controls="management-navigation" onClick={()=>setOpen(!open)}>{open?<X size={18}/>:<Menu size={18}/>}管理导航</Button><span>{items.find(item=>item.id===value)?.label}</span></div><aside className="fp-console-sidebar" data-open={open}><div className="fp-console-sidebar-heading">管理中心</div><nav id="management-navigation" aria-label="管理导航">{items.map(item=><button type="button" key={item.id} aria-current={value===item.id?'page':undefined} onClick={()=>{onChange(item.id);setOpen(false);}}>{item.icon}<span>{item.label}</span></button>)}</nav>{identity&&<footer>{identity}</footer>}</aside><main className="fp-console-content" tabIndex={-1}>{children}</main></div></div>;
}
export function ManagementForm({title,description,items,value,onChange,actions,status,children}:{title:string;description?:string;items:{value:string;label:string}[];value:string;onChange:(id:string)=>void;actions:ReactNode;status?:ReactNode;children:ReactNode}){
 return <section className="fp-console-form"><header><div><h1>{title}</h1>{description&&<p>{description}</p>}</div></header><Tabs items={items} value={value} onChange={onChange}/><div className="fp-console-form-body">{children}</div><footer><div role="status" aria-live="polite">{status}</div><div className="fp-console-form-actions">{actions}</div></footer></section>;
}
