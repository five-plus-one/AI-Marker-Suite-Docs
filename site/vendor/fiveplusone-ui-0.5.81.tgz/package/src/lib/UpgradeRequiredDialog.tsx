import type {ReactNode} from 'react';
import {Dialog} from './index';
import {ArrowUpRight,ArrowRight} from 'lucide-react';
export function UpgradeRequiredDialog({open,version,minimum,children,actions,updateContent}:{open:boolean;version?:string;minimum?:string;children?:ReactNode;actions?:ReactNode;updateContent?:ReactNode}){
 return <Dialog open={open} dismissible={false} className="fp-upgrade-dialog" title="更新课栈，继续学习" onClose={()=>{}} footer={actions}>
  {updateContent || <div className="fp-upgrade-required"><div className="fp-upgrade-symbol" aria-hidden="true"><ArrowUpRight size={28}/></div><p>当前版本需要升级，完成后即可继续使用。</p><div className="fp-update-versions"><span><small>当前版本</small><strong>{version||'—'}</strong></span><ArrowRight size={18} aria-hidden="true"/><span><small>最低支持版本</small><strong>{minimum||'—'}</strong></span></div><p className="fp-upgrade-hint">升级前请保留正在编辑的内容。</p>{children}</div>}
 </Dialog>;
}
