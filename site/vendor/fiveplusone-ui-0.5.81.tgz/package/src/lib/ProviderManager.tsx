import {useState,type ReactNode} from 'react';
import {ShieldCheck} from 'lucide-react';
import {Button} from './index';
import {WorkspaceField,WorkspaceToggle} from './WorkspaceForms';

export interface PersonalProviderModel {id:string;label?:string;registryId?:string;tools?:boolean;vision?:boolean;contextK?:number;contextSource?:'provider'|'user'|'default'}
export interface PersonalProviderDraft {id?:string;revision?:number;name:string;baseUrl:string;protocol:'openai'|'anthropic'|'siliconflow';apiKey:string;models:PersonalProviderModel[]}
export interface PersonalProviderItem extends Omit<PersonalProviderDraft,'apiKey'> {id:string;revision:number;keyConfigured:boolean}
export interface PersonalProviderImport {id:string;label:string;draft:PersonalProviderDraft}
export interface ProviderManagerProps {
 items:PersonalProviderItem[];loading?:boolean;error?:string;
 credentialNotice?:ReactNode;
 imports?:PersonalProviderImport[];
 onImportSaved?:(id:string)=>void;
 onDiscover:(draft:PersonalProviderDraft)=>Promise<PersonalProviderModel[]>;
 onTest:(draft:PersonalProviderDraft)=>Promise<string>;
 onSave:(draft:PersonalProviderDraft,proof:string)=>Promise<void>;
 onDelete:(item:PersonalProviderItem)=>Promise<void>;
}
const empty:PersonalProviderDraft={name:'',baseUrl:'',protocol:'openai',apiKey:'',models:[]};
/** Credential input stays in the editing session; the host owns requests and storage. */
export function ProviderManager({items,loading,error,credentialNotice,imports=[],onImportSaved,onDiscover,onTest,onSave,onDelete}:ProviderManagerProps){
 const [importing,setImporting]=useState<string>();
 const [draft,setDraft]=useState<PersonalProviderDraft|null>(null),[busy,setBusy]=useState(''),[message,setMessage]=useState(''),[proof,setProof]=useState(''),[manual,setManual]=useState(''),[available,setAvailable]=useState<PersonalProviderModel[]>([]),[remove,setRemove]=useState<string>();
 const validContext = !draft || draft.models.every(model=>Number.isInteger(model.contextK ?? 32) && (model.contextK ?? 32)>=4 && (model.contextK ?? 32)<=2048);
 const change=(patch:Partial<PersonalProviderDraft>)=>{setDraft(current=>current?{...current,...patch}:null);setProof('');setMessage('');};
 const edit=(item?:PersonalProviderItem)=>{setDraft(item?{...item,apiKey:''}:{...empty,models:[]});setAvailable(item?.models||[]);setManual('');setProof('');setMessage('');setRemove(undefined);setImporting(undefined);};
 const run=async(label:string,action:()=>Promise<void>)=>{setBusy(label);setMessage('');try{await action();}catch(e){setMessage(e instanceof Error?e.message:'操作未完成，请重试');}finally{setBusy('');}};
 return <div className="fp-provider-manager">
  <p>连接你自己的 AI 服务。供应商和模型会同步到账号，在其他设备也可使用。</p>
  {credentialNotice&&<aside className="fp-provider-privacy" role="note" aria-label="API Key 使用说明"><ShieldCheck size={20} aria-hidden="true"/><div>{credentialNotice}</div></aside>}
  {loading&&<p role="status">正在读取供应商…</p>}{error&&<p role="alert">{error}</p>}
  {imports.length>0&&!draft&&<section className="fp-provider-imports" aria-label="此设备的旧配置"><strong>此设备的旧配置</strong><p>检查并测试后保存到账号，即可在其他设备使用。</p>{imports.map(item=><div key={item.id} className="fp-provider-actions"><span>{item.label}</span><Button variant="secondary" disabled={!!busy} onClick={()=>{edit();setDraft({...item.draft});setAvailable(item.draft.models);setImporting(item.id);}}>检查并迁移 {item.label}</Button></div>)}</section>}
  {items.map(item=><div key={item.id} className="fp-provider-summary"><div><strong>{item.name}</strong><small>{item.models.length} 个模型 · {item.protocol==='anthropic'?'Anthropic Messages':item.protocol==='siliconflow'?'SiliconFlow':'OpenAI 兼容'}</small></div><Button variant="ghost" disabled={!!busy} onClick={()=>edit(item)}>编辑</Button><Button variant="ghost" disabled={!!busy} onClick={()=>setRemove(item.id)}>删除</Button>{remove===item.id&&<div className="fp-provider-actions"><span>删除此供应商？</span><Button variant="secondary" onClick={()=>setRemove(undefined)}>取消</Button><Button disabled={!!busy} onClick={()=>void run('delete',async()=>{await onDelete(item);setRemove(undefined);if(draft?.id===item.id)setDraft(null);})}>确认删除</Button></div>}</div>)}
  {!draft&&<Button variant="secondary" onClick={()=>edit()}>添加供应商</Button>}
  {draft&&<div className="fp-provider-form" aria-label={draft.id?'编辑供应商':'添加供应商'}>
   <WorkspaceField label="供应商名称" value={draft.name} disabled={!!busy} onChange={name=>change({name})}/>
   <WorkspaceField label="API 端点" hint="填写 HTTPS 地址，例如 https://api.example.com/v1" value={draft.baseUrl} disabled={!!busy} onChange={baseUrl=>{change({baseUrl,models:[]});setAvailable([]);}}/>
   <WorkspaceField label="协议" value={draft.protocol} disabled={!!busy} options={[{value:'openai',label:'OpenAI 兼容'},{value:'anthropic',label:'Anthropic Messages'},{value:'siliconflow',label:'SiliconFlow'}]} onChange={protocol=>{change({protocol:protocol as PersonalProviderDraft['protocol'],models:[]});setAvailable([]);}}/>
   <WorkspaceField label="API Key" hint={draft.id?'留空沿用已保存的 Key。':'Key 仅用于连接你的供应商，保存后不会再显示。'} value={draft.apiKey} secret disabled={!!busy} onChange={apiKey=>change({apiKey})}/>
   <div className="fp-provider-actions"><Button variant="secondary" disabled={!!busy||!draft.baseUrl||(!draft.apiKey&&!draft.id)} onClick={()=>void run('discover',async()=>{const models=await onDiscover(draft);setAvailable(models);change({models:[]});setMessage('已获取模型，请选择要添加的模型。');})}>{busy==='discover'?'正在获取…':'获取模型'}</Button></div>
   {available.length>0&&<><p aria-live="polite">已选择 {draft.models.length} / 50 个模型</p><div className="fp-provider-models" role="group" aria-label="选择模型">{available.map(model=><label key={model.id}><input type="checkbox" disabled={!!busy||draft.models.length>=50&&!draft.models.some(selected=>selected.id===model.id)} checked={draft.models.some(selected=>selected.id===model.id)} onChange={e=>change({models:e.target.checked?[...draft.models,model]:draft.models.filter(selected=>selected.id!==model.id)})}/>{model.label||model.id}</label>)}</div></>}
   {draft.models.length>0&&<section className="fp-provider-contexts" aria-label="模型能力设置"><h3>模型能力与容量</h3><p>按供应商实际支持的能力分别设置每个模型。图片输入用于识别图片；工具调用用于读取资料、操作笔记等。1K 为 1000 tokens。</p>{draft.models.map(model=><fieldset className="fp-provider-context" key={model.id}><legend>{model.label||model.id}</legend><WorkspaceToggle label="支持图片输入" description="允许在对话中上传图片供此模型识别。" checked={model.vision===true} disabled={!!busy} onChange={vision=>change({models:draft.models.map(item=>item.id===model.id?{...item,vision}:item)})}/><WorkspaceToggle label="启用工具调用" description="允许此模型读取资料及执行你授权的笔记操作。" checked={model.tools===true} disabled={!!busy} onChange={tools=>change({models:draft.models.map(item=>item.id===model.id?{...item,tools}:item)})}/><WorkspaceField label="上下文容量（K）" numeric value={model.contextK ?? 32} disabled={!!busy} hint={model.contextSource==='provider'?'供应商提供的容量，可按实际限制调整。':model.contextSource==='user'?'手动设置的容量。':model.contextSource==='default'||model.contextK===undefined?'供应商未提供容量，暂用保守默认值 32K，请按实际限制确认。':'已保存的容量，请按供应商实际限制确认。'} onChange={value=>change({models:draft.models.map(item=>item.id===model.id?{...item,contextK:Number(value),contextSource:'user'}:item)})}/>{(!Number.isInteger(model.contextK ?? 32)||(model.contextK ?? 32)<4||(model.contextK ?? 32)>2048)&&<p role="alert">请填写 4–2048 之间的整数。</p>}</fieldset>)}</section>}
   <details><summary>手动添加模型</summary><div><WorkspaceField label="模型 ID" value={manual} hint="供应商无法列出模型时，可填写模型 ID，多个模型用逗号或换行分隔。" multiline disabled={!!busy} onChange={setManual}/><Button variant="secondary" disabled={!!busy||!manual.trim()} onClick={()=>{const models=[...new Set(manual.split(/[\n,，]/).map(id=>id.trim()).filter(Boolean))].map(id=>({id,label:id}));const merged=[...draft.models,...models.filter(model=>!draft.models.some(existing=>existing.id===model.id))];setAvailable(current=>[...current,...models.filter(model=>!current.some(existing=>existing.id===model.id))]);change({models:merged});setManual('');}}>加入模型列表</Button></div></details>
   <p>连接测试只检查所选第一个模型是否可访问，图片和工具能力请按供应商说明设置。测试及对话的费用由你的供应商收取。</p>
   <div className="fp-provider-actions"><Button variant="secondary" disabled={!!busy||!validContext||!draft.name.trim()||!draft.models.length||draft.models.length>50} onClick={()=>void run('test',async()=>{setProof(await onTest(draft));setMessage('连接成功，可以保存供应商。');})}>{busy==='test'?'正在测试…':'测试连接'}</Button><Button disabled={!!busy||!proof||!validContext} onClick={()=>void run('save',async()=>{await onSave(draft,proof);if(importing)onImportSaved?.(importing);setImporting(undefined);setDraft(null);setProof('');setMessage('供应商已保存，可在模型菜单中选择。');})}>{busy==='save'?'正在保存…':draft.id?'保存供应商':'添加供应商'}</Button><Button variant="ghost" disabled={!!busy} onClick={()=>{setDraft(null);setImporting(undefined);setProof('');setMessage('');}}>取消</Button></div>
  </div>}
  {message&&<p role="status" aria-live="polite">{message}</p>}
 </div>;
}
