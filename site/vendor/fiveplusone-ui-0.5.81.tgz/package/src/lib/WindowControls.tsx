import type { HTMLAttributes, ReactNode } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';
import './window-controls.css';

export interface WindowControlsProps {
 maximized: boolean;
 fullscreen?: boolean;
 onMinimize: () => void;
 onMaximize: () => void;
 onClose: () => void;
}
/** Embeds native window actions in an application's existing header. */
export function WindowControls({maximized, fullscreen, onMinimize, onMaximize, onClose}: WindowControlsProps) {
 return <div className="fp-window-controls" role="group" aria-label="窗口操作">
  <button type="button" aria-label="最小化" onClick={onMinimize}><Minus size={16}/></button>
  <button type="button" aria-label={fullscreen ? '退出全屏' : maximized ? '还原窗口' : '最大化'} onClick={onMaximize}>{maximized || fullscreen ? <Copy size={14}/> : <Square size={14}/>}</button>
  <button type="button" aria-label="关闭窗口" onClick={onClose}><X size={18}/></button>
 </div>;
}
export function WindowDragRegion({enabled = false, as: Tag = 'header', children, className = '', ...props}: HTMLAttributes<HTMLElement> & {enabled?: boolean; as?: 'header' | 'div' | 'section'; children?: ReactNode}) {
 return <Tag {...props} className={`${className}${enabled ? ' fp-window-drag-region' : ''}`}>{children}</Tag>;
}
