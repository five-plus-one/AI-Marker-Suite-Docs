import type {ReactNode} from 'react';
import {ChevronRight} from 'lucide-react';
import './settings-links.css';

export interface SettingsLinkItem {id:string;label:string;description?:string;icon?:ReactNode;disabled?:boolean}
export interface SettingsLinksProps {items:SettingsLinkItem[];onSelect:(id:string)=>void;label?:string}
/** Related settings destinations; routing remains with the host. */
export function SettingsLinks({items,onSelect,label='相关设置'}:SettingsLinksProps){
 return <nav className="fp-settings-links" aria-label={label}>{items.map(item=><button type="button" key={item.id} disabled={item.disabled} onClick={()=>onSelect(item.id)}>{item.icon&&<span className="fp-settings-link-icon" aria-hidden="true">{item.icon}</span>}<span className="fp-settings-link-copy"><strong>{item.label}</strong>{item.description&&<small>{item.description}</small>}</span><ChevronRight size={18} aria-hidden="true"/></button>)}</nav>;
}
