import type { ReactNode } from 'react';
import { ArrowLeft, ChevronRight, Mic, Pause, Play, Square, Check } from 'lucide-react';
import './mobile-surfaces.css';

export function MobileHeader({title,subtitle,leading,actions,onBack}:{title:ReactNode;subtitle?:ReactNode;leading?:ReactNode;actions?:ReactNode;onBack?:()=>void}) {
  return <header className="fp-touch-header">{onBack?<button type="button" onClick={onBack} aria-label="返回"><ArrowLeft size={22}/></button>:leading}<div className="fp-touch-heading"><strong>{title}</strong>{subtitle&&<small>{subtitle}</small>}</div>{actions&&<div className="fp-touch-header-actions">{actions}</div>}</header>;
}
export function MobileSection({title,description,action,children}:{title:string;description?:string;action?:ReactNode;children:ReactNode}) {
  return <section className="fp-touch-section"><header><div><h2>{title}</h2>{description&&<p>{description}</p>}</div>{action}</header>{children}</section>;
}
export type MobileAction = {id:string;label:string;icon:ReactNode;description?:string;disabled?:boolean;onClick:()=>void};
export function MobileActionGrid({items,label='快捷操作'}:{items:MobileAction[];label?:string}) {
  return <div className="fp-touch-actions" aria-label={label}>{items.map(item=><button type="button" key={item.id} disabled={item.disabled} onClick={item.onClick}><span>{item.icon}</span><strong>{item.label}</strong>{item.description&&<small>{item.description}</small>}</button>)}</div>;
}
export function MobileCollectionRow({title,description,icon,trailing,onClick}:{title:string;description?:string;icon?:ReactNode;trailing?:ReactNode;onClick:()=>void}) {
  return <button type="button" className="fp-touch-row" onClick={onClick}>{icon&&<span className="fp-touch-row-icon">{icon}</span>}<span className="fp-touch-row-copy"><strong>{title}</strong>{description&&<small>{description}</small>}</span>{trailing||<ChevronRight size={18} aria-hidden="true"/>}</button>;
}

export function MobileNotebookGrid({children}:{children:ReactNode}) {
  return <div className="fp-mobile-notebook-grid">{children}</div>;
}

export function MobileNotebookCard({title,description,icon,onClick}:{title:string;description:string;icon:ReactNode;onClick:()=>void}) {
  return <button type="button" className="fp-mobile-notebook" onClick={onClick}><span className="fp-mobile-notebook-mark" aria-hidden="true">{icon}</span><strong>{title}</strong><small>{description}</small></button>;
}

export function MobileWelcome({mark,title,description,children,footer}:{mark:ReactNode;title:string;description:string;children:ReactNode;footer?:ReactNode}) {
  return <main className="fp-mobile-welcome"><div className="fp-mobile-welcome-content"><div className="fp-mobile-welcome-mark">{mark}</div><h1>{title}</h1><p>{description}</p><div className="fp-mobile-welcome-actions">{children}</div></div>{footer&&<footer>{footer}</footer>}</main>;
}

export function MobileRecorder({state,time,busy,onStart,onPause,onFinish,onUpload,onAgain}:{state:'idle'|'recording'|'paused'|'saved';time:string;busy?:boolean;onStart:()=>void;onPause:()=>void;onFinish:()=>void;onUpload:()=>void;onAgain:()=>void}) {
  const active=state==='recording'||state==='paused';
  return <section className="fp-recorder" aria-label="课堂录音" aria-busy={busy}>
    <div className="fp-recorder-status" role="status">{state==='recording'&&<i/>}{state==='idle'?'准备记录课堂':state==='paused'?'已暂停':state==='saved'?'录音已保存':'正在录音'}</div>
    <div className="fp-recorder-time" aria-label={`录音时长 ${time}`}>{time}</div>
    <p>{state==='idle'?'点击开始，记录课堂里的重点':state==='saved'?'已保存在手机，可以试听或上传到资源中心':state==='paused'?'继续录音，或结束并保存':'锁屏或返回笔记后，录音仍会继续'}</p>
    <div className="fp-recorder-controls">{active?<>
      <button type="button" disabled={busy} onClick={onPause} className="fp-recorder-secondary">{state==='paused'?<Play size={24}/>:<Pause size={24}/>}<span>{state==='paused'?'继续录音':'暂停'}</span></button>
      <button type="button" disabled={busy} onClick={onFinish} className="fp-recorder-finish"><Square size={22}/><span>结束并保存</span></button>
    </>:state==='saved'?<><span className="fp-recorder-saved"><Check size={32}/></span><button type="button" disabled={busy} onClick={onUpload} className="fp-recorder-primary">上传录音</button><button type="button" disabled={busy} onClick={onAgain}>录制下一条</button></>:<button type="button" disabled={busy} onClick={onStart} className="fp-recorder-start"><Mic size={30}/><span>开始录音</span></button>}</div>
  </section>;
}
