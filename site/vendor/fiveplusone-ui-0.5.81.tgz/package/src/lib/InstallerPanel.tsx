import {useEffect,useRef,type ReactNode} from 'react';
import {ArrowDownToLine,CheckCircle2,CircleAlert,LoaderCircle,PackageOpen} from 'lucide-react';
export interface InstallerPanelProps {brand:ReactNode;showStatusIcon?:boolean;preview?:ReactNode;productIcon?:ReactNode;headerActions?:ReactNode;onDrag?:()=>void;phase:'checking'|'ready'|'downloading'|'verifying'|'installing'|'done'|'error'|'confirm';transitionKey?:string;title:string;description:string;version?:string;progress?:number;progressLabel?:string;detail?:string;children?:ReactNode;actions:ReactNode;footer?:ReactNode}
export function InstallerPanel({brand,showStatusIcon=true,preview,productIcon,headerActions,onDrag,phase,transitionKey,title,description,version,progress,progressLabel:label,detail,children,actions,footer}:InstallerPanelProps){
 const stage=phase+':'+(transitionKey||''),content=useRef<HTMLElement>(null),previousStage=useRef(stage);
 useEffect(()=>{if(previousStage.current===stage)return;previousStage.current=stage;const node=content.current;if(!node||typeof node.animate!=='function'||window.matchMedia?.('(prefers-reduced-motion:reduce)').matches)return;const animation=node.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'none'}],{duration:320,easing:'cubic-bezier(.22,1,.36,1)'});return()=>animation.cancel();},[stage]);
 const busy=['checking','verifying','installing'].includes(phase);
 const determinate=phase==='downloading'&&Number.isFinite(progress),value=Math.max(0,Math.min(100,determinate?progress!:0));
 const progressLabel=label||(phase==='checking'?'正在连接下载服务':phase==='verifying'?'正在检查文件完整性':phase==='installing'?'正在安装到此电脑':'正在下载');
 return <div className="fp-installer" data-phase={phase} data-preview={!!preview}>
  <header onMouseDown={event=>{if(!(event.target as HTMLElement).closest('button,a,input'))onDrag?.();}}><strong>{brand}</strong><div>{headerActions}</div></header>
  <main>{preview&&<aside className="fp-installer-preview">{preview}</aside>}<section ref={content} className="fp-installer-content">
   <div className="fp-installer-heading">{showStatusIcon&&<div className="fp-installer-art" aria-hidden="true">{phase==='ready'&&productIcon?productIcon:busy?<LoaderCircle size={28}/>:phase==='done'?<CheckCircle2 size={28}/>:phase==='error'||phase==='confirm'?<CircleAlert size={28}/>:phase==='downloading'?<ArrowDownToLine size={28}/>:<PackageOpen size={28}/>}</div>}<div>{version&&<p className="fp-installer-version">版本 {version}</p>}<h1>{title}</h1></div></div>
   <p className="fp-installer-description" role={phase==='error'?'alert':'status'}>{description}</p>
   {(busy||phase==='downloading')&&<div className="fp-installer-progress"><div><span>{progressLabel}</span>{determinate&&<strong>{Math.round(value)}%</strong>}</div><div role="progressbar" aria-label={phase==='downloading'?'安装文件下载进度':progressLabel} data-indeterminate={!determinate} aria-valuenow={determinate?value:undefined} aria-valuemin={0} aria-valuemax={100}><i style={determinate?{width:`${value}%`}:undefined}/></div></div>}
   {detail&&<p className="fp-installer-detail">{detail}</p>}{children}<div className="fp-installer-actions">{actions}</div>
  </section></main>{footer&&<footer>{footer}</footer>}
 </div>;
}
