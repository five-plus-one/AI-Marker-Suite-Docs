import { useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { usePortalTheme } from './usePortalTheme';

export type SuggestionItem = { id: string; label: string; detail?: string; preview?: ReactNode };
/** A compact completion surface that keeps focus in the input being edited. */
export function SuggestionList({ anchor, items, activeId, onSelect, label = '输入建议' }: {
  anchor: RefObject<HTMLElement | null>; items: SuggestionItem[]; activeId?: string;
  onSelect: (id: string) => void; label?: string;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const theme = usePortalTheme(anchor, items.length > 0);
  const [position, setPosition] = useState({ left: 8, top: 8, maxHeight: 280 });
  useLayoutEffect(() => {
    if (!items.length) return;
    const place = () => {
      if (!anchor.current || !panel.current) return;
      const rect = anchor.current.getBoundingClientRect(), box = panel.current.getBoundingClientRect();
      const below = innerHeight - rect.bottom - 16, above = rect.top - 16;
      const upward = below < Math.min(box.height, 180) && above > below;
      const maxHeight = Math.max(80, Math.min(280, upward ? above : below));
      setPosition({ left: Math.max(8, Math.min(rect.left, innerWidth - box.width - 8)), top: upward ? Math.max(8, rect.top - Math.min(box.height, maxHeight) - 6) : rect.bottom + 6, maxHeight });
    };
    place(); window.addEventListener('resize', place); document.addEventListener('scroll', place, true);
    return () => { window.removeEventListener('resize', place); document.removeEventListener('scroll', place, true); };
  }, [anchor, items]);
  useLayoutEffect(() => { panel.current?.querySelector('[aria-selected="true"]')?.scrollIntoView?.({ block: 'nearest' }); }, [activeId]);
  if (!items.length) return null;
  return createPortal(<div ref={panel} role="listbox" aria-label={label} className="fp-popup-panel fp-suggestion-list" style={{ ...theme, ...position }} onPointerDown={event => event.preventDefault()}>
    {items.map(item => <button type="button" role="option" aria-selected={item.id === activeId} key={item.id} onClick={() => onSelect(item.id)}><span><strong>{item.label}</strong>{item.detail && <small>{item.detail}</small>}</span>{item.preview && <span className="fp-suggestion-preview">{item.preview}</span>}</button>)}
  </div>, document.body);
}
