import { useEffect, useRef, useState, type RefObject } from 'react';
import { SuggestionList } from '../SuggestionList';
import { mathCatalog } from './mathCatalog';
let consumers=0;

export function MathSuggestions({ anchor }: { anchor: RefObject<HTMLElement | null> }) {
  const native = useRef<HTMLElement | null>(null);
  const [items, setItems] = useState<{ id: string; label: string; markup: string; active: boolean }[]>([]);
  useEffect(() => {
    let panelObserver: MutationObserver | undefined;
    const read = () => {
      const panel = native.current;
      const next = anchor.current?.contains(document.activeElement) && panel?.classList.contains('is-visible') ? [...panel.querySelectorAll<HTMLElement>('li[data-command]')].map(row => {
        const id = row.dataset.command!;
        return { id, label: mathCatalog.find(item => item.latex === id)?.label || id, markup: row.querySelector('.ML__popover__command')?.innerHTML || '', active: row.classList.contains('ML__popover__current') };
      }) : [];
      setItems(previous => JSON.stringify(previous) === JSON.stringify(next) ? previous : next);
    };
    const attach = () => {
      const panel = document.getElementById('mathlive-suggestion-popover');
      if (panel === native.current) return;
      panelObserver?.disconnect(); native.current = panel;
      if (panel) { panel.setAttribute('aria-hidden', 'true'); panelObserver = new MutationObserver(read); panelObserver.observe(panel, { subtree: true, childList: true, attributes: true, attributeFilter: ['class', 'style'] }); }
      read();
    };
    consumers++;document.documentElement.dataset.fpMathCandidates = 'true';
    document.addEventListener('focusin',read);document.addEventListener('focusout',read);
    const observer = new MutationObserver(attach); observer.observe(document.body, { childList: true }); attach();
    return () => { observer.disconnect(); panelObserver?.disconnect();document.removeEventListener('focusin',read);document.removeEventListener('focusout',read); if(--consumers===0){native.current?.removeAttribute('aria-hidden'); delete document.documentElement.dataset.fpMathCandidates;} };
  }, []);
  return <SuggestionList anchor={anchor} label="公式输入建议" activeId={items.find(item => item.active)?.id} items={items.map(item => ({ id: item.id, label: item.label, detail: item.id, preview: <span dangerouslySetInnerHTML={{ __html: item.markup }}/> }))} onSelect={id => {
    const row = [...(native.current?.querySelectorAll<HTMLElement>('li[data-command]') || [])].find(row => row.dataset.command === id);
    row?.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  }}/>;
}
