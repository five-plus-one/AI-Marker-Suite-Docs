import { type ReactNode } from 'react';
import { Tooltip } from '../Tooltip';
export default function Tip({ tip, children }: { tip: string; children: ReactNode }) {
  return <Tooltip text={tip}>{children}</Tooltip>;
}
