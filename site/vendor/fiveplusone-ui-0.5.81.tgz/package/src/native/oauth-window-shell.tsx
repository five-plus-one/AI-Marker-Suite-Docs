import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {AuthenticationWindow} from '../lib/AuthenticationWindow';
declare global { interface Window { authWindow:{close():void;continueBrowser():void;reload():void;onTheme(callback:(theme:'dark'|'light')=>void):()=>void;onBrowserState(callback:(waiting:boolean)=>void):()=>void} } }
const params=new URLSearchParams(location.search);
function Shell(){
 const [browserPending,setBrowserPending]=useState(false);
 useEffect(()=>window.authWindow.onTheme(theme=>{document.documentElement.dataset.theme=theme;}),[]);
 useEffect(()=>window.authWindow.onBrowserState(setBrowserPending),[]);
 return <AuthenticationWindow mode={params.get('mode')==='task'?'task':'login'} title={params.get('title')||'账号登录'} browserPending={browserPending} onClose={()=>window.authWindow.close()} onBrowser={()=>window.authWindow.continueBrowser()} onReload={()=>window.authWindow.reload()}/>;
}
createRoot(document.getElementById('root')!).render(<Shell/>);
