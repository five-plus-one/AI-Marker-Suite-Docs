type IndicatorOptions={active:string;surface?:boolean;inset?:number;indicator?:HTMLElement};
/** Follow the committed selection, including interrupted switches and container resizing. */
export function mountSelectionIndicator(host:HTMLElement,{active,surface=false,inset=0,indicator:provided}:IndicatorOptions){
 const marker=provided||document.createElement('span');
 marker.classList.add('fp-selection-indicator');marker.setAttribute('aria-hidden','true');
 if(!provided)host.append(marker);
 host.dataset.fpSelection=surface?'surface':'underline';
 const media=window.matchMedia?.('(prefers-reduced-motion: reduce)');
 let animation:Animation|undefined,visible=false,frame=0,animateNext=false;
 let targetBox:{left:number;top:number;width:number;height:number}|undefined;
 const update=(animate=true)=>{
  const selected=host.querySelector<HTMLElement>(active),bounds=host.getBoundingClientRect();
  if(!selected||!bounds.width||!bounds.height){animation?.cancel();marker.style.opacity='0';visible=false;targetBox=undefined;return}
  const item=selected.getBoundingClientRect(),next={left:item.left-bounds.left+host.scrollLeft+inset,top:surface?item.top-bounds.top+host.scrollTop:host.clientHeight-3,width:Math.max(0,item.width-inset*2),height:surface?item.height:3};
  if(targetBox&&Object.entries(next).every(([key,value])=>Math.abs(value-targetBox![key as keyof typeof next])<.5))return;
  const current=marker.getBoundingClientRect(),from={left:current.left-bounds.left+host.scrollLeft,top:current.top-bounds.top+host.scrollTop,width:current.width,height:current.height};
  animation?.cancel();targetBox=next;
  Object.assign(marker.style,{left:next.left+'px',top:next.top+'px',width:next.width+'px',height:next.height+'px',opacity:'1'});
  if(animate&&!media?.matches&&typeof marker.animate==='function'){
   const px=(box:typeof next)=>Object.fromEntries(Object.entries(box).map(([key,value])=>[key,value+'px']));
   if(visible){
    const distance=surface?next.top-from.top:next.left-from.left;
    const stretch=surface?{...next,top:from.top+distance*.58,height:next.height+Math.min(Math.abs(distance)*.18,20)}:{...next,left:from.left+distance*.58,width:Math.max(from.width,next.width)+Math.min(Math.abs(distance)*.2,28)};
    const settle=surface?{...next,top:next.top+Math.sign(distance)*2}:{...next,left:next.left+Math.sign(distance)*2};
    animation=marker.animate([{...px(from),offset:0},{...px(stretch),offset:.48},{...px(settle),offset:.82},{...px(next),offset:1}],{duration:480,easing:'cubic-bezier(.2,.7,.2,1)'});
   }else animation=marker.animate([{opacity:0,transform:surface?'scale(.98)':'scaleX(.55)'},{opacity:1,transform:'scale(1)'}],{duration:280,easing:'cubic-bezier(.16,1,.3,1)'});
  }
  visible=true;
 };
 const schedule=(animate=true)=>{animateNext||=animate;if(!frame)frame=requestAnimationFrame(()=>{frame=0;const shouldAnimate=animateNext;animateNext=false;update(shouldAnimate)})};
 const mutation=new MutationObserver(()=>schedule());mutation.observe(host,{subtree:true,childList:true,attributes:true,attributeFilter:['class','aria-selected','aria-current']});
 const resize=typeof ResizeObserver==='undefined'?undefined:new ResizeObserver(()=>schedule(false));
 resize?.observe(host);host.querySelectorAll<HTMLElement>('a,button').forEach(element=>resize?.observe(element));
 const preference=()=>{animation?.cancel();update(false)};media?.addEventListener('change',preference);
 update(false);
 return {update,destroy(){cancelAnimationFrame(frame);animation?.cancel();mutation.disconnect();resize?.disconnect();media?.removeEventListener('change',preference);delete host.dataset.fpSelection;if(!provided)marker.remove()}};
}
