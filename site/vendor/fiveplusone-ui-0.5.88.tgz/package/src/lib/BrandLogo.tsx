export const brandLogoUrl = "https://go.r-l.ink/ico";
export function BrandLogo({
  size = 32,
  decorative = false,
}: {
  size?: number;
  decorative?: boolean;
}) {
  return (
    <img
      src={brandLogoUrl}
      alt={decorative ? "" : "五加一"}
      width={size}
      height={size}
      className="fp-brand-logo"
    />
  );
}
