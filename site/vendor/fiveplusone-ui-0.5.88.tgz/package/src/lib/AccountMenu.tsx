import {useState, type ReactNode} from 'react';
import {Popup} from './Popup';
import './account-menu.css';
export interface AccountMenuItem {id:string;label:string;icon?:ReactNode;detail?:string;shortcut?:string;separator?:boolean;danger?:boolean;disabled?:boolean;}
export function AccountMenu({name,description,avatarUrl,items,onSelect,busy=false}:{name:string;description?:string;avatarUrl?:string;items:AccountMenuItem[];onSelect:(id:string)=>void;busy?:boolean}){
 const [failed,setFailed]=useState('');
 const avatar=avatarUrl&&failed!==avatarUrl?<img src={avatarUrl} alt="" referrerPolicy="no-referrer" onError={()=>setFailed(avatarUrl)}/>:name.trim().slice(0,1).toUpperCase()||'我';
 return <span className="fp-account-menu-anchor"><Popup label="账号与设置" menu className="fp-account-menu" disabled={busy} trigger={<span className="fp-account-avatar" aria-hidden="true">{avatar}</span>}>{close=><><div className="fp-account-menu-identity"><span className="fp-account-avatar" aria-hidden="true">{avatar}</span><div><strong>{name}</strong>{description&&<small>{description}</small>}</div></div>{items.map(item=><div key={item.id} className={item.separator?'fp-account-menu-group':undefined}><button type="button" role="menuitem" disabled={item.disabled} className={item.danger?'fp-error-text':undefined} onClick={()=>{close();onSelect(item.id);}}>{item.icon}<span>{item.label}</span>{(item.detail||item.shortcut)&&<small>{item.detail||item.shortcut}</small>}</button></div>)}</>}</Popup></span>;
}
