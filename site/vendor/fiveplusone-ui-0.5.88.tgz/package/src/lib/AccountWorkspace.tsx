import {useState,type ReactNode} from 'react';
import {Menu,ChevronRight} from 'lucide-react';
import {Dialog} from './Dialog';
import {Button} from './PageControls';
import './account-workspace.css';
export interface AccountWorkspaceProps {
 brand:ReactNode; identity?:ReactNode; navigation:{id:string;label:string;icon?:ReactNode}[];
 activeId:string; onNavigate:(id:string)=>void; title:string; description?:string;
 actions?:ReactNode; footer?:ReactNode; children:ReactNode;
}
/** Quiet account workspace with a stable rail and a mobile navigation drawer. */
export function AccountWorkspace({brand,identity,navigation,activeId,onNavigate,title,description,actions,footer,children}:AccountWorkspaceProps){
 const [open,setOpen]=useState(false);
 const nav=<nav className="fp-account-nav" aria-label="账号功能">{navigation.map(item=><button type="button" key={item.id} aria-current={activeId===item.id?'page':undefined} onClick={()=>{onNavigate(item.id);setOpen(false);}}>{item.icon}<span>{item.label}</span></button>)}</nav>;
 return <div className="fp-account-workspace"><a className="fp-skip-link" href="#account-content">跳到主要内容</a><aside className="fp-account-rail"><div className="fp-account-brand">{brand}</div>{identity&&<div className="fp-account-identity">{identity}</div>}{nav}<div className="fp-account-rail-footer">{footer}</div></aside><div className="fp-account-stage"><header className="fp-account-topbar"><div><Button variant="ghost" className="fp-account-menu-button" aria-label="打开账号导航" onClick={()=>setOpen(true)}><Menu size={20}/></Button><span>账号中心</span><ChevronRight size={14}/><strong>{title}</strong></div><div className="fp-account-topbar-actions">{actions}</div></header><main id="account-content" className="fp-account-page"><header className="fp-account-page-heading"><h1>{title}</h1>{description&&<p>{description}</p>}</header>{children}</main></div><Dialog open={open} drawer title="账号中心" onClose={()=>setOpen(false)}>{identity}{nav}{footer}</Dialog></div>;
}
export function AccountPanel({title,description,children,actions,className=''}:{title:string;description?:string;children:ReactNode;actions?:ReactNode;className?:string}){
 return <section className={'fp-account-panel '+className}><header><div><h2>{title}</h2>{description&&<p>{description}</p>}</div>{actions}</header><div className="fp-account-panel-body">{children}</div></section>;
}
export function AccountSetting({label,value,description,icon,action}:{label:string;value?:ReactNode;description?:ReactNode;icon?:ReactNode;action?:ReactNode}){
 return <div className="fp-account-setting">{icon&&<span className="fp-account-setting-icon">{icon}</span>}<div className="fp-account-setting-copy"><h3>{label}</h3>{value&&<div className="fp-account-setting-value">{value}</div>}{description&&<p>{description}</p>}</div>{action&&<div className="fp-account-setting-action">{action}</div>}</div>;
}
