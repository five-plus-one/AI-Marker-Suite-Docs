import {useId,useState,useEffect,useCallback,createContext,useContext,type ReactNode,type InputHTMLAttributes} from 'react';
import {Check,ShieldCheck,AlertCircle,Info,CheckCircle2} from 'lucide-react';
import {Dialog} from './Dialog';
import {Button} from './PageControls';
import './account-task.css';
/** Progress belongs to a task, while verification and persistence remain host responsibilities. */
export function AccountTaskProgress({steps,current}:{steps:string[];current:number}){
 return <ol className="fp-account-task-progress" aria-label="操作步骤">{steps.map((step,index)=><li key={step} data-state={index<current?'complete':index===current?'current':'upcoming'} aria-current={index===current?'step':undefined}><span aria-hidden="true">{index<current?<Check size={14}/>:index+1}</span><strong>{step}</strong></li>)}</ol>;
}
export function AccountField({label,hint,error,...input}:InputHTMLAttributes<HTMLInputElement>&{label:string;hint?:ReactNode;error?:string}){
 const generated=useId(),id=input.id||generated,help=id+'-help';
 return <div className="fp-account-field"><label htmlFor={id}>{label}</label><input {...input} id={id} aria-invalid={!!error||undefined} aria-describedby={hint||error?help:undefined}/>{(error||hint)&&<p id={help} className={error?'fp-account-field-error':'fp-account-field-hint'} role={error?'alert':undefined}>{error&&<AlertCircle size={15}/>}<span>{error||hint}</span></p>}</div>;
}
export function AccountFeedback({tone='info',title,children,action}:{tone?:'info'|'success'|'error';title?:string;children?:ReactNode;action?:ReactNode}){
 const Icon=tone==='error'?AlertCircle:tone==='success'?CheckCircle2:Info;
 return <div className="fp-account-message" data-tone={tone} role={tone==='error'?'alert':'status'}><Icon size={19}/><div>{title&&<strong>{title}</strong>}{children&&<div>{children}</div>}{action&&<div className="fp-account-message-action">{action}</div>}</div></div>;
}
export function AccountVerificationIntro({description}:{description?:string}){return <div className="fp-account-verification-intro"><span><ShieldCheck size={22}/></span><div><h3>确认是你本人</h3><p>{description||'完成一次验证，即可继续本次安全设置。'}</p></div></div>;}

export function AccountCodeField({value,onChange,onSend,busy=false,sending=false,sent=false,remaining=0,error,label='邮箱验证码',destination}:{value:string;onChange:(value:string)=>void;onSend:()=>void;busy?:boolean;sending?:boolean;sent?:boolean;remaining?:number;error?:string;label?:string;destination?:string}){
 return <div className="fp-account-code-field">{destination&&<p className="fp-account-code-destination">{sent?'验证码已发送至':'使用此邮箱接收验证码'}<strong>{destination}</strong></p>}<div className="fp-account-code-controls"><AccountField label={label} value={value} onChange={e=>onChange(e.target.value.replace(/[^0-9]/g,''))} inputMode="numeric" autoComplete="one-time-code" maxLength={6} required disabled={busy} error={error} hint={sent?'请输入邮件中的 6 位验证码。':'请先发送验证码。'}/><Button variant="secondary" loading={sending} disabled={busy||remaining>0} onClick={onSend} aria-label={remaining>0?`${remaining} 秒后可以重新发送验证码`:sent?'重新发送验证码':'发送验证码'}>{sending?'正在发送…':remaining>0?`${remaining} 秒后重发`:sent?'重新发送':'发送验证码'}</Button></div></div>;
}

const BusyContext=createContext<((id:string,busy:boolean)=>void)|null>(null);
export function useAccountTaskBusy(busy:boolean){const update=useContext(BusyContext),id=useId();useEffect(()=>{update?.(id,busy);return()=>update?.(id,false);},[busy,id,update]);}
export function AccountTaskDialog({title,onClose,children,busy=false}:{title:string;onClose:()=>void;children:ReactNode;busy?:boolean}){
 const [pending,setPending]=useState<Record<string,boolean>>({});const update=useCallback((id:string,busy:boolean)=>setPending(old=>old[id]===busy?old:{...old,[id]:busy}),[]);
 return <Dialog open title={title} onClose={onClose} dismissible={!busy&&!Object.values(pending).some(Boolean)} className="fp-account-task-dialog"><BusyContext.Provider value={update}>{children}</BusyContext.Provider></Dialog>;
}
