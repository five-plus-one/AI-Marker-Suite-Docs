import type {AnchorHTMLAttributes, ReactNode} from 'react';
import {ArrowDownToLine,ArrowRight,CheckCircle2, CircleAlert, LoaderCircle,RefreshCw} from 'lucide-react';
import './app-surfaces.css';
export {Button,Spinner,Badge,Card,Tabs,Accordion} from './PageControls';
export {ThemeToggle} from './ThemeToggle';
export {AccountMenu,type AccountMenuItem} from './AccountMenu';
export {Tooltip,TooltipProvider} from './Tooltip';
export {ChoiceCards,type ChoiceCardOption} from './ChoiceCards';
export {ApplicationAccess,type ApplicationAccessProps} from './ApplicationAccess';
export {WindowChrome,type WindowChromeProps} from './WindowChrome';
export {AuthenticationWindow,type AuthenticationWindowProps} from './AuthenticationWindow';

export function ButtonLink({variant='primary',size='md',className='',...props}:AnchorHTMLAttributes<HTMLAnchorElement>&{variant?:'primary'|'secondary'|'ghost';size?:'sm'|'md'|'lg'}) {
 return <a {...props} className={`fp-button fp-button-link fp-${variant} fp-${size} ${className}`}/>;
}
export interface AppEntryLayoutProps {
 brand:ReactNode; eyebrow?:string; title:ReactNode; description:string;
 benefits?:{icon:ReactNode;label:string}[]; children:ReactNode; actions?:ReactNode; footer?:ReactNode;
}
export function AppEntryLayout({brand,eyebrow,title,description,benefits=[],children,actions,footer}:AppEntryLayoutProps){
 return <main className="fp-app-entry"><section className="fp-app-entry-story"><div className="fp-app-entry-brand">{brand}</div><div className="fp-app-entry-copy">{eyebrow&&<p className="fp-eyebrow">{eyebrow}</p>}<h1>{title}</h1><p>{description}</p><ul>{benefits.map(item=><li key={item.label}>{item.icon}<span>{item.label}</span></li>)}</ul></div>{footer&&<footer>{footer}</footer>}</section><section className="fp-app-entry-panel">{actions&&<div className="fp-app-entry-window">{actions}</div>}<div className="fp-app-entry-content">{children}</div></section></main>;
}
export interface StatusPageProps {
 brand?:ReactNode; title:string; description:string; tone?:'success'|'error'|'loading'|'neutral';
 children?:ReactNode; actions?:ReactNode; headerActions?:ReactNode; footer?:ReactNode;
}
export function StatusPage({brand,title,description,tone='neutral',children,actions,headerActions,footer}:StatusPageProps){
 return <main className="fp-status-page"><header className="fp-status-page-header">{brand}<div>{headerActions}</div></header><section className="fp-status-card" data-tone={tone} aria-labelledby="status-heading"><div className="fp-status-symbol" aria-hidden="true">{tone==='success'?<CheckCircle2 size={32}/>:tone==='loading'?<LoaderCircle size={32}/>:<CircleAlert size={32}/>}</div><h1 id="status-heading">{title}</h1><p className="fp-status-description" role={tone==='error'?'alert':'status'}>{description}</p>{children}{actions&&<div className="fp-status-actions">{actions}</div>}{footer&&<footer>{footer}</footer>}</section></main>;
}
export interface ProductLandingProps {brand:ReactNode;navigation?:ReactNode;headerActions?:ReactNode;eyebrow?:string;title:ReactNode;description:string;actions:ReactNode;meta?:ReactNode;preview:ReactNode;children:ReactNode;footer:ReactNode;}
export function ProductLanding({brand,navigation,headerActions,eyebrow,title,description,actions,meta,preview,children,footer}:ProductLandingProps){
 return <div className="fp-product-landing"><a className="fp-skip-link" href="#main">跳到主要内容</a><header className="fp-product-header"><div className="fp-product-header-inner">{brand}<nav aria-label="页面导航">{navigation}</nav><div className="fp-product-header-actions">{headerActions}</div></div></header><main id="main"><section className="fp-product-hero"><div className="fp-product-hero-copy">{eyebrow&&<p className="fp-eyebrow">{eyebrow}</p>}<h1>{title}</h1><p className="fp-product-description">{description}</p><div className="fp-product-actions">{actions}</div>{meta&&<div className="fp-product-meta">{meta}</div>}</div><div className="fp-product-preview">{preview}</div></section>{children}</main><footer className="fp-product-footer">{footer}</footer></div>;
}
export function ProductSection({id,eyebrow,title,description,children}: {id?:string;eyebrow?:string;title:string;description?:string;children:ReactNode}){
 return <section id={id} className="fp-product-section"><header>{eyebrow&&<p className="fp-eyebrow">{eyebrow}</p>}<h2>{title}</h2>{description&&<p>{description}</p>}</header>{children}</section>;
}
export function ProductFeatures({items}:{items:{icon:ReactNode;title:string;description:string}[]}){
 return <div className="fp-product-features">{items.map(item=><article key={item.title}><div className="fp-product-feature-icon">{item.icon}</div><h3>{item.title}</h3><p>{item.description}</p></article>)}</div>;
}
export function WorkspaceSkeleton({brand='课栈笔记',label='正在打开工作区',actions}: {brand?:ReactNode;label?:string;actions?:ReactNode}){
 return <div className="fp-workspace-skeleton" role="status" aria-label={label} aria-busy="true"><header><strong>{brand}</strong><div>{actions}</div></header><div className="fp-workspace-skeleton-body"><aside><i/><i/><i/><i/></aside><section><i/><i/><i/><i/><i/></section></div></div>;
}

export interface UpdatePanelProps {
 phase:'checking'|'preparing'|'available'|'downloading'|'verifying'|'installing'|'ready'|'current'|'error';
 title:string; description:string; currentVersion?:string; version?:string;
 notes?:string; progress?:number; required?:boolean; compact?:boolean; actions:ReactNode;
}
export function UpdatePanel({phase,title,description,currentVersion,version,notes,progress=0,required=false,compact=false,actions}:UpdatePanelProps){
 const value=Math.max(0,Math.min(100,Number.isFinite(progress)?progress:0));
 return <section className="fp-update-panel" data-phase={phase} data-compact={compact||undefined}>
  <div className="fp-update-art" aria-hidden="true"><span>{['checking','preparing','verifying','installing'].includes(phase)?<LoaderCircle size={34}/>:phase==='error'?<CircleAlert size={34}/>:phase==='ready'||phase==='current'?<CheckCircle2 size={34}/>:phase==='downloading'?<ArrowDownToLine size={34}/>:<RefreshCw size={34}/>}</span><i/><i/></div>
  <div className="fp-update-heading">{required&&<span className="fp-update-required">需要更新</span>}<h3>{title}</h3><p role={phase==='error'?'alert':'status'}>{description}</p></div>
  {(currentVersion||version)&&<div className="fp-update-versions"><span><small>当前版本</small><strong>{currentVersion||'—'}</strong></span>{version&&<><ArrowRight size={18} aria-hidden="true"/><span><small>最新版本</small><strong>{version}</strong></span></>}</div>}
  {notes&&<section className="fp-update-notes"><h4>本次更新</h4><p>{notes}</p></section>}
  {phase==='downloading'&&<div className="fp-update-progress"><div><span>正在下载</span><strong>{Math.round(value)}%</strong></div><div role="progressbar" aria-label="更新下载进度" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}><i style={{width:`${value}%`}}/></div></div>}
  <div className="fp-update-actions">{actions}</div>
 </section>;
}

export * from './InstallerPanel';

export * from './FeatureCardStack';

export * from './DocumentationLayout';

export * from './MarkerLogo';

export * from './DocumentationSearch';

export * from './ProductStatementHero';
