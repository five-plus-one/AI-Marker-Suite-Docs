import { type ReactNode } from 'react';
import './account-workspace.css';
export interface AccountWorkspaceProps {
    brand: ReactNode;
    identity?: ReactNode;
    navigation: {
        id: string;
        label: string;
        icon?: ReactNode;
    }[];
    activeId: string;
    onNavigate: (id: string) => void;
    title: string;
    description?: string;
    actions?: ReactNode;
    footer?: ReactNode;
    children: ReactNode;
}
/** Quiet account workspace with a stable rail and a mobile navigation drawer. */
export declare function AccountWorkspace({ brand, identity, navigation, activeId, onNavigate, title, description, actions, footer, children }: AccountWorkspaceProps): import("react").JSX.Element;
export declare function AccountPanel({ title, description, children, actions, className }: {
    title: string;
    description?: string;
    children: ReactNode;
    actions?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
export declare function AccountSetting({ label, value, description, icon, action }: {
    label: string;
    value?: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    action?: ReactNode;
}): import("react").JSX.Element;
