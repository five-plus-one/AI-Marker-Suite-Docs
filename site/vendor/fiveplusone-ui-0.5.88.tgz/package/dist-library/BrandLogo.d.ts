export declare const brandLogoUrl = "https://go.r-l.ink/ico";
export declare function BrandLogo({ size, decorative, }: {
    size?: number;
    decorative?: boolean;
}): import("react").JSX.Element;
