export interface DocumentationSearchEntry {
    url: string;
    title: string;
    heading?: string;
    group?: string;
    text: string;
}
export declare function rankDocumentation(entries: DocumentationSearchEntry[], query: string): DocumentationSearchEntry[];
export declare function DocumentationSearch({ open, onClose, entries, loading, error, onRetry, initialQuery }: {
    open: boolean;
    onClose: () => void;
    entries: DocumentationSearchEntry[];
    loading?: boolean;
    error?: boolean;
    onRetry?: () => void;
    initialQuery?: string;
}): import("react").JSX.Element;
