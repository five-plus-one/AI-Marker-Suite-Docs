import type { ReactNode } from 'react';
export declare function ProductStatementHero({ eyebrow, title, statement, description, actions, meta, preview, pattern }: {
    eyebrow: string;
    title: string;
    statement: string;
    description: string;
    actions: ReactNode;
    meta?: ReactNode;
    preview?: ReactNode;
    pattern?: string;
}): import("react").JSX.Element;
export declare function ProductEditorialSections({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function ProductEditorialSection({ kind, children, label }: {
    kind?: 'split' | 'community' | 'support' | 'links';
    children: ReactNode;
    label?: string;
}): import("react").JSX.Element;
import './product-editorial.css';
