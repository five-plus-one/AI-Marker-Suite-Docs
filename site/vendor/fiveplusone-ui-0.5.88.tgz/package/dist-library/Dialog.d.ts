import { type ReactNode } from 'react';
export declare function Dialog({ open, onClose, title, children, footer, drawer, className, dismissible, }: {
    open: boolean;
    onClose: () => void;
    title: string;
    children: ReactNode;
    footer?: ReactNode;
    drawer?: boolean;
    className?: string;
    dismissible?: boolean;
}): import("react").ReactPortal | null;
export declare function Drawer(p: Omit<Parameters<typeof Dialog>[0], "drawer">): import("react").JSX.Element;
