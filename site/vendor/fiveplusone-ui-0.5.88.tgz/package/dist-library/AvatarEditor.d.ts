import './avatar-editor.css';
export declare function calculateAvatarCrop(width: number, height: number, zoom: number, x: number, y: number): {
    x: number;
    y: number;
    size: number;
};
export interface AvatarEditorProps {
    name: string;
    avatarUrl?: string;
    onSave: (file: File) => Promise<void>;
    onChooseLibrary?: () => Promise<Blob | null>;
    maxBytes?: number;
}
/** Local and connected-library images share a crop, preview and confirmed upload. */
export declare function AvatarEditor({ name, avatarUrl, onSave, onChooseLibrary, maxBytes }: AvatarEditorProps): import("react").JSX.Element;
