import { type ReactNode } from 'react';
export interface ToolbarAction {
    id: string;
    label: string;
    icon: ReactNode;
    onSelect: () => void;
    disabled?: boolean;
    danger?: boolean;
}
export declare function visibleActionCount(widths: number[], available: number, more: number, gap: number): number;
/** Expose actions as space permits and retain their order in the overflow menu. */
export declare function ActionToolbar({ actions, label, moreLabel, className, showLabels }: {
    actions: ToolbarAction[];
    label?: string;
    moreLabel?: string;
    className?: string;
    showLabels?: boolean;
}): import("react").JSX.Element;
