import {execFileSync} from 'node:child_process';
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
for (const args of [
 ['exec','--','tailwindcss','-i','src/lib/learning-utilities.input.css','-o','src/lib/learning-utilities.css','--config','tailwind.learning.cjs','--minify'],
 ['exec','--','vite','build','--config','vite.lib.config.ts'],
 ['exec','--','tsc','-p','tsconfig.lib.json'],
]) execFileSync(npm,args,{stdio:'inherit',shell:process.platform==='win32'});
for (const script of ['build-window-titlebar','build-app-surfaces','build-oauth-window','build-account-surfaces']) execFileSync(process.execPath,['scripts/'+script+'.mjs'],{stdio:'inherit'});
