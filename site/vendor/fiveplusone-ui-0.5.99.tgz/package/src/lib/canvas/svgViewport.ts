function dimension(tag: string, name: string): number | undefined {
  const value = tag.match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']+)["']`, "i"))?.[1];
  if (!value || !/^\s*\d+(?:\.\d+)?(?:px)?\s*$/.test(value)) return;
  const number = parseFloat(value);
  return number > 0 && Number.isFinite(number) ? number : undefined;
}
export function prepareSvgViewport(source: string, width = 400, height = 300) {
  const valid = (n: number, fallback: number) => Number.isFinite(n) && n > 0 ? n : fallback;
  width = valid(width, 400); height = valid(height, 300);
  const root = source.match(/<svg\b[^>]*>/i);
  if (!root) return { markup: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}">${source}</svg>`, width, height };
  const values = root[0].match(/\bviewBox\s*=\s*["']([^"']+)["']/i)?.[1].trim().split(/[\s,]+/).map(Number);
  const hasViewBox = values?.length === 4 && values.every(Number.isFinite) && values[2] > 0 && values[3] > 0;
  width = hasViewBox ? values![2] : dimension(root[0], "width") ?? width;
  height = hasViewBox ? values![3] : dimension(root[0], "height") ?? height;
  let tag = root[0].replace(/\s(?:width|height|preserveAspectRatio)\s*=\s*(?:"[^"]*"|'[^']*')/gi, "");
  if (!hasViewBox) tag = tag.replace(/\sviewBox\s*=\s*(?:"[^"]*"|'[^']*')/gi, "").replace(/<svg\b/i, `<svg viewBox="0 0 ${width} ${height}"`);
  tag = tag.replace(/<svg\b/i, '<svg preserveAspectRatio="xMidYMid meet"');
  return { markup: source.replace(root[0], tag), width, height };
}
/** Trim pronounced empty margins after fonts settle, retaining room for strokes and markers. */
export function fitSvgWhitespace(svg: SVGSVGElement): { width: number; height: number; viewBox: string } | undefined {
  try {
    if (svg.querySelector('[filter],[mask]')) return;
    const box = svg.getBBox(), original = svg.viewBox.baseVal;
    if (!box.width || !box.height || !original.width || !original.height) return;
    const stroke = Math.max(1, ...Array.from(svg.querySelectorAll('path,line,polyline,polygon,circle,ellipse,rect,text')).map(e => parseFloat(getComputedStyle(e).strokeWidth) || 0));
    const marker = Math.max(3, ...Array.from(svg.querySelectorAll('marker')).map(e => Math.max(parseFloat(e.getAttribute('markerWidth') || '3'), parseFloat(e.getAttribute('markerHeight') || '3'))));
    const pad = Math.max(24, Math.max(box.width, box.height) * 0.04, stroke * marker);
    const width = box.width + pad * 2, height = box.height + pad * 2;
    if (width >= original.width * 0.65 && height >= original.height * 0.65) return;
    // Content outside the authored viewBox may be intentionally clipped.
    if (box.x < original.x - 1 || box.y < original.y - 1 || box.x + box.width > original.x + original.width + 1 || box.y + box.height > original.y + original.height + 1) return;
    const viewBox = `${box.x - pad} ${box.y - pad} ${width} ${height}`;
    svg.setAttribute("viewBox", viewBox);
    return { width, height, viewBox };
  } catch { return; }
}
