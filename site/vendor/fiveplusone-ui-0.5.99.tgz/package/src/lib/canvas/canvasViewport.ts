export interface CanvasPoint { x: number; y: number }
export interface CanvasView { x: number; y: number; zoom: number }
export const initialCanvasView: CanvasView = { x: 0, y: 0, zoom: 1 };
export function zoomCanvasAt(view: CanvasView, point: CanvasPoint, zoom: number): CanvasView {
  const next = Math.max(0.25, Math.min(4, zoom));
  const factor = next / view.zoom;
  return { x: point.x - (point.x - view.x) * factor, y: point.y - (point.y - view.y) * factor, zoom: next };
}
export function moveCanvasGesture(view: CanvasView, from: CanvasPoint[], to: CanvasPoint[], zoomable = true, pannable = true): CanvasView {
  const center = (points: CanvasPoint[]) => ({ x: points.reduce((v, p) => v + p.x, 0) / points.length, y: points.reduce((v, p) => v + p.y, 0) / points.length });
  const before = center(from), after = center(to);
  const distance = (points: CanvasPoint[]) => Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
  const factor = zoomable && from.length === 2 && to.length === 2 && distance(from) > 2 ? distance(to) / distance(from) : 1;
  const next = zoomCanvasAt(view, before, view.zoom * factor);
  return { ...next, x: next.x + (pannable ? after.x - before.x : 0), y: next.y + (pannable ? after.y - before.y : 0) };
}
