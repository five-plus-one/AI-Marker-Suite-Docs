"use client";
import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { initialCanvasView, moveCanvasGesture, zoomCanvasAt, type CanvasPoint, type CanvasView } from "./canvasViewport";

/** Inline scrolling remains native until two fingers manipulate the diagram.
 * Keep that gesture on the diagram until every finger has lifted. */
export function useCanvasGesture<T extends HTMLElement | SVGSVGElement>({ fullscreen = false, pannable = true, zoomable = true, resetKey, origin = "top-left" }: { fullscreen?: boolean; pannable?: boolean; zoomable?: boolean; resetKey?: unknown; origin?: "top-left" | "center" } = {}) {
  const [element, ref] = useState<T | null>(null);
  const [view, setView] = useState<CanvasView>(initialCanvasView);
  const current = useRef(view);
  const mouse = useRef<{ id: number; point: CanvasPoint } | null>(null);
  const apply = useCallback((next: CanvasView) => { current.current = next; setView(next); }, []);
  const reset = useCallback(() => apply(initialCanvasView), [apply]);
  useEffect(reset, [reset, resetKey]);
  const point = useCallback((x: number, y: number): CanvasPoint => {
    if (!element) return { x, y };
    if (element instanceof SVGSVGElement) {
      const matrix = element.getScreenCTM();
      if (matrix) { const p = new DOMPoint(x, y).matrixTransform(matrix.inverse()); return { x: p.x, y: p.y }; }
    }
    const rect = element.getBoundingClientRect();
    return { x: x - rect.left - (origin === "center" ? rect.width / 2 : 0), y: y - rect.top - (origin === "center" ? rect.height / 2 : 0) };
  }, [element, origin]);
  const zoomBy = useCallback((factor: number) => {
    if (!element || !zoomable) return;
    const rect = element.getBoundingClientRect();
    apply(zoomCanvasAt(current.current, point(rect.left + rect.width / 2, rect.top + rect.height / 2), current.current.zoom * factor));
  }, [element, point, apply, zoomable]);
  useEffect(() => {
    if (!element) return;
    let gesture: { ids: number[]; points: CanvasPoint[] } | null = null;
    let manipulating = false;
    const touches = (event: TouchEvent) => Array.from(event.touches).filter(t => t.target instanceof Node && element.contains(t.target));
    const start = (raw: Event) => {
      const event = raw as TouchEvent;
      const active = touches(event);
      if (!active.length) { gesture = null; manipulating = false; return; }
      if ((!fullscreen && !manipulating && active.length < 2) || (!pannable && !zoomable) || !event.cancelable) { gesture = null; return; }
      event.preventDefault();
      manipulating = true;
      const selected = active.slice(0, 2);
      gesture = { ids: selected.map(t => t.identifier), points: selected.map(t => point(t.clientX, t.clientY)) };
    };
    const move = (raw: Event) => {
      const event = raw as TouchEvent;
      if (!gesture || !event.cancelable) { gesture = null; return; }
      const active = touches(event);
      const selected = gesture.ids.map(id => active.find(t => t.identifier === id));
      if (selected.some(t => !t)) { start(event); return; }
      event.preventDefault();
      const next = selected.map(t => point(t!.clientX, t!.clientY));
      apply(moveCanvasGesture(current.current, gesture.points, next, zoomable, pannable));
      gesture.points = next;
    };
    const cancel = () => { gesture = null; manipulating = false; mouse.current = null; };
    const wheel = (raw: Event) => {
      const event = raw as WheelEvent;
      if (!zoomable || (!event.ctrlKey && !event.metaKey)) return;
      event.preventDefault();
      apply(zoomCanvasAt(current.current, point(event.clientX, event.clientY), current.current.zoom * Math.exp(-event.deltaY * 0.002)));
    };
    element.addEventListener("touchstart", start, { passive: false });
    element.addEventListener("touchmove", move, { passive: false });
    element.addEventListener("touchend", start, { passive: false });
    element.addEventListener("touchcancel", cancel);
    element.addEventListener("wheel", wheel, { passive: false });
    window.addEventListener("blur", cancel);
    return () => {
      cancel();
      element.removeEventListener("touchstart", start); element.removeEventListener("touchmove", move);
      element.removeEventListener("touchend", start); element.removeEventListener("touchcancel", cancel);
      element.removeEventListener("wheel", wheel); window.removeEventListener("blur", cancel);
    };
  }, [element, fullscreen, pannable, zoomable, point, apply]);
  const finish = useCallback((event: ReactPointerEvent<T>) => {
    if (mouse.current?.id === event.pointerId) mouse.current = null;
  }, []);
  return { ref, element, view, reset, zoomBy, bind: {
    onPointerDown: (event: ReactPointerEvent<T>) => {
      if (event.pointerType === "touch" || !pannable || event.button !== 0 || mouse.current) return;
      if ((event.target as Element).closest?.("button,a,input,textarea")) return;
      mouse.current = { id: event.pointerId, point: point(event.clientX, event.clientY) };
      event.currentTarget.setPointerCapture(event.pointerId);
    },
    onPointerMove: (event: ReactPointerEvent<T>) => {
      const drag = mouse.current;
      if (!drag || drag.id !== event.pointerId) return;
      const next = point(event.clientX, event.clientY);
      apply(moveCanvasGesture(current.current, [drag.point], [next], false, pannable));
      drag.point = next;
    },
    onPointerUp: finish, onPointerCancel: finish, onLostPointerCapture: finish,
    style: { touchAction: pannable || zoomable ? fullscreen ? "none" : "pan-y" : "auto" },
  } };
}
