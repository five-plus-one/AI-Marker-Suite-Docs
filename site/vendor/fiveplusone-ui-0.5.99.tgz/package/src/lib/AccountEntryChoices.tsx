import type { ReactNode } from 'react';
import { CircleHelp } from 'lucide-react';
import { CollapsibleSection } from './CollapsibleSection';
import { TooltipProvider } from './Tooltip';
import './account-entry-choices.css';
export interface AccountEntryChoicesProps {
 primaryAction: ReactNode;
 primaryDescription: string;
 secondaryAction?: ReactNode;
 secondaryDescription?: string;
 /** Put descriptions behind a compact, initially collapsed help control. */
 helpLabel?: string;
 helpContent?: ReactNode;
}
/** Two account entry actions, ordered by the recommended path. The host owns authentication. */
export function AccountEntryChoices(props: AccountEntryChoicesProps) {
 return <TooltipProvider><div className="fp-account-entry-choices">
  <div className="fp-account-entry-choice" data-emphasis="primary">{props.primaryAction}{!props.helpLabel && <p>{props.primaryDescription}</p>}</div>
  {props.secondaryAction && <div className="fp-account-entry-choice" data-emphasis="secondary">{props.secondaryAction}{!props.helpLabel && <p>{props.secondaryDescription}</p>}</div>}
  {props.helpLabel && <CollapsibleSection className="fp-account-entry-help" label={<span className="fp-account-entry-help-label"><CircleHelp size={16} aria-hidden="true" />{props.helpLabel}</span>}>
   <div className="fp-account-entry-help-copy"><p>{props.primaryDescription}</p>{props.secondaryAction && props.secondaryDescription && <p>{props.secondaryDescription}</p>}{props.helpContent}</div>
  </CollapsibleSection>}
 </div></TooltipProvider>;
}
