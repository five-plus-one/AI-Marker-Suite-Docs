import { Extension, type Editor } from "@tiptap/core";
import { Plugin, PluginKey, NodeSelection } from "@tiptap/pm/state";
import { closeHistory } from "@tiptap/pm/history";
import { yUndoPluginKey } from "@tiptap/y-tiptap";

type OpenMath = (latex: string, position: number) => void;
const key = new PluginKey("mathDollarShortcut");
const pending = new WeakMap<Editor, { position: number; promote: () => boolean }>();

export function clearDollarShortcut(editor: Editor, position?: number) {
  if (position === undefined || pending.get(editor)?.position === position) pending.delete(editor);
}

export function promoteDollarShortcut(editor: Editor, position: number) {
  const shortcut = pending.get(editor);
  if (!shortcut || shortcut.position !== position) return false;
  pending.delete(editor);
  return shortcut.promote();
}

export function createMathDollarShortcut(onInline?: OpenMath, onBlock?: OpenMath) {
  return Extension.create({
    name: "mathDollarShortcut",
    priority: 1100,
    addProseMirrorPlugins() {
      const editor = this.editor;
      const insert = (from: number, to: number, display: boolean) => {
        yUndoPluginKey.getState(editor.state)?.undoManager.stopCapturing();
        editor.view.dispatch(closeHistory(editor.state.tr));
        let position: number | undefined;
        const type = display ? "blockMath" : "inlineMath";
        const inserted = editor.chain().insertContentAt({ from, to }, { type, attrs: { latex: "" } })
          .command(({ tr }) => {
            tr.mapping.maps.at(-1)?.forEach((_a, _b, start, end) => {
              tr.doc.nodesBetween(start, end, (node, pos) => {
                if (node.type.name === type) { position = pos; return false; }
              });
            });
            if (position === undefined) return false;
            tr.setSelection(NodeSelection.create(tr.doc, position)).setMeta(key, true);
            return true;
          }).run();
        if (!inserted || position === undefined) return false;
        const pos = position;
        if (!display) pending.set(editor, { position: pos, promote: () => insert(pos, pos + 1, true) });
        (display ? onBlock : onInline)?.("", pos);
        return true;
      };
      return [new Plugin({
        key,
        state: {
          init: () => null,
          apply(tr) {
            const shortcut = pending.get(editor);
            if (shortcut && !tr.getMeta(key) && (tr.docChanged || tr.selectionSet)) {
              const node = tr.doc.nodeAt(shortcut.position);
              if (node?.type.name !== "inlineMath" || node.attrs.latex !== "" ||
                  tr.selection.from < shortcut.position || tr.selection.to > shortcut.position + 1) pending.delete(editor);
            }
            return null;
          },
        },
        props: {
          handleTextInput(view, from, to, text) {
            if (!editor.isEditable || view.composing) return false;
            const shortcut = pending.get(editor);
            if (shortcut && from >= shortcut.position && to <= shortcut.position + 1) {
              if (text === "$") return promoteDollarShortcut(editor, shortcut.position);
              pending.delete(editor);
              view.dispatch(view.state.tr.setNodeMarkup(shortcut.position, undefined, { latex: text }));
              return true;
            }
            if (from !== to) return false;
            const point = view.state.doc.resolve(from);
            if (!point.parent.isTextblock || point.parent.type.spec.code ||
              (view.state.storedMarks || point.marks()).some(mark => mark.type.spec.code)) return false;
            const before = point.parent.textBetween(0, point.parentOffset, "\n", "\ufffc");
            const typed = before + text;
            const match = /(?<!\$)(\${2,3})$/.exec(typed);
            if (!match || text.length > match[1].length) return false;
            const escapes = /\\+$/.exec(typed.slice(0, match.index))?.[0].length ?? 0;
            if (escapes % 2 === 1) return false;
            return insert(from - (match[1].length - text.length), to, match[1].length === 3);
          },
          handleDOMEvents: { pointerdown: () => { pending.delete(editor); return false; } },
          handleKeyDown: (_view, event) => {
            const shortcut = pending.get(editor);
            if (shortcut && event.key === "$" && !event.isComposing && event.keyCode !== 229 && !event.ctrlKey && !event.metaKey && !event.altKey)
              return promoteDollarShortcut(editor, shortcut.position);
            if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown", "Tab", "Escape", "Backspace", "Delete"].includes(event.key)) pending.delete(editor);
            return false;
          },
        },
        view: () => {
          // WebKit can briefly focus body while a nested node view moves its input.
          const handoff = (event: KeyboardEvent) => {
            const shortcut = pending.get(editor);
            if (!shortcut || event.defaultPrevented || event.target !== document.body ||
                !editor.view.dom.isConnected || event.isComposing || event.keyCode === 229 ||
                event.ctrlKey || event.metaKey || event.altKey) return;
            if (event.key === "$" && promoteDollarShortcut(editor, shortcut.position)) {
              event.preventDefault(); event.stopPropagation();
            }
          };
          const disarm = () => pending.delete(editor);
          document.addEventListener("keydown", handoff, true);
          document.addEventListener("pointerdown", disarm, true);
          return { destroy: () => {
            disarm();
            document.removeEventListener("keydown", handoff, true);
            document.removeEventListener("pointerdown", disarm, true);
          } };
        },
      })];
    },
  });
}
