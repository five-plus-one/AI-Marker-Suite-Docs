import type { MathfieldElement } from "mathlive";

/** Native IMEs may send deletion input without a Backspace keydown. */
export function installMathNativeInput(field: MathfieldElement): () => void {
  const root = field.shadowRoot;
  if (!root) return () => {};
  const commands = {
    deleteContentBackward: "deleteBackward",
    deleteContentForward: "deleteForward",
    deleteWordBackward: "deletePreviousWord",
    deleteWordForward: "deleteNextWord",
  } as const;
  let pending: string | undefined;
  let composing = false;
  let deletionKey: KeyboardEvent | undefined;
  const keyDown = (event: Event) => {
    const key = event as KeyboardEvent;
    deletionKey = key.key === "Backspace" || key.key === "Delete" ? key : undefined;
  };
  const clearKey = () => { deletionKey = undefined; };
  const keyAlreadyHandled = (event: InputEvent) => {
    const key = deletionKey;
    deletionKey = undefined;
    return key?.defaultPrevented && Math.abs(event.timeStamp - key.timeStamp) < 200 &&
      ((key.key === "Backspace" && event.inputType.endsWith("Backward")) ||
       (key.key === "Delete" && event.inputType.endsWith("Forward")));
  };
  const compositionStart = () => { composing = true; };
  const compositionEnd = () => { composing = false; };
  const command = (event: InputEvent) => {
    // MathLive also emits semantic input events from the host. Those must not
    // run a second edit, nor should an IME's active composition be interrupted.
    if (composing || event.isComposing || event.target === field || !(event.target instanceof HTMLElement)) return;
    return commands[event.inputType as keyof typeof commands];
  };
  const before = (event: Event) => {
    const input = event as InputEvent, action = command(input);
    if (!action || !input.cancelable) return;
    input.preventDefault();
    input.stopImmediatePropagation();
    pending = input.inputType;
    queueMicrotask(() => { pending = undefined; });
    if (!keyAlreadyHandled(input)) field.executeCommand(action);
  };
  const after = (event: Event) => {
    const input = event as InputEvent, action = command(input);
    if (!action) return;
    input.stopImmediatePropagation();
    // Some IMEs deliver only input, or a non-cancelable beforeinput.
    (input.target as HTMLElement).textContent = "";
    if (pending !== input.inputType && !keyAlreadyHandled(input)) field.executeCommand(action);
    pending = undefined;
  };
  root.addEventListener("beforeinput", before, true);
  root.addEventListener("input", after, true);
  root.addEventListener("compositionstart", compositionStart, true);
  root.addEventListener("compositionend", compositionEnd, true);
  root.addEventListener("keydown", keyDown, true);
  root.addEventListener("keyup", clearKey, true);
  field.addEventListener("blur", clearKey);
  return () => {
    root.removeEventListener("beforeinput", before, true);
    root.removeEventListener("input", after, true);
    root.removeEventListener("compositionstart", compositionStart, true);
    root.removeEventListener("compositionend", compositionEnd, true);
    root.removeEventListener("keydown", keyDown, true);
    root.removeEventListener("keyup", clearKey, true);
    field.removeEventListener("blur", clearKey);
  };
}
