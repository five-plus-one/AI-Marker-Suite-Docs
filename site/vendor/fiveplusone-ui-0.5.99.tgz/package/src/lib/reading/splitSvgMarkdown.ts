export type SvgMarkdownPart = { kind: "markdown"; content: string } | { kind: "svg"; content: string };
export function mapMarkdownOutsideCode(source: string, transform: (text: string) => string): string {
  const inline = (text: string) => {
    const spans = /(`+)[\s\S]*?\1/g; let result = "", last = 0, span: RegExpExecArray | null;
    while ((span = spans.exec(text))) { result += transform(text.slice(last, span.index)) + span[0]; last = spans.lastIndex; }
    return result + transform(text.slice(last));
  };
  const fences = /^ {0,3}(`{3,}|~{3,})[^\r\n]*\r?\n/gm;
  let result = "", last = 0, opening: RegExpExecArray | null;
  while ((opening = fences.exec(source))) {
    result += inline(source.slice(last, opening.index));
    const close = new RegExp(`^ {0,3}${opening[1][0]}{${opening[1].length},}[\\t ]*(?:\\r?\\n|$)`, "gm"); close.lastIndex = fences.lastIndex;
    if (!close.exec(source)) return result + source.slice(opening.index);
    result += source.slice(opening.index, close.lastIndex); last = close.lastIndex; fences.lastIndex = last;
  }
  return result + inline(source.slice(last));
}
/** Separate complete diagrams while retaining ordinary fenced code verbatim. */
export function splitSvgMarkdown(source: string): SvgMarkdownPart[] {
  const parts: SvgMarkdownPart[] = [];
  const markdown = (content: string) => {
    if (!content) return;
    const last = parts.at(-1);
    if (last?.kind === "markdown") last.content += content;
    else parts.push({ kind: "markdown", content });
  };
  const raw = (text: string) => {
    // Inline code is content, even if it happens to contain SVG markup.
    const tokens = /(`+)[\s\S]*?\1|<\/?svg\b[^>]*>/gi;
    let token: RegExpExecArray | null, depth = 0, start = 0, last = 0;
    while ((token = tokens.exec(text))) {
      if (token[1] && !depth) continue;
      if (token[0].startsWith("`")) continue;
      const closing = /^<\//.test(token[0]), selfClosing = /\/\s*>$/.test(token[0]);
      if (!closing) { if (depth === 0) start = token.index; if (!selfClosing) depth++; }
      else if (depth > 0) depth--;
      else continue;
      if (depth === 0) {
        markdown(text.slice(last, start)); parts.push({ kind: "svg", content: text.slice(start, tokens.lastIndex) }); last = tokens.lastIndex;
      }
    }
    markdown(text.slice(last));
  };
  const fences = /^ {0,3}(`{3,}|~{3,})([^\r\n]*)\r?\n/gm;
  let opening: RegExpExecArray | null, last = 0;
  while ((opening = fences.exec(source))) {
    raw(source.slice(last, opening.index));
    const close = new RegExp(`^ {0,3}${opening[1][0]}{${opening[1].length},}[\\t ]*(?:\\r?\\n|$)`, "gm"); close.lastIndex = fences.lastIndex;
    const closing = close.exec(source);
    if (!closing) { markdown(source.slice(opening.index)); return parts; }
    const body = source.slice(fences.lastIndex, closing.index).trim();
    const language = opening[2].trim().toLowerCase();
    if (["", "svg", "xml", "html"].includes(language) && /^<svg\b[\s\S]*<\/svg\s*>$/i.test(body)) {
      raw(body);
    } else markdown(source.slice(opening.index, close.lastIndex));
    last = close.lastIndex; fences.lastIndex = last;
  }
  raw(source.slice(last)); return parts;
}
