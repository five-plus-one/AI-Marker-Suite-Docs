import { CALLOUTS, canonicalDirectiveName } from './calloutTypes';

/** Accept conversational callout shorthand while retaining code and source content. */
export function normalizeAssistantMarkdown(source: string): string {
  let fence = '', fenceLength = 0;
  return source.split('\n').map(line => {
    const boundary = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
    if (boundary) {
      const marker=boundary[1];
      if (!fence) {fence=marker[0];fenceLength=marker.length;}
      else if (marker[0]===fence && marker.length>=fenceLength && !boundary[2].trim()) fence='';
      return line;
    }
    if (fence || /^(?: {4}|\t)/.test(line)) return line;
    const directive=line.match(/^( {0,3})(:{3,})([\w-]+)[ \t]+(\S.*)$/);
    if (directive && CALLOUTS.has(canonicalDirectiveName(directive[3]))) {
      line=`${directive[1]}${directive[2]}${canonicalDirectiveName(directive[3])}\n${directive[1]}${directive[4]}`;
    }
    // Move paired quotation marks outside emphasis delimiters for CJK flanking rules.
    // Inline code spans and escaped delimiters remain literal.
    return line.split(/(`+[^`]*`+)/g).map(part=>part.startsWith('`')?part:part.replace(
      /(^|[^\\])\*\*([“‘「『《])([^\n]+?)([”’」』》])\*\*/g,
      (_all,prefix,open,body,close)=>`${prefix}${open}**${body}**${close}`,
    )).join('');
  }).join('\n');
}
