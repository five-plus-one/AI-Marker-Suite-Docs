import {type ReactNode} from 'react';
import {Button} from './PageControls';
import './account-cost-summary.css';
export interface CostAccountSummary {id:string;name:string;description?:ReactNode;status?:ReactNode;metrics:{id:string;label:string;value:ReactNode;emphasis?:boolean}[];footnote?:ReactNode}
/** Parallel account summaries preserve cost, cash and prepaid values as distinct metrics. */
export function AccountCostSummary({label,accounts,onSelect,onDetails,value}:{label:string;accounts:CostAccountSummary[];onSelect?:(id:string)=>void;onDetails?:(id:string)=>void;value?:string}){
 return <section className="fp-cost-accounts" aria-label={label}>{accounts.map(account=><section key={account.id} className="fp-cost-account" data-selected={value===account.id||undefined} aria-label={account.name}><header><div><h3>{onSelect?<Button variant="ghost" aria-pressed={value===account.id} onClick={()=>onSelect(account.id)}>{account.name}</Button>:account.name}</h3>{account.description&&<p>{account.description}</p>}</div>{account.status}</header><dl>{account.metrics.map(metric=><div key={metric.id} data-emphasis={metric.emphasis||undefined}><dt>{metric.label}</dt><dd>{metric.value}</dd></div>)}</dl>{(account.footnote||onDetails)&&<footer><span>{account.footnote}</span>{onDetails&&<Button variant="ghost" aria-label={'查看'+account.name+'账单'} onClick={()=>onDetails(account.id)}>查看账单</Button>}</footer>}</section>)}</section>;
}
