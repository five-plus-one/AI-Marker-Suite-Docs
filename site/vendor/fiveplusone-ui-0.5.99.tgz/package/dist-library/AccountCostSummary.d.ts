import { type ReactNode } from 'react';
import './account-cost-summary.css';
export interface CostAccountSummary {
    id: string;
    name: string;
    description?: ReactNode;
    status?: ReactNode;
    metrics: {
        id: string;
        label: string;
        value: ReactNode;
        emphasis?: boolean;
    }[];
    footnote?: ReactNode;
}
/** Parallel account summaries preserve cost, cash and prepaid values as distinct metrics. */
export declare function AccountCostSummary({ label, accounts, onSelect, onDetails, value }: {
    label: string;
    accounts: CostAccountSummary[];
    onSelect?: (id: string) => void;
    onDetails?: (id: string) => void;
    value?: string;
}): import("react").JSX.Element;
