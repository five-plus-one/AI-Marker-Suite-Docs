import { type ReactNode } from 'react';
export interface IconImageProps {
    src: string;
    size?: number;
    fallback?: ReactNode;
    className?: string;
}
/** Decorative brand artwork. The adjacent model or vendor name supplies its label. */
export declare function IconImage({ src, size, fallback, className }: IconImageProps): import("react").JSX.Element;
