import { type ReactNode } from 'react';
import './dashboard-workspace.css';
export interface ComparisonMetric {
    id: string;
    label: string;
    value: ReactNode;
    detail?: ReactNode;
    emphasis?: boolean;
}
export interface ComparisonPeriod {
    id: string;
    label: string;
    detail?: ReactNode;
    metrics: ComparisonMetric[];
}
/** A compact comparison that keeps each period and its values together at any width. */
export declare function PeriodComparison({ label, periods, value, onChange, inlineDetails }: {
    label: string;
    periods: ComparisonPeriod[];
    value?: string;
    onChange?: (period: string) => void;
    inlineDetails?: boolean;
}): import("react").JSX.Element;
/** Host-owned filters, financial values and charts share one adaptive, dense overview. */
export declare function DashboardWorkspace({ navigation, filters, comparison, summary, primary, secondary, details, notes, children }: {
    navigation?: ReactNode;
    filters?: ReactNode;
    comparison?: ReactNode;
    summary?: ReactNode;
    primary?: ReactNode;
    secondary?: ReactNode;
    details?: ReactNode;
    notes?: ReactNode;
    children?: ReactNode;
}): import("react").JSX.Element;
