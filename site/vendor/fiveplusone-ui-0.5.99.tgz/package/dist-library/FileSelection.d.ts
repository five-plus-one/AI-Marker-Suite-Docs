import './file-selection.css';
export interface FileSelectionProps {
    label?: string;
    buttonLabel?: string;
    file?: File;
    onSelect: (file: File) => void;
    disabled?: boolean;
    busy?: boolean;
    hint?: string;
    error?: string;
    accept?: string;
}
export declare function FileSelection({ label, buttonLabel, file, onSelect, disabled, busy, hint, error, accept }: FileSelectionProps): import("react").JSX.Element;
