export type SvgMarkdownPart = {
    kind: "markdown";
    content: string;
} | {
    kind: "svg";
    content: string;
};
export declare function mapMarkdownOutsideCode(source: string, transform: (text: string) => string): string;
/** Separate complete diagrams while retaining ordinary fenced code verbatim. */
export declare function splitSvgMarkdown(source: string): SvgMarkdownPart[];
