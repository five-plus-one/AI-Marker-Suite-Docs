/** Accept conversational callout shorthand while retaining code and source content. */
export declare function normalizeAssistantMarkdown(source: string): string;
