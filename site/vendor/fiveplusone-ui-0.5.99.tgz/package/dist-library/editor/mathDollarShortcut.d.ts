import { Extension, type Editor } from "@tiptap/core";
type OpenMath = (latex: string, position: number) => void;
export declare function clearDollarShortcut(editor: Editor, position?: number): void;
export declare function promoteDollarShortcut(editor: Editor, position: number): boolean;
export declare function createMathDollarShortcut(onInline?: OpenMath, onBlock?: OpenMath): Extension<any, any>;
export {};
