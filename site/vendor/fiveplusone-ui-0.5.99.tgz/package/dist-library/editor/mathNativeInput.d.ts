import type { MathfieldElement } from "mathlive";
/** Native IMEs may send deletion input without a Backspace keydown. */
export declare function installMathNativeInput(field: MathfieldElement): () => void;
