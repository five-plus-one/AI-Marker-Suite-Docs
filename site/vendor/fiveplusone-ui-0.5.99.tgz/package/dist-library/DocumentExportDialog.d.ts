import type { ReactNode } from 'react';
import './document-export.css';
export interface DocumentExportDialogProps {
    title?: string;
    choices: {
        id: string;
        label: string;
        description?: string;
    }[];
    value: string;
    onChange: (value: string) => void;
    onClose: () => void;
    onExport: () => void;
    busy?: boolean;
    disabled?: boolean;
    summary?: string;
    error?: string;
    children?: ReactNode;
    navigation?: ReactNode;
    preview?: ReactNode;
    completed?: {
        description: string;
        onViewQueue: () => void;
    };
}
export declare function DocumentExportDialog({ title, choices, value, onChange, onClose, onExport, busy, disabled, summary, error, children, navigation, preview, completed }: DocumentExportDialogProps): import("react").JSX.Element;
