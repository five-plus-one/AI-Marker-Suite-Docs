export declare function Avatar({ name, src, size }: {
    name: string;
    src?: string;
    size?: number;
}): import("react").JSX.Element;
export declare function AvatarGroup({ names, members, size, label }: {
    names?: string[];
    members?: {
        id: string;
        name: string;
        src?: string;
    }[];
    size?: number;
    label?: string;
}): import("react").JSX.Element;
