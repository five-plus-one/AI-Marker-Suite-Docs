import { type ComponentType } from "react";
import type { CanvasBlock, RawSvgCanvasBlock } from "../engines/types";
import { type CanvasFrameProps } from "../CanvasFrame";
export interface RawSvgRendererProps {
    block: RawSvgCanvasBlock;
    revisionBlock?: CanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
    frameComponent?: ComponentType<CanvasFrameProps>;
}
export declare function RawSvgRenderer({ block, revisionBlock, revisionTopic, onRevisionSubmit, onRevisionAccepted, frameComponent: Frame }: RawSvgRendererProps): import("react").JSX.Element;
