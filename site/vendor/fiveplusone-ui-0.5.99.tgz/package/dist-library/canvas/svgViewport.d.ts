export declare function prepareSvgViewport(source: string, width?: number, height?: number): {
    markup: string;
    width: number;
    height: number;
};
/** Trim pronounced empty margins after fonts settle, retaining room for strokes and markers. */
export declare function fitSvgWhitespace(svg: SVGSVGElement): {
    width: number;
    height: number;
    viewBox: string;
} | undefined;
