export interface CanvasPoint {
    x: number;
    y: number;
}
export interface CanvasView {
    x: number;
    y: number;
    zoom: number;
}
export declare const initialCanvasView: CanvasView;
export declare function zoomCanvasAt(view: CanvasView, point: CanvasPoint, zoom: number): CanvasView;
export declare function moveCanvasGesture(view: CanvasView, from: CanvasPoint[], to: CanvasPoint[], zoomable?: boolean, pannable?: boolean): CanvasView;
