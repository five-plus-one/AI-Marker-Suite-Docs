import { type PointerEvent as ReactPointerEvent } from "react";
import { type CanvasView } from "./canvasViewport";
/** Inline scrolling remains native until two fingers manipulate the diagram.
 * Keep that gesture on the diagram until every finger has lifted. */
export declare function useCanvasGesture<T extends HTMLElement | SVGSVGElement>({ fullscreen, pannable, zoomable, resetKey, origin }?: {
    fullscreen?: boolean;
    pannable?: boolean;
    zoomable?: boolean;
    resetKey?: unknown;
    origin?: "top-left" | "center";
}): {
    ref: import("react").Dispatch<import("react").SetStateAction<T | null>>;
    element: T | null;
    view: CanvasView;
    reset: () => void;
    zoomBy: (factor: number) => void;
    bind: {
        onPointerDown: (event: ReactPointerEvent<T>) => void;
        onPointerMove: (event: ReactPointerEvent<T>) => void;
        onPointerUp: (event: ReactPointerEvent<T>) => void;
        onPointerCancel: (event: ReactPointerEvent<T>) => void;
        onLostPointerCapture: (event: ReactPointerEvent<T>) => void;
        style: {
            touchAction: string;
        };
    };
};
