export interface MediaLightboxProps {
    src: string | null;
    alt?: string;
    onClose: () => void;
}
export declare function MediaLightbox({ src, alt, onClose }: MediaLightboxProps): import("react").ReactPortal | null;
