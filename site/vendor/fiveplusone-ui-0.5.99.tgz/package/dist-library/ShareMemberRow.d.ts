import type { ReactNode } from "react";
export interface ShareMemberRowProps {
    name: string;
    detail?: string;
    avatar?: ReactNode;
    role: ReactNode;
    roleLabel?: string;
    actions?: ReactNode;
}
export declare function ShareMemberRow({ name, detail, avatar, role, roleLabel, actions }: ShareMemberRowProps): import("react").JSX.Element;
