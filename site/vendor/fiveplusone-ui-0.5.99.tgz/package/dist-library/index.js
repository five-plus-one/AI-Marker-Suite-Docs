import { jsx as e, jsxs as o, Fragment as ee } from "react/jsx-runtime";
import mt, { useRef as R, useEffect as Y, useId as ve, useState as k, useLayoutEffect as xe, useCallback as De, Fragment as Br, lazy as Ul, Suspense as Wl, createContext as yn, useContext as Wt, Component as _l, useMemo as Ke, Children as Vl, isValidElement as sa, cloneElement as ca, forwardRef as Gl, useImperativeHandle as Yl } from "react";
import { createPortal as Oe } from "react-dom";
import { Minus as jt, Plus as qt, Minimize2 as jr, Maximize2 as qr, Download as _t, RotateCcw as tt, ChevronDown as St, Check as Ie, Play as cn, Pause as Vn, VolumeX as da, Volume2 as ua, PictureInPicture as Xl, Maximize as Gn, ZoomIn as Kr, ZoomOut as Hr, ExternalLink as Vt, Pencil as Yn, Code2 as Ur, Trash2 as Gt, IndentIncrease as Ql, IndentDecrease as Jl, CornerDownLeft as pa, ArrowDown as ha, BookOpen as et, ChevronRight as Ae, ImageOff as Zl, Undo2 as eo, Redo2 as to, Paintbrush as no, Bold as ro, Italic as io, Baseline as ao, Highlighter as lo, List as dn, Link2 as ft, Paperclip as Sr, Sigma as Pt, Table2 as dr, Strikethrough as oo, Underline as so, Eraser as co, Quote as fa, Braces as uo, Layers3 as wi, Video as ki, Workflow as po, FlaskConical as ho, Save as ma, MoreHorizontal as Kt, ListOrdered as fo, Search as Ue, Star as Ni, ChevronLeft as Wr, Keyboard as ba, Settings2 as mo, Grid2X2 as bo, FileText as nt, X as ke, SlidersHorizontal as ga, Clock as Xn, Minimize as go, Home as yo, RefreshCw as Qn, Monitor as ya, Smartphone as vo, Settings as wo, Menu as un, Copy as vn, CalendarDays as va, Sun as ko, Moon as No, Columns2 as xo, Network as xi, ArrowUpRight as _r, Eye as wa, Code as Co, ImagePlus as So, Upload as Mo, Images as Eo, FolderOpen as ka, Folder as Ht, ChevronUp as $o, Square as pn, LoaderCircle as Ut, ArrowUp as Vr, UserPlus as zo, UserRound as Ao, Users as In, RotateCw as Na, AlertCircle as Gr, Loader as Lo, Circle as xa, AlertTriangle as Io, Cloud as Do, CloudOff as To, Brain as Po, Wrench as Fo, Cpu as Oo, Coins as Ro, Lightbulb as Ci, ShieldAlert as Bo, Sparkles as Dn, Globe as jo, MessageSquare as qo, CircleDashed as Ko, CheckCircle2 as ct, ImageIcon as Ho, FolderPlus as Uo, LayoutGrid as Wo, FolderInput as _o, Share2 as Vo, FileCheck2 as Go, ArrowRight as Jn, ShieldCheck as Yr, CircleAlert as Xr, ArrowDownToLine as Tn, PackageOpen as Yo, FileOutput as Xo, ArrowUpFromLine as Qo, ArrowLeft as Qr, Mic as Jo, Activity as Zo, File as es, BookPlus as ts, History as ns, Info as rs, UsersRound as is, CircleHelp as as } from "lucide-react";
import { useReducedMotion as Zn, motion as er } from "framer-motion";
import { Extension as tr, InputRule as ls, Node as nr, mergeAttributes as Jr } from "@tiptap/core";
import { Plugin as Yt, TextSelection as rt, NodeSelection as Rt, PluginKey as Zr, Selection as Pn } from "@tiptap/pm/state";
import Ca from "react-markdown";
import os from "remark-gfm";
import Sa from "remark-math";
import ss from "remark-directive";
import Ma from "rehype-katex";
import cs from "rehype-raw";
import ds, { defaultSchema as At } from "rehype-sanitize";
import { visit as hn } from "unist-util-visit";
import us from "dompurify";
import { ReactNodeViewRenderer as nn, NodeViewWrapper as Ft, NodeViewContent as Si, useEditor as ps, EditorContent as Ea } from "@tiptap/react";
import { CodeBlockLowlight as $a } from "@tiptap/extension-code-block-lowlight";
import { createLowlight as hs, common as fs } from "lowlight";
import { closeHistory as ei } from "@tiptap/pm/history";
import { yUndoPluginKey as ti } from "@tiptap/y-tiptap";
import "katex/contrib/mhchem";
import { DecorationSet as Mr, Decoration as za } from "@tiptap/pm/view";
import { DOMSerializer as ms } from "@tiptap/pm/model";
import bs from "@tiptap/extension-collaboration";
import gs from "@tiptap/extension-collaboration-caret";
import ys from "@tiptap/extension-placeholder";
import { pinyin as vs } from "pinyin-pro";
import ws from "@tiptap/starter-kit";
import ks from "@tiptap/extension-link";
import { Mathematics as Ns, InlineMath as xs, BlockMath as Cs } from "@tiptap/extension-mathematics";
import { TableKit as Ss } from "@tiptap/extension-table";
import { Markdown as Ms, MarkdownManager as Aa } from "@tiptap/markdown";
import Es from "@tiptap/extension-image";
import $s from "@tiptap/extension-unique-id";
import { TextStyle as zs } from "@tiptap/extension-text-style";
import { Color as As } from "@tiptap/extension-color";
import Ls from "@tiptap/extension-highlight";
import La from "katex";
import { PanelGroup as Is, Panel as Ds, PanelResizeHandle as Ts } from "react-resizable-panels";
import { HocuspocusProvider as Ps } from "@hocuspocus/provider";
import * as Fs from "yjs";
import { useVirtualizer as Ia } from "@tanstack/react-virtual";
function je({ isOpen: t, children: n, duration: r = 240, easing: i = "cubic-bezier(0.2, 0, 0, 1)" }) {
  return /* @__PURE__ */ e("div", { className: "fp-collapse-transition", "data-open": t || void 0, "aria-hidden": !t, inert: !t, style: { display: "grid", gridTemplateRows: t ? "1fr" : "0fr", transition: `grid-template-rows ${r}ms ${i}, opacity ${r}ms ${i}`, opacity: t ? 1 : 0 }, children: /* @__PURE__ */ e("div", { style: { minHeight: 0, overflow: "hidden" }, children: n }) });
}
function Da(t, { active: n, surface: r = !1, inset: i = 0, indicator: a }) {
  const l = a || document.createElement("span");
  l.classList.add("fp-selection-indicator"), l.setAttribute("aria-hidden", "true"), a || t.append(l), t.dataset.fpSelection = r ? "surface" : "underline";
  const s = window.matchMedia?.("(prefers-reduced-motion: reduce)");
  let c, u = !1, d = 0, p = !1, h;
  const f = (w = !0) => {
    const y = t.querySelector(n), N = t.getBoundingClientRect();
    if (!y || !N.width || !N.height) {
      c?.cancel(), l.style.opacity = "0", u = !1, h = void 0;
      return;
    }
    const x = y.getBoundingClientRect(), C = { left: x.left - N.left + t.scrollLeft + i, top: r ? x.top - N.top + t.scrollTop : t.clientHeight - 3, width: Math.max(0, x.width - i * 2), height: r ? x.height : 3 };
    if (h && Object.entries(C).every(([j, M]) => Math.abs(M - h[j]) < 0.5)) return;
    const z = l.getBoundingClientRect(), L = { left: z.left - N.left + t.scrollLeft, top: z.top - N.top + t.scrollTop, width: z.width, height: z.height };
    if (c?.cancel(), h = C, Object.assign(l.style, { left: C.left + "px", top: C.top + "px", width: C.width + "px", height: C.height + "px", opacity: "1" }), w && !s?.matches && typeof l.animate == "function") {
      const j = (M) => Object.fromEntries(Object.entries(M).map(([A, O]) => [A, O + "px"]));
      if (u) {
        const M = r ? C.top - L.top : C.left - L.left, A = r ? { ...C, top: L.top + M * 0.58, height: C.height + Math.min(Math.abs(M) * 0.18, 20) } : { ...C, left: L.left + M * 0.58, width: Math.max(L.width, C.width) + Math.min(Math.abs(M) * 0.2, 28) };
        c = l.animate([{ ...j(L), offset: 0 }, { ...j(A), offset: 0.48 }, { ...j(C), offset: 1 }], { duration: 400, easing: "cubic-bezier(.2,.7,.2,1)" });
      } else c = l.animate([{ opacity: 0, transform: r ? "scale(.98)" : "scaleX(.55)" }, { opacity: 1, transform: "scale(1)" }], { duration: 280, easing: "cubic-bezier(.16,1,.3,1)" });
    }
    u = !0;
  }, m = (w = !0) => {
    p ||= w, d || (d = requestAnimationFrame(() => {
      d = 0;
      const y = p;
      p = !1, f(y);
    }));
  }, b = new MutationObserver(() => m());
  b.observe(t, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["class", "aria-selected", "aria-current"] });
  const g = typeof ResizeObserver > "u" ? void 0 : new ResizeObserver(() => m(!1));
  g?.observe(t), t.querySelectorAll("a,button").forEach((w) => g?.observe(w));
  const v = () => {
    c?.cancel(), f(!1);
  };
  return s?.addEventListener("change", v), f(!1), { update: f, destroy() {
    cancelAnimationFrame(d), c?.cancel(), b.disconnect(), g?.disconnect(), s?.removeEventListener("change", v), delete t.dataset.fpSelection, a || l.remove();
  } };
}
const Ve = (...t) => t.filter(Boolean).join(" ");
function Ta(t) {
  return mt.Children.toArray(t).map((n) => typeof n == "string" || typeof n == "number" ? String(n) : mt.isValidElement(n) && n.type !== "svg" ? Ta(n.props.children) : "").join("").trim();
}
function te({
  variant: t = "primary",
  size: n = "md",
  loading: r,
  multiline: i = !1,
  children: a,
  className: l,
  title: s,
  type: c = "button",
  ...u
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      ...u,
      "data-multiline": i || void 0,
      "data-fp-tooltip": s || u["data-fp-tooltip"] || u["aria-label"] || Ta(a) || void 0,
      type: c,
      disabled: u.disabled || r,
      className: Ve("fp-button", `fp-${t}`, `fp-${n}`, l),
      "aria-busy": r,
      children: [
        r && /* @__PURE__ */ e(ri, { size: 16 }),
        a
      ]
    }
  );
}
function ni({
  children: t,
  tone: n = "neutral"
}) {
  return /* @__PURE__ */ e("span", { className: `fp-badge fp-tone-${n}`, children: t });
}
function Bt({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: Ve("fp-card", n), children: t });
}
function ri({ size: t = 22 }) {
  return /* @__PURE__ */ e(
    "span",
    {
      role: "status",
      "aria-label": "正在处理",
      className: "fp-spinner",
      style: { width: t, height: t }
    }
  );
}
function ii({
  items: t,
  value: n,
  onChange: r,
  id: i,
  label: a
}) {
  let l = R(null);
  const s = t.map((c) => c.label).join("\0");
  return Y(() => {
    const c = l.current;
    if (!c) return;
    const u = c.querySelector(".fp-tab-indicator");
    if (!u) return;
    const d = Da(c, { active: 'button[aria-selected="true"]', indicator: u });
    return () => d.destroy();
  }, [s]), /* @__PURE__ */ o(
    "div",
    {
      ref: l,
      className: "fp-tabs",
      role: "tablist",
      "aria-label": a,
      onKeyDown: (c) => {
        if (!t.length || c.altKey || c.ctrlKey || c.metaKey) return;
        let u = t.findIndex((p) => p.value === n), d = c.key === "ArrowRight" ? (u + 1) % t.length : c.key === "ArrowLeft" ? (u - 1 + t.length) % t.length : c.key === "Home" ? 0 : c.key === "End" ? t.length - 1 : -1;
        d >= 0 && (c.preventDefault(), r(t[d].value), l.current?.children[d]?.focus());
      },
      children: [
        t.map((c) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            role: "tab",
            id: i ? `${i}-tab-${c.value}` : void 0,
            "aria-controls": i ? `${i}-panel-${c.value}` : void 0,
            "aria-selected": c.value === n,
            tabIndex: c.value === n ? 0 : -1,
            onClick: () => r(c.value),
            children: c.label
          },
          c.value
        )),
        /* @__PURE__ */ e(
          "span",
          {
            className: "fp-tab-indicator",
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function qh({
  items: t
}) {
  const [n, r] = mt.useState(/* @__PURE__ */ new Set()), i = mt.useId();
  return /* @__PURE__ */ e("div", { className: "fp-accordion", children: t.map((a, l) => /* @__PURE__ */ o("div", { className: "fp-accordion-item", children: [
    /* @__PURE__ */ o(
      "button",
      {
        className: "fp-accordion-trigger",
        type: "button",
        "aria-expanded": n.has(l),
        "aria-controls": `${i}-${l}`,
        onClick: () => r((s) => {
          const c = new Set(s);
          return c.has(l) ? c.delete(l) : c.add(l), c;
        }),
        children: [
          a.title,
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "＋" })
        ]
      }
    ),
    /* @__PURE__ */ e(je, { isOpen: n.has(l), children: /* @__PURE__ */ e("div", { id: `${i}-${l}`, className: "fp-accordion-content", children: a.content }) })
  ] }, a.title)) });
}
function Ye({
  open: t,
  onClose: n,
  title: r,
  children: i,
  footer: a,
  drawer: l = !1,
  className: s,
  dismissible: c = !0
}) {
  let u = R(null), d = ve();
  return Y(() => {
    let p = u.current;
    t && !p?.open && p?.showModal(), !t && p?.open && p.close();
  }, [t]), typeof window > "u" ? null : Oe(
    /* @__PURE__ */ o(
      "dialog",
      {
        ref: u,
        className: Ve("fp-dialog", l && "fp-drawer", s),
        "aria-labelledby": d,
        onCancel: (p) => {
          p.preventDefault(), c && n();
        },
        onClick: (p) => {
          if (p.target === p.currentTarget) {
            let h = p.currentTarget.getBoundingClientRect();
            (p.clientX < h.left || p.clientX > h.right || p.clientY < h.top || p.clientY > h.bottom) && c && n();
          }
        },
        children: [
          /* @__PURE__ */ o("header", { children: [
            /* @__PURE__ */ e("h2", { id: d, children: r }),
            c && /* @__PURE__ */ e(te, { variant: "ghost", className: "fp-icon-button", "aria-label": "关闭", title: "关闭", onClick: n, children: "×" })
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-dialog-body", children: i }),
          a && /* @__PURE__ */ e("footer", { children: a })
        ]
      }
    ),
    document.body
  );
}
function Kh(t) {
  return /* @__PURE__ */ e(Ye, { ...t, drawer: !0 });
}
function Hh(t, n) {
  const r = Math.max(0, Math.min(255, parseInt(n, 16) || 0));
  return `color-mix(in srgb, ${t} ${Math.round(r / 255 * 1e4) / 100}%, transparent)`;
}
function Os({
  value: t,
  max: n,
  viewport: r,
  controls: i,
  onChange: a
}) {
  const l = R(null), s = R(
    null
  ), [c, u] = k(!1), d = Math.max(0, n), p = d <= 0 ? 1 : Math.max(0.08, Math.min(1, r / Math.max(1, r + d))), f = (d > 0 ? Math.min(1, Math.max(0, t / d)) : 0) * (1 - p), m = (g) => Math.max(0, Math.min(d, g)), b = (g) => a(m(g));
  return /* @__PURE__ */ o(
    "div",
    {
      ref: l,
      className: "horizontal-scrollbar",
      role: "scrollbar",
      "aria-label": "横向滚动预览",
      "aria-orientation": "horizontal",
      "aria-controls": i,
      "aria-valuemin": 0,
      "aria-valuemax": Math.round(d),
      "aria-valuenow": Math.round(t),
      "data-dragging": c || void 0,
      tabIndex: 0,
      onPointerDown: (g) => {
        if (g.button !== 0 || !l.current) return;
        const v = l.current.getBoundingClientRect(), w = v.width * (1 - p), y = g.target === g.currentTarget ? (g.clientX - v.left - v.width * p / 2) / Math.max(1, w) * d : t;
        b(y), s.current = {
          x: g.clientX,
          value: m(y),
          travel: w
        }, u(!0), g.currentTarget.setPointerCapture(g.pointerId);
      },
      onPointerMove: (g) => {
        s.current && b(
          s.current.value + (g.clientX - s.current.x) / Math.max(1, s.current.travel) * d
        );
      },
      onPointerUp: (g) => {
        s.current = null, u(!1), g.currentTarget.hasPointerCapture(g.pointerId) && g.currentTarget.releasePointerCapture(g.pointerId);
      },
      onPointerCancel: () => {
        s.current = null, u(!1);
      },
      onKeyDown: (g) => {
        const v = g.key === "ArrowLeft" ? -48 : g.key === "ArrowRight" ? 48 : g.key === "PageUp" ? -r : g.key === "PageDown" ? r : 0;
        (v || g.key === "Home" || g.key === "End") && (g.preventDefault(), b(
          g.key === "Home" ? 0 : g.key === "End" ? d : t + v
        ));
      },
      children: [
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-fill",
            style: { width: `${(f + p) * 100}%` },
            "aria-hidden": "true"
          }
        ),
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-thumb",
            style: { width: `${p * 100}%`, left: `${f * 100}%` },
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function ge({ children: t, initialHeight: n, className: r }) {
  const i = R(null), [a, l] = k(n), s = Zn();
  return xe(() => {
    const c = i.current;
    if (!c) return;
    const u = () => l(c.getBoundingClientRect().height);
    if (u(), typeof ResizeObserver > "u") return;
    const d = new ResizeObserver(u);
    return d.observe(c), () => d.disconnect();
  }, []), /* @__PURE__ */ e(
    er.div,
    {
      className: r,
      "data-animated-size": "",
      initial: n === void 0 ? !1 : { height: n, opacity: 0 },
      animate: { height: a ?? "auto", opacity: 1 },
      exit: { height: n ?? 0, opacity: 0 },
      transition: { duration: s ? 0 : 0.24, ease: [0.2, 0, 0, 1] },
      style: { overflow: "clip", minWidth: 0 },
      children: /* @__PURE__ */ e("div", { ref: i, style: { display: "flow-root", minWidth: 0 }, children: t })
    }
  );
}
function Rs({
  page: t,
  zoom: n,
  aspect: r,
  onAspect: i,
  expanded: a
}) {
  const l = R(null), [s, c] = k(t.n <= 2), [u, d] = k(!1), [p, h] = k(0), [f, m] = k(!1);
  Y(() => {
    if (s || !l.current) return;
    const g = a ? l.current.closest(".resource-detail") : l.current.closest(".pdf-preview-pages"), v = new IntersectionObserver(
      (w) => {
        w.some((y) => y.isIntersecting) && (c(!0), v.disconnect());
      },
      { root: g, rootMargin: "700px 0px" }
    );
    return v.observe(l.current), () => v.disconnect();
  }, [s, a]), Y(() => {
    d(!1), h(0);
  }, [t.url]);
  const b = `${Math.round(n * 100)}%`;
  return /* @__PURE__ */ e(
    "div",
    {
      ref: l,
      "data-pdf-sheet": t.n,
      style: {
        width: b,
        aspectRatio: f ? void 0 : String(r),
        margin: n <= 1 ? "0 auto 12px" : "0 0 12px",
        background: "#fff",
        boxShadow: "0 1px 4px rgba(0,0,0,.12)"
      },
      children: s && (u ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
        "第 ",
        t.n,
        " 页加载失败。",
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              d(!1), h((g) => g + 1);
            },
            children: "重试"
          }
        )
      ] }) : /* @__PURE__ */ e(
        "img",
        {
          src: p ? `${t.url}${t.url.includes("?") ? "&" : "?"}retry=${p}` : t.url,
          alt: `第 ${t.n} 页`,
          draggable: !1,
          onLoad: (g) => {
            const v = g.currentTarget;
            t.n === 1 && v.naturalWidth > 0 && v.naturalHeight > 0 && i(v.naturalWidth / v.naturalHeight), m(!0);
          },
          onError: () => {
            m(!1), d(!0);
          },
          style: { display: "block", width: "100%", height: "auto" }
        }
      ))
    }
  );
}
function Bs({
  url: t,
  name: n,
  downloadUrl: r
}) {
  const i = R(null), a = R(null), l = ve(), s = R(null), [c, u] = k(!1), [d, p] = k(null), [h, f] = k("loading"), [m, b] = k(1), [g, v] = k(""), [w, y] = k(!1), [N, x] = k(1), [C, z] = k(0.707), [L, j] = k(0), [M, A] = k({ left: 0, max: 0 });
  Y(() => {
    b(1), v(""), z(0.707), a.current && (a.current.scrollTop = 0);
  }, [t]), Y(() => {
    if (!i.current) return;
    const T = new IntersectionObserver(
      (E) => {
        E.some((S) => S.isIntersecting) && (u(!0), T.disconnect());
      },
      { rootMargin: "200px" }
    );
    return T.observe(i.current), () => T.disconnect();
  }, []), Y(() => {
    if (!c) return;
    const T = new AbortController();
    let E, S = 0, P = "";
    p(null), f("loading");
    const _ = async () => {
      try {
        const q = new URL(t, window.location.href);
        q.searchParams.set("view", "pages"), q.searchParams.delete("download"), P && q.searchParams.set("hash", P);
        const H = await fetch(q.href, {
          credentials: "include",
          signal: T.signal,
          cache: "no-store"
        });
        if (!H.ok) throw new Error("preview unavailable");
        const I = await H.json();
        if (T.signal.aborted) return;
        typeof I.contentHash == "string" && (P = I.contentHash), I.status === "ready" && I.manifest?.pages?.length ? (p({
          pages: I.manifest.pages,
          pageCount: I.manifest.pageCount || I.manifest.pages.length
        }), f("ready"), S = 0, E = setTimeout(() => {
          _();
        }, 1800 * 1e3)) : I.status === "failed" ? f("error") : (S++, f("rendering"), E = setTimeout(
          () => {
            _();
          },
          S < 15 ? 2e3 : S < 60 ? 5e3 : 1e4
        ));
      } catch {
        T.signal.aborted || f("error");
      }
    };
    return _(), () => {
      T.abort(), clearTimeout(E);
    };
  }, [t, c, L]);
  const O = De(
    (T) => {
      const E = Math.max(1, Math.min(d?.pageCount || 1, T)), S = a.current, P = S?.querySelector(
        `[data-pdf-sheet="${E}"]`
      );
      S && P && (w ? P.scrollIntoView({ block: "start", behavior: "smooth" }) : S.scrollTo({
        top: S.scrollTop + P.getBoundingClientRect().top - S.getBoundingClientRect().top,
        behavior: "smooth"
      })), b(E);
    },
    [d?.pageCount, w]
  );
  Y(() => {
    const T = a.current;
    T && (T.scrollLeft = Math.max(
      0,
      (T.scrollWidth - T.clientWidth) / 2
    ));
  }, [N, h]), Y(() => {
    const T = a.current;
    if (!T) return;
    const E = () => A({
      left: T.scrollLeft,
      max: Math.max(0, T.scrollWidth - T.clientWidth)
    }), S = typeof ResizeObserver > "u" ? null : new ResizeObserver(E);
    S?.observe(T);
    const P = requestAnimationFrame(E);
    return () => {
      cancelAnimationFrame(P), S?.disconnect();
    };
  }, [N, h, d]);
  const U = (T) => {
    a.current && (a.current.scrollLeft = T), A((E) => ({ ...E, left: T }));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: i,
      className: `pdf-preview pdf-preview-scroll${w ? " pdf-preview-expanded" : " pdf-preview-windowed"}`,
      "aria-label": `${n} 预览`,
      children: [
        /* @__PURE__ */ o("div", { className: "pdf-preview-controls", children: [
          /* @__PURE__ */ o("div", { className: "pdf-page-navigation", children: [
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(
                "input",
                {
                  type: "number",
                  min: 1,
                  max: d?.pageCount || 1,
                  value: g || m,
                  onChange: (T) => v(T.target.value),
                  onKeyDown: (T) => {
                    T.key === "Enter" && (O(Number(g || m)), v(""));
                  },
                  "aria-label": "跳转到页码"
                }
              ),
              " ",
              "/ ",
              d?.pageCount || "…",
              " 页"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h !== "ready",
                onClick: () => {
                  O(Number(g || m)), v("");
                },
                children: "跳转"
              }
            )
          ] }),
          /* @__PURE__ */ o("div", { className: "pdf-zoom-controls", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: N <= 0.5 || h !== "ready",
                onClick: () => x((T) => Math.max(0.5, T - 0.25)),
                "aria-label": "缩小",
                children: /* @__PURE__ */ e(jt, {})
              }
            ),
            /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                className: "pdf-zoom-value",
                title: "恢复适合宽度",
                onClick: () => x(1),
                children: [
                  Math.round(N * 100),
                  "%"
                ]
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: N >= 3 || h !== "ready",
                onClick: () => x((T) => Math.min(3, T + 0.25)),
                "aria-label": "放大",
                children: /* @__PURE__ */ e(qt, {})
              }
            )
          ] }),
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "pdf-expand-toggle",
              "aria-label": w ? "固定窗口" : "完整展开",
              title: w ? "固定窗口" : "完整展开",
              "aria-pressed": w,
              "aria-controls": l,
              onClick: () => y((T) => !T),
              children: [
                w ? /* @__PURE__ */ e(jr, { "aria-hidden": "true" }) : /* @__PURE__ */ e(qr, { "aria-hidden": "true" }),
                /* @__PURE__ */ e("span", { children: w ? "固定窗口" : "完整展开" })
              ]
            }
          ),
          /* @__PURE__ */ e(
            "a",
            {
              className: "pdf-download",
              "aria-label": "下载原文件",
              title: "下载原文件",
              href: r || `${t}${t.includes("?") ? "&" : "?"}download=1`,
              download: !0,
              children: /* @__PURE__ */ e(_t, {})
            }
          ),
          M.max > 1 && /* @__PURE__ */ e("div", { className: "pdf-preview-horizontal", children: /* @__PURE__ */ e(
            Os,
            {
              value: M.left,
              max: M.max,
              viewport: a.current?.clientWidth || 1,
              controls: l,
              onChange: U
            }
          ) })
        ] }),
        /* @__PURE__ */ e(ge, { children: h === "error" ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
          "暂时无法预览此文件。",
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => j((T) => T + 1),
              children: [
                /* @__PURE__ */ e(tt, {}),
                "重试"
              ]
            }
          )
        ] }) : h !== "ready" ? /* @__PURE__ */ e("div", { role: "status", className: "pdf-preview-message", children: "正在准备预览…" }) : /* @__PURE__ */ e(
          "div",
          {
            ref: a,
            id: l,
            className: "pdf-preview-pages",
            style: { cursor: N > 1 ? "grab" : void 0 },
            onScroll: (T) => {
              const E = T.currentTarget.scrollLeft;
              A(
                (S) => S.left === E ? S : { ...S, left: E }
              );
            },
            onPointerDown: (T) => {
              N <= 1 || T.pointerType !== "mouse" || T.button !== 0 || (s.current = {
                x: T.clientX,
                left: T.currentTarget.scrollLeft
              }, T.currentTarget.setPointerCapture(T.pointerId), T.currentTarget.style.cursor = "grabbing");
            },
            onPointerMove: (T) => {
              s.current && (T.currentTarget.scrollLeft = s.current.left - (T.clientX - s.current.x));
            },
            onPointerUp: (T) => {
              s.current = null, T.currentTarget.style.cursor = "grab";
            },
            onPointerCancel: () => {
              s.current = null;
            },
            children: d?.pages.map((T) => /* @__PURE__ */ e(
              Rs,
              {
                page: T,
                zoom: N,
                aspect: C,
                onAspect: z,
                expanded: w
              },
              T.n
            ))
          }
        ) })
      ]
    }
  );
}
function js({ progress: t, children: n, className: r = "", ...i }) {
  return /* @__PURE__ */ o("div", { ...i, "data-theme": "dark", className: `fp-media-controls ${r}`, children: [
    t && /* @__PURE__ */ e("div", { className: "fp-media-progress", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-media-toolbar", children: n })
  ] });
}
function Er({ className: t = "", style: n, min: r = 0, max: i = 100, value: a, ...l }) {
  const s = Math.max(0, Math.min(100, (Number(a ?? r) - Number(r)) / (Number(i) - Number(r) || 1) * 100));
  return /* @__PURE__ */ e("input", { ...l, type: "range", min: r, max: i, value: a, className: `fp-media-slider ${t}`, style: { ...n, "--fp-media-fill": `${s}%` } });
}
function Xt(t, n, r) {
  const [i, a] = k({});
  return xe(() => {
    if (!n || !t.current) return;
    const l = () => {
      if (!t.current) return;
      const u = getComputedStyle(t.current), d = {
        color: u.color,
        colorScheme: u.colorScheme,
        fontFamily: u.fontFamily
      };
      for (let p = 0; p < u.length; p++) {
        const h = u.item(p);
        h.startsWith("--fp-") && (d[h] = u.getPropertyValue(h));
      }
      a((p) => {
        const h = d;
        return JSON.stringify(p) === JSON.stringify(h) ? p : h;
      });
    };
    l();
    const s = new MutationObserver(l);
    for (let u = t.current; u; u = u.parentElement)
      s.observe(u, { attributes: !0, attributeFilter: ["class", "style", "data-theme", "data-product"] });
    const c = window.matchMedia?.("(prefers-color-scheme: dark)");
    return c?.addEventListener("change", l), () => {
      s.disconnect(), c?.removeEventListener("change", l);
    };
  }, [t, n, r]), i;
}
function Xe({
  label: t,
  triggerRole: n,
  triggerId: r,
  children: i,
  menu: a = !1,
  icon: l,
  trigger: s,
  disabled: c,
  className: u = "",
  role: d,
  onOpenChange: p,
  density: h = "comfortable"
}) {
  const [f, m] = k(!1), [b, g] = k(!1), v = () => {
    g(!0), m(!1);
  };
  Y(() => {
    if (!b) return;
    const U = setTimeout(() => g(!1), 120);
    return () => clearTimeout(U);
  }, [b]);
  const w = R(null), y = R(null), N = Xt(w, f), x = ve(), C = R(p);
  C.current = p, Y(() => {
    C.current?.(f);
  }, [f]);
  const z = d || (a ? "menu" : "dialog"), [L, j] = k({ left: 8, top: 8, maxHeight: 400 }), M = () => {
    v(), w.current?.focus();
  }, A = z === "listbox" ? '[role="option"]:not(:disabled)' : '[role="menuitem"]:not(:disabled)', O = (U = !1) => requestAnimationFrame(() => {
    const T = y.current?.querySelectorAll(A), E = y.current?.querySelector(
      '[aria-selected="true"]:not(:disabled)'
    );
    (U ? T?.[T.length - 1] : E || T?.[0])?.focus();
  });
  return xe(() => {
    if (!f) return;
    const U = () => {
      const E = w.current?.getBoundingClientRect(), S = y.current?.getBoundingClientRect();
      if (!E || !S) return;
      const P = window.innerHeight - E.bottom - 16, _ = E.top - 16, q = P < Math.min(S.height, 240) && _ > P, H = Math.max(80, q ? _ : P), I = {
        left: Math.max(
          8,
          Math.min(E.left, window.innerWidth - S.width - 8)
        ),
        top: q ? Math.max(8, E.top - Math.min(S.height, H) - 8) : E.bottom + 8,
        maxHeight: H
      };
      j(
        ($) => $.left === I.left && $.top === I.top && $.maxHeight === I.maxHeight ? $ : I
      );
    };
    U(), window.addEventListener("resize", U), window.addEventListener("scroll", U, !0);
    const T = typeof ResizeObserver > "u" ? null : new ResizeObserver(U);
    return y.current && T?.observe(y.current), () => {
      T?.disconnect(), window.removeEventListener("resize", U), window.removeEventListener("scroll", U, !0);
    };
  }, [f]), Y(() => {
    c && f && v();
  }, [c]), Y(() => {
    if (!f) return;
    const U = (E) => {
      const S = E.target;
      !w.current?.contains(S) && !y.current?.contains(S) && v();
    }, T = (E) => {
      E.key === "Escape" && (!E.target.closest?.("[data-fp-overlay]") || E.target.closest?.("[data-fp-overlay]") === y.current) && (E.preventDefault(), E.stopPropagation(), M());
    };
    return document.addEventListener("pointerdown", U, !0), document.addEventListener("focusin", U, !0), document.addEventListener("keydown", T, !0), z === "listbox" && y.current?.querySelector(".fp-select-search input") ? requestAnimationFrame(
      () => y.current?.querySelector(".fp-select-search input")?.focus({ preventScroll: !0 })
    ) : z !== "dialog" ? O() : requestAnimationFrame(
      () => (y.current?.querySelector(
        '[aria-pressed="true"]:not(:disabled)'
      ) || y.current?.querySelector(
        'input:not(:disabled), button:not(:disabled), [tabindex="0"]'
      ))?.focus({ preventScroll: !0 })
    ), () => {
      document.removeEventListener("pointerdown", U, !0), document.removeEventListener("focusin", U, !0), document.removeEventListener("keydown", T, !0);
    };
  }, [f]), /* @__PURE__ */ o("span", { className: "fp-dropdown", children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        ref: w,
        role: n,
        id: r,
        disabled: c,
        "aria-label": t,
        "aria-expanded": f,
        "aria-controls": f ? x : void 0,
        "aria-haspopup": z,
        className: `fp-popup-trigger${l ? " fp-popup-icon" : ""}`,
        onClick: () => {
          f ? v() : (g(!1), m(!0));
        },
        onKeyDown: (U) => {
          z !== "dialog" && (U.key === "ArrowDown" || U.key === "ArrowUp") && (U.preventDefault(), m(!0), O(U.key === "ArrowUp"));
        },
        children: s || l || /* @__PURE__ */ o(ee, { children: [
          /* @__PURE__ */ e("span", { children: t }),
          /* @__PURE__ */ e(St, { size: 15, "aria-hidden": "true" })
        ] })
      }
    ),
    (f || b) && Oe(
      /* @__PURE__ */ e(
        "div",
        {
          ref: y,
          "data-fp-overlay": "",
          id: x,
          role: z,
          "aria-label": t,
          "aria-hidden": b || void 0,
          inert: b,
          "data-exiting": b || void 0,
          className: `fp-popup-panel ${z === "menu" ? "fp-popup-menu" : z === "listbox" ? "fp-popup-listbox" : "fp-popover-content"} ${h === "compact" ? "fp-popup-compact" : ""} ${u}`,
          style: {
            ...N,
            position: "fixed",
            ...L,
            overflowY: "auto",
            maxWidth: "calc(100vw - 16px)"
          },
          onKeyDown: (U) => {
            if (z === "dialog") return;
            if (U.key === "Tab") {
              v(), w.current?.focus();
              return;
            }
            const T = Array.from(
              y.current?.querySelectorAll(A) || []
            ), E = T.indexOf(
              document.activeElement
            ), S = U.key === "ArrowDown" ? (E + 1) % T.length : U.key === "ArrowUp" ? (E - 1 + T.length) % T.length : U.key === "Home" ? 0 : U.key === "End" ? T.length - 1 : -1;
            S >= 0 && (U.preventDefault(), U.stopPropagation(), T[S]?.focus());
          },
          children: i(M)
        }
      ),
      w.current?.closest("[data-fp-overlay],dialog") || document.body
    )
  ] });
}
function Pa({
  label: t,
  items: n,
  icon: r
}) {
  return /* @__PURE__ */ e(Xe, { label: t, icon: r, menu: !0, children: (i) => n.map((a) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      role: "menuitem",
      className: a.danger ? "fp-error-text" : "",
      onClick: () => {
        i(), a.onClick();
      },
      children: a.label
    },
    a.label
  )) });
}
function Uh({
  label: t,
  children: n
}) {
  return /* @__PURE__ */ e(Xe, { label: t, children: () => n });
}
function Ce({ value: t, onChange: n, options: r, label: i, id: a, disabled: l, placeholder: s = "请选择", className: c = "", searchable: u = r.length > 8 }) {
  return /* @__PURE__ */ e("span", { className: `fp-select-field ${c}`, children: /* @__PURE__ */ e(Xe, { label: i, triggerRole: "combobox", triggerId: a, role: "listbox", disabled: l, className: "fp-select-options", trigger: /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: r.find((d) => d.value === t)?.fontFamily }, children: [
      r.find((d) => d.value === t)?.color && /* @__PURE__ */ e("i", { style: { background: r.find((d) => d.value === t)?.color } }),
      r.find((d) => d.value === t)?.label || s
    ] }),
    /* @__PURE__ */ e(St, { size: 14, "aria-hidden": "true" })
  ] }), children: (d) => /* @__PURE__ */ e(qs, { options: r, value: t, searchable: u, onSelect: (p) => {
    n(p), d();
  } }) }) });
}
function qs({ options: t, value: n, searchable: r, onSelect: i }) {
  const [a, l] = k(""), s = t.filter((c) => `${c.label} ${c.value} ${c.description || ""}`.toLowerCase().includes(a.trim().toLowerCase()));
  return /* @__PURE__ */ o(ee, { children: [
    r && /* @__PURE__ */ e("div", { className: "fp-select-search", children: /* @__PURE__ */ e("input", { "aria-label": "搜索选项", placeholder: "搜索…", value: a, onChange: (c) => l(c.target.value), onKeyDown: (c) => {
      if (!c.nativeEvent.isComposing) {
        if (c.key === "ArrowDown" && (c.preventDefault(), c.currentTarget.parentElement?.nextElementSibling?.querySelector('[role="option"]:not(:disabled)')?.focus()), c.key === "Enter") {
          c.preventDefault();
          const u = s.find((d) => !d.disabled);
          u && i(u.value);
        }
        c.key !== "Escape" && c.stopPropagation();
      }
    } }) }),
    /* @__PURE__ */ o("div", { className: "fp-select-scroll", children: [
      s.map((c, u) => /* @__PURE__ */ o("div", { role: "none", children: [
        c.group && s[u - 1]?.group !== c.group && /* @__PURE__ */ e("div", { className: "fp-select-group", children: c.group }),
        /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": n === c.value, disabled: c.disabled, tabIndex: -1, onClick: () => i(c.value), children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: c.fontFamily }, children: [
              c.color && /* @__PURE__ */ e("i", { style: { background: c.color } }),
              c.label
            ] }),
            c.description && /* @__PURE__ */ e("small", { children: c.description })
          ] }),
          n === c.value && /* @__PURE__ */ e(Ie, { size: 14, "aria-hidden": "true" })
        ] })
      ] }, c.value)),
      !s.length && /* @__PURE__ */ e("p", { className: "fp-select-empty", children: "没有匹配的选项" })
    ] })
  ] });
}
function Mi(t) {
  if (!Number.isFinite(t)) return "0:00";
  const n = Math.floor(t / 60), r = Math.floor(t % 60);
  return `${n}:${String(r).padStart(2, "0")}`;
}
function on({
  src: t,
  poster: n,
  title: r,
  startAt: i = 0,
  autoPlay: a = !1,
  onReady: l,
  onWindowPlayback: s,
  onTimeUpdate: c,
  onEnded: u,
  resolveSource: d,
  videoRef: p,
  onSeek: h,
  onPlaybackRateChange: f,
  onPlaybackError: m,
  tracks: b = [],
  onPictureInPictureChange: g,
  keyboardShortcuts: v = !0
}) {
  const w = R(null), y = R(null), N = R(i), x = R(t), C = R(null), [z, L] = k(b.findIndex((W) => W.default)), [j, M] = k(!1), [A, O] = k(i), [U, T] = k(0), [E, S] = k(1), [P, _] = k(!1), [q, H] = k(d ? "" : t), [I, $] = k(""), [B, J] = k(""), [Z, Ne] = k(0), [pe, V] = k(1), K = R({ onPlaybackError: m });
  K.current = { onPlaybackError: m };
  const re = (W) => {
    $(W), K.current.onPlaybackError?.(W);
  };
  Y(() => {
    const W = new AbortController();
    if (x.current !== t && (x.current = t, N.current = i), $(""), J(""), M(!1), O(N.current), T(0), !d) {
      H(t);
      return;
    }
    return H(""), d(t, W.signal).then((F) => {
      W.signal.aborted || H(F);
    }).catch((F) => {
      W.signal.aborted || re(F instanceof Error ? F.message : "视频暂时无法播放");
    }), () => W.abort();
  }, [t, d, Z]), Y(() => {
    const W = y.current;
    W && (N.current = i, W.currentTime = i);
  }, [t, i]), Y(() => {
    const W = y.current;
    if (!W) return;
    const F = () => g?.(!0), D = () => g?.(!1);
    return W.addEventListener("enterpictureinpicture", F), W.addEventListener("leavepictureinpicture", D), () => {
      W.removeEventListener("enterpictureinpicture", F), W.removeEventListener("leavepictureinpicture", D);
    };
  }, [g]);
  const le = () => {
    const W = y.current;
    W && (W.paused ? W.play().catch(() => re("暂时无法播放，请重试")) : W.pause());
  }, fe = async () => {
    const W = y.current;
    if (W)
      try {
        document.pictureInPictureElement ? await document.exitPictureInPicture() : document.pictureInPictureEnabled && await W.requestPictureInPicture();
      } catch {
        J("暂时无法打开画中画，请重试。");
      }
  }, se = async () => {
    try {
      J(""), document.fullscreenElement === w.current ? await document.exitFullscreen() : await w.current?.requestFullscreen?.();
    } catch {
      J("暂时无法进入全屏，请重试");
    }
  }, we = (W) => {
    const F = y.current;
    !F || !Number.isFinite(F.duration) || F.duration <= 0 || (F.currentTime = Math.max(0, Math.min(F.duration, W)), O(F.currentTime));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-video",
      ref: w,
      tabIndex: 0,
      role: "region",
      "aria-label": r ? `${r}视频播放器` : "视频播放器",
      "aria-keyshortcuts": v ? "Space k j l ArrowLeft ArrowRight ArrowUp ArrowDown m f Home End" : void 0,
      onKeyDown: (W) => {
        if (!v || W.defaultPrevented || W.nativeEvent.isComposing || W.ctrlKey || W.altKey || W.metaKey || W.target.closest('input,textarea,select,button,[contenteditable="true"],[role="combobox"],[role="menu"]')) return;
        const F = y.current;
        if (!F) return;
        const D = W.key.toLowerCase();
        ![" ", "k", "j", "l", "arrowleft", "arrowright", "arrowup", "arrowdown", "m", "f", "home", "end", ",", "."].includes(D) && !/^[0-9]$/.test(D) || (W.preventDefault(), W.stopPropagation(), !(W.repeat && [" ", "k", "m", "f"].includes(D)) && (D === " " || D === "k" ? le() : D === "j" || D === "arrowleft" ? we(F.currentTime - (D === "j" ? 10 : 5)) : D === "l" || D === "arrowright" ? we(F.currentTime + (D === "l" ? 10 : 5)) : D === "home" ? we(0) : D === "end" ? we(F.duration) : /^[0-9]$/.test(D) ? we(F.duration * Number(D) / 10) : D === "arrowup" || D === "arrowdown" ? (F.volume = Math.max(0, Math.min(1, F.volume + (D === "arrowup" ? 0.05 : -0.05))), D === "arrowup" && (F.muted = !1), S(F.volume), _(F.muted)) : D === "m" ? (F.muted = !F.muted, _(F.muted)) : D === "f" ? se() : F.paused && we(F.currentTime + (D === "." ? 1 / 30 : -1 / 30))));
      },
      children: [
        /* @__PURE__ */ o("div", { className: "fp-video-stage", children: [
          /* @__PURE__ */ e(
            "video",
            {
              ref: (W) => {
                y.current = W, typeof p == "function" ? p(W) : p && (p.current = W);
              },
              src: q || void 0,
              poster: n,
              playsInline: !0,
              preload: "metadata",
              onCanPlay: (W) => {
                const F = W.currentTarget;
                l?.(F), a && C.current !== t && (C.current = t, F.play().catch(() => {
                }));
              },
              onClick: () => {
                w.current?.focus({ preventScroll: !0 }), le();
              },
              onPlay: () => M(!0),
              onPause: () => M(!1),
              onLoadedMetadata: (W) => {
                W.currentTarget.playbackRate = pe, W.currentTarget.volume = E, W.currentTarget.muted = P, Array.from(W.currentTarget.textTracks).forEach((F, D) => {
                  F.mode = D === z ? "showing" : "disabled";
                }), T(W.currentTarget.duration), W.currentTarget.currentTime = Math.max(0, Math.min(N.current, W.currentTarget.duration || N.current));
              },
              onError: () => {
                q && re("视频暂时无法播放，请重试");
              },
              onSeeked: (W) => h?.(W.currentTarget.currentTime),
              onRateChange: (W) => {
                V(W.currentTarget.playbackRate), f?.(W.currentTarget.playbackRate);
              },
              onVolumeChange: (W) => {
                S(W.currentTarget.volume), _(W.currentTarget.muted);
              },
              onTimeUpdate: (W) => {
                N.current = W.currentTarget.currentTime, O(W.currentTarget.currentTime), c?.(W.currentTarget.currentTime);
              },
              onEnded: () => {
                M(!1), u?.();
              },
              "aria-label": r || "视频",
              children: b.map((W) => /* @__PURE__ */ e("track", { kind: "subtitles", src: W.src, srcLang: W.language, label: W.label, default: W.default }, W.src))
            }
          ),
          I && /* @__PURE__ */ o("div", { className: "fp-video-error", role: "alert", children: [
            /* @__PURE__ */ e("span", { children: I }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              d || y.current?.load(), Ne((W) => W + 1);
            }, children: "重新加载" })
          ] }),
          !I && !q && /* @__PURE__ */ e("div", { className: "fp-video-error", role: "status", children: "正在准备视频…" }),
          !j && !I && q && /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-video-bigplay",
              "aria-label": "播放",
              onClick: () => {
                w.current?.focus({ preventScroll: !0 }), le();
              },
              children: /* @__PURE__ */ e(cn, { size: 26, fill: "currentColor" })
            }
          )
        ] }),
        /* @__PURE__ */ o(js, { progress: /* @__PURE__ */ e(
          Er,
          {
            type: "range",
            min: 0,
            max: U || 0,
            step: 0.1,
            value: A,
            "aria-label": "播放进度",
            onChange: (W) => {
              const F = Number(W.target.value);
              O(F), y.current && (y.current.currentTime = F);
            }
          }
        ), children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": j ? "暂停" : "播放",
              title: "播放／暂停（空格或 K）",
              onClick: le,
              children: j ? /* @__PURE__ */ e(Vn, { size: 16 }) : /* @__PURE__ */ e(cn, { size: 16 })
            }
          ),
          /* @__PURE__ */ o("span", { className: "fp-media-time", children: [
            Mi(A),
            " / ",
            Mi(U)
          ] }),
          b.length > 0 && /* @__PURE__ */ e(Ce, { label: "字幕", value: String(z), options: [{ value: "-1", label: "关闭字幕" }, ...b.map((W, F) => ({ value: String(F), label: W.label }))], onChange: (W) => {
            const F = Number(W);
            L(F), y.current && Array.from(y.current.textTracks).forEach((D, G) => {
              D.mode = G === F ? "showing" : "disabled";
            });
          } }),
          /* @__PURE__ */ e(Ce, { label: "播放速度", value: String(pe), onChange: (W) => {
            y.current && (y.current.playbackRate = Number(W));
          }, options: [0.5, 0.75, 1, 1.25, 1.5, 2].map((W) => ({ value: String(W), label: `${W}×` })) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": P ? "取消静音" : "静音",
              title: "静音（M）",
              onClick: () => {
                const W = y.current;
                W && (W.muted = !W.muted, _(W.muted));
              },
              children: P ? /* @__PURE__ */ e(da, { size: 16 }) : /* @__PURE__ */ e(ua, { size: 16 })
            }
          ),
          /* @__PURE__ */ e(
            Er,
            {
              className: "fp-media-volume",
              min: 0,
              max: 1,
              step: 0.05,
              value: E,
              "aria-label": "音量",
              onChange: (W) => {
                const F = Number(W.target.value);
                S(F), y.current && (y.current.volume = F);
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": s ? "小窗播放" : "画中画", disabled: !s && typeof document < "u" && !document.pictureInPictureEnabled, onClick: s ? () => s(y.current?.currentTime || 0) : fe, children: /* @__PURE__ */ e(Xl, { size: 16 }) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "全屏",
              title: "全屏（F）",
              onClick: () => {
                se();
              },
              children: /* @__PURE__ */ e(Gn, { size: 16 })
            }
          )
        ] }),
        B && /* @__PURE__ */ e("div", { className: "fp-video-notice", role: "status", children: B })
      ]
    }
  );
}
const Ei = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function Fn({
  src: t,
  title: n = "音频",
  startAt: r = 0,
  onTimeUpdate: i,
  onEnded: a,
  resolveSource: l,
  audioRef: s,
  onSeek: c,
  onPlaybackRateChange: u
}) {
  const d = R(null), p = R(0), h = R(r), f = R(t), [m, b] = k(1), [g, v] = k(l ? "" : t), [w, y] = k(!1), [N, x] = k(0), [C, z] = k(0), [L, j] = k(1), [M, A] = k(""), [O, U] = k(0);
  Y(() => {
    const S = new AbortController(), P = ++p.current;
    return f.current !== t && (f.current = t, h.current = r), A(""), y(!1), x(h.current), z(0), v(""), Promise.resolve(l ? l(t, S.signal) : t).then((_) => {
      !S.signal.aborted && P === p.current && v(_);
    }).catch(() => {
      S.signal.aborted || A("音频暂时无法加载，请重试。");
    }), () => S.abort();
  }, [t, l, O]);
  const T = (S) => {
    if (d.current) {
      const P = Math.max(0, Math.min(C || 0, S));
      d.current.currentTime = P, x(P), h.current = P;
    }
  }, E = () => {
    const S = d.current;
    S && (S.paused ? S.play().catch(() => A("暂时无法播放，请重试。")) : S.pause());
  };
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-audio-player",
      "aria-label": n,
      tabIndex: 0,
      onKeyDown: (S) => {
        if (!S.target.closest("button,input") && [" ", "k", "ArrowLeft", "ArrowRight", "m"].includes(S.key))
          if (S.preventDefault(), S.key === " " || S.key === "k") E();
          else if (S.key === "m") {
            const P = L ? 0 : 1;
            j(P), d.current && (d.current.volume = P);
          } else T(N + (S.key === "ArrowLeft" ? -5 : 5));
      },
      children: [
        /* @__PURE__ */ e(
          "audio",
          {
            ref: (S) => {
              d.current = S, typeof s == "function" ? s(S) : s && (s.current = S);
            },
            src: g || void 0,
            preload: "metadata",
            onLoadedMetadata: () => {
              const S = d.current;
              z(Number.isFinite(S.duration) ? S.duration : 0), S.currentTime = Math.max(0, Math.min(h.current, S.duration || 0)), S.playbackRate = m, S.volume = L;
            },
            onSeeked: () => c?.(d.current.currentTime),
            onRateChange: () => {
              const S = d.current.playbackRate;
              b(S), u?.(S);
            },
            onTimeUpdate: () => {
              h.current = d.current.currentTime, x(h.current), i?.(d.current.currentTime);
            },
            onPlay: () => y(!0),
            onPause: () => y(!1),
            onEnded: () => {
              y(!1), a?.();
            },
            onError: () => {
              g && A("音频暂时无法加载，请重试。");
            }
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-audio-heading", children: [
          /* @__PURE__ */ e("strong", { children: n }),
          /* @__PURE__ */ o("span", { children: [
            Ei(N),
            " / ",
            Ei(C)
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-audio-controls", children: [
          /* @__PURE__ */ e(Ce, { label: "播放速度", value: String(m), options: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((S) => ({ value: String(S), label: `${S}×` })), onChange: (S) => {
            b(Number(S)), d.current && (d.current.playbackRate = Number(S));
          } }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": w ? "暂停" : "播放",
              disabled: !g || !!M,
              onClick: E,
              children: w ? /* @__PURE__ */ e(Vn, { size: 18 }) : /* @__PURE__ */ e(cn, { size: 18 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "播放进度",
              type: "range",
              min: 0,
              max: C || 0,
              step: 0.1,
              value: Math.min(N, C),
              disabled: !C,
              onChange: (S) => T(Number(S.target.value))
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": L ? "静音" : "恢复音量",
              onClick: () => {
                const S = L ? 0 : 1;
                j(S), d.current && (d.current.volume = S);
              },
              children: L ? /* @__PURE__ */ e(ua, { size: 17 }) : /* @__PURE__ */ e(da, { size: 17 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "音量",
              type: "range",
              min: 0,
              max: 1,
              step: 0.05,
              value: L,
              onChange: (S) => {
                const P = Number(S.target.value);
                j(P), d.current && (d.current.volume = P);
              }
            }
          )
        ] }),
        M && /* @__PURE__ */ o("p", { role: "alert", children: [
          M,
          /* @__PURE__ */ e("button", { type: "button", onClick: () => U((S) => S + 1), children: "重试" })
        ] })
      ]
    }
  );
}
function Ks({
  resource: t,
  renderVideoExtra: n,
  videoProps: r,
  audioProps: i
}) {
  let { name: a, url: l, mediaType: s = "", previewUrl: c, bytes: u = 0 } = t, [d, p] = k(""), [h, f] = k(!1), m = /^(text\/(plain|markdown|csv)|application\/json)$/.test(s) || /\.(txt|md|csv|json)$/i.test(a), b = /\.(pdf|pptx?|docx?|xlsx?|odt|odp|ods)$/i.test(a) || s === "application/pdf";
  const g = b ? Br : ge;
  return Y(() => {
    if (p(""), f(!1), !m || u > 2e6) return;
    let v = new AbortController();
    return fetch(l, { signal: v.signal, credentials: "include" }).then((w) => {
      if (!w.ok) throw Error();
      return w.text();
    }).then((w) => {
      v.signal.aborted || p(w);
    }).catch(() => {
      v.signal.aborted || f(!0);
    }), () => v.abort();
  }, [l, m, u]), /* @__PURE__ */ o("section", { className: "fp-resource-preview", children: [
    /* @__PURE__ */ o("header", { className: "fp-resource-header", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: a }),
        /* @__PURE__ */ e("small", { children: b ? "文档预览" : s.startsWith("image/") ? "图片预览" : "文件预览" })
      ] }),
      !b && /* @__PURE__ */ o("a", { href: t.downloadUrl || l, download: a, children: [
        /* @__PURE__ */ e(_t, { size: 16, "aria-hidden": "true" }),
        "下载原文件"
      ] })
    ] }),
    /* @__PURE__ */ e(g, { children: b ? /* @__PURE__ */ e(
      Bs,
      {
        url: c || l,
        name: a,
        downloadUrl: t.downloadUrl || l
      }
    ) : s.startsWith("image/") ? /* @__PURE__ */ e("img", { className: "fp-preview-image", src: l, alt: a }) : s.startsWith("video/") ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e(on, { ...r, src: l, title: a }),
      n
    ] }) : s.startsWith("audio/") ? /* @__PURE__ */ e(Fn, { ...i, src: l, title: a }) : m && u <= 2e6 ? /* @__PURE__ */ e("pre", { className: "fp-preview-text", children: h ? "暂时无法读取，请下载查看。" : d || "正在阅读文件…" }) : /* @__PURE__ */ e("div", { className: "pdf-preview-message", children: "此文件可以下载后查看。" }) })
  ] });
}
function Hs(t, n) {
  const i = (t.target instanceof Element ? t.target : t.target instanceof Node ? t.target.parentElement : null)?.closest("a[href]");
  if (!i) return !1;
  let a;
  try {
    a = new URL(i.href, window.location.href);
  } catch {
    return !1;
  }
  return ["http:", "https:", "mailto:", "tel:"].includes(a.protocol) ? (t.preventDefault(), t.stopPropagation(), n(a.href, i.textContent || ""), !0) : !1;
}
const On = /* @__PURE__ */ new WeakMap();
function Fa(t, n) {
  const r = t.composedPath().find((i) => i instanceof Element && i.matches(".note-math-card,.mermaid-card,.fp-card-editor-frame,.fp-directive-node[data-nested-editor-boundary]"));
  return !r || r === n;
}
function Oa(t, n) {
  return typeof n == "string" && On.get(t) === n;
}
function Us(t, n) {
  Oa(t, n) && On.delete(t);
}
function ur(t, n = "note") {
  if (!t.isEditable) return !1;
  const r = crypto.randomUUID();
  On.set(t, r);
  const i = t.chain().focus().insertContent({ type: "directiveBlock", attrs: { name: n, attributes: "", body: "", id: r } }).command(({ tr: a }) => {
    let l;
    return a.doc.descendants((s, c) => {
      if (s.type.name === "directiveBlock" && s.attrs.id === r)
        return l = c, !1;
    }), l === void 0 ? !1 : (a.setSelection(Rt.create(a.doc, l)), !0);
  }).run();
  return i || On.delete(t), i;
}
function Ws(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const r = n();
  if (r === void 0) return !1;
  const i = t.state.doc.nodeAt(r);
  if (i?.type.name !== "directiveBlock") return !1;
  const a = r + i.nodeSize, l = t.chain().command(({ tr: s }) => (s.doc.nodeAt(a)?.type.name !== "paragraph" && s.insert(a, t.schema.nodes.paragraph.create()), s.setSelection(rt.create(s.doc, a + 1)).setStoredMarks(null).scrollIntoView(), !0)).run();
  return l && t.view.focus(), l;
}
function $i(t) {
  let n = 0;
  return t.descendants((r) => {
    if (r.type.name === "directiveBlock")
      return n++, !1;
  }), n;
}
const _s = tr.create({ name: "cardBodyBoundary", addProseMirrorPlugins() {
  return [new Yt({ filterTransaction: (t, n) => !t.docChanged || $i(t.doc) <= $i(n.doc) })];
} }), $r = "fp.editor.commands.v1", zr = "fp:editor-command-usage";
let Ra, Lt;
const Ar = (t) => /^[a-zA-Z0-9:_-]{1,80}$/.test(t) && !["__proto__", "constructor", "prototype"].includes(t);
function Rn(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    const r = JSON.parse(t || "null");
    if (r?.version !== 1 || !r.counts || typeof r.counts != "object") return n;
    for (const [i, a] of Object.entries(r.counts).slice(0, 128)) {
      if (!Ar(i) || !a || typeof a != "object") continue;
      const l = /* @__PURE__ */ Object.create(null);
      for (const [s, c] of Object.entries(a).slice(0, 256)) Ar(s) && typeof c == "number" && Number.isSafeInteger(c) && c > 0 && c <= 1e9 && (l[s] = c);
      n[i] = l;
    }
  } catch {
  }
  return n;
}
function Wh(t, n) {
  const r = Rn(t);
  for (const [i, a] of Object.entries(Rn(n))) {
    const l = r[i] ??= /* @__PURE__ */ Object.create(null);
    for (const [s, c] of Object.entries(a)) l[s] = Math.max(l[s] || 0, c);
  }
  return JSON.stringify({ version: 1, counts: r });
}
const Ba = () => Ra ?? (typeof window < "u" ? window.localStorage : void 0);
function _h(t) {
  Ra = t, ja();
}
function ja() {
  typeof window < "u" && window.dispatchEvent(new Event(zr));
}
function qa(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    for (const [r, i] of Object.entries(Rn(t === void 0 ? Ba()?.getItem($r) ?? null : t))) n[r] = Object.values(i).reduce((a, l) => a + l, 0);
  } catch {
  }
  return n;
}
function Vh(t, n) {
  return qa(n)[t] || 0;
}
function Vs() {
  if (Lt) return Lt;
  const t = "fp.editor.command-device";
  try {
    Lt = window.localStorage.getItem(t) || crypto.randomUUID(), window.localStorage.setItem(t, Lt);
  } catch {
    Lt = crypto.randomUUID();
  }
  return Lt;
}
function Gs(t) {
  if (!Ar(t) || typeof window > "u") return;
  const n = () => {
    try {
      const r = Ba();
      if (!r) return;
      const i = Rn(r.getItem($r)), a = Vs(), l = i[t] ??= /* @__PURE__ */ Object.create(null);
      l[a] = Math.min(1e9, (l[a] || 0) + 1), r.setItem($r, JSON.stringify({ version: 1, counts: i })), ja();
    } catch {
    }
  };
  navigator.locks ? navigator.locks.request("fp-editor-command-usage", n).catch(() => {
  }) : n();
}
function Ka(t) {
  const n = {}, r = /([\w-]+)=(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^\s}]+))/g;
  for (const i of t.matchAll(r))
    n[i[1]] = (i[2] ?? i[3] ?? i[4] ?? "").replace(
      /\\([\\"'])/g,
      "$1"
    );
  return n;
}
function zi(t, n, r) {
  const i = Ka(t);
  return r ? i[n] = r : delete i[n], Object.entries(i).map(
    ([a, l]) => `${a}="${l.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`
  ).join(" ");
}
const Ys = {
  video: [
    ["src", "视频地址"],
    ["poster", "封面地址"]
  ],
  audio: [["src", "音频地址"]],
  figure: [
    ["src", "图片地址"],
    ["alt", "图片说明"],
    ["caption", "图片标题"],
    ["credit", "图片来源"]
  ],
  interactive: [["src", "内容地址"]],
  plot: [
    ["fn", "函数表达式"],
    ["xmin", "横轴最小值"],
    ["xmax", "横轴最大值"],
    ["ymin", "纵轴最小值"],
    ["ymax", "纵轴最大值"]
  ],
  historymap: [
    ["points", "地点与坐标"],
    ["caption", "地图说明"]
  ],
  learninganimation: [
    ["src", "演示地址"],
    ["source", "源文件地址"],
    ["caption", "演示说明"]
  ],
  event: [
    ["year", "事件时间"],
    ["location", "地点"],
    ["people", "人物"],
    ["result", "结果"],
    ["impact", "影响"]
  ],
  attachment: [
    ["src", "附件地址"],
    ["name", "附件名称"]
  ]
};
function Xs({
  name: t,
  value: n,
  onChange: r,
  disabled: i
}) {
  const a = Ka(n), s = {
    "learning-animation": "learninganimation",
    figuremedia: "figure",
    functionplot: "plot",
    eventcard: "event",
    noteattachment: "attachment",
    memorycard: "memory"
  }[t] || t, c = Ys[s] || [];
  return !c.length && s !== "memory" ? null : /* @__PURE__ */ o("div", { className: "fp-directive-fields", children: [
    s === "memory" && /* @__PURE__ */ o("label", { children: [
      "回忆方式",
      /* @__PURE__ */ e(
        Ce,
        {
          label: "回忆方式",
          value: a.mode || "checklist",
          onChange: (u) => r(zi(n, "mode", u)),
          disabled: i,
          options: [
            { value: "checklist", label: "逐项回忆" },
            { value: "cloze", label: "重点挖空" }
          ]
        }
      )
    ] }),
    c.map(([u, d]) => /* @__PURE__ */ o("label", { children: [
      d,
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": d,
          value: a[u] || "",
          disabled: i,
          onChange: (p) => r(zi(n, u, p.target.value))
        }
      )
    ] }, u))
  ] });
}
function Qs() {
  return (t) => {
    function n(r, i = !1) {
      if (r.type === "element" && ["code", "pre", "script", "style", "math"].includes(r.tagName)) return;
      const a = i || r.type === "element" && ["td", "th"].includes(r.tagName);
      for (let l = 0; l < r.children.length; l++) {
        const s = r.children[l];
        if (s.type === "element") {
          n(s, a);
          continue;
        }
        if (!a || s.type !== "text" || !s.value.includes("$")) continue;
        const c = [], u = new RegExp("(?<!\\\\)\\$(?!\\$)([^$\\n]+?)(?<!\\\\)\\$(?!\\$)", "g");
        let d = 0, p;
        for (; p = u.exec(s.value); )
          p.index > d && c.push({ type: "text", value: s.value.slice(d, p.index) }), c.push({ type: "element", tagName: "span", properties: { className: ["math-inline", "language-math"] }, children: [{ type: "text", value: p[1] }] }), d = p.index + p[0].length;
        c.length && (d < s.value.length && c.push({ type: "text", value: s.value.slice(d) }), r.children.splice(l, 1, ...c), l += c.length - 1);
      }
    }
    n(t);
  };
}
function Js() {
  return (t) => {
    hn(t, "containerDirective", (n) => {
      n.name === "callout" && hn(
        n,
        "text",
        (r, i, a) => {
          if (i == null || a == null || a.children == null) return;
          const l = r.value;
          if (typeof l != "string" || !l.includes(`
`)) return;
          const s = l.split(`
`), c = [];
          return s.forEach((u, d) => {
            d > 0 && c.push({ type: "break" }), u && c.push({ type: "text", value: u });
          }), a.children.splice(i, 1, ...c), [void 0, i + c.length];
        }
      );
    });
  };
}
const Zs = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
], ec = new Set(Zs), tc = {
  intuition: "insight",
  technique: "tip",
  comparison: "compare",
  summary: "keypoint",
  question: "note",
  task: "note"
};
function Ai(t) {
  return tc[t] ?? t;
}
const Bn = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function nc(t) {
  const n = t.toLowerCase();
  return n in Bn ? Bn[n] ?? "note" : "note";
}
function rc(t) {
  const n = t.toLowerCase();
  return n in Bn && Bn[n] === null;
}
const ic = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, ac = /^(\s*)>( ?)(.*)$/;
function lc(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (i) => {
    if (i === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const a = r ? "‘" : "’";
    return r = !r, a;
  });
}
function oc(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let i = !1, a = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const v = c[1][0];
      i ? v === a && (i = !1, a = "") : (i = !0, a = v), r.push(s), l++;
      continue;
    }
    if (i) {
      r.push(s), l++;
      continue;
    }
    const u = s.match(ic);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (rc(p)) {
      r.push(s), l++;
      continue;
    }
    const m = nc(p), b = f.trim(), g = [`kind=${m}`];
    for (b && g.push(`label="${lc(b)}"`), h === "-" && g.push("collapsed=true"), r.push(`${d}:::callout{${g.join(" ")}}`), l++; l < n.length; ) {
      const v = n[l];
      if (!/^\s*>/.test(v) || v.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const y = v.match(ac);
      y ? r.push(y[3]) : r.push(v.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function sc(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let i = !1, a = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      i ? u === a && (i = !1, a = "") : (i = !0, a = u), r.push(l);
      continue;
    }
    if (i) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const cc = /^(\s*:{1,4}[A-Za-z][\w-]*)(\{[^}\n]*\})([^\n]*)$/, dc = /^\{(label|title)=([\s\S]*)\}$/;
function uc(t) {
  return /^\{(?:label|title)=(?:"[^"]*"|'[^']*')(?:\s+[\s\S]*)?\}$/.test(t) ? t : t.replace(dc, (n, r, i) => {
    let a = i.trim();
    return a.length >= 2 && a.startsWith('"') && a.endsWith('"') && (a = a.slice(1, -1)), a = a.replace(/"([^"]*)"/g, "“$1”").replace(/"/g, "“"), a = a.replace(/'([^']*)'/g, "‘$1’").replace(/'/g, "‘"), `{${r}="${a}"}`;
  });
}
function pc(t) {
  if (!t || (t = sc(t), t = oc(t), t.indexOf("::") === -1)) return t;
  const n = t.split(`
`);
  let r = !1, i = "";
  for (let a = 0; a < n.length; a++) {
    const l = n[a], s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const f = s[1][0];
      r ? f === i && (r = !1, i = "") : (r = !0, i = f);
      continue;
    }
    if (r) continue;
    const c = l.match(cc);
    if (!c) continue;
    const [, u, d, p] = c, h = uc(d);
    h !== d && (n[a] = u + h + p);
  }
  return n.join(`
`);
}
const hc = { ...At, clobberPrefix: "fp-content-", tagNames: [...At.tagNames || [], "fp-directive", "mark"], attributes: { ...At.attributes, "fp-directive": ["dataName", "dataAttributes", "data-name", "data-attributes"], span: [...At.attributes?.span || [], "style", ["className", "math-inline", "language-math"]], mark: ["dataColor", "style"], td: [...At.attributes?.td || [], "rowSpan", "colSpan"], th: [...At.attributes?.th || [], "rowSpan", "colSpan"] } }, Li = /^(?:#[\da-f]{3,8}|[a-z]{1,24}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\))$/i;
function fc() {
  return (t) => {
    hn(t, "element", (n) => {
      if (n.tagName !== "span" && n.tagName !== "mark") return;
      const r = n.properties, a = String(r.style || "").split(";").map((s) => s.split(":")).filter(([s, c]) => /^(?:color|background-color|background)$/.test(s?.trim()) && Li.test(c?.trim())).map(([s, c]) => `${s.trim()}:${c.trim()}`), l = String(r.dataColor || "");
      n.tagName === "mark" && Li.test(l) && a.push(`background-color:${l}`), a.length ? r.style = a.join(";") : delete r.style;
    });
  };
}
function mc() {
  return (t) => {
    const n = /* @__PURE__ */ new Map();
    hn(t, "element", (r) => {
      if (!/^h[1-6]$/.test(r.tagName)) return;
      const i = (s) => s.children.map((c) => c.type === "text" ? c.value : c.type === "element" ? i(c) : "").join(""), a = i(r).toLowerCase().trim().replace(/[^\p{L}\p{N}\s_-]/gu, "").replace(/\s+/g, "-") || "section", l = (n.get(a) || 0) + 1;
      n.set(a, l), r.properties.id = l === 1 ? a : `${a}-${l}`;
    });
  };
}
const Ha = {
  "\\placeholder": "\\mathord{\\square}\\phantom{#1}",
  "\\displaylines": "\\begin{gathered}#1\\end{gathered}"
};
function Q(t, n) {
  const r = Ul(async () => {
    const i = await t();
    return typeof i == "function" ? { default: i } : i;
  });
  return () => /* @__PURE__ */ e(Wl, { fallback: /* @__PURE__ */ e("p", { role: "status", children: "正在打开实验…" }), children: /* @__PURE__ */ e(r, {}) });
}
const ai = [
  {
    id: "probability-disk-conditional-lab",
    subjectId: "probability",
    chapterId: "ch03",
    sectionId: "conditional-density",
    title: "圆盘条件密度切片",
    description: "拖动横坐标，比较弦长与归一后的条件密度。",
    Component: Q(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.DiskConditionalLab)
    )
  },
  {
    id: "probability-occupancy-lab",
    subjectId: "probability",
    chapterId: "ch01",
    sectionId: "finite-occupancy",
    title: "每个窗口非空的分配",
    description: "调整人数和窗口数，观察条件计数与指定窗口人数分布。",
    Component: Q(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.OccupancyLab)
    )
  },
  {
    id: "physics-electrostatics-lab",
    subjectId: "physics",
    chapterId: "learning",
    sectionId: "physics-electrostatics-lab",
    title: "静电场与叠加",
    Component: Q(() => import("./ElectrostaticsLab-M7oVnK6H.js"))
  },
  {
    id: "discrete-set-counting",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-set-counting",
    title: "集合运算与计数",
    Component: Q(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.SetCountingLab)
    )
  },
  {
    id: "discrete-order-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-order-lab",
    title: "整除偏序与上下界",
    Component: Q(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.OrderLab)
    )
  },
  {
    id: "discrete-graph-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-graph-lab",
    title: "图的度数与二染色",
    Component: Q(
      () => import("./StructureLabs-DM9gD4l8.js").then(
        (t) => t.GraphStructureLab
      )
    )
  },
  {
    id: "discrete-matching-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-matching-lab",
    title: "图的最大匹配",
    Component: Q(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.MatchingLab)
    )
  },
  {
    id: "numerical-lu-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-lu-lab",
    title: "保存消元乘子的LU分解",
    Component: Q(
      () => import("./FactorizationLabs-CV0_wH89.js").then((t) => t.LULab)
    )
  },
  {
    id: "numerical-cholesky-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-cholesky-lab",
    title: "平方根分解与正定条件",
    Component: Q(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.CholeskyLab
      )
    )
  },
  {
    id: "numerical-thomas-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-thomas-lab",
    title: "追赶法的递推与回代",
    Component: Q(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ThomasLab
      )
    )
  },
  {
    id: "numerical-condition-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-condition-lab",
    title: "条件数与扰动放大",
    Component: Q(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ConditionLab
      )
    )
  },
  {
    id: "numerical-divided-difference-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-divided-difference-lab",
    title: "差商与插值曲线",
    Component: Q(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.DividedDifferenceLab
      )
    )
  },
  {
    id: "discrete-prop-truth-table",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "propositional-logic",
    title: "真值表实验台",
    description: "切换公式与赋值，观察蕴含、双条件和德摩根律。",
    Component: Q(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.TruthTableLab
      )
    )
  },
  {
    id: "discrete-predicate-quantifier",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "predicate-logic",
    title: "量词作用域实验台",
    description: "调整有限论域和谓词条件，对比全称量词与存在量词。",
    Component: Q(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.QuantifierScopeLab
      )
    )
  },
  {
    id: "discrete-relation-properties",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "binary-relations",
    title: "关系性质实验台",
    description: "编辑三阶关系矩阵，实时判断自反、对称、反对称和传递性。",
    Component: Q(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.RelationPropertyLab
      )
    )
  },
  {
    id: "discrete-function-mapping",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "orders-functions",
    title: "函数映射实验台",
    description: "改变有限函数的映射，实时判断单射、满射与双射。",
    Component: Q(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.FunctionMappingLab
      )
    )
  },
  {
    id: "numerical-linear-lab",
    subjectId: "numerical-methods",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "两种线性迭代的计算过程",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.LinearLab)
    )
  },
  {
    id: "numerical-interpolation-lab",
    subjectId: "numerical-methods",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "等距高次插值的变化",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.InterpolationLab
      )
    )
  },
  {
    id: "numerical-fitting-lab",
    subjectId: "numerical-methods",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "观测点与最小二乘拟合",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.FittingLab)
    )
  },
  {
    id: "numerical-quadrature-lab",
    subjectId: "numerical-methods",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "加密网格与积分精度",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.QuadratureLab
      )
    )
  },
  {
    id: "numerical-ode-lab",
    subjectId: "numerical-methods",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "常微分方程的逐步求解",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.OdeLab)
    )
  },
  {
    id: "numerical-power-lab",
    subjectId: "numerical-methods",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "幂法收敛过程",
    Component: Q(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.PowerLab)
    )
  },
  {
    id: "numerical-source-rec-01",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01",
    title: "第一课 · 原始录音",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.RecordingOne)
    )
  },
  {
    id: "numerical-source-rec-02",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02",
    title: "第二课 · 原始录音",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.RecordingTwo)
    )
  },
  {
    id: "numerical-source-slides-03-04",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-03-04",
    title: "课件 · 第三、四章",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then(
        (t) => t.SlidesThreeFour
      )
    )
  },
  {
    id: "numerical-source-slides-05-06",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-05-06",
    title: "课件 · 第五、六章",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.SlidesFiveSix)
    )
  },
  {
    id: "numerical-source-slides-07-08",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-07-08",
    title: "课件 · 第七、八章",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then(
        (t) => t.SlidesSevenEight
      )
    )
  },
  {
    id: "numerical-source-slides",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides",
    title: "课件 · 第一、二章",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.Slides)
    )
  },
  {
    id: "numerical-source-textbook-6",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-6",
    title: "教材 · 第六版完整 PDF",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.Textbook)
    )
  },
  {
    id: "numerical-source-textbook-reference",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-reference",
    title: "补充教材 · 完整 PDF",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then(
        (t) => t.ReferenceTextbook
      )
    )
  },
  {
    id: "numerical-source-rec-01-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01-transcript",
    title: "第一课 · 原始转录稿",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.TranscriptOne)
    )
  },
  {
    id: "numerical-source-rec-02-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02-transcript",
    title: "第二课 · 原始转录稿",
    Component: Q(
      () => Promise.resolve().then(() => Ze).then((t) => t.TranscriptTwo)
    )
  },
  {
    id: "numerical-error-lab",
    subjectId: "numerical-methods",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "面积误差实验",
    Component: Q(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.ErrorLab)
    )
  },
  {
    id: "numerical-bisection-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二分法实验",
    Component: Q(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.BisectionLab)
    )
  },
  {
    id: "numerical-iteration-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "不动点迭代实验",
    Component: Q(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.IterationLab)
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.1-events",
    chapterId: "ch01",
    sectionId: "1.1",
    title: "样本空间构造器",
    description: "点击骰子结果归入事件 A / B，实时显示集合表示与并交差补，直观体会「事件=子集」。",
    Component: Q(() => import("./SampleSpaceBuilder-DKDCubKb.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.2-venn",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "事件运算 · 维恩图实验台",
    description: "选择并、交、差、补、对称差与德摩根律，实时高亮对应区域。",
    Component: Q(() => import("./VennPlayground-yDIe19eQ.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.3-frequency",
    chapterId: "ch01",
    sectionId: "1.3",
    title: "频率趋于概率 · 抛硬币模拟",
    description: "批量抛硬币，观察正面频率随试验次数增大向 0.5 收敛。",
    Component: Q(
      () => import("./FrequencyConvergence-D_R7GMec.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.4-coins",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "古典概型实验室",
    description: "切换掷两骰子之和 / 摸球场景，蒙特卡洛模拟对比理论概率与频率收敛。",
    Component: Q(() => import("./ClassicalProbLab-CsFOyWKB.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.5-bayes-lab",
    chapterId: "ch01",
    sectionId: "1.5",
    title: "贝叶斯推断可视化",
    description: "调患病率 / 灵敏度 / 特异度，用方块图直观显示后验 P(病|阳性) 与基率谬误。",
    Component: Q(() => import("./BayesExplorer-BRx_irdu.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.6-reliability",
    chapterId: "ch01",
    sectionId: "1.6",
    title: "串/并联系统可靠度探索器",
    description: "拖动各元件可靠度，实时计算系统可靠度并高亮工作/失效路径。",
    Component: Q(() => import("./ReliabilityExplorer-BZLcH3fY.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.1-rv-mapper",
    chapterId: "ch02",
    sectionId: "2.1",
    title: "随机变量映射器",
    description: "点击样本点为其指定一个实数值，构造自定义随机变量 X，实时展示 X 的分布律。",
    Component: Q(() => import("./RVMapper-65hp8cRq.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.2-binomial-explorer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二项/泊松分布探索器",
    description: "滑块调 n、p（或 λ），实时绘制分布律柱状图，切换二项/泊松，直观体会参数变化对形状的影响。",
    Component: Q(() => import("./BinomialExplorer-BUimg2bl.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.3-cdf-visualizer",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "分布函数可视化",
    description: "切换离散/连续分布，拖动 x 轴上的竖线，左侧阴影面积实时显示 F(x)=P(X≤x) 的数值。",
    Component: Q(() => import("./CDFVisualizer-1I8Pictu.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.4-pdf-explorer",
    chapterId: "ch02",
    sectionId: "2.4",
    title: "连续分布密度函数探索器",
    description: "切换均匀/指数/正态分布，调参数，拖动区间端点，实时计算 P(a≤X≤b)（面积）。",
    Component: Q(() => import("./PDFExplorer-82a47XZM.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.5-func-dist-demo",
    chapterId: "ch02",
    sectionId: "2.5",
    title: "随机变量函数分布演示",
    description: "选 X 的分布，选变换 Y=g(X)，并排展示 X 和 Y 的 PDF/PMF，直观看到「折叠/拉伸」效果。",
    Component: Q(() => import("./FuncDistDemo-CVrNS8dD.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.1-joint-dist-explorer",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "联合分布律探索器",
    description: "3×3 表格可编辑 p(xi,yj)，自动归一化，热力图实时展示联合分布，底部/右侧显示边缘分布。",
    Component: Q(() => import("./JointDistExplorer-DhO5cBsX.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.2-marginal-explorer",
    chapterId: "ch03",
    sectionId: "3.2",
    title: "边缘分布提取演示",
    description: "从联合分布热力图中，点击某行/列即「投影」出该边缘分布，直观体会「对另一变量求和」的含义。",
    Component: Q(() => import("./MarginalExplorer-CV5J9xv-.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.3-conditional-explorer",
    chapterId: "ch03",
    sectionId: "3.3",
    title: "条件分布可视化",
    description: "点击选定 Y=yj 的行，右侧自动计算并展示归一化后的 P(X|Y=yj)，与边缘 P(X) 并排对比。",
    Component: Q(() => import("./ConditionalExplorer-14dDs9eY.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.4-independence-checker",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "独立性检验器",
    description: "编辑联合分布表，实时检验 p(xi,yj)=pi·qj 是否成立，用颜色高亮违反独立性的格子。",
    Component: Q(() => import("./IndependenceChecker-BDQA5czh.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.5-convolution-demo",
    chapterId: "ch03",
    sectionId: "3.5",
    title: "卷积：两独立随机变量之和",
    description: "选 X 和 Y 各自的分布类型和参数，用蒙特卡洛模拟 Z=X+Y，展示 Z 的经验分布与理论 PDF。",
    Component: Q(() => import("./ConvolutionDemo-BfkHEOoN.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.1-expectation-explorer",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "期望：加权重心探索器",
    description: "可拖动数轴上的概率质量块，实时看到期望「重心」移动，直观体会期望=加权平均。",
    Component: Q(() => import("./ExpectationExplorer-C-WMDKGL.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.2-variance-explorer",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "方差与分布扩散度可视化",
    description: "并排两个正态分布，独立调 μ 和 σ，实时看到曲线形状变化，量化均值/方差/标准差。",
    Component: Q(() => import("./VarianceExplorer-Bv_PRTxx.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.3-correlation-explorer",
    chapterId: "ch04",
    sectionId: "4.3",
    title: "相关系数可视化实验室",
    description: "拖动 ρ 滑块实时生成对应散点云，展示相关系数的几何意义；额外演示不相关但不独立的案例。",
    Component: Q(() => import("./CorrelationExplorer-Ch9T7o1B.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.4-cov-matrix-demo",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "协方差矩阵与等高线椭圆",
    description: "调整 2×2 协方差矩阵的四个元素，实时看到二维正态分布等高线椭圆的形状和方向变化。",
    Component: Q(() => import("./CovMatrixDemo-B-1WZEsk.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.1-chebyshev-demo",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "切比雪夫不等式演示",
    description: "调 ε 和 σ，实时看到概率尾部与切比雪夫上界的数值对比，直观体会不等式的松紧程度。",
    Component: Q(() => import("./ChebyshevDemo-CZm0Kt2n.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.2-lln-simulator",
    chapterId: "ch05",
    sectionId: "5.2",
    title: "大数定律模拟器",
    description: "选分布、调 ε，批量模拟样本均值折线，可视化展示「n 越大，超出 ε 带的折线比例越小」。",
    Component: Q(() => import("./LLNSimulator-pLGn9nLM.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.3-clt-simulator",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "中心极限定理模拟实验室",
    description: "任选底层分布（均匀/指数/泊松/二项），拖动 n，实时看样本均值的标准化直方图收敛到 N(0,1)。",
    Component: Q(() => import("./CLTSimulator-BZqx08Ja.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.1-statistic-calculator",
    chapterId: "ch06",
    sectionId: "6.1",
    title: "统计量计算器",
    description: "输入或随机生成一组样本数据，实时计算 X̄、S²（n-1）、S、顺序统计量，并展示每步计算过程。",
    Component: Q(() => import("./StatisticCalculator-qUSdZTwp.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.2-sampling-dist-explorer",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "三大抽样分布探索器",
    description: "切换 χ²/t/F 分布，调自由度参数，实时展示 PDF 曲线与临界值（α=0.05/0.01）。",
    Component: Q(
      () => import("./SamplingDistExplorer-UxlLcTBn.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch06-6.3-normal-sampling-demo",
    chapterId: "ch06",
    sectionId: "6.3",
    title: "正态总体抽样分布仿真",
    description: "设定正态总体参数和样本量 n，大量重复抽样，实证验证四大定理（X̄、S²、t统计量的分布）。",
    Component: Q(() => import("./NormalSamplingDemo-CwxsNJo3.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.4-quantile-explorer",
    chapterId: "ch06",
    sectionId: "6.4",
    title: "样本分位数与 Q-Q 图",
    description: "生成样本，展示各顺序统计量，绘制 Q-Q 图（与正态理论分位数对比），判断是否来自正态总体。",
    Component: Q(() => import("./QuantileExplorer-DGChs3kW.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.1-moment-estimator",
    chapterId: "ch07",
    sectionId: "7.1",
    title: "矩估计量计算器",
    description: "选分布（指数/正态/均匀），输入样本，自动推导矩估计量公式并代入样本矩给出数值估计。",
    Component: Q(() => import("./MomentEstimator-KE5isNUD.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.2-mle-explorer",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "极大似然估计可视化",
    description: "输入样本数据，展示对数似然函数曲线，标注 MLE 峰值，并允许用户拖动参数感受似然如何随 θ 变化。",
    Component: Q(() => import("./MLEExplorer-Dq7T8fU7.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.3-estimator-comparator",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "估计量性质比较器",
    description: "大量重复抽样，可视化比较 X̄（均值估计）、S²（无偏方差）和 Sn²（有偏方差）的分布，验证无偏性和相合性。",
    Component: Q(() => import("./EstimatorComparator-Dk3lkNZs.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.4-conf-interval-explorer",
    chapterId: "ch07",
    sectionId: "7.4",
    title: "置信区间捕获率可视化",
    description: "设定置信水平、样本量，批量模拟抽样，可视化每次的置信区间，统计实际覆盖率是否接近声称的 1-α。",
    Component: Q(
      () => import("./ConfidenceIntervalExplorer-BxRdZEkH.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.1-hyp-test-demo",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "假设检验直觉演示",
    description: "调显著性水平 α 和观测到的检验统计量 z，实时看到拒绝域变化和决策结果（拒绝/不拒绝 H0）。",
    Component: Q(() => import("./HypTestDemo-rrTfTpPc.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.2-mean-test-explorer",
    chapterId: "ch08",
    sectionId: "8.2",
    title: "均值假设检验计算器",
    description: "输入样本统计量，选 Z/t 检验和检验方向，自动计算检验统计量和 p 值，判断在给定 α 下是否拒绝 H0。",
    Component: Q(() => import("./MeanTestExplorer-CusKecP0.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.3-variance-test-explorer",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "方差假设检验计算器",
    description: "输入样本方差 S²、样本量 n、假设方差 σ₀²，计算 χ² 统计量，在分布图上标注位置，给出检验结论。",
    Component: Q(
      () => import("./VarianceTestExplorer-DMdp9C2G.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.4-error-type-demo",
    chapterId: "ch08",
    sectionId: "8.4",
    title: "两类错误权衡可视化",
    description: "调整显著性水平 α（或等价地移动拒绝域边界），实时看到 α（第一类）和 β（第二类）错误概率的此消彼长。",
    Component: Q(() => import("./ErrorTypeDemo-Ci-t9P-0.js"))
  },
  // ─── 有机化学交互组件 ───────────────────────────────────────────────────────
  {
    subjectId: "chemistry",
    id: "ch01-1.2-bond-polarity",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "电负性与键极性探索器",
    description: "选择两个成键原子，按电负性差 Δχ 判定非极性/极性共价键/离子键，并画出偶极箭头。",
    Component: Q(() => import("./BondPolarityExplorer-CoRShQhQ.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch02-2.2-iupac-namer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "IUPAC 命名练习器",
    description: "选择支链烷烃结构，逐步演示选主链、编号、列取代基、组合系统名的命名过程。",
    Component: Q(() => import("./IUPACNamingPractice-Ba2XNKYT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch03-3.1-boiling-point",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "分子间作用力与沸点比较",
    description: "对烷烃同系列/同分异构体/氢键组排序沸点，验证分子间作用力对物理性质的影响。",
    Component: Q(
      () => import("./BoilingPointComparator-sWZRZAmF.js")
    )
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.1-newman",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "纽曼投影构象能量",
    description: "拖动二面角观察纽曼投影旋转与势能曲线，对比乙烷/丁烷的交叉式与重叠式。",
    Component: Q(() => import("./NewmanProjection-C1EvLXJm.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.2-chair-flip",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "环己烷椅式翻转",
    description: "演示椅式翻转时直立键 a 与平伏键 e 的互换，体会大取代基偏好赤道键。",
    Component: Q(() => import("./ChairFlip-Md0U2D_M.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch05-5.3-carbocation",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "碳正离子稳定性",
    description: "比较甲基/伯/仲/叔碳正离子的超共轭数目与稳定性排序，理解电荷分散。",
    Component: Q(() => import("./CarbocationStability-qUHSlIsS.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch06-6.2-markovnikov",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "马氏规则加成预测",
    description: "选不对称烯烃与 HX，对比两条路径碳正离子稳定性预测主产物；过氧化物切换反马氏。",
    Component: Q(() => import("./MarkovnikovPredictor-DwurHVMV.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch07-7.3-diene",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "共轭二烯 1,2 vs 1,4 加成",
    description: "用温度滑块切换动力学（1,2，低温）与热力学（1,4，高温）产物比例。",
    Component: Q(() => import("./DieneAddition-BoBJrygY.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch08-8.3-directing",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "芳环定位效应预测",
    description: "选苯环上已有取代基，判定致活/致钝与邻对位/间位定向，高亮下一取代位置。",
    Component: Q(() => import("./DirectingEffect-C6D3YGBy.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.1-chirality",
    chapterId: "ch09",
    sectionId: "9.1",
    title: "手性与镜像",
    description: "尝试旋转手性分子的镜像使其重叠，体会对映异构体不可重叠即手性。",
    Component: Q(() => import("./ChiralityMirror-CEewePpu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.3-rs-config",
    chapterId: "ch09",
    sectionId: "9.3",
    title: "R/S 构型判定",
    description: "分步引导：顺序规则排优先级、最小基朝后、看大中小转向判定 R/S。",
    Component: Q(() => import("./RSConfigPractice-BBihDfok.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.1-sn1-sn2",
    chapterId: "ch10",
    sectionId: "10.1",
    title: "SN1/SN2 机理对比",
    description: "选底物/亲核试剂/溶剂，判定倾向 SN1 还是 SN2，演示背面进攻翻转与碳正离子外消旋。",
    Component: Q(() => import("./SN1SN2Compare-De50UNKU.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.2-elimination",
    chapterId: "ch10",
    sectionId: "10.2",
    title: "E1/E2 与扎伊采夫规则",
    description: "选卤代烷展示不同 β-氢消除得到的烯烃，按扎伊采夫规则标出主产物。",
    Component: Q(() => import("./EliminationZaitsev-BuPuwKj3.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch11-11.3-epoxide",
    chapterId: "ch11",
    sectionId: "11.3",
    title: "环氧乙烷开环区域选择",
    description: "切换酸/碱催化，对比亲核试剂进攻位阻大碳（酸）或位阻小碳（碱）。",
    Component: Q(() => import("./EpoxideOpening-MXwtj4vu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch12-12.1-carbonyl",
    chapterId: "ch12",
    sectionId: "12.1",
    title: "羰基亲核加成",
    description: "选不同亲核试剂进攻羰基碳，演示电子流向与对应产物（α-羟基腈/醇/缩醛/亚胺等）。",
    Component: Q(() => import("./CarbonylAddition-DVZgPquT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch13-13.2-acyl-reactivity",
    chapterId: "ch13",
    sectionId: "13.2",
    title: "羧酸衍生物活性序列",
    description: "酰氯>酸酐>酯>酰胺活性排序，点击查看离去能力与电子效应的原因。",
    Component: Q(() => import("./AcylReactivity-wN8j1BXK.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.1-diazonium",
    chapterId: "ch14",
    sectionId: "14.1",
    title: "重氮盐转化网络",
    description: "点击不同试剂展示重氮盐的桑德迈尔/席曼/还原/水解/偶联等转化产物。",
    Component: Q(() => import("./DiazoniumNetwork-Cd5Wc6HL.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.2-amine-basicity",
    chapterId: "ch14",
    sectionId: "14.2",
    title: "胺碱性比较",
    description: "对脂肪胺/氨/芳胺/吡啶/吡咯排序碱性，解释电子效应与芳香共轭的影响。",
    Component: Q(() => import("./AmineBasicity-C1sxuYtu.js"))
  }
];
(() => {
  const t = /* @__PURE__ */ new Set();
  for (const n of ai) {
    if (t.has(n.id))
      throw new Error(
        `[registry] 重复的交互 id: "${n.id}"（交互 id 必须全局唯一）`
      );
    t.add(n.id);
  }
})();
function bc(t) {
  if (t)
    return ai.find((n) => n.id === t);
}
const li = yn(null);
function it({
  id: t,
  kind: n = "document"
}) {
  const r = Wt(li);
  return /* @__PURE__ */ e("section", { className: "fp-learning-source", children: r ? r(t, n) : /* @__PURE__ */ e("p", { children: "请从课程资料中打开此内容。" }) });
}
const gc = () => /* @__PURE__ */ e(it, { id: "rec-01", kind: "audio" }), yc = () => /* @__PURE__ */ e(it, { id: "rec-02", kind: "audio" }), vc = () => /* @__PURE__ */ e(it, { id: "slides" }), wc = () => /* @__PURE__ */ e(it, { id: "textbook-6" }), kc = () => /* @__PURE__ */ e(it, { id: "textbook-reference" }), Nc = () => /* @__PURE__ */ e(it, { id: "rec-01", kind: "transcript" }), xc = () => /* @__PURE__ */ e(it, { id: "rec-02", kind: "transcript" }), Cc = () => /* @__PURE__ */ e(it, { id: "slides-03-04" }), Sc = () => /* @__PURE__ */ e(it, { id: "slides-05-06" }), Mc = () => /* @__PURE__ */ e(it, { id: "slides-07-08" }), Ze = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LearningSourceContext: li,
  RecordingOne: gc,
  RecordingTwo: yc,
  ReferenceTextbook: kc,
  Slides: vc,
  SlidesFiveSix: Sc,
  SlidesSevenEight: Mc,
  SlidesThreeFour: Cc,
  Textbook: wc,
  TranscriptOne: Nc,
  TranscriptTwo: xc
}, Symbol.toStringTag, { value: "Module" }));
class Ec extends _l {
  state = { failed: !1, attempt: 0 };
  static getDerivedStateFromError() {
    return { failed: !0 };
  }
  componentDidCatch(n, r) {
    this.props.onError?.(n, r);
  }
  componentDidUpdate(n) {
    n.resetKey !== this.props.resetKey && this.state.failed && this.retry();
  }
  retry = () => this.setState(({ attempt: n }) => ({ failed: !1, attempt: n + 1 }));
  render() {
    return this.state.failed ? /* @__PURE__ */ o("section", { className: "fp-surface-recovery", role: "alert", children: [
      /* @__PURE__ */ e(tt, { size: 24, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: this.props.title || "内容暂时无法显示" }),
      /* @__PURE__ */ e("p", { children: this.props.description || "请重新打开，继续查看内容。" }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary", onClick: this.retry, children: [
        /* @__PURE__ */ e(tt, { size: 15, "aria-hidden": "true" }),
        "重新打开"
      ] })
    ] }) : /* @__PURE__ */ e("div", { className: "fp-surface-boundary", children: this.props.children }, this.state.attempt);
  }
}
function ne({
  title: t,
  description: n,
  actions: r,
  children: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-section", children: [
    (t || n || r) && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        t && /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r && /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: r })
    ] }),
    i
  ] });
}
function $c({
  label: t,
  value: n,
  onChange: r,
  disabled: i,
  required: a
}) {
  const [l, s] = k(String(n)), c = R(!1), u = R(l);
  return u.current = l, Y(() => {
    (!c.current || !(typeof n == "number" && Object.is(Number(u.current), n)) && u.current !== String(n)) && s(String(n));
  }, [n]), /* @__PURE__ */ e(
    "input",
    {
      "aria-label": t,
      className: "fp-input",
      type: "text",
      inputMode: "decimal",
      value: l,
      onFocus: () => {
        c.current = !0;
      },
      onBlur: () => {
        c.current = !1, (typeof n == "string" || Number.isFinite(n)) && s(String(n));
      },
      onChange: (d) => {
        const p = d.target.value;
        u.current = p, s(p), r(p);
      },
      disabled: i,
      required: a
    }
  );
}
function X({
  label: t,
  value: n,
  onChange: r,
  hint: i,
  options: a,
  multiline: l,
  secret: s,
  numeric: c,
  disabled: u,
  required: d
}) {
  return /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    a ? /* @__PURE__ */ e(
      Ce,
      {
        label: t,
        value: String(n),
        options: a,
        onChange: r,
        disabled: u
      }
    ) : l ? /* @__PURE__ */ e(
      "textarea",
      {
        "aria-label": t,
        className: "fp-input",
        value: n,
        onChange: (p) => r(p.target.value),
        rows: 5,
        disabled: u,
        required: d
      }
    ) : c ? /* @__PURE__ */ e(
      $c,
      {
        label: t,
        value: n,
        onChange: r,
        disabled: u,
        required: d
      }
    ) : /* @__PURE__ */ e(
      "input",
      {
        "aria-label": t,
        className: "fp-input",
        type: s ? "password" : "text",
        value: n,
        onChange: (p) => r(p.target.value),
        disabled: u,
        required: d,
        autoComplete: s ? "new-password" : void 0
      }
    ),
    i && /* @__PURE__ */ e("small", { children: i })
  ] });
}
function Le({
  label: t,
  checked: n,
  onChange: r,
  description: i,
  disabled: a
}) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-toggle", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      i && /* @__PURE__ */ e("p", { children: i })
    ] }),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        role: "switch",
        "aria-label": t,
        "aria-checked": n,
        disabled: a,
        className: "fp-switch-label",
        onClick: () => r(!n),
        children: /* @__PURE__ */ e("span", { "aria-hidden": "true", className: `fp-switch${n ? " is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) })
      }
    )
  ] });
}
function Ge({
  label: t,
  value: n,
  onChange: r,
  items: i,
  density: a = "comfortable"
}) {
  const l = ve(), s = Zn();
  return /* @__PURE__ */ e("div", { className: "fp-settings-tabs", "data-density": a, role: "tablist", "aria-label": t, children: i.map((c) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      role: "tab",
      "aria-selected": n === c.id,
      tabIndex: n === c.id ? 0 : -1,
      onClick: () => r(c.id),
      onKeyDown: (u) => {
        const d = i.findIndex((h) => h.id === c.id), p = u.key === "ArrowRight" ? (d + 1) % i.length : u.key === "ArrowLeft" ? (d - 1 + i.length) % i.length : u.key === "Home" ? 0 : u.key === "End" ? i.length - 1 : -1;
        p >= 0 && (u.preventDefault(), r(i[p].id), u.currentTarget.parentElement?.children[p]?.focus());
      },
      children: [
        n === c.id && /* @__PURE__ */ e(
          er.span,
          {
            className: "fp-settings-tab-indicator",
            layoutId: `settings-tab-${l}`,
            transition: {
              duration: s ? 0 : 0.18,
              ease: [0.2, 0.8, 0.2, 1]
            }
          }
        ),
        /* @__PURE__ */ e("span", { children: c.label })
      ]
    },
    c.id
  )) });
}
function Pe() {
  const [t, n] = k(!1), [r, i] = k(""), [a, l] = k(""), s = R(!1), c = R(!0);
  return Y(() => (c.current = !0, () => {
    c.current = !1;
  }), []), { busy: t, error: r, message: a, run: async (d, p = "") => {
    if (s.current) return !1;
    s.current = !0, n(!0), i(""), l("");
    try {
      return await d(), c.current && p && l(p), !0;
    } catch (h) {
      return c.current && i(
        h instanceof Error ? h.message : "操作暂未完成，请重试。"
      ), !1;
    } finally {
      s.current = !1, c.current && n(!1);
    }
  }, setError: i, setMessage: l };
}
function Ee({
  error: t,
  message: n
}) {
  return /* @__PURE__ */ e(
    ge,
    {
      className: `fp-feedback-size${t || n ? " fp-feedback-visible" : ""}`,
      children: /* @__PURE__ */ o("div", { className: "fp-workspace-feedback", children: [
        t && /* @__PURE__ */ e("p", { role: "alert", children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] })
    }
  );
}
function dt({
  busy: t,
  dirty: n = !0,
  onClick: r,
  label: i = "保存更改"
}) {
  return /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-primary",
      disabled: t || !n,
      onClick: r,
      children: t ? "正在保存…" : i
    }
  );
}
function at(t) {
  const [n, r] = k(t), [i, a] = k(() => JSON.stringify(t)), l = JSON.stringify(t), s = JSON.stringify(n) !== i, c = R(l);
  return Y(() => {
    l !== c.current && (c.current = l, s || (r(t), a(l)));
  }, [l, i, s]), { draft: n, setDraft: r, dirty: s, accept: (d) => {
    r(d), a(JSON.stringify(d));
  } };
}
function Ua({
  id: t,
  renderSource: n,
  sources: r
}) {
  const i = bc(t);
  if (!i) return /* @__PURE__ */ e("p", { children: "暂时无法打开此实验，请重新选择。" });
  const a = i.Component;
  return /* @__PURE__ */ e(
    li.Provider,
    {
      value: n || (r ? (l, s) => r[`${l}:${s}`] || r[l] ? /* @__PURE__ */ e(
        Ku,
        {
          source: r[`${l}:${s}`] || r[l]
        },
        `${l}:${s}`
      ) : /* @__PURE__ */ e("p", { children: "此资料暂不可用。" }) : null),
      children: /* @__PURE__ */ e(Ec, { resetKey: t, children: /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ e("div", { className: "fp-lab-content", "aria-label": i.title, children: /* @__PURE__ */ e(a, {}) }) }) })
    }
  );
}
function Gh({
  value: t,
  onSelect: n,
  onSave: r,
  renderSource: i,
  sources: a
}) {
  const [l, s] = k(""), [c, u] = k("all"), [d, p] = k(""), h = Pe(), f = t ?? d, m = {
    probability: "概率论",
    chemistry: "有机化学",
    physics: "大学物理",
    "discrete-math": "离散数学",
    "numerical-methods": "数值计算"
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ne,
    {
      title: "交互实验",
      description: "改变条件，观察结果，检验自己的理解。",
      children: [
        /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
          /* @__PURE__ */ e(X, { label: "搜索实验", value: l, onChange: s }),
          /* @__PURE__ */ e(
            X,
            {
              label: "实验学科",
              value: c,
              onChange: u,
              options: [
                { value: "all", label: "全部学科" },
                ...Object.entries(m).map(([b, g]) => ({
                  value: b,
                  label: g
                }))
              ]
            }
          )
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ e(
            "nav",
            {
              className: "fp-workspace-item-list fp-experiment-list",
              "aria-label": "交互实验列表",
              children: ai.filter(
                (b) => (c === "all" || c === b.subjectId) && `${b.title} ${b.description || ""}`.includes(l)
              ).map((b) => /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-pressed": f === b.id,
                  onClick: () => {
                    p(b.id), n?.(b.id);
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: b.title }),
                    /* @__PURE__ */ e("small", { children: m[b.subjectId] || b.subjectId })
                  ]
                },
                b.id
              ))
            }
          ),
          /* @__PURE__ */ e("div", { children: f ? /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e(
              Ua,
              {
                id: f,
                renderSource: i,
                sources: a
              }
            ),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h.busy,
                className: "fp-button fp-secondary",
                onClick: () => {
                  h.run(() => r(f), "实验已保存到笔记。");
                },
                children: "保存到笔记"
              }
            )
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个实验开始探索。" }) })
        ] }),
        /* @__PURE__ */ e(Ee, { ...h })
      ]
    }
  ) });
}
const zc = [
  "svg",
  "g",
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "textPath",
  "defs",
  "marker",
  "use",
  "symbol",
  "clipPath",
  "mask",
  "pattern",
  "linearGradient",
  "radialGradient",
  "stop",
  "title",
  "desc",
  "image"
], Ac = [
  "viewBox",
  "xmlns",
  "width",
  "height",
  "x",
  "y",
  "cx",
  "cy",
  "r",
  "rx",
  "ry",
  "x1",
  "y1",
  "x2",
  "y2",
  "d",
  "points",
  "fill",
  "stroke",
  "stroke-width",
  "stroke-dasharray",
  "stroke-linecap",
  "stroke-linejoin",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "transform",
  "font-size",
  "font-family",
  "font-weight",
  "text-anchor",
  "dominant-baseline",
  "dx",
  "dy",
  "markerWidth",
  "markerHeight",
  "refX",
  "refY",
  "orient",
  "id",
  "class",
  "clip-path",
  "mask",
  "filter",
  "gradientUnits",
  "offset",
  "stop-color",
  "stop-opacity",
  "patternUnits",
  "preserveAspectRatio",
  "role",
  "aria-label",
  "startOffset",
  "textLength",
  "lengthAdjust",
  "marker-end",
  "marker-start",
  "marker-mid",
  "fill-rule",
  "clip-rule",
  "letter-spacing",
  "word-spacing",
  "writing-mode",
  "alignment-baseline",
  "baseline-shift"
];
function Lc(t, n = !0) {
  if (typeof window > "u") return t;
  let r;
  try {
    r = us.sanitize(t, {
      USE_PROFILES: { svg: !0, svgFilters: !0 },
      ADD_TAGS: zc,
      ADD_ATTR: Ac,
      FORBID_TAGS: ["script", "foreignObject", "iframe", "object", "embed"],
      FORBID_ATTR: ["onclick", "onload", "onerror", "onmouseover", "onmouseout", "onfocus", "onblur"]
    });
  } catch {
    return "";
  }
  return n && (r = r.replace(/(fill|stroke)="(?:black|#000(?:000)?|rgb\(0,\s*0,\s*0\))"/g, '$1="currentColor"').replace(/fill="(?:white|#fff(?:fff)?|rgb\(255,\s*255,\s*255\))"/g, 'fill="var(--diagram-surface)"')), r;
}
const Ic = /* @__PURE__ */ new Set([
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "use",
  "image"
]);
function Dc(t) {
  const n = t.getAttribute("viewBox") ?? t.getAttribute("viewbox");
  if (!n) return null;
  const r = n.trim().split(/[\s,]+/).map(Number).filter(Number.isFinite);
  return r.length !== 4 || r[2] <= 0 || r[3] <= 0 ? null : { minX: r[0], minY: r[1], width: r[2], height: r[3] };
}
function pt(t, n) {
  const r = t.getAttribute(n);
  if (!r) return null;
  const i = Number.parseFloat(r);
  return Number.isFinite(i) ? i : null;
}
function Tc(t, n) {
  const r = n.minX + n.width, i = n.minY + n.height, a = t.tagName.toLowerCase(), l = [];
  if (a === "circle" || a === "ellipse") {
    const s = pt(t, "cx"), c = pt(t, "cy");
    s !== null && c !== null && l.push({ x: s, y: c });
  } else if (a === "rect" || a === "image" || a === "text" || a === "use") {
    const s = pt(t, "x") ?? 0, c = pt(t, "y") ?? 0;
    l.push({ x: s, y: c });
  } else if (a === "line") {
    const s = pt(t, "x1"), c = pt(t, "y1"), u = pt(t, "x2"), d = pt(t, "y2");
    s !== null && c !== null && l.push({ x: s, y: c }), u !== null && d !== null && l.push({ x: u, y: d });
  } else
    return !0;
  return l.length === 0 ? !0 : l.some(
    (s) => s.x >= n.minX && s.x <= r && s.y >= n.minY && s.y <= i
  );
}
function Pc(t) {
  const n = t.trim();
  if (!n) return { ok: !1, reason: "empty", visibleElementCount: 0 };
  if (typeof DOMParser > "u") {
    const s = (n.match(/<(?:circle|ellipse|rect|line|polyline|polygon|path|text|tspan|use|image)\b/gi) ?? []).length;
    return s > 0 ? { ok: !0, reason: "ok", visibleElementCount: s } : { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  }
  const i = new DOMParser().parseFromString(n, "image/svg+xml").querySelector("svg");
  if (!i) return { ok: !1, reason: "no-svg-root", visibleElementCount: 0 };
  const a = Array.from(i.querySelectorAll("*")).filter((s) => Ic.has(s.tagName.toLowerCase()));
  if (a.length === 0) return { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  const l = Dc(i);
  return l && !a.some((s) => Tc(s, l)) ? { ok: !1, reason: "out-of-viewbox", visibleElementCount: a.length } : { ok: !0, reason: "ok", visibleElementCount: a.length };
}
function oi() {
  const [t, n] = k(!1), r = De(() => n((a) => !a), []), i = De(() => n(!1), []);
  return Y(() => {
    if (!t) return;
    const a = document.activeElement, l = (s) => {
      s.key === "Escape" && (s.preventDefault(), s.stopPropagation(), i());
    };
    return document.addEventListener("keydown", l, !0), () => {
      document.removeEventListener("keydown", l, !0), a?.focus({ preventScroll: !0 });
    };
  }, [t, i]), { fullscreen: t, toggle: r, exit: i };
}
function si({
  onReset: t,
  onZoomIn: n,
  onZoomOut: r,
  onDownload: i,
  onOpenExternal: a,
  onMaximize: l,
  fullscreen: s = !1
}) {
  return /* @__PURE__ */ o("div", { className: "svg-canvas-controls", children: [
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: n,
        "data-fp-tooltip": "放大",
        "aria-label": "放大",
        children: /* @__PURE__ */ e(Kr, { size: 17 })
      }
    ),
    r && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: r,
        "data-fp-tooltip": "缩小",
        "aria-label": "缩小",
        children: /* @__PURE__ */ e(Hr, { size: 17 })
      }
    ),
    t && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: t,
        "data-fp-tooltip": "重置视图",
        "aria-label": "重置视图",
        children: /* @__PURE__ */ e(tt, { size: 17 })
      }
    ),
    i && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: i,
        "data-fp-tooltip": "下载 HTML",
        "aria-label": "下载 HTML",
        children: /* @__PURE__ */ e(_t, { size: 17 })
      }
    ),
    a && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: a,
        "data-fp-tooltip": "新页面展开",
        "aria-label": "新页面展开",
        children: /* @__PURE__ */ e(Vt, { size: 17 })
      }
    ),
    l && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: l,
        "data-fp-tooltip": s ? "退出全屏" : "放大查看",
        "aria-label": s ? "退出全屏" : "放大查看",
        children: s ? /* @__PURE__ */ e(jr, { size: 17 }) : /* @__PURE__ */ e(qr, { size: 17 })
      }
    )
  ] });
}
function Fc({
  diagnostic: t
}) {
  return !t || t.ok ? null : /* @__PURE__ */ o("div", { className: "fp-canvas-status", role: "status", children: [
    /* @__PURE__ */ e("strong", { children: "画布暂时无法显示" }),
    /* @__PURE__ */ e("p", { children: "请检查内容，或通过“修改画布”调整后再试。" })
  ] });
}
function Oc({
  busy: t,
  error: n,
  onCancel: r,
  onSubmit: i
}) {
  const [a, l] = k(""), s = Pe(), c = t || s.busy;
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-canvas-revision",
      onSubmit: (u) => {
        u.preventDefault(), !(!a.trim() || c || !i) && s.run(async () => {
          await i(a.trim()), l(""), r();
        });
      },
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "希望如何调整画布",
            value: a,
            multiline: !0,
            disabled: c,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(Ee, { error: n || s.error }),
        /* @__PURE__ */ o("footer", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-secondary",
              type: "button",
              disabled: c,
              onClick: r,
              children: "取消"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-primary",
              type: "submit",
              disabled: c || !a.trim() || !i,
              children: c ? "正在调整…" : "生成修改"
            }
          )
        ] })
      ]
    }
  );
}
function wn({
  title: t,
  source: n,
  diagnostic: r,
  controls: i,
  children: a,
  className: l,
  style: s,
  onPointerDown: c,
  onPointerMove: u,
  onPointerUp: d,
  onPointerCancel: p,
  onWheel: h,
  revisionBlock: f,
  revisionTopic: m,
  revisionBusy: b = !1,
  revisionError: g,
  onRevisionSubmit: v,
  onRevisionAccepted: w
}) {
  const [y, N] = k(!1), [x, C] = k(!1), z = !!n?.trim();
  return /* @__PURE__ */ o(
    "div",
    {
      className: `svg-canvas-wrapper canvas-frame ${l ?? ""}`,
      style: s,
      onPointerDown: c,
      onPointerMove: u,
      onPointerUp: d,
      onPointerCancel: p,
      onWheel: h,
      children: [
        /* @__PURE__ */ e("div", { className: "svg-canvas-controls svg-canvas-controls-left", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "press",
            disabled: !v,
            onClick: () => N((L) => !L),
            title: "修改画布",
            "aria-label": "修改画布",
            children: /* @__PURE__ */ e(Yn, { size: 11 })
          }
        ) }),
        i,
        t ? /* @__PURE__ */ e("div", { className: "canvas-frame-title", children: t }) : null,
        /* @__PURE__ */ e("div", { className: "canvas-frame-body", children: a }),
        /* @__PURE__ */ e(Fc, { diagnostic: r }),
        /* @__PURE__ */ e(ge, { children: y ? /* @__PURE__ */ e(
          Oc,
          {
            block: f,
            topic: m,
            busy: b,
            error: g,
            onCancel: () => N(!1),
            onSubmit: v,
            onRevisionAccepted: w
          }
        ) : null }),
        z ? /* @__PURE__ */ o("div", { className: "canvas-source-panel", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "viz-error-toggle press",
              onClick: () => C((L) => !L),
              children: x ? "收起内容" : "查看内容"
            }
          ),
          /* @__PURE__ */ e(ge, { children: x ? /* @__PURE__ */ e("pre", { className: "viz-error-source", children: n }) : null })
        ] }) : null
      ]
    }
  );
}
function rr({
  open: t,
  onExit: n,
  children: r,
  label: i = "学习画布"
}) {
  const a = R(null), l = R(null), s = R(null), [c, u] = k(null);
  return xe(() => {
    const d = document.createElement("div");
    return d.className = "fp-canvas-portal-content", u(d), () => d.remove();
  }, []), xe(() => {
    c && (t ? l.current : a.current)?.append(c);
  }, [c, t]), Y(() => {
    if (!t) return;
    s.current = document.activeElement;
    const d = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const p = requestAnimationFrame(
      () => l.current?.querySelector('button:not(:disabled),[tabindex="0"]')?.focus({ preventScroll: !0 })
    );
    return () => {
      cancelAnimationFrame(p), document.body.style.overflow = d, s.current?.focus({ preventScroll: !0 });
    };
  }, [t]), /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e("div", { ref: a }),
    c && Oe(r, c),
    t && Oe(
      /* @__PURE__ */ e("div", { className: "canvas-fullscreen-backdrop", onClick: n, children: /* @__PURE__ */ e(
        "div",
        {
          ref: l,
          className: "canvas-fullscreen-stage",
          role: "dialog",
          "aria-modal": "true",
          "aria-label": i,
          onClick: (d) => d.stopPropagation(),
          onKeyDown: (d) => {
            if (d.key === "Escape" && d.target.closest("[data-fp-overlay]") || (d.key === "Escape" && (d.preventDefault(), d.stopPropagation(), n()), d.key !== "Tab")) return;
            const p = [
              ...d.currentTarget.querySelectorAll(
                'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]'
              )
            ].filter((m) => m.getClientRects().length), h = p[0], f = p.at(-1);
            d.shiftKey && document.activeElement === h ? (d.preventDefault(), f?.focus()) : !d.shiftKey && document.activeElement === f && (d.preventDefault(), h?.focus());
          }
        }
      ) }),
      document.body
    )
  ] });
}
const Ii = { x: 0, y: 0, zoom: 1 };
function Lr(t, n, r) {
  const i = Math.max(0.25, Math.min(4, r)), a = i / t.zoom;
  return { x: n.x - (n.x - t.x) * a, y: n.y - (n.y - t.y) * a, zoom: i };
}
function Di(t, n, r, i = !0, a = !0) {
  const l = (h) => ({ x: h.reduce((f, m) => f + m.x, 0) / h.length, y: h.reduce((f, m) => f + m.y, 0) / h.length }), s = l(n), c = l(r), u = (h) => Math.hypot(h[0].x - h[1].x, h[0].y - h[1].y), d = i && n.length === 2 && r.length === 2 && u(n) > 2 ? u(r) / u(n) : 1, p = Lr(t, s, t.zoom * d);
  return { ...p, x: p.x + (a ? c.x - s.x : 0), y: p.y + (a ? c.y - s.y : 0) };
}
function ci({ fullscreen: t = !1, pannable: n = !0, zoomable: r = !0, resetKey: i, origin: a = "top-left" } = {}) {
  const [l, s] = k(null), [c, u] = k(Ii), d = R(c), p = R(null), h = De((v) => {
    d.current = v, u(v);
  }, []), f = De(() => h(Ii), [h]);
  Y(f, [f, i]);
  const m = De((v, w) => {
    if (!l) return { x: v, y: w };
    if (l instanceof SVGSVGElement) {
      const N = l.getScreenCTM();
      if (N) {
        const x = new DOMPoint(v, w).matrixTransform(N.inverse());
        return { x: x.x, y: x.y };
      }
    }
    const y = l.getBoundingClientRect();
    return { x: v - y.left - (a === "center" ? y.width / 2 : 0), y: w - y.top - (a === "center" ? y.height / 2 : 0) };
  }, [l, a]), b = De((v) => {
    if (!l || !r) return;
    const w = l.getBoundingClientRect();
    h(Lr(d.current, m(w.left + w.width / 2, w.top + w.height / 2), d.current.zoom * v));
  }, [l, m, h, r]);
  Y(() => {
    if (!l) return;
    let v = null, w = !1;
    const y = (L) => Array.from(L.touches).filter((j) => j.target instanceof Node && l.contains(j.target)), N = (L) => {
      const j = L, M = y(j);
      if (!M.length) {
        v = null, w = !1;
        return;
      }
      if (!t && !w && M.length < 2 || !n && !r || !j.cancelable) {
        v = null;
        return;
      }
      j.preventDefault(), w = !0;
      const A = M.slice(0, 2);
      v = { ids: A.map((O) => O.identifier), points: A.map((O) => m(O.clientX, O.clientY)) };
    }, x = (L) => {
      const j = L;
      if (!v || !j.cancelable) {
        v = null;
        return;
      }
      const M = y(j), A = v.ids.map((U) => M.find((T) => T.identifier === U));
      if (A.some((U) => !U)) {
        N(j);
        return;
      }
      j.preventDefault();
      const O = A.map((U) => m(U.clientX, U.clientY));
      h(Di(d.current, v.points, O, r, n)), v.points = O;
    }, C = () => {
      v = null, w = !1, p.current = null;
    }, z = (L) => {
      const j = L;
      !r || !j.ctrlKey && !j.metaKey || (j.preventDefault(), h(Lr(d.current, m(j.clientX, j.clientY), d.current.zoom * Math.exp(-j.deltaY * 2e-3))));
    };
    return l.addEventListener("touchstart", N, { passive: !1 }), l.addEventListener("touchmove", x, { passive: !1 }), l.addEventListener("touchend", N, { passive: !1 }), l.addEventListener("touchcancel", C), l.addEventListener("wheel", z, { passive: !1 }), window.addEventListener("blur", C), () => {
      C(), l.removeEventListener("touchstart", N), l.removeEventListener("touchmove", x), l.removeEventListener("touchend", N), l.removeEventListener("touchcancel", C), l.removeEventListener("wheel", z), window.removeEventListener("blur", C);
    };
  }, [l, t, n, r, m, h]);
  const g = De((v) => {
    p.current?.id === v.pointerId && (p.current = null);
  }, []);
  return { ref: s, element: l, view: c, reset: f, zoomBy: b, bind: {
    onPointerDown: (v) => {
      v.pointerType === "touch" || !n || v.button !== 0 || p.current || v.target.closest?.("button,a,input,textarea") || (p.current = { id: v.pointerId, point: m(v.clientX, v.clientY) }, v.currentTarget.setPointerCapture(v.pointerId));
    },
    onPointerMove: (v) => {
      const w = p.current;
      if (!w || w.id !== v.pointerId) return;
      const y = m(v.clientX, v.clientY);
      h(Di(d.current, [w.point], [y], !1, n)), w.point = y;
    },
    onPointerUp: g,
    onPointerCancel: g,
    onLostPointerCapture: g,
    style: { touchAction: n || r ? t ? "none" : "pan-y" : "auto" }
  } };
}
function Ti(t, n) {
  const r = t.match(new RegExp(`\\b${n}\\s*=\\s*["']([^"']+)["']`, "i"))?.[1];
  if (!r || !/^\s*\d+(?:\.\d+)?(?:px)?\s*$/.test(r)) return;
  const i = parseFloat(r);
  return i > 0 && Number.isFinite(i) ? i : void 0;
}
function Rc(t, n = 400, r = 300) {
  const i = (u, d) => Number.isFinite(u) && u > 0 ? u : d;
  n = i(n, 400), r = i(r, 300);
  const a = t.match(/<svg\b[^>]*>/i);
  if (!a) return { markup: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${r}">${t}</svg>`, width: n, height: r };
  const l = a[0].match(/\bviewBox\s*=\s*["']([^"']+)["']/i)?.[1].trim().split(/[\s,]+/).map(Number), s = l?.length === 4 && l.every(Number.isFinite) && l[2] > 0 && l[3] > 0;
  n = s ? l[2] : Ti(a[0], "width") ?? n, r = s ? l[3] : Ti(a[0], "height") ?? r;
  let c = a[0].replace(/\s(?:width|height|preserveAspectRatio)\s*=\s*(?:"[^"]*"|'[^']*')/gi, "");
  return s || (c = c.replace(/\sviewBox\s*=\s*(?:"[^"]*"|'[^']*')/gi, "").replace(/<svg\b/i, `<svg viewBox="0 0 ${n} ${r}"`)), c = c.replace(/<svg\b/i, '<svg preserveAspectRatio="xMidYMid meet"'), { markup: t.replace(a[0], c), width: n, height: r };
}
function Bc(t) {
  try {
    if (t.querySelector("[filter],[mask]")) return;
    const n = t.getBBox(), r = t.viewBox.baseVal;
    if (!n.width || !n.height || !r.width || !r.height) return;
    const i = Math.max(1, ...Array.from(t.querySelectorAll("path,line,polyline,polygon,circle,ellipse,rect,text")).map((d) => parseFloat(getComputedStyle(d).strokeWidth) || 0)), a = Math.max(3, ...Array.from(t.querySelectorAll("marker")).map((d) => Math.max(parseFloat(d.getAttribute("markerWidth") || "3"), parseFloat(d.getAttribute("markerHeight") || "3")))), l = Math.max(24, Math.max(n.width, n.height) * 0.04, i * a), s = n.width + l * 2, c = n.height + l * 2;
    if (s >= r.width * 0.65 && c >= r.height * 0.65 || n.x < r.x - 1 || n.y < r.y - 1 || n.x + n.width > r.x + r.width + 1 || n.y + n.height > r.y + r.height + 1) return;
    const u = `${n.x - l} ${n.y - l} ${s} ${c}`;
    return t.setAttribute("viewBox", u), { width: s, height: c, viewBox: u };
  } catch {
    return;
  }
}
function di({ block: t, revisionBlock: n = t, revisionTopic: r, onRevisionSubmit: i, onRevisionAccepted: a, frameComponent: l = wn }) {
  const { fullscreen: s, toggle: c, exit: u } = oi(), d = Ke(() => Lc(t.source), [t.source]), p = Ke(() => Rc(d, t.width, t.height), [d, t.width, t.height]), [h, f] = k(), m = h?.key === p.markup ? h : p, b = h?.key === p.markup ? p.markup.replace(/(<svg\b[^>]*\bviewBox\s*=\s*)["'][^"']*["']/i, `$1"${h.viewBox}"`) : p.markup, g = Ke(() => ({ __html: b }), [b]), v = ci({ fullscreen: s, resetKey: p.markup });
  Y(() => {
    const N = v.element?.querySelector(".svg-raw-inner > svg");
    if (!N) return;
    let x = !0;
    const C = () => {
      if (!x) return;
      const L = Bc(N);
      L && f({ key: p.markup, ...L });
    }, z = requestAnimationFrame(C);
    return document.fonts?.ready.then(C), () => {
      x = !1, cancelAnimationFrame(z);
    };
  }, [v.element, p.markup]);
  const w = Ke(() => Pc(p.markup), [p.markup]), y = w.ok ? null : { ok: !1, reason: w.reason, message: "图表内容暂时无法显示", details: { visibleElementCount: w.visibleElementCount } };
  return /* @__PURE__ */ e(rr, { open: s, onExit: u, children: /* @__PURE__ */ e(
    l,
    {
      title: t.title,
      source: t.source,
      diagnostic: y,
      className: "svg-raw-content fp-responsive-svg",
      controls: /* @__PURE__ */ e(si, { onReset: v.reset, onZoomIn: () => v.zoomBy(1.2), onZoomOut: () => v.zoomBy(1 / 1.2), onMaximize: c, fullscreen: s }),
      revisionBlock: n,
      revisionTopic: r,
      onRevisionSubmit: i,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e("div", { ref: v.ref, ...v.bind, className: "svg-raw-viewport", style: { ...v.bind.style, "--canvas-aspect": `${m.width} / ${m.height}` }, children: /* @__PURE__ */ e("div", { className: "svg-raw-inner", style: { transform: `translate(${v.view.x}px,${v.view.y}px) scale(${v.view.zoom})`, transformOrigin: "0 0" }, dangerouslySetInnerHTML: g }) })
    }
  ) });
}
const Pi = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, Fi = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
}, jc = /\\[A-Za-z]+/;
function Oi(t) {
  const n = [];
  let r = 0, i = 0;
  for (let a = 0; a < t.length; a += 1) {
    const l = t[a];
    l === "(" && (r += 1), l === ")" && (r -= 1), l === "," && r === 0 && (n.push(t.slice(i, a).trim()), i = a + 1);
  }
  return n.push(t.slice(i).trim()), n;
}
function Ri(t, n, r) {
  return `(1/((${r})*sqrt(2*pi)))*exp(-(((${t})-(${n}))^2)/(2*(${r})^2))`;
}
function Wa(t, n = {}) {
  const r = String(n.mu ?? 0), i = String(n.sigma ?? 1);
  let a = (t ?? "").trim().replace(/\u2212/g, "-").replace(/\bMath\./g, "").replace(/μ/g, r).replace(/σ/g, i);
  return a = a.replace(/\b(?:normal_pdf|gaussian)\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x", u = "0", d = "1"] = Oi(s);
    return Ri(c, u, d);
  }), a = a.replace(/\bphi\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x"] = Oi(s);
    return Ri(c, "0", "1");
  }), a;
}
function qc(t) {
  const n = Object.keys(Pi), r = Object.values(Pi), i = Object.keys(Fi), a = Object.values(Fi), l = t.replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), s = new Function(
    "x",
    ...n,
    ...i,
    `"use strict"; return (${l});`
  );
  return (c) => {
    const u = s(c, ...r, ...a);
    return typeof u == "number" ? u : NaN;
  };
}
function Kc(t, n = {}) {
  const r = Wa(t, n);
  if (!r)
    return {
      ok: !1,
      reason: "empty-fn",
      normalizedFn: r,
      message: "Function expression is empty."
    };
  if (jc.test(r))
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function plots do not accept LaTeX syntax. Use plain expressions such as normal_pdf(x,0,1)."
    };
  let i;
  try {
    i = qc(r);
  } catch {
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function expression could not be parsed."
    };
  }
  const a = n.xmin ?? -10, l = n.xmax ?? 10, s = Math.max(2, Math.floor(n.samples ?? 200)), c = (l - a) / (s - 1);
  let u = 0;
  for (let d = 0; d < s; d += 1)
    try {
      const p = i(a + d * c);
      Number.isFinite(p) && (u += 1);
    } catch {
      return {
        ok: !1,
        reason: "unsupported-syntax",
        normalizedFn: r,
        message: "Function expression failed while sampling."
      };
    }
  return u === 0 ? {
    ok: !1,
    reason: "no-finite-samples",
    normalizedFn: r,
    message: "Function expression produced no finite sample points."
  } : {
    ok: !0,
    normalizedFn: r,
    sampledPoints: u
  };
}
const Bi = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, ji = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
};
function ui(t) {
  const n = Wa(t).replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), r = Object.keys(Bi), i = Object.values(Bi), a = Object.keys(ji), l = Object.values(ji);
  try {
    const s = new Function(
      "x",
      ...r,
      ...a,
      `"use strict"; return (${n});`
    );
    return (c) => {
      try {
        const u = s(c, ...i, ...l);
        return typeof u == "number" ? u : NaN;
      } catch {
        return NaN;
      }
    };
  } catch {
    return () => NaN;
  }
}
function qi(t, n, r = 8) {
  const i = n - t;
  if (i <= 0 || !isFinite(i)) return [];
  const a = i / r, l = Math.pow(10, Math.floor(Math.log10(a))), s = a / l;
  let c;
  s <= 1.5 ? c = 1 * l : s <= 3.5 ? c = 2 * l : s <= 7.5 ? c = 5 * l : c = 10 * l;
  const u = Math.ceil(t / c) * c, d = [];
  for (let p = u; p <= n + c * 0.01; p += c) {
    const h = Math.round(p * 1e12) / 1e12;
    h >= t && h <= n && d.push({ value: h, label: Hc(h, c) });
  }
  return d;
}
function Hc(t, n) {
  if (t === 0) return "0";
  const r = Math.max(0, -Math.floor(Math.log10(n)));
  return t.toFixed(r).replace(/\.?0+$/, "");
}
function Uc(t, n, r, i, a, l, s, c) {
  const u = (r - n) / (i - 1), p = (c - s) * 2;
  let h = "", f = null, m = !1;
  for (let b = 0; b < i; b++) {
    const g = n + b * u, v = t(g);
    if (!isFinite(v) || isNaN(v)) {
      m = !1, f = null;
      continue;
    }
    const w = a(g), y = l(v);
    f !== null && Math.abs(v - f) > p && (m = !1), m ? h += `L${w.toFixed(2)},${y.toFixed(2)}` : (h += `M${w.toFixed(2)},${y.toFixed(2)}`, m = !0), f = v;
  }
  return h;
}
function _a(t, n, r, i = 200) {
  let a = 1 / 0, l = -1 / 0;
  const s = (r - n) / (i - 1);
  for (let u = 0; u < i; u++) {
    const d = n + u * s, p = t(d);
    isFinite(p) && (p < a && (a = p), p > l && (l = p));
  }
  if (!isFinite(a) || !isFinite(l)) return { yMin: -1, yMax: 1 };
  const c = (l - a) * 0.1 || 1;
  return { yMin: a - c, yMax: l + c };
}
const pr = [
  "var(--md-sys-color-primary)",
  "var(--md-sys-color-tertiary)",
  "var(--md-sys-color-error)",
  "var(--color-formula, #1976d2)",
  "var(--color-success, #2e7d32)",
  "var(--color-warning, #f57c00)"
];
function Wc(t, n) {
  return n ? pr.some((r) => r.includes(n)) ? `var(--md-sys-color-${n})` : n : pr[t % pr.length];
}
const ue = { top: 20, right: 20, bottom: 36, left: 48 };
function Va({
  width: t = 600,
  height: n = 400,
  xMin: r = -10,
  xMax: i = 10,
  yMin: a = -5,
  yMax: l = 5,
  showGrid: s = !0,
  showAxes: c = !0,
  axisLabels: u,
  pannable: d = !0,
  zoomable: p = !0,
  className: h,
  children: f
}) {
  const { fullscreen: m, toggle: b, exit: g } = oi(), v = ci({ fullscreen: m, pannable: d, zoomable: p }), { x: w, y, zoom: N } = v.view, x = t - ue.left - ue.right, C = n - ue.top - ue.bottom, z = i - r || 1e-6, L = l - a || 1e-6, j = qi(r, i), M = qi(a, l), A = (S) => ue.left + (S - r) / z * x, O = (S) => ue.top + (l - S) / L * C, U = A(0), T = O(0), E = 0 >= r && 0 <= i && 0 >= a && 0 <= l;
  return /* @__PURE__ */ e(rr, { open: m, onExit: g, children: /* @__PURE__ */ o("div", { className: `svg-canvas-wrapper fp-gesture-plot ${h ?? ""}`, children: [
    /* @__PURE__ */ o(
      "svg",
      {
        ref: v.ref,
        ...v.bind,
        viewBox: `0 0 ${t} ${n}`,
        width: t,
        height: n,
        children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e("clipPath", { id: "plot-area", children: /* @__PURE__ */ e(
            "rect",
            {
              x: ue.left,
              y: ue.top,
              width: x,
              height: C
            }
          ) }) }),
          /* @__PURE__ */ o(
            "g",
            {
              transform: `translate(${w}, ${y}) scale(${N})`,
              children: [
                s && /* @__PURE__ */ o("g", { className: "svg-canvas-grid", clipPath: "url(#plot-area)", children: [
                  j.map((S) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: A(S.value),
                      y1: ue.top,
                      x2: A(S.value),
                      y2: ue.top + C
                    },
                    `gx-${S.value}`
                  )),
                  M.map((S) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: ue.left,
                      y1: O(S.value),
                      x2: ue.left + x,
                      y2: O(S.value)
                    },
                    `gy-${S.value}`
                  ))
                ] }),
                c && /* @__PURE__ */ o("g", { className: "svg-canvas-axis", children: [
                  E || a <= 0 ? /* @__PURE__ */ o(ee, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: ue.left,
                        y1: E ? T : ue.top + C,
                        x2: ue.left + x,
                        y2: E ? T : ue.top + C
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${ue.left + x},${E ? T : ue.top + C} ${ue.left + x - 6},${(E ? T : ue.top + C) - 3} ${ue.left + x - 6},${(E ? T : ue.top + C) + 3}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  E || r <= 0 ? /* @__PURE__ */ o(ee, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: E ? U : ue.left,
                        y1: ue.top,
                        x2: E ? U : ue.left,
                        y2: ue.top + C
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${E ? U : ue.left},${ue.top} ${(E ? U : ue.left) - 3},${ue.top + 6} ${(E ? U : ue.left) + 3},${ue.top + 6}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  j.map(
                    (S) => S.value === 0 && E ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: A(S.value),
                          y1: (E ? T : ue.top + C) - 3,
                          x2: A(S.value),
                          y2: (E ? T : ue.top + C) + 3
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: A(S.value),
                          y: (E ? T : ue.top + C) + 16,
                          textAnchor: "middle",
                          children: S.label
                        }
                      )
                    ] }, `xt-${S.value}`)
                  ),
                  M.map(
                    (S) => S.value === 0 && E ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: (E ? U : ue.left) - 3,
                          y1: O(S.value),
                          x2: (E ? U : ue.left) + 3,
                          y2: O(S.value)
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: (E ? U : ue.left) - 8,
                          y: O(S.value) + 4,
                          textAnchor: "end",
                          children: S.label
                        }
                      )
                    ] }, `yt-${S.value}`)
                  ),
                  u?.x && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: ue.left + x - 4,
                      y: (E ? T : ue.top + C) + 32,
                      textAnchor: "end",
                      children: u.x
                    }
                  ),
                  u?.y && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: (E ? U : ue.left) + 12,
                      y: ue.top + 4,
                      textAnchor: "start",
                      children: u.y
                    }
                  ),
                  E && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-tick",
                      x: U - 8,
                      y: T + 16,
                      textAnchor: "end",
                      fill: "var(--md-sys-color-on-surface-variant)",
                      fontSize: "10",
                      fontFamily: "var(--font-mono)",
                      children: "O"
                    }
                  )
                ] }),
                /* @__PURE__ */ e("g", { clipPath: "url(#plot-area)", children: f })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e(
      si,
      {
        onReset: d || p ? v.reset : void 0,
        onZoomIn: p ? () => v.zoomBy(1.2) : void 0,
        onZoomOut: p ? () => v.zoomBy(1 / 1.2) : void 0,
        onMaximize: b,
        fullscreen: m
      }
    )
  ] }) });
}
function Ga({
  fn: t,
  xMin: n,
  xMax: r,
  yMin: i,
  yMax: a,
  plotLeft: l,
  plotTop: s,
  plotWidth: c,
  plotHeight: u,
  color: d,
  colorIndex: p = 0,
  label: h,
  strokeWidth: f = 2,
  samples: m = 500
}) {
  const b = Ke(
    () => Kc(t, { xmin: n, xmax: r, samples: m }),
    [t, m, r, n]
  ), g = b.normalizedFn, v = Ke(
    () => ui(g),
    [g]
  ), w = (C) => l + (C - n) / (r - n) * c, y = (C) => s + (a - C) / (a - i) * u, N = Ke(
    () => b.ok ? Uc(
      v,
      n,
      r,
      m,
      w,
      y,
      i,
      a
    ) : "",
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      b.ok,
      g,
      n,
      r,
      i,
      a,
      l,
      s,
      c,
      u,
      m
    ]
  ), x = Wc(p, d);
  return !b.ok || !N.trim() ? /* @__PURE__ */ e(
    "g",
    {
      "data-testid": "plot-diagnostic",
      "aria-label": b.ok ? "empty plot path" : b.message,
      children: /* @__PURE__ */ e(
        "text",
        {
          x: l + 8,
          y: s + 20,
          fontSize: 12,
          fill: "var(--md-sys-color-error)",
          children: b.ok ? "No drawable curve points." : b.message
        }
      )
    }
  ) : /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e(
      "path",
      {
        d: N,
        className: "svg-canvas-curve",
        stroke: x,
        strokeWidth: f
      }
    ),
    h && /* @__PURE__ */ e("title", { children: h })
  ] });
}
const It = { top: 20, right: 20, bottom: 36, left: 48 };
function _c({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: i
}) {
  const a = t.width ?? 600, l = t.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = _a(ui(t.fn), s, c), d = t.attrs.ymin ?? u.yMin, p = t.attrs.ymax ?? u.yMax, h = a - It.left - It.right, f = l - It.top - It.bottom;
  return /* @__PURE__ */ e(
    wn,
    {
      title: t.title,
      source: t.fn,
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: i,
      children: /* @__PURE__ */ e(
        Va,
        {
          width: a,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: /* @__PURE__ */ e(
            Ga,
            {
              fn: t.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: It.left,
              plotTop: It.top,
              plotWidth: h,
              plotHeight: f,
              color: t.attrs.color,
              label: t.attrs.label,
              samples: t.attrs.samples
            }
          )
        }
      )
    }
  );
}
const Dt = { top: 20, right: 20, bottom: 36, left: 48 };
function Vc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: i
}) {
  const a = t.width ?? t.attrs.width ?? 600, l = t.height ?? t.attrs.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = t.plots.reduce(
    (m, b) => {
      const g = _a(ui(b.fn), s, c);
      return {
        yMin: Math.min(m.yMin, g.yMin),
        yMax: Math.max(m.yMax, g.yMax)
      };
    },
    { yMin: 1 / 0, yMax: -1 / 0 }
  ), d = t.attrs.ymin ?? (Number.isFinite(u.yMin) ? u.yMin : -5), p = t.attrs.ymax ?? (Number.isFinite(u.yMax) ? u.yMax : 5), h = a - Dt.left - Dt.right, f = l - Dt.top - Dt.bottom;
  return /* @__PURE__ */ e(
    wn,
    {
      title: t.title,
      source: JSON.stringify(t.plots, null, 2),
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: i,
      children: /* @__PURE__ */ e(
        Va,
        {
          width: a,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: t.plots.map((m, b) => /* @__PURE__ */ e(
            Ga,
            {
              fn: m.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: Dt.left,
              plotTop: Dt.top,
              plotWidth: h,
              plotHeight: f,
              color: m.color,
              colorIndex: b,
              label: m.label,
              samples: m.samples
            },
            `${m.fn}-${b}`
          ))
        }
      )
    }
  );
}
const Ya = yn(null);
function Gc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: i
}) {
  const a = Wt(Ya), [l, s] = k({ key: "", svg: "", error: "" });
  Y(() => {
    if (!a) return;
    const u = new AbortController();
    return s({ key: t.source, svg: "", error: "" }), a(t.source, {
      width: t.width || 380,
      height: t.height || 300,
      signal: u.signal
    }).then((d) => {
      u.signal.aborted || s({ key: t.source, svg: d, error: "" });
    }).catch(() => {
      u.signal.aborted || s({
        key: t.source,
        svg: "",
        error: "分子结构暂时无法显示，请检查后重试。"
      });
    }), () => u.abort();
  }, [a, t.source, t.width, t.height]);
  const c = { revisionTopic: n, onRevisionSubmit: r, onRevisionAccepted: i };
  return l.key === t.source && l.svg ? /* @__PURE__ */ e(
    di,
    {
      ...c,
      block: { ...t, kind: "raw-svg", source: l.svg }
    }
  ) : /* @__PURE__ */ e(
    wn,
    {
      ...c,
      title: t.title || "分子结构",
      source: t.source,
      revisionBlock: t,
      children: /* @__PURE__ */ e("p", { role: "status", children: l.error || (a ? "正在绘制分子结构…" : "选择分子结构，查看对应内容。") })
    }
  );
}
function Yc(t, n) {
  const r = n.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 60) || "demo", i = new Blob([t], { type: "text/html;charset=utf-8" }), a = URL.createObjectURL(i), l = document.createElement("a");
  l.href = a, l.download = `${r}.html`, document.body.appendChild(l), l.click(), l.remove(), setTimeout(() => URL.revokeObjectURL(a), 1e3);
}
function Xc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: i
}) {
  const { fullscreen: a, toggle: l, exit: s } = oi(), c = t.title || "互动内容", u = t.height ?? 360, d = De(() => {
    const f = URL.createObjectURL(
      new Blob([t.source], { type: "text/html" })
    );
    window.open(f, "_blank", "noopener"), setTimeout(() => URL.revokeObjectURL(f), 6e4);
  }, [t.source]), p = De(
    () => Yc(t.source, c),
    [t.source, c]
  ), h = /* @__PURE__ */ e(
    si,
    {
      onDownload: p,
      onOpenExternal: d,
      onMaximize: l,
      fullscreen: a
    }
  );
  return /* @__PURE__ */ e(rr, { open: a, onExit: s, children: /* @__PURE__ */ e(
    wn,
    {
      title: t.title,
      source: t.source,
      controls: h,
      className: "html-canvas-layer",
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: i,
      children: /* @__PURE__ */ e(
        "iframe",
        {
          title: c,
          srcDoc: `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none';">${t.source}`,
          sandbox: "allow-scripts",
          referrerPolicy: "no-referrer",
          className: "html-canvas-frame",
          style: { height: a ? "100%" : u }
        }
      )
    }
  ) });
}
function Ir({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: i
}) {
  switch (t.kind) {
    case "raw-svg":
      return /* @__PURE__ */ e(
        di,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: i
        }
      );
    case "plot":
      return /* @__PURE__ */ e(
        _c,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: i
        }
      );
    case "multi-plot":
      return /* @__PURE__ */ e(
        Vc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: i
        }
      );
    case "molecule":
      return /* @__PURE__ */ e(
        Gc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: i
        }
      );
    case "html":
      return /* @__PURE__ */ e(
        Xc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: i
        }
      );
  }
}
const Qc = /^<svg\b[\s\S]*<\/svg>$/i, Jc = /<(?:g|path|rect|circle|ellipse|line|polyline|polygon|text|tspan|textPath|defs|marker|stop|linearGradient|radialGradient|clipPath|mask|pattern|image|use|symbol)\b[\s\S]*>/i;
function st(t) {
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function He(t) {
  if (t === "" || t === null || t === void 0) return;
  const n = Number(t);
  return Number.isFinite(n) ? n : void 0;
}
function jn(t) {
  if (t === !0 || t === "true") return !0;
  if (t === !1 || t === "false") return !1;
}
function Zc(t) {
  return {
    title: st(t.title),
    width: He(t.width),
    height: He(t.height)
  };
}
function ed(t, n, r) {
  const i = String(t ?? "").trim();
  if (!i) return "";
  if (Qc.test(i) || !Jc.test(i)) return i;
  const a = Number.isFinite(n) && n && n > 0 ? Math.round(n) : 600, l = Number.isFinite(r) && r && r > 0 ? Math.round(r) : 360;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${a} ${l}" width="${a}" height="${l}">${i}</svg>`;
}
function Xa(t) {
  return {
    xmin: He(t.xmin),
    xmax: He(t.xmax),
    ymin: He(t.ymin),
    ymax: He(t.ymax),
    label: st(t.label),
    xlabel: st(t.xlabel),
    ylabel: st(t.ylabel),
    color: st(t.color),
    samples: He(t.samples),
    grid: jn(t.grid),
    axes: jn(t.axes)
  };
}
function td(t) {
  return {
    xmin: He(t.xmin),
    xmax: He(t.xmax),
    ymin: He(t.ymin),
    ymax: He(t.ymax),
    xlabel: st(t.xlabel),
    ylabel: st(t.ylabel),
    width: He(t.width),
    height: He(t.height),
    grid: jn(t.grid),
    axes: jn(t.axes)
  };
}
function nd(t, n) {
  const r = st(t.mode)?.toLowerCase() ?? "raw", i = (n ?? "").trim(), a = Zc(t);
  return r === "molecule" ? {
    ...a,
    kind: "molecule",
    source: i
  } : r === "math" ? {
    ...a,
    kind: "plot",
    fn: st(t.fn) ?? i,
    attrs: Xa(t)
  } : r === "html" ? {
    ...a,
    kind: "html",
    source: i
  } : {
    ...a,
    kind: "raw-svg",
    source: ed(i, a.width, a.height)
  };
}
const Qa = hs(fs), ir = [
  { value: "javascript", label: "JavaScript" },
  { value: "typescript", label: "TypeScript" },
  { value: "python", label: "Python" },
  { value: "bash", label: "Bash" },
  { value: "json", label: "JSON" },
  { value: "html", label: "HTML" },
  { value: "css", label: "CSS" },
  { value: "markdown", label: "Markdown" },
  { value: "xml", label: "XML" },
  { value: "yaml", label: "YAML" },
  { value: "mermaid", label: "Mermaid" },
  { value: "cpp", label: "C++" },
  { value: "java", label: "Java" },
  { value: "c", label: "C" },
  { value: "csharp", label: "C#" },
  { value: "go", label: "Go" },
  { value: "rust", label: "Rust" },
  { value: "sql", label: "SQL" }
];
function hr() {
  return null;
}
function rd(t) {
  if (!t || typeof t != "object") return hr();
  const r = t.attrs?.language;
  if (typeof r != "string") return hr();
  const i = r.trim();
  return i || hr();
}
const Ja = 4;
function Za(t, n, r, i = !1, a = Ja) {
  const l = " ".repeat(a);
  if (n === r && !i) return [{ from: n, to: r, text: l }];
  const s = t.slice(0, n).lastIndexOf(`
`) + 1, c = r > n && t[r - 1] === `
` ? r - 1 : r, u = [];
  for (let d = s; d <= c; ) {
    const p = t[d] === "	" ? 1 : t.slice(d).match(/^ */)?.[0].length || 0;
    i ? p && u.push({ from: d, to: d + Math.min(p, a), text: "" }) : u.push({ from: d, to: d, text: l });
    const h = t.indexOf(`
`, d);
    if (h < 0) break;
    d = h + 1;
  }
  return u;
}
function qn(t, n) {
  let r = 0;
  for (const i of n) {
    if (t < i.from) break;
    if (t <= i.to) return i.from + r + i.text.length;
    r += i.text.length - (i.to - i.from);
  }
  return t + r;
}
function Kn(t, n = !1) {
  if (!t.isEditable || t.isDestroyed || t.view.composing) return !1;
  const { selection: r } = t.state;
  if (!(r instanceof rt) || !r.$from.sameParent(r.$to) || r.$from.parent.type.name !== "codeBlock") return !1;
  const i = r.$from.start(), a = Za(r.$from.parent.textContent, r.from - i, r.to - i, n);
  return t.commands.command(({ tr: l }) => {
    for (const s of [...a].reverse()) l.insertText(s.text, i + s.from, i + s.to);
    return l.setSelection(rt.create(
      l.doc,
      i + qn(r.anchor - i, a),
      i + qn(r.head - i, a)
    )), a.length && l.scrollIntoView(), !0;
  });
}
function el(t, n, r) {
  const i = t.slice(0, n).lastIndexOf(`
`) + 1, a = t.slice(i, n), l = a.match(/^[\t ]*/)?.[0] || "";
  return n === r && r === t.length && a && a === l ? { from: i, to: r, text: `
` } : { from: n, to: r, text: `
${l}` };
}
function id(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!(n instanceof rt) || !n.$from.sameParent(n.$to) || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.start(), i = el(n.$from.parent.textContent, n.from - r, n.to - r);
  return t.commands.command(({ tr: a }) => (a.insertText(i.text, r + i.from, r + i.to), a.setSelection(rt.create(a.doc, r + i.from + i.text.length)).scrollIntoView(), !0));
}
function ad(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parentOffset, i = n.$from.parent.textContent.slice(0, r), a = i.slice(i.lastIndexOf(`
`) + 1);
  if (!a || !/^[\t ]+$/.test(a)) return !1;
  const l = a.endsWith("	") ? 1 : Math.min(a.match(/ +$/)?.[0].length || 0, (a.length - 1) % Ja + 1);
  return t.commands.deleteRange({ from: n.from - l, to: n.from });
}
function ld(t, n) {
  const r = t.currentTarget;
  if (r.readOnly || r.disabled || t.nativeEvent.isComposing || t.ctrlKey || t.metaKey || t.altKey) return !1;
  const { value: i, selectionStart: a, selectionEnd: l, selectionDirection: s } = r, c = t.key === "Tab" ? Za(i, a, l, t.shiftKey) : t.key === "Enter" && !t.shiftKey ? [el(i, a, l)] : null;
  if (!c) return !1;
  if (t.preventDefault(), !c.length) return !0;
  let u = i;
  for (const b of [...c].reverse()) u = u.slice(0, b.from) + b.text + u.slice(b.to);
  const d = c[0].from, p = c.at(-1).to, h = u.slice(d, u.length - (i.length - p)), f = t.key === "Enter" ? d + c[0].text.length : qn(a, c), m = t.key === "Enter" ? f : qn(l, c);
  return r.setSelectionRange(d, p), document.execCommand?.("insertText", !1, h) || n(u), r.setSelectionRange(f, m, s), requestAnimationFrame(() => {
    document.activeElement === r && r.value === u && r.setSelectionRange(f, m, s);
  }), !0;
}
const tl = {
  stopEvent: ({ event: t }) => !!(t.target instanceof Element ? t.target : t.target instanceof globalThis.Node ? t.target.parentElement : null)?.closest("[data-nested-editor-boundary]")
}, fn = { "(": ")", "[": "]", "{": "}", "<": ">", '"': '"', "'": "'", "`": "`" }, od = new Set(Object.values(fn));
function nl(t, n, r) {
  let i = "", a = !1, l = !1;
  const s = /^(python|py|bash|sh|shell|ruby|rb|yaml|yml|r)$/i.test(r);
  for (let c = 0; c < n; c++) {
    const u = t[c], d = t[c + 1];
    if (a) {
      u === `
` && (a = !1);
      continue;
    }
    if (l) {
      u === "*" && d === "/" && (l = !1, c++);
      continue;
    }
    if (i) {
      u === "\\" ? c++ : u === i && (i = "");
      continue;
    }
    u === "/" && d === "/" ? (a = !0, c++) : u === "/" && d === "*" ? (l = !0, c++) : s && u === "#" ? a = !0 : "\"'`".includes(u) && (i = u);
  }
  return { quote: i, comment: a || l };
}
function sd(t, n, r) {
  const i = t.slice(0, n), a = i.slice(i.lastIndexOf(`
`) + 1);
  return /^(html|xml|vue|svelte|jsx|tsx)$/i.test(r) || /^\s*$/.test(a) || /^\s*#\s*include\s*$/.test(a) ? !0 : /^(c|cpp|c\+\+|java|rust|rs|csharp|cs|typescript|ts)$/i.test(r) && /[\w>:]$/.test(i);
}
function rl(t, n, r, i, a = "") {
  if (i.length !== 1) return null;
  const l = Math.min(n, r), s = Math.max(n, r), c = nl(t, l, a);
  if (c.comment) return null;
  const u = i === '"' || i === "'" || i === "`";
  if ((t.slice(0, l).match(/\\+$/)?.[0].length ?? 0) % 2 === 1) return null;
  if (l === s && t[l] === i && od.has(i) && (u ? c.quote === i : !c.quote))
    return { from: l, to: s, text: "", anchor: l + 1, head: l + 1 };
  const p = fn[i];
  return !p || c.quote || i === "<" && !sd(t, l, a) || u && i === "'" && /[\p{L}\p{N}_]/u.test(t[l - 1] ?? "") || l === s && t[s] && !/[\s)\]}>;,.:]/.test(t[s]) ? null : { from: l, to: s, text: i + t.slice(l, s) + p, anchor: n + 1, head: r + 1 };
}
function cd(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, i = n.$from.parentOffset, a = r[i - 1];
  return !fn[a] || fn[a] !== r[i] || !rl(r.slice(0, i - 1) + r.slice(i + 1), i - 1, i - 1, a, String(n.$from.parent.attrs.language || "")) ? !1 : t.commands.deleteRange({ from: n.from - 1, to: n.from + 1 });
}
function dd(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, i = n.$from.parentOffset;
  if (!"([{".includes(r[i - 1] || " ") || fn[r[i - 1]] !== r[i]) return !1;
  const a = nl(r, i, String(n.$from.parent.attrs.language || ""));
  if (a.quote || a.comment) return !1;
  const l = r.slice(0, i), s = l.slice(l.lastIndexOf(`
`) + 1).match(/^[\t ]*/)?.[0] || "";
  return t.commands.command(({ tr: c }) => (c.insertText(`
` + s + `    
` + s, n.from), c.setSelection(rt.create(c.doc, n.from + s.length + 5)).scrollIntoView(), !0));
}
function ud(t) {
  return new Yt({ props: { handleTextInput(n, r, i, a) {
    if (!t.isEditable || n.composing) return !1;
    const l = n.state.selection;
    if (!(l instanceof rt) || !l.$from.sameParent(l.$to) || l.$from.parent.type.name !== "codeBlock" || r !== l.from || i !== l.to) return !1;
    const s = l.$from.start(), c = rl(l.$from.parent.textContent, l.anchor - s, l.head - s, a, String(l.$from.parent.attrs.language || ""));
    if (!c) return !1;
    const u = n.state.tr;
    return c.text && u.insertText(c.text, s + c.from, s + c.to), u.setSelection(rt.create(u.doc, s + c.anchor, s + c.head)).scrollIntoView(), n.dispatch(u), !0;
  } } });
}
const mn = new Zr("codeFence"), il = /^[a-zA-Z][a-zA-Z0-9_+#.-]*$/;
function pd(t) {
  return new ls({
    find: /^```$/,
    handler: ({ state: n, range: r }) => {
      const i = n.doc.resolve(r.from);
      if (!i.node(-1).canReplaceWith(i.index(-1), i.indexAfter(-1), t)) return null;
      const a = n.tr.delete(r.from, r.to).setBlockType(r.from, r.from, t);
      a.setMeta(mn, a.selection.$from.before());
    }
  });
}
function hd() {
  return new Yt({
    key: mn,
    state: {
      init: () => null,
      apply(t, n) {
        const r = t.getMeta(mn);
        if (r !== void 0) return r;
        if (n === null || t.selectionSet && !t.docChanged) return null;
        const i = t.mapping.map(n, -1), a = t.doc.nodeAt(i), { selection: l } = t;
        return a?.type.name !== "codeBlock" || a.attrs.language || !l.empty || l.$from.start() !== i + 1 || l.$from.parentOffset !== a.content.size || a.textContent && !il.test(a.textContent) ? null : i;
      }
    }
  });
}
function Ki(t) {
  const n = mn.getState(t.state);
  if (n == null || !t.isEditable || t.view.composing) return !1;
  const r = t.state.doc.nodeAt(n);
  return r?.type.name !== "codeBlock" || r.textContent && !il.test(r.textContent) ? !1 : t.commands.command(({ tr: i }) => {
    const a = r.textContent || null;
    return i.delete(n + 1, n + r.nodeSize - 1), i.setNodeMarkup(n, void 0, { ...r.attrs, language: a }), i.setSelection(rt.create(i.doc, n + 1)).setMeta(mn, null), !0;
  });
}
const Hi = [
  { value: "flow", label: "流程图", code: `flowchart LR
  A[开始] --> B{理解}
  B --> C[应用]` },
  { value: "sequence", label: "时序图", code: `sequenceDiagram
  participant U as 用户
  participant S as 服务
  U->>S: 请求
  S-->>U: 响应` },
  { value: "state", label: "状态图", code: `stateDiagram-v2
  [*] --> 待办
  待办 --> 进行中
  进行中 --> 完成` }
];
function al({ code: t }) {
  const n = ve().replace(/[^a-zA-Z0-9]/g, ""), r = R(0), [i, a] = k(""), [l, s] = k(""), [c, u] = k("");
  return Y(() => {
    const d = () => u(`${document.documentElement.dataset.theme}/${document.documentElement.dataset.product}`);
    d();
    const p = new MutationObserver(d);
    return p.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product"] }), () => p.disconnect();
  }, []), Y(() => {
    const d = ++r.current, p = setTimeout(async () => {
      try {
        const { default: h } = await import("mermaid"), f = getComputedStyle(document.documentElement);
        h.initialize({ startOnLoad: !1, securityLevel: "strict", suppressErrorRendering: !0, theme: "base", themeVariables: { fontFamily: "system-ui, sans-serif", primaryColor: f.getPropertyValue("--fp-primary-soft").trim() || "#fff2e2", primaryTextColor: f.getPropertyValue("--fp-ink").trim() || "#202124", primaryBorderColor: f.getPropertyValue("--fp-line-strong").trim() || "#b9a68e", lineColor: f.getPropertyValue("--fp-muted").trim() || "#757575" } });
        const m = await h.render(`fp-mermaid-${n}-${d}`, t);
        r.current === d && (a(m.svg), s(""));
      } catch {
        r.current === d && s("图表语法有误，请检查连线、括号和节点名称。");
      }
    }, 250);
    return () => {
      clearTimeout(p), r.current++;
    };
  }, [t, n, c]), /* @__PURE__ */ e("div", { className: "fp-mermaid-preview", "aria-label": "图表预览", children: /* @__PURE__ */ e(ge, { children: l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : i ? /* @__PURE__ */ e("div", { dangerouslySetInnerHTML: { __html: i } }) : /* @__PURE__ */ e("p", { role: "status", children: "正在绘制图表…" }) }) });
}
function fd({ node: t, editor: n, getPos: r, deleteNode: i, selected: a }) {
  const l = String(t.attrs.language).toLowerCase() === "mermaid", [s, c] = k(!1), [u, d] = k(!1), p = R(null), h = R(null), f = R(!1);
  Y(() => {
    s ? p.current?.focus({ preventScroll: !0 }) : f.current && h.current?.focus({ preventScroll: !0 }), f.current = s;
  }, [s]);
  const m = t.textContent, [b, g] = k(m);
  Y(() => {
    g(m);
  }, [m]);
  const v = () => {
    ti.getState(n.state)?.undoManager.stopCapturing(), n.view.dispatch(ei(n.state.tr));
  }, w = (N) => {
    const x = r();
    x === void 0 || n.isDestroyed || !n.isEditable || (g(N), n.commands.command(({ tr: C }) => {
      const z = C.doc.nodeAt(x);
      return z ? (C.replaceWith(x + 1, x + z.nodeSize - 1, N ? n.schema.text(N) : []), !0) : !1;
    }));
  }, y = () => {
    const N = r();
    if (N === void 0 || !n.isEditable) return !1;
    const x = n.state.doc.nodeAt(N);
    if (x?.type.name !== "codeBlock") return !1;
    const { $from: C, $to: z } = n.state.selection;
    return (!C.sameParent(z) || C.start() !== N + 1) && n.commands.setTextSelection({ from: N + 1, to: N + x.nodeSize - 1 }), n.commands.focus(void 0, { scrollIntoView: !1 }), !0;
  };
  return /* @__PURE__ */ o(Ft, { className: l ? "fp-mermaid-node" : "fp-code-node", "data-selected": a || void 0, "data-note-object": l ? "diagram" : void 0, children: [
    l && /* @__PURE__ */ e("pre", { hidden: !0, "aria-hidden": "true", children: /* @__PURE__ */ e(Si, {}) }),
    l ? /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", children: [
      /* @__PURE__ */ o("header", { className: "fp-code-header", children: [
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e(Ur, { size: 14 }),
          "Mermaid 图表"
        ] }),
        /* @__PURE__ */ o("div", { children: [
          n.isEditable && /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ o("button", { ref: h, type: "button", "aria-label": s ? "完成图表编辑" : "编辑图表", "aria-expanded": s, onClick: () => {
              v(), c((N) => !N);
            }, children: [
              s ? /* @__PURE__ */ e(Ie, { size: 14 }) : /* @__PURE__ */ e(Yn, { size: 14 }),
              s ? "完成" : "编辑"
            ] }),
            /* @__PURE__ */ o("button", { type: "button", "aria-label": "删除图表", onClick: () => {
              v(), i(), n.commands.focus();
            }, children: [
              /* @__PURE__ */ e(Gt, { size: 14 }),
              "删除"
            ] })
          ] }),
          /* @__PURE__ */ e("button", { type: "button", "aria-pressed": u, onClick: () => d((N) => !N), children: "源码" })
        ] })
      ] }),
      /* @__PURE__ */ e(je, { isOpen: s, children: /* @__PURE__ */ o("div", { className: "fp-mermaid-source", children: [
        /* @__PURE__ */ e(Ce, { label: "图表模板", value: "", placeholder: "插入模板", options: Hi, onChange: (N) => {
          const x = Hi.find((C) => C.value === N);
          x && w(x.code);
        } }),
        /* @__PURE__ */ e("textarea", { ref: p, readOnly: !n.isEditable, "aria-label": "Mermaid 源码", value: b, spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", onChange: (N) => w(N.target.value), onKeyDown: (N) => {
          N.stopPropagation(), !N.nativeEvent.isComposing && (ld(N, w) || (N.key === "Escape" || N.key === "Enter" && (N.ctrlKey || N.metaKey)) && (N.preventDefault(), c(!1)));
        } })
      ] }) }),
      /* @__PURE__ */ e(je, { isOpen: !s && u, children: /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: m }) }) }),
      /* @__PURE__ */ e(al, { code: m })
    ] }) : /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", className: "fp-code-header", children: [
        /* @__PURE__ */ e(Ce, { label: "代码块语言", value: t.attrs.language || "", disabled: !n.isEditable, options: [{ value: "", label: "纯文本" }, ...ir], onChange: (N) => {
          const x = r();
          x !== void 0 && n.commands.command(({ tr: C }) => (C.setNodeMarkup(x, void 0, { ...t.attrs, language: N || null }), !0));
        } }),
        n.isEditable && /* @__PURE__ */ o("div", { className: "fp-code-actions", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩进", "data-fp-tooltip": "缩进 · Tab", "aria-keyshortcuts": "Tab", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            y() && Kn(n);
          }, children: /* @__PURE__ */ e(Ql, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "减少缩进", "data-fp-tooltip": "减少缩进 · Shift+Tab", "aria-keyshortcuts": "Shift+Tab", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            y() && Kn(n, !0);
          }, children: /* @__PURE__ */ e(Jl, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "在代码块下方继续", "data-fp-tooltip": "在代码块下方继续 · Ctrl/⌘+Enter", "aria-keyshortcuts": "Control+Enter Meta+Enter", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            y() && n.commands.exitCode();
          }, children: /* @__PURE__ */ e(pa, { size: 16 }) })
        ] })
      ] }),
      /* @__PURE__ */ e("pre", { spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", children: /* @__PURE__ */ e("code", { children: /* @__PURE__ */ e(Si, { style: { whiteSpace: "pre" } }) }) })
    ] })
  ] });
}
const md = $a.extend({
  priority: 110,
  addNodeView() {
    return nn(fd, tl);
  },
  addInputRules() {
    return [pd(this.type), ...this.parent?.() || []];
  },
  addProseMirrorPlugins() {
    return [...this.parent?.() || [], hd(), ud(this.editor)];
  },
  addKeyboardShortcuts() {
    const t = this.parent?.() || {};
    return {
      ...t,
      Tab: () => Kn(this.editor),
      "Shift-Tab": () => Kn(this.editor, !0),
      Space: () => Ki(this.editor),
      Enter: (n) => this.editor.isEditable && !this.editor.view.composing && (Ki(this.editor) || dd(this.editor) || t.Enter?.(n) || id(this.editor)),
      Backspace: (n) => this.editor.isEditable && !this.editor.view.composing && (cd(this.editor) || ad(this.editor) || t.Backspace?.(n) || !1),
      "Mod-Enter": () => this.editor.isEditable && this.editor.isActive(this.name) && this.editor.commands.exitCode(),
      Escape: () => {
        const { editor: n } = this;
        if (!n.isEditable || n.state.selection.$from.parent.type.name !== this.name) return !1;
        const r = n.view.nodeDOM(n.state.selection.$from.before()), i = r instanceof Element ? r.querySelector(".fp-code-header button:not(:disabled)") : null;
        return i ? (i.focus({ preventScroll: !0 }), !0) : !1;
      }
    };
  }
}).configure({ lowlight: Qa }), bd = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
];
new Set(bd);
const gd = {
  animation: "learninganimation",
  map: "historymap",
  "cause-effect": "causeeffect",
  "learning-animation": "learninganimation",
  intuition: "insight",
  technique: "tip",
  comparison: "compare",
  summary: "keypoint",
  question: "note",
  task: "note"
};
function yd(t) {
  return gd[t] ?? t;
}
const vd = {
  definition: { label: "定义", cls: "callout-definition" },
  theorem: { label: "定理", cls: "callout-theorem" },
  example: { label: "例", cls: "callout-example" },
  insight: { label: "直觉", cls: "callout-insight" },
  pitfall: { label: "易错点", cls: "callout-pitfall" },
  note: { label: "注", cls: "callout-note" },
  tip: { label: "提示", cls: "callout-tip" },
  memory: { label: "记忆卡", cls: "callout-memory" }
}, Hn = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function wd(t) {
  const n = t.toLowerCase();
  return n in Hn ? Hn[n] ?? "note" : "note";
}
function kd(t) {
  const n = t.toLowerCase();
  return n in Hn && Hn[n] === null;
}
function Nd({ label: t = "核心要点", children: n }) {
  return /* @__PURE__ */ o("aside", { className: "fp-keypoint", children: [
    /* @__PURE__ */ e("span", { className: "fp-keypoint-label", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-keypoint-body", children: n })
  ] });
}
function xd({
  term: t,
  children: n,
  defaultOpen: r = !1
}) {
  const [i, a] = k(r), l = ve();
  return /* @__PURE__ */ o("section", { className: "fp-concept", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-concept-head",
        "aria-expanded": i,
        "aria-controls": l,
        onClick: () => a((s) => !s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-concept-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(et, { size: 16 }) }),
          /* @__PURE__ */ e("span", { className: "fp-concept-term", children: t }),
          /* @__PURE__ */ e("span", { className: "fp-concept-hint", children: i ? "点击收起" : "点击展开" }),
          /* @__PURE__ */ e(Ae, { size: 16, className: "fp-concept-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: l, className: "fp-concept-body", inert: !i, "aria-hidden": !i, "data-open": i || void 0, children: /* @__PURE__ */ e("div", { className: "fp-concept-clip", children: /* @__PURE__ */ e("div", { className: "fp-concept-inner", children: n }) }) })
  ] });
}
function Cd({ title: t, children: n }) {
  return /* @__PURE__ */ o("section", { className: "fp-compare", children: [
    t && /* @__PURE__ */ e("header", { className: "fp-compare-title", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-compare-body", children: n })
  ] });
}
const Sd = {
  cause: "因",
  effect: "影响",
  result: "结果"
};
function Md(t) {
  return t.split(`
`).map((n) => n.trim().replace(/^[-*]\s*/, "")).filter(Boolean).map((n) => /^(因|原因)[：:]/.test(n) ? { kind: "cause", text: n.replace(/^(因|原因)[：:]/, "").trim() } : /^(果|结果)[：:]/.test(n) ? { kind: "result", text: n.replace(/^(果|结果)[：:]/, "").trim() } : /^(影响|后果)[：:]/.test(n) ? { kind: "effect", text: n.replace(/^(影响|后果)[：:]/, "").trim() } : { kind: void 0, text: n });
}
function Ed({ items: t, text: n, children: r }) {
  const i = t ?? (n ? Md(n) : []);
  return /* @__PURE__ */ o("div", { className: "fp-cause-effect", children: [
    i.map((a, l) => {
      const s = a.kind ?? (l === 0 ? "cause" : "effect");
      return /* @__PURE__ */ o("div", { className: "fp-cause-node", "data-kind": s, children: [
        /* @__PURE__ */ e("span", { className: "fp-cause-label", children: Sd[s] }),
        /* @__PURE__ */ e("div", { className: "fp-cause-text", children: a.text }),
        l < i.length - 1 && /* @__PURE__ */ e(ha, { size: 16, className: "fp-cause-arrow", "aria-hidden": "true" })
      ] }, l);
    }),
    r
  ] });
}
function $d({
  label: t = "推导过程",
  children: n,
  defaultOpen: r = !1
}) {
  const [i, a] = k(r), l = ve();
  return /* @__PURE__ */ o("section", { className: "fp-derivation", "data-open": i || void 0, children: [
    /* @__PURE__ */ o("button", { type: "button", className: "fp-derivation-trigger", "aria-expanded": i, "aria-controls": l, onClick: () => a((s) => !s), children: [
      /* @__PURE__ */ e(Ae, { size: 15, className: "fp-derivation-chevron" }),
      t
    ] }),
    /* @__PURE__ */ e(je, { isOpen: i, children: /* @__PURE__ */ e("div", { id: l, className: "fp-derivation-body", children: n }) })
  ] });
}
function Dr({ src: t, alt: n, title: r, onError: i, ...a }) {
  const [l, s] = k(void 0), c = l === t || !t ? /* @__PURE__ */ o("span", { className: "fp-content-image-error", role: "img", "aria-label": n || "图片", children: [
    /* @__PURE__ */ e(Zl, { size: 22, "aria-hidden": "true" }),
    /* @__PURE__ */ e("span", { children: n || "图片加载失败" })
  ] }) : /* @__PURE__ */ e(
    "img",
    {
      src: t,
      alt: n || "",
      title: r,
      loading: "lazy",
      decoding: "async",
      ...a,
      onError: (u) => {
        s(t), i?.(u);
      }
    }
  );
  return r ? /* @__PURE__ */ o("figure", { className: "fp-content-image", children: [
    c,
    /* @__PURE__ */ e("figcaption", { children: r })
  ] }) : /* @__PURE__ */ e("span", { className: "fp-content-image-plain", children: c });
}
function Ui({
  title: t,
  date: n,
  children: r,
  defaultOpen: i = !1,
  fields: a = []
}) {
  const [l, s] = k(i);
  return /* @__PURE__ */ o("article", { className: "fp-event-card", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": l,
        onClick: () => s((c) => !c),
        children: [
          /* @__PURE__ */ e(
            Ae,
            {
              size: 16,
              style: { transform: l ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: t }),
            n && /* @__PURE__ */ e("time", { children: n })
          ] })
        ]
      }
    ),
    !!a.length && /* @__PURE__ */ e("dl", { className: "fp-event-fields", children: a.map((c) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: c.label }),
      /* @__PURE__ */ e("dd", { children: c.value })
    ] }, c.label)) }),
    /* @__PURE__ */ e(je, { isOpen: l, children: /* @__PURE__ */ e("div", { className: "fp-reading-body", children: r }) })
  ] });
}
function zd({
  src: t,
  alt: n,
  caption: r,
  credit: i,
  onOpen: a
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-reading-figure", children: [
    a ? /* @__PURE__ */ e("button", { type: "button", "aria-label": `查看${n}`, onClick: a, children: /* @__PURE__ */ e(Dr, { src: t, alt: n }) }) : /* @__PURE__ */ e(Dr, { src: t, alt: n }),
    (r || i) && /* @__PURE__ */ o("figcaption", { children: [
      r,
      i && /* @__PURE__ */ e("small", { children: i })
    ] })
  ] });
}
function Yh({
  question: t,
  answer: n,
  revealed: r,
  onReveal: i,
  onGrade: a
}) {
  return /* @__PURE__ */ o("article", { className: "fp-memory-card", children: [
    /* @__PURE__ */ e("div", { children: t }),
    /* @__PURE__ */ e(je, { isOpen: r, children: /* @__PURE__ */ e("div", { className: "fp-memory-answer", children: n }) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r ? a && ["again", "hard", "good", "easy"].map((l, s) => /* @__PURE__ */ e("button", { type: "button", onClick: () => a(l), children: ["再学一次", "有些困难", "已经掌握", "很轻松"][s] }, l)) : /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "查看答案" }) })
  ] });
}
function Xh({
  events: t,
  selectedId: n,
  onSelect: r
}) {
  return /* @__PURE__ */ e("section", { className: "fp-history-map", "aria-label": "历史脉络", children: /* @__PURE__ */ e("ol", { children: t.map((i) => /* @__PURE__ */ o("li", { "data-active": n === i.id || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": n === i.id,
        onClick: () => r(i.id),
        children: [
          /* @__PURE__ */ e("time", { children: i.date }),
          /* @__PURE__ */ e("strong", { children: i.title })
        ]
      }
    ),
    /* @__PURE__ */ e(je, { isOpen: n === i.id, children: /* @__PURE__ */ o("div", { className: "fp-reading-body", children: [
      i.description,
      i.relatedIds?.map((a) => {
        const l = t.find((s) => s.id === a);
        return l ? /* @__PURE__ */ o("button", { type: "button", onClick: () => r(a), children: [
          "关联：",
          l.title
        ] }, a) : null;
      })
    ] }) })
  ] }, i.id)) }) });
}
function Ad({
  title: t,
  children: n,
  sourceUrl: r,
  caption: i
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-learning-animation", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      r && /* @__PURE__ */ o("a", { href: r, download: !0, children: [
        "下载源文件",
        /* @__PURE__ */ e(Vt, { size: 13 })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { children: n }),
    i && /* @__PURE__ */ e("figcaption", { children: i })
  ] });
}
function Qh({
  title: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-note-link", onClick: r, children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e(Vt, { size: 15 })
  ] });
}
function Jh({
  leftLabel: t,
  rightLabel: n,
  leftCount: r,
  rightCount: i,
  intersection: a,
  total: l
}) {
  return /* @__PURE__ */ e(
    "figure",
    {
      className: "fp-venn",
      "aria-label": `${t} ${r}，${n} ${i}，交集 ${a}${l === void 0 ? "" : `，总数 ${l}`}`,
      children: /* @__PURE__ */ o("svg", { viewBox: "0 0 360 210", role: "img", children: [
        /* @__PURE__ */ e("title", { children: "集合关系" }),
        /* @__PURE__ */ e(
          "rect",
          {
            x: "8",
            y: "8",
            width: "344",
            height: "194",
            rx: "8",
            fill: "none",
            stroke: "var(--fp-line)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "139",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "221",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            fillOpacity: ".65",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e("text", { x: "112", y: "70", textAnchor: "middle", children: t }),
        /* @__PURE__ */ e("text", { x: "249", y: "70", textAnchor: "middle", children: n }),
        /* @__PURE__ */ e("text", { x: "112", y: "120", textAnchor: "middle", children: Math.max(0, r - a) }),
        /* @__PURE__ */ e("text", { x: "180", y: "120", textAnchor: "middle", children: a }),
        /* @__PURE__ */ e("text", { x: "249", y: "120", textAnchor: "middle", children: Math.max(0, i - a) }),
        l !== void 0 && /* @__PURE__ */ e("text", { x: "325", y: "184", textAnchor: "end", children: Math.max(0, l - r - i + a) })
      ] })
    }
  );
}
function Ld({
  children: t,
  mode: n = "cloze"
}) {
  const [r, i] = k([]), a = (l, s = "root") => Vl.map(l, (c, u) => {
    const d = `${s}.${u}`;
    if (!sa(c)) return c;
    const p = c;
    return n === "cloze" && p.type === "strong" || n !== "cloze" && p.type === "li" ? /* @__PURE__ */ e("span", { className: "fp-recall-item", children: /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-expanded": r.includes(d),
        onClick: () => i(
          (f) => f.includes(d) ? f.filter((m) => m !== d) : [...f, d]
        ),
        children: r.includes(d) ? p.props.children : "点击回忆"
      }
    ) }) : ca(p, {}, a(p.props.children, d));
  });
  return /* @__PURE__ */ e("div", { className: "fp-recall-content", children: a(t) });
}
function Id({
  title: t = "历史地图",
  points: n,
  caption: r,
  onSelect: i
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-location-map", children: [
    /* @__PURE__ */ e("figcaption", { children: t }),
    /* @__PURE__ */ e("div", { children: n.map((a, l) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        style: {
          left: `${Math.max(0, Math.min(100, a.x))}%`,
          top: `${Math.max(0, Math.min(100, a.y))}%`
        },
        onClick: () => i?.(a),
        children: [
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "●" }),
          a.name
        ]
      },
      l
    )) }),
    r && /* @__PURE__ */ e("p", { children: r })
  ] });
}
function Dd({
  title: t = "时间轴",
  children: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-reading-timeline", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    n
  ] });
}
function Td({
  title: t,
  kind: n,
  collapsed: r,
  children: i
}) {
  const [a, l] = k(!r);
  return /* @__PURE__ */ o("aside", { className: "fp-reader-callout", "data-kind": n, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-reader-callout-toggle",
        "aria-expanded": a,
        onClick: () => l(!a),
        children: [
          /* @__PURE__ */ e(
            St,
            {
              size: 16,
              style: { transform: a ? void 0 : "rotate(-90deg)" }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t })
        ]
      }
    ),
    /* @__PURE__ */ e(je, { isOpen: a, children: i })
  ] });
}
function Pd() {
  return (t) => {
    hn(t, (n) => {
      const r = n;
      if (!["containerDirective", "leafDirective", "textDirective"].includes(
        r.type
      ))
        return;
      const i = { ...r.attributes }, a = (l) => (l || []).map(
        (s) => s.value || a(s.children)
      ).join(`
`);
      r.name === "canvas" && r.children && (i.plots = JSON.stringify(
        r.children.filter((l) => l.name === "plot").map((l) => l.attributes || {})
      )), r.data = {
        ...r.data,
        hName: "fp-directive",
        hProperties: {
          "data-name": r.name,
          "data-attributes": JSON.stringify({
            ...i,
            __source: a(r.children)
          })
        }
      };
    });
  };
}
const Fd = (t) => /^\s*(?:javascript|vbscript|data):/i.test(t) ? "" : t;
function Nt({
  markdown: t,
  resolveResourceUrl: n,
  renderDirective: r,
  onOpenResource: i,
  onOpenLink: a,
  components: l,
  remarkPlugins: s,
  rehypePlugins: c
}) {
  const u = (h) => Fd(n?.(h) ?? h), d = ({
    name: h,
    attributes: f,
    children: m,
    source: b
  }) => {
    const g = yd(h), v = f.title || f.label || vd[g]?.label || "学习内容";
    if (r) {
      const w = r({
        name: g,
        attributes: f,
        children: m,
        source: b
      });
      if (w !== void 0) return w;
    }
    if (g === "interactive" && f.id)
      return /* @__PURE__ */ e(Ua, { id: f.id });
    if (["plot", "functionplot"].includes(g))
      return /* @__PURE__ */ e(
        Ir,
        {
          block: {
            kind: "plot",
            title: f.title || f.label,
            fn: f.fn || b || "x",
            attrs: Xa(f)
          }
        }
      );
    if (["canvas", "svgcanvas", "svg"].includes(g)) {
      let w = [];
      try {
        w = JSON.parse(f.plots || "[]");
      } catch {
      }
      return /* @__PURE__ */ e(
        Ir,
        {
          block: w.length ? {
            kind: "multi-plot",
            title: f.title,
            attrs: td(f),
            plots: w
          } : nd(f, b || "")
        }
      );
    }
    return ["concept", "conceptcard"].includes(g) ? /* @__PURE__ */ e(xd, { term: f.term || v, children: m }) : g === "derivation" ? /* @__PURE__ */ e($d, { label: v, children: m }) : g === "keypoint" ? /* @__PURE__ */ e(Nd, { label: v, children: m }) : ["compare", "comparetable"].includes(g) ? /* @__PURE__ */ e(Cd, { title: v, children: m }) : g === "causeeffect" ? /* @__PURE__ */ e(Ed, { children: m }) : ["event", "eventcard"].includes(g) ? /* @__PURE__ */ e(
      Ui,
      {
        title: v,
        date: f.date || f.year,
        fields: [
          ["location", "地点"],
          ["people", "人物"],
          ["result", "结果"],
          ["impact", "影响"]
        ].filter(([w]) => !!f[w]).map(([w, y]) => ({ label: y, value: f[w] })),
        children: m
      }
    ) : ["figure", "figuremedia"].includes(g) && f.src ? /* @__PURE__ */ e(
      zd,
      {
        src: u(f.src),
        alt: f.alt || v,
        caption: f.caption,
        credit: f.credit
      }
    ) : ["memory", "memorycard"].includes(g) ? /* @__PURE__ */ e(Ui, { title: v, children: /* @__PURE__ */ e(Ld, { mode: f.mode || "checklist", children: m }) }) : g === "timeline" ? /* @__PURE__ */ e(
      Dd,
      {
        title: f.period ? `时间轴 · ${f.period}` : v,
        children: m
      }
    ) : g === "historymap" ? /* @__PURE__ */ e(
      Id,
      {
        title: v,
        caption: f.caption,
        points: (f.points || "").split(",").filter(Boolean).map((w) => {
          const [y, N, x] = w.split(":");
          return {
            name: y,
            x: Number.isFinite(Number(N)) ? Number(N) : 50,
            y: Number.isFinite(Number(x)) ? Number(x) : 50
          };
        })
      }
    ) : ["learninganimation", "learning-animation"].includes(g) ? /* @__PURE__ */ e(
      Ad,
      {
        title: v,
        sourceUrl: f.source ? u(f.source) : void 0,
        caption: f.caption,
        children: f.src ? /* @__PURE__ */ e(on, { src: u(f.src), title: v }) : m
      }
    ) : g === "mediaembed" && f.src ? /audio/i.test(f.type || "") ? /* @__PURE__ */ e(Fn, { src: u(f.src), title: v }) : /* @__PURE__ */ e(on, { src: u(f.src), title: v }) : g === "video" && f.src ? /* @__PURE__ */ e(on, { src: u(f.src), title: v }) : g === "audio" && f.src ? /* @__PURE__ */ e(Fn, { src: u(f.src), title: v }) : [
      "interactive",
      "plot",
      "functionplot",
      "canvas",
      "svgcanvas",
      "svg",
      "attachment",
      "noteattachment",
      "learning-animation"
    ].includes(g) && i ? /* @__PURE__ */ o("section", { className: "fp-reader-resource", children: [
      /* @__PURE__ */ e("strong", { children: v }),
      m,
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => i(f, g),
          children: "打开内容"
        }
      )
    ] }) : /* @__PURE__ */ e(
      Td,
      {
        title: v,
        kind: g === "callout" ? f.kind || "note" : g,
        collapsed: f.collapsed === "true",
        children: m
      }
    );
  };
  return /* @__PURE__ */ e("article", { className: "fp-markdown-content", children: /* @__PURE__ */ e(
    Ca,
    {
      remarkPlugins: s || [
        os,
        Sa,
        ss,
        Js,
        Pd
      ],
      rehypePlugins: c || [
        cs,
        fc,
        [ds, hc],
        Qs,
        [
          Ma,
          { throwOnError: !1, strict: !1, macros: Ha }
        ],
        mc
      ],
      components: { ...{
        "fp-directive": ({
          node: h,
          children: f
        }) => {
          const m = h?.properties || {};
          let b = {};
          try {
            b = JSON.parse(
              String(
                m["data-attributes"] || m.dataAttributes || "{}"
              )
            );
          } catch {
          }
          const g = b.__source;
          return delete b.__source, d({
            name: String(m["data-name"] || m.dataName || "note"),
            attributes: b,
            children: f,
            source: g
          });
        },
        img: ({ src: h, alt: f }) => u(h || "") ? /* @__PURE__ */ e(Dr, { src: u(h || ""), alt: f || "" }) : /* @__PURE__ */ e("span", { children: f || "图片暂时无法显示。" }),
        a: ({ href: h, children: f }) => /* @__PURE__ */ e(
          "a",
          {
            href: h,
            onClick: (m) => {
              h && a && !m.ctrlKey && !m.metaKey && !m.shiftKey && (m.preventDefault(), a(h));
            },
            children: f
          }
        ),
        pre: ({ children: h }) => /* @__PURE__ */ e("div", { className: "fp-reader-code", children: h }),
        code: ({
          className: h,
          children: f
        }) => h?.includes("language-mermaid") ? /* @__PURE__ */ e(al, { code: String(f).trimEnd() }) : /* @__PURE__ */ e("code", { className: h, children: f })
      }, ...l },
      children: pc(t)
    }
  ) });
}
function Tr(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const { state: r } = t, i = r.selection.$from.index(0), a = [];
  r.doc.forEach((p, h) => a.push(h));
  const l = i + (n === "up" ? -1 : 1);
  if (l < 0 || l >= r.doc.childCount) return !1;
  const s = r.doc.child(i), c = a[i], u = r.doc.child(l), d = n === "up" ? a[l] : a[l] + u.nodeSize - s.nodeSize;
  return t.commands.command(({ tr: p }) => (p.delete(c, c + s.nodeSize), p.insert(d, s), p.setSelection(
    Pn.near(
      p.doc.resolve(Math.min(p.doc.content.size, d + 1))
    )
  ), !0));
}
function Od(t) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const n = t.state.selection.$from.index(0);
  let r = 0;
  for (let i = 0; i < n; i++)
    r += t.state.doc.child(i).nodeSize;
  return t.commands.deleteRange({
    from: r,
    to: r + t.state.doc.child(n).nodeSize
  });
}
const Rd = tr.create({
  name: "blockDragHandles",
  addProseMirrorPlugins() {
    const t = this.editor;
    return [
      new Yt({
        props: {
          decorations(n) {
            if (!t.isEditable) return Mr.empty;
            const r = [];
            return n.doc.forEach((i, a) => {
              Rt.isSelectable(i) && r.push(
                za.widget(
                  a,
                  (l, s) => {
                    const c = document.createElement("span");
                    c.className = "fp-block-handle", c.contentEditable = "false";
                    const u = document.createElement("button");
                    return u.type = "button", u.draggable = !0, u.tabIndex = 0, u.title = "拖动段落", u.setAttribute("aria-label", "拖动段落"), u.textContent = "⠿", u.addEventListener("dragstart", (d) => {
                      const p = s();
                      if (p === void 0 || !d.dataTransfer) return;
                      d.stopPropagation();
                      const h = Rt.create(
                        l.state.doc,
                        p
                      );
                      l.dispatch(l.state.tr.setSelection(h));
                      const f = h.content(), m = document.createElement("div");
                      m.append(
                        ms.fromSchema(
                          l.state.schema
                        ).serializeFragment(f.content)
                      ), d.dataTransfer.clearData(), d.dataTransfer.setData(
                        "text/html",
                        m.innerHTML
                      ), d.dataTransfer.setData(
                        "text/plain",
                        h.node.textContent
                      ), d.dataTransfer.effectAllowed = "copyMove", l.dragging = {
                        slice: f,
                        move: !d.ctrlKey && !d.altKey
                      };
                    }), u.addEventListener("keydown", (d) => {
                      if (!d.altKey || !["ArrowUp", "ArrowDown"].includes(d.key))
                        return;
                      const p = s();
                      p !== void 0 && (d.preventDefault(), d.stopPropagation(), t.commands.setTextSelection(
                        Math.min(p + 1, l.state.doc.content.size)
                      ), Tr(
                        t,
                        d.key === "ArrowUp" ? "up" : "down"
                      ));
                    }), u.addEventListener("mousedown", (d) => {
                      const p = s();
                      p === void 0 || d.button !== 0 || (d.stopPropagation(), l.dispatch(
                        l.state.tr.setSelection(
                          Rt.create(l.state.doc, p)
                        )
                      ), l.focus());
                    }), c.append(u), c;
                  },
                  { side: -1, key: `block-${a}` }
                )
              );
            }), Mr.create(n.doc, r);
          }
        }
      })
    ];
  }
});
function ll(t) {
  return t.chain().focus().insertContent({ type: "codeBlock", attrs: { language: "mermaid" }, content: [{ type: "text", text: `flowchart LR
  A[开始] --> B[理解] --> C[应用]` }] }).run();
}
function bn(...t) {
  const n = t.join(" "), r = vs(n, { toneType: "none", type: "array" });
  return `${n} ${r.join("")} ${r.map((i) => i[0]).join("")}`.toLowerCase();
}
const Bd = [
  ["text", "文本", "普通段落", "paragraph wenben wb"],
  ["h1", "一级标题", "大标题", "heading title yijibiaoti yjbt"],
  ["h2", "二级标题", "章节标题", "heading erjibiaoti ejbt"],
  ["h3", "三级标题", "小节标题", "heading sanjibiaoti sjbt"],
  ["h4", "四级标题", "细分内容", "heading sijibiaoti sjbt"],
  ["h5", "五级标题", "细分内容", "heading wujibiaoti wjbt"],
  ["h6", "六级标题", "细分内容", "heading liujibiaoti ljbt"],
  ["bullet", "无序列表", "项目列表", "list unordered wuxuliebiao wxlb"],
  ["ordered", "有序列表", "编号列表", "list numbered youxuliebiao yxlb"],
  ["quote", "引用", "引用段落", "blockquote yinyong yy"],
  ["code", "代码块", "代码内容", "codeblock daima dm dmk"],
  ["divider", "分隔线", "划分内容", "horizontal rule fengexian fgx"],
  ["table", "表格", "3 × 3", "biaoge bg"],
  ["inlineMath", "行内公式", "在段落中输入公式", "formula equation gongshi gs latex hangneigongshi hngs"],
  ["math", "独立公式", "独立成行的公式", "blockmath equation duligongshi dlgs"],
  ["card", "卡片", "说明与重点", "callout kapian kp"],
  ["mermaid", "Mermaid 图表", "流程图与时序图", "diagram flowchart liuchengtu lct tuxing tx"],
  ["interactive", "交互实验", "插入可探索的实验", "experiment lab jiaohushiyan jhsy hudong hd"],
  ["attachment", "附件", "图片、视频或 PDF", "file image pdf audio upload 图片 音频 文件 上传 fujian fj tupian tp"],
  ["video", "视频", "边看边记", "movie shipin sp"]
], jd = { javascript: "js node nodejs", typescript: "ts", python: "py", bash: "sh shell terminal 终端", cpp: "c++ cc cxx", csharp: "c# cs", rust: "rs", yaml: "yml", markdown: "md" }, ol = [
  ["definition", "定义", "明确概念", "概念定义 dy"],
  ["theorem", "定理", "记录条件与结论", "定律 dl"],
  ["example", "例题", "题目与解答", "例子 示例 lt"],
  ["tip", "技巧", "记录解题方法", "提示 jq"],
  ["pitfall", "易错点", "记录常见错误", "warning 注意 ycd"],
  ["memory", "记忆卡", "整理记忆要点", "记忆 flashcard jyk"],
  ["derivation", "推导", "分步说明推导", "推导过程 td"],
  ["compare", "对比", "比较概念与方法", "比较 comparison db"],
  ["keypoint", "核心要点", "突出重要内容", "重点 key hxyd"],
  ["concept", "概念", "整理概念边界", "术语 gn"],
  ["insight", "直觉", "解释直观理解", "理解 intuition zj"],
  ["note", "说明", "补充说明", "备注 callout sm"],
  ["cause-effect", "因果", "梳理原因与结果", "因果关系 cause effect yg"]
].map(([t, n, r, i]) => ["card:" + t, n + "卡片", r, t + " " + i]), sl = [
  ...Bd,
  ...ir.filter((t) => t.value !== "mermaid").map((t) => [
    "code:" + t.value,
    t.label + " 代码块",
    "输入 " + t.label + " 代码",
    t.value + " " + (jd[t.value] || "") + " code 代码"
  ]),
  ["code:plaintext", "纯文本代码块", "按原样记录文本", "text txt plaintext 纯文本"],
  ...ol
], qd = new Map(sl.map((t) => [t[0], bn(...t)]));
function Kd(t) {
  const n = t.trim().replace(/^\//, "").toLowerCase(), r = Pr(n);
  if (r) return [[`table:${r.rows}x${r.cols}`, `${r.rows} × ${r.cols} 表格`, `${r.rows} 行 × ${r.cols} 列`, n]];
  const i = n.split(/\s+/), a = sl.filter((d) => i.every((p) => qd.get(d[0]).includes(p))), l = (d) => [d[0], d[0].split(":").at(-1), ...d[3].toLowerCase().split(/\s+/)].includes(n), s = n ? a.filter(l) : [], c = s.length ? s : a, u = qa();
  return c.sort((d, p) => Number(l(p)) - Number(l(d)) || (u[p[0]] || 0) - (u[d[0]] || 0));
}
function Wi(t) {
  return t === "code:plaintext" ? null : ir.find((n) => t === "code:" + n.value)?.value;
}
function Mn(t) {
  return ol.find((n) => n[0] === t)?.[0].slice(5);
}
function Pr(t) {
  const n = t.trim().toLowerCase().replace(/^\//, "").match(/^(?:bg|table:?)([1-9]\d?)[x*×]([1-9]\d?)$/);
  if (!n) return;
  const r = Number(n[1]), i = Number(n[2]);
  return r <= 20 && i <= 20 ? { rows: r, cols: i } : void 0;
}
function xt({
  children: t,
  items: n,
  label: r = "快捷操作",
  disabled: i,
  tabIndex: a = 0,
  onOpen: l
}) {
  const s = R(null), c = R(null), u = R(null), [d, p] = k(null), [h, f] = k([]), m = ve(), b = Xt(s, !!d), g = (y = !0) => {
    p(null), f([]), y && u.current?.focus({ preventScroll: !0 });
  }, v = (y, N) => {
    u.current = document.activeElement, f([]), p({ x: y, y: N });
  };
  xe(() => {
    if (!d || !c.current) return;
    const y = c.current.getBoundingClientRect();
    c.current.style.left = `${Math.max(8, Math.min(d.x, window.innerWidth - y.width - 8))}px`, c.current.style.top = `${Math.max(8, Math.min(d.y, window.innerHeight - y.height - 8))}px`, c.current.querySelector('[role="menuitem"]:not(:disabled)')?.focus({ preventScroll: !0 });
  }, [d, h]), Y(() => {
    if (!d) return;
    const y = (C) => {
      c.current?.contains(C.target) || g(!1);
    }, N = (C) => {
      C.key === "Escape" && (C.preventDefault(), g());
    }, x = () => g(!1);
    return document.addEventListener("pointerdown", y, !0), document.addEventListener("keydown", N, !0), window.addEventListener("resize", x), window.addEventListener("blur", x), window.addEventListener("scroll", y, !0), () => {
      document.removeEventListener("pointerdown", y, !0), document.removeEventListener("keydown", N, !0), window.removeEventListener("resize", x), window.removeEventListener("blur", x), window.removeEventListener("scroll", y, !0);
    };
  }, [d]);
  let w = typeof n == "function" ? n() : n;
  for (const y of h)
    w = w.find((N) => N.id === y)?.children || [];
  return /* @__PURE__ */ o(
    "div",
    {
      ref: s,
      className: "fp-context-host",
      tabIndex: a,
      onContextMenu: (y) => {
        i || l?.(y) === !1 || (y.preventDefault(), y.stopPropagation(), v(y.clientX, y.clientY));
      },
      onKeyDown: (y) => {
        if (!i && (y.key === "ContextMenu" || y.shiftKey && y.key === "F10")) {
          if (l?.(y) === !1) return;
          y.preventDefault(), y.stopPropagation();
          const N = s.current.getBoundingClientRect();
          v(N.left + 16, N.top + 16);
        }
      },
      children: [
        t,
        d && Oe(
          /* @__PURE__ */ o(
            "div",
            {
              ref: c,
              "data-fp-overlay": "",
              id: m,
              role: "menu",
              "aria-label": r,
              className: "fp-popup-panel fp-popup-menu fp-context-menu",
              style: {
                ...b,
                position: "fixed",
                left: d.x,
                top: d.y,
                maxHeight: "calc(100vh - 16px)",
                overflowY: "auto"
              },
              onContextMenu: (y) => y.preventDefault(),
              onKeyDown: (y) => {
                const N = Array.from(
                  c.current?.querySelectorAll(
                    '[role="menuitem"]:not(:disabled)'
                  ) || []
                ), x = N.indexOf(
                  document.activeElement
                ), C = y.key === "ArrowDown" ? (x + 1) % N.length : y.key === "ArrowUp" ? (x - 1 + N.length) % N.length : y.key === "Home" ? 0 : y.key === "End" ? N.length - 1 : -1;
                if (C >= 0 && (y.preventDefault(), N[C]?.focus()), y.key === "ArrowLeft" && h.length && (y.preventDefault(), f(h.slice(0, -1))), y.key === "ArrowRight") {
                  const z = document.activeElement?.dataset.item, L = w.find((j) => j.id === z);
                  L?.children && (y.preventDefault(), f([...h, L.id]));
                }
                y.key === "Tab" && g(!1);
              },
              children: [
                h.length > 0 && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: () => f(h.slice(0, -1)),
                    children: "‹ 返回"
                  }
                ),
                w.map((y) => /* @__PURE__ */ o("div", { children: [
                  y.separator && /* @__PURE__ */ e("div", { role: "separator", className: "fp-context-separator" }),
                  /* @__PURE__ */ o(
                    "button",
                    {
                      type: "button",
                      role: "menuitem",
                      "data-item": y.id,
                      disabled: y.disabled,
                      "aria-haspopup": y.children ? "menu" : void 0,
                      className: y.danger ? "fp-error-text" : "",
                      onClick: () => {
                        y.children ? f([...h, y.id]) : (g(), y.onSelect?.());
                      },
                      children: [
                        /* @__PURE__ */ e("span", { className: "fp-context-icon", children: y.checked ? /* @__PURE__ */ e(Ie, { size: 15 }) : y.icon }),
                        /* @__PURE__ */ e("span", { children: y.label }),
                        y.children ? /* @__PURE__ */ e(Ae, { size: 14 }) : y.shortcut ? /* @__PURE__ */ e("kbd", { children: y.shortcut }) : null
                      ]
                    }
                  )
                ] }, y.id))
              ]
            }
          ),
          s.current?.closest("dialog") || document.body
        )
      ]
    }
  );
}
function cl({
  editor: t,
  children: n,
  getExtraItems: r
}) {
  const [i, a] = k(""), l = R(""), s = R(null), c = async (d) => {
    if (!t) return;
    const { from: p, to: h } = t.state.selection, f = t.state.doc;
    try {
      if (d === "paste") {
        const m = await navigator.clipboard.readText();
        if (!m) return;
        !t.isDestroyed && t.state.doc === f && t.chain().focus().insertContentAt({ from: p, to: h }, { type: "text", text: m }).run();
      } else {
        const { dom: m, text: b } = t.view.serializeForClipboard(t.state.selection.content());
        navigator.clipboard.write && typeof ClipboardItem < "u" ? await navigator.clipboard.write([new ClipboardItem({
          "text/html": new Blob([m.innerHTML], { type: "text/html" }),
          "text/plain": new Blob([b], { type: "text/plain" })
        })]) : await navigator.clipboard.writeText(b), d === "cut" && !t.isDestroyed && t.state.doc === f && t.chain().focus().deleteRange({ from: p, to: h }).run();
      }
      a(
        d === "paste" ? "已粘贴" : d === "cut" ? "已剪切" : "已复制"
      );
    } catch {
      a("暂时无法访问剪贴板，请使用键盘快捷键。");
    }
  };
  return /* @__PURE__ */ o(
    xt,
    {
      label: "笔记快捷操作",
      tabIndex: -1,
      disabled: !t,
      items: () => {
        if (!t) return [];
        const d = !t.isEditable, p = t.state.selection.empty;
        return [
          ...s.current ? r?.(s.current) ?? [] : [],
          {
            id: "cut",
            label: "剪切",
            shortcut: "Ctrl+X",
            disabled: d || p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("cut");
            }
          },
          {
            id: "copy",
            label: "复制",
            shortcut: "Ctrl+C",
            disabled: p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("copy");
            }
          },
          {
            id: "paste",
            label: "粘贴为纯文本",
            shortcut: "Ctrl+Shift+V",
            disabled: d || !navigator.clipboard?.readText,
            onSelect: () => {
              c("paste");
            }
          },
          {
            id: "all",
            label: "全选",
            shortcut: "Ctrl+A",
            onSelect: () => t.chain().focus().selectAll().run()
          },
          ...l.current ? [
            {
              id: "copy-link",
              label: "复制链接地址",
              disabled: !navigator.clipboard?.writeText,
              onSelect: () => {
                navigator.clipboard.writeText(l.current).then(
                  () => a("链接已复制"),
                  () => a("请使用键盘快捷键复制链接。")
                );
              }
            },
            {
              id: "unlink",
              label: "取消链接",
              disabled: d,
              onSelect: () => t.chain().focus().extendMarkRange("link").unsetLink().run()
            }
          ] : [],
          {
            id: "format",
            label: "文字格式",
            separator: !0,
            disabled: d,
            children: [
              {
                id: "bold",
                label: "粗体",
                checked: t.isActive("bold"),
                onSelect: () => t.chain().focus().toggleBold().run()
              },
              {
                id: "italic",
                label: "斜体",
                checked: t.isActive("italic"),
                onSelect: () => t.chain().focus().toggleItalic().run()
              },
              {
                id: "clear",
                label: "清除格式",
                onSelect: () => t.chain().focus().unsetAllMarks().run()
              }
            ]
          },
          {
            id: "block",
            label: "段落操作",
            disabled: d,
            children: [
              {
                id: "move-up",
                label: "向上移动",
                disabled: t.state.selection.$from.index(0) === 0,
                onSelect: () => Tr(t, "up")
              },
              {
                id: "move-down",
                label: "向下移动",
                disabled: t.state.selection.$from.index(0) >= t.state.doc.childCount - 1,
                onSelect: () => Tr(t, "down")
              },
              {
                id: "delete-block",
                label: "删除这一块",
                danger: !0,
                onSelect: () => Od(t)
              }
            ]
          },
          ...t.isActive("table") ? [
            {
              id: "table",
              label: "表格操作",
              disabled: d,
              children: [
                {
                  id: "row-before",
                  label: "向上插入行",
                  onSelect: () => t.chain().focus().addRowBefore().run()
                },
                {
                  id: "row-after",
                  label: "向下插入行",
                  onSelect: () => t.chain().focus().addRowAfter().run()
                },
                {
                  id: "column-before",
                  label: "向左插入列",
                  onSelect: () => t.chain().focus().addColumnBefore().run()
                },
                {
                  id: "column-after",
                  label: "向右插入列",
                  onSelect: () => t.chain().focus().addColumnAfter().run()
                },
                {
                  id: "merge",
                  label: "合并单元格",
                  disabled: !t.can().mergeCells(),
                  onSelect: () => t.chain().focus().mergeCells().run()
                },
                {
                  id: "split",
                  label: "拆分单元格",
                  disabled: !t.can().splitCell(),
                  onSelect: () => t.chain().focus().splitCell().run()
                },
                {
                  id: "delete-row",
                  label: "删除当前行",
                  danger: !0,
                  separator: !0,
                  onSelect: () => t.chain().focus().deleteRow().run()
                },
                {
                  id: "delete-column",
                  label: "删除当前列",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteColumn().run()
                },
                {
                  id: "delete-table",
                  label: "删除表格",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteTable().run()
                }
              ]
            }
          ] : [],
          {
            id: "undo",
            label: "撤销",
            separator: !0,
            shortcut: "Ctrl+Z",
            disabled: d || !t.can().undo(),
            onSelect: () => t.chain().focus().undo().run()
          },
          {
            id: "redo",
            label: "重做",
            shortcut: "Ctrl+Shift+Z",
            disabled: d || !t.can().redo(),
            onSelect: () => t.chain().focus().redo().run()
          }
        ];
      },
      onOpen: (d) => {
        if (!t) return !1;
        const p = d.target;
        if (p.closest("input,textarea,math-field,button")) return !1;
        if (s.current = p, l.current = p.closest("a")?.getAttribute("href") || "", "clientX" in d) {
          const h = t.view.posAtCoords({
            left: d.clientX,
            top: d.clientY
          }), f = p.closest("[data-note-object], .fp-mermaid-node");
          if (f && t.view.dom.contains(f) && t.isEditable) {
            const m = t.view.posAtDOM(f, 0), b = t.state.doc.nodeAt(m), g = b && (b.isAtom || b.type.name === "codeBlock") ? m : Math.max(0, m - 1);
            t.state.doc.nodeAt(g) && t.commands.setNodeSelection(g);
          } else h && (t.state.selection.empty || h.pos < t.state.selection.from || h.pos > t.state.selection.to) && t.commands.setTextSelection(h.pos);
        }
        a("");
      },
      children: [
        n,
        i && /* @__PURE__ */ e("span", { className: "fp-visually-hidden", role: "status", children: i })
      ]
    }
  );
}
const Un = yn(!1), Hd = '[data-fp-tooltip],button,[role="button"],a[title],a[aria-label],[tabindex][title]', _i = /* @__PURE__ */ new WeakSet();
function dl({ children: t }) {
  return Wt(Un) ? /* @__PURE__ */ e(ee, { children: t }) : /* @__PURE__ */ o(Un.Provider, { value: !0, children: [
    /* @__PURE__ */ e(ul, {}),
    t
  ] });
}
function ul({ owner: t }) {
  const [n, r] = k(null), i = R(null), a = R(null), l = ve(), s = Xt(i, !!n, n?.node), [c, u] = k({ left: 8, top: 8 });
  return Y(() => {
    let d = !1, p = !1;
    const h = () => r(null), f = (v) => {
      if ("pointerType" in v && (d = v.pointerType === "touch"), v.type === "focusin" && p || d) return;
      const w = v.target instanceof Element ? v.target : null, y = w?.closest(Hd);
      if (t && y?.dataset.fpTooltipOwner !== t) {
        h();
        return;
      }
      if (!t && y?.dataset.fpTooltipOwner) {
        h();
        return;
      }
      if (!y || y.closest('[inert],[aria-hidden="true"]') || y.dataset.fpTooltip === "off" || y.matches('[role="menuitem"],[role="option"],[aria-expanded="true"]')) {
        h();
        return;
      }
      if (_i.has(v)) {
        h();
        return;
      }
      _i.add(v);
      for (let C = w; C; C = C.parentElement) {
        const z = C.getAttribute("title");
        z && (C.dataset.fpTooltip ||= z, C.removeAttribute("title"));
      }
      const N = y.dataset.fpTooltip || y.getAttribute("aria-label") || y.textContent?.trim();
      if (!N) {
        h();
        return;
      }
      i.current = y;
      const x = y.dataset.fpTooltipSide || (y.closest('[data-variant="rail"]') ? "right" : "bottom");
      r((C) => C?.node === y && C.text === N ? C : { node: y, text: N, side: x });
    }, m = (v) => {
      const w = v.relatedTarget;
      (!(w instanceof Node) || !i.current?.contains(w)) && h();
    }, b = (v) => {
      d = !1, p = !1, v.key === "Escape" && h();
    }, g = (v) => {
      d = v.pointerType === "touch", p = !0, h();
    };
    return document.addEventListener("pointerover", f, !0), document.addEventListener("pointerout", m, !0), document.addEventListener("focusin", f, !0), document.addEventListener("focusout", h, !0), document.addEventListener("pointerdown", g, !0), document.addEventListener("keydown", b, !0), window.addEventListener("blur", h), window.addEventListener("scroll", h, !0), window.addEventListener("resize", h), () => {
      document.removeEventListener("pointerover", f, !0), document.removeEventListener("pointerout", m, !0), document.removeEventListener("focusin", f, !0), document.removeEventListener("focusout", h, !0), document.removeEventListener("pointerdown", g, !0), document.removeEventListener("keydown", b, !0), window.removeEventListener("blur", h), window.removeEventListener("scroll", h, !0), window.removeEventListener("resize", h);
    };
  }, [t]), xe(() => {
    if (!n || !a.current) return;
    const d = n.node, p = d.getAttribute("aria-describedby");
    d.setAttribute("aria-describedby", [p, l].filter(Boolean).join(" "));
    const h = d.getBoundingClientRect(), f = a.current.getBoundingClientRect(), m = 8, b = 8;
    let g = n.side;
    g === "bottom" && h.bottom + m + f.height > innerHeight - b && (g = "top"), g === "top" && h.top - m - f.height < b && (g = "bottom"), g === "right" && h.right + m + f.width > innerWidth - b && (g = "left"), g === "left" && h.left - m - f.width < b && (g = "right");
    const v = g === "left" ? h.left - m - f.width : g === "right" ? h.right + m : h.left + (h.width - f.width) / 2, w = g === "top" ? h.top - m - f.height : g === "bottom" ? h.bottom + m : h.top + (h.height - f.height) / 2;
    u({ left: Math.max(b, Math.min(v, innerWidth - f.width - b)), top: Math.max(b, Math.min(w, innerHeight - f.height - b)) });
    const y = new MutationObserver(() => {
      (!d.isConnected || d.closest('[inert],[aria-hidden="true"]') || d.getAttribute("aria-expanded") === "true") && r(null);
    });
    return y.observe(document.body, { childList: !0, subtree: !0, attributes: !0, attributeFilter: ["aria-expanded", "inert", "aria-hidden"] }), () => {
      y.disconnect(), p ? d.setAttribute("aria-describedby", p) : d.removeAttribute("aria-describedby");
    };
  }, [n, l]), n && typeof document < "u" ? Oe(/* @__PURE__ */ e("div", { ref: a, id: l, role: "tooltip", className: "fp-tooltip-bubble", style: { ...s, color: "var(--fp-surface)", ...c }, children: n.text }), document.body) : null;
}
function gn({ text: t, children: n, side: r = "bottom" }) {
  const i = Wt(Un), a = ve(), l = { "data-fp-tooltip": t, "data-fp-tooltip-side": r, "data-fp-tooltip-owner": i ? void 0 : a, title: void 0 }, s = sa(n) ? ca(n, l) : /* @__PURE__ */ e("span", { ...l, children: n });
  return i ? s : /* @__PURE__ */ o(Un.Provider, { value: !0, children: [
    /* @__PURE__ */ e(ul, { owner: a }),
    s
  ] });
}
function Ud({ tip: t, children: n }) {
  return /* @__PURE__ */ e(gn, { text: t, children: n });
}
const zn = ["bold", "italic", "strike", "code", "underline"];
function Wd(t) {
  const { from: n, to: r, empty: i } = t.state.selection;
  if (i || n >= r)
    return zn.filter((l) => t.isActive(l));
  const a = /* @__PURE__ */ new Set();
  return t.state.doc.nodesBetween(n, r, (l) => {
    if (l.isText)
      for (const s of l.marks)
        zn.includes(s.type.name) && a.add(s.type.name);
  }), zn.filter((l) => a.has(l));
}
function _d(t, n, r, i) {
  if (r >= i) return !1;
  const a = t.chain().focus().setTextSelection({ from: r, to: i });
  for (const l of zn)
    n.includes(l) ? a.setMark(l) : a.unsetMark(l);
  return a.run();
}
function Vd(t) {
  return t === null ? "once" : t === "once" ? "locked" : null;
}
function Gd({ language: t, onChange: n, className: r }) {
  return /* @__PURE__ */ e(Ce, { label: "代码块语言", className: r, value: t ?? "", onChange: (a) => n(a || null), options: [{ value: "", label: "无语言" }, ...ir] });
}
const Yd = [
  { label: "墨色", value: "#1f2937" },
  { label: "白", value: "#ffffff" },
  { label: "红", value: "#dc2626" },
  { label: "橙", value: "#ea580c" },
  { label: "黄", value: "#ca8a04" },
  { label: "绿", value: "#16a34a" },
  { label: "青", value: "#0891b2" },
  { label: "蓝", value: "#2563eb" },
  { label: "紫", value: "#7c3aed" },
  { label: "粉", value: "#db2777" }
], Xd = [
  "#000000",
  "#7f1d1d",
  "#9a3412",
  "#854d0e",
  "#166534",
  "#0e7490",
  "#1d4ed8",
  "#6d28d9",
  "#9d174d",
  "#525252"
], Qd = [
  "#fef08a",
  "#bbf7d0",
  "#a5f3fc",
  "#ddd6fe",
  "#fecdd3",
  "#fde68a",
  "#86efac",
  "#67e8f9",
  "#c4b5fd",
  "#fda4af"
], Jd = [
  "rgba(17,24,39,0.55)",
  "rgba(220,38,38,0.45)",
  "rgba(234,88,12,0.45)",
  "rgba(22,163,74,0.45)",
  "rgba(37,99,235,0.45)",
  "rgba(124,58,237,0.45)"
];
function Fr() {
  try {
    const t = localStorage.getItem("fp-toolbar-recent-colors"), n = t ? JSON.parse(t) : null;
    return Array.isArray(n) ? n.filter((r) => typeof r == "string").slice(0, 8) : [];
  } catch {
    return [];
  }
}
function Zd(t) {
  const n = [t, ...Fr().filter((r) => r !== t)].slice(0, 8);
  try {
    localStorage.setItem("fp-toolbar-recent-colors", JSON.stringify(n));
  } catch {
  }
}
function eu({
  mode: t,
  current: n,
  onApply: r,
  onClose: i
}) {
  const [a, l] = k([]), [s, c] = k(n?.startsWith("#") ? n : "#FD8B07"), u = R(null);
  Y(() => l(Fr()), []), Y(() => {
    const h = (m) => {
      u.current?.contains(m.target) || i();
    }, f = (m) => m.key === "Escape" && i();
    return window.addEventListener("pointerdown", h), window.addEventListener("keydown", f), () => {
      window.removeEventListener("pointerdown", h), window.removeEventListener("keydown", f);
    };
  }, [i]);
  const d = (h) => {
    h && Zd(h), l(Fr()), r(h), i();
  }, p = (h) => h.map((f) => {
    const m = typeof f == "string" ? f : f.value, b = typeof f == "string" ? m : f.label;
    return /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        title: b,
        "aria-label": b,
        className: "toolbar-color-swatch",
        style: { background: m },
        "data-active": n === m || void 0,
        onClick: () => d(m)
      },
      m
    );
  });
  return /* @__PURE__ */ o("div", { ref: u, className: "toolbar-color-picker", role: "listbox", "aria-label": t === "text" ? "字体颜色" : "荧光笔颜色", children: [
    a.length > 0 && /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "最近使用" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(a) })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: t === "text" ? "主题色" : "荧光笔" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(t === "text" ? Yd : Qd) })
    ] }),
    t === "text" && /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "标准色" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(Xd) })
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "半透明" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(Jd) })
      ] })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "自定义" }),
      /* @__PURE__ */ o("div", { className: "toolbar-color-custom", children: [
        /* @__PURE__ */ e(
          "input",
          {
            type: "text",
            "aria-label": "自定义颜色",
            value: s,
            placeholder: "#FD8B07",
            onChange: (h) => c(h.target.value)
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: !/^#[0-9a-f]{6}$/i.test(s), onClick: () => d(s), children: "应用" }),
        /* @__PURE__ */ e("button", { type: "button", onClick: () => d(t === "text" ? null : "#fef08a"), children: t === "text" ? "默认颜色" : "默认高亮" })
      ] })
    ] })
  ] });
}
function tu(t, n, r = (a) => a.width ?? 0, i = 4) {
  const a = new Set(t.map((s) => s.id)), l = () => t.reduce((s, c) => s + (a.has(c.id) ? r(c) : 0), 0) + Math.max(0, a.size - 1) * i;
  for (const s of [...t].sort((c, u) => c.priority - u.priority || t.indexOf(u) - t.indexOf(c))) {
    if (l() <= Math.max(0, n)) break;
    a.delete(s.id);
  }
  return { visible: t.filter((s) => a.has(s.id)), overflow: t.filter((s) => !a.has(s.id)) };
}
function nu(t, n, r, i = 40, a = 4) {
  let l = null;
  const s = (p, h, f, m) => {
    if (h > n) return;
    if (p === t.length) {
      (!l || f > l.score) && (l = { modes: { ...m }, score: f });
      return;
    }
    const b = t[p], g = b.actions?.length ?? 1;
    for (const v of ["full", "icons", "group"]) {
      const w = v === "group" ? 0 : g, y = w * 1e5 + w * b.priority * 100 + (v === "full" ? g * b.priority : 0);
      m[b.id] = v, s(p + 1, h + r(b, v) + (p ? a : 0), f + y, m);
    }
  };
  if (s(0, 0, 0, {}), l) return { modes: l.modes, visible: [...t], overflow: [] };
  const c = Object.fromEntries(t.map((p) => [p.id, "full"])), u = [...t].sort((p, h) => p.priority - h.priority), d = () => t.reduce((p, h) => p + r(h, c[h.id]), 0) + Math.max(0, t.length - 1) * a;
  for (const p of ["icons", "group"])
    for (const h of u) {
      if (d() <= n) return { modes: c, visible: [...t], overflow: [] };
      r(h, p) < r(h, c[h.id]) && (c[h.id] = p);
    }
  return d() <= n ? { modes: c, visible: [...t], overflow: [] } : { modes: c, ...tu(t, n - i, (p) => r(p, c[p.id]), a) };
}
function ru(t) {
  const n = R(null), r = R(null), [i, a] = k({ modes: {}, ids: [] });
  return xe(() => {
    const l = n.current, s = r.current;
    if (!l || !s || !l.parentElement) return;
    const c = l.parentElement;
    let u = 0, d = !0;
    const p = () => {
      if (!d) return;
      const m = new Map(Array.from(s.querySelectorAll("[data-measure-mode] [data-group]")).map((z) => [`${z.parentElement.dataset.measureMode}:${z.dataset.group}`, z.getBoundingClientRect().width])), b = getComputedStyle(c), g = parseFloat(getComputedStyle(l).columnGap) || 0, v = c.clientWidth - parseFloat(b.paddingLeft || "0") - parseFloat(b.paddingRight || "0"), w = c.querySelector(".note-toolbar-hint"), y = w && getComputedStyle(w).position !== "absolute" ? w.getBoundingClientRect().width + g : 0, N = (s.querySelector("[data-measure-overflow]")?.getBoundingClientRect().width ?? 40) + g, x = nu(t, Math.max(0, Math.floor(v - y)), (z, L) => m.get(`${L}:${z.id}`) ?? 1 / 0, N, g), C = { modes: x.modes, ids: x.visible.map((z) => z.id) };
      a((z) => JSON.stringify(z) === JSON.stringify(C) ? z : C);
    }, h = () => {
      cancelAnimationFrame(u), u = requestAnimationFrame(p);
    };
    p();
    const f = typeof ResizeObserver > "u" ? null : new ResizeObserver(h);
    return f?.observe(c), f?.observe(s), window.addEventListener("resize", h), document.fonts?.addEventListener("loadingdone", h), document.fonts?.ready.then(() => {
      d && h();
    }), () => {
      d = !1, cancelAnimationFrame(u), f?.disconnect(), window.removeEventListener("resize", h), document.fonts?.removeEventListener("loadingdone", h);
    };
  }), { hostRef: n, measureRef: r, modes: i.modes, visible: t.filter((l) => i.ids.includes(l.id)), overflow: t.filter((l) => !i.ids.includes(l.id)) };
}
function iu({ editor: t, onHistory: n, onAttachment: r, onVideo: i, onInteractive: a, onInsertCard: l, onMath: s, onSnapshot: c, onExport: u, formatPainterMode: d, onFormatPainterMode: p, formatPainterMarks: h, onFormatPainterMarks: f, hiddenActions: m = [] }) {
  const [b, g] = k(null), [v, w] = k(null), [y, N] = k({ rows: 3, cols: 3 }), [x, C] = k(""), [, z] = k(0), L = R(null), j = R(null), M = R(null), A = R(null), O = R([]);
  Y(() => {
    const F = ({ transaction: D }) => {
      A.current && D.docChanged && (A.current = {
        from: D.mapping.map(A.current.from),
        to: D.mapping.map(A.current.to)
      }), z((G) => G + 1);
    };
    return t.on("transaction", F), () => {
      t.off("transaction", F);
    };
  }, [t]), Y(() => {
    if (!b) return;
    const F = (ze) => {
      const $e = ze.target;
      !L.current?.contains($e) && !j.current?.contains($e) && !$e.closest?.(".fp-popup-panel") && g(null);
    }, D = (ze) => {
      ze.key === "Escape" && (g(null), M.current?.focus());
    }, G = () => g(null), de = L.current?.clientWidth, me = typeof ResizeObserver > "u" ? null : new ResizeObserver(() => {
      L.current?.clientWidth !== de && G();
    });
    return L.current && me?.observe(L.current), window.addEventListener("pointerdown", F), window.addEventListener("keydown", D), window.addEventListener("resize", G), () => {
      me?.disconnect(), window.removeEventListener("pointerdown", F), window.removeEventListener("keydown", D), window.removeEventListener("resize", G);
    };
  }, [b]);
  const U = () => {
    const { from: F, to: D } = t.state.selection;
    A.current = { from: F, to: D };
  }, T = () => {
    const F = A.current;
    F && F.to <= t.state.doc.content.size ? t.chain().focus().setTextSelection(F).run() : t.commands.focus();
  }, E = () => {
    g(null), A.current = null;
  }, S = (F) => {
    F(), E();
  }, P = [1, 2, 3, 4, 5, 6].find((F) => t.isActive("heading", { level: F })), _ = t.getAttributes("textStyle").color || null, q = t.getAttributes("highlight").color || "#fde047", H = () => {
    const F = Vd(d);
    p(F), f(F ? O.current : []);
  }, I = [
    { id: "history", priority: 100, actions: [
      { id: "undo", label: "撤销", icon: /* @__PURE__ */ e(eo, { size: 16 }), disabled: !t.can().undo(), run: () => {
        t.chain().focus().undo().run();
      } },
      { id: "redo", label: "重做", icon: /* @__PURE__ */ e(to, { size: 16 }), disabled: !t.can().redo(), run: () => {
        t.chain().focus().redo().run();
      } }
    ] },
    { id: "painter", priority: 40, actions: [{ id: "painter", label: "格式刷", icon: /* @__PURE__ */ e(no, { size: 16 }), active: !!d, before: () => {
      O.current = Wd(t);
    }, run: H }] },
    { id: "heading", priority: 95, actions: [{ id: "heading", label: "标题级别", icon: /* @__PURE__ */ e("b", { children: P ? `H${P}` : "Hn" }), menu: "heading" }] },
    { id: "bold", priority: 90, actions: [{ id: "bold", label: "粗体", icon: /* @__PURE__ */ e(ro, { size: 16 }), active: t.isActive("bold"), run: () => {
      t.chain().focus().toggleBold().run();
    } }] },
    { id: "italic", priority: 65, actions: [{ id: "italic", label: "斜体", icon: /* @__PURE__ */ e(io, { size: 16 }), active: t.isActive("italic"), run: () => {
      t.chain().focus().toggleItalic().run();
    } }] },
    { id: "colors", priority: 60, actions: [
      { id: "color", label: "字体颜色", icon: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(ao, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: _ || "var(--fp-ink)" } })
      ] }), menu: "color", before: U },
      { id: "highlight", label: "荧光笔", icon: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(lo, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: q } })
      ] }), menu: "highlight", before: U }
    ] },
    { id: "list", priority: 70, actions: [{ id: "list", label: "列表", icon: /* @__PURE__ */ e(dn, { size: 16 }), menu: "list" }] },
    { id: "link", priority: 45, actions: [{ id: "link", label: "链接", icon: /* @__PURE__ */ e(ft, { size: 16 }), active: t.isActive("link"), menu: "link", before: U }] },
    { id: "attachment", priority: 42, actions: [{ id: "attachment", label: "附件", icon: /* @__PURE__ */ e(Sr, { size: 16 }), run: r }] },
    { id: "math", priority: 99, actions: [{ id: "math", label: "公式", icon: /* @__PURE__ */ e(Pt, { size: 16 }), menu: "math" }] },
    { id: "insert", priority: 98, actions: [{ id: "insert", label: "插入", icon: /* @__PURE__ */ e(dr, { size: 16 }), menu: "insert" }] },
    { id: "decoration", priority: 35, actions: [
      { id: "strike", label: "删除线", icon: /* @__PURE__ */ e(oo, { size: 16 }), active: t.isActive("strike"), run: () => {
        t.chain().focus().toggleStrike().run();
      } },
      { id: "underline", label: "下划线", icon: /* @__PURE__ */ e(so, { size: 16 }), active: t.isActive("underline"), run: () => {
        t.chain().focus().toggleUnderline().run();
      } }
    ] },
    { id: "clear", priority: 20, actions: [{ id: "clear", label: "清除格式", icon: /* @__PURE__ */ e(co, { size: 16 }), run: () => {
      t.chain().focus().unsetAllMarks().clearNodes().run();
    } }] },
    { id: "quote", priority: 30, actions: [{ id: "quote", label: "引用", icon: /* @__PURE__ */ e(fa, { size: 16 }), active: t.isActive("blockquote"), run: () => {
      t.chain().focus().toggleBlockquote().run();
    } }] },
    { id: "code", priority: 25, actions: [
      { id: "code", label: "行内代码", icon: /* @__PURE__ */ e(Ur, { size: 16 }), active: t.isActive("code"), run: () => {
        t.chain().focus().toggleCode().run();
      } },
      { id: "codeBlock", label: "代码块", icon: /* @__PURE__ */ e(uo, { size: 16 }), active: t.isActive("codeBlock"), run: () => {
        t.chain().focus().toggleCodeBlock().run();
      } }
    ] },
    { id: "versions", priority: 15, actions: [{ id: "versions", label: "历史", icon: /* @__PURE__ */ e("span", { children: "历史" }), run: n }] }
  ];
  t.isActive("codeBlock") && I.push({ id: "language", priority: 85, actions: [], custom: /* @__PURE__ */ e(Gd, { language: rd(t.state.selection.$head.parent), onChange: (F) => t.chain().focus().updateAttributes("codeBlock", { language: F }).run() }) }), t.isActive("table") && I.push({ id: "tableActions", priority: 80, actions: [
    { id: "addRow", label: "添加行", icon: /* @__PURE__ */ e("span", { children: "+行" }), run: () => {
      t.chain().focus().addRowAfter().run();
    } },
    { id: "deleteRow", label: "删除行", icon: /* @__PURE__ */ e("span", { children: "−行" }), run: () => {
      t.chain().focus().deleteRow().run();
    } },
    { id: "addColumn", label: "添加列", icon: /* @__PURE__ */ e("span", { children: "+列" }), run: () => {
      t.chain().focus().addColumnAfter().run();
    } },
    { id: "deleteColumn", label: "删除列", icon: /* @__PURE__ */ e("span", { children: "−列" }), run: () => {
      t.chain().focus().deleteColumn().run();
    } },
    { id: "deleteTable", label: "删除表格", icon: /* @__PURE__ */ e("span", { children: "删表" }), run: () => {
      t.chain().focus().deleteTable().run();
    } }
  ] });
  const $ = I.flatMap((F) => F.actions), B = (...F) => $.filter((D) => F.includes(D.id)), Z = [
    { id: "history", label: "撤销重做", priority: 100, actions: B("undo", "redo") },
    { id: "text", label: "文字格式", priority: 80, actions: B("heading", "bold", "italic", "underline", "strike", "color", "highlight", "painter", "clear") },
    { id: "paragraph", label: "段落", priority: 60, actions: B("list", "quote", "code", "codeBlock") },
    { id: "insertions", label: "插入", priority: 90, actions: [
      ...B("math"),
      { id: "table", label: "表格", icon: /* @__PURE__ */ e(dr, { size: 16 }), menu: "table" },
      { id: "card", label: "卡片", icon: /* @__PURE__ */ e(wi, { size: 16 }), run: l },
      ...B("link", "attachment"),
      { id: "video", label: "视频 · 边看边记", icon: /* @__PURE__ */ e(ki, { size: 16 }), run: i || r },
      { id: "mermaid", label: "Mermaid 图", icon: /* @__PURE__ */ e(po, { size: 16 }), run: () => {
        ll(t);
      } },
      ...a ? [{ id: "interactive", label: "交互实验", icon: /* @__PURE__ */ e(ho, { size: 16 }), run: a }] : [],
      { id: "divider", label: "分隔线", icon: /* @__PURE__ */ e(jt, { size: 16 }), run: () => {
        t.chain().focus().setHorizontalRule().run();
      } }
    ] },
    { id: "versions", label: "历史与导出", priority: 40, actions: [
      ...B("versions"),
      { id: "snapshot", label: "建立版本", icon: /* @__PURE__ */ e(ma, { size: 16 }), run: c },
      { id: "export", label: "导出", icon: /* @__PURE__ */ e(_t, { size: 16 }), run: u }
    ] },
    ...I.filter((F) => ["language", "tableActions"].includes(F.id)).map((F) => ({ ...F, label: F.id === "language" ? "代码语言" : "表格操作" }))
  ].map((F) => ({ ...F, actions: F.actions.filter((D) => !m.includes(D.id)) })).filter((F) => F.actions.length || F.custom), { hostRef: Ne, measureRef: pe, modes: V, visible: K, overflow: re } = ru(Z), le = (F, D = !1, G = !1, de = !1) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "data-fp-tooltip": D ? "off" : F.label,
      "aria-label": F.label,
      "aria-pressed": F.active || void 0,
      "aria-expanded": F.menu ? b === F.menu : void 0,
      disabled: F.disabled,
      className: D ? "toolbar-menu-item" : void 0,
      onMouseDown: (me) => {
        G || (me.preventDefault(), F.before?.());
      },
      onClick: (me) => {
        G || (F.before?.(), F.menu ? (w(D ? v ?? me.currentTarget.getBoundingClientRect() : me.currentTarget.getBoundingClientRect()), g((ze) => ze === F.menu ? null : F.menu), F.menu === "link" && C(t.getAttributes("link").href || "")) : F.run && S(F.run));
      },
      children: [
        F.icon,
        (D || de) && F.id !== "versions" && /* @__PURE__ */ e("span", { children: F.label })
      ]
    },
    F.id
  ), fe = (F, D = !1, G = !1, de = V[F.id] ?? "full") => /* @__PURE__ */ e("div", { "data-group": F.id, className: D ? "toolbar-overflow-group" : "toolbar-group", children: de === "group" && !D && F.id !== "history" ? /* @__PURE__ */ o("button", { type: "button", "aria-label": F.label, "aria-expanded": b === `group:${F.id}`, onMouseDown: (me) => me.preventDefault(), onClick: (me) => {
    w(me.currentTarget.getBoundingClientRect()), g(`group:${F.id}`);
  }, children: [
    F.label,
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌄" })
  ] }) : /* @__PURE__ */ o(ee, { children: [
    F.actions.map((me) => le(me, D, G, de === "full" && F.id !== "history")),
    F.custom
  ] }) }, F.id), se = (F, D, G) => /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onMouseDown: (de) => de.preventDefault(), onClick: () => S(G), children: [
    D,
    /* @__PURE__ */ e("span", { children: F })
  ] }), we = v ? Math.max(8, Math.min(v.left, window.innerWidth - 256)) : 8, W = v ? Math.min(v.bottom + 6, window.innerHeight - 160) : 8;
  return /* @__PURE__ */ o("div", { className: "fp-note-toolbar note-editor-topbar", ref: L, role: "toolbar", "aria-label": "笔记编辑工具", children: [
    /* @__PURE__ */ e("div", { ref: Ne, className: "visual-note-editor-toolbar", children: K.map((F) => fe(F)) }),
    re.length > 0 && /* @__PURE__ */ e(Ud, { tip: "更多", children: /* @__PURE__ */ e("button", { ref: M, type: "button", "aria-label": "更多", title: "更多", "aria-expanded": b === "more", onMouseDown: (F) => F.preventDefault(), onClick: () => {
      w(M.current?.getBoundingClientRect() ?? null), g(b === "more" ? null : "more");
    }, children: /* @__PURE__ */ e(Kt, { size: 17 }) }) }),
    /* @__PURE__ */ o("div", { ref: pe, className: "visual-note-editor-toolbar toolbar-measure", "aria-hidden": "true", inert: !0, children: [
      ["full", "icons", "group"].map((F) => /* @__PURE__ */ e("div", { "data-measure-mode": F, className: "toolbar-measure-row", children: Z.map((D) => fe(D, !1, !0, F)) }, F)),
      /* @__PURE__ */ e("button", { type: "button", "data-measure-overflow": !0, "aria-label": "更多", children: /* @__PURE__ */ e(Kt, { size: 17 }) })
    ] }),
    d && t.state.selection.empty && !h.length && /* @__PURE__ */ e("span", { className: "note-toolbar-hint", role: "status", children: "请先选中带格式的文字，再点格式刷" }),
    b && v && Oe(/* @__PURE__ */ o("div", { ref: j, className: "fp-editor-menu note-toolbar-portal-menu", role: "dialog", "aria-label": "编辑工具选项", style: { left: we, top: W, maxHeight: Math.max(100, window.innerHeight - W - 12) }, children: [
      b === "more" && /* @__PURE__ */ e(ee, { children: re.map((F) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: F.label }),
        fe(F, !0)
      ] }, F.id)) }),
      b.startsWith("group:") && Z.filter((F) => `group:${F.id}` === b).map((F) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: F.label }),
        fe(F, !0)
      ] }, F.id)),
      b === "heading" && /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: "标题级别" }),
        /* @__PURE__ */ e("div", { className: "toolbar-menu-grid", children: [1, 2, 3, 4, 5, 6].map((F) => /* @__PURE__ */ o("button", { type: "button", className: P === F ? "is-active" : "", onClick: () => S(() => {
          t.chain().focus().toggleHeading({ level: F }).run();
        }), children: [
          "H",
          F
        ] }, F)) }),
        se("正文", null, () => {
          t.chain().focus().setParagraph().run();
        })
      ] }),
      (b === "color" || b === "highlight") && /* @__PURE__ */ e(eu, { mode: b === "color" ? "text" : "highlight", current: b === "color" ? _ : q, onApply: (F) => {
        T(), b === "color" ? F === null ? t.chain().unsetMark("textStyle").removeEmptyTextStyle().run() : t.chain().setColor(F).run() : F === null ? t.chain().unsetHighlight().run() : t.chain().setHighlight({ color: F }).run();
      }, onClose: E }),
      b === "list" && /* @__PURE__ */ o(ee, { children: [
        se("无序列表", /* @__PURE__ */ e(dn, { size: 15 }), () => {
          t.chain().focus().toggleBulletList().run();
        }),
        se("有序列表", /* @__PURE__ */ e(fo, { size: 15 }), () => {
          t.chain().focus().toggleOrderedList().run();
        })
      ] }),
      b === "link" && /* @__PURE__ */ o("form", { className: "toolbar-link-form", onSubmit: (F) => {
        F.preventDefault(), T(), x.trim() ? t.chain().extendMarkRange("link").setLink({ href: x.trim() }).run() : t.chain().extendMarkRange("link").unsetLink().run(), E();
      }, children: [
        /* @__PURE__ */ o("label", { children: [
          "链接地址",
          /* @__PURE__ */ e("input", { "aria-label": "链接地址", value: x, onChange: (F) => C(F.target.value), placeholder: "https://" })
        ] }),
        /* @__PURE__ */ e("button", { type: "submit", children: "应用" }),
        se("移除链接", null, () => {
          T(), t.chain().extendMarkRange("link").unsetLink().run();
        })
      ] }),
      b === "math" && /* @__PURE__ */ o(ee, { children: [
        se("行内公式", /* @__PURE__ */ e(Pt, { size: 15 }), () => s(!1)),
        se("独立公式", /* @__PURE__ */ e(Pt, { size: 15 }), () => s(!0))
      ] }),
      b === "insert" && /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onClick: () => g("table"), children: [
          /* @__PURE__ */ e(dr, { size: 15 }),
          "表格…"
        ] }),
        se("行内公式", /* @__PURE__ */ e(Pt, { size: 15 }), () => s(!1)),
        se("独立公式", /* @__PURE__ */ e(Pt, { size: 15 }), () => s(!0)),
        !m.includes("card") && se("说明卡片", /* @__PURE__ */ e(wi, { size: 15 }), l),
        !m.includes("video") && se("视频 · 边看边记", /* @__PURE__ */ e(ki, { size: 15 }), i || r),
        !m.includes("attachment") && se("附件", /* @__PURE__ */ e(Sr, { size: 15 }), r),
        se("分隔线", /* @__PURE__ */ e(jt, { size: 15 }), () => {
          t.chain().focus().setHorizontalRule().run();
        })
      ] }),
      b === "table" && /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ o("strong", { className: "toolbar-menu-label", children: [
          y.rows,
          " × ",
          y.cols,
          " 表格"
        ] }),
        /* @__PURE__ */ e("div", { className: "toolbar-table-grid", children: Array.from({ length: 64 }, (F, D) => {
          const G = Math.floor(D / 8) + 1, de = D % 8 + 1;
          return /* @__PURE__ */ e("button", { type: "button", "aria-label": `${G} 行 ${de} 列`, className: G <= y.rows && de <= y.cols ? "is-active" : "", onFocus: () => N({ rows: G, cols: de }), onMouseEnter: () => N({ rows: G, cols: de }), onClick: () => S(() => {
            t.chain().focus().insertTable({ rows: G, cols: de, withHeaderRow: !0 }).run();
          }) }, D);
        }) })
      ] })
    ] }), document.body)
  ] });
}
const pl = nr.create({
  name: "imageConversion",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return Object.fromEntries(["src", "alt", "jobId", "markdown", "error"].map((t) => [t, { default: "" }]));
  },
  parseHTML() {
    return [{ tag: "figure[data-image-conversion]" }];
  },
  renderHTML({ node: t }) {
    return ["figure", { "data-image-conversion": "" }, ["img", { src: t.attrs.src, alt: t.attrs.alt }]];
  },
  renderMarkdown(t) {
    return `![${String(t.attrs?.alt || "图片").replace(/[\[\]]/g, "")}](${t.attrs?.src || ""})`;
  }
});
function Zh(t, n) {
  const r = t.state.selection.to;
  return t.chain().focus().insertContentAt(r, [n, { type: "paragraph" }]).run();
}
const en = (t) => String(t ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), hl = nr.create({
  name: "uploadPlaceholder",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return {
      uploadId: { default: "" },
      name: { default: "附件" },
      mediaType: { default: "application/octet-stream" },
      error: { default: "" },
      convert: { default: !1, parseHTML: (t) => t.getAttribute("convert") === "true" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-upload-placeholder]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["div", Jr(t, { "data-upload-placeholder": "" }), `正在上传 ${t.name || "附件"}`];
  },
  renderMarkdown(t) {
    const n = t.attrs || {};
    return `<div data-upload-placeholder="" uploadid="${en(n.uploadId)}" name="${en(n.name)}" mediatype="${en(n.mediaType)}" error="${en(n.error)}" convert="${n.convert === !0 ? "true" : "false"}">正在上传 ${en(n.name || "附件")}</div>

`;
  }
});
function au(t) {
  const n = (r) => {
    if (!r.content) return [r];
    const i = r.content.flatMap(n);
    if (!["paragraph", "heading"].includes(r.type || "") || !i.some((u) => u.type === "image")) return [{ ...r, content: i }];
    const a = [];
    let l = [], s = !1;
    const c = () => {
      if (!l.length) return;
      const u = { ...r.attrs };
      s && delete u.id, a.push({ ...r, attrs: u, content: l }), s = !0, l = [];
    };
    for (const u of i)
      u.type === "image" ? (c(), a.push(u)) : l.push(u);
    return c(), a;
  };
  return n(t)[0];
}
function lu(t) {
  const n = t.match(
    /^::(video|audio|interactive|figure|plot)\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/
  );
  if (n)
    return {
      type: "directiveBlock",
      raw: n[0],
      name: n[1],
      attributes: n[2] || "",
      body: ""
    };
  const r = t.match(/^:::([a-zA-Z][\w-]*)(?:\{([^\n}]*)\})?[ \t]*\r?\n/);
  if (!r) return;
  let i = 1, a = r[0].length;
  for (; a <= t.length; ) {
    const l = t.indexOf(`
`, a), s = l < 0 ? t.length : l + 1, c = t.slice(a, s).replace(/\r?\n$/, "");
    if (/^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/.test(c) && (i += 1), /^:::[ \t]*$/.test(c) && (i -= 1, i === 0)) {
      const u = t.slice(r[0].length, a).replace(/\r?\n$/, "");
      return {
        type: "directiveBlock",
        raw: t.slice(0, s),
        name: r[1],
        attributes: r[2] || "",
        body: u
      };
    }
    if (l < 0) break;
    a = s;
  }
}
const fl = nr.create({
  name: "directiveBlock",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "note" },
      attributes: { default: "" },
      body: { default: "" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-directive-block]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return [
      "div",
      Jr(t, { "data-directive-block": "" })
    ];
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("directiveBlock", {
      name: r.name,
      attributes: r.attributes,
      body: r.body
    });
  },
  renderMarkdown(t) {
    const n = String(t.attrs?.attributes || "").trim(), r = String(t.attrs?.body || ""), i = t.attrs?.name || "note";
    return ["video", "audio", "interactive", "figure", "plot"].includes(i) ? `::${i}${n ? `{${n}}` : ""}` : `:::${i}${n ? `{${n}}` : ""}
${r}${r.endsWith(`
`) ? "" : `
`}:::`;
  },
  markdownTokenizer: {
    name: "directiveBlock",
    level: "block",
    start: (t) => t.search(
      /^::(?:interactive|video|audio|figure|plot)\{[^\n}]*\}[ \t]*$|^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/m
    ),
    tokenize: (t) => lu(t)
  }
}), ou = [
  ["definition", "定义"],
  ["theorem", "定理"],
  ["example", "例题"],
  ["insight", "直觉"],
  ["pitfall", "易错点"],
  ["note", "说明"],
  ["tip", "技巧"],
  ["memory", "记忆卡"],
  ["derivation", "推导"],
  ["timeline", "时间线"],
  ["event", "事件"],
  ["concept", "概念"],
  ["compare", "对比"],
  ["cause-effect", "因果"],
  ["keypoint", "核心要点"],
  ["interactive", "互动内容"],
  ["video", "视频"],
  ["figure", "图片"],
  ["plot", "函数图"],
  ["audio", "音频"],
  ["historymap", "历史地图"],
  ["learninganimation", "学习动画"],
  ["attachment", "附件"]
];
function ml(t) {
  return t === "timeline" ? "period" : t === "concept" ? "term" : ["event", "compare", "cause-effect"].includes(t) ? "title" : "label";
}
function Vi(t, n) {
  const r = ml(n);
  for (const i of [r, "label", "title", "term", "period"]) {
    const a = t.match(
      new RegExp(`(?:^|\\s)${i}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)
    );
    if (a) return a[1] ?? a[2] ?? a[3] ?? "";
  }
  return "";
}
function Gi(t, n, r) {
  const i = ml(n), a = t.replace(
    /(?:^|\s)(?:label|title|period|term)=(?:"[^"]*"|'[^']*'|[^\s}]+)/g,
    ""
  ).trim(), l = r.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return [`${i}="${l}"`, a].filter(Boolean).join(" ");
}
const su = Es.extend({
  addOptions() {
    return { ...this.parent?.(), resolveUrl: (t) => t };
  },
  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: null,
        parseHTML: (t) => t.getAttribute("data-width") || t.style.width || null,
        renderHTML: (t) => t.width ? { "data-width": t.width, style: `width:${t.width};max-width:100%` } : {}
      }
    };
  },
  addNodeView() {
    return ({ node: t, getPos: n, editor: r }) => {
      let i = t;
      const a = document.createElement("span");
      a.className = "visual-image-node", a.contentEditable = "false", a.dataset.noteObject = "image";
      const l = document.createElement("img"), s = document.createElement("input");
      s.type = "text", s.className = "visual-image-caption", s.setAttribute("aria-label", "图片名称"), s.placeholder = "添加图片名称", s.addEventListener("keydown", (d) => {
        d.stopPropagation(), d.key === "Enter" && !d.isComposing && (d.preventDefault(), s.blur());
      }), s.addEventListener("blur", () => {
        const d = n();
        typeof d == "number" && s.value !== String(i.attrs.title || i.attrs.alt || "") && r.view.dispatch(r.state.tr.setNodeMarkup(d, void 0, { ...i.attrs, alt: s.value, title: s.value }));
      });
      const c = document.createElement("button");
      c.type = "button", c.className = "visual-image-resize", c.setAttribute("aria-label", "调整图片大小");
      const u = () => {
        l.src = this.options.resolveUrl(String(i.attrs.src || "")), l.alt = String(i.attrs.alt || ""), l.title = String(i.attrs.title || ""), document.activeElement !== s && (s.value = String(i.attrs.title || i.attrs.alt || "")), l.style.width = i.attrs.width ? String(i.attrs.width) : "";
      };
      return c.addEventListener("pointerdown", (d) => {
        d.preventDefault(), d.stopPropagation();
        const p = d.clientX, h = l.getBoundingClientRect().width;
        c.setPointerCapture(d.pointerId);
        const f = (b) => {
          const g = Math.max(180, a.parentElement?.clientWidth || 900);
          l.style.width = `${Math.round(Math.min(g, Math.max(120, h + b.clientX - p)))}px`;
        }, m = (b) => {
          c.releasePointerCapture(b.pointerId), c.removeEventListener("pointermove", f), c.removeEventListener("pointerup", m);
          const g = n();
          typeof g == "number" && r.view.dispatch(r.state.tr.setNodeMarkup(g, void 0, { ...i.attrs, width: l.style.width }));
        };
        c.addEventListener("pointermove", f), c.addEventListener("pointerup", m);
      }), a.append(l, c, s), u(), {
        dom: a,
        stopEvent(d) {
          return d.target === s;
        },
        update(d) {
          return d.type !== i.type ? !1 : (i = d, u(), !0);
        },
        selectNode() {
          a.classList.add("is-selected");
        },
        deselectNode() {
          a.classList.remove("is-selected");
        }
      };
    };
  }
}), cu = $s.extend({
  onCreate(t) {
    if (this.parent?.(t), !this.options.updateDocument || !this.editor.extensionManager.extensions.find((u) => ["collaboration", "collaborationCaret"].includes(u.name) && u.options.provider)?.options.provider?.synced) return;
    const { state: r, view: i } = this.editor, { attributeName: a, generateID: l, types: s } = this.options, c = r.tr;
    r.doc.descendants((u, d) => {
      (s === "all" ? !["doc", "text"].includes(u.type.name) : s.includes(u.type.name)) && u.attrs[a] === null && c.setNodeMarkup(d, void 0, { ...u.attrs, [a]: l({ node: u, pos: d }) });
    }), c.steps.length && i.dispatch(c.setStoredMarks(r.storedMarks).setMeta("addToHistory", !1).setMeta("__uniqueIDTransaction", !0));
  }
});
function fr(t, n) {
  const r = t.match(new RegExp(`(?:^|\\s)${n}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)), i = r?.[1] ?? r?.[2] ?? r?.[3] ?? "";
  try {
    return decodeURIComponent(i);
  } catch {
    return i;
  }
}
function mr(t) {
  return encodeURIComponent(t);
}
function du(t) {
  const n = t.match(/^::attachment\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/);
  if (n)
    return {
      type: "attachment",
      raw: n[0],
      name: fr(n[1], "name") || "附件",
      url: fr(n[1], "url"),
      mediaType: fr(n[1], "mediaType") || "application/octet-stream"
    };
}
const bl = nr.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "附件" },
      url: { default: "" },
      mediaType: { default: "application/octet-stream" }
    };
  },
  parseHTML() {
    return [{
      tag: "figure[data-note-attachment]",
      getAttrs: (t) => {
        const n = t;
        return {
          name: n.dataset.name || "附件",
          url: n.dataset.url || "",
          mediaType: n.dataset.mediaType || "application/octet-stream"
        };
      }
    }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["figure", Jr(t, {
      "data-note-attachment": "",
      "data-name": t.name,
      "data-url": t.url,
      "data-media-type": t.mediaType
    }), ["a", { href: t.url, target: "_blank", rel: "noreferrer" }, t.name || "附件"]];
  },
  renderMarkdown(t) {
    const n = mr(String(t.attrs?.name || "附件")), r = mr(String(t.attrs?.url || "")), i = mr(String(t.attrs?.mediaType || "application/octet-stream"));
    return `::attachment{name="${n}" url="${r}" mediaType="${i}"}

`;
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("attachment", { name: r.name, url: r.url, mediaType: r.mediaType });
  },
  markdownTokenizer: {
    name: "attachment",
    level: "block",
    start: (t) => t.search(/^::attachment\{[^\n}]*\}[ \t]*$/m),
    tokenize: (t) => du(t)
  }
}), uu = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, pu = /^(\s*)>( ?)(.*)$/;
function hu(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (i) => {
    if (i === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const a = r ? "‘" : "’";
    return r = !r, a;
  });
}
function fu(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let i = !1, a = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const v = c[1][0];
      i ? v === a && (i = !1, a = "") : (i = !0, a = v), r.push(s), l++;
      continue;
    }
    if (i) {
      r.push(s), l++;
      continue;
    }
    const u = s.match(uu);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (kd(p)) {
      r.push(s), l++;
      continue;
    }
    const m = wd(p), b = f.trim(), g = [`kind=${m}`];
    for (b && g.push(`label="${hu(b)}"`), h === "-" && g.push("collapsed=true"), r.push(`${d}:::callout{${g.join(" ")}}`), l++; l < n.length; ) {
      const v = n[l];
      if (!/^\s*>/.test(v) || v.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const y = v.match(pu);
      y ? r.push(y[3]) : r.push(v.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function mu(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let i = !1, a = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      i ? u === a && (i = !1, a = "") : (i = !0, a = u), r.push(l);
      continue;
    }
    if (i) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const Yi = /#[\p{L}\p{N}_][\p{L}\p{N}_-]{0,48}/gu, bu = tr.create({
  name: "hashtagHighlight",
  addProseMirrorPlugins() {
    return [
      new Yt({
        key: new Zr("hashtagHighlight"),
        props: {
          decorations(t) {
            const { doc: n, selection: r } = t, i = [];
            return n.descendants((a, l) => {
              if (a.type.spec.code) return !1;
              if (!a.isText || !a.text || a.marks.some((d) => d.type.spec.code) || r.empty && r.from >= l && r.from <= l + a.nodeSize) return;
              const c = a.text;
              Yi.lastIndex = 0;
              let u;
              for (; (u = Yi.exec(c)) !== null; ) {
                const d = l + u.index, p = d + u[0].length;
                i.push(
                  za.inline(d, p, { class: "note-inline-tag" })
                );
              }
            }), Mr.create(n, i);
          }
        }
      })
    ];
  }
}), gu = [
  "paragraph",
  "heading",
  "blockquote",
  "codeBlock",
  "bulletList",
  "orderedList",
  "table",
  "horizontalRule",
  "image",
  "attachment",
  "blockMath",
  "directiveBlock"
], ef = 2;
function pi(t = !0, n, r = fl, i, a = bl, l = $a.configure({ lowlight: Qa })) {
  return [
    ws.configure({
      undoRedo: t ? void 0 : !1,
      link: !1,
      codeBlock: !1
    }),
    ks.configure({ openOnClick: !1, autolink: !0, defaultProtocol: "https" }),
    zs,
    As,
    Ls.configure({ multicolor: !0 }),
    l,
    su.configure({ allowBase64: !1, inline: !1 }),
    a,
    pl,
    hl,
    Ss.configure({ table: { resizable: !0 } }),
    cu.configure({ types: gu }),
    r,
    ...i || [Ns.configure({
      katexOptions: { throwOnError: !1 },
      inlineOptions: { onClick: (s, c) => n?.onInlineClick?.(String(s.attrs.latex || ""), c) },
      blockOptions: { onClick: (s, c) => n?.onBlockClick?.(String(s.attrs.latex || ""), c) }
    })],
    Ms.configure({ markedOptions: { gfm: !0, breaks: !1 } }),
    bu
  ];
}
function gl(t) {
  return au(new Aa({ extensions: pi(!1) }).parse(
    fu(mu(t))
  ));
}
function Xi(t) {
  return new Aa({ extensions: pi(!1) }).serialize(t);
}
const br = new Zr("mathDollarShortcut"), qe = /* @__PURE__ */ new WeakMap();
function An(t, n) {
  (n === void 0 || qe.get(t)?.position === n) && qe.delete(t);
}
function sn(t, n) {
  const r = qe.get(t);
  return !r || r.position !== n ? !1 : (qe.delete(t), r.promote());
}
function yu(t, n) {
  return tr.create({
    name: "mathDollarShortcut",
    priority: 1100,
    addProseMirrorPlugins() {
      const r = this.editor, i = (a, l, s) => {
        ti.getState(r.state)?.undoManager.stopCapturing(), r.view.dispatch(ei(r.state.tr));
        let c;
        const u = s ? "blockMath" : "inlineMath";
        if (!r.chain().insertContentAt({ from: a, to: l }, { type: u, attrs: { latex: "" } }).command(({ tr: h }) => (h.mapping.maps.at(-1)?.forEach((f, m, b, g) => {
          h.doc.nodesBetween(b, g, (v, w) => {
            if (v.type.name === u)
              return c = w, !1;
          });
        }), c === void 0 ? !1 : (h.setSelection(Rt.create(h.doc, c)).setMeta(br, !0), !0))).run() || c === void 0) return !1;
        const p = c;
        return s || qe.set(r, { position: p, promote: () => i(p, p + 1, !0) }), (s ? n : t)?.("", p), !0;
      };
      return [new Yt({
        key: br,
        state: {
          init: () => null,
          apply(a) {
            const l = qe.get(r);
            if (l && !a.getMeta(br) && (a.docChanged || a.selectionSet)) {
              const s = a.doc.nodeAt(l.position);
              (s?.type.name !== "inlineMath" || s.attrs.latex !== "" || a.selection.from < l.position || a.selection.to > l.position + 1) && qe.delete(r);
            }
            return null;
          }
        },
        props: {
          handleTextInput(a, l, s, c) {
            if (!r.isEditable || a.composing) return !1;
            const u = qe.get(r);
            if (u && l >= u.position && s <= u.position + 1)
              return c === "$" ? sn(r, u.position) : (qe.delete(r), a.dispatch(a.state.tr.setNodeMarkup(u.position, void 0, { latex: c })), !0);
            if (l !== s) return !1;
            const d = a.state.doc.resolve(l);
            if (!d.parent.isTextblock || d.parent.type.spec.code || (a.state.storedMarks || d.marks()).some((b) => b.type.spec.code)) return !1;
            const h = d.parent.textBetween(0, d.parentOffset, `
`, "￼") + c, f = new RegExp("(?<!\\$)(\\${2,3})$").exec(h);
            return !f || c.length > f[1].length || (/\\+$/.exec(h.slice(0, f.index))?.[0].length ?? 0) % 2 === 1 ? !1 : i(l - (f[1].length - c.length), s, f[1].length === 3);
          },
          handleDOMEvents: { pointerdown: () => (qe.delete(r), !1) },
          handleKeyDown: (a, l) => {
            const s = qe.get(r);
            return s && l.key === "$" && !l.isComposing && l.keyCode !== 229 && !l.ctrlKey && !l.metaKey && !l.altKey ? sn(r, s.position) : (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown", "Tab", "Escape", "Backspace", "Delete"].includes(l.key) && qe.delete(r), !1);
          }
        },
        view: () => {
          const a = (s) => {
            const c = qe.get(r);
            !c || s.defaultPrevented || s.target !== document.body || !r.view.dom.isConnected || s.isComposing || s.keyCode === 229 || s.ctrlKey || s.metaKey || s.altKey || s.key === "$" && sn(r, c.position) && (s.preventDefault(), s.stopPropagation());
          }, l = () => qe.delete(r);
          return document.addEventListener("keydown", a, !0), document.addEventListener("pointerdown", l, !0), { destroy: () => {
            l(), document.removeEventListener("keydown", a, !0), document.removeEventListener("pointerdown", l, !0);
          } };
        }
      })];
    }
  });
}
const Wn = /* @__PURE__ */ new WeakMap();
let rn = null;
function vu() {
  return typeof IntersectionObserver > "u" ? null : (rn || (rn = new IntersectionObserver((t) => {
    for (const n of t) {
      if (!n.isIntersecting) continue;
      const r = Wn.get(n.target);
      r && (Wn.delete(n.target), rn?.unobserve(n.target), r());
    }
  }, { rootMargin: "600px 0px" })), rn);
}
function Qi({ node: t, getPos: n, editor: r }, i, a) {
  let l = t, s = !1, c = !1;
  const u = document.createElement(i ? "div" : "span");
  u.mathPosition = () => c ? void 0 : n();
  const d = document.createElement(i ? "div" : "span");
  u.className = "tiptap-mathematics-render is-deferred", u.dataset.type = i ? "block-math" : "inline-math", u.contentEditable = "false", u.draggable = !1, d.className = "math-node-content", u.append(d);
  const p = document.createElement(i ? "div" : "span");
  p.className = "math-node-editor-slot", u.append(p);
  const h = (N) => {
    N.preventDefault(), N.stopPropagation();
  };
  u.addEventListener("dragstart", h);
  const f = document.createElement("button");
  f.type = "button", f.className = "math-node-edit", f.textContent = "编辑公式", f.setAttribute("aria-label", "编辑公式"), a && u.append(f);
  const m = () => {
    const N = String(l.attrs.latex || "");
    u.dataset.latex = N, u.setAttribute("aria-label", `公式：${N}`), d.textContent = N;
  }, b = () => {
    if (c) return;
    const N = String(l.attrs.latex || "");
    try {
      La.render(N || "\\;", d, { throwOnError: !0, displayMode: i, macros: Ha }), u.classList.remove(i ? "block-math-error" : "inline-math-error"), u.removeAttribute("title");
    } catch {
      d.textContent = N, u.classList.add(i ? "block-math-error" : "inline-math-error"), u.title = "公式暂时无法显示，点击编辑后可检查写法";
    }
    N || (d.textContent = "点击输入公式"), u.classList.toggle("is-empty-math", !N), u.classList.remove("is-deferred"), s = !0;
  }, g = () => {
    const N = vu();
    if (!N) {
      b();
      return;
    }
    Wn.set(u, b), N.observe(u);
  }, v = () => {
    Wn.delete(u), rn?.unobserve(u);
  }, w = (N) => {
    if (p.contains(N.target) || !r.isEditable) return;
    N.preventDefault(), N.stopPropagation();
    const x = n();
    typeof x == "number" && a?.(String(l.attrs.latex || ""), x);
  }, y = (N) => {
    if (p.contains(N.target)) return;
    N.preventDefault(), N.stopPropagation();
    const x = n();
    typeof x == "number" && r.isEditable && (r.commands.setNodeSelection(x), a?.(String(l.attrs.latex || ""), x));
  };
  return f.addEventListener("click", w), u.addEventListener("dblclick", w), m(), g(), a && u.addEventListener("click", y), {
    dom: u,
    selectNode() {
      u.classList.add("ProseMirror-selectednode"), u.draggable = !1;
    },
    deselectNode() {
      u.classList.remove("ProseMirror-selectednode"), u.draggable = !1;
    },
    stopEvent: (N) => p.contains(N.target) || f.contains(N.target),
    ignoreMutation: () => !0,
    update(N) {
      return N.type !== l.type ? !1 : (l = N, u.dataset.latex = String(l.attrs.latex || ""), u.setAttribute("aria-label", `公式：${l.attrs.latex || ""}`), s ? b() : m(), !0);
    },
    destroy() {
      c = !0, u.removeEventListener("dragstart", h), v(), u.removeEventListener("click", y), u.removeEventListener("dblclick", w), f.removeEventListener("click", w);
    }
  };
}
function wu(t) {
  const n = (a, l, s) => ({
    Enter: () => {
      const c = a.state.selection;
      return !(c instanceof Rt) || c.node.type.name !== l || !s ? !1 : (s(String(c.node.attrs.latex || ""), c.from), !0);
    }
  }), r = xs.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "inlineMath", t.onInlineClick);
    },
    addNodeView() {
      return (a) => Qi(a, !1, t.onInlineClick);
    }
  });
  return [Cs.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "blockMath", t.onBlockClick);
    },
    addNodeView() {
      return (a) => Qi(a, !0, t.onBlockClick);
    }
  }), r, yu(t.onInlineClick, t.onBlockClick)];
}
const yl = {
  sin: "正弦",
  cos: "余弦",
  tan: "正切",
  cot: "余切",
  sec: "正割",
  csc: "余割",
  arcsin: "反正弦",
  arccos: "反余弦",
  arctan: "反正切",
  sinh: "双曲正弦",
  cosh: "双曲余弦",
  tanh: "双曲正切",
  coth: "双曲余切",
  exp: "指数函数",
  ln: "自然对数",
  log: "对数",
  lg: "常用对数",
  min: "最小值",
  max: "最大值",
  inf: "下确界",
  sup: "上确界",
  liminf: "下极限",
  limsup: "上极限",
  gcd: "最大公约数",
  arg: "辐角"
}, ku = { "e^x": "自然指数", "\\log_a": "任意底对数", "\\sqrt[n]{x}": "高次根号", "f'(x)": "一阶导数", "\\frac{d^2}{dx^2}": "二阶导数", "|x|": "绝对值", "\\{x\\}": "集合", "\\operatorname{span}": "线性张成", "\\ker": "核空间", "\\operatorname{Im}": "像空间", "\\operatorname{diag}": "对角矩阵", "\\frac{1}{n}": "倒数", "x^2": "平方" }, ie = (t, n = t, r) => ({ latex: `\\textstyle ${t}`, insert: n, tooltip: r ?? ku[t] ?? yl[t.replace(/^\\/, "")], class: "small" }), Nu = ["[undo]", "[redo]", "[left]", "[right]", { label: "下一格", tooltip: "移到下一个占位框", command: ["performWithFeedback", "moveToNextPlaceholder"], width: 2 }, { label: "[backspace]", width: 2 }], tn = (t, n) => ({ id: t, label: "", displayEditToolbar: !1, rows: [...n, Nu] }), xu = [
  { id: "basic", label: "常用", layout: tn("note-basic", [
    ["7", "8", "9", "+", "-", ie("\\frac{a}{b}", "\\frac{#0}{#?}", "分数"), ie("\\sqrt{x}", "\\sqrt{#0}", "根号"), ie("x^n", "#0^{#?}", "上标")],
    ["4", "5", "6", "\\times", "\\div", "(", ")", ie("x_n", "#0_{#?}", "下标")],
    ["1", "2", "3", "=", "\\ne", "<", ">", "\\pi"],
    ["0", ".", "x", "y", "\\le", "\\ge", "\\pm", "\\infty"]
  ]) },
  { id: "calculus", label: "高等数学", layout: tn("note-calculus", [
    [ie("\\lim", "\\lim_{x\\to #?} #?", "极限"), ie("\\frac{d}{dx}", "\\frac{d #?}{d x}", "导数"), ie("\\frac{\\partial}{\\partial x}", "\\frac{\\partial #?}{\\partial x}", "偏导数"), ie("\\int", "\\int #?\\,d x", "不定积分"), ie("\\int_a^b", "\\int_{#?}^{#?} #?\\,d x", "定积分"), ie("\\iint", "\\iint_{#?} #?\\,d x\\,d y", "二重积分"), ie("\\iiint", "\\iiint_{#?} #?\\,d V", "三重积分"), ie("\\oint", "\\oint_{#?} #?\\,d s", "曲线积分")],
    [ie("\\sum", "\\sum_{n=#?}^{#?} #?", "求和"), ie("\\prod", "\\prod_{n=#?}^{#?} #?", "连乘"), ie("e^x", "e^{#?}"), ie("\\ln", "\\ln\\left(#?\\right)"), ie("\\log_a", "\\log_{#?}\\left(#?\\right)"), ie("\\sqrt[n]{x}", "\\sqrt[#?]{#0}"), "\\infty", "\\to"],
    [ie("\\sin", "\\sin\\left(#?\\right)"), ie("\\cos", "\\cos\\left(#?\\right)"), ie("\\tan", "\\tan\\left(#?\\right)"), ie("\\arcsin", "\\arcsin\\left(#?\\right)"), "\\pi", "\\theta", "\\Delta", "\\nabla"],
    [ie("f'(x)", "f^{\\prime}(#?)"), ie("\\frac{d^2}{dx^2}", "\\frac{d^2 #?}{d x^2}"), ie("|x|", "\\left|#0\\right|"), ie("\\{\\cdots", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}", "分段函数"), "x", "n", "=", "\\approx"]
  ]) },
  { id: "discrete", label: "离散数学", layout: tn("note-discrete", [
    ["\\neg", "\\land", "\\lor", "\\oplus", "\\implies", "\\iff", "\\forall", "\\exists"],
    ["\\in", "\\notin", "\\subset", "\\subseteq", "\\cup", "\\cap", "\\setminus", "\\varnothing"],
    [ie("\\{x\\}", "\\left\\{#0\\right\\}"), ie("|A|", "\\left|#0\\right|", "集合基数"), "\\mathbb{N}", "\\mathbb{Z}", "\\mathbb{Q}", "\\mathbb{R}", "\\times", "\\mathcal{P}"],
    [ie("\\binom{n}{k}", "\\binom{#?}{#?}", "组合数"), ie("n!", "#0!", "阶乘"), ie("\\sum", "\\sum_{#?}^{#?}#?"), "\\equiv", ie("\\pmod{n}", "\\pmod{#?}", "模运算"), "\\mapsto", "\\vdash", "\\models"]
  ]) },
  { id: "linear", label: "线性代数", layout: tn("note-linear", [
    [ie("\\vec{a}", "\\vec{#0}", "向量"), ie("\\mathbf{A}", "\\mathbf{#0}", "粗体矩阵"), ie("A^{\\mathsf T}", "#0^{\\mathsf T}", "转置"), ie("A^{-1}", "#0^{-1}", "逆矩阵"), ie("\\det A", "\\det\\left(#?\\right)", "行列式"), ie("\\operatorname{rank}", "\\operatorname{rank}\\left(#?\\right)", "秩"), ie("\\operatorname{tr}", "\\operatorname{tr}\\left(#?\\right)", "迹"), "\\lambda"],
    [ie("\\lVert x\\rVert", "\\left\\lVert #0\\right\\rVert", "范数"), ie("\\langle u,v\\rangle", "\\left\\langle #?,#?\\right\\rangle", "内积"), "\\cdot", "\\times", "\\otimes", "\\perp", "\\mathbb{R}", "\\mathbb{C}"],
    [ie("\\operatorname{span}", "\\operatorname{span}\\left(#?\\right)"), ie("\\ker", "\\ker\\left(#?\\right)"), ie("\\operatorname{Im}", "\\operatorname{Im}\\left(#?\\right)"), ie("\\operatorname{diag}", "\\operatorname{diag}\\left(#?\\right)"), "\\alpha", "\\beta", "\\mu", "\\sigma"],
    ["a", "b", "x", "=", "\\sim", "\\cdots", "\\vdots", "\\ddots"]
  ]) },
  { id: "probability", label: "概率统计", layout: tn("note-probability", [
    [ie("P(A)", "P\\left(#?\\right)", "概率"), ie("P(A\\mid B)", "P\\left(#?\\mid #?\\right)", "条件概率"), ie("E(X)", "E\\left(#?\\right)", "期望"), ie("\\operatorname{Var}", "\\operatorname{Var}\\left(#?\\right)", "方差"), ie("\\operatorname{Cov}", "\\operatorname{Cov}\\left(#?,#?\\right)", "协方差"), "\\mu", "\\sigma", "\\rho"],
    [ie("\\bar{x}", "\\bar{#0}", "均值"), ie("\\hat{\\theta}", "\\hat{#0}", "估计量"), ie("\\binom{n}{k}", "\\binom{#?}{#?}"), ie("n!", "#0!"), ie("\\sum", "\\sum_{i=1}^{#?}#?"), ie("\\prod", "\\prod_{i=1}^{#?}#?"), ie("\\frac{1}{n}", "\\frac{1}{#?}"), ie("x^2", "#0^2")],
    [ie("\\mathcal{N}", "\\mathcal{N}\\left(#?,#?\\right)", "正态分布"), ie("\\operatorname{Bin}", "\\operatorname{Bin}\\left(#?,#?\\right)", "二项分布"), ie("\\operatorname{Pois}", "\\operatorname{Pois}\\left(#?\\right)", "泊松分布"), "\\sim", "\\Phi", "\\phi", "\\chi^2", "\\alpha"],
    ["X", "Y", "n", "p", "\\cap", "\\cup", "\\le", "\\ge"]
  ]) },
  { id: "letters", label: "abc", layout: "alphabetic" },
  { id: "greek", label: "αβγ", layout: "greek" }
], vl = [
  ["pmatrix", "圆括号 ( )"],
  ["bmatrix", "方括号 [ ]"],
  ["vmatrix", "行列式 | |"],
  ["Vmatrix", "双竖线 ‖ ‖"],
  ["Bmatrix", "花括号 { }"],
  ["matrix", "无括号"]
];
function wl(t, n, r) {
  if (!Number.isInteger(t) || !Number.isInteger(n) || t < 1 || n < 1 || t > 10 || n > 10) throw new RangeError("Matrix dimensions must be between 1 and 10");
  if (!vl.some(([i]) => i === r)) throw new RangeError("Unsupported matrix style");
  return `\\begin{${r}}${Array.from({ length: t }, () => Array(n).fill("#?").join(" & ")).join(" \\\\ ")}\\end{${r}}`;
}
const Cu = [
  ["basic", "常用"],
  ["letters", "字母"],
  ["calculus", "微积分"],
  ["discrete", "集合与逻辑"],
  ["linear", "线性代数"],
  ["probability", "概率统计"],
  ["relations", "关系与运算"],
  ["arrows", "箭头"],
  ["greek", "希腊字母"],
  ["accents", "修饰与括号"],
  ["fonts", "数学字体"]
], kl = [], Or = /* @__PURE__ */ new Map();
function gt(t, n, r, i = n) {
  const a = Or.get(i);
  if (a) {
    a.categories.includes(t) || a.categories.push(t), a.aliases += ` ${bn(r)}`, !/[\u3400-\u9fff]/.test(a.label) && /[\u3400-\u9fff]/.test(r) && (a.label = r);
    return;
  }
  const l = { id: encodeURIComponent(i), category: t, categories: [t], latex: n, label: r, insert: i, aliases: bn(r, n, i) };
  Or.set(i, l), kl.push(l);
}
for (const t of xu)
  if (!(typeof t.layout == "string" || !("rows" in t.layout)))
    for (const n of t.layout.rows.slice(0, -1)) for (const r of n) {
      const i = typeof r == "string" ? r : r.latex;
      !i || i.startsWith("[") || gt(t.id, i, typeof r == "string" ? r.replaceAll("\\", "") : r.tooltip ?? i.replace(/\\textstyle\s*/g, "").replaceAll("\\", ""), typeof r == "string" ? r : r.insert ?? i);
    }
function Mt(t, n) {
  for (const r of n.split("|")) {
    const [i, a] = r.split(":");
    gt(t, `\\${i}`, a?.split(" ")[0] ?? i), a && (Or.get(`\\${i}`).aliases += ` ${bn(a)}`);
  }
}
Mt("relations", "sim:相似 服从分布 波浪号 similar distributed|approx:约等于 近似等于 approximately|times:乘 叉乘 multiplication|cdot:点乘 点积|otimes:张量积 克罗内克积|perp:垂直 正交|pm:正负|ne:不等于|le:小于等于|ge:大于等于|equiv:恒等 等价|cdots:横向省略号|vdots:竖向省略号|ddots:对角省略号");
Mt("discrete", "neg:逻辑非|land:逻辑与 合取|lor:逻辑或 析取|oplus:异或 直和|implies:蕴含 推出|iff:当且仅当 等价|forall:任意 全称量词|exists:存在 存在量词|in:属于|notin:不属于|subset:真子集|subseteq:子集 包含于|cup:并集|cap:交集|setminus:差集|varnothing:空集|mapsto:映射到|vdash:推导|models:满足 模型");
Mt("relations", "leq:小于等于|geq:大于等于|neq:不等于|ll:远小于|gg:远大于|lesssim:小于或近似|gtrsim:大于或近似|lessapprox:小于或约等于|gtrapprox:大于或约等于|prec:先于|succ:后于|preceq:先于或等于|succeq:后于或等于|simeq:渐近相等|simcolon:相似冒号|simcoloncolon:相似双冒号|cong:全等|asymp:渐近等价|propto:成比例|doteq:定义等于|triangleq:定义等于三角|leqq:小于双等号|geqq:大于双等号|lneq:小于且不等于|gneq:大于且不等于|nless:不小于|ngtr:不大于|nleq:不小于等于|ngeq:不大于等于|ncong:不全等|nsim:不相似|parallel:平行|nparallel:不平行|mid:整除|nmid:不整除|mp:减加|div:除法|ast:星号乘法|star:星形运算|circ:复合运算|bullet:点积实心点|diamond:菱形运算|odot:圈点积|ominus:圈减|oslash:圈除|bigcirc:圆运算|amalg:并合|wr:环绕积|dagger:匕首伴随|ddagger:双匕首|angle:角|measuredangle:有向角|sphericalangle:球面角|degree:度");
Mt("discrete", "ni:包含元素|subsetneq:真子集|supset:超集|supseteq:超集或相等|supsetneq:真超集|nsubseteq:不是子集|nsupseteq:不是超集|emptyset:空集|uplus:不交并|sqcup:方并|sqcap:方交|sqsubseteq:方子集|sqsupseteq:方超集|bigcup:大并集|bigcap:大交集|biguplus:大不交并|bigsqcup:大方并|bigvee:大析取|bigwedge:大合取|wedge:合取|vee:析取|lnot:逻辑非|nexists:不存在|top:真|bot:假|vDash:语义蕴涵|Vdash:强制|dashv:逆推出|nvdash:不可推导|nvDash:不语义蕴涵|therefore:所以|because:因为|aleph:阿列夫基数|beth:贝斯基数|complement:补集|triangleleft:左三角关系|triangleright:右三角关系");
Mt("arrows", "leftarrow:左箭头|rightarrow:右箭头|leftrightarrow:双向箭头|Leftarrow:左双箭头|Rightarrow:右双箭头|Leftrightarrow:左右双箭头|longleftarrow:长左箭头|longrightarrow:长右箭头|longleftrightarrow:长双向箭头|Longleftarrow:长左双箭头|Longrightarrow:长右双箭头|Longleftrightarrow:长左右双箭头|longmapsto:长映射箭头|hookleftarrow:左钩箭头|hookrightarrow:右钩箭头|uparrow:上箭头|downarrow:下箭头|updownarrow:上下箭头|Uparrow:上双箭头|Downarrow:下双箭头|Updownarrow:上下双箭头|nearrow:右上箭头|searrow:右下箭头|swarrow:左下箭头|nwarrow:左上箭头|leftharpoonup:左上鱼叉|leftharpoondown:左下鱼叉|rightharpoonup:右上鱼叉|rightharpoondown:右下鱼叉|rightleftharpoons:可逆反应|leftrightharpoons:左右鱼叉|twoheadrightarrow:满射|twoheadleftarrow:左双头箭头|rightarrowtail:单射尾箭头|leftarrowtail:左尾箭头|rightsquigarrow:波浪箭头|leadsto:导向|curvearrowleft:左弯箭头|curvearrowright:右弯箭头|circlearrowleft:逆时针箭头|circlearrowright:顺时针箭头|nrightarrow:非右箭头|nleftarrow:非左箭头|nRightarrow:不蕴涵|nLeftrightarrow:不等价");
Mt("greek", "alpha:阿尔法 alpha|beta:贝塔 beta|gamma:伽马 gamma|delta:德尔塔 delta|epsilon:艾普西隆 epsilon|zeta:泽塔 zeta|eta:伊塔 eta|theta:西塔 theta|iota:约塔 iota|kappa:卡帕 kappa|lambda:兰姆达 lambda|mu:缪 mu|nu:纽 nu|xi:克西 xi|omicron:奥米克戎 omicron|pi:派 pi|rho:柔 rho|sigma:西格玛 sigma|tau:陶 tau|upsilon:宇普西隆 upsilon|phi:斐 phi|chi:卡 chi|psi:普西 psi|omega:欧米伽 omega|Gamma:大写伽马|Delta:大写德尔塔|Theta:大写西塔|Lambda:大写兰姆达|Xi:大写克西|Pi:大写派|Sigma:大写西格玛|Upsilon:大写宇普西隆|Phi:大写斐|Psi:大写普西|Omega:大写欧米伽|varepsilon:变体艾普西隆|vartheta:变体西塔|varpi:变体派|varrho:变体柔|varsigma:末尾西格玛|varphi:变体斐|varkappa:变体卡帕");
Mt("calculus", "partial:偏导 partial|infty:无穷 infinity|nabla:梯度 nabla|hbar:约化普朗克常量|ell:花体长度|Re:实部|Im:虚部|prime:一阶导撇号");
for (const [t, n] of Object.entries(yl)) gt("calculus", `\\${t}`, `${n} ${t}`, `\\${t}\\left(#?\\right)`);
for (const [t, n] of [["hat", "帽"], ["widehat", "宽帽"], ["bar", "横线"], ["overline", "上划线"], ["underline", "下划线"], ["vec", "向量"], ["overrightarrow", "右向量"], ["overleftarrow", "左向量"], ["overleftrightarrow", "双向量"], ["dot", "一阶点导数"], ["ddot", "二阶点导数"], ["tilde", "波浪修饰"], ["widetilde", "宽波浪"], ["check", "抑扬符"], ["breve", "短音符"], ["acute", "尖音符"], ["grave", "重音符"]]) gt("accents", `\\${t}{x}`, n, `\\${t}{#0}`);
for (const [t, n, r] of [["(", ")", "圆括号"], ["[", "]", "方括号"], ["\\{", "\\}", "集合花括号"], ["|", "|", "绝对值"], ["\\lVert", "\\rVert", "范数"], ["\\langle", "\\rangle", "内积括号"], ["\\lfloor", "\\rfloor", "向下取整"], ["\\lceil", "\\rceil", "向上取整"]]) gt("accents", `\\left${t} x\\right${n}`, r, `\\left${t} #0\\right${n}`);
for (const [t, n, r] of [["mathbb", "NZQRCFHP", "黑板粗体"], ["mathcal", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "花体"], ["mathfrak", "gabh", "哥特体"], ["mathbf", "ABuvx", "粗体"]]) for (const i of n) gt("fonts", `\\${t}{${i}}`, `${r} ${i}`);
for (const [t, n, r] of [
  ["\\underbrace{x+y}_{n}", "下括注", "\\underbrace{#0}_{#?}"],
  ["\\overbrace{x+y}^{n}", "上括注", "\\overbrace{#0}^{#?}"],
  ["\\overset{a}{=}", "上方标注", "\\overset{#?}{#0}"],
  ["\\underset{a}{=}", "下方标注", "\\underset{#?}{#0}"],
  ["\\xrightarrow{f}", "带标注箭头", "\\xrightarrow{#?}"],
  ["\\begin{aligned}a&=b\\\\c&=d\\end{aligned}", "多行对齐方程", "\\begin{aligned}#? &= #? \\\\ #? &= #?\\end{aligned}"]
]) gt("accents", t, n, r);
for (const t of "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") gt("letters", t, `字母 ${t}`);
const ht = kl;
function Su(t) {
  const n = t.trim().toLowerCase().split(/\s+/);
  return ht.filter((r) => n.every((i) => r.aliases.includes(i)));
}
const Ct = "fp:math-preferences-changed";
let Ot;
function tf(t) {
  Ot = t, typeof window < "u" && window.dispatchEvent(new Event(Ct));
}
const ar = {
  getItem(t) {
    if (Ot) return Ot.getItem(t);
    try {
      return globalThis.localStorage?.getItem(t) ?? null;
    } catch {
      return null;
    }
  },
  setItem(t, n) {
    Ot ? Ot.setItem(t, n) : globalThis.localStorage?.setItem(t, n), typeof window < "u" && window.dispatchEvent(new Event(Ct));
  }
};
async function Mu() {
  await Ot?.refresh?.(), typeof window < "u" && window.dispatchEvent(new Event(Ct));
}
const Nl = "fp.math.symbols.v1";
function Ji() {
  try {
    const t = JSON.parse(ar.getItem(Nl) ?? "{}");
    return { favorites: Array.isArray(t.favorites) ? t.favorites.filter((n) => typeof n == "string") : [], recent: Array.isArray(t.recent) ? t.recent.filter((n) => typeof n == "string") : [] };
  } catch {
    return { favorites: [], recent: [] };
  }
}
const Eu = new Map(ht.map((t) => [t.id, La.renderToString(t.latex, { throwOnError: !1, trust: !1, strict: !1 })]));
function $u({ onInsert: t, shortcuts: n, onCommand: r }) {
  const [i, a] = k("basic"), [l, s] = k(""), [c, u] = k({}), [d, p] = k(8), [h, f] = k(Ji), [m, b] = k(null), g = R(null);
  Y(() => {
    const M = () => f(Ji());
    return window.addEventListener(Ct, M), window.addEventListener("storage", M), () => {
      window.removeEventListener(Ct, M), window.removeEventListener("storage", M);
    };
  }, []), Y(() => {
    if (!g.current) return;
    const M = () => {
      const O = g.current?.clientWidth ?? 0;
      p(Math.max(4, Math.min(20, Math.floor(O / 56))));
    };
    M();
    const A = new ResizeObserver(M);
    return A.observe(g.current), () => A.disconnect();
  }, []);
  const v = Ke(() => {
    if (l.trim()) {
      const M = new Set(n.filter((O) => O.trigger.toLowerCase().includes(l.toLowerCase())).map((O) => O.replacement)), A = new Set(Su(l));
      return ht.filter((O) => A.has(O) || M.has(O.insert));
    }
    return i === "recent" ? h.recent.map((M) => ht.find((A) => A.id === M)).filter((M) => !!M) : i === "favorites" ? ht.filter((M) => h.favorites.includes(M.id)) : ht.filter((M) => M.categories.includes(i));
  }, [i, l, h, n]), w = d * (d <= 7 ? 3 : 4), y = l ? `search:${l}` : i, N = Math.max(1, Math.ceil(v.length / w)), x = Math.min(c[y] ?? 0, N - 1), C = v.slice(x * w, (x + 1) * w), z = ht.find((M) => M.id === m), L = z && n.find((M) => M.enabled && M.replacement === z.insert), j = (M) => {
    f(M);
    try {
      ar.setItem(Nl, JSON.stringify(M));
    } catch {
    }
  };
  return /* @__PURE__ */ o("div", { className: "math-symbol-palette", ref: g, children: [
    /* @__PURE__ */ e("div", { className: "math-keyboard-navigation", "aria-label": "键盘操作", children: [["undo", "撤销"], ["redo", "重做"], ["moveToPreviousChar", "←"], ["moveToNextChar", "→"], ["moveToPreviousPlaceholder", "上一空位"], ["moveToNextPlaceholder", "下一空位"], ["deleteBackward", "退格"]].map(([M, A]) => /* @__PURE__ */ e("button", { type: "button", onMouseDown: (O) => O.preventDefault(), onClick: () => r?.(M), children: A }, M)) }),
    /* @__PURE__ */ e("div", { className: "math-symbol-categories", role: "tablist", "aria-label": "符号分类", children: [["recent", "最近"], ["favorites", "收藏"], ...Cu].map(([M, A]) => /* @__PURE__ */ e("button", { type: "button", role: "tab", "aria-selected": !l && i === M, onMouseDown: (O) => O.preventDefault(), onClick: () => {
      a(M), s("");
    }, children: A }, M)) }),
    /* @__PURE__ */ o("div", { className: "math-symbol-search", children: [
      /* @__PURE__ */ e(Ue, { size: 15 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索数学符号", placeholder: "搜索名称、LaTeX 或快捷词", value: l, onChange: (M) => s(M.target.value) }),
      /* @__PURE__ */ o("span", { children: [
        v.length,
        " 项"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "math-symbol-grid", style: { gridTemplateColumns: `repeat(${d}, minmax(0, 1fr))` }, children: C.map((M) => /* @__PURE__ */ o("div", { className: "math-symbol-cell", children: [
      /* @__PURE__ */ e("button", { type: "button", className: "math-symbol-insert", "aria-label": `插入${M.label}`, title: `${M.label} · ${M.insert}`, onMouseDown: (A) => A.preventDefault(), onFocus: () => b(M.id), onMouseEnter: () => b(M.id), onClick: () => {
        t(M.insert), b(M.id), j({ ...h, recent: [M.id, ...h.recent.filter((A) => A !== M.id)].slice(0, 40) });
      }, children: /* @__PURE__ */ e("span", { "aria-hidden": "true", dangerouslySetInnerHTML: { __html: Eu.get(M.id) ?? "" } }) }),
      /* @__PURE__ */ e("button", { type: "button", className: `math-symbol-star${h.favorites.includes(M.id) ? " is-favorite" : ""}`, "aria-label": `${h.favorites.includes(M.id) ? "取消收藏" : "收藏"}${M.label}`, "aria-pressed": h.favorites.includes(M.id), onMouseDown: (A) => A.preventDefault(), onClick: () => j({ ...h, favorites: h.favorites.includes(M.id) ? h.favorites.filter((A) => A !== M.id) : [...h.favorites, M.id] }), children: /* @__PURE__ */ e(Ni, { size: 10 }) })
    ] }, M.id)) }),
    !v.length && /* @__PURE__ */ e("p", { className: "note-math-status", children: l ? "没有找到匹配符号，请尝试名称或 LaTeX 命令。" : i === "favorites" ? "选择符号后点按星标，将常用符号放在这里。" : "使用过的符号会显示在这里。" }),
    /* @__PURE__ */ o("div", { className: "math-symbol-footer", children: [
      z && /* @__PURE__ */ e("button", { type: "button", className: "math-mobile-favorite", "aria-label": `${h.favorites.includes(z.id) ? "取消收藏" : "收藏"}${z.label}`, onClick: () => j({ ...h, favorites: h.favorites.includes(z.id) ? h.favorites.filter((M) => M !== z.id) : [...h.favorites, z.id] }), children: /* @__PURE__ */ e(Ni, { size: 18 }) }),
      /* @__PURE__ */ e("span", { className: "math-symbol-detail", children: z ? /* @__PURE__ */ o(ee, { children: [
        z.label,
        " ",
        /* @__PURE__ */ e("code", { children: z.insert }),
        L && /* @__PURE__ */ o("kbd", { children: [
          L.trigger,
          L.mode === "tab" ? " ⇥" : ""
        ] })
      ] }) : "选中公式片段后，点击符号可替换选区" }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上一页符号", disabled: x === 0, onMouseDown: (M) => M.preventDefault(), onClick: () => u((M) => ({ ...M, [y]: x - 1 })), children: /* @__PURE__ */ e(Wr, { size: 14 }) }),
        /* @__PURE__ */ o("span", { "aria-live": "polite", children: [
          x + 1,
          " / ",
          N
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下一页符号", disabled: x + 1 >= N, onMouseDown: (M) => M.preventDefault(), onClick: () => u((M) => ({ ...M, [y]: x + 1 })), children: /* @__PURE__ */ e(Ae, { size: 14 }) })
      ] })
    ] })
  ] });
}
const xl = "fp.math.shortcuts.v1", zu = { a: "alpha", b: "beta", g: "gamma", d: "delta", e: "epsilon", z: "zeta", h: "eta", t: "theta", i: "iota", k: "kappa", l: "lambda", m: "mu", n: "nu", x: "xi", p: "pi", r: "rho", s: "sigma", u: "upsilon", f: "phi", c: "chi", j: "psi", o: "omega", G: "Gamma", D: "Delta", T: "Theta", L: "Lambda", X: "Xi", P: "Pi", S: "Sigma", U: "Upsilon", F: "Phi", J: "Psi", O: "Omega" }, Cl = [
  { trigger: "mat", replacement: "\\begin{pmatrix}#?\\end{pmatrix}", mode: "tab", enabled: !0, kind: "matrix" },
  ...Object.entries(zu).map(([t, n]) => ({ trigger: `@${t}`, replacement: `\\${n}`, mode: "auto", enabled: !0 })),
  { trigger: "//", replacement: "\\frac{#?}{#?}", mode: "auto", enabled: !0 },
  ...[["sum", "\\sum_{#?}^{#?}#?"], ["lim", "\\lim_{#?\\to #?}#?"], ["sqrt", "\\sqrt{#?}"], ["int", "\\int_{#?}^{#?}#?\\,d x"], ["cases", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}"], ["vec", "\\vec{#?}"], ["frac", "\\frac{#?}{#?}"]].map(([t, n]) => ({ trigger: t, replacement: n, mode: "tab", enabled: !0 }))
];
function Au(t, n) {
  const r = t.match(/(10|[1-9])x(10|[1-9])$/);
  if (!r) return null;
  const i = n.find((a) => a.kind === "matrix" && a.enabled && t.endsWith(a.trigger + r[0]));
  return i ? { length: i.trigger.length + r[0].length, replacement: wl(Number(r[1]), Number(r[2]), "pmatrix") } : null;
}
function Sl(t) {
  const n = /* @__PURE__ */ new Set();
  for (const i of t) {
    if (!i.trigger.trim() || /\s/.test(i.trigger) || i.trigger.length > 40 || !i.replacement.trim()) return "请填写有效的触发词和公式，触发词不能含空格。";
    if (n.has(i.trigger)) return `触发词 ${i.trigger} 重复，请修改。`;
    n.add(i.trigger);
  }
  const r = t.filter((i) => i.enabled && i.mode === "auto");
  for (const i of r) for (const a of r) if (i !== a && a.trigger.startsWith(i.trigger)) return `${i.trigger} 与 ${a.trigger} 会提前触发，请改用 Tab 展开。`;
  return null;
}
function Zi() {
  try {
    const t = JSON.parse(ar.getItem(xl) ?? "null");
    if (Array.isArray(t) && t.every((n) => n && typeof n.trigger == "string" && typeof n.replacement == "string" && ["auto", "tab"].includes(n.mode) && typeof n.enabled == "boolean") && !Sl(t)) return t;
  } catch {
  }
  return Cl.map((t) => ({ ...t }));
}
function Lu(t, n, r) {
  const i = t.inlineShortcuts, a = { ...i };
  for (const u of Object.keys(a))
    (u === "@" || n.some((d) => d.enabled && d.trigger.startsWith(u) && d.trigger !== u)) && delete a[u];
  for (const u of n)
    delete a[u.trigger], u.enabled && u.mode === "auto" && (a[u.trigger] = u.replacement);
  a["*"] = "\\ast", t.inlineShortcuts = a, t.inlineShortcutTimeout = 0;
  let l = [];
  const s = () => {
    l = [];
  }, c = (u) => {
    if (u.isComposing || u.keyCode === 229 || u.ctrlKey || u.metaKey || u.altKey) {
      s();
      return;
    }
    if (u.key === "Tab" && !u.shiftKey) {
      const d = l.map((g) => g.key).join(""), p = [...n].filter((g) => g.enabled && g.mode === "tab" && d.endsWith(g.trigger)).sort((g, v) => v.trigger.length - g.trigger.length)[0], h = Au(d, n), f = p?.replacement ?? h?.replacement, m = p?.trigger.length ?? h?.length ?? 0, b = l[l.length - m]?.position;
      if (f && b !== void 0 && t.position >= b) {
        u.preventDefault(), u.stopImmediatePropagation(), t.selection = { ranges: [[b, t.position]] }, t.insert(f, { selectionMode: "placeholder" }), r(), s();
        return;
      }
    }
    u.key.length === 1 ? (l.push({ key: u.key, position: t.position }), l = l.slice(-64)) : s();
  };
  return t.addEventListener("keydown", c, !0), t.addEventListener("pointerdown", s), t.addEventListener("blur", s), () => {
    t.removeEventListener("keydown", c, !0), t.removeEventListener("pointerdown", s), t.removeEventListener("blur", s), t.isConnected && (t.inlineShortcuts = i);
  };
}
function Iu({ rules: t, onSave: n, onClose: r }) {
  const [i, a] = k(t.map((p) => ({ ...p }))), [l, s] = k(""), [c, u] = k(""), d = (p, h) => {
    a((f) => f.map((m, b) => b === p ? { ...m, ...h } : m)), u("");
  };
  return /* @__PURE__ */ o("section", { className: "math-shortcut-settings", "aria-label": "公式快捷输入设置", children: [
    /* @__PURE__ */ o("div", { className: "math-shortcut-heading", children: [
      /* @__PURE__ */ e("strong", { children: "快捷输入" }),
      /* @__PURE__ */ e("input", { "aria-label": "查找快捷规则", placeholder: "查找触发词或命令", value: l, onChange: (p) => s(p.target.value) }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        a(Cl.map((p) => ({ ...p }))), u("");
      }, children: "恢复默认" })
    ] }),
    /* @__PURE__ */ e("p", { children: "触屏可使用数学键盘；使用实体键盘时，在公式中输入 @a 得到 α；sum 后按 Tab 展开求和。mat3x4 后按 Tab 插入矩阵。Tab / Shift+Tab 切换占位框。" }),
    /* @__PURE__ */ e("div", { className: "math-shortcut-list", children: i.map((p, h) => `${p.trigger} ${p.replacement}`.toLowerCase().includes(l.toLowerCase()) ? /* @__PURE__ */ o("div", { className: "math-shortcut-row", children: [
      /* @__PURE__ */ e("input", { type: "checkbox", "aria-label": `启用规则 ${h + 1}`, checked: p.enabled, onChange: (f) => d(h, { enabled: f.target.checked }) }),
      /* @__PURE__ */ e("input", { "aria-label": `触发词 ${h + 1}`, value: p.trigger, onChange: (f) => d(h, { trigger: f.target.value }) }),
      /* @__PURE__ */ e("input", { "aria-label": `替换公式 ${h + 1}`, readOnly: p.kind === "matrix", value: p.kind === "matrix" ? "接行数 x 列数，例如 3x4（1–10）" : p.replacement, onChange: (f) => d(h, { replacement: f.target.value }) }),
      /* @__PURE__ */ e(Ce, { label: `触发方式 ${h + 1}`, disabled: p.kind === "matrix", value: p.mode, onChange: (f) => d(h, { mode: f }), options: [{ value: "auto", label: "自动" }, { value: "tab", label: "Tab" }] }),
      /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除规则 ${h + 1}`, onClick: () => a((f) => f.filter((m, b) => b !== h)), children: "×" })
    ] }, h) : null) }),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    /* @__PURE__ */ o("div", { className: "math-shortcut-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        s(""), a((p) => [...p, { trigger: "", replacement: "", mode: "tab", enabled: !0 }]);
      }, children: "添加规则" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => a((p) => p.map((h) => ({ ...h, enabled: !1 }))), children: "全部停用" }),
      /* @__PURE__ */ e("span", {}),
      /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "取消" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        const p = Sl(i);
        if (p) {
          u(p);
          return;
        }
        try {
          ar.setItem(xl, JSON.stringify(i));
        } catch {
          u("浏览器无法保存设置，请检查存储权限。");
          return;
        }
        n(i), r();
      }, children: "保存规则" })
    ] })
  ] });
}
function Du({ anchor: t, items: n, activeId: r, onSelect: i, label: a = "输入建议" }) {
  const l = R(null), s = Xt(t, n.length > 0), [c, u] = k({ left: 8, top: 8, maxHeight: 280 });
  return xe(() => {
    if (!n.length) return;
    const d = () => {
      if (!t.current || !l.current) return;
      const p = t.current.getBoundingClientRect(), h = l.current.getBoundingClientRect(), f = innerHeight - p.bottom - 16, m = p.top - 16, b = f < Math.min(h.height, 180) && m > f, g = Math.max(80, Math.min(280, b ? m : f));
      u({ left: Math.max(8, Math.min(p.left, innerWidth - h.width - 8)), top: b ? Math.max(8, p.top - Math.min(h.height, g) - 6) : p.bottom + 6, maxHeight: g });
    };
    return d(), window.addEventListener("resize", d), document.addEventListener("scroll", d, !0), () => {
      window.removeEventListener("resize", d), document.removeEventListener("scroll", d, !0);
    };
  }, [t, n]), xe(() => {
    l.current?.querySelector('[aria-selected="true"]')?.scrollIntoView?.({ block: "nearest" });
  }, [r]), n.length ? Oe(/* @__PURE__ */ e("div", { ref: l, role: "listbox", "aria-label": a, className: "fp-popup-panel fp-suggestion-list", style: { ...s, ...c }, onPointerDown: (d) => d.preventDefault(), children: n.map((d) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": d.id === r, onClick: () => i(d.id), children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: d.label }),
      d.detail && /* @__PURE__ */ e("small", { children: d.detail })
    ] }),
    d.preview && /* @__PURE__ */ e("span", { className: "fp-suggestion-preview", children: d.preview })
  ] }, d.id)) }), document.body) : null;
}
let ea = 0;
function Tu({ anchor: t }) {
  const n = R(null), [r, i] = k([]);
  return Y(() => {
    let a;
    const l = () => {
      const u = n.current, d = t.current?.contains(document.activeElement) && u?.classList.contains("is-visible") ? [...u.querySelectorAll("li[data-command]")].map((p) => {
        const h = p.dataset.command;
        return { id: h, label: ht.find((f) => f.latex === h)?.label || h, markup: p.querySelector(".ML__popover__command")?.innerHTML || "", active: p.classList.contains("ML__popover__current") };
      }) : [];
      i((p) => JSON.stringify(p) === JSON.stringify(d) ? p : d);
    }, s = () => {
      const u = document.getElementById("mathlive-suggestion-popover");
      u !== n.current && (a?.disconnect(), n.current = u, u && (u.setAttribute("aria-hidden", "true"), a = new MutationObserver(l), a.observe(u, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["class", "style"] })), l());
    };
    ea++, document.documentElement.dataset.fpMathCandidates = "true", document.addEventListener("focusin", l), document.addEventListener("focusout", l);
    const c = new MutationObserver(s);
    return c.observe(document.body, { childList: !0 }), s(), () => {
      c.disconnect(), a?.disconnect(), document.removeEventListener("focusin", l), document.removeEventListener("focusout", l), --ea === 0 && (n.current?.removeAttribute("aria-hidden"), delete document.documentElement.dataset.fpMathCandidates);
    };
  }, []), /* @__PURE__ */ e(Du, { anchor: t, label: "公式输入建议", activeId: r.find((a) => a.active)?.id, items: r.map((a) => ({ id: a.id, label: a.label, detail: a.id, preview: /* @__PURE__ */ e("span", { dangerouslySetInnerHTML: { __html: a.markup } }) })), onSelect: (a) => {
    [...n.current?.querySelectorAll("li[data-command]") || []].find((s) => s.dataset.command === a)?.dispatchEvent(new MouseEvent("click", { bubbles: !0 }));
  } });
}
const Ln = /* @__PURE__ */ new WeakMap();
function Ml(t) {
  Ln.get(t)?.();
}
function Pu(t, n, r, i) {
  Ml(t);
  const a = { duration: 220, easing: "cubic-bezier(.2,0,0,1)" }, l = t.animate([{ height: `${r}px`, overflow: "clip" }, { height: `${i}px`, overflow: "clip" }], a), s = t.animate([{ opacity: 0 }, { opacity: 0, offset: 0.35 }, { opacity: 1 }], a), c = n.animate([{ height: `${r}px`, opacity: 1 }, { height: `${i}px`, opacity: 0 }], a), u = () => {
    Ln.get(t) === u && (Ln.delete(t), n.remove(), l.cancel(), s.cancel(), c.cancel());
  };
  Ln.set(t, u), c.onfinish = u, c.oncancel = u;
}
function Fu(t) {
  const n = t.shadowRoot;
  if (!n) return () => {
  };
  const r = {
    deleteContentBackward: "deleteBackward",
    deleteContentForward: "deleteForward",
    deleteWordBackward: "deletePreviousWord",
    deleteWordForward: "deleteNextWord"
  };
  let i, a = !1, l;
  const s = (b) => {
    const g = b;
    l = g.key === "Backspace" || g.key === "Delete" ? g : void 0;
  }, c = () => {
    l = void 0;
  }, u = (b) => {
    const g = l;
    return l = void 0, g?.defaultPrevented && Math.abs(b.timeStamp - g.timeStamp) < 200 && (g.key === "Backspace" && b.inputType.endsWith("Backward") || g.key === "Delete" && b.inputType.endsWith("Forward"));
  }, d = () => {
    a = !0;
  }, p = () => {
    a = !1;
  }, h = (b) => {
    if (!(a || b.isComposing || b.target === t || !(b.target instanceof HTMLElement)))
      return r[b.inputType];
  }, f = (b) => {
    const g = b, v = h(g);
    !v || !g.cancelable || (g.preventDefault(), g.stopImmediatePropagation(), i = g.inputType, queueMicrotask(() => {
      i = void 0;
    }), u(g) || t.executeCommand(v));
  }, m = (b) => {
    const g = b, v = h(g);
    v && (g.stopImmediatePropagation(), g.target.textContent = "", i !== g.inputType && !u(g) && t.executeCommand(v), i = void 0);
  };
  return n.addEventListener("beforeinput", f, !0), n.addEventListener("input", m, !0), n.addEventListener("compositionstart", d, !0), n.addEventListener("compositionend", p, !0), n.addEventListener("keydown", s, !0), n.addEventListener("keyup", c, !0), t.addEventListener("blur", c), () => {
    n.removeEventListener("beforeinput", f, !0), n.removeEventListener("input", m, !0), n.removeEventListener("compositionstart", d, !0), n.removeEventListener("compositionend", p, !0), n.removeEventListener("keydown", s, !0), n.removeEventListener("keyup", c, !0), t.removeEventListener("blur", c);
  };
}
const Ou = [
  ["分数", "\\frac{#0}{#?}"],
  ["根号", "\\sqrt{#0}"],
  ["上标", "#0^{#?}"],
  ["下标", "#0_{#?}"],
  ["积分", "\\int_{#?}^{#?} #? \\,d#?"],
  ["求和", "\\sum_{#?}^{#?} #?"]
], an = /* @__PURE__ */ new WeakMap();
function nf(t, n, r) {
  const i = () => an.set(t, { editor: n, open: r }), a = (l) => {
    (!(l.target instanceof Element) || !l.target.closest(".visual-directive-editor,.fp-card-editor-frame")) && an.delete(t);
  };
  return n.on("focus", i), t.view.dom.addEventListener("pointerdown", a, !0), i(), () => {
    n.off("focus", i), t.view.dom.removeEventListener("pointerdown", a, !0), an.get(t)?.editor === n && an.delete(t);
  };
}
function rf(t, n, r) {
  const i = an.get(t);
  i && !i.editor.isDestroyed && i.editor.view.dom.isConnected ? i.open(i.editor, n) : r(t, n);
}
function gr(t) {
  ti.getState(t.state)?.undoManager.stopCapturing(), t.view.dispatch(ei(t.state.tr));
}
function Ru() {
  const [t, n] = k(null), r = R(null), i = De((l) => {
    if (l && r.current?.id !== l) return;
    const s = r.current;
    r.current = null, n(null), s && !s.editor.isDestroyed && (An(s.editor, s.host.mathPosition()), gr(s.editor));
  }, []);
  return {
    open: De(
      (l, s, c, u) => {
        if (!l.isEditable) return;
        if (c === void 0) {
          gr(l);
          const f = u ?? l.state.selection;
          l.chain().insertContentAt(
            { from: f.from, to: f.to },
            {
              type: s ? "blockMath" : "inlineMath",
              attrs: { latex: "" }
            }
          ).command(({ tr: m }) => (m.mapping.maps.at(-1)?.forEach((b, g, v, w) => {
            m.doc.nodesBetween(v, w, (y, N) => {
              if (y.type.name === (s ? "blockMath" : "inlineMath"))
                return c = N, !1;
            });
          }), !0)).run();
        }
        if (c === void 0) return;
        const d = l.view.nodeDOM(c), p = d?.querySelector(".math-node-editor-slot");
        if (!d?.mathPosition || !p || r.current?.host === d)
          return;
        i(), gr(l);
        const h = {
          id: crypto.randomUUID(),
          editor: l,
          display: s,
          host: d,
          slot: p,
          collapsedHeight: d.getBoundingClientRect().height,
          original: String(l.state.doc.nodeAt(c)?.attrs.latex ?? "")
        };
        r.current = h, n(h);
      },
      [i]
    ),
    card: t ? /* @__PURE__ */ e(Bu, { session: t, onClose: i }, t.id) : null
  };
}
function Bu({
  session: t,
  onClose: n
}) {
  const r = De(
    () => n(t.id),
    [n, t.id]
  ), [i, a] = k(t.original), l = R(t.original), [s, c] = k(!1), [u, d] = k(
    "loading"
  ), [p, h] = k(
    () => typeof window < "u" && !!window.matchMedia?.("(pointer: coarse)").matches
  ), [f, m] = k(!1), [b, g] = k(Zi), v = R(!1), w = R(!1), y = R(!1), [N, x] = k(!1), [C, z] = k(3), [L, j] = k(3), [M, A] = k("pmatrix"), [O, U] = k(""), T = R(null), E = R(null), S = R(null), P = R(null), _ = De(
    ($) => {
      const B = t.host.mathPosition();
      if (B === void 0 || t.editor.isDestroyed) return;
      const J = t.editor.state.doc.nodeAt(B);
      !J || !["inlineMath", "blockMath"].includes(J.type.name) || (l.current = $, a($), J.attrs.latex !== $ && t.editor.view.dispatch(
        t.editor.state.tr.setNodeMarkup(B, void 0, {
          ...J.attrs,
          latex: $
        })
      ));
    },
    [t]
  );
  xe(() => {
    (P.current || T.current)?.focus();
    const $ = () => {
      if (document.activeElement === document.body && t.host.isConnected) {
        const le = S.current;
        (le?.parentElement?.hidden === !1 ? le : P.current || T.current)?.focus();
      }
    }, B = new MutationObserver($);
    B.observe(document.body, { childList: !0, subtree: !0 }), queueMicrotask($), Ml(
      t.display ? t.host : t.host.closest("p, li, td") || t.host
    ), t.host.classList.add("is-math-editing"), t.host.setAttribute("draggable", "false");
    const J = t.display ? null : t.host.closest("p"), Z = t.editor.view.dom, Ne = Z.style.getPropertyValue(
      "--fp-inline-math-space"
    ), pe = () => {
      J && Z.style.setProperty(
        "--fp-inline-math-space",
        `${t.slot.getBoundingClientRect().height + 12}px`
      );
    };
    pe();
    const V = J && typeof ResizeObserver < "u" ? new ResizeObserver(pe) : null;
    V?.observe(t.slot);
    const K = () => {
      const le = t.host.mathPosition();
      if (le === void 0 || !t.host.isConnected) {
        r();
        return;
      }
      const fe = t.editor.state.doc.nodeAt(le);
      if (!fe || !["inlineMath", "blockMath"].includes(fe.type.name)) {
        r();
        return;
      }
      const se = String(fe.attrs.latex ?? "");
      se !== l.current && (l.current = se, a(se), S.current?.setValue(se, { silenceNotifications: !0 }));
    }, re = (le) => {
      !t.host.contains(le.target) && !le.target.closest?.(".fp-popup-panel, #mathlive-suggestion-popover") && r();
    };
    return t.editor.on("transaction", K), t.editor.on("destroy", r), document.addEventListener("pointerdown", re), () => {
      B.disconnect();
      const le = t.host, fe = t.display ? le : le.closest("p, li, td") || le, se = fe.getBoundingClientRect(), we = fe.cloneNode(!0);
      we.querySelectorAll("math-field").forEach((D) => {
        const G = le.querySelector(".math-node-content")?.cloneNode(!0);
        G ? (G.style.display = "block", D.replaceWith(G)) : D.remove();
      }), V?.disconnect(), t.slot.style.display = "none";
      const W = Z.style.getPropertyValue(
        "--fp-inline-math-space"
      );
      Ne ? Z.style.setProperty("--fp-inline-math-space", Ne) : Z.style.removeProperty("--fp-inline-math-space"), le.classList.remove("is-math-editing");
      const F = fe.getBoundingClientRect();
      if (t.slot.style.removeProperty("display"), fe.isConnected && typeof fe.animate == "function" && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
        const D = document.createElement("div");
        D.className = "fp-markdown-editor fp-formula-closing", D.style.setProperty("--fp-inline-math-space", W), D.inert = !0, D.setAttribute("aria-hidden", "true"), Object.assign(D.style, {
          position: "absolute",
          left: `${se.left + window.scrollX}px`,
          top: `${se.top + window.scrollY}px`,
          width: `${se.width}px`,
          maxWidth: `calc(100vw - ${Math.max(0, se.left)}px)`,
          height: `${se.height}px`,
          overflow: "clip",
          pointerEvents: "none",
          zIndex: "20"
        }), we.style.margin = "0", we.querySelectorAll("[id]").forEach((de) => de.removeAttribute("id"));
        const G = document.createElement("div");
        G.className = "fp-editor-prose", Object.assign(G.style, { padding: "0", minHeight: "0" }), G.append(we), D.append(G), document.body.append(D), Pu(fe, D, se.height, F.height);
      }
      t.editor.off("transaction", K), t.editor.off("destroy", r), document.removeEventListener("pointerdown", re);
    };
  }, [t, r]), Y(() => {
    let $ = !0, B = () => {
    };
    return document.documentElement.dataset.mathEditing = "true", document.dispatchEvent(new Event("fp:math-open")), (async () => {
      try {
        const { MathfieldElement: J } = await import("mathlive");
        if (await Promise.resolve({                   }), !$ || !E.current) return;
        const Z = new J();
        Z.className = "note-math-live", Z.mathVirtualKeyboardPolicy = "manual", Z.smartFence = !0, Z.smartMode = !1, Z.environmentPopoverPolicy = "off", Z.maxMatrixCols = 10, Z.setAttribute("aria-label", "公式内容");
        const Ne = new Promise(
          (le) => Z.addEventListener("mount", () => le(), { once: !0 })
        );
        if (E.current.append(Z), B = () => {
          Z.remove(), S.current = null;
        }, await Ne, w.current && P.current && await new Promise((le) => P.current?.addEventListener("compositionend", () => le(), { once: !0 })), !$) return;
        Z.menuItems = [], Z.setValue(l.current, { silenceNotifications: !0 }), S.current = Z;
        const pe = Fu(Z), V = window.mathVirtualKeyboard;
        V.hide();
        const K = () => _(Z.getValue("latex-unstyled"));
        Z.addEventListener("input", K);
        const re = () => {
          v.current = !1;
        };
        Z.addEventListener("focus", re), B = () => {
          V.hide(), pe(), Z.removeEventListener("input", K), Z.removeEventListener("focus", re), Z.remove(), S.current = null;
        }, y.current = P.current?.getAttribute("aria-label") === "LaTeX 源码" && document.activeElement === P.current, d("ready");
      } catch (J) {
        B(), console.warn("Formula input initialization failed", J), $ && (d("fallback"), c(!0));
      }
    })(), () => {
      $ = !1, B(), delete document.documentElement.dataset.mathEditing;
    };
  }, [_]), xe(() => {
    u === "ready" && !y.current && S.current?.focus();
  }, [u]), Y(() => {
    const $ = () => g(Zi()), B = () => {
      Mu();
    };
    return window.addEventListener(Ct, $), window.addEventListener("storage", $), window.addEventListener("focus", B), B(), () => {
      window.removeEventListener(Ct, $), window.removeEventListener("storage", $), window.removeEventListener("focus", B);
    };
  }, []), Y(() => {
    if (u !== "ready" || !S.current) return;
    const $ = S.current;
    return Lu(
      $,
      b,
      () => _($.getValue("latex-unstyled"))
    );
  }, [u, b, _]);
  const q = ($) => {
    const B = S.current;
    if (!B) return;
    B.focus();
    const J = B.executeCommand($);
    U(J ? "" : "请将光标放在矩阵内；每行最多 10 列。"), J && _(B.getValue("latex-unstyled"));
  }, H = ($ = !1) => {
    $ || _(S.current?.getValue("latex-unstyled") ?? P.current?.value ?? l.current);
    const B = t.editor, J = t.host.mathPosition();
    if (J === void 0 || B.isDestroyed) {
      r();
      return;
    }
    const Z = B.state.doc.nodeAt(J);
    if ($ && Z && B.commands.deleteRange({ from: J, to: J + Z.nodeSize }), r(), !B.isDestroyed) {
      const Ne = Math.min(
        J + ($ ? 0 : Z?.nodeSize ?? 0),
        B.state.doc.content.size
      );
      B.view.dispatch(
        B.state.tr.setSelection(
          Pn.near(B.state.doc.resolve(Ne), 1)
        )
      ), B.view.focus();
    }
  };
  xe(() => {
    const $ = T.current, B = () => H();
    return $?.addEventListener("fp-commit-editor-input", B), () => $?.removeEventListener("fp-commit-editor-input", B);
  });
  const I = ($) => {
    const B = S.current;
    if (B && !v.current)
      B.focus(), B.insert($, { selectionMode: "placeholder" }), _(B.getValue("latex-unstyled"));
    else {
      const J = P.current, Z = J?.selectionStart ?? l.current.length, Ne = J?.selectionEnd ?? Z, pe = $.replaceAll("#0", l.current.slice(Z, Ne)).replaceAll("#?", ""), V = l.current.slice(0, Z) + pe + l.current.slice(Ne);
      _(V), B?.setValue(V, { silenceNotifications: !0 }), J?.focus(), requestAnimationFrame(
        () => J?.setSelectionRange(Z + pe.length, Z + pe.length)
      );
    }
  };
  return Oe(
    /* @__PURE__ */ o(ge, { initialHeight: t.collapsedHeight, children: [
      /* @__PURE__ */ e(Tu, { anchor: E }),
      /* @__PURE__ */ o(
        "div",
        {
          className: "note-math-card inline-card-expansion",
          ref: T,
          role: "group",
          "aria-label": t.display ? "编辑独立公式" : "编辑行内公式",
          tabIndex: -1,
          onPointerDown: ($) => {
            An(t.editor, t.host.mathPosition()), $.stopPropagation();
          },
          onClick: ($) => $.stopPropagation(),
          onDoubleClick: ($) => $.stopPropagation(),
          onContextMenu: ($) => $.stopPropagation(),
          onBeforeInputCapture: ($) => {
            const B = $.nativeEvent, J = t.host.mathPosition();
            B.isComposing || w.current || (B.data === "$" && J !== void 0 && l.current === "" && sn(t.editor, J) ? ($.preventDefault(), $.stopPropagation()) : An(t.editor, J));
          },
          onKeyDownCapture: ($) => {
            if ($.nativeEvent.isComposing || $.nativeEvent.keyCode === 229)
              return;
            const B = t.host.mathPosition();
            if ($.key === "$" && !$.ctrlKey && !$.metaKey && !$.altKey && B !== void 0 && l.current === "" && sn(t.editor, B)) {
              $.preventDefault(), $.stopPropagation();
              return;
            }
            if (["Shift", "Control", "Meta", "Alt"].includes($.key) || An(t.editor, B), u === "loading" && $.target !== P.current && $.key.length === 1 && !$.ctrlKey && !$.metaKey && !$.altKey) {
              $.preventDefault(), $.stopPropagation(), _(l.current + $.key);
              return;
            }
            if (!($.target === S.current && S.current?.mode === "latex" && !$.ctrlKey && !$.metaKey)) {
              if (!t.display && $.key === "Enter" && !$.shiftKey && !($.target instanceof HTMLButtonElement)) {
                $.preventDefault(), $.stopPropagation(), H();
                return;
              }
              if (t.display && $.key === "Enter" && !$.ctrlKey && !$.metaKey && $.target === S.current) {
                $.preventDefault(), $.stopPropagation(), S.current?.executeCommand("addRowAfter"), S.current && _(S.current.getValue("latex-unstyled"));
                return;
              }
              ($.key === "Escape" || $.key === "Enter" && ($.ctrlKey || $.metaKey)) && ($.preventDefault(), $.stopPropagation(), H());
            }
          },
          onKeyDown: ($) => $.stopPropagation(),
          children: [
            /* @__PURE__ */ o("div", { className: "note-math-topline", children: [
              /* @__PURE__ */ o("span", { className: "note-math-title", children: [
                "∑ ",
                /* @__PURE__ */ e("span", { children: t.display ? "独立公式" : "行内公式" })
              ] }),
              /* @__PURE__ */ o("div", { className: "note-math-controls", children: [
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    title: "LaTeX 源码",
                    "aria-label": "LaTeX 源码",
                    "aria-expanded": s,
                    disabled: u === "fallback",
                    onClick: () => c(($) => !$),
                    children: [
                      /* @__PURE__ */ e(Ur, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "源码" })
                    ]
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    "aria-label": "数学键盘",
                    "aria-expanded": p,
                    onClick: () => {
                      h(($) => !$), window.mathVirtualKeyboard?.hide();
                    },
                    children: [
                      /* @__PURE__ */ e(ba, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "键盘" })
                    ]
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "快捷输入设置",
                    "aria-expanded": f,
                    onClick: () => m(($) => !$),
                    children: /* @__PURE__ */ e(mo, { size: 15 })
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "note-math-delete",
                    title: "删除公式",
                    "aria-label": "删除公式",
                    onClick: () => H(!0),
                    children: /* @__PURE__ */ e(Gt, { size: 15 })
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    className: "note-math-done",
                    "aria-label": "收起",
                    title: "收起 · Ctrl/⌘+Enter",
                    onClick: () => H(),
                    children: [
                      /* @__PURE__ */ e(Ie, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "完成" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-writing", children: [
              u === "loading" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "正在准备公式输入…" }),
              /* @__PURE__ */ e(
                "div",
                {
                  ref: E,
                  className: "note-math-live-host",
                  hidden: u !== "ready"
                }
              ),
              (s || u === "loading") && /* @__PURE__ */ o("label", { className: "note-math-source-label", children: [
                "LaTeX",
                /* @__PURE__ */ e(
                  "textarea",
                  {
                    ref: P,
                    "aria-label": u === "loading" ? "公式内容" : "LaTeX 源码",
                    className: "note-math-source",
                    rows: 2,
                    value: i,
                    spellCheck: !1,
                    onCompositionStart: () => {
                      w.current = !0;
                    },
                    onCompositionEnd: () => {
                      w.current = !1;
                    },
                    onFocus: () => {
                      v.current = !0;
                    },
                    onChange: ($) => {
                      _($.target.value), S.current?.setValue($.target.value, {
                        silenceNotifications: !0
                      });
                    }
                  }
                )
              ] }),
              u === "fallback" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "可直接输入 LaTeX 公式。" })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-tools", role: "toolbar", "aria-label": "公式结构", children: [
              Ou.map(([$, B]) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  disabled: u === "loading" && !s,
                  onMouseDown: (J) => J.preventDefault(),
                  onClick: () => I(B),
                  children: $
                },
                $
              )),
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-expanded": N,
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => {
                    x(($) => !$), U("");
                  },
                  children: [
                    /* @__PURE__ */ e(bo, { size: 14 }),
                    "矩阵"
                  ]
                }
              )
            ] }),
            N && /* @__PURE__ */ o(
              "div",
              {
                className: "note-matrix-builder",
                role: "group",
                "aria-label": "矩阵设置",
                children: [
                  /* @__PURE__ */ o("div", { className: "note-matrix-settings", children: [
                    /* @__PURE__ */ o("label", { children: [
                      "行",
                      /* @__PURE__ */ e(
                        Ce,
                        {
                          label: "矩阵行数",
                          value: String(C),
                          onChange: ($) => z(Number($)),
                          options: Array.from({ length: 10 }, ($, B) => ({
                            value: String(B + 1),
                            label: String(B + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "×" }),
                    /* @__PURE__ */ o("label", { children: [
                      "列",
                      /* @__PURE__ */ e(
                        Ce,
                        {
                          label: "矩阵列数",
                          value: String(L),
                          onChange: ($) => j(Number($)),
                          options: Array.from({ length: 10 }, ($, B) => ({
                            value: String(B + 1),
                            label: String(B + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o("label", { children: [
                      "括号",
                      /* @__PURE__ */ e(
                        Ce,
                        {
                          label: "矩阵括号",
                          value: M,
                          onChange: ($) => A($),
                          options: vl.map(([$, B]) => ({
                            value: $,
                            label: B
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        className: "note-matrix-insert",
                        disabled: u === "loading" && !s,
                        onMouseDown: ($) => $.preventDefault(),
                        onClick: () => {
                          I(
                            wl(C, L, M)
                          ), x(!1);
                        },
                        children: [
                          "插入 ",
                          C,
                          " × ",
                          L
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-presets", children: [
                    /* @__PURE__ */ e("span", { children: "常用" }),
                    [
                      [1, 3],
                      [3, 1],
                      [2, 2],
                      [3, 3],
                      [4, 4],
                      [3, 4]
                    ].map(([$, B]) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": C === $ && L === B,
                        onClick: () => {
                          z($), j(B);
                        },
                        children: [
                          $,
                          " × ",
                          B
                        ]
                      },
                      `${$}-${B}`
                    ))
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-actions", children: [
                    /* @__PURE__ */ e("span", { children: "光标所在矩阵" }),
                    [
                      ["增行", "addRowAfter"],
                      ["增列", "addColumnAfter"],
                      ["删行", "removeRow"],
                      ["删列", "removeColumn"]
                    ].map(([$, B]) => /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        disabled: u !== "ready" || s,
                        onMouseDown: (J) => J.preventDefault(),
                        onClick: () => q(B),
                        children: $
                      },
                      B
                    ))
                  ] }),
                  O && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: O })
                ]
              }
            ),
            t.display && /* @__PURE__ */ o("div", { className: "note-math-line-actions", children: [
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => {
                    const $ = S.current;
                    $ && ($.focus(), $.executeCommand("addRowAfter"), _($.getValue("latex-unstyled")));
                  },
                  children: [
                    /* @__PURE__ */ e(pa, { size: 14 }),
                    "换行"
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => I("\\begin{aligned}#0 &= #? \\\\ #? &= #?\\end{aligned}"),
                  children: "对齐多行"
                }
              ),
              /* @__PURE__ */ e("span", { children: "Enter 换行 · Ctrl/⌘+Enter 完成" })
            ] }),
            f && /* @__PURE__ */ e(
              Iu,
              {
                rules: b,
                onSave: g,
                onClose: () => m(!1)
              }
            ),
            p && /* @__PURE__ */ e(
              $u,
              {
                onInsert: I,
                shortcuts: b,
                onCommand: ($) => {
                  const B = S.current;
                  B && (B.focus(), B.executeCommand($), _(B.getValue("latex-unstyled")));
                }
              }
            )
          ]
        }
      )
    ] }),
    t.slot
  );
}
function ju(t) {
  const { node: n, updateAttributes: r, editor: i, deleteNode: a, getPos: l } = t, [s, c] = k(() => Oa(i, n.attrs.id)), u = R(null), d = R(!1), p = () => {
    c(!1), Ws(i, l);
  }, h = R(null), f = R(String(n.attrs.body || ""));
  Y(() => {
    s && (Us(i, n.attrs.id), requestAnimationFrame(() => u.current?.focus()));
  }, [s]), Y(() => {
    const b = String(n.attrs.body || "");
    h.current && !h.current.isDestroyed && b !== f.current && (h.current.commands.setContent(gl(b), {
      emitUpdate: !1
    }), f.current = b);
  }, [n.attrs.body]);
  const m = String(n.attrs.name);
  return /* @__PURE__ */ o(
    Ft,
    {
      onKeyDownCapture: (b) => {
        s && !b.nativeEvent.isComposing && b.nativeEvent.keyCode !== 229 && !b.repeat && b.key === "Enter" && (b.ctrlKey || b.metaKey) && Fa(b.nativeEvent, b.currentTarget) && (b.preventDefault(), b.stopPropagation(), p());
      },
      className: "fp-directive-node",
      contentEditable: !1,
      "data-selected": t.selected || void 0,
      "data-card-type": m,
      "data-nested-editor-boundary": s ? "" : void 0,
      children: [
        /* @__PURE__ */ o("div", { className: "fp-directive-heading", contentEditable: !1, "data-nested-editor-boundary": "", children: [
          /* @__PURE__ */ e(
            Ce,
            {
              label: "卡片类型",
              value: m,
              disabled: !i.isEditable,
              onChange: (b) => {
                const g = Vi(n.attrs.attributes, m);
                r({
                  name: b,
                  attributes: Gi(
                    n.attrs.attributes,
                    b,
                    g
                  )
                });
              },
              options: ou.map(([b, g]) => ({
                value: b,
                label: g
              }))
            }
          ),
          i.isEditable && /* @__PURE__ */ o("span", { className: "fp-directive-actions", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": s ? "完成卡片编辑" : "编辑卡片内容",
                onClick: () => s ? p() : c(!0),
                children: s ? /* @__PURE__ */ e(Ie, { size: 14 }) : /* @__PURE__ */ e(Yn, { size: 14 })
              }
            ),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "删除卡片", onClick: a, children: /* @__PURE__ */ e(Gt, { size: 14 }) })
          ] })
        ] }),
        s && /* @__PURE__ */ e(
          "input",
          {
            ref: u,
            onKeyDown: (b) => {
              b.key === "Enter" && !b.nativeEvent.isComposing && !b.ctrlKey && !b.metaKey && (b.preventDefault(), b.stopPropagation(), h.current ? h.current.commands.focus("start") : d.current = !0);
            },
            "aria-label": "卡片标题",
            value: Vi(n.attrs.attributes, m),
            disabled: !i.isEditable,
            placeholder: "添加标题",
            onChange: (b) => r({
              attributes: Gi(
                n.attrs.attributes,
                m,
                b.target.value
              )
            })
          }
        ),
        /* @__PURE__ */ o(ge, { children: [
          s && /* @__PURE__ */ e(
            Xs,
            {
              name: m,
              value: String(n.attrs.attributes || ""),
              onChange: (b) => r({ attributes: b }),
              disabled: !i.isEditable
            }
          ),
          " ",
          s ? /* @__PURE__ */ e(
            lr,
            {
              allowCards: !1,
              markdown: String(n.attrs.body || ""),
              editable: i.isEditable,
              onOpenLink: t.onOpenLink,
              resolveResourceUrl: t.resolveResourceUrl,
              toolbar: !0,
              onReady: (b) => {
                h.current = b, d.current && (d.current = !1, b.commands.focus("start"));
              },
              onChange: (b) => {
                f.current = b, r({ body: b });
              }
            }
          ) : /* @__PURE__ */ e(
            Nt,
            {
              resolveResourceUrl: t.resolveResourceUrl,
              markdown: ":::" + m + (n.attrs.attributes ? "{" + n.attrs.attributes + "}" : "") + `
` + String(n.attrs.body || "") + `
:::`
            }
          )
        ] })
      ]
    }
  );
}
function lr(t) {
  const {
    markdown: n = "",
    documentKey: r = "default",
    document: i,
    provider: a,
    user: l,
    editable: s = !0,
    placeholder: c = "写下你的理解…",
    extensions: u = [],
    status: d
  } = t, p = R(t);
  p.current = t;
  const h = Ru(), f = R(null), m = R(h);
  m.current = h;
  const [b, g] = k(null), [v, w] = k(null), [y, N] = k([]), [x, C] = k(0), [z, L] = k(""), j = R({ suggestion: v, suggestions: y, suggestionActive: x });
  j.current = { suggestion: v, suggestions: y, suggestionActive: x }, Y(() => {
    const I = new AbortController();
    if (N([]), C(0), L(""), !v || !t.getSuggestions) return () => I.abort();
    const $ = setTimeout(() => {
      t.getSuggestions(
        v.query,
        v.kind,
        I.signal
      ).then((B) => {
        I.signal.aborted || N(B);
      }).catch(() => {
        I.signal.aborted || L("暂时无法查找，请继续输入或重试。");
      });
    }, 180);
    return () => {
      clearTimeout($), I.abort();
    };
  }, [v?.query, v?.kind, t.getSuggestions]), Y(() => {
    const I = () => g(($) => $ && { ...$ });
    return window.addEventListener(zr, I), () => window.removeEventListener(zr, I);
  }, []);
  const M = R(b);
  M.current = b;
  const A = (I) => Kd(I).filter(($) => !(["attachment", "video"].includes($[0]) && !t.onAttachment) && !($[0] === "interactive" && !t.onInteractive) && !(t.allowCards === !1 && ($[0] === "card" || Mn($[0]))));
  function O(I) {
    const { $from: $, from: B, empty: J } = I.state.selection, Z = J && I.isEditable && !$.parent.type.spec.code ? $.parent.textBetween(0, $.parentOffset).match(/(?:^|\s)\/([^\s/]*)$/u) : null, Ne = $.parent.textBetween(0, $.parentOffset), pe = t.getSuggestions && J && I.isEditable && !$.parent.type.spec.code ? Ne.match(/(?:^|\s)(#([^\s#]*)|\[\[([^\]\n]*))$/u) : null;
    if (pe) {
      const K = I.view.coordsAtPos(B), re = pe[2] !== void 0 ? "tag" : "link", le = pe[2] ?? pe[3];
      w({
        from: B - le.length - (re === "tag" ? 1 : 2),
        to: B,
        kind: re,
        query: le,
        top: Math.max(8, Math.min(K.bottom + 6, window.innerHeight - 290)),
        left: Math.max(8, Math.min(K.left, window.innerWidth - 280))
      });
    } else w(null);
    if (!Z) {
      g(null);
      return;
    }
    const V = I.view.coordsAtPos(B);
    g((K) => ({
      from: B - Z[1].length - 1,
      to: B,
      query: Z[1],
      top: Math.max(8, Math.min(V.bottom + 6, window.innerHeight - 300)),
      left: Math.max(8, Math.min(V.left, window.innerWidth - 272)),
      active: K?.query === Z[1] ? K.active : 0
    }));
  }
  function U(I) {
    const $ = f.current, B = M.current;
    !$ || !B || p.current.allowCards === !1 && (I === "card" || Mn(I)) || (g(null), Gs(I), $.chain().focus().deleteRange(B).run(), I === "text" ? $.commands.setParagraph() : /^h[1-6]$/.test(I) ? $.commands.setHeading({ level: Number(I[1]) }) : I === "bullet" ? $.commands.toggleBulletList() : I === "ordered" ? $.commands.toggleOrderedList() : I === "quote" ? $.commands.toggleBlockquote() : I === "code" ? $.commands.toggleCodeBlock() : Wi(I) !== void 0 ? $.commands.setCodeBlock({ language: Wi(I) || "" }) : Mn(I) ? ur($, Mn(I)) : I === "divider" ? $.commands.setHorizontalRule() : Pr(I) ? $.commands.insertTable({ ...Pr(I), withHeaderRow: !0 }) : I === "table" ? $.commands.insertTable({ rows: 3, cols: 3, withHeaderRow: !0 }) : I === "inlineMath" || I === "math" ? m.current.open($, I === "math") : I === "card" ? ur($) : I === "mermaid" ? ll($) : I === "interactive" ? p.current.onInteractive?.($) : (I === "attachment" || I === "video") && p.current.onAttachment?.(
      $,
      I === "video" ? "video" : "file"
    ));
  }
  function T(I) {
    const $ = f.current, B = j.current.suggestion;
    !$ || !B || ($.chain().focus().deleteRange({ from: B.from, to: B.to }).run(), B.kind === "link" && I.href ? $.chain().insertContent({
      type: "text",
      text: I.label,
      marks: [{ type: "link", attrs: { href: I.href } }]
    }).run() : $.commands.insertContent({
      type: "text",
      text: I.insertText ?? (B.kind === "tag" ? `#${I.label} ` : I.label)
    }), w(null));
  }
  const [E, S] = k(null), [P, _] = k([]), q = R({ mode: E, marks: P });
  q.current = { mode: E, marks: P };
  const H = ps(
    {
      immediatelyRender: !1,
      editable: s,
      extensions: [
        Rd,
        ...(t.baseExtensions || pi(
          !i,
          void 0,
          fl.extend({
            addNodeView: () => nn(
              (I) => p.current.renderDirective ? /* @__PURE__ */ e(Ft, { children: p.current.renderDirective(I) }) : /* @__PURE__ */ e(
                ju,
                {
                  ...I,
                  onOpenLink: p.current.onOpenLink,
                  resolveResourceUrl: p.current.resolveResourceUrl
                }
              ),
              tl
            )
          }),
          wu({
            onInlineClick: (I, $) => f.current && m.current.open(f.current, !1, $),
            onBlockClick: (I, $) => f.current && m.current.open(f.current, !0, $)
          }),
          bl.extend({
            addNodeView: () => nn(
              ({ node: I, editor: $, deleteNode: B }) => /* @__PURE__ */ o(Ft, { className: "fp-attachment-node", children: [
                /* @__PURE__ */ e(nt, { size: 20 }),
                /* @__PURE__ */ e("span", { children: String(I.attrs.name) }),
                p.current.onOpenAttachment && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    onClick: () => p.current.onOpenAttachment?.({
                      name: I.attrs.name,
                      url: I.attrs.url,
                      mediaType: I.attrs.mediaType
                    }),
                    children: "查看附件"
                  }
                ),
                $.isEditable && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "删除附件",
                    onClick: B,
                    children: /* @__PURE__ */ e(Gt, { size: 14 })
                  }
                )
              ] })
            )
          }),
          md
        )).map(
          (I) => I.name === "image" ? I.configure({
            resolveUrl: ($) => p.current.resolveResourceUrl?.($) || $
          }) : I.name === "uploadPlaceholder" ? hl.extend({
            addNodeView: () => nn(({ node: $, deleteNode: B }) => /* @__PURE__ */ o(
              Ft,
              {
                className: "fp-editor-upload",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e("strong", { children: String($.attrs.name) }),
                  /* @__PURE__ */ e("p", { role: $.attrs.error ? "alert" : "status", children: $.attrs.error || "正在上传…" }),
                  f.current?.isEditable && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    $.attrs.error && p.current.onUploadAction && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onUploadAction?.(
                          String($.attrs.uploadId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          p.current.onUploadAction?.(
                            String($.attrs.uploadId),
                            "cancel"
                          ), B();
                        },
                        children: "取消上传"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : I.name === "imageConversion" ? pl.extend({
            addNodeView: () => nn(({ node: $ }) => /* @__PURE__ */ o(
              Ft,
              {
                className: "fp-editor-conversion",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e(
                    "img",
                    {
                      src: p.current.resolveResourceUrl?.(
                        $.attrs.src
                      ) || $.attrs.src,
                      alt: $.attrs.alt || "识别中的图片"
                    }
                  ),
                  /* @__PURE__ */ e("p", { role: $.attrs.error ? "alert" : "status", children: $.attrs.error || ($.attrs.markdown ? "内容已识别" : "正在识别图片…") }),
                  f.current?.isEditable && p.current.onConversionAction && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    $.attrs.markdown && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "insert"
                        ),
                        children: "插入识别内容"
                      }
                    ),
                    $.attrs.error && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "keep-image"
                        ),
                        children: "保留图片"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : I
        ),
        ys.configure({ placeholder: c }),
        ...t.allowCards === !1 ? [_s] : [],
        ...i ? [bs.configure({ document: i })] : [],
        ...a && l ? [gs.configure({ provider: a, user: l })] : [],
        ...u
      ],
      content: i ? void 0 : t.content ?? gl(n),
      onCreate: ({ editor: I }) => p.current.onReady?.(I),
      onUpdate: ({ editor: I }) => {
        p.current.onChange?.(
          Xi(I.getJSON()),
          I.getJSON()
        ), O(I);
      },
      onSelectionUpdate: ({ editor: I }) => O(I),
      onBlur: () => {
        g(null), w(null);
      },
      editorProps: {
        handleDoubleClick: (I, $, B) => Hs(B, (J, Z) => {
          p.current.onOpenLink ? p.current.onOpenLink(J, Z) : window.open(J, "_blank", "noopener,noreferrer");
        }),
        attributes: { "aria-label": "笔记正文", class: "fp-editor-prose" },
        handleKeyDown(I, $) {
          if (!$.isComposing && ($.ctrlKey || $.metaKey) && ($.key === "Home" || $.key === "End")) {
            const Ne = $.key === "Home" ? Pn.atStart(I.state.doc) : Pn.atEnd(I.state.doc), pe = $.shiftKey ? rt.create(I.state.doc, I.state.selection.anchor, Ne.head) : Ne;
            return I.dispatch(I.state.tr.setSelection(pe).scrollIntoView()), !0;
          }
          const B = j.current;
          if (B.suggestion && !$.isComposing) {
            if ($.key === "Escape")
              return w(null), !0;
            if (B.suggestions.length) {
              if ($.key === "ArrowDown" || $.key === "ArrowUp")
                return C(
                  (B.suggestionActive + ($.key === "ArrowDown" ? 1 : -1) + B.suggestions.length) % B.suggestions.length
                ), !0;
              if ($.key === "Enter")
                return T(
                  B.suggestions[B.suggestionActive] || B.suggestions[0]
                ), !0;
            }
          }
          const J = M.current;
          if (!J || $.isComposing) return !1;
          const Z = A(J.query);
          return $.key === "Escape" ? (g(null), !0) : Z.length ? $.key === "ArrowDown" || $.key === "ArrowUp" ? (g({
            ...J,
            active: (J.active + ($.key === "ArrowDown" ? 1 : -1) + Z.length) % Z.length
          }), !0) : $.key === "Enter" ? (U(Z[Math.min(J.active, Z.length - 1)][0]), !0) : !1 : !1;
        },
        handlePaste(I, $) {
          const B = Array.from($.clipboardData?.files || []), J = f.current;
          return B.length && p.current.onFiles && J ? (p.current.onFiles(B, J), !0) : !1;
        },
        handleDrop(I, $, B, J) {
          const Z = Array.from($.dataTransfer?.files || []), Ne = f.current;
          if (!J && Z.length && p.current.onFiles && Ne) {
            const pe = I.posAtCoords({
              left: $.clientX,
              top: $.clientY
            });
            return pe && Ne.commands.setTextSelection(pe.pos), p.current.onFiles(Z, Ne), !0;
          }
          return !1;
        },
        handleDOMEvents: {
          mouseup: () => {
            const I = f.current;
            if (I && q.current.mode && !I.state.selection.empty) {
              const { from: $, to: B } = I.state.selection;
              _d(I, q.current.marks, $, B), q.current.mode === "once" && S(null);
            }
            return !1;
          }
        }
      }
    },
    [r, i, a]
  );
  return f.current = H, Y(() => {
    H?.setEditable(s);
  }, [H, s]), /* @__PURE__ */ o(
    "section",
    {
      className: "fp-markdown-editor",
      "data-readonly": !s || void 0,
      children: [
        H && s && t.toolbar !== !1 && /* @__PURE__ */ e(
          iu,
          {
            editor: H,
            onHistory: () => p.current.onHistory?.(),
            onSnapshot: () => p.current.onSnapshot?.(),
            hiddenActions: [
              ...t.allowCards === !1 ? ["card"] : [],
              ...t.onHistory ? [] : ["versions"],
              ...t.onSnapshot ? [] : ["snapshot"],
              ...t.onExport ? [] : ["export"],
              ...t.onAttachment ? [] : ["attachment", "video"]
            ],
            onExport: () => p.current.onExport?.(Xi(H.getJSON())),
            onAttachment: () => p.current.onAttachment?.(H, "file"),
            onInteractive: t.onInteractive ? () => p.current.onInteractive?.(H) : void 0,
            onVideo: () => p.current.onAttachment?.(H, "video"),
            onInsertCard: () => {
              p.current.allowCards !== !1 && ur(H);
            },
            onMath: (I) => h.open(H, I),
            formatPainterMode: E,
            onFormatPainterMode: S,
            formatPainterMarks: P,
            onFormatPainterMarks: _
          }
        ),
        /* @__PURE__ */ e(cl, { editor: H, children: /* @__PURE__ */ e(Ea, { editor: H }) }),
        h.card,
        b && H && Oe(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": "插入内容",
              style: { left: b.left, top: b.top, maxHeight: 280 },
              children: [
                A(b.query).map(([I, $, B], J) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": J === b.active,
                    tabIndex: -1,
                    onMouseDown: (Z) => Z.preventDefault(),
                    onClick: () => U(I),
                    children: [
                      /* @__PURE__ */ e("strong", { children: $ }),
                      /* @__PURE__ */ e("small", { children: B })
                    ]
                  },
                  I
                )),
                !A(b.query).length && /* @__PURE__ */ e("p", { className: "fp-muted", children: "没有匹配的内容" })
              ]
            }
          ),
          H.view.dom.closest("dialog") || window.document.body
        ),
        d && /* @__PURE__ */ e("footer", { className: "fp-markdown-status", children: d }),
        v && H && Oe(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": v.kind === "tag" ? "标签建议" : "笔记链接建议",
              style: {
                left: v.left,
                top: v.top,
                maxHeight: 260
              },
              children: [
                y.map((I, $) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": $ === x,
                    onMouseDown: (B) => B.preventDefault(),
                    onClick: () => T(I),
                    children: [
                      /* @__PURE__ */ e("strong", { children: I.label }),
                      I.detail && /* @__PURE__ */ e("small", { children: I.detail })
                    ]
                  },
                  I.id
                )),
                !y.length && /* @__PURE__ */ e("p", { role: z ? "alert" : "status", children: z || "输入关键词查找…" })
              ]
            }
          ),
          H.view.dom.closest("dialog") || window.document.body
        )
      ]
    }
  );
}
const yr = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function qu({
  title: t,
  media: n,
  transcript: r,
  chapters: i = [],
  notes: a,
  onNotesChange: l,
  onPositionChange: s,
  onCite: c
}) {
  const [u, d] = k(n.startAt || 0), [p, h] = k("transcript"), [f, m] = k(!0), b = R(null), g = R(null), v = r.findIndex(
    (x) => u >= x.start && u < x.end
  ), w = [...i].reverse().find((x) => x.start <= u);
  Y(() => {
    if (!f || p !== "transcript" || !g.current) return;
    const x = g.current, C = x.parentElement;
    if (!C) return;
    const z = x.getBoundingClientRect(), L = C.getBoundingClientRect();
    (z.top < L.top || z.bottom > L.bottom) && C.scrollTo?.({
      top: C.scrollTop + z.top - L.top - 16,
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
    });
  }, [v, f, p]), Y(() => {
    d(n.startAt || 0);
  }, [n.src, n.startAt]), Y(() => {
    p === "chapter" && !w?.markdown && h("transcript");
  }, [p, w?.markdown]);
  const y = (x) => {
    d(x), s?.(x), n.onTimeUpdate?.(x);
  }, N = (x) => {
    b.current && (b.current.currentTime = Math.max(0, x), y(x));
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-lecture-workspace", children: /* @__PURE__ */ o(ne, { title: t, children: [
    n.kind === "audio" ? /* @__PURE__ */ e(
      Fn,
      {
        ...n,
        audioRef: (x) => {
          b.current = x;
          const C = n.audioRef;
          typeof C == "function" ? C(x) : C && (C.current = x);
        },
        onTimeUpdate: y
      }
    ) : /* @__PURE__ */ e(
      on,
      {
        ...n,
        videoRef: (x) => {
          b.current = x;
          const C = n.videoRef;
          typeof C == "function" ? C(x) : C && (C.current = x);
        },
        onTimeUpdate: y
      }
    ),
    i.length > 0 && /* @__PURE__ */ e("nav", { className: "fp-lecture-chapters", "aria-label": "课堂章节", children: i.map((x) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        "aria-current": w?.id === x.id ? "step" : void 0,
        onClick: () => N(x.start),
        children: [
          /* @__PURE__ */ e("span", { children: yr(x.start) }),
          x.title
        ]
      },
      x.id
    )) }),
    /* @__PURE__ */ e(
      Ge,
      {
        label: "课堂内容",
        value: p,
        onChange: h,
        items: [
          { id: "transcript", label: "讲稿" },
          { id: "notes", label: "课堂笔记" },
          ...w?.markdown ? [{ id: "chapter", label: "章节内容" }] : []
        ]
      }
    ),
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ e("div", { className: "fp-lecture-content", children: p === "notes" ? /* @__PURE__ */ e(
      lr,
      {
        markdown: a,
        onChange: l,
        placeholder: "记录课堂中的想法…"
      }
    ) : p === "chapter" ? /* @__PURE__ */ e(Nt, { markdown: w?.markdown || "" }) : /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          "aria-pressed": f,
          onClick: () => m(!f),
          children: "跟随播放"
        }
      ) }),
      /* @__PURE__ */ e("div", { className: "fp-lecture-transcript", "aria-label": "课堂讲稿", children: r.length ? r.map((x, C) => /* @__PURE__ */ o(
        "div",
        {
          ref: C === v ? g : void 0,
          className: "fp-lecture-line",
          "data-active": C === v || void 0,
          children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-timestamp",
                onClick: () => N(x.start),
                "aria-label": `跳转至 ${yr(x.start)}`,
                children: yr(x.start)
              }
            ),
            /* @__PURE__ */ e("p", { children: x.words?.length ? x.words.map((z, L) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                "data-active": u >= z.start && u < z.end || void 0,
                onClick: () => N(z.start),
                children: z.text
              },
              L
            )) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                onClick: () => N(x.start),
                children: x.text
              }
            ) }),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => c({
                  title: t,
                  time: x.start,
                  text: x.text
                }),
                children: "引用"
              }
            )
          ]
        },
        x.id || `${x.start}-${C}`
      )) : /* @__PURE__ */ e("p", { className: "fp-workspace-empty", children: "还没有可用的课堂讲稿。" }) })
    ] }) }) })
  ] }) });
}
function Ku({
  source: t
}) {
  const [n, r] = k("");
  return t.audio ? /* @__PURE__ */ e(
    qu,
    {
      title: t.title,
      media: { kind: "audio", ...t.audio },
      transcript: t.transcript || [],
      chapters: t.chapters,
      notes: n,
      onNotesChange: r
    }
  ) : t.resource ? /* @__PURE__ */ e(Ks, { resource: t.resource }) : /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h3", { children: t.title }),
    /* @__PURE__ */ e(
      Nt,
      {
        markdown: t.markdown || "此资料还没有可阅读的正文。"
      }
    )
  ] });
}
function ye({
  children: t,
  onAction: n,
  disabled: r = !1,
  confirm: i
}) {
  const [a, l] = k(!1), [s, c] = k(""), [u, d] = k(!1), p = R(!1), h = async () => {
    if (!p.current) {
      p.current = !0, l(!0), c("");
      try {
        await n(), d(!1);
      } catch (f) {
        c(
          f instanceof Error ? f.message : "操作未能完成，请重试。"
        );
      } finally {
        p.current = !1, l(!1);
      }
    }
  };
  return /* @__PURE__ */ o("span", { className: "fp-async-action", children: [
    u ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e("span", { children: i }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a || r,
          onClick: () => {
            h();
          },
          children: a ? "正在处理…" : "确认"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a,
          onClick: () => d(!1),
          children: "取消"
        }
      )
    ] }) : /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary fp-sm",
        disabled: a || r,
        onClick: () => i ? d(!0) : void h(),
        children: a ? "正在处理…" : t
      }
    ),
    s && /* @__PURE__ */ e("span", { role: "alert", children: s })
  ] });
}
function Hu({
  title: t,
  items: n,
  columns: r,
  actions: i = [],
  loading: a,
  error: l,
  toolbar: s,
  onLoadMore: c,
  hasMore: u,
  showHeading: d = !0,
  embedded: p = !1,
  layout: h = "responsive",
  columnSizing: f = "auto"
}) {
  return /* @__PURE__ */ o("section", { className: "fp-management", "aria-label": t, "data-embedded": p || void 0, "data-layout": h, children: [
    (d || s) && /* @__PURE__ */ o("header", { children: [
      d && /* @__PURE__ */ e("h3", { children: t }),
      s
    ] }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    /* @__PURE__ */ e("div", { className: "fp-management-scroll", children: /* @__PURE__ */ o("table", { style: { tableLayout: f }, children: [
      /* @__PURE__ */ o("colgroup", { children: [
        r.map((m) => /* @__PURE__ */ e("col", { style: { width: m.width } }, m.id)),
        !!i.length && /* @__PURE__ */ e("col", {})
      ] }),
      /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ o("tr", { children: [
        r.map((m) => /* @__PURE__ */ e("th", { scope: "col", children: m.label }, m.id)),
        !!i.length && /* @__PURE__ */ e("th", { scope: "col", children: "操作" })
      ] }) }),
      /* @__PURE__ */ e("tbody", { children: n.map((m) => /* @__PURE__ */ o("tr", { children: [
        r.map((b) => /* @__PURE__ */ e("td", { "data-label": b.label, "data-overflow": b.overflow, children: b.render(m) }, b.id)),
        !!i.length && /* @__PURE__ */ e("td", { "data-label": "操作", children: /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: i.map((b) => /* @__PURE__ */ e(
          ye,
          {
            disabled: b.disabled?.(m) || a,
            confirm: b.confirm?.(m),
            onAction: () => b.run(m),
            children: b.label
          },
          b.id
        )) }) })
      ] }, m.id)) })
    ] }) }),
    a && /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }),
    !n.length && !a && /* @__PURE__ */ e("p", { children: "这里还没有内容。" }),
    u && c && /* @__PURE__ */ e("button", { type: "button", disabled: a, onClick: c, children: "加载更多" })
  ] });
}
function af({
  entries: t,
  loading: n,
  error: r
}) {
  return /* @__PURE__ */ e(
    Hu,
    {
      title: "收支明细",
      items: t,
      loading: n,
      error: r,
      columns: [
        { id: "title", label: "事项", render: (i) => i.title },
        { id: "date", label: "时间", render: (i) => i.date },
        {
          id: "amount",
          label: "变动",
          render: (i) => /* @__PURE__ */ o("span", { "data-positive": i.amount > 0 || void 0, children: [
            i.amount > 0 ? "+" : "",
            i.amount.toLocaleString()
          ] })
        },
        {
          id: "balance",
          label: "余额",
          render: (i) => i.balance?.toLocaleString() ?? "—"
        },
        { id: "status", label: "状态", render: (i) => i.status || "已完成" }
      ]
    }
  );
}
function lf({
  balance: t,
  reserved: n = 0,
  children: r,
  onTopUp: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的积分" }),
      i && /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "补充积分" })
    ] }),
    /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: t.toLocaleString() }),
    /* @__PURE__ */ o("p", { children: [
      "可用积分",
      n > 0 && ` · 使用中 ${n.toLocaleString()}`
    ] }),
    r
  ] });
}
function of({
  items: t,
  onManage: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "使用情况" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-capacity-row", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: r.label }),
        /* @__PURE__ */ o("span", { children: [
          r.used.toLocaleString(),
          " / ",
          r.limit.toLocaleString(),
          " ",
          r.unit
        ] })
      ] }),
      /* @__PURE__ */ e(
        "progress",
        {
          "aria-label": r.label,
          value: Math.min(r.limit, Math.max(0, r.used)),
          max: Math.max(1, r.limit)
        }
      ),
      n && /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
        "管理",
        r.label
      ] })
    ] }, r.id))
  ] });
}
function sf({
  items: t,
  canManage: n,
  onManage: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-label": "访问权限来源", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "访问权限" }),
      n && r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "管理权限" })
    ] }),
    t.length ? /* @__PURE__ */ e("ul", { children: t.map((i, a) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("strong", { children: i.source }),
      /* @__PURE__ */ e("span", { children: i.role }),
      /* @__PURE__ */ e("small", { children: i.inherited ? "来自上级目录" : "单独设置" })
    ] }, `${i.source}-${a}`)) }) : /* @__PURE__ */ e("p", { children: "仅自己可以访问。" })
  ] });
}
function cf({
  title: t,
  fields: n,
  onChange: r,
  onSave: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-settings-fields", children: n.map((a) => /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ e("span", { children: a.label }),
      a.options ? /* @__PURE__ */ e(
        Ce,
        {
          label: a.label,
          value: a.value,
          options: a.options,
          disabled: a.disabled,
          onChange: (l) => r(a.id, l)
        }
      ) : /* @__PURE__ */ e(
        "input",
        {
          "aria-label": a.label,
          type: a.secret ? "password" : "text",
          value: a.value,
          disabled: a.disabled,
          onChange: (l) => r(a.id, l.target.value)
        }
      ),
      " ",
      a.description && /* @__PURE__ */ e("small", { children: a.description })
    ] }, a.id)) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(ye, { onAction: i, children: "保存设置" }) })
  ] });
}
function df({
  steps: t,
  step: n,
  onStepChange: r,
  onComplete: i
}) {
  const a = t[n];
  return a ? /* @__PURE__ */ o("section", { className: "fp-onboarding", children: [
    /* @__PURE__ */ e("ol", { "aria-label": "设置进度", children: t.map((l, s) => /* @__PURE__ */ o("li", { "aria-current": s === n ? "step" : void 0, children: [
      /* @__PURE__ */ e("span", { children: s + 1 }),
      l.title
    ] }, l.id)) }),
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: a.title }),
      a.description && /* @__PURE__ */ e("p", { children: a.description }),
      a.content
    ] }) }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      n < t.length - 1 ? /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: a.canContinue === !1,
          onClick: () => r(n + 1),
          children: "继续"
        }
      ) : /* @__PURE__ */ e(
        ye,
        {
          disabled: a.canContinue === !1,
          onAction: i,
          children: "完成设置"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n === 0,
          onClick: () => r(n - 1),
          children: "上一步"
        }
      )
    ] })
  ] }) : /* @__PURE__ */ e("section", { className: "fp-onboarding", children: /* @__PURE__ */ e("p", { children: "暂时没有可用的设置步骤。" }) });
}
function Uu(t) {
  return /* @__PURE__ */ e(Wu, { ...t }, t.notebook?.id || "new");
}
function Wu({
  notebook: t,
  drafts: n = [],
  versions: r = [],
  onPrepare: i,
  onPublish: a,
  onSetSource: l,
  onRestore: s,
  onLoadVersions: c,
  onRefresh: u,
  resolveResourceUrl: d
}) {
  const [p, h] = k("update"), {
    draft: f,
    setDraft: m,
    dirty: b,
    accept: g
  } = at({
    sourcePrefix: t?.sourcePrefix || "",
    syncMode: t?.syncMode || "review"
  }), v = f.sourcePrefix, w = f.syncMode, y = (S) => m({ ...f, sourcePrefix: S }), N = (S) => m({ ...f, syncMode: S }), [x, C] = k(), [z, L] = k(""), [j, M] = k(null), [A, O] = k(""), U = Pe(), T = j?.items.find((S) => S.id === A) || j?.items[0], E = () => {
    U.run(async () => {
      if (!v.trim()) throw new Error("请填写资料来源目录。");
      const S = await i({
        notebookId: t?.id,
        sourcePrefix: v.trim(),
        manifest: x
      });
      M(S), O(S.items[0]?.id || "");
    }, "内容已准备好，请检查后发布。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "笔记本发布", children: /* @__PURE__ */ o(
    ne,
    {
      title: t?.title || "新建笔记本",
      description: "预览课程内容，为读者发布新的阅读版本。",
      actions: u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          disabled: U.busy,
          onClick: () => {
            U.run(u);
          },
          children: "刷新"
        }
      ),
      children: [
        /* @__PURE__ */ e(
          Ge,
          {
            label: "笔记本管理",
            value: p,
            onChange: (S) => {
              h(S), S === "history" && c && U.run(c);
            },
            items: [
              { id: "update", label: "预览与发布" },
              { id: "source", label: "来源与更新" },
              { id: "history", label: "发布历史" }
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { ...U }),
        /* @__PURE__ */ e("fieldset", { disabled: U.busy, children: /* @__PURE__ */ o(ge, { children: [
          p === "update" && /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ o(ne, { title: "准备课程资料", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "资料来源目录",
                  value: v,
                  onChange: (S) => {
                    y(S), M(null);
                  },
                  hint: "选择已经上传的课程资料目录。"
                }
              ),
              /* @__PURE__ */ o(
                "label",
                {
                  className: "fp-workspace-upload",
                  role: "button",
                  tabIndex: 0,
                  onKeyDown: (S) => {
                    (S.key === "Enter" || S.key === " ") && (S.preventDefault(), S.currentTarget.querySelector("input")?.click());
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: z || "选择目录清单" }),
                    /* @__PURE__ */ e("span", { children: "JSON 文件，最大 2 MB" }),
                    /* @__PURE__ */ e(
                      "input",
                      {
                        hidden: !0,
                        type: "file",
                        "aria-label": "选择目录清单",
                        accept: ".json,application/json",
                        onChange: (S) => {
                          const P = S.target.files?.[0];
                          S.target.value = "", P && (C(void 0), L(""), M(null), U.run(async () => {
                            if (P.size > 2e6)
                              throw new Error("清单文件不能超过 2 MB。");
                            let _;
                            try {
                              _ = JSON.parse(await P.text());
                            } catch {
                              throw new Error(
                                "无法读取清单，请选择有效的 JSON 文件。"
                              );
                            }
                            C(_), L(P.name), M(null);
                          }));
                        }
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: E,
                  children: U.busy ? "正在检查…" : "检查并预览"
                }
              )
            ] }),
            n.length > 0 && /* @__PURE__ */ e(ne, { title: "待发布内容", children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: n.map((S) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                onClick: () => {
                  M(S), O(S.items[0]?.id || "");
                },
                children: [
                  /* @__PURE__ */ e("strong", { children: S.title }),
                  /* @__PURE__ */ o("small", { children: [
                    S.sections,
                    " 个章节 · ",
                    S.resources,
                    " 份资料"
                  ] })
                ]
              },
              S.id
            )) }) }),
            j && /* @__PURE__ */ o(
              ne,
              {
                title: j.title,
                description: `${j.sections} 个章节 · ${j.resources} 份资料${j.structureChanged ? " · 目录有调整" : ""}`,
                children: [
                  /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
                    /* @__PURE__ */ e(
                      "nav",
                      {
                        className: "fp-workspace-item-list",
                        "aria-label": "草稿章节",
                        children: j.items.map((S) => /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            "aria-pressed": S.id === T?.id,
                            onClick: () => O(S.id),
                            children: S.title
                          },
                          S.id
                        ))
                      }
                    ),
                    /* @__PURE__ */ e("article", { children: T ? /* @__PURE__ */ e(
                      Nt,
                      {
                        markdown: T.content,
                        resolveResourceUrl: d
                      }
                    ) : /* @__PURE__ */ e("p", { children: "此草稿还没有可预览的章节。" }) })
                  ] }),
                  /* @__PURE__ */ e(
                    ye,
                    {
                      disabled: !j.items.length,
                      confirm: `将“${j.title}”发布给读者？`,
                      onAction: async () => {
                        await a(j.id, t?.currentRelease), M(null), U.setMessage("发布完成，读者可以看到新内容。");
                      },
                      children: "确认发布"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-ghost",
                      onClick: () => M(null),
                      children: "返回修改"
                    }
                  )
                ]
              }
            )
          ] }),
          p === "source" && /* @__PURE__ */ o(ne, { title: "资料来源与更新方式", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "来源目录",
                value: v,
                onChange: (S) => {
                  y(S), M(null);
                }
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "发布方式",
                value: w,
                options: [
                  {
                    value: "review",
                    label: "确认后发布",
                    description: "先预览内容，再决定发布时间。"
                  },
                  {
                    value: "auto",
                    label: "自动发布",
                    description: "正文变化自动更新，目录调整仍需确认。"
                  }
                ],
                onChange: (S) => N(S)
              }
            ),
            l && /* @__PURE__ */ e(
              dt,
              {
                busy: U.busy,
                dirty: b,
                onClick: () => {
                  U.run(async () => {
                    if (!v.trim()) throw new Error("请填写来源目录。");
                    const S = {
                      sourcePrefix: v.trim(),
                      syncMode: w
                    };
                    await l(S), g(S);
                  }, "来源与更新方式已保存。");
                }
              }
            )
          ] }),
          p === "history" && /* @__PURE__ */ o(ne, { title: "发布历史", children: [
            r.map((S) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
              /* @__PURE__ */ o("div", { children: [
                /* @__PURE__ */ e("strong", { children: S.label || new Date(S.createdAt).toLocaleString("zh-CN") }),
                /* @__PURE__ */ e("p", { children: S.id === t?.currentRelease ? "当前阅读版本" : "历史阅读版本" })
              ] }),
              s && t && S.id !== t.currentRelease && /* @__PURE__ */ e(
                ye,
                {
                  confirm: "恢复此版本？后续更新将等待你确认。",
                  onAction: async () => {
                    await s(
                      S.id,
                      t.currentRelease
                    ), U.setMessage("阅读版本已恢复。");
                  },
                  children: "恢复版本"
                }
              )
            ] }, S.id)),
            !r.length && /* @__PURE__ */ e("p", { children: "暂无发布历史。" })
          ] })
        ] }) })
      ]
    }
  ) });
}
function uf({
  notebooks: t,
  drafts: n,
  versions: r = {},
  loading: i,
  error: a,
  onPrepare: l,
  onPublish: s,
  onSetSource: c,
  onRestore: u,
  onLoadVersions: d,
  onRefresh: p,
  resolveResourceUrl: h
}) {
  const [f, m] = k(""), [b, g] = k("all"), [v, w] = k(null), y = t.find((z) => z.id === v), N = n.filter(
    (z) => v === "new" ? !z.notebookId : z.notebookId === v
  ), x = t.filter(
    (z) => z.title.toLowerCase().includes(f.trim().toLowerCase()) && (b === "all" || n.some((L) => L.notebookId === z.id))
  ), C = n.filter(
    (z) => !z.notebookId || !t.some((L) => L.id === z.notebookId)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ne,
    {
      title: "笔记本",
      description: "整理课程资料，检查更新并发布阅读版本。",
      actions: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          onClick: () => w("new"),
          children: "新建笔记本"
        }
      ),
      children: [
        /* @__PURE__ */ e(X, { label: "搜索笔记本", value: f, onChange: m }),
        /* @__PURE__ */ e(
          Ge,
          {
            label: "笔记本筛选",
            value: b,
            onChange: g,
            items: [
              { id: "all", label: "全部笔记本" },
              { id: "pending", label: "有待发布内容" }
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { error: a }),
        i ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ o("div", { className: "fp-workspace-item-list", children: [
          x.map((z) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              "aria-pressed": v === z.id,
              onClick: () => w(z.id),
              children: [
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: z.title }),
                  /* @__PURE__ */ e("small", { children: n.some((L) => L.notebookId === z.id) ? "有内容等待发布" : "课程内容已发布" })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            z.id
          )),
          !x.length && /* @__PURE__ */ e("p", { children: f ? "没有找到匹配的笔记本。" : "选择新建笔记本，开始整理课程。" }),
          C.filter(
            (z) => z.title.toLowerCase().includes(f.toLowerCase())
          ).map((z) => /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => w("new"),
              children: /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: z.title }),
                /* @__PURE__ */ e("small", { children: "首次发布待确认" })
              ] })
            },
            z.id
          ))
        ] }),
        /* @__PURE__ */ e(ge, { children: v && /* @__PURE__ */ e(
          ne,
          {
            title: y?.title || "准备新的笔记本",
            actions: /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => w(null),
                children: "返回笔记本列表"
              }
            ),
            children: /* @__PURE__ */ e(
              Uu,
              {
                notebook: y,
                drafts: N,
                versions: r[v],
                onPrepare: l,
                onPublish: s,
                onSetSource: y && c ? (z) => c(y.id, z) : void 0,
                onRestore: y && u ? (z, L) => u(y.id, z, L) : void 0,
                onLoadVersions: y && d ? () => d(y.id) : void 0,
                onRefresh: p,
                resolveResourceUrl: h
              },
              v
            )
          }
        ) })
      ]
    }
  ) });
}
const El = [
  { id: "#7196D3", label: "蓝色" },
  { id: "#56A58A", label: "绿色" },
  { id: "#A18AD4", label: "紫色" },
  { id: "#D99150", label: "橙色" },
  { id: "#CE7D92", label: "粉色" },
  { id: "#C7AA55", label: "黄色" },
  { id: "#679FAE", label: "青色" },
  { id: "#8C96A5", label: "灰色" }
];
function pf({ value: t, onChange: n, icons: r, title: i = "我的笔记本", disabled: a = !1 }) {
  const l = ve();
  return /* @__PURE__ */ o("div", { className: "fp-notebook-appearance", children: [
    /* @__PURE__ */ o("div", { className: "fp-notebook-appearance-preview", style: { "--fp-notebook-color": t.color }, children: [
      /* @__PURE__ */ e("span", { children: r.find((s) => s.id === t.icon)?.icon }),
      /* @__PURE__ */ e("strong", { children: i })
    ] }),
    /* @__PURE__ */ o("fieldset", { disabled: a, children: [
      /* @__PURE__ */ e("legend", { children: "笔记本颜色" }),
      /* @__PURE__ */ e("div", { className: "fp-notebook-color-options", children: El.map((s) => /* @__PURE__ */ e("button", { type: "button", "aria-label": s.label, "aria-pressed": t.color.toLowerCase() === s.id.toLowerCase(), style: { background: s.id }, onClick: () => n({ ...t, color: s.id }), children: t.color.toLowerCase() === s.id.toLowerCase() && /* @__PURE__ */ e(Ie, { size: 18 }) }, s.id)) }),
      /* @__PURE__ */ o("label", { className: "fp-notebook-custom-color", htmlFor: l, children: [
        "自选颜色",
        /* @__PURE__ */ e("input", { id: l, type: "color", value: t.color, onChange: (s) => n({ ...t, color: s.target.value }) })
      ] })
    ] }),
    /* @__PURE__ */ o("fieldset", { disabled: a, children: [
      /* @__PURE__ */ e("legend", { children: "笔记本图标" }),
      /* @__PURE__ */ e("div", { className: "fp-notebook-icon-options", children: r.map((s) => /* @__PURE__ */ o("button", { type: "button", "aria-label": s.label, "data-fp-tooltip": s.label, "aria-pressed": t.icon === s.id, onClick: () => n({ ...t, icon: s.id }), children: [
        s.icon,
        /* @__PURE__ */ e("span", { children: s.label })
      ] }, s.id)) })
    ] })
  ] });
}
function hf({ query: t, onQueryChange: n, color: r, onColorChange: i, icon: a, onIconChange: l, colors: s = El, icons: c, presets: u = [], preset: d, onPresetChange: p }) {
  const [h, f] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-notebook-quick-filters", children: [
    /* @__PURE__ */ o("div", { className: "fp-notebook-filter-search", children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ e(Ue, { size: 16 }),
        /* @__PURE__ */ e("input", { type: "search", "aria-label": "搜索笔记本", placeholder: "搜索笔记本", value: t, onChange: (m) => n(m.target.value) })
      ] }),
      t && /* @__PURE__ */ e("button", { className: "fp-notebook-query-clear", type: "button", "aria-label": "清除搜索", onClick: () => n(""), children: /* @__PURE__ */ e(ke, { size: 15 }) }),
      /* @__PURE__ */ e("span", { "data-active": !!(r || a) || void 0, children: /* @__PURE__ */ e(Xe, { label: "颜色与图标筛选", icon: /* @__PURE__ */ e(ga, { size: 17 }), className: "fp-notebook-filter-popover", density: "compact", onOpenChange: f, children: (m) => /* @__PURE__ */ o("div", { className: "fp-notebook-filter-details", children: [
        /* @__PURE__ */ e("strong", { children: "筛选笔记本" }),
        /* @__PURE__ */ o("fieldset", { children: [
          /* @__PURE__ */ e("legend", { children: "颜色" }),
          /* @__PURE__ */ o("div", { className: "fp-notebook-color-options", children: [
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "全部颜色", "aria-pressed": !r, onClick: () => i(""), children: /* @__PURE__ */ e("span", { children: "全部" }) }),
            s.map((b) => /* @__PURE__ */ e("button", { type: "button", "aria-label": b.label, "data-fp-tooltip": b.label, "aria-pressed": r.toLowerCase() === b.id.toLowerCase(), style: { background: b.id }, onClick: () => i(r.toLowerCase() === b.id.toLowerCase() ? "" : b.id), children: r.toLowerCase() === b.id.toLowerCase() && /* @__PURE__ */ e(Ie, { size: 18 }) }, b.id))
          ] })
        ] }),
        /* @__PURE__ */ o("fieldset", { children: [
          /* @__PURE__ */ e("legend", { children: "图标" }),
          /* @__PURE__ */ o("div", { className: "fp-notebook-filter-icons", children: [
            /* @__PURE__ */ e("button", { type: "button", "aria-pressed": !a, onClick: () => l(""), children: "全部" }),
            c.map((b) => /* @__PURE__ */ o("button", { type: "button", "aria-label": b.label, "aria-pressed": a === b.id, onClick: () => l(a === b.id ? "" : b.id), children: [
              b.icon,
              /* @__PURE__ */ e("span", { children: b.label })
            ] }, b.id))
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-notebook-filter-footer", children: [
          /* @__PURE__ */ e("button", { type: "button", className: "fp-notebook-filter-clear", disabled: !t && !r && !a, onClick: () => {
            n(""), i(""), l("");
          }, children: "清除搜索和外观筛选" }),
          /* @__PURE__ */ e("button", { type: "button", onClick: m, children: "完成" })
        ] })
      ] }) }) })
    ] }),
    !!u.length && /* @__PURE__ */ e("div", { className: "fp-notebook-filter-presets", role: "group", "aria-label": "快捷筛选", children: u.map((m) => /* @__PURE__ */ e("button", { type: "button", "aria-pressed": d === m.id, onClick: () => p?.(m.id), children: m.label }, m.id)) }),
    !h && !!(r || a) && /* @__PURE__ */ e("small", { className: "fp-notebook-filter-summary", children: [s.find((m) => m.id.toLowerCase() === r.toLowerCase())?.label, c.find((m) => m.id === a)?.label].filter(Boolean).join(" · ") })
  ] });
}
function _u({
  versions: t,
  selectedId: n,
  onSelect: r,
  onRestore: i,
  loading: a,
  error: l
}) {
  const [s, c] = k(null), [u, d] = k(!1), [p, h] = k(""), f = R(!1), m = t.find((b) => b.id === n);
  return /* @__PURE__ */ o("section", { className: "fp-version-history", "aria-label": "笔记历史", children: [
    /* @__PURE__ */ e("div", { className: "fp-version-list", "aria-busy": a, children: a ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取历史…" }) : t.length ? t.map((b) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": b.id === n,
        onClick: () => {
          c(null), h(""), r(b.id);
        },
        children: [
          /* @__PURE__ */ e(Xn, { size: 15 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: b.label }),
            /* @__PURE__ */ o("small", { children: [
              b.date,
              b.author && ` · ${b.author}`
            ] })
          ] })
        ]
      },
      b.id
    )) : /* @__PURE__ */ e("p", { children: "还没有保存的历史版本。" }) }),
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ o("div", { className: "fp-version-preview", children: [
      m ? /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e("h3", { children: m.label }),
        m.preview,
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: s === m.id ? /* @__PURE__ */ o(ee, { children: [
          /* @__PURE__ */ e("span", { children: "将当前笔记恢复到此版本？" }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: async () => {
                if (!f.current) {
                  f.current = !0, d(!0), h("");
                  try {
                    await i(m.id), c(null);
                  } catch {
                    h("恢复未能完成，当前内容已保留。");
                  } finally {
                    f.current = !1, d(!1);
                  }
                }
              },
              children: u ? "正在恢复…" : "确认恢复"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: () => c(null),
              children: "取消"
            }
          )
        ] }) : /* @__PURE__ */ o("button", { type: "button", onClick: () => c(m.id), children: [
          /* @__PURE__ */ e(tt, { size: 15 }),
          "恢复此版本"
        ] }) })
      ] }) : /* @__PURE__ */ e("p", { children: "选择一个版本查看内容。" }),
      (l || p) && /* @__PURE__ */ e("p", { role: "alert", children: l || p })
    ] }) })
  ] });
}
function ff({
  local: t,
  remote: n,
  onResolve: r
}) {
  const [i, a] = k(!1), [l, s] = k(""), c = R(!1);
  return /* @__PURE__ */ o("section", { className: "fp-save-conflict", "aria-label": "处理笔记冲突", children: [
    /* @__PURE__ */ e("h3", { children: "笔记有新的修改" }),
    /* @__PURE__ */ e("p", { children: "比较两个版本，选择要继续使用的内容。" }),
    /* @__PURE__ */ o("div", { className: "fp-compare-panes", children: [
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "我的修改" }),
        t
      ] }),
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "最新版本" }),
        n
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: ["local", "remote"].map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        disabled: i,
        onClick: async () => {
          if (!c.current) {
            c.current = !0, a(!0), s("");
            try {
              await r(u);
            } catch {
              s("暂时无法应用，请重试。");
            } finally {
              c.current = !1, a(!1);
            }
          }
        },
        children: u === "local" ? "使用我的修改" : "使用最新版本"
      },
      u
    )) }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l })
  ] });
}
function mf({
  items: t,
  onOpen: n,
  loading: r = !1
}) {
  return /* @__PURE__ */ o("section", { className: "fp-backlinks", "aria-label": "关联笔记", children: [
    /* @__PURE__ */ e("h3", { children: "引用这篇笔记" }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在查找关联…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((i) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("button", { type: "button", onClick: () => n(i.id), children: [
      /* @__PURE__ */ e(ft, { size: 15 }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: i.title }),
        i.excerpt && /* @__PURE__ */ e("small", { children: i.excerpt })
      ] })
    ] }) }, i.id)) }) : /* @__PURE__ */ e("p", { children: "还没有其他笔记引用这里。" })
  ] });
}
function bf({
  previewUrl: t,
  onChoose: n,
  onCancel: r,
  busy: i = !1,
  error: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-image-paste", "aria-label": "添加图片", children: [
    /* @__PURE__ */ e("img", { src: t, alt: "待添加的图片" }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: "如何添加这张图片？" }),
      /* @__PURE__ */ e("p", { children: "保留图片，或识别其中的文字与公式。" }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: i,
            onClick: () => n("image"),
            children: "插入图片"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: i,
            onClick: () => n("recognize"),
            children: "识别内容"
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: i, onClick: r, children: "取消" })
      ] }),
      i && /* @__PURE__ */ e("p", { role: "status", children: "正在处理图片…" }),
      a && /* @__PURE__ */ e("p", { role: "alert", children: a })
    ] })
  ] });
}
function gf({ lines: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-version-diff", "aria-label": "版本变化", children: t.map((n, r) => /* @__PURE__ */ o("div", { "data-kind": n.kind, children: [
    /* @__PURE__ */ e(
      "span",
      {
        "aria-label": n.kind === "added" ? "新增" : n.kind === "removed" ? "删除" : "保留",
        children: n.kind === "added" ? "+" : n.kind === "removed" ? "−" : " "
      }
    ),
    /* @__PURE__ */ e("code", { children: n.text || " " })
  ] }, r)) });
}
function Vu(t) {
  return /* @__PURE__ */ e(Gu, { ...t }, t.document.id);
}
function Gu({
  document: t,
  onSave: n,
  autosaveDelay: r = 1600,
  readOnly: i,
  editorProps: a,
  versions: l = [],
  onRestore: s,
  onExportDraft: c,
  registerNavigationGuard: u,
  onDirtyChange: d
}) {
  const [p, h] = k(t), [f, m] = k(t.markdown), [b, g] = k(
    "clean"
  ), [v, w] = k(""), [y, N] = k(null), [x, C] = k(!1), [z, L] = k(l[0]?.id), [j, M] = k(!1), A = R(!1), O = p.markdown !== f, U = R(p), T = R(n), E = R(null), S = R(null), P = R(!0), _ = R(t.revision);
  U.current = p, T.current = n, Y(() => (P.current = !0, () => {
    P.current = !1, E.current?.abort();
  }), []), Y(() => {
    d?.(O);
  }, [O, d]), Y(() => {
    t.revision !== _.current && (O || S.current ? N(t) : (_.current = t.revision, h(t), m(t.markdown)));
  }, [t, O]);
  const q = De(() => {
    if (S.current) return S.current;
    if (i || y) return Promise.resolve(!O);
    const H = U.current, I = new AbortController();
    E.current = I, g("saving"), w("");
    const $ = (async () => {
      try {
        const B = await T.current(H, I.signal);
        if (I.signal.aborted || !P.current) return !1;
        if (B.id !== H.id)
          throw new Error("保存的笔记不匹配，请重试。");
        return _.current = B.revision, m(B.markdown), h(
          (J) => J.markdown === H.markdown ? B : { ...J, revision: B.revision }
        ), g("saved"), !0;
      } catch (B) {
        return P.current && !I.signal.aborted && (g("error"), w(
          B instanceof Error ? B.message : "保存未完成，当前内容已保留。"
        )), !1;
      } finally {
        S.current = null;
      }
    })();
    return S.current = $, $;
  }, [i, y, O]);
  return Y(() => {
    if (!O || i || y || b === "error" || b === "saving" || r <= 0)
      return;
    const H = setTimeout(() => {
      q();
    }, r);
    return () => clearTimeout(H);
  }, [O, p.markdown, i, y, b, r, q]), Y(
    () => u?.(async () => O ? await q() ? U.current.markdown === p.markdown : !1 : !0),
    [u, O, q, p.markdown]
  ), Y(() => {
    const H = (I) => {
      O && (I.preventDefault(), I.returnValue = "");
    };
    return window.addEventListener("beforeunload", H), () => window.removeEventListener("beforeunload", H);
  }, [O]), /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form",
      onKeyDown: (H) => {
        (H.ctrlKey || H.metaKey) && H.key.toLowerCase() === "s" && (H.preventDefault(), O && q());
      },
      children: /* @__PURE__ */ o(
        ne,
        {
          title: p.title,
          actions: /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e("span", { role: "status", children: i ? "只读" : b === "saving" ? "正在保存…" : O ? "有待保存的更改" : "已保存" }),
            l.length > 0 && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                "aria-expanded": x,
                onClick: () => C(!x),
                children: "版本历史"
              }
            ),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: () => c(p),
                children: "导出笔记"
              }
            ),
            !i && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-primary",
                disabled: !O || b === "saving" || !!y || j,
                onClick: () => {
                  q();
                },
                children: "保存"
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(Ee, { error: v }),
            /* @__PURE__ */ e(ge, { children: y && /* @__PURE__ */ o("div", { className: "fp-workspace-subsection", role: "alert", children: [
              /* @__PURE__ */ e("strong", { children: "这篇笔记有新的版本" }),
              /* @__PURE__ */ e("p", { children: "当前编辑内容已保留，请先导出需要保留的内容，再选择继续使用的版本。" }),
              /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      _.current = y.revision, h(y), m(y.markdown), N(null), w(""), g("clean");
                    },
                    children: "读取最新版本"
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      _.current = y.revision, h((H) => ({
                        ...H,
                        revision: y.revision
                      })), N(null), g("clean");
                    },
                    children: "继续编辑当前内容"
                  }
                )
              ] })
            ] }) }),
            /* @__PURE__ */ e(
              lr,
              {
                ...a,
                documentKey: t.id,
                markdown: p.markdown,
                editable: !i && !j,
                onChange: (H) => {
                  h((I) => ({ ...I, markdown: H })), b !== "saving" && g("clean");
                }
              }
            ),
            /* @__PURE__ */ e(ge, { children: x && /* @__PURE__ */ e(
              _u,
              {
                versions: l,
                selectedId: z,
                onSelect: L,
                onRestore: async (H) => {
                  if (!s) throw new Error("暂时无法恢复此版本。");
                  if (!A.current) {
                    A.current = !0, M(!0);
                    try {
                      const I = U.current;
                      if (O && !await q())
                        throw new Error("请先保存当前更改。");
                      if (U.current.markdown !== I.markdown)
                        throw new Error("请先保存当前更改。");
                      const $ = new AbortController();
                      E.current = $;
                      const B = await s(
                        H,
                        U.current.revision,
                        $.signal
                      );
                      if (!P.current || $.signal.aborted) return;
                      if (B.id !== t.id)
                        throw new Error("恢复的笔记不匹配，请重试。");
                      _.current = B.revision, h(B), m(B.markdown), g("saved");
                    } finally {
                      A.current = !1, P.current && M(!1);
                    }
                  }
                }
              }
            ) })
          ]
        }
      )
    }
  );
}
function yf(t) {
  return /* @__PURE__ */ e(Yu, { ...t }, t.document.id);
}
function Yu({
  document: t,
  onSave: n,
  autosaveDelay: r,
  versions: i,
  onRestore: a,
  editorProps: l,
  onExportDraft: s,
  subject: c,
  summary: u,
  examples: d = [],
  quiz: p,
  readOnly: h,
  loading: f,
  error: m,
  onRetry: b,
  actions: g,
  contentProps: v,
  renderedContent: w
}) {
  const [y, N] = k("content"), [x, C] = k(!1), [z, L] = k(!1), [j, M] = k(d[0]?.id || ""), A = R(null), O = Pe(), U = (E) => {
    O.run(async () => {
      if (x && A.current && !await A.current())
        throw new Error("当前修改已保留，请保存后继续。");
      C(!1), N(E);
    });
  }, T = d.find((E) => E.id === j) || d[0];
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ e(
    rr,
    {
      open: z,
      onExit: () => L(!1),
      label: t.title,
      children: /* @__PURE__ */ e("div", { className: "fp-course-content", children: /* @__PURE__ */ o(
        ne,
        {
          title: t.title,
          description: [c, u].filter(Boolean).join(" · "),
          actions: /* @__PURE__ */ o(ee, { children: [
            g,
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": z ? "退出全屏" : "全屏阅读",
                onClick: () => L(!z),
                children: z ? /* @__PURE__ */ e(go, { size: 17 }) : /* @__PURE__ */ e(Gn, { size: 17 })
              }
            ),
            z && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": "关闭全屏阅读",
                onClick: () => L(!1),
                children: /* @__PURE__ */ e(ke, { size: 17 })
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(
              Ge,
              {
                label: "课程内容",
                value: y,
                onChange: U,
                items: [
                  { id: "content", label: "正文" },
                  ...d.length ? [{ id: "examples", label: `例题 ${d.length}` }] : [],
                  ...p ? [{ id: "quiz", label: "练习" }] : []
                ]
              }
            ),
            /* @__PURE__ */ e(Ee, { error: m || O.error }),
            /* @__PURE__ */ e(ge, { children: f ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开课程内容…" }) : m ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: b,
                children: "重新打开"
              }
            ) : y === "quiz" ? p : y === "examples" ? /* @__PURE__ */ o(ee, { children: [
              /* @__PURE__ */ e("nav", { className: "fp-workspace-actions", "aria-label": "例题列表", children: d.map((E) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  "aria-pressed": T?.id === E.id,
                  onClick: () => M(E.id),
                  children: E.title
                },
                E.id
              )) }),
              T && /* @__PURE__ */ e(
                Nt,
                {
                  ...v,
                  markdown: T.markdown
                }
              )
            ] }) : x ? /* @__PURE__ */ e(
              Vu,
              {
                document: t,
                onSave: n,
                autosaveDelay: r,
                versions: i,
                onRestore: a,
                editorProps: l,
                onExportDraft: s,
                registerNavigationGuard: (E) => (A.current = E, () => {
                  A.current = null;
                })
              }
            ) : w ?? /* @__PURE__ */ e(
              Nt,
              {
                ...v,
                markdown: t.markdown
              }
            ) }),
            y === "content" && !h && !f && !m && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                disabled: O.busy,
                onClick: () => {
                  O.run(async () => {
                    if (x && A.current && !await A.current())
                      throw new Error("当前修改已保留，请保存后继续。");
                    C(!x);
                  });
                },
                children: x ? "完成编辑" : "编辑笔记"
              }
            )
          ]
        }
      ) })
    }
  ) });
}
function _n(t) {
  try {
    const n = new URL(
      /^[a-z][a-z\d+.-]*:/i.test(t.trim()) ? t.trim() : `https://${t.trim()}`
    );
    return ["http:", "https:"].includes(n.protocol) && n.hostname ? n.href : "";
  } catch {
    return "";
  }
}
function Xu({
  bookmarks: t,
  homeUrl: n,
  onAdd: r,
  onRemove: i,
  onOpen: a,
  onHomeChange: l
}) {
  const [s, c] = k(""), [u, d] = k(""), p = Pe(), {
    draft: h,
    setDraft: f,
    dirty: m,
    accept: b
  } = at(n);
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ne, { title: "浏览与收藏", children: [
    /* @__PURE__ */ e(Ee, { ...p }),
    /* @__PURE__ */ o(ne, { title: "添加收藏", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "收藏名称",
          value: s,
          onChange: c,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        X,
        {
          label: "网页地址",
          value: u,
          onChange: d,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: p.busy || !u.trim(),
          onClick: () => {
            p.run(async () => {
              const g = _n(u);
              if (!g) throw new Error("请填写有效的网页地址。");
              await r({
                name: s.trim() || new URL(g).hostname,
                url: g
              }), c(""), d("");
            }, "收藏已添加。");
          },
          children: "添加收藏"
        }
      )
    ] }),
    /* @__PURE__ */ o(ne, { title: "我的收藏", children: [
      t.map((g) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-ghost",
            onClick: () => a(g.id),
            children: g.name
          }
        ),
        /* @__PURE__ */ e(
          ye,
          {
            confirm: `移除“${g.name}”收藏？`,
            onAction: () => i(g.id),
            children: "移除"
          }
        )
      ] }, g.id)),
      !t.length && /* @__PURE__ */ e("p", { children: "添加常用网页，下次可以快速打开。" })
    ] }),
    /* @__PURE__ */ o(ne, { title: "浏览器主页", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "主页地址",
          value: h,
          onChange: f,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        dt,
        {
          busy: p.busy,
          dirty: m,
          label: "保存主页",
          onClick: () => {
            p.run(async () => {
              const g = _n(h);
              if (!g) throw new Error("请填写有效的主页地址。");
              await l(g), b(g);
            }, "主页已更新。");
          }
        }
      )
    ] })
  ] }) });
}
function $l({
  title: t,
  icon: n,
  onClose: r,
  onMinimize: i,
  onFullscreen: a,
  isFullscreen: l = !1,
  children: s,
  onDragStart: c,
  actions: u,
  className: d,
  native: p = !1,
  closeLabel: h = "关闭窗口",
  closeShortcut: f
}) {
  return /* @__PURE__ */ o("div", { className: `fp-window${p ? " fp-window-native" : ""} ${d || ""}`, children: [
    /* @__PURE__ */ o(
      "header",
      {
        className: "fp-window-bar",
        onPointerDown: (m) => {
          m.button === 0 && !m.target.closest(
            "button,a,input,textarea,select,[data-no-drag]"
          ) && c?.(m);
        },
        "data-draggable": c ? !0 : void 0,
        children: [
          /* @__PURE__ */ o("div", { className: "fp-window-title", children: [
            n,
            /* @__PURE__ */ e("span", { "data-fp-tooltip": t, "data-fp-tooltip-side": "left", children: t })
          ] }),
          u && /* @__PURE__ */ e("div", { className: "fp-window-actions", "data-no-drag": !0, children: u }),
          /* @__PURE__ */ o("div", { className: "fp-window-controls", "data-no-drag": !0, children: [
            i && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": "最小化窗口",
                "data-fp-tooltip": "最小化",
                "data-fp-tooltip-side": "left",
                onClick: i,
                children: /* @__PURE__ */ e(jt, { size: 16 })
              }
            ),
            a && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": l ? "退出全屏" : "全屏",
                "data-fp-tooltip": l ? "退出全屏" : "全屏",
                "data-fp-tooltip-side": "left",
                onClick: a,
                children: l ? /* @__PURE__ */ e(jr, { size: 16 }) : /* @__PURE__ */ e(qr, { size: 16 })
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control fp-window-control-close",
                "aria-label": h,
                "data-fp-tooltip": f ? `${h}（${f}）` : h,
                "data-fp-tooltip-side": "left",
                onClick: r,
                children: /* @__PURE__ */ e(ke, { size: 16 })
              }
            )
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-window-body", children: s })
  ] });
}
const zl = yn(
  () => () => {
  }
);
function Qu(t, n) {
  const r = n.toLowerCase().split("+").map((l) => l.trim()), i = r.at(-1), a = (l) => r.includes(l);
  return t.key.toLowerCase() === i && (a("mod") ? t.ctrlKey || t.metaKey : t.ctrlKey === a("ctrl") && t.metaKey === a("meta")) && t.altKey === a("alt") && t.shiftKey === a("shift");
}
function vf({
  children: t,
  paused: n = !1
}) {
  const r = R(/* @__PURE__ */ new Map());
  Y(() => {
    const a = (l) => {
      if (n || l.defaultPrevented || l.isComposing || l.key === "Process")
        return;
      const s = l.target instanceof Element && !!l.target.closest(
        "input,textarea,[contenteditable=true],math-field,[role=dialog],[role=menu]"
      ), c = [...r.current.values()].sort(
        (u, d) => (d.priority || 0) - (u.priority || 0)
      );
      for (const u of c)
        if (!(u.enabled === !1 || s && !u.allowInInput || !Qu(l, u.keys))) {
          l.preventDefault(), u.run();
          break;
        }
    };
    return window.addEventListener("keydown", a), () => window.removeEventListener("keydown", a);
  }, [n]);
  const i = R((a) => {
    const l = Symbol(a.id);
    return r.current.set(l, a), () => {
      r.current.delete(l);
    };
  });
  return /* @__PURE__ */ e(zl.Provider, { value: i.current, children: t });
}
function wf(t) {
  const n = Wt(zl);
  Y(
    () => n(t),
    [
      n,
      t.id,
      t.keys,
      t.enabled,
      t.allowInInput,
      t.priority,
      t.run
    ]
  );
}
function kf({
  items: t,
  onChange: n,
  onReset: r
}) {
  const [i, a] = k(""), [l, s] = k(null), [c, u] = k("");
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "快捷键" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-pattern-input",
        "aria-label": "搜索快捷键",
        placeholder: "查找操作",
        value: i,
        onChange: (d) => a(d.target.value)
      }
    ),
    t.filter((d) => d.label.includes(i)).map((d) => /* @__PURE__ */ o("div", { className: "fp-shortcut-setting", children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `设置${d.label}快捷键`,
          onClick: () => {
            u(""), s(d.id);
          },
          onKeyDown: (p) => {
            if (l !== d.id) return;
            if (p.preventDefault(), p.stopPropagation(), p.key === "Escape") {
              s(null);
              return;
            }
            if (["Control", "Shift", "Alt", "Meta"].includes(p.key)) return;
            const h = [
              p.ctrlKey ? "Ctrl" : "",
              p.metaKey ? "Meta" : "",
              p.altKey ? "Alt" : "",
              p.shiftKey ? "Shift" : "",
              p.key
            ].filter(Boolean).join("+");
            if (t.some(
              (f) => f.id !== d.id && f.enabled && f.keys.toLowerCase() === h.toLowerCase()
            )) {
              u("这个快捷键已被其他操作使用。");
              return;
            }
            n(d.id, h, d.enabled), s(null);
          },
          children: l === d.id ? "按下新的快捷键…" : d.keys
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-pressed": d.enabled,
          onClick: () => n(d.id, d.keys, !d.enabled),
          children: d.enabled ? "已启用" : "已停用"
        }
      )
    ] }, d.id)),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "恢复默认" })
  ] });
}
function vr(t, n, r = { width: 300, height: 200 }) {
  const i = Math.min(n.width, Math.max(r.width, t.width)), a = Math.min(
    n.height,
    Math.max(r.height, t.height)
  );
  return {
    width: i,
    height: a,
    x: Math.max(0, Math.min(n.width - i, t.x)),
    y: Math.max(0, Math.min(n.height - a, t.y))
  };
}
function Nf({
  title: t,
  geometry: n,
  onGeometryChange: r,
  onClose: i,
  onMinimize: a,
  onFocus: l,
  children: s,
  zIndex: c = 40,
  minWidth: u = 300,
  minHeight: d = 200,
  contained: p = !1
}) {
  const [h, f] = k(!1), m = R(null), b = R(null), [g, v] = k(null);
  xe(() => {
    const x = () => {
      const z = p ? b.current?.parentElement : null, L = {
        width: z?.clientWidth || window.innerWidth,
        height: z?.clientHeight || window.innerHeight
      };
      v(
        (j) => j?.width === L.width && j.height === L.height ? j : L
      );
    };
    x();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(x);
    return p && b.current?.parentElement && C?.observe(b.current.parentElement), window.addEventListener("resize", x), () => {
      C?.disconnect(), window.removeEventListener("resize", x);
    };
  }, [p]);
  const w = g ? vr(n, g, {
    width: u,
    height: d
  }) : n, y = R(n);
  y.current = w;
  const N = (x, C) => {
    x.button !== 0 || h || x.target.closest(
      "button,input,textarea,a,[data-no-drag]"
    ) || (x.preventDefault(), x.currentTarget.setPointerCapture(x.pointerId), m.current = {
      mode: C,
      x: x.clientX,
      y: x.clientY,
      value: y.current
    }, l?.());
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: b,
      className: "fp-floating-window",
      role: "region",
      "aria-label": t,
      style: h ? { position: p ? "absolute" : "fixed", inset: 8, zIndex: c } : {
        position: p ? "absolute" : "fixed",
        left: w.x,
        top: w.y,
        width: w.width,
        height: w.height,
        zIndex: c
      },
      onPointerDown: l,
      onPointerMove: (x) => {
        const C = m.current;
        if (!C) return;
        const z = g || {
          width: window.innerWidth,
          height: window.innerHeight
        }, L = x.clientX - C.x, j = x.clientY - C.y;
        r(
          vr(
            C.mode === "move" ? {
              ...C.value,
              x: C.value.x + L,
              y: C.value.y + j
            } : {
              ...C.value,
              width: Math.max(
                u,
                Math.min(
                  z.width - C.value.x,
                  C.value.width + L
                )
              ),
              height: Math.max(
                d,
                Math.min(
                  z.height - C.value.y,
                  C.value.height + j
                )
              )
            },
            z,
            { width: u, height: d }
          )
        );
      },
      onPointerUp: () => {
        m.current = null;
      },
      onPointerCancel: () => {
        m.current = null;
      },
      children: [
        /* @__PURE__ */ e(
          $l,
          {
            title: t,
            onClose: i,
            onMinimize: a,
            onFullscreen: () => f((x) => !x),
            isFullscreen: h,
            onDragStart: (x) => N(x, "move"),
            children: s
          }
        ),
        !h && /* @__PURE__ */ e(
          "div",
          {
            className: "fp-window-resize",
            role: "separator",
            "aria-label": "调整窗口大小",
            "aria-orientation": "horizontal",
            tabIndex: 0,
            onPointerDown: (x) => N(x, "resize"),
            onKeyDown: (x) => {
              ["ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown"].includes(
                x.key
              ) && (x.preventDefault(), r(
                vr(
                  {
                    ...w,
                    width: Math.max(
                      u,
                      w.width + (x.key === "ArrowRight" ? 16 : x.key === "ArrowLeft" ? -16 : 0)
                    ),
                    height: Math.max(
                      d,
                      w.height + (x.key === "ArrowDown" ? 16 : x.key === "ArrowUp" ? -16 : 0)
                    )
                  },
                  g || {
                    width: window.innerWidth,
                    height: window.innerHeight
                  },
                  { width: u, height: d }
                )
              ));
            }
          }
        )
      ]
    }
  );
}
function Ju({
  url: t,
  onNavigate: n,
  onBack: r,
  onForward: i,
  canBack: a,
  canForward: l,
  loading: s,
  error: c,
  children: u
}) {
  const [d, p] = k(t), [h, f] = k("");
  return Y(() => p(t), [t]), /* @__PURE__ */ o("section", { className: "fp-browser-surface", children: [
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: (m) => {
          m.preventDefault();
          try {
            const b = _n(d);
            if (!b) throw Error();
            f(""), n(b);
          } catch {
            f("请输入有效的网址。");
          }
        },
        children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "后退",
              disabled: !a,
              onClick: r,
              children: "←"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "前进",
              disabled: !l,
              onClick: i,
              children: "→"
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "网页地址",
              value: d,
              onChange: (m) => p(m.target.value)
            }
          ),
          /* @__PURE__ */ e("button", { type: "submit", children: "前往" })
        ]
      }
    ),
    (c || h) && /* @__PURE__ */ e("p", { role: "alert", children: c || h }),
    s && /* @__PURE__ */ e("p", { role: "status", children: "正在打开网页…" }),
    /* @__PURE__ */ e("div", { children: u })
  ] });
}
function xf({
  title: t = "导入学习资料",
  accept: n,
  multiple: r = !0,
  onImport: i,
  children: a
}) {
  const l = R(null), [s, c] = k([]), [u, d] = k(""), p = (h) => {
    d(""), c(r ? h : h.slice(0, 1));
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "fp-import-drop",
        onDragOver: (h) => h.preventDefault(),
        onDrop: (h) => {
          h.preventDefault(), p(Array.from(h.dataTransfer.files));
        },
        children: [
          /* @__PURE__ */ e("p", { children: "将文件拖到这里，或选择文件。" }),
          /* @__PURE__ */ e(
            "input",
            {
              ref: l,
              type: "file",
              accept: n,
              multiple: r,
              hidden: !0,
              onChange: (h) => {
                p(Array.from(h.target.files || [])), h.target.value = "";
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => l.current?.click(), children: "选择文件" })
        ]
      }
    ),
    s.length > 0 && /* @__PURE__ */ e("ul", { children: s.map((h, f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { children: h.name }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `移除${h.name}`,
          onClick: () => c((m) => m.filter((b, g) => g !== f)),
          children: "移除"
        }
      )
    ] }, `${h.name}-${f}`)) }),
    a,
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      ye,
      {
        disabled: !s.length,
        onAction: async () => {
          const h = s;
          try {
            await i(h), c((f) => f === h ? [] : f);
          } catch (f) {
            throw d("资料已保留，可以重试。"), f;
          }
        },
        children: "开始导入"
      }
    ) }),
    u && /* @__PURE__ */ e("p", { role: "status", children: u })
  ] });
}
function Cf({
  children: t,
  fallback: n = null,
  margin: r = "240px"
}) {
  const i = R(null), [a, l] = k(!1);
  return Y(() => {
    if (!i.current) return;
    if (typeof IntersectionObserver > "u") {
      l(!0);
      return;
    }
    const s = new IntersectionObserver(
      (c) => {
        c.some((u) => u.isIntersecting) && (l(!0), s.disconnect());
      },
      { rootMargin: r }
    );
    return s.observe(i.current), () => s.disconnect();
  }, [r]), /* @__PURE__ */ e("div", { ref: i, children: a ? t : n });
}
function Sf({
  url: t,
  onNavigate: n,
  children: r,
  homeUrl: i,
  canBack: a,
  canForward: l,
  onBack: s,
  onForward: c,
  onRefresh: u,
  onOpenExternal: d,
  loading: p,
  error: h,
  viewport: f = "desktop",
  onViewportChange: m,
  bookmarks: b = [],
  onAddBookmark: g,
  onRemoveBookmark: v,
  onHomeChange: w
}) {
  const [y, N] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form fp-browser-workspace", children: [
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", "aria-label": "浏览器操作", children: [
      i && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "打开主页",
          onClick: () => {
            const x = _n(i);
            x && n(x);
          },
          children: /* @__PURE__ */ e(yo, { size: 17 })
        }
      ),
      u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "刷新网页",
          onClick: u,
          children: /* @__PURE__ */ e(Qn, { size: 17 })
        }
      ),
      m && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: () => m(f === "desktop" ? "mobile" : "desktop"),
          children: [
            f === "desktop" ? /* @__PURE__ */ e(ya, { size: 17 }) : /* @__PURE__ */ e(vo, { size: 17 }),
            /* @__PURE__ */ e("span", { children: f === "desktop" ? "桌面视图" : "手机视图" })
          ]
        }
      ),
      d && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "在浏览器中打开",
          onClick: () => d(t),
          children: /* @__PURE__ */ e(Vt, { size: 17 })
        }
      ),
      g && v && w && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "浏览与收藏设置",
          "aria-expanded": y,
          onClick: () => N(!y),
          children: /* @__PURE__ */ e(wo, { size: 17 })
        }
      )
    ] }),
    /* @__PURE__ */ e(ge, { children: y && g && v && w && /* @__PURE__ */ e(
      Xu,
      {
        bookmarks: b,
        homeUrl: i || "",
        onAdd: g,
        onRemove: v,
        onHomeChange: w,
        onOpen: (x) => {
          const C = b.find((z) => z.id === x);
          C && (n(C.url), N(!1));
        }
      }
    ) }),
    /* @__PURE__ */ e(
      Ju,
      {
        url: t,
        onNavigate: n,
        canBack: a,
        canForward: l,
        onBack: s,
        onForward: c,
        loading: p,
        error: h,
        children: /* @__PURE__ */ e("div", { className: "fp-browser-viewport", "data-viewport": f, children: r })
      }
    )
  ] });
}
function kn({ name: t, src: n, size: r = 36 }) {
  const [i, a] = k("");
  return /* @__PURE__ */ e("span", { className: "fp-avatar", role: "img", "aria-label": t, style: { width: r, height: r, flexShrink: 0 }, children: n && n !== i ? /* @__PURE__ */ e("img", { src: n, alt: "", referrerPolicy: "no-referrer", onError: () => a(n) }) : t.trim().slice(0, 1).toUpperCase() || "?" });
}
function Mf({ names: t = [], members: n, size: r = 28, label: i = "参与作者" }) {
  return /* @__PURE__ */ e("div", { className: "fp-avatar-group", role: "list", "aria-label": i, children: (n || t.map((a, l) => ({ id: String(l), name: a, src: void 0 }))).map((a) => /* @__PURE__ */ e("span", { role: "listitem", tabIndex: 0, "data-fp-tooltip": a.name, "aria-label": a.name, children: /* @__PURE__ */ e(kn, { name: a.name, src: a.src, size: r }) }, a.id)) });
}
function Ef({
  users: t,
  groups: n,
  protectedUserIds: r = [],
  onSaveUser: i,
  onSaveGroup: a,
  onDeleteGroup: l,
  renderUserDetails: s,
  onRefresh: c,
  loading: u,
  error: d
}) {
  const [p, h] = k("users"), [f, m] = k(""), [b, g] = k(0), [v, w] = k(
    null
  ), y = Pe(), N = (p === "users" ? t.map((C) => ({
    id: C.sub,
    label: C.name,
    description: C.email || C.sub,
    value: C
  })) : n.map((C) => ({
    id: C.id,
    label: C.name,
    description: `${C.members.length} 位成员 · ${C.description}`,
    value: C
  }))).filter(
    (C) => `${C.label} ${C.description}`.toLowerCase().includes(f.toLowerCase())
  ), x = Math.min(
    b,
    Math.max(0, Math.ceil(N.length / 20) - 1)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "用户与用户组", children: /* @__PURE__ */ o(
    ne,
    {
      title: "用户与授权",
      description: "管理成员资料、用户组和访问权限。",
      actions: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            disabled: u,
            onClick: () => w(
              p === "users" ? { sub: "", name: "", email: "", disabled: !1 } : {
                id: crypto.randomUUID(),
                name: "",
                description: "",
                members: []
              }
            ),
            children: p === "users" ? "添加用户" : "新建用户组"
          }
        ),
        c && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: y.busy,
            onClick: () => {
              y.run(c);
            },
            children: "刷新"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(
          Ge,
          {
            label: "成员类型",
            value: p,
            onChange: (C) => {
              h(C), g(0), m("");
            },
            items: [
              { id: "users", label: `用户 ${t.length}` },
              { id: "groups", label: `用户组 ${n.length}` }
            ]
          }
        ),
        /* @__PURE__ */ e(
          X,
          {
            label: "搜索成员",
            value: f,
            onChange: (C) => {
              m(C), g(0);
            }
          }
        ),
        /* @__PURE__ */ e(Ee, { error: d || y.error, message: y.message }),
        u ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取成员…" }) : /* @__PURE__ */ o(ee, { children: [
          /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: N.slice(x * 20, x * 20 + 20).map((C) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => w(C.value),
              children: [
                /* @__PURE__ */ e("span", { className: "fp-workspace-avatar", children: /* @__PURE__ */ e(kn, { name: C.label, src: "sub" in C.value ? C.value.avatar : void 0, size: 36 }) }),
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: C.label }),
                  /* @__PURE__ */ e("small", { children: C.description })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            C.id
          )) }),
          !N.length && /* @__PURE__ */ e("p", { children: "没有匹配的成员，试试其他关键词。" }),
          /* @__PURE__ */ o("footer", { className: "fp-workspace-pagination", children: [
            /* @__PURE__ */ o("span", { children: [
              N.length,
              " 项"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: !x,
                onClick: () => g(x - 1),
                children: "上一页"
              }
            ),
            /* @__PURE__ */ o("span", { children: [
              x + 1,
              " /",
              " ",
              Math.max(1, Math.ceil(N.length / 20))
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: (x + 1) * 20 >= N.length,
                onClick: () => g(x + 1),
                children: "下一页"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(ge, { children: v && ("members" in v ? /* @__PURE__ */ e(
          Zu,
          {
            group: v,
            users: t,
            onSave: a,
            onDelete: n.some((C) => C.id === v.id) ? l : void 0,
            onClose: () => w(null)
          },
          v.id
        ) : s?.(v, () => w(null)) || /* @__PURE__ */ e(
          Al,
          {
            protectedUser: r.includes(v.sub),
            user: v,
            existing: t.some((C) => C.sub === v.sub),
            onSave: i,
            onClose: () => w(null)
          },
          v.sub || "new"
        )) })
      ]
    }
  ) });
}
function Zu({
  group: t,
  users: n,
  onSave: r,
  onDelete: i,
  onClose: a
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = at(t), d = Pe(), [p, h] = k("");
  return /* @__PURE__ */ o(
    ne,
    {
      title: l.name || "新建用户组",
      actions: /* @__PURE__ */ e(
        ye,
        {
          confirm: c ? "放弃尚未保存的更改？" : void 0,
          disabled: d.busy,
          onAction: a,
          children: "关闭用户组"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组名称",
              value: l.name,
              onChange: (f) => s({ ...l, name: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组说明",
              value: l.description,
              onChange: (f) => s({ ...l, description: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "搜索候选成员",
              value: p,
              onChange: h
            }
          ),
          /* @__PURE__ */ e("div", { className: "fp-workspace-picker", children: n.filter(
            (f) => `${f.name} ${f.email || ""} ${f.sub}`.toLowerCase().includes(p.toLowerCase())
          ).map((f) => /* @__PURE__ */ e(
            Le,
            {
              label: f.name,
              description: f.email,
              checked: l.members.includes(f.sub),
              onChange: (m) => s({
                ...l,
                members: m ? [...l.members, f.sub] : l.members.filter((b) => b !== f.sub)
              })
            },
            f.sub
          )) }),
          /* @__PURE__ */ o("p", { children: [
            "已选 ",
            l.members.length,
            " 位成员"
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
            /* @__PURE__ */ e(
              dt,
              {
                busy: d.busy,
                dirty: c,
                label: "保存用户组",
                onClick: () => {
                  if (!l.name.trim()) {
                    d.setError("请填写用户组名称。");
                    return;
                  }
                  d.run(async () => {
                    await r(l), u(l);
                  }, "用户组已保存。");
                }
              }
            ),
            i && /* @__PURE__ */ e(
              ye,
              {
                confirm: "删除此用户组？通过该组获得的访问权限将失效。",
                onAction: async () => {
                  await i(l.id), a();
                },
                children: "删除用户组"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(Ee, { ...d })
      ]
    }
  );
}
function Al({
  user: t,
  existing: n = !0,
  protectedUser: r,
  onSave: i,
  emailEditable: a = !0,
  onClose: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = at(t), p = Pe();
  return /* @__PURE__ */ o(
    ne,
    {
      title: t.name || "添加用户",
      actions: l && /* @__PURE__ */ e(
        ye,
        {
          confirm: u ? "放弃尚未保存的更改？" : void 0,
          disabled: p.busy,
          onAction: l,
          children: "关闭用户"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: p.busy, children: [
          /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "账号",
                value: s.sub,
                disabled: n,
                onChange: (h) => c({ ...s, sub: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "显示名称",
                value: s.name,
                onChange: (h) => c({ ...s, name: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "邮箱",
                disabled: !a,
                hint: a ? void 0 : "邮箱由账号中心同步。",
                value: s.email || "",
                onChange: (h) => c({ ...s, email: h })
              }
            )
          ] }),
          /* @__PURE__ */ e(
            Le,
            {
              label: "停用此用户",
              checked: !!s.disabled,
              disabled: r,
              description: r ? "此账号受到保护。" : "保存后生效。",
              onChange: (h) => c({ ...s, disabled: h })
            }
          ),
          /* @__PURE__ */ e(
            dt,
            {
              busy: p.busy,
              dirty: u,
              label: "保存资料",
              onClick: () => {
                if (!/^[\w-]{1,128}$/.test(s.sub) || !s.name.trim()) {
                  p.setError("请填写有效的账号和显示名称。");
                  return;
                }
                p.run(async () => {
                  await i(s), d(s);
                }, "用户资料已保存。");
              }
            }
          )
        ] }),
        /* @__PURE__ */ e(Ee, { ...p })
      ]
    }
  );
}
function Ll({
  usedBytes: t,
  capacityBytes: n,
  onSave: r
}) {
  const {
    draft: i,
    setDraft: a,
    dirty: l,
    accept: s
  } = at(
    String(Math.round(n / 1073741824 * 100) / 100)
  ), c = Pe();
  return /* @__PURE__ */ o(
    ne,
    {
      title: "存储额度",
      description: `已使用 ${(t / 1024 ** 3).toFixed(2)} GB`,
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "总存储额度（GB）",
            numeric: !0,
            value: i,
            onChange: a,
            hint: "调整额度会保留已上传的资料。"
          }
        ),
        /* @__PURE__ */ e(
          dt,
          {
            busy: c.busy,
            dirty: l,
            onClick: () => {
              const u = Number(i);
              if (!Number.isFinite(u) || u < 1 || u > 102400) {
                c.setError("请输入 1 至 102400 GB 的有效额度。");
                return;
              }
              c.run(async () => {
                await r(u, n), s(i);
              }, "存储额度已保存。");
            }
          }
        ),
        /* @__PURE__ */ e(Ee, { ...c })
      ]
    }
  );
}
function Il({
  name: t,
  enabled: n,
  protectedUser: r,
  onSave: i
}) {
  const {
    draft: a,
    setDraft: l,
    dirty: s,
    accept: c
  } = at(n);
  return /* @__PURE__ */ o(
    ne,
    {
      title: "平台管理权限",
      description: "平台管理员可以管理课程、用户和计费配置。",
      children: [
        /* @__PURE__ */ e(
          Le,
          {
            label: "允许进入管理中心",
            checked: a,
            disabled: r,
            description: r ? "当前账号或平台负责人的权限受到保护。" : void 0,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(
          ye,
          {
            disabled: r || !s,
            confirm: `确认${a ? "授予" : "收回"} ${t} 的平台管理权限？`,
            onAction: async () => {
              await i(a), c(a);
            },
            children: "保存权限"
          }
        )
      ]
    }
  );
}
function ep({
  items: t,
  value: n,
  onChange: r,
  label: i = "产品导航",
  variant: a = "tabs",
  compact: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-product-navigation", "data-variant": a, "data-compact": l || void 0, "aria-label": i, children: t.map((s) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-label": l ? s.label : void 0,
      "data-fp-tooltip": s.label,
      "data-fp-tooltip-side": a === "rail" ? "right" : "bottom",
      "aria-current": s.id === n ? "page" : void 0,
      disabled: s.disabled,
      onClick: () => r(s.id),
      children: [
        s.icon,
        /* @__PURE__ */ e("span", { children: s.label }),
        s.detail && /* @__PURE__ */ e("small", { children: s.detail })
      ]
    },
    s.id
  )) });
}
function $f({
  items: t,
  onOpen: n,
  actions: r,
  loading: i,
  error: a,
  onCreate: l
}) {
  const [s, c] = k(""), u = t.filter(
    (d) => `${d.title} ${d.subtitle || ""} ${d.group || ""}`.toLowerCase().includes(s.toLowerCase())
  );
  return /* @__PURE__ */ o("section", { className: "fp-bookshelf", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的笔记本" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "新建笔记本" })
    ] }),
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(Ue, { size: 16 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索笔记本",
          value: s,
          placeholder: "搜索笔记本",
          onChange: (d) => c(d.target.value)
        }
      )
    ] }),
    a && /* @__PURE__ */ e("p", { role: "alert", children: a }),
    i ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ e("div", { className: "fp-bookshelf-grid", children: u.map((d) => /* @__PURE__ */ e(
      xt,
      {
        disabled: !r,
        items: () => r?.(d) || [],
        label: `${d.title}的操作`,
        children: /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-book",
            onClick: () => n(d.id),
            children: [
              d.coverUrl ? /* @__PURE__ */ e("img", { src: d.coverUrl, alt: "" }) : /* @__PURE__ */ e("span", { className: "fp-book-cover", children: /* @__PURE__ */ e(et, { size: 25 }) }),
              /* @__PURE__ */ e("strong", { children: d.title }),
              d.subtitle && /* @__PURE__ */ e("small", { children: d.subtitle }),
              d.detail && /* @__PURE__ */ e("small", { children: d.detail }),
              d.progress !== void 0 && /* @__PURE__ */ e(
                "progress",
                {
                  "aria-label": `${d.title}的学习进度`,
                  value: Math.min(100, Math.max(0, d.progress)),
                  max: 100
                }
              )
            ]
          }
        )
      },
      d.id
    )) }),
    !u.length && !i && /* @__PURE__ */ e("p", { children: s ? "没有找到匹配的笔记本。" : "创建一本笔记本，开始整理学习内容。" })
  ] });
}
function zf({
  title: t,
  onBack: n,
  actions: r
}) {
  return /* @__PURE__ */ o("header", { className: "fp-mobile-topbar", children: [
    n && /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回", onClick: n, children: "‹" }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: r })
  ] });
}
function Af({
  title: t,
  navigation: n,
  activeId: r,
  onNavigate: i,
  profile: a,
  children: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-account-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: t }),
      a,
      /* @__PURE__ */ e(
        ep,
        {
          items: n,
          value: r,
          onChange: i,
          label: "账户功能"
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-account-content", children: l })
  ] });
}
function Lf({
  onLogin: t,
  heading: n = "登录课栈",
  description: r = "继续整理笔记，与同学一起学习。",
  alternate: i
}) {
  const [a, l] = k(""), [s, c] = k(""), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(!1), b = R(!1);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel fp-login-form", children: [
    /* @__PURE__ */ e("h2", { children: n }),
    /* @__PURE__ */ e("p", { children: r }),
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: async (g) => {
          if (g.preventDefault(), !(b.current || !a.trim() || !s)) {
            b.current = !0, d(!0), h("");
            try {
              await t(a.trim(), s);
            } catch (v) {
              h(
                v instanceof Error ? v.message : "登录未能完成，请检查账号和密码。"
              );
            } finally {
              b.current = !1, d(!1);
            }
          }
        },
        children: [
          /* @__PURE__ */ o("label", { children: [
            "账号",
            /* @__PURE__ */ e(
              "input",
              {
                "aria-label": "账号",
                autoComplete: "username",
                required: !0,
                value: a,
                disabled: u,
                onChange: (g) => l(g.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ o("label", { children: [
            "密码",
            /* @__PURE__ */ o("div", { className: "fp-password-entry", children: [
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "密码",
                  autoComplete: "current-password",
                  required: !0,
                  type: f ? "text" : "password",
                  value: s,
                  disabled: u,
                  onChange: (g) => c(g.target.value)
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  "aria-label": f ? "隐藏密码" : "显示密码",
                  onClick: () => m((g) => !g),
                  children: f ? "隐藏" : "显示"
                }
              )
            ] })
          ] }),
          p && /* @__PURE__ */ e("p", { role: "alert", children: p }),
          /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e("button", { type: "submit", disabled: u || !a.trim() || !s, children: u ? "正在登录…" : "登录" }) })
        ]
      }
    ),
    i
  ] });
}
function If({
  name: t,
  avatarUrl: n,
  description: r,
  details: i,
  actions: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { className: "fp-profile-heading", children: [
        n ? /* @__PURE__ */ e("img", { src: n, alt: "" }) : /* @__PURE__ */ e("span", { "aria-hidden": "true", children: t.slice(0, 1) }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: t }),
          r && /* @__PURE__ */ e("small", { children: r })
        ] })
      ] }),
      a
    ] }),
    /* @__PURE__ */ e("dl", { className: "fp-detail-list", children: i.map((l, s) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, s)) })
  ] });
}
function tp({
  name: t,
  balance: n,
  onSubmit: r
}) {
  const [i, a] = k(""), [l, s] = k(""), c = Number(i);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("h3", { children: [
      "调整",
      t,
      "的积分"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "当前可用 ",
      n.toLocaleString(),
      " 积分"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-settings-fields", children: [
      /* @__PURE__ */ o("label", { children: [
        "调整数量",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整数量",
            inputMode: "numeric",
            value: i,
            onChange: (u) => a(u.target.value)
          }
        ),
        /* @__PURE__ */ e("small", { children: "正数增加，负数扣减。" })
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "调整原因",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整原因",
            value: l,
            onChange: (u) => s(u.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      ye,
      {
        disabled: !i.trim() || !Number.isSafeInteger(c) || c === 0 || !l.trim() || n + c < 0,
        confirm: `将${c >= 0 ? "增加" : "扣减"} ${Math.abs(c) || 0} 积分，确认继续？`,
        onAction: () => r(c, l.trim()),
        children: "确认调整"
      }
    ) })
  ] });
}
function np({
  item: t,
  onRespond: n
}) {
  const [r, i] = k(!1), a = R(!1), l = async (s) => {
    if (!a.current) {
      a.current = !0, i(!0);
      try {
        await n(t.id, s);
      } finally {
        a.current = !1, i(!1);
      }
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
    /* @__PURE__ */ e(ye, { disabled: r, onAction: () => l(!0), children: "接受" }),
    /* @__PURE__ */ e(ye, { disabled: r, onAction: () => l(!1), children: "婉拒" })
  ] });
}
function Df({
  items: t,
  onRespond: n,
  loading: r,
  error: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "协作邀请" }),
    i && /* @__PURE__ */ e("p", { role: "alert", children: i }),
    /* @__PURE__ */ e(ge, { children: r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取邀请…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((a) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: a.name }),
        /* @__PURE__ */ o("small", { children: [
          a.from,
          " 邀请你",
          a.role,
          a.date && ` · ${a.date}`
        ] })
      ] }),
      /* @__PURE__ */ e(np, { item: a, onRespond: n })
    ] }, a.id)) }) : /* @__PURE__ */ e("p", { children: "暂时没有待处理的邀请。" }) })
  ] });
}
function Tf({
  items: t,
  value: n,
  onChange: r,
  label: i = "选择目录",
  onConfirm: a
}) {
  const l = (s) => {
    const c = [s.name], u = /* @__PURE__ */ new Set([s.id]);
    let d = s;
    for (; d.parentId; ) {
      const p = t.find((h) => h.id === d.parentId);
      if (!p || u.has(p.id)) break;
      c.unshift(p.name), u.add(p.id), d = p;
    }
    return c.join(" / ");
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: i }),
    /* @__PURE__ */ e(
      Ce,
      {
        label: i,
        value: n,
        onChange: r,
        searchable: !0,
        options: t.map((s) => ({
          value: s.id,
          label: s.name,
          description: l(s),
          disabled: s.disabled
        }))
      }
    ),
    a && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      ye,
      {
        disabled: !t.some((s) => s.id === n && !s.disabled),
        onAction: a,
        children: "选择此目录"
      }
    ) })
  ] });
}
function Pf({
  plans: t,
  onSelect: n
}) {
  return /* @__PURE__ */ e("section", { className: "fp-plan-picker", "aria-label": "选择方案", children: t.map((r) => /* @__PURE__ */ o(
    "article",
    {
      className: "fp-pattern-panel",
      "data-current": r.current || void 0,
      children: [
        /* @__PURE__ */ e("h3", { children: r.name }),
        /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: r.price }),
        /* @__PURE__ */ e("p", { children: r.description }),
        /* @__PURE__ */ e("ul", { children: r.features.map((i) => /* @__PURE__ */ e("li", { children: i }, i)) }),
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: r.current || r.disabled,
            onClick: () => n(r.id),
            children: r.current ? "当前方案" : "查看方案"
          }
        ) })
      ]
    },
    r.id
  )) });
}
function Ff(t) {
  return /* @__PURE__ */ e(rp, { ...t }, t.user.sub || "new");
}
function rp({
  user: t,
  groups: n,
  existing: r = !0,
  protectedUser: i,
  storage: a,
  credits: l,
  administrator: s,
  loading: c,
  error: u,
  onSaveProfile: d,
  onSaveCapacity: p,
  onAdjustCredits: h,
  onSaveAdministrator: f,
  onRetry: m,
  canManageAdministrator: b = !0,
  emailEditable: g = !0,
  usage: v,
  notebooks: w
}) {
  const [y, N] = k("profile");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ne, { title: y === "profile" ? void 0 : t.name || "添加用户", children: [
    /* @__PURE__ */ e(
      Ge,
      {
        label: "用户详情",
        value: y,
        onChange: N,
        items: [
          { id: "profile", label: "资料" },
          ...r ? [
            ...v ? [{ id: "usage", label: "使用统计" }] : [],
            ...w ? [{ id: "notebooks", label: "笔记本" }] : [],
            { id: "storage", label: "存储" },
            { id: "credits", label: "积分" },
            { id: "access", label: "平台权限" }
          ] : []
        ]
      }
    ),
    /* @__PURE__ */ e(Ee, { error: u }),
    u && m && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: m,
        children: "重试"
      }
    ),
    /* @__PURE__ */ o(ge, { children: [
      /* @__PURE__ */ e("div", { hidden: y !== "usage", children: v }),
      /* @__PURE__ */ e("div", { hidden: y !== "notebooks", children: w }),
      /* @__PURE__ */ o("div", { hidden: y !== "profile", children: [
        /* @__PURE__ */ e(
          Al,
          {
            user: t,
            emailEditable: g,
            existing: r,
            protectedUser: i,
            onSave: d
          }
        ),
        /* @__PURE__ */ e(ne, { title: "所在用户组", children: /* @__PURE__ */ e("p", { children: n.filter((x) => x.members.includes(t.sub)).map((x) => x.name).join("、") || "尚未加入用户组" }) })
      ] }),
      /* @__PURE__ */ e("div", { hidden: y !== "storage", children: a && p ? /* @__PURE__ */ e(
        Ll,
        {
          usedBytes: a.used,
          capacityBytes: a.capacity,
          onSave: p
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取存储信息…" : "存储信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: y !== "credits", children: l !== void 0 && h ? /* @__PURE__ */ e(
        tp,
        {
          name: t.name,
          balance: l,
          onSubmit: h
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取积分…" : "积分信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: y !== "access", children: b ? s !== void 0 && f ? /* @__PURE__ */ e(
        Il,
        {
          name: t.name,
          enabled: s,
          protectedUser: i,
          onSave: f
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取管理权限…" : "管理权限暂不可用。" }) : /* @__PURE__ */ o(ne, { title: "平台管理权限", children: [
        /* @__PURE__ */ e("p", { children: s ? "平台管理员" : "普通用户" }),
        /* @__PURE__ */ e("p", { children: "仅超级管理员可以调整平台管理权限。" })
      ] }) })
    ] })
  ] }) });
}
function Of({
  value: t,
  onSave: n,
  onConfigureStorage: r
}) {
  const { draft: i, setDraft: a, dirty: l, accept: s } = at(t), c = Pe(), u = i.documentProcessing.quark, d = (h, f) => a({
    ...i,
    providers: i.providers.map(
      (m, b) => b === h ? { ...m, ...f } : m
    )
  }), p = (h) => a({
    ...i,
    documentProcessing: {
      ...i.documentProcessing,
      quark: { ...u, ...h }
    }
  });
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ne,
    {
      title: "站点与学习服务",
      description: "管理站点信息、模型连接和资料识别。",
      actions: /* @__PURE__ */ e(
        dt,
        {
          busy: c.busy,
          dirty: l,
          onClick: () => {
            if (!i.siteName.trim() || !i.accountName.trim() || i.supportUrl && !/^https?:\/\//.test(i.supportUrl) || !Number.isInteger(u.pagesPerRequest) || u.pagesPerRequest < 1 || u.pagesPerRequest > 4 || new Set(i.providers.map((h) => h.id)).size !== i.providers.length || i.providers.some(
              (h) => !/^[a-z0-9-]+$/.test(h.id) || !h.name.trim() || h.enabled && !/^https?:\/\//.test(h.baseUrl)
            )) {
              c.setError("请检查站点名称、服务地址和识别页数。");
              return;
            }
            c.run(
              async () => s(await n(i) || i),
              "平台设置已保存。"
            );
          }
        }
      ),
      children: [
        /* @__PURE__ */ e(Ee, { ...c }),
        /* @__PURE__ */ o("fieldset", { disabled: c.busy, children: [
          /* @__PURE__ */ o(ne, { title: "站点信息", children: [
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "站点名称",
                  value: i.siteName,
                  onChange: (h) => a({ ...i, siteName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "账号品牌",
                  value: i.accountName,
                  onChange: (h) => a({ ...i, accountName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "帮助中心地址",
                  value: i.supportUrl,
                  onChange: (h) => a({ ...i, supportUrl: h })
                }
              )
            ] }),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: r,
                children: "配置资料存储"
              }
            )
          ] }),
          /* @__PURE__ */ e(
            ne,
            {
              title: "模型供应商",
              description: "保存密钥后，仅显示配置状态。",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => a({
                    ...i,
                    providers: [
                      ...i.providers,
                      {
                        id: `service-${crypto.randomUUID().slice(0, 8)}`,
                        name: "模型服务",
                        baseUrl: "",
                        apiKey: "",
                        enabled: !1,
                        models: []
                      }
                    ]
                  }),
                  children: "添加供应商"
                }
              ),
              children: i.providers.map((h, f) => /* @__PURE__ */ o(ne, { title: h.name || "模型服务", children: [
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "连接标识",
                      value: h.id,
                      onChange: (m) => d(f, { id: m }),
                      hint: "使用小写字母、数字和连字符。"
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务名称",
                      value: h.name,
                      onChange: (m) => d(f, { name: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务地址",
                      value: h.baseUrl,
                      onChange: (m) => d(f, { baseUrl: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务密钥",
                      secret: !0,
                      value: h.apiKey,
                      hint: h.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (m) => d(f, { apiKey: m })
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "可用模型",
                    multiline: !0,
                    value: h.models.join(`
`),
                    hint: "每行填写一个模型名称。",
                    onChange: (m) => d(f, {
                      models: m.split(`
`).map((b) => b.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  Le,
                  {
                    label: `启用 ${h.name}`,
                    checked: h.enabled,
                    onChange: (m) => d(f, { enabled: m })
                  }
                ),
                /* @__PURE__ */ e(
                  ye,
                  {
                    confirm: "移除此供应商？保存后生效。",
                    onAction: () => a({
                      ...i,
                      providers: i.providers.filter((m, b) => b !== f)
                    }),
                    children: "移除供应商"
                  }
                )
              ] }, f))
            }
          ),
          /* @__PURE__ */ o(
            ne,
            {
              title: "扫描识别",
              description: "将扫描资料中的文字、表格与公式转为可阅读内容。",
              children: [
                /* @__PURE__ */ e(
                  Le,
                  {
                    label: "启用扫描识别",
                    checked: u.enabled,
                    onChange: (h) => p({ enabled: h })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "识别服务密钥",
                      secret: !0,
                      value: u.apiKey,
                      hint: u.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (h) => p({ apiKey: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "默认识别方式",
                      value: u.scene,
                      options: [
                        { value: "general-ocr", label: "通用识别" },
                        { value: "formula-recognition", label: "公式识别" },
                        { value: "table-recognition", label: "表格识别" }
                      ],
                      onChange: (h) => p({ scene: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "每批处理页数",
                      numeric: !0,
                      value: u.pagesPerRequest,
                      onChange: (h) => p({ pagesPerRequest: Number(h) })
                    }
                  )
                ] })
              ]
            }
          )
        ] })
      ]
    }
  ) });
}
function Rf({
  users: t,
  enabledIds: n,
  protectedIds: r,
  onSave: i
}) {
  const [a, l] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ne, { title: "平台管理员", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索管理员账户",
        value: a,
        onChange: l
      }
    ),
    t.filter(
      (s) => `${s.name} ${s.email || ""} ${s.sub}`.toLowerCase().includes(a.toLowerCase())
    ).map((s) => /* @__PURE__ */ e(
      Il,
      {
        name: s.name,
        enabled: n.includes(s.sub),
        protectedUser: r.includes(s.sub),
        onSave: (c) => i(s.sub, c)
      },
      `${s.sub}-${n.includes(s.sub)}`
    ))
  ] }) });
}
function Bf({
  entries: t,
  onSave: n
}) {
  const [r, i] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ne, { title: "用户存储", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索存储账户",
        value: r,
        onChange: i
      }
    ),
    t.filter(
      (a) => a.name.toLowerCase().includes(r.toLowerCase())
    ).map((a) => /* @__PURE__ */ e(ne, { title: a.name, children: /* @__PURE__ */ e(
      Ll,
      {
        usedBytes: a.used,
        capacityBytes: a.capacity,
        onSave: (l, s) => n(a.id, l, s)
      }
    ) }, a.id))
  ] }) });
}
function jf({
  canReset: t,
  confirmation: n = "重置课栈平台",
  onReset: r
}) {
  const [i, a] = k(""), l = Pe();
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ne,
    {
      title: "重新配置平台",
      description: "重新设置平台服务，已保存的课程、笔记和资料会保留。",
      children: [
        t ? /* @__PURE__ */ o(ee, { children: [
          /* @__PURE__ */ e(
            X,
            {
              label: `输入“${n}”确认`,
              value: i,
              onChange: a,
              disabled: l.busy
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              disabled: l.busy || i !== n,
              onClick: () => {
                l.run(r, "平台配置已重置。");
              },
              children: l.busy ? "正在重新配置…" : "重置并重新配置"
            }
          )
        ] }) : /* @__PURE__ */ e("p", { children: "请联系平台负责人进行此项操作。" }),
        /* @__PURE__ */ e(Ee, { ...l })
      ]
    }
  ) });
}
function qf({
  questions: t,
  onSelect: n,
  sourceCount: r = 0,
  onOpenSources: i,
  title: a = "你可能还想问"
}) {
  return /* @__PURE__ */ e(ge, { children: (t.length > 0 || r > 0) && /* @__PURE__ */ o("section", { className: "fp-followup-questions", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t.length ? a : "参考资料" }),
      r > 0 && i && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          onClick: i,
          children: [
            "来源 · ",
            r
          ]
        }
      )
    ] }),
    t.map((l, s) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-followup-question",
        onClick: () => n(l),
        children: /* @__PURE__ */ e(
          Ca,
          {
            remarkPlugins: [Sa],
            rehypePlugins: [Ma],
            components: {
              a: ({ children: c }) => /* @__PURE__ */ e("span", { children: c }),
              img: ({ alt: c }) => /* @__PURE__ */ e("span", { children: c })
            },
            children: l
          }
        )
      },
      s
    ))
  ] }) });
}
function Dl({ label: t = "正在打开内容", variant: n = "document" }) {
  return /* @__PURE__ */ o("div", { className: `fp-content-skeleton fp-content-skeleton-${n}`, role: "status", "aria-label": t, "aria-busy": "true", children: [
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-title" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" }),
    /* @__PURE__ */ e("div", { className: "fp-content-skeleton-block" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" })
  ] });
}
function Kf({
  title: t,
  markdown: n,
  entries: r = [],
  selectedId: i,
  onNavigate: a,
  headings: l = [],
  loading: s,
  error: c,
  onRetry: u,
  access: d = "granted",
  onSignIn: p,
  toolbar: h,
  footer: f,
  onCopyReference: m,
  contentProps: b,
  content: g,
  navigation: v,
  brand: w,
  account: y,
  authors: N,
  collection: x
}) {
  const [C, z] = k(null), [L, j] = k(""), M = Pe(), A = ve().replace(/:/g, ""), [O, U] = k(""), T = R(null);
  Y(() => {
    if (!C) return;
    const q = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const H = (I) => {
      I.key === "Escape" && z(null);
    };
    return window.addEventListener("keydown", H), () => {
      window.removeEventListener("keydown", H), document.body.style.overflow = q, T.current?.focus({ preventScroll: !0 });
    };
  }, [C]), Y(() => {
    if (!l.length || typeof IntersectionObserver > "u") return;
    const q = document.getElementById(A);
    if (!q) return;
    const H = /* @__PURE__ */ new Map(), I = new IntersectionObserver(
      ($) => {
        for (const J of $)
          J.isIntersecting ? H.set(J.target.id, J.boundingClientRect.top) : H.delete(J.target.id);
        const B = [...H].sort((J, Z) => J[1] - Z[1])[0];
        B && j(B[0]);
      },
      { rootMargin: "-10% 0px -65% 0px" }
    );
    for (const $ of q.querySelectorAll("h2[id],h3[id],h4[id]"))
      I.observe($);
    return () => I.disconnect();
  }, [A, n, l.length, s, d]), Y(() => {
    z(null), j("");
  }, [i]);
  const S = n.trimStart().match(/^#\s+(.+?)(?:\s+#+)?\s*(?:\r?\n|$)/)?.[1].trim() !== t.trim(), P = v ?? /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e("h2", { children: "笔记目录" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-input",
        "aria-label": "搜索分享笔记",
        value: O,
        placeholder: "搜索笔记",
        onChange: (q) => U(q.target.value)
      }
    ),
    /* @__PURE__ */ e("nav", { "aria-label": "分享笔记", children: r.filter(
      (q) => `${q.title} ${q.group || ""}`.toLowerCase().includes(O.toLowerCase())
    ).map((q, H, I) => /* @__PURE__ */ o("div", { children: [
      q.group && (H === 0 || I[H - 1].group !== q.group) && /* @__PURE__ */ e("h3", { children: q.group }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-note",
          "aria-current": i === q.id ? "page" : void 0,
          onClick: () => {
            a?.(q.id), z(null);
          },
          children: q.title
        }
      )
    ] }, q.id)) })
  ] }), _ = /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e("h2", { children: "本页目录" }),
    /* @__PURE__ */ e("nav", { "aria-label": "本页目录", children: l.map((q) => /* @__PURE__ */ e(
      "a",
      {
        href: `#${q.id}`,
        "aria-current": L === q.id ? "location" : void 0,
        style: {
          paddingInlineStart: Math.max(0, q.level - 1) * 12 + 12
        },
        onClick: (H) => {
          H.preventDefault(), document.getElementById(A)?.querySelector(`[id="${CSS.escape(q.id)}"]`)?.scrollIntoView({
            behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
            block: "start"
          }), j(q.id), z(null);
        },
        children: q.title
      },
      q.id
    )) })
  ] });
  return /* @__PURE__ */ o("div", { className: "fp-shared-reading", children: [
    /* @__PURE__ */ o("header", { className: "fp-shared-header", children: [
      w ?? /* @__PURE__ */ e("a", { href: "https://fiveplus.one/", "aria-label": "五加一主页", children: /* @__PURE__ */ e(
        "img",
        {
          src: "https://go.r-l.ink/ico",
          alt: "五加一",
          width: 28,
          height: 28
        }
      ) }),
      /* @__PURE__ */ e("strong", { children: x?.title || t }),
      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
        h,
        y,
        p && d !== "granted" && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-shared-mobile-bar", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (q) => {
            T.current = q.currentTarget, z("notes");
          },
          children: [
            /* @__PURE__ */ e(un, { size: 16 }),
            "笔记"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (q) => {
            T.current = q.currentTarget, z("contents");
          },
          children: [
            /* @__PURE__ */ e(dn, { size: 16 }),
            "目录"
          ]
        }
      )
    ] }),
    C && /* @__PURE__ */ e(
      "div",
      {
        className: "fp-shared-drawer-backdrop",
        onClick: () => z(null),
        children: /* @__PURE__ */ o(
          "aside",
          {
            className: "fp-shared-drawer",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": C === "notes" ? "笔记目录" : "本页目录",
            onClick: (q) => q.stopPropagation(),
            onKeyDown: (q) => {
              if (q.key !== "Tab") return;
              const H = [
                ...q.currentTarget.querySelectorAll(
                  "button,a,input"
                )
              ], I = H[0], $ = H.at(-1);
              q.shiftKey && document.activeElement === I ? (q.preventDefault(), $?.focus()) : !q.shiftKey && document.activeElement === $ && (q.preventDefault(), I?.focus());
            },
            children: [
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  autoFocus: !0,
                  className: "fp-shared-close",
                  "aria-label": "关闭目录",
                  onClick: () => z(null),
                  children: /* @__PURE__ */ e(ke, { size: 18 })
                }
              ),
              C === "notes" ? P : _
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ o("div", { className: "fp-shared-layout", children: [
      /* @__PURE__ */ e("aside", { className: "fp-shared-navigation", children: P }),
      /* @__PURE__ */ e("main", { id: A, children: /* @__PURE__ */ e(ge, { children: s ? /* @__PURE__ */ e(Dl, { label: "正在打开笔记" }) : c ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: c }),
        u && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            onClick: u,
            children: "重试"
          }
        )
      ] }) : d !== "granted" ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", children: [
        /* @__PURE__ */ e("h1", { children: d === "sign-in" ? "登录后阅读" : "这篇笔记尚未向你分享" }),
        /* @__PURE__ */ e("p", { children: d === "sign-in" ? "登录账户，继续查看分享内容。" : "请联系分享者获取访问权限。" }),
        d === "sign-in" && p && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录并继续"
          }
        )
      ] }) : /* @__PURE__ */ o(ee, { children: [
        x && /* @__PURE__ */ o("section", { className: "fp-shared-collection", "aria-label": "分享笔记本", children: [
          /* @__PURE__ */ o("div", { className: "fp-shared-collection-title", children: [
            /* @__PURE__ */ e(et, { size: 23, "aria-hidden": "true" }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("strong", { children: x.title }),
              x.byline && /* @__PURE__ */ e("span", { children: x.byline })
            ] })
          ] }),
          x.description && /* @__PURE__ */ e("p", { children: x.description }),
          x.actions && /* @__PURE__ */ e("div", { className: "fp-shared-collection-actions", children: x.actions })
        ] }),
        S && /* @__PURE__ */ e("h1", { children: t }),
        N && /* @__PURE__ */ e("div", { className: "fp-reading-authors", "aria-label": "参与作者", children: N }),
        m && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: M.busy,
            onClick: () => {
              M.run(
                () => m({
                  title: t,
                  text: (() => {
                    const q = window.getSelection();
                    return q?.anchorNode && document.getElementById(A)?.contains(q.anchorNode) && q.toString() || t;
                  })(),
                  heading: L || void 0
                }),
                "引用已复制"
              );
            },
            children: [
              /* @__PURE__ */ e(vn, { size: 15 }),
              "复制引用"
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { ...M }),
        g ?? /* @__PURE__ */ e(Nt, { ...b, markdown: n }),
        f
      ] }) }) }),
      /* @__PURE__ */ e("aside", { className: "fp-shared-contents", children: _ })
    ] })
  ] });
}
function Hf({
  available: t,
  onRefresh: n,
  onDismiss: r,
  beforeRefresh: i
}) {
  const a = Pe();
  return /* @__PURE__ */ e(ge, { children: t && /* @__PURE__ */ o("aside", { className: "fp-release-notice", "aria-label": "应用更新", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: "新版本已就绪" }),
      /* @__PURE__ */ e("p", { children: "更新后继续使用最新功能。" }),
      /* @__PURE__ */ e(Ee, { ...a })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: a.busy,
          onClick: () => {
            a.run(async () => {
              if (i && !await i()) {
                a.setMessage("请先保存当前内容。");
                return;
              }
              await n();
            });
          },
          children: a.busy ? "正在更新…" : "立即更新"
        }
      ),
      r && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-close",
          "aria-label": "稍后更新",
          onClick: r,
          children: /* @__PURE__ */ e(ke, { size: 17 })
        }
      )
    ] })
  ] }) });
}
function Uf({
  currentVersion: t,
  checkVersion: n,
  interval: r = 6e4,
  enabled: i = !0,
  onError: a
}) {
  const [l, s] = k(t), [c, u] = k(""), d = R({ checkVersion: n, onError: a });
  return d.current = { checkVersion: n, onError: a }, Y(() => {
    if (!i) return;
    let p = null, h = !0;
    const f = async () => {
      if (p || document.visibilityState === "hidden") return;
      const g = new AbortController();
      p = g;
      try {
        const v = await d.current.checkVersion(g.signal);
        h && !g.signal.aborted && v && s(v);
      } catch (v) {
        g.signal.aborted || d.current.onError?.(v);
      } finally {
        p === g && (p = null);
      }
    }, m = () => {
      f();
    }, b = setInterval(m, Math.max(1e3, r));
    return window.addEventListener("focus", m), document.addEventListener("visibilitychange", m), m(), () => {
      h = !1, p?.abort(), clearInterval(b), window.removeEventListener("focus", m), document.removeEventListener("visibilitychange", m);
    };
  }, [t, r, i]), {
    available: l !== t && l !== c,
    version: l,
    dismiss: () => u(l)
  };
}
function Wf({
  value: t,
  onChange: n,
  onRevise: r,
  renderMolecule: i,
  recorder: a,
  onDiagnostic: l
}) {
  const [s, c] = k(null), [u, d] = k("current"), p = Pe(), h = R(null), f = R(t);
  return f.current = t, Y(() => () => h.current?.abort(), []), Y(() => {
    c(null), d("current"), h.current?.abort();
  }, [t]), /* @__PURE__ */ e(Ya.Provider, { value: i || null, children: /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-canvas-workspace", children: /* @__PURE__ */ o(
    ne,
    {
      title: t.title || "学习画布",
      description: "探索图形，提出修改，再确认需要保留的版本。",
      children: [
        /* @__PURE__ */ e(
          Ge,
          {
            label: "画布版本",
            value: u,
            onChange: d,
            items: [
              { id: "current", label: "当前版本" },
              ...s ? [{ id: "candidate", label: "修改预览" }] : [],
              ...a ? [{ id: "recording", label: "操作回放" }] : []
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { ...p }),
        /* @__PURE__ */ e(ge, { children: u === "recording" ? a : /* @__PURE__ */ e(
          Ir,
          {
            block: u === "candidate" && s ? s : t,
            onRevisionSubmit: r ? async (m) => {
              h.current?.abort();
              const b = new AbortController();
              h.current = b;
              let g;
              const v = t;
              if (!await p.run(async () => {
                try {
                  const y = await r(
                    v,
                    m,
                    b.signal
                  );
                  if (b.signal.aborted || f.current !== v)
                    return;
                  c(y), d("candidate");
                } catch (y) {
                  throw g = y, y;
                }
              }))
                throw l?.(g), new Error("画布修改未完成，请保留输入后重试。");
            } : void 0
          }
        ) }),
        s && /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-primary",
              onClick: () => {
                n(s), c(null), d("current");
              },
              children: "采用此版本"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              onClick: () => {
                c(null), d("current");
              },
              children: "保留当前版本"
            }
          )
        ] })
      ]
    }
  ) }) });
}
const En = (t) => Number.isFinite(t) && t >= 0;
function ip(t) {
  if (!(t.creditsPerYuan > 0 && t.creditsPerYuan <= 1e4) || !((t.costMultiplier ?? 1) > 0 && (t.costMultiplier ?? 1) <= 100))
    return "请填写有效的积分比例和成本倍率。";
  if (Object.values(t.serviceRates).some((n) => !En(n) || n > 1e4))
    return "请填写有效的资料处理价格。";
  if (Object.entries(t.modelRates || {}).some(
    ([n, r]) => !n.trim() || Object.values(r).some((i) => !En(i) || i > 1e5)
  ))
    return "请检查模型名称和价格。";
  if (new Set(t.plans.map((n) => n.id)).size !== t.plans.length || t.plans.length > 30 || t.plans.some(
    (n) => !n.name.trim() || !Number.isInteger(n.days) || n.days < 1 || n.days > 3660 || !En(n.priceYuan) || n.priceYuan <= 0 || n.priceYuan > 1e4 || !En(n.credits) || n.credits > 1e6 || !(n.discount >= 0 && n.discount <= 1)
  ))
    return "请检查会员名称、天数、价格及折扣。";
  if (t.enabled && (!/^https?:\/\//.test(t.gateway) || !t.pid.trim()))
    return "启用支付前，请填写支付网关和商户号。";
}
function _f({
  value: t,
  onSave: n,
  onSyncPrices: r,
  readOnly: i
}) {
  const { draft: a, setDraft: l, dirty: s, accept: c } = at(t), u = Pe(), [d, p] = k("credits"), [h, f] = k(""), [m, b] = k(""), g = (y, N) => l({ ...a, [y]: N }), v = (y = []) => {
    if (r) {
      if (s) {
        u.setError("请先保存当前更改，再同步价格。");
        return;
      }
      u.run(
        async () => c(await r(y)),
        "模型价格已同步。"
      );
    }
  }, w = () => {
    const y = ip(a);
    if (y) {
      u.setError(y);
      return;
    }
    u.run(
      async () => c(await n(a) || a),
      "积分与会员设置已保存。"
    );
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "积分与会员设置", children: /* @__PURE__ */ o(
    ne,
    {
      title: "积分与会员",
      description: "管理充值、会员权益和服务价格。",
      actions: /* @__PURE__ */ e(
        dt,
        {
          busy: u.busy,
          dirty: s && !i,
          onClick: w
        }
      ),
      children: [
        /* @__PURE__ */ e(
          Ge,
          {
            label: "计费设置",
            value: d,
            onChange: p,
            items: [
              { id: "credits", label: "充值与积分" },
              { id: "plans", label: "会员计划" },
              { id: "payment", label: "支付接入" },
              { id: "models", label: "模型价格" }
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { ...u }),
        /* @__PURE__ */ e("fieldset", { disabled: u.busy || i, children: /* @__PURE__ */ o(ge, { children: [
          d === "credits" && /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e(ne, { title: "积分规则", children: /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "每元兑换积分",
                  numeric: !0,
                  value: a.creditsPerYuan,
                  onChange: (y) => g("creditsPerYuan", Number(y))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "成本倍率",
                  numeric: !0,
                  value: a.costMultiplier ?? 1,
                  onChange: (y) => g("costMultiplier", Number(y))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "单次回复积分",
                  numeric: !0,
                  value: a.replyCredits ?? 0,
                  onChange: (y) => g("replyCredits", Number(y))
                }
              )
            ] }) }),
            /* @__PURE__ */ e(
              ne,
              {
                title: "资料处理价格",
                description: "按实际处理次数计费。",
                children: /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                  ["quarkOcrRequest", "扫描识别（每次）"],
                  ["documentOrganization", "资料整理（每次）"],
                  ["webSearch", "联网搜索（每次）"]
                ].map(([y, N]) => /* @__PURE__ */ e(
                  X,
                  {
                    label: N,
                    numeric: !0,
                    value: a.serviceRates[y],
                    onChange: (x) => g("serviceRates", {
                      ...a.serviceRates,
                      [y]: Number(x)
                    })
                  },
                  y
                )) })
              }
            )
          ] }),
          d === "plans" && /* @__PURE__ */ o(
            ne,
            {
              title: "会员计划",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  disabled: a.plans.length >= 30,
                  onClick: () => g("plans", [
                    ...a.plans,
                    {
                      id: crypto.randomUUID(),
                      name: "学习会员",
                      days: 30,
                      priceYuan: 10,
                      credits: 100,
                      discount: 0.9,
                      enabled: !1
                    }
                  ]),
                  children: "添加会员计划"
                }
              ),
              children: [
                a.plans.map((y, N) => /* @__PURE__ */ o(
                  ne,
                  {
                    title: y.name || "新会员计划",
                    children: [
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["name", "计划名称"],
                        ["days", "有效天数"],
                        ["priceYuan", "价格（元）"],
                        ["credits", "附赠积分"],
                        ["discount", "对话价格系数"]
                      ].map(([x, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: C,
                          numeric: x !== "name",
                          value: y[x],
                          onChange: (z) => g(
                            "plans",
                            a.plans.map(
                              (L, j) => j === N ? {
                                ...L,
                                [x]: x === "name" ? z : Number(z)
                              } : L
                            )
                          )
                        },
                        x
                      )) }),
                      /* @__PURE__ */ e(
                        Le,
                        {
                          label: `上架 ${y.name}`,
                          checked: y.enabled,
                          onChange: (x) => g(
                            "plans",
                            a.plans.map(
                              (C, z) => z === N ? { ...C, enabled: x } : C
                            )
                          )
                        }
                      ),
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-ghost",
                          onClick: () => g(
                            "plans",
                            a.plans.filter((x) => x.id !== y.id)
                          ),
                          children: "移除计划"
                        }
                      )
                    ]
                  },
                  y.id
                )),
                !a.plans.length && /* @__PURE__ */ e("p", { children: "添加会员计划，设置学习权益。" })
              ]
            }
          ),
          d === "payment" && /* @__PURE__ */ o(ne, { title: "支付接入", children: [
            /* @__PURE__ */ e(
              Le,
              {
                label: "启用充值",
                checked: a.enabled,
                onChange: (y) => g("enabled", y)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "支付网关",
                value: a.gateway,
                onChange: (y) => g("gateway", y)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户号",
                  value: a.pid,
                  onChange: (y) => g("pid", y)
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户密钥",
                  secret: !0,
                  value: a.secret,
                  hint: "留空时保留已保存的密钥。",
                  onChange: (y) => g("secret", y)
                }
              )
            ] })
          ] }),
          d === "models" && /* @__PURE__ */ o(
            ne,
            {
              title: "模型价格",
              description: "价格单位：元 / 百万 Token。",
              actions: r && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => v(),
                  children: "同步上游价格"
                }
              ),
              children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "搜索模型价格",
                    value: h,
                    onChange: f
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "新模型名称",
                      value: m,
                      onChange: b
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-secondary",
                      disabled: !m.trim(),
                      onClick: () => {
                        const y = m.trim();
                        if (a.modelRates?.[y]) {
                          u.setError("模型名称已存在。");
                          return;
                        }
                        g("modelRates", {
                          ...a.modelRates,
                          [y]: { input: 0, cachedInput: 0, output: 0 }
                        }), b("");
                      },
                      children: "添加模型"
                    }
                  )
                ] }),
                Object.entries(a.modelRates || {}).filter(
                  ([y]) => y.toLowerCase().includes(h.toLowerCase())
                ).map(([y, N]) => /* @__PURE__ */ o(
                  ne,
                  {
                    title: y,
                    description: a.rateOverrides?.includes(y) ? "使用手动价格" : "使用上游价格",
                    children: [
                      /* @__PURE__ */ e(
                        ap,
                        {
                          name: y,
                          onRename: (x) => {
                            const C = x.trim();
                            if (!C || C !== y && a.modelRates?.[C])
                              return u.setError("请填写尚未使用的模型名称。"), !1;
                            const z = { ...a.modelRates, [C]: N };
                            return C !== y && delete z[y], l({
                              ...a,
                              modelRates: z,
                              rateOverrides: a.rateOverrides?.map(
                                (L) => L === y ? C : L
                              )
                            }), !0;
                          }
                        }
                      ),
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["input", "输入价格"],
                        ["cachedInput", "缓存命中价格"],
                        ["output", "输出价格"]
                      ].map(([x, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: `${y} · ${C}`,
                          numeric: !0,
                          value: N[x],
                          onChange: (z) => l({
                            ...a,
                            modelRates: {
                              ...a.modelRates,
                              [y]: { ...N, [x]: Number(z) }
                            },
                            rateOverrides: [
                              .../* @__PURE__ */ new Set([
                                ...a.rateOverrides || [],
                                y
                              ])
                            ]
                          })
                        },
                        x
                      )) }),
                      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                        r && /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-secondary",
                            onClick: () => v([y]),
                            children: "恢复上游价格"
                          }
                        ),
                        /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-ghost",
                            onClick: () => {
                              const x = { ...a.modelRates };
                              delete x[y], l({
                                ...a,
                                modelRates: x,
                                rateOverrides: a.rateOverrides?.filter(
                                  (C) => C !== y
                                )
                              });
                            },
                            children: "移除模型"
                          }
                        )
                      ] })
                    ]
                  },
                  y
                ))
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
function ap({
  name: t,
  onRename: n
}) {
  const [r, i] = k(!1), [a, l] = k(t);
  return r ? /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: `${t} · 模型名称`,
        value: a,
        onChange: l
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: () => {
          n(a) && i(!1);
        },
        children: "确认名称"
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-ghost",
        onClick: () => {
          l(t), i(!1);
        },
        children: "取消"
      }
    )
  ] }) : /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-ghost",
      onClick: () => i(!0),
      children: "修改模型名称"
    }
  );
}
function lp(t, n) {
  const r = t.replace(/^\uFEFF/, "").replace(/\r\n/g, `
`), i = r.match(/^---\n([\s\S]*?)\n---(?:\n|$)/), a = Object.fromEntries(
    (i?.[1] || "").split(`
`).flatMap((l) => {
      const s = l.match(/^(name|description):\s*(.*?)\s*$/);
      return s ? [[s[1], s[2].replace(/^(['"])(.*)\1$/, "$2")]] : [];
    })
  );
  return {
    name: a.name || n.replace(/\.(md|markdown)$/i, ""),
    description: a.description || "",
    content: i ? r.slice(i[0].length) : r
  };
}
function Vf({
  skills: t,
  maxSkills: n = 100,
  maxFileBytes: r = 2e6,
  onSave: i,
  onExport: a
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = at(t), d = Pe(), [p, h] = k(""), [f, m] = k(null), b = l.find((w) => w.id === f), g = (w) => s(l.map((y) => y.id === f ? { ...y, ...w } : y)), v = async (w) => {
    await d.run(async () => {
      const y = [];
      if (l.length + w.length > n)
        throw new Error(`最多可保留 ${n} 个技能，请先整理后再导入。`);
      for (const N of w) {
        if (!/\.(md|markdown)$/i.test(N.name))
          throw new Error("请选择 Markdown 技能文件。");
        if (N.size > r)
          throw new Error(`${N.name} 超出文件大小限制。`);
        y.push({
          ...lp(await N.text(), N.name),
          id: crypto.randomUUID(),
          pinned: !1
        });
      }
      s([...l, ...y]), y[0] && m(y[0].id);
    }, "文件已读入，保存后即可使用。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "技能管理", children: /* @__PURE__ */ o(
    ne,
    {
      title: "技能库",
      description: `${l.length} / ${n} 个技能`,
      actions: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ o(
          "label",
          {
            className: "fp-button fp-secondary",
            role: "button",
            tabIndex: 0,
            onKeyDown: (w) => {
              !d.busy && (w.key === "Enter" || w.key === " ") && (w.preventDefault(), w.currentTarget.querySelector("input")?.click());
            },
            children: [
              "导入文件",
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "导入技能文件",
                  hidden: !0,
                  type: "file",
                  accept: ".md,.markdown,text/markdown",
                  multiple: !0,
                  disabled: d.busy,
                  onChange: (w) => {
                    const y = Array.from(w.target.files || []);
                    w.target.value = "", y.length && v(y);
                  }
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: d.busy || l.length >= n,
            onClick: () => {
              const w = {
                id: crypto.randomUUID(),
                name: "新技能",
                description: "",
                content: "",
                pinned: !1
              };
              s([...l, w]), m(w.id);
            },
            children: "新建技能"
          }
        ),
        /* @__PURE__ */ e(
          dt,
          {
            busy: d.busy,
            dirty: c,
            onClick: () => {
              if (l.some((w) => !w.name.trim())) {
                d.setError("请填写技能名称。");
                return;
              }
              d.run(async () => {
                await i(l), u(l);
              }, "技能库已保存。");
            }
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(Ee, { ...d }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ o("aside", { children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "搜索技能",
                value: p,
                onChange: h
              }
            ),
            /* @__PURE__ */ e("nav", { "aria-label": "技能列表", className: "fp-workspace-item-list", children: l.filter(
              (w) => `${w.name} ${w.description}`.toLowerCase().includes(p.toLowerCase())
            ).map((w) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                "aria-pressed": f === w.id,
                onClick: () => m(w.id),
                children: [
                  /* @__PURE__ */ e("strong", { children: w.name }),
                  /* @__PURE__ */ o("small", { children: [
                    w.pinned ? "始终使用" : "按需使用",
                    " ·",
                    " ",
                    new Blob([w.content]).size.toLocaleString(),
                    " B"
                  ] })
                ]
              },
              w.id
            )) }),
            !l.length && /* @__PURE__ */ e("p", { children: "添加技能，为学习助手补充工作方法。" })
          ] }),
          /* @__PURE__ */ e("div", { children: b ? /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "技能名称",
                value: b.name,
                onChange: (w) => g({ name: w })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能说明",
                value: b.description,
                onChange: (w) => g({ description: w })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能正文",
                multiline: !0,
                value: b.content,
                onChange: (w) => g({ content: w })
              }
            ),
            /* @__PURE__ */ e(
              Le,
              {
                label: "始终使用此技能",
                description: "关闭后，助手会按任务需要使用。",
                checked: b.pinned,
                onChange: (w) => g({ pinned: w })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
              a && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => a(b),
                  children: "导出技能"
                }
              ),
              /* @__PURE__ */ e(
                ye,
                {
                  confirm: `删除“${b.name}”？保存后生效。`,
                  onAction: () => {
                    s(l.filter((w) => w.id !== f)), m(null);
                  },
                  children: "删除技能"
                }
              )
            ] })
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个技能，查看和编辑内容。" }) })
        ] })
      ]
    }
  ) });
}
const op = () => ({
  id: "",
  label: "",
  modelType: "text",
  contextK: 128,
  cacheTtlSec: 3600,
  inputPrice: 0,
  outputPrice: 0,
  vision: !1,
  tools: !0,
  thinking: !1,
  thinkingRequired: !1,
  thinkingLevels: ["low", "medium", "high", "max"],
  apiProtocol: "openai",
  thinkingRequestStyle: "none",
  imageApiStyle: "auto",
  sizes: ["1024x1024"],
  maxCount: 1
});
function ta(t) {
  if (!t || typeof t != "object") return !1;
  const n = t, r = (a) => Array.isArray(a) && a.length <= 1e3 && a.every((l) => typeof l == "string" && l.length <= 2e3), i = (a, l = !1) => l && a === void 0 || typeof a == "number" && Number.isFinite(a) && a >= 0 && a <= 1e5;
  return Array.isArray(n.groups) && n.groups.length <= 100 && new Set(n.groups.map((a) => a?.id)).size === n.groups.length && n.groups.every(
    (a) => a && typeof a == "object" && typeof a.id == "string" && a.id.length <= 128 && typeof a.name == "string" && typeof a.baseUrl == "string" && typeof a.apiKey == "string" && Array.isArray(a.models) && a.models.length <= 1e3 && a.models.every(
      (l) => l && typeof l == "object" && typeof l.id == "string" && typeof l.label == "string" && ["text", "image"].includes(l.modelType) && Number.isFinite(l.contextK) && l.contextK > 0 && l.contextK <= 1e5 && Number.isFinite(l.cacheTtlSec) && l.cacheTtlSec >= 0 && i(l.inputPrice) && i(l.outputPrice) && i(l.cachedInputPrice, !0) && i(l.cacheWritePrice, !0) && ["vision", "tools", "thinking", "thinkingRequired"].every(
        (s) => typeof l[s] == "boolean"
      ) && r(l.thinkingLevels) && r(l.sizes) && typeof l.thinkingRequestStyle == "string" && ["openai", "anthropic", "siliconflow"].includes(l.apiProtocol) && ["auto", "openai", "siliconflow"].includes(l.imageApiStyle) && Number.isInteger(l.maxCount) && l.maxCount > 0 && l.maxCount <= 100
    )
  ) && [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel",
    "thinkingEffort",
    "globalContext"
  ].every((a) => typeof n[a] == "string") && ["defaultThinking", "defaultSearch", "imageEnabled"].every(
    (a) => typeof n[a] == "boolean"
  ) && r(n.disabledTools) && (n.fontSize === void 0 || Number.isFinite(n.fontSize) && n.fontSize >= 10 && n.fontSize <= 32) && (n.fontFamily === void 0 || typeof n.fontFamily == "string");
}
function wr(t, n) {
  const r = { ...t };
  for (const i of [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel"
  ])
    Object.hasOwn(n, r[i]) && (r[i] = n[r[i]]);
  return r;
}
function Gf({
  value: t,
  builtInModels: n = [],
  tools: r = [],
  onSave: i,
  onExportChats: a,
  onExportSettings: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = at(t), p = Pe(), [h, f] = k("models"), [m, b] = k(s.groups[0]?.id || ""), [g, v] = k(null), w = s.groups.find((M) => M.id === m), y = g === null ? void 0 : w?.models[g], N = (M, A) => c({ ...s, [M]: A }), x = (M) => {
    const A = {};
    if (M.models && w)
      for (const O of w.models)
        M.models.some((U) => U.id === O.id) || (A[`${m}:${O.id}`] = "");
    c(
      wr(
        {
          ...s,
          groups: s.groups.map(
            (O) => O.id === m ? { ...O, ...M } : O
          )
        },
        A
      )
    );
  }, C = (M) => {
    if (!w || !y) return;
    const A = M.id !== void 0 && M.id !== y.id ? {
      [`${m}:${y.id}`]: M.id ? `${m}:${M.id}` : ""
    } : {};
    c(
      wr(
        {
          ...s,
          groups: s.groups.map(
            (O) => O.id === m ? {
              ...O,
              models: O.models.map(
                (U, T) => T === g ? { ...U, ...M } : U
              )
            } : O
          )
        },
        A
      )
    );
  }, z = [
    ...n,
    ...s.groups.flatMap(
      (M) => M.models.filter((A) => A.id).map((A) => ({
        id: `${M.id}:${A.id}`,
        label: `${M.name} · ${A.label || A.id}`
      }))
    )
  ], L = [
    { value: "", label: "跟随主对话" },
    ...z.map((M) => ({ value: M.id, label: M.label }))
  ], j = () => {
    if (!ta(s) || s.groups.some(
      (M) => !M.name.trim() || !/^https?:\/\//.test(M.baseUrl) || M.models.some((A) => !A.id.trim()) || new Set(M.models.map((A) => A.id)).size !== M.models.length
    )) {
      p.setError("请检查分组地址、模型名称和数值设置。");
      return;
    }
    p.run(async () => {
      await i(s), d(s);
    }, "助手设置已保存。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "助手完整设置", children: /* @__PURE__ */ o(
    ne,
    {
      title: "学习助手设置",
      description: "管理模型、学习偏好和技能使用方式。",
      actions: /* @__PURE__ */ e(dt, { busy: p.busy, dirty: u, onClick: j }),
      children: [
        /* @__PURE__ */ e(
          Ge,
          {
            label: "助手设置分区",
            value: h,
            onChange: f,
            items: [
              { id: "models", label: "模型与连接" },
              { id: "defaults", label: "学习偏好" },
              { id: "images", label: "图片创作" },
              { id: "tools", label: "工具" },
              { id: "data", label: "导入与导出" }
            ]
          }
        ),
        /* @__PURE__ */ e(Ee, { ...p }),
        /* @__PURE__ */ e("fieldset", { disabled: p.busy, children: /* @__PURE__ */ o(ge, { children: [
          h === "models" && /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ o(ne, { title: "对话模型", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "默认对话模型",
                  value: s.defaultModel,
                  options: [
                    { value: "", label: "自动选择" },
                    ...L.slice(1)
                  ],
                  onChange: (M) => N("defaultModel", M)
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "摘录模型",
                    value: s.excerptModel,
                    options: L,
                    onChange: (M) => N("excerptModel", M)
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "划词助手模型",
                    value: s.selectionModel,
                    options: L,
                    onChange: (M) => N("selectionModel", M)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o(
              ne,
              {
                title: "自定义连接",
                actions: /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      const M = {
                        id: crypto.randomUUID(),
                        name: "新连接",
                        baseUrl: "",
                        apiKey: "",
                        models: []
                      };
                      N("groups", [...s.groups, M]), b(M.id), v(null);
                    },
                    children: "添加连接"
                  }
                ),
                children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "当前连接",
                      value: m,
                      options: s.groups.map((M) => ({
                        value: M.id,
                        label: M.name
                      })),
                      onChange: (M) => {
                        b(M), v(null);
                      }
                    }
                  ),
                  w && /* @__PURE__ */ o(ee, { children: [
                    /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "连接名称",
                          value: w.name,
                          onChange: (M) => x({ name: M })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "服务地址",
                          value: w.baseUrl,
                          onChange: (M) => x({ baseUrl: M })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "API 密钥",
                          secret: !0,
                          value: w.apiKey,
                          onChange: (M) => x({ apiKey: M })
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: w.models.map((M, A) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": A === g,
                        onClick: () => v(A),
                        children: [
                          /* @__PURE__ */ e("strong", { children: M.label || M.id || "新模型" }),
                          /* @__PURE__ */ o("small", { children: [
                            M.modelType === "image" ? "图片模型" : "文本模型",
                            " ",
                            "· ",
                            M.contextK,
                            " K"
                          ] })
                        ]
                      },
                      A
                    )) }),
                    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-secondary",
                          onClick: () => {
                            v(w.models.length), x({
                              models: [
                                ...w.models,
                                op()
                              ]
                            });
                          },
                          children: "添加模型"
                        }
                      ),
                      /* @__PURE__ */ e(
                        ye,
                        {
                          confirm: `删除“${w.name}”及其模型？保存后生效。`,
                          onAction: () => {
                            c(
                              wr(
                                {
                                  ...s,
                                  groups: s.groups.filter(
                                    (M) => M.id !== m
                                  )
                                },
                                Object.fromEntries(
                                  w.models.map((M) => [
                                    `${m}:${M.id}`,
                                    ""
                                  ])
                                )
                              )
                            ), b(""), v(null);
                          },
                          children: "删除连接"
                        }
                      )
                    ] })
                  ] })
                ]
              }
            ),
            y && /* @__PURE__ */ o(ne, { title: y.label || "编辑模型", children: [
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型名称",
                    value: y.id,
                    onChange: (M) => C({ id: M })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "显示名称",
                    value: y.label,
                    onChange: (M) => C({ label: M })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型类型",
                    value: y.modelType,
                    options: [
                      { value: "text", label: "文本" },
                      { value: "image", label: "图片" }
                    ],
                    onChange: (M) => C({
                      modelType: M
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "上下文长度（K）",
                    value: y.contextK,
                    numeric: !0,
                    onChange: (M) => C({ contextK: Number(M) })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "缓存有效期（秒）",
                    value: y.cacheTtlSec,
                    numeric: !0,
                    onChange: (M) => C({ cacheTtlSec: Number(M) })
                  }
                ),
                [
                  "inputPrice",
                  "cachedInputPrice",
                  "cacheWritePrice",
                  "outputPrice"
                ].map((M, A) => /* @__PURE__ */ e(
                  X,
                  {
                    label: [
                      "输入价格",
                      "缓存读取价格",
                      "缓存写入价格",
                      "输出价格"
                    ][A],
                    value: y[M] ?? 0,
                    numeric: !0,
                    onChange: (O) => C({ [M]: Number(O) })
                  },
                  M
                )),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "服务协议",
                    value: y.apiProtocol,
                    options: ["openai", "anthropic", "siliconflow"].map(
                      (M) => ({ value: M, label: M })
                    ),
                    onChange: (M) => C({
                      apiProtocol: M
                    })
                  }
                )
              ] }),
              [
                "vision",
                "tools",
                "thinking",
                "thinkingRequired"
              ].map((M, A) => /* @__PURE__ */ e(
                Le,
                {
                  label: ["理解图片", "使用工具", "支持思考", "始终启用思考"][A],
                  checked: y[M],
                  onChange: (O) => C({ [M]: O })
                },
                M
              )),
              /* @__PURE__ */ e(
                X,
                {
                  label: "可用思考力度",
                  value: y.thinkingLevels.join(", "),
                  hint: "以逗号分隔。",
                  onChange: (M) => C({
                    thinkingLevels: M.split(",").map((A) => A.trim()).filter(Boolean)
                  })
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "思考参数格式",
                    value: y.thinkingRequestStyle,
                    options: [
                      "none",
                      "siliconflow",
                      "mimo-thinking",
                      "openai-reasoning-effort",
                      "openrouter-reasoning",
                      "anthropic-thinking"
                    ].map((M) => ({
                      value: M,
                      label: M === "none" ? "自动使用默认格式" : M
                    })),
                    onChange: (M) => C({ thinkingRequestStyle: M })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "推理内容字段",
                    value: y.reasoningField || "",
                    onChange: (M) => C({ reasoningField: M })
                  }
                )
              ] }),
              y.modelType === "image" && /* @__PURE__ */ o(ee, { children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片接口",
                    value: y.imageApiStyle,
                    options: ["auto", "openai", "siliconflow"].map(
                      (M) => ({
                        value: M,
                        label: M === "auto" ? "自动识别" : M
                      })
                    ),
                    onChange: (M) => C({
                      imageApiStyle: M
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片尺寸",
                    value: y.sizes.join(", "),
                    hint: "例如 1024x1024，以逗号分隔。",
                    onChange: (M) => C({
                      sizes: M.split(",").map((A) => A.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "最多生成张数",
                    numeric: !0,
                    value: y.maxCount,
                    onChange: (M) => C({ maxCount: Number(M) })
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                ye,
                {
                  confirm: "移除此模型？保存后生效。",
                  onAction: () => {
                    x({
                      models: w.models.filter(
                        (M, A) => A !== g
                      )
                    }), v(null);
                  },
                  children: "移除模型"
                }
              )
            ] })
          ] }),
          h === "defaults" && /* @__PURE__ */ o(ne, { title: "新对话偏好", children: [
            /* @__PURE__ */ e(
              Le,
              {
                label: "深度思考",
                checked: s.defaultThinking,
                onChange: (M) => N("defaultThinking", M)
              }
            ),
            /* @__PURE__ */ e(
              Le,
              {
                label: "联网搜索",
                checked: s.defaultSearch,
                onChange: (M) => N("defaultSearch", M)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "默认思考力度",
                value: s.thinkingEffort,
                options: ["low", "medium", "high", "max"].map((M, A) => ({
                  value: M,
                  label: ["轻度", "适中", "深入", "充分"][A]
                })),
                onChange: (M) => N("thinkingEffort", M)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "补充学习背景",
                multiline: !0,
                value: s.globalContext,
                hint: "介绍你的课程、称呼和回答偏好。",
                onChange: (M) => N("globalContext", M)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字号",
                  numeric: !0,
                  value: s.fontSize || 15,
                  onChange: (M) => N("fontSize", Number(M))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字体",
                  value: s.fontFamily || "inherit",
                  options: [
                    { value: "inherit", label: "跟随全局" },
                    { value: "sans-serif", label: "清晰黑体" },
                    { value: "serif", label: "阅读衬线" },
                    { value: "monospace", label: "等宽" }
                  ],
                  onChange: (M) => N("fontFamily", M)
                }
              )
            ] })
          ] }),
          h === "images" && /* @__PURE__ */ o(ne, { title: "图片创作", children: [
            /* @__PURE__ */ e(
              Le,
              {
                label: "开启图片创作",
                checked: s.imageEnabled,
                onChange: (M) => N("imageEnabled", M)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "图片创作理解模型",
                value: s.imageTextModel,
                options: L,
                onChange: (M) => N("imageTextModel", M)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "备用模型",
                value: s.fallbackModel,
                options: L,
                onChange: (M) => N("fallbackModel", M)
              }
            )
          ] }),
          h === "tools" && /* @__PURE__ */ o(ne, { title: "可用工具", children: [
            r.map((M) => /* @__PURE__ */ e(
              Le,
              {
                label: M.label,
                description: M.description,
                checked: !s.disabledTools.includes(M.id),
                onChange: (A) => N(
                  "disabledTools",
                  A ? s.disabledTools.filter((O) => O !== M.id) : [...s.disabledTools, M.id]
                )
              },
              M.id
            )),
            !r.length && /* @__PURE__ */ e("p", { children: "当前没有可配置的工具。" })
          ] }),
          h === "data" && /* @__PURE__ */ o(
            ne,
            {
              title: "导入与导出",
              description: "配置文件可能包含连接密钥，请妥善保管。",
              children: [
                /* @__PURE__ */ o(
                  "label",
                  {
                    className: "fp-workspace-upload",
                    role: "button",
                    tabIndex: 0,
                    onKeyDown: (M) => {
                      (M.key === "Enter" || M.key === " ") && (M.preventDefault(), M.currentTarget.querySelector("input")?.click());
                    },
                    children: [
                      "导入助手设置",
                      /* @__PURE__ */ e(
                        "input",
                        {
                          type: "file",
                          hidden: !0,
                          "aria-label": "导入助手设置",
                          accept: ".json,application/json",
                          onChange: (M) => {
                            const A = M.target.files?.[0];
                            M.target.value = "", A && p.run(async () => {
                              if (A.size > 2e6)
                                throw new Error("设置文件不能超过 2 MB。");
                              let O;
                              try {
                                O = JSON.parse(await A.text());
                              } catch {
                                throw new Error(
                                  "无法读取设置文件，请选择有效的 JSON 文件。"
                                );
                              }
                              if (!ta(O))
                                throw new Error("文件内容与助手设置不匹配。");
                              c(O), b(O.groups[0]?.id || ""), v(null);
                            }, "设置已读入，请检查后保存。");
                          }
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                  l && /* @__PURE__ */ e(ye, { onAction: () => l(s), children: "导出助手设置" }),
                  a && /* @__PURE__ */ e(ye, { onAction: a, children: "导出对话记录" })
                ] })
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
const sp = "#FD8B07", cp = {
  brand: { name: "五加一", primary: sp, onPrimary: "#542D0C", action: "#B85E00", onAction: "#FFFFFF", darkAction: "#FFB65C", darkOnAction: "#492600", soft: "#FFF2E2", ink: "#914600", darkSoft: "#422D18", darkInk: "#FFC98F" },
  kezhan: { name: "课栈笔记", primary: "#1A73E8", onPrimary: "#FFFFFF", soft: "#E8F0FE", ink: "#185ABC", darkPrimary: "#A8C7FA", darkSoft: "#263751", darkInk: "#C2D7FA", darkOnPrimary: "#142D50" },
  marker: { name: "AI 批改助手", primary: "#13795B", onPrimary: "#FFFFFF", soft: "#E6F4ED", ink: "#0C6248", darkPrimary: "#8DD8B6", darkSoft: "#193C30", darkInk: "#B1E8CE", darkOnPrimary: "#103C2B" },
  onepass: { name: "OnePass", primary: "#7252C7", onPrimary: "#FFFFFF", soft: "#F0EAFC", ink: "#5D3DA8", darkPrimary: "#CDB8FF", darkSoft: "#35294B", darkInk: "#DFD0FF", darkOnPrimary: "#342052" },
  hydronexus: { name: "灵枢智闸", primary: "#216B81", onPrimary: "#FFFFFF", soft: "#E7F1F4", ink: "#18556A", darkPrimary: "#80C5D8", darkSoft: "#193A45", darkInk: "#A4DBE7", darkOnPrimary: "#113541" }
}, ln = (t) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
function na(t) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const n = /* @__PURE__ */ new Date(t + "T12:00:00");
  return Number.isFinite(n.getTime()) && ln(n) === t ? n : null;
}
function Tl(t) {
  const [n, r] = k(String(t.defaultValue ?? "")), i = R(null), a = String(t.value ?? n), l = (c) => {
    if (r(c), i.current) {
      i.current.value = c;
      const u = new Event("change", { bubbles: !0 });
      t.onChange?.({ target: i.current, currentTarget: i.current, nativeEvent: u, type: "change", bubbles: !0, cancelable: !1, defaultPrevented: !1, eventPhase: 3, isTrusted: !1, timeStamp: u.timeStamp, preventDefault: () => u.preventDefault(), stopPropagation: () => u.stopPropagation(), isDefaultPrevented: () => u.defaultPrevented, isPropagationStopped: () => !1, persist: () => {
      } });
    }
  }, s = (c) => {
    i.current = c, typeof t.ref == "function" ? t.ref(c) : t.ref && (t.ref.current = c);
  };
  return Y(() => {
    const c = i.current?.form, u = () => r(String(t.defaultValue ?? ""));
    return c?.addEventListener("reset", u), () => c?.removeEventListener("reset", u);
  }, [t.defaultValue]), { input: i, bind: s, value: a, change: l };
}
function ra({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: i, bind: a, value: l, change: s } = Tl(r), c = na(l) || /* @__PURE__ */ new Date(), [u, d] = k(new Date(c.getFullYear(), c.getMonth(), 1)), p = u.getFullYear(), h = u.getMonth(), f = r.disabled || r.readOnly, m = (b) => (!r.min || b >= String(r.min)) && (!r.max || b <= String(r.max));
  return Y(() => {
    i.current?.setCustomValidity(l && (!na(l) || !m(l)) ? "请填写有效范围内的日期" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: a, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "YYYY-MM-DD", onChange: (b) => s(b.target.value) }),
    /* @__PURE__ */ e(Xe, { label: "选择日期", disabled: f, trigger: /* @__PURE__ */ e(va, { size: 17 }), className: "fp-date-popup", onOpenChange: (b) => {
      b && d(new Date(c.getFullYear(), c.getMonth(), 1));
    }, children: (b) => /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上个月", onClick: () => d(new Date(p, h - 1, 1)), children: /* @__PURE__ */ e(Wr, { size: 17 }) }),
        /* @__PURE__ */ o("strong", { children: [
          p,
          " 年 ",
          h + 1,
          " 月"
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下个月", onClick: () => d(new Date(p, h + 1, 1)), children: /* @__PURE__ */ e(Ae, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-calendar-grid", role: "group", "aria-label": "日期", children: [
        "日一二三四五六".split("").map((g) => /* @__PURE__ */ e("span", { children: g }, g)),
        Array.from({ length: new Date(p, h, 1).getDay() }, (g, v) => /* @__PURE__ */ e("span", {}, "blank" + v)),
        Array.from({ length: new Date(p, h + 1, 0).getDate() }, (g, v) => {
          const w = ln(new Date(p, h, v + 1));
          return /* @__PURE__ */ e("button", { type: "button", "data-date": w, "aria-label": w, "aria-pressed": l === w, disabled: !m(w), onClick: () => {
            s(w), b();
          }, onKeyDown: (y) => {
            const N = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[y.key];
            if (!N) return;
            y.preventDefault();
            const x = new Date(p, h, v + 1 + N), C = ln(x), z = y.currentTarget.closest(".fp-calendar");
            d(new Date(x.getFullYear(), x.getMonth(), 1)), requestAnimationFrame(() => z?.querySelector(`[data-date="${C}"]`)?.focus());
          }, children: v + 1 }, w);
        })
      ] }),
      /* @__PURE__ */ o("footer", { children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: r.required, onClick: () => {
          s(""), b();
        }, children: "清除" }),
        /* @__PURE__ */ e("button", { type: "button", disabled: !m(ln(/* @__PURE__ */ new Date())), onClick: () => {
          s(ln(/* @__PURE__ */ new Date())), b();
        }, children: "今天" })
      ] })
    ] }) })
  ] });
}
function Yf({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: i, bind: a, value: l, change: s } = Tl(r), [c, u] = l.split(":");
  return Y(() => {
    i.current?.setCustomValidity(l && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(l) || r.min && l < String(r.min) || r.max && l > String(r.max)) ? "请填写有效范围内的时间" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: a, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "HH:mm", onChange: (d) => s(d.target.value) }),
    /* @__PURE__ */ e(Xe, { label: "选择时间", disabled: r.disabled || r.readOnly, trigger: /* @__PURE__ */ e(Xn, { size: 17 }), className: "fp-time-popup", children: (d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-time-columns", children: [["小时", 24, c], ["分钟", 60, u]].map(([p, h, f], m) => /* @__PURE__ */ e("div", { role: "group", "aria-label": String(p), children: Array.from({ length: Number(h) }, (b, g) => {
        const v = String(g).padStart(2, "0"), w = m === 0 ? `${v}:${u || "00"}` : `${c || "00"}:${v}`, y = m === 0 ? r.min && w < String(r.min) ? String(r.min) : r.max && w > String(r.max) ? String(r.max) : w : w, N = m === 0 ? (!r.min || `${v}:59` >= String(r.min)) && (!r.max || `${v}:00` <= String(r.max)) : (!r.min || y >= String(r.min)) && (!r.max || y <= String(r.max));
        return /* @__PURE__ */ e("button", { type: "button", "aria-pressed": f === v, disabled: !N, onClick: () => s(y), children: v }, v);
      }) }, p)) }),
      /* @__PURE__ */ e("footer", { children: /* @__PURE__ */ e("button", { type: "button", onClick: d, children: "完成" }) })
    ] }) })
  ] });
}
function Pl({ label: t, value: n, onChange: r, disabled: i = !1 }) {
  const [a, l] = k(n), s = ["#FD8B07", "#B85E00", "#1A73E8", "#13795B", "#7252C7", "#D44A61", "#202124", "#FFFFFF"];
  Y(() => l(n), [n]);
  const c = /^#[0-9a-f]{6}$/i.test(n) ? n : "#FD8B07", u = (p) => parseInt(c.slice(p * 2 + 1, p * 2 + 3), 16), d = ve();
  return /* @__PURE__ */ o("div", { className: "fp-color-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e(Xe, { disabled: i, label: t, trigger: /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e("i", { className: "fp-color-swatch", style: { background: c } }),
      /* @__PURE__ */ e("code", { children: n })
    ] }), className: "fp-color-popup", children: () => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-color-swatches", children: s.map((p) => /* @__PURE__ */ e("button", { type: "button", "aria-label": p, "aria-pressed": n.toLowerCase() === p.toLowerCase(), style: { background: p }, onClick: () => {
        l(p), r(p);
      } }, p)) }),
      ["红", "绿", "蓝"].map((p, h) => /* @__PURE__ */ o("label", { className: "fp-color-channel", children: [
        p,
        /* @__PURE__ */ e("input", { type: "range", "aria-label": p, min: 0, max: 255, value: u(h), onChange: (f) => {
          const m = [u(0), u(1), u(2)];
          m[h] = Number(f.target.value);
          const b = "#" + m.map((g) => g.toString(16).padStart(2, "0")).join("");
          l(b), r(b);
        } }),
        /* @__PURE__ */ e("output", { children: u(h) })
      ] }, p)),
      /* @__PURE__ */ e("label", { htmlFor: d, children: "HEX" }),
      /* @__PURE__ */ e("input", { id: d, className: "fp-input", "aria-label": "十六进制颜色", value: a, onFocus: () => l(n), onChange: (p) => {
        l(p.target.value), /^#[0-9a-f]{6}$/i.test(p.target.value) && r(p.target.value);
      } })
    ] }) })
  ] });
}
const hi = {
  system: "system-ui, sans-serif",
  songti: '"Noto Serif SC", SimSun, serif',
  kaiti: "KaiTi, STKaiti, serif",
  hei: '"Microsoft YaHei", sans-serif',
  serif: "Georgia, serif",
  mono: "Consolas, monospace"
}, ia = [
  { value: "system", label: "系统默认" },
  { value: "songti", label: "宋体阅读" },
  { value: "kaiti", label: "楷体手写" },
  { value: "hei", label: "黑体清晰" },
  { value: "serif", label: "英文衬线" },
  { value: "mono", label: "等宽" }
].map((t) => ({ ...t, fontFamily: hi[t.value] }));
function dp(t, n = !1, r = "brand") {
  const i = t.theme === "dark" || t.theme === "system" && n, a = i ? "#1d1f22" : "#ffffff", l = {
    colorScheme: i ? "dark" : "light",
    fontFamily: hi[t.font] || t.font,
    "--fp-bg": i ? "#141517" : "#fbfaf8",
    "--fp-surface": a,
    "--fp-surface-muted": i ? "#26282c" : "#f4f2ef",
    "--fp-surface-sunken": i ? "#101113" : "#eeebe7",
    "--fp-ink": i ? "#e8eaed" : "#202124",
    "--fp-muted": i ? "#a9adb4" : "#6b7075",
    "--fp-faint": i ? "#7c828a" : "#9aa0a6",
    "--fp-line": i ? "#34373c" : "#e6e3df",
    "--fp-line-strong": i ? "#464a50" : "#d3cfca"
  }, s = cp[r];
  Object.assign(l, {
    "--fp-primary": i && s.darkPrimary || s.primary,
    "--fp-on-primary": i && s.darkOnPrimary || s.onPrimary,
    "--fp-primary-soft": i ? s.darkSoft : s.soft,
    "--fp-primary-ink": i ? s.darkInk : s.ink,
    "--fp-action": i ? s.darkAction || s.darkPrimary || s.primary : s.action || s.primary,
    "--fp-on-action": i ? s.darkOnAction || s.darkOnPrimary || s.onPrimary : s.onAction || s.onPrimary
  });
  const c = i ? t.darkAccent : t.lightAccent;
  if (t.mode === "custom" && /^#[\da-f]{6}$/i.test(c)) {
    const u = [1, 3, 5].map((f) => parseInt(c.slice(f, f + 2), 16)), d = (f, m) => "#" + u.map(
      (b) => Math.round(b + (m - b) * f).toString(16).padStart(2, "0")
    ).join(""), p = (f) => {
      const m = [1, 3, 5].map((b) => parseInt(f.slice(b, b + 2), 16) / 255).map((b) => b <= 0.04045 ? b / 12.92 : ((b + 0.055) / 1.055) ** 2.4);
      return m[0] * 0.2126 + m[1] * 0.7152 + m[2] * 0.0722;
    };
    let h = c;
    for (let f = 0; f <= 0.9; f += 0.05) {
      h = d(f, i ? 255 : 0);
      const m = p(h);
      if (i ? (m + 0.05) / 0.05 >= 7 : 1.05 / (m + 0.05) >= 4.5) break;
    }
    Object.assign(l, {
      "--fp-primary": c,
      "--fp-on-primary": p(c) > 0.179 ? "#202124" : "#ffffff",
      "--fp-primary-soft": `color-mix(in srgb, ${c} 14%, ${a})`,
      "--fp-primary-ink": i ? d(0.5, 255) : d(0.35, 0),
      "--fp-action": h,
      "--fp-on-action": i ? "#101113" : "#ffffff"
    });
  }
  return /^#[\da-f]{6}$/i.test(t.selection) && (l["--fp-selection"] = t.selection), l["--fp-heading-color"] = t.mode === "colorful" ? l["--fp-primary-ink"] : l["--fp-ink"], l;
}
function up(t, n) {
  const r = t.regions[n];
  return {
    fontFamily: hi[!r || r.inherit ? t.font : r.font] || (!r || r.inherit ? t.font : r.font),
    fontSize: r && !r.inherit ? r.fontSize : void 0,
    lineHeight: r && !r.inherit ? r.lineHeight : void 0
  };
}
function Xf({
  value: t,
  onChange: n,
  onReset: r,
  product: i = "brand",
  heading: a = !0,
  regions: l = [
    { id: "reading", label: "笔记阅读" },
    { id: "editor", label: "笔记编辑" },
    { id: "chat", label: "助手对话" }
  ]
}) {
  const [s, c] = k(
    () => typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches
  );
  Y(() => {
    if (typeof matchMedia > "u") return;
    const d = matchMedia("(prefers-color-scheme: dark)"), p = () => c(d.matches);
    return d.addEventListener("change", p), () => d.removeEventListener("change", p);
  }, []);
  const u = (d) => n({ ...t, ...d });
  return /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form fp-appearance-workspace",
      "data-mode": t.mode,
      style: dp(t, s, i),
      "aria-label": "外观设置",
      children: /* @__PURE__ */ o(
        ne,
        {
          title: a ? "外观" : void 0,
          description: a ? "让阅读、写作和对话保持适合自己的节奏。" : void 0,
          children: [
            /* @__PURE__ */ e(
              Ge,
              {
                label: "明暗主题",
                value: t.theme,
                onChange: (d) => u({ theme: d }),
                items: [
                  { id: "light", label: "浅色" },
                  { id: "dark", label: "深色" },
                  { id: "system", label: "跟随系统" }
                ]
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "配色方式",
                value: t.mode,
                options: [
                  { value: "default", label: "产品默认" },
                  { value: "colorful", label: "内容彩色" },
                  { value: "custom", label: "自定义" }
                ],
                onChange: (d) => u({ mode: d })
              }
            ),
            /* @__PURE__ */ e(ge, { children: t.mode === "custom" && /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: ["lightAccent", "darkAccent", "selection"].map(
              (d, p) => /* @__PURE__ */ e(
                Pl,
                {
                  label: ["白天主色", "夜间主色", "划词颜色"][p],
                  value: t[d],
                  onChange: (h) => u({ [d]: h, mode: "custom" })
                },
                d
              )
            ) }) }),
            /* @__PURE__ */ e(
              X,
              {
                label: "全局字体",
                value: t.font,
                options: ia,
                onChange: (d) => u({ font: d })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "界面字号 · ",
                  t.uiFontSize ?? 14,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "界面字号", type: "range", min: "12", max: "20", step: "1", value: t.uiFontSize ?? 14, onChange: (d) => u({ uiFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整导航、按钮和设置中的文字大小。" })
              ] }),
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "正文字号 · ",
                  t.readingFontSize ?? 16,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "正文字号", type: "range", min: "14", max: "28", step: "1", value: t.readingFontSize ?? 16, onChange: (d) => u({ readingFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整笔记、编辑器和 AI 对话中的正文大小。" })
              ] })
            ] }),
            /* @__PURE__ */ e("p", { className: "fp-workspace-type-preview", style: { fontSize: `${t.readingFontSize ?? 16}px` }, children: "从阅读到理解，把想法变成自己的笔记。" }),
            l.map((d) => {
              const p = t.regions[d.id] || {
                font: t.font,
                fontSize: 16,
                lineHeight: 1.9,
                inherit: !0
              }, h = (f) => u({
                regions: {
                  ...t.regions,
                  [d.id]: { ...p, ...f }
                }
              });
              return /* @__PURE__ */ o(ne, { title: d.label, children: [
                /* @__PURE__ */ e(
                  Le,
                  {
                    label: `${d.label}跟随全局字体`,
                    checked: p.inherit,
                    onChange: (f) => h({ inherit: f })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字体`,
                      value: p.font,
                      options: ia,
                      disabled: p.inherit,
                      onChange: (f) => h({ font: f })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字号`,
                      value: p.fontSize,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        Number.isFinite(m) && m >= 10 && m <= 32 && h({ fontSize: m });
                      }
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}行高`,
                      value: p.lineHeight,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        m >= 1.2 && m <= 2.5 && h({ lineHeight: m });
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  "p",
                  {
                    className: "fp-workspace-type-preview",
                    style: up(t, d.id),
                    children: "从阅读到理解，把想法变成自己的笔记。"
                  }
                )
              ] }, d.id);
            }),
            /* @__PURE__ */ e(ye, { confirm: "恢复产品默认外观？", onAction: r, children: "恢复默认外观" })
          ]
        }
      )
    }
  );
}
function Qf({
  records: t,
  onOpen: n,
  onClear: r,
  shortcuts: i,
  appearance: a
}) {
  const l = [...new Set(t.map((u) => u.subject))], s = t.reduce((u, d) => u + d.attempts, 0), c = t.length ? Math.round(t.reduce((u, d) => u + d.best, 0) / t.length) : 0;
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form", "aria-label": "学习设置", children: [
    /* @__PURE__ */ o(
      ne,
      {
        title: "学习记录",
        description: `${t.length} 个章节 · 平均最佳分 ${c} · ${s} 次测验`,
        children: [
          l.map((u) => /* @__PURE__ */ e(ne, { title: u, children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: t.filter((d) => d.subject === u).map((d) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(d.id), children: [
            /* @__PURE__ */ e("strong", { children: d.chapter }),
            /* @__PURE__ */ o("small", { children: [
              "上次 ",
              d.last,
              " 分 · 最佳 ",
              d.best,
              " 分 · ",
              d.attempts,
              " 次"
            ] })
          ] }, d.id)) }) }, u)),
          !t.length && /* @__PURE__ */ e("p", { children: "完成章节测验后，可以在这里查看学习记录。" }),
          /* @__PURE__ */ e(
            ye,
            {
              disabled: !t.length,
              confirm: "清空全部测验成绩？题目和笔记会保留。",
              onAction: r,
              children: "清空测验成绩"
            }
          )
        ]
      }
    ),
    i && /* @__PURE__ */ e(ne, { title: "快捷键", children: i }),
    a
  ] });
}
function pp(t, n, r, i) {
  if (t.reduce((s, c) => s + c, 0) + Math.max(0, t.length - 1) * i <= n) return t.length;
  let a = r, l = 0;
  for (const s of t) {
    if (a + i + s > n) break;
    a += i + s, l++;
  }
  return l;
}
function or({ actions: t, label: n = "操作", moreLabel: r = "更多操作", className: i = "", showLabels: a = !1 }) {
  const l = R(null), s = R(null), [c, u] = k(0), d = t.map((h) => h.id).join("\0");
  xe(() => {
    const h = l.current, f = s.current;
    if (!h || !f) return;
    const m = () => {
      const g = getComputedStyle(h), v = parseFloat(g.columnGap) || 4, y = Array.from(f.querySelectorAll("[data-action-width]")).map((x) => x.getBoundingClientRect().width || 32), N = f.querySelector("[data-more-width]")?.getBoundingClientRect().width || 32;
      u(pp(y, h.clientWidth - (parseFloat(g.paddingLeft) || 0) - (parseFloat(g.paddingRight) || 0), N, v));
    };
    m();
    const b = typeof ResizeObserver > "u" ? null : new ResizeObserver(m);
    return b?.observe(h), b?.observe(f), document.fonts?.ready.then(m), () => b?.disconnect();
  }, [d, a]);
  const p = (h, f = !1) => /* @__PURE__ */ o("button", { type: "button", "data-action-width": f ? "" : void 0, "data-fp-tooltip": h.label, "aria-label": h.label, disabled: h.disabled, "data-danger": h.danger || void 0, onClick: f ? void 0 : h.onSelect, children: [
    h.icon,
    a && /* @__PURE__ */ e("span", { children: h.label })
  ] }, h.id);
  return /* @__PURE__ */ o("div", { ref: l, className: `fp-action-toolbar ${i}`, "data-show-labels": a || void 0, role: "toolbar", "aria-label": n, onKeyDown: (h) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(h.key)) return;
    const f = Array.from(l.current?.querySelectorAll(":scope > button:not(:disabled), :scope > .fp-dropdown > button:not(:disabled)") || []), m = f.indexOf(document.activeElement);
    m < 0 || (h.preventDefault(), f[h.key === "Home" ? 0 : h.key === "End" ? f.length - 1 : (m + (h.key === "ArrowRight" ? 1 : -1) + f.length) % f.length]?.focus());
  }, children: [
    t.slice(0, c).map((h) => p(h)),
    c < t.length && /* @__PURE__ */ e(Xe, { label: r, icon: /* @__PURE__ */ e(Kt, { size: 18 }), menu: !0, density: "compact", children: (h) => /* @__PURE__ */ e("div", { className: "fp-action-menu", children: t.slice(c).map((f) => /* @__PURE__ */ o("button", { role: "menuitem", type: "button", disabled: f.disabled, "data-danger": f.danger || void 0, onClick: () => {
      h(), f.onSelect();
    }, children: [
      f.icon,
      /* @__PURE__ */ e("span", { children: f.label })
    ] }, f.id)) }) }),
    /* @__PURE__ */ o("div", { ref: s, className: "fp-action-measure", style: { position: "fixed", left: -1e4, top: -1e4 }, "aria-hidden": "true", inert: !0, children: [
      t.map((h) => p(h, !0)),
      /* @__PURE__ */ e("button", { type: "button", "data-more-width": !0, children: /* @__PURE__ */ e(Kt, { size: 18 }) })
    ] })
  ] });
}
function Jf({
  anchor: t,
  open: n,
  onClose: r,
  children: i,
  label: a,
  id: l,
  role: s = "dialog",
  width: c,
  maxHeight: u = 320,
  className: d = "",
  initialFocus: p,
  autoFocus: h = s !== "listbox"
}) {
  const f = R(null), m = R(r);
  m.current = r;
  const [b, g] = k(!1), [v, w] = k({
    left: 8,
    top: 8,
    width: c || 240,
    maxHeight: u
  }), y = R(!1), N = Xt(t, n);
  return xe(() => {
    y.current && !n && g(!0), y.current = n;
  }, [n]), Y(() => {
    if (!b) return;
    const x = setTimeout(() => g(!1), 120);
    return () => clearTimeout(x);
  }, [b]), xe(() => {
    if (!n) return;
    const x = () => {
      const z = t.current?.getBoundingClientRect();
      if (!z) {
        m.current();
        return;
      }
      const L = Math.max(
        0,
        Math.min(c || Math.max(z.width, 240), window.innerWidth - 16)
      ), j = window.innerHeight - z.bottom - 16, M = z.top - 16, A = j < Math.min(f.current?.scrollHeight || u, 200) && M > j, O = Math.max(0, Math.min(u, A ? M : j));
      w({
        left: Math.max(8, Math.min(z.left, window.innerWidth - L - 8)),
        top: A ? Math.max(
          8,
          z.top - Math.min(f.current?.scrollHeight || O, O) - 8
        ) : z.bottom + 8,
        width: L,
        maxHeight: O
      });
    };
    x();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(x);
    return t.current && C?.observe(t.current), f.current && C?.observe(f.current), window.addEventListener("resize", x), window.addEventListener("scroll", x, !0), () => {
      C?.disconnect(), window.removeEventListener("resize", x), window.removeEventListener("scroll", x, !0);
    };
  }, [n, t, c, u]), Y(() => {
    if (!n) return;
    const x = requestAnimationFrame(() => {
      !h && !p?.current || (p?.current || f.current?.querySelector(
        'input,button,[tabindex="0"]'
      ) || f.current)?.focus({ preventScroll: !0 });
    }), C = (L) => {
      !f.current?.contains(L.target) && !t.current?.contains(L.target) && m.current();
    }, z = (L) => {
      L.key === "Escape" && (!L.target.closest?.("[data-fp-overlay]") || L.target.closest?.("[data-fp-overlay]") === f.current) && (L.preventDefault(), L.stopPropagation(), m.current(), t.current?.focus({ preventScroll: !0 }));
    };
    return document.addEventListener("pointerdown", C, !0), document.addEventListener("focusin", C, !0), document.addEventListener("keydown", z, !0), () => {
      cancelAnimationFrame(x), document.removeEventListener("pointerdown", C, !0), document.removeEventListener("focusin", C, !0), document.removeEventListener("keydown", z, !0);
    };
  }, [n, t, p, h]), !n && !b ? null : Oe(
    /* @__PURE__ */ e(
      "div",
      {
        ref: f,
        "data-fp-overlay": "",
        id: l,
        role: s,
        "aria-label": a,
        tabIndex: -1,
        "data-exiting": !n || void 0,
        "aria-hidden": !n || void 0,
        inert: !n,
        className: `fp-popup-panel fp-anchored-panel ${d}`,
        style: { ...N, position: "fixed", ...v, overflow: "auto" },
        onKeyDown: (x) => {
          if (s === "dialog" || x.target.closest("[data-fp-overlay]") !== f.current || x.target.matches("input,textarea"))
            return;
          const C = [
            ...x.currentTarget.querySelectorAll(
              '[role="menuitem"]:not(:disabled),[role="option"]:not(:disabled)'
            )
          ], z = C.indexOf(document.activeElement), L = x.key === "ArrowDown" ? (z + 1) % C.length : x.key === "ArrowUp" ? (z - 1 + C.length) % C.length : x.key === "Home" ? 0 : x.key === "End" ? C.length - 1 : -1;
          L >= 0 && (x.preventDefault(), x.stopPropagation(), C[L]?.focus());
        },
        children: i
      }
    ),
    t.current?.closest("[data-fp-overlay],dialog") || document.body
  );
}
function Zf({ dark: t, onChange: n, disabled: r }) {
  return /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": t ? "切换为浅色" : "切换为深色", disabled: r, onClick: () => n(!t), children: t ? /* @__PURE__ */ e(ko, { size: 19, "aria-hidden": "true" }) : /* @__PURE__ */ e(No, { size: 19, "aria-hidden": "true" }) });
}
function em({ name: t, detail: n, avatar: r, role: i, roleLabel: a, actions: l }) {
  return /* @__PURE__ */ o("div", { className: "fp-share-member-row", children: [
    /* @__PURE__ */ e("span", { className: "fp-share-member-avatar", "aria-hidden": "true", children: r || t.slice(0, 1) }),
    /* @__PURE__ */ o("span", { className: "fp-share-member-identity", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-share-member-role", children: [
      a && /* @__PURE__ */ e("small", { className: "fp-share-member-role-label", children: a }),
      i
    ] }),
    l && /* @__PURE__ */ e("div", { className: "fp-share-member-actions", children: l })
  ] });
}
function tm({ items: t, value: n, onChange: r, onClose: i, children: a }) {
  const [l, s] = k("");
  return /* @__PURE__ */ o("div", { className: "fp-settings-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: "设置" }),
      /* @__PURE__ */ o("label", { className: "fp-settings-search", children: [
        /* @__PURE__ */ e(Ue, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索设置", placeholder: "搜索设置", value: l, onChange: (c) => s(c.target.value) })
      ] }),
      /* @__PURE__ */ e("nav", { "aria-label": "设置分类", children: t.filter((c) => c.label.includes(l.trim())).map((c) => /* @__PURE__ */ o("button", { type: "button", "aria-current": n === c.id ? "page" : void 0, onClick: () => r(c.id), children: [
        c.icon,
        /* @__PURE__ */ e("span", { children: c.label })
      ] }, c.id)) })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-settings-page", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("h2", { children: t.find((c) => c.id === n)?.label }),
        /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": "关闭", onClick: i, children: /* @__PURE__ */ e(ke, { size: 20 }) })
      ] }),
      /* @__PURE__ */ e("div", { className: "fp-settings-page-content", children: a })
    ] })
  ] });
}
function nm({ onContinue: t, onDiscard: n }) {
  const r = R(null), i = ve();
  return Y(() => {
    const a = document.activeElement;
    return r.current?.focus(), () => {
      a?.isConnected && a.focus();
    };
  }, []), /* @__PURE__ */ e("div", { className: "fp-discard-backdrop", children: /* @__PURE__ */ o("section", { className: "fp-discard-prompt", role: "alertdialog", "aria-modal": "true", "aria-label": "保存当前更改", "aria-describedby": i, children: [
    /* @__PURE__ */ e("h2", { children: "保留这次更改？" }),
    /* @__PURE__ */ e("p", { id: i, children: "更改尚未保存。你可以继续编辑，或放弃后关闭。" }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("button", { ref: r, type: "button", className: "fp-button fp-secondary", onClick: t, children: "继续编辑" }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-danger", onClick: n, children: "放弃更改" })
    ] })
  ] }) });
}
function rm({ header: t, children: n, actions: r, onFinish: i }) {
  return /* @__PURE__ */ o("section", { className: "fp-card-editor-frame", "data-nested-editor-boundary": "", onKeyDownCapture: (a) => {
    i && !a.nativeEvent.isComposing && a.nativeEvent.keyCode !== 229 && !a.repeat && a.key === "Enter" && (a.ctrlKey || a.metaKey) && Fa(a.nativeEvent, a.currentTarget) && (a.preventDefault(), a.stopPropagation(), i());
  }, children: [
    /* @__PURE__ */ e("header", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-card-editor-content", children: n }),
    /* @__PURE__ */ e("footer", { children: r })
  ] });
}
function im({
  query: t,
  onQueryChange: n,
  onSearch: r,
  onOpen: i,
  placeholder: a = "搜索笔记与资料",
  debounceMs: l = 220
}) {
  const [s, c] = k([]), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(0), [b, g] = k(0), v = R(0), w = R(null);
  Y(() => {
    const N = new AbortController(), x = ++v.current;
    if (c([]), m(0), h(""), d(!!t.trim()), !t.trim()) return () => N.abort();
    const C = setTimeout(() => {
      r(t.trim(), N.signal).then((z) => {
        !N.signal.aborted && x === v.current && c(z);
      }).catch(() => {
        N.signal.aborted || h("暂时无法搜索，请重试。");
      }).finally(() => {
        !N.signal.aborted && x === v.current && d(!1);
      });
    }, l);
    return () => {
      clearTimeout(C), N.abort();
    };
  }, [t, r, l, b]);
  const y = s.filter((N) => !N.disabled);
  return /* @__PURE__ */ o("section", { className: "fp-search-results", children: [
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(Ue, { size: 17 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索内容",
          placeholder: a,
          value: t,
          onChange: (N) => n(N.target.value),
          onKeyDown: (N) => {
            if (!N.nativeEvent.isComposing) {
              if (N.key === "ArrowDown" || N.key === "ArrowUp") {
                N.preventDefault();
                const x = (f + (N.key === "ArrowDown" ? 1 : -1) + Math.max(y.length, 1)) % Math.max(y.length, 1);
                m(x), w.current?.querySelectorAll("button[data-hit]")[x]?.scrollIntoView?.({ block: "nearest" });
              }
              N.key === "Enter" && y[f] && (N.preventDefault(), i(y[f]));
            }
          }
        }
      )
    ] }),
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ e("div", { ref: w, className: "fp-search-hits", "aria-busy": u, children: u ? /* @__PURE__ */ e("p", { role: "status", children: "正在搜索…" }) : p ? /* @__PURE__ */ o("p", { role: "alert", children: [
      p,
      /* @__PURE__ */ e("button", { type: "button", onClick: () => g((N) => N + 1), children: "重试" })
    ] }) : t.trim() ? s.length ? s.map((N) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "data-hit": N.disabled ? void 0 : "",
        "data-active": y[f]?.id === N.id || void 0,
        disabled: N.disabled,
        onClick: () => i(N),
        children: [
          N.icon,
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: N.title }),
            N.path && /* @__PURE__ */ e("small", { children: N.path }),
            N.excerpt && /* @__PURE__ */ e("span", { children: N.excerpt })
          ] })
        ]
      },
      N.id
    )) : /* @__PURE__ */ e("p", { children: "没有找到匹配的内容。" }) : /* @__PURE__ */ e("p", { children: "输入关键词查找内容。" }) }) })
  ] });
}
function am({
  tabs: t,
  activeId: n,
  paneId: r = "main",
  onSelect: i,
  onClose: a,
  onMove: l,
  onSplit: s
}) {
  const c = R(null), u = (d, p) => {
    d.preventDefault();
    try {
      const h = JSON.parse(
        d.dataTransfer.getData("application/x-fiveplusone-tab")
      );
      typeof h.id == "string" && l?.(h.id, r, p);
    } catch {
    }
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-workspace-tabs",
      onDragOver: (d) => {
        l && d.dataTransfer.types.includes("application/x-fiveplusone-tab") && d.preventDefault();
      },
      onDrop: (d) => u(d, t.length),
      children: [
        /* @__PURE__ */ e(
          "div",
          {
            ref: c,
            role: "tablist",
            "aria-label": "打开的文档",
            onKeyDown: (d) => {
              const p = t.findIndex((f) => f.id === n);
              let h = p;
              if (d.key === "ArrowRight") h = (p + 1) % t.length;
              else if (d.key === "ArrowLeft")
                h = (p - 1 + t.length) % t.length;
              else if (d.key === "Home") h = 0;
              else if (d.key === "End") h = t.length - 1;
              else return;
              t[h] && (d.preventDefault(), i(t[h].id), c.current?.querySelectorAll("[role=tab]")[h]?.focus());
            },
            children: t.map((d, p) => /* @__PURE__ */ e(
              xt,
              {
                label: `${d.title}的操作`,
                items: [
                  {
                    id: "close",
                    label: "关闭",
                    disabled: d.closable === !1,
                    onSelect: () => a(d.id)
                  },
                  ...l ? [
                    {
                      id: "left",
                      label: "移到最前",
                      onSelect: () => l(d.id, r, 0)
                    }
                  ] : []
                ],
                children: /* @__PURE__ */ o(
                  "div",
                  {
                    className: "fp-workspace-tab",
                    "data-active": n === d.id || void 0,
                    draggable: !!l,
                    onDragStart: (h) => {
                      h.dataTransfer.setData(
                        "application/x-fiveplusone-tab",
                        JSON.stringify({ id: d.id, paneId: r })
                      ), h.dataTransfer.effectAllowed = "move";
                    },
                    onDrop: (h) => {
                      h.stopPropagation(), u(h, p);
                    },
                    children: [
                      /* @__PURE__ */ o(
                        "button",
                        {
                          type: "button",
                          role: "tab",
                          "aria-selected": n === d.id,
                          tabIndex: n === d.id ? 0 : -1,
                          onClick: () => i(d.id),
                          children: [
                            d.icon,
                            /* @__PURE__ */ e("span", { children: d.title }),
                            d.dirty && /* @__PURE__ */ e("span", { "aria-label": "尚未保存", className: "fp-tab-dirty", children: "•" })
                          ]
                        }
                      ),
                      d.closable !== !1 && /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          "aria-label": `关闭${d.title}`,
                          onClick: () => a(d.id),
                          children: /* @__PURE__ */ e(ke, { size: 13 })
                        }
                      )
                    ]
                  }
                )
              },
              d.id
            ))
          }
        ),
        s && /* @__PURE__ */ e("button", { type: "button", "aria-label": "切换分屏", onClick: s, children: /* @__PURE__ */ e(xo, { size: 16 }) })
      ]
    }
  );
}
function hp({ section: t }) {
  const [n, r] = k(
    t.defaultOpen ?? t.kind === "content"
  );
  return /* @__PURE__ */ o("section", { className: "fp-message-section", "data-status": t.status, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": n,
        onClick: () => r((i) => !i),
        children: [
          /* @__PURE__ */ e(
            Ae,
            {
              size: 14,
              style: { transform: n ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t.label }),
          t.status && /* @__PURE__ */ e("small", { children: t.status === "running" ? "进行中" : t.status === "done" ? "已完成" : "需要处理" })
        ]
      }
    ),
    /* @__PURE__ */ e(je, { isOpen: n, children: /* @__PURE__ */ e("div", { children: t.content }) })
  ] });
}
function lm({
  sections: t,
  actions: n
}) {
  return /* @__PURE__ */ o("article", { className: "fp-message-content-view", children: [
    t.map((r) => /* @__PURE__ */ e(hp, { section: r }, r.id)),
    n && /* @__PURE__ */ e("footer", { children: n })
  ] });
}
function om({
  title: t,
  description: n,
  kind: r = "文档",
  onOpen: i
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-artifact-card", onClick: i, children: [
    /* @__PURE__ */ e(nt, { size: 24 }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("small", { children: r }),
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "↗" })
  ] });
}
function sm({
  title: t,
  children: n,
  onDownload: r,
  onSave: i,
  loading: a,
  error: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-artifact", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "下载" }),
        i && /* @__PURE__ */ e(ye, { disabled: a, onAction: i, children: "保存到资料" })
      ] })
    ] }),
    a ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开内容…" }) : l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : /* @__PURE__ */ e("div", { className: "fp-artifact-content", children: n })
  ] });
}
function cm({
  items: t,
  onToggle: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "学习助手能力" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-skill-row", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: r.name }),
        /* @__PURE__ */ e("small", { children: r.description })
      ] }),
      /* @__PURE__ */ e(
        ye,
        {
          disabled: r.disabled,
          onAction: () => n(r.id, !r.enabled),
          children: r.enabled ? "停用" : "启用"
        }
      )
    ] }, r.id))
  ] });
}
class fp {
  nodes = [];
  links = [];
  heat = 1;
  byId = /* @__PURE__ */ new Map();
  reconcile(n, r) {
    const i = /* @__PURE__ */ new Map();
    n.forEach((l, s) => {
      if (i.has(l)) return;
      const c = s * 2.399963229728653, u = 24 * Math.sqrt(s + 1), d = this.byId.get(l) || { id: l, x: Math.cos(c) * u, y: Math.sin(c) * u, vx: 0, vy: 0, degree: 0 };
      d.degree = 0, i.set(l, d);
    }), this.byId = i, this.nodes = [...i.values()];
    const a = /* @__PURE__ */ new Set();
    this.links = [], r.forEach((l) => {
      const s = i.get(l.source), c = i.get(l.target), u = JSON.stringify([l.source, l.target].sort());
      !s || !c || s === c || a.has(u) || (a.add(u), s.degree++, c.degree++, this.links.push([s, c]));
    }), this.wake();
  }
  get(n) {
    return this.byId.get(n);
  }
  wake() {
    this.heat = 1;
  }
  pin(n, r, i) {
    const a = this.get(n);
    a && (a.fixed = { x: r, y: i }, a.x = r, a.y = i, a.vx = a.vy = 0, this.wake());
  }
  release(n) {
    const r = this.get(n);
    r && (delete r.fixed, this.wake());
  }
  step(n) {
    if (this.heat < 2e-3) return !1;
    const r = this.nodes, i = Math.max(0, n.repelForce) * 180, a = Math.max(0.15, this.heat);
    for (let c = 0; c < r.length; c++) for (let u = c + 1; u < r.length; u++) {
      const d = r[c], p = r[u];
      let h = p.x - d.x, f = p.y - d.y;
      Math.abs(h) + Math.abs(f) < 1e-3 && (h = 0.1 * Math.cos(c + u), f = 0.1 * Math.sin(c + u));
      const m = Math.sqrt(h * h + f * f), b = 16 * n.nodeSize, g = Math.min(8, i / Math.max(64, m * m) + Math.max(0, b - m) * 0.12) * a, v = h / m * g, w = f / m * g;
      d.vx -= v, d.vy -= w, p.vx += v, p.vy += w;
    }
    for (const [c, u] of this.links) {
      const d = u.x - c.x, p = u.y - c.y, h = Math.max(1, Math.hypot(d, p)), f = 74 + Math.min(40, (c.degree + u.degree) * 1.2), m = (h - f) * 0.025 * n.linkForce * a, b = d / h * m, g = p / h * m;
      c.vx += b / Math.sqrt(c.degree), c.vy += g / Math.sqrt(c.degree), u.vx -= b / Math.sqrt(u.degree), u.vy -= g / Math.sqrt(u.degree);
    }
    let l = 0, s = !1;
    for (const c of r) {
      if (c.fixed) {
        c.x = c.fixed.x, c.y = c.fixed.y, c.vx = c.vy = 0, s = !0;
        continue;
      }
      c.vx = Math.max(-14, Math.min(14, (c.vx - c.x * n.centerForce * 1e-3) * 0.82)), c.vy = Math.max(-14, Math.min(14, (c.vy - c.y * n.centerForce * 1e-3) * 0.82)), c.x += c.vx, c.y += c.vy, l += c.vx * c.vx + c.vy * c.vy;
    }
    return this.heat = s ? Math.max(0.35, this.heat * 0.985) : this.heat * (l / Math.max(1, r.length) < 2e-3 ? 0.85 : 0.995), !0;
  }
}
const aa = { showArrows: !1, textOpacity: 1, nodeSize: 1, lineThickness: 1, centerForce: 0.5, repelForce: 9, linkForce: 0.8, colorGroups: [] }, $n = (t) => Math.max(0.08, Math.min(4, t)), kr = (t, n) => (4 + Math.min(5, Math.sqrt(t.degree) * 0.7)) * n;
function dm({ nodes: t, edges: n, selectedId: r, onSelect: i, settings: a, onSettingsChange: l, onRefresh: s, onClose: c, loading: u, error: d }) {
  const [p, h] = k(aa), [f, m] = k(""), [b, g] = k(!1), [v, w] = k(r || ""), [y, N] = k(""), [x, C] = k(!1), [z, L] = k(""), j = a || p, M = R(null), A = R(new fp()), O = R({ x: 0, y: 0, zoom: 1 }), U = R({ x: 0, y: 0, zoom: 1 }), T = R({ width: 1, height: 1 }), E = R(!1), S = R(!1), P = R(!0), _ = R({ nodes: t, settings: j, active: v, hovered: y, paused: x, query: f, onSelect: i });
  _.current = { nodes: t, settings: j, active: v, hovered: y, paused: x, query: f, onSelect: i };
  const q = () => {
    const V = A.current.nodes;
    if (!V.length) return;
    const K = Math.min(...V.map((F) => F.x)), re = Math.max(...V.map((F) => F.x)), le = Math.min(...V.map((F) => F.y)), fe = Math.max(...V.map((F) => F.y)), { width: se, height: we } = T.current, W = $n(Math.min((se - 100) / Math.max(120, re - K), (we - 140) / Math.max(120, fe - le), 1.5));
    U.current = { x: -(K + re) / 2 * W, y: -(le + fe) / 2 * W, zoom: W }, P.current = !0;
  }, H = R(q);
  H.current = q;
  const I = (V) => {
    S.current = !0;
    const K = U.current, re = $n(K.zoom * V);
    U.current = { x: K.x * re / K.zoom, y: K.y * re / K.zoom, zoom: re }, P.current = !0;
  }, $ = (V) => {
    w(V);
    const K = A.current.get(V);
    if (!K) return;
    S.current = !0;
    const re = Math.max(0.8, U.current.zoom);
    U.current = { x: -K.x * re, y: -K.y * re, zoom: re }, P.current = !0;
  }, B = (V) => {
    const K = { ...j, ...V };
    h(K), l?.(K), A.current.wake(), P.current = !0;
  };
  Y(() => {
    w(r || "");
  }, [r]), Y(() => {
    A.current.reconcile(t.map((V) => V.id), n), P.current = !0, !E.current && t.length && (S.current = !1, H.current()), E.current = t.length > 0;
  }, [t, n]), Y(() => {
    A.current.wake(), P.current = !0;
  }, [j, f, v, y, x]), Y(() => {
    const V = M.current;
    if (!V || typeof CanvasRenderingContext2D > "u") return;
    const K = V.getContext("2d");
    if (!K) {
      L("画布暂时无法显示，请通过搜索打开笔记。");
      return;
    }
    let re = 0, le = 0, fe = 0, se = !0, we = "sans-serif", W = { ink: "#202124", muted: "#747981", line: "#d5d8de", surface: "#fff", action: "#7255b4", groups: [] };
    const F = () => {
      const ce = getComputedStyle(V), ae = (he, oe) => ce.getPropertyValue(he).trim() || oe;
      we = ce.fontFamily, W = { ink: ae("--fp-ink", W.ink), muted: ae("--fp-muted", W.muted), line: ae("--fp-line-strong", W.line), surface: ae("--fp-surface", W.surface), action: ae("--fp-primary", W.action), groups: [ae("--fp-primary", "#7255b4"), ae("--fp-success", "#368b75"), ae("--fp-warning", "#ae782f"), "#6d91b6", "#b67c96", "#8b94a8"] }, P.current = !0;
    };
    F();
    const D = new MutationObserver(F);
    D.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product", "class", "style"] });
    const G = () => {
      const ce = V.getBoundingClientRect(), ae = Math.min(window.devicePixelRatio || 1, 2);
      T.current = { width: Math.max(1, ce.width), height: Math.max(1, ce.height) }, V.width = Math.round(T.current.width * ae), V.height = Math.round(T.current.height * ae), K.setTransform(ae, 0, 0, ae, 0, 0), P.current = !0, S.current || H.current();
    }, de = new ResizeObserver(G);
    de.observe(V), G();
    const me = (ce) => {
      const ae = V.getBoundingClientRect();
      return { x: ce.clientX - ae.left - T.current.width / 2, y: ce.clientY - ae.top - T.current.height / 2 };
    }, ze = (ce) => {
      const ae = O.current, he = { x: (ce.x - ae.x) / ae.zoom, y: (ce.y - ae.y) / ae.zoom };
      return A.current.nodes.reduce((oe, Re) => {
        const Qe = Math.hypot(Re.x - he.x, Re.y - he.y), We = Math.max(kr(Re, _.current.settings.nodeSize), 12 / ae.zoom);
        return Qe <= We && (!oe || Qe < Math.hypot(oe.x - he.x, oe.y - he.y)) ? Re : oe;
      }, void 0);
    }, $e = /* @__PURE__ */ new Map();
    let Se;
    const yt = (ce) => {
      if (ce.button !== 0) return;
      const ae = me(ce);
      if ($e.set(ce.pointerId, ae), V.setPointerCapture(ce.pointerId), S.current = !0, N(""), $e.size > 1) {
        Se?.node && A.current.release(Se.node), Se = void 0;
        return;
      }
      const he = ze(ae);
      Se = { id: ce.pointerId, node: he?.id, start: ae, last: ae, moved: !1 }, he && A.current.pin(he.id, he.x, he.y), V.style.cursor = "grabbing";
    }, Qt = (ce) => {
      const ae = me(ce), he = $e.get(ce.pointerId);
      if (he && $e.size === 2) {
        const oe = [...$e.entries()].find(([Te]) => Te !== ce.pointerId)[1], Re = Math.hypot(he.x - oe.x, he.y - oe.y), Qe = Math.hypot(ae.x - oe.x, ae.y - oe.y), We = O.current, vt = $n(We.zoom * Qe / Math.max(1, Re)), Et = { x: (he.x + oe.x) / 2, y: (he.y + oe.y) / 2 }, Nn = { x: (ae.x + oe.x) / 2, y: (ae.y + oe.y) / 2 };
        O.current = U.current = { x: Nn.x - (Et.x - We.x) * vt / We.zoom, y: Nn.y - (Et.y - We.y) * vt / We.zoom, zoom: vt }, $e.set(ce.pointerId, ae), P.current = !0;
        return;
      }
      if (he && $e.set(ce.pointerId, ae), Se && Se.id === ce.pointerId) {
        if (Se.moved ||= Math.hypot(ae.x - Se.start.x, ae.y - Se.start.y) > 4, Se.node) {
          const oe = O.current;
          A.current.pin(Se.node, (ae.x - oe.x) / oe.zoom, (ae.y - oe.y) / oe.zoom);
        } else {
          const oe = O.current;
          O.current = U.current = { ...oe, x: oe.x + ae.x - Se.last.x, y: oe.y + ae.y - Se.last.y };
        }
        Se.last = ae, P.current = !0;
      } else if (!$e.size) {
        const oe = ze(ae);
        N(oe?.id || ""), V.style.cursor = "grab";
      }
    }, lt = (ce) => {
      $e.delete(ce.pointerId), Se?.id === ce.pointerId && (Se.node && A.current.release(Se.node), !Se.moved && ce.type !== "pointercancel" && w(Se.node || ""), Se = void 0), V.hasPointerCapture(ce.pointerId) && V.releasePointerCapture(ce.pointerId), P.current = !0, V.style.cursor = "grab";
    }, bi = () => {
      $e.size || N("");
    }, gi = (ce) => {
      const ae = ze(me(ce));
      ae && _.current.onSelect(ae.id);
    }, yi = (ce) => {
      ce.preventDefault(), S.current = !0;
      const ae = me(ce), he = U.current, oe = $n(he.zoom * Math.exp(-Math.max(-100, Math.min(100, ce.deltaY)) * 2e-3));
      U.current = { x: ae.x - (ae.x - he.x) * oe / he.zoom, y: ae.y - (ae.y - he.y) * oe / he.zoom, zoom: oe }, P.current = !0;
    };
    V.addEventListener("pointerdown", yt), V.addEventListener("pointermove", Qt), V.addEventListener("pointerup", lt), V.addEventListener("pointercancel", lt), V.addEventListener("lostpointercapture", lt), V.addEventListener("pointerleave", bi), V.addEventListener("dblclick", gi), V.addEventListener("wheel", yi, { passive: !1 });
    const Bl = () => {
      const { width: ce, height: ae } = T.current, he = O.current, { settings: oe, active: Re, hovered: Qe, query: We, nodes: vt } = _.current;
      K.clearRect(0, 0, ce, ae);
      const Et = A.current, Nn = new Map(vt.map((be) => [be.id, be])), Te = Qe || Re, $t = new Set(Te ? [Te] : []);
      if (Te) for (const [be, Me] of Et.links)
        be.id === Te && $t.add(Me.id), Me.id === Te && $t.add(be.id);
      const jl = new Set(We.trim() ? vt.filter((be) => be.label.toLocaleLowerCase().includes(We.trim().toLocaleLowerCase())).map((be) => be.id) : []), xn = (be) => ({ x: be.x * he.zoom + he.x + ce / 2, y: be.y * he.zoom + he.y + ae / 2 }), sr = (be) => {
        const Me = xn(be);
        return Me.x > -30 && Me.y > -30 && Me.x < ce + 30 && Me.y < ae + 30;
      }, ql = (be) => Te ? !$t.has(be) : We.trim() ? !jl.has(be) : !1;
      for (const [be, Me] of Et.links) {
        if (!sr(be) && !sr(Me)) continue;
        const _e = xn(be), Je = xn(Me), wt = Te && (be.id === Te || Me.id === Te);
        if (K.globalAlpha = wt ? 0.8 : Te || We.trim() ? 0.08 : 0.58, K.strokeStyle = wt ? W.action : W.line, K.lineWidth = oe.lineThickness * (wt ? 1.4 : 0.7), K.beginPath(), K.moveTo(_e.x, _e.y), K.lineTo(Je.x, Je.y), K.stroke(), oe.showArrows && (wt || he.zoom > 0.7)) {
          const kt = Math.atan2(Je.y - _e.y, Je.x - _e.x), Jt = kr(Me, oe.nodeSize) * he.zoom + 3, zt = Je.x - Math.cos(kt) * Jt, ut = Je.y - Math.sin(kt) * Jt;
          K.beginPath(), K.moveTo(zt - Math.cos(kt - 0.5) * 5, ut - Math.sin(kt - 0.5) * 5), K.lineTo(zt, ut), K.lineTo(zt - Math.cos(kt + 0.5) * 5, ut - Math.sin(kt + 0.5) * 5), K.stroke();
        }
      }
      const Kl = [...new Set(vt.map((be) => be.kind).filter(Boolean))], Hl = [...Et.nodes].sort((be, Me) => +(Me.id === Te) - +(be.id === Te) || Number($t.has(Me.id)) - Number($t.has(be.id)) || Me.degree - be.degree), cr = [];
      for (const be of Hl) {
        if (!sr(be)) continue;
        const Me = xn(be), _e = Nn.get(be.id), Je = Math.max(2, kr(be, oe.nodeSize) * he.zoom), wt = ql(be.id), Jt = oe.colorGroups.find((ot) => ot.query.trim() && _e?.label.includes(ot.query))?.color || (_e?.kind ? W.groups[Math.max(0, Kl.indexOf(_e.kind)) % W.groups.length] : W.action);
        if (K.globalAlpha = wt ? 0.18 : 1, K.fillStyle = Jt, K.beginPath(), K.arc(Me.x, Me.y, Je, 0, Math.PI * 2), K.fill(), be.id === Te && (K.strokeStyle = Jt, K.lineWidth = 1.5, K.beginPath(), K.arc(Me.x, Me.y, Je + 5, 0, Math.PI * 2), K.stroke()), wt || !_e || !oe.textOpacity || (Te ? !$t.has(be.id) : he.zoom < 0.55 && cr.length >= 12)) continue;
        const zt = _e.label.length > 22 ? _e.label.slice(0, 21) + "…" : _e.label;
        K.font = `${be.id === Te ? 600 : 400} 12px ${we}`;
        const ut = K.measureText(zt).width + 10, Cn = 20, Sn = Me.x - ut / 2, Zt = Me.y + Je + 6;
        cr.some((ot) => Sn < ot.x + ot.w + 6 && Sn + ut + 6 > ot.x && Zt < ot.y + ot.h + 3 && Zt + Cn + 3 > ot.y) || (cr.push({ x: Sn, y: Zt, w: ut, h: Cn }), K.globalAlpha = oe.textOpacity * 0.94, K.fillStyle = W.surface, K.fillRect(Sn, Zt, ut, Cn), K.fillStyle = W.ink, K.textBaseline = "middle", K.textAlign = "center", K.fillText(zt, Me.x, Zt + Cn / 2));
      }
      K.globalAlpha = 1;
    }, vi = (ce) => {
      if (!se) return;
      const ae = Math.min(50, ce - le);
      if (le = ce, fe += ae, document.hidden)
        fe = 0;
      else {
        let he = !1;
        if (_.current.paused) fe = 0;
        else for (; fe >= 1e3 / 60; )
          he = A.current.step(_.current.settings) || he, fe -= 1e3 / 60;
        !S.current && he && H.current();
        const oe = O.current, Re = U.current;
        if (Math.abs(oe.x - Re.x) + Math.abs(oe.y - Re.y) + Math.abs(oe.zoom - Re.zoom) > 0.01) {
          const Qe = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : 0.2;
          O.current = { x: oe.x + (Re.x - oe.x) * Qe, y: oe.y + (Re.y - oe.y) * Qe, zoom: oe.zoom + (Re.zoom - oe.zoom) * Qe }, he = !0;
        }
        (he || P.current) && (Bl(), P.current = !1);
      }
      re = requestAnimationFrame(vi);
    };
    return re = requestAnimationFrame(vi), () => {
      se = !1, cancelAnimationFrame(re), de.disconnect(), D.disconnect(), V.removeEventListener("pointerdown", yt), V.removeEventListener("pointermove", Qt), V.removeEventListener("pointerup", lt), V.removeEventListener("pointercancel", lt), V.removeEventListener("lostpointercapture", lt), V.removeEventListener("pointerleave", bi), V.removeEventListener("dblclick", gi), V.removeEventListener("wheel", yi);
    };
  }, []);
  const J = t.filter((V) => V.label.toLocaleLowerCase().includes(f.trim().toLocaleLowerCase())), Z = t.find((V) => V.id === v), Ne = new Set(n.flatMap((V) => V.source === v ? [V.target] : V.target === v ? [V.source] : []).filter((V) => V !== v)), pe = [...new Set(t.map((V) => V.kind).filter(Boolean))];
  return /* @__PURE__ */ o("section", { className: "fp-graph", "aria-label": "关系图谱", onKeyDown: (V) => {
    V.key === "Escape" && (b ? g(!1) : f ? m("") : v ? w("") : c?.());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-graph-toolbar", children: [
      /* @__PURE__ */ o("div", { className: "fp-graph-heading", children: [
        /* @__PURE__ */ e(xi, { size: 18 }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: "关系图谱" }),
          /* @__PURE__ */ o("span", { children: [
            t.length,
            " 篇笔记 · ",
            n.length,
            " 条关联"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-graph-search", children: [
        /* @__PURE__ */ e(Ue, { size: 16 }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索关联笔记", placeholder: "搜索笔记…", value: f, onChange: (V) => m(V.target.value) }),
        f && /* @__PURE__ */ e("button", { type: "button", "aria-label": "清空搜索", onClick: () => m(""), children: /* @__PURE__ */ e(ke, { size: 14 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-actions", children: [
        /* @__PURE__ */ e("button", { type: "button", title: "适应画布", "aria-label": "适应画布", onClick: () => {
          S.current = !0, q();
        }, children: /* @__PURE__ */ e(Gn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": x ? "继续动态布局" : "暂停动态布局", title: x ? "继续动态布局" : "暂停动态布局", onClick: () => {
          C(!x), A.current.wake();
        }, children: x ? /* @__PURE__ */ e(cn, { size: 17 }) : /* @__PURE__ */ e(Vn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "显示设置", title: "图谱设置", "aria-expanded": b, onClick: () => g(!b), children: /* @__PURE__ */ e(ga, { size: 17 }) }),
        c && /* @__PURE__ */ e("button", { type: "button", title: "关闭图谱", "aria-label": "关闭图谱", onClick: c, children: /* @__PURE__ */ e(ke, { size: 19 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-graph-viewport", children: [
      /* @__PURE__ */ e("canvas", { ref: M, className: "fp-graph-canvas", tabIndex: 0, role: "img", "aria-label": "可拖动的笔记关系图；使用搜索选择笔记", onKeyDown: (V) => {
        V.key === "+" || V.key === "=" ? (V.preventDefault(), I(1.2)) : V.key === "-" ? (V.preventDefault(), I(1 / 1.2)) : V.key === "0" ? (V.preventDefault(), q()) : ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(V.key) ? (V.preventDefault(), S.current = !0, U.current = { ...U.current, x: U.current.x + (V.key === "ArrowLeft" ? 40 : V.key === "ArrowRight" ? -40 : 0), y: U.current.y + (V.key === "ArrowUp" ? 40 : V.key === "ArrowDown" ? -40 : 0) }, P.current = !0) : V.key === "Enter" && v && i(v);
      } }),
      u && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "status", children: [
        /* @__PURE__ */ o("div", { className: "fp-graph-skeleton", children: [
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {})
        ] }),
        /* @__PURE__ */ e("p", { children: "正在展开笔记关系…" })
      ] }),
      (d || z) && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: d || z }),
        s && /* @__PURE__ */ e("button", { type: "button", onClick: s, children: "重新加载" })
      ] }),
      !u && !d && !t.length && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", children: [
        /* @__PURE__ */ e(xi, { size: 32 }),
        /* @__PURE__ */ e("p", { children: "把笔记链接起来，知识会在这里连接成图。" })
      ] }),
      f.trim() && /* @__PURE__ */ o("nav", { className: "fp-graph-results", "aria-label": "选择关联笔记", children: [
        /* @__PURE__ */ e("small", { children: J.length ? `${J.length} 篇匹配的笔记` : "没有找到匹配的笔记" }),
        J.slice(0, 30).map((V) => /* @__PURE__ */ e("button", { type: "button", "aria-pressed": V.id === v, onClick: () => $(V.id), children: V.label }, V.id)),
        J.length > 30 && /* @__PURE__ */ e("small", { children: "继续输入可缩小范围" })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-graph-options", "data-open": b, inert: !b, "aria-hidden": !b, "aria-label": "图谱设置", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: "图谱设置" }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭设置", onClick: () => g(!1), children: /* @__PURE__ */ e(ke, { size: 16 }) })
        ] }),
        /* @__PURE__ */ e("p", { children: "拖动节点时，周围的笔记会随之调整。" }),
        /* @__PURE__ */ e(mi, { label: "显示箭头", checked: j.showArrows, onChange: (V) => B({ showArrows: V.target.checked }) }),
        [["repelForce", "节点间距", 1, 20, 1], ["linkForce", "连线牵引", 0.1, 2, 0.1], ["centerForce", "中心吸引", 0, 2, 0.1], ["nodeSize", "节点大小", 0.5, 3, 0.1], ["lineThickness", "连线粗细", 0.5, 3, 0.1], ["textOpacity", "文字清晰度", 0, 1, 0.1]].map(([V, K, re, le, fe]) => /* @__PURE__ */ o("label", { className: "fp-graph-setting", children: [
          /* @__PURE__ */ o("span", { children: [
            K,
            /* @__PURE__ */ e("output", { children: j[V] })
          ] }),
          /* @__PURE__ */ e(Er, { "aria-label": K, min: re, max: le, step: fe, value: j[V], onChange: (se) => B({ [V]: Number(se.target.value) }) })
        ] }, V)),
        pe.length > 0 && /* @__PURE__ */ o("div", { className: "fp-graph-group-legend", children: [
          /* @__PURE__ */ e("strong", { children: "笔记分组" }),
          pe.map((V, K) => /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", { "data-color": K % 6 }),
            V
          ] }, V))
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-graph-color-groups", children: [
          /* @__PURE__ */ e("strong", { children: "关键词颜色" }),
          j.colorGroups.map((V, K) => /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("input", { className: "fp-pattern-input", "aria-label": `第 ${K + 1} 组关键词`, value: V.query, placeholder: "标题包含", onChange: (re) => B({ colorGroups: j.colorGroups.map((le, fe) => fe === K ? { ...le, query: re.target.value } : le) }) }),
            /* @__PURE__ */ e(Pl, { label: `第 ${K + 1} 组颜色`, value: V.color, onChange: (re) => B({ colorGroups: j.colorGroups.map((le, fe) => fe === K ? { ...le, color: re } : le) }) }),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除第 ${K + 1} 组`, onClick: () => B({ colorGroups: j.colorGroups.filter((re, le) => le !== K) }), children: /* @__PURE__ */ e(ke, { size: 14 }) })
          ] }, K)),
          /* @__PURE__ */ o("button", { type: "button", onClick: () => B({ colorGroups: [...j.colorGroups, { query: "", color: "#7255b4" }] }), children: [
            /* @__PURE__ */ e(qt, { size: 14 }),
            "添加分组"
          ] })
        ] }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => {
          B(aa), A.current.wake();
        }, children: [
          /* @__PURE__ */ e(tt, { size: 14 }),
          "恢复默认"
        ] }),
        s && /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: s, children: "刷新笔记关系" })
      ] }),
      Z && /* @__PURE__ */ o("div", { className: "fp-graph-inspector", children: [
        /* @__PURE__ */ e("button", { className: "fp-graph-inspector-close", type: "button", "aria-label": "取消选择", onClick: () => w(""), children: /* @__PURE__ */ e(ke, { size: 14 }) }),
        /* @__PURE__ */ o("small", { children: [
          Z.kind || "笔记",
          " · ",
          Ne.size,
          " 篇关联"
        ] }),
        /* @__PURE__ */ e("strong", { children: Z.label }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => i(Z.id), children: [
          "打开笔记",
          /* @__PURE__ */ e(_r, { size: 15 })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-zoom", children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "放大图谱", onClick: () => I(1.2), children: /* @__PURE__ */ e(qt, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩小图谱", onClick: () => I(1 / 1.2), children: /* @__PURE__ */ e(jt, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("p", { className: "fp-graph-hint", children: [
        "拖动节点 · 滚轮缩放 · 双击打开笔记",
        x ? " · 布局已暂停" : ""
      ] })
    ] })
  ] });
}
function um({
  title: t,
  children: n,
  tools: r,
  inspector: i,
  source: a,
  onSourceChange: l,
  onRun: s,
  onReset: c,
  onSave: u,
  loading: d,
  error: p
}) {
  const h = R(null), [f, m] = k(!1), [b, g] = k(!1), [v, w] = k("");
  return /* @__PURE__ */ o("section", { ref: h, className: "fp-workbench", "aria-label": t, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r,
        a !== void 0 && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            "aria-pressed": f,
            onClick: () => m((y) => !y),
            children: [
              f ? /* @__PURE__ */ e(wa, { size: 15 }) : /* @__PURE__ */ e(Co, { size: 15 }),
              " ",
              f ? "查看内容" : "编辑源码"
            ]
          }
        ),
        i && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-expanded": b,
            onClick: () => g((y) => !y),
            children: "参数"
          }
        ),
        c && /* @__PURE__ */ o("button", { type: "button", onClick: c, children: [
          /* @__PURE__ */ e(tt, { size: 15 }),
          "重置"
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "全屏查看",
            onClick: () => {
              if (!h.current?.requestFullscreen) {
                w("当前设备暂不支持全屏。");
                return;
              }
              h.current.requestFullscreen().catch(() => w("暂时无法进入全屏，请重试。"));
            },
            children: /* @__PURE__ */ e(Gn, { size: 15 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(je, { isOpen: b, children: /* @__PURE__ */ e("div", { className: "fp-workbench-inspector", children: i }) }),
    /* @__PURE__ */ e("div", { className: "fp-workbench-stage", "aria-busy": d, children: d ? /* @__PURE__ */ e("p", { role: "status", children: "正在准备内容…" }) : f ? /* @__PURE__ */ o("label", { children: [
      "源码",
      /* @__PURE__ */ e(
        "textarea",
        {
          "aria-label": "内容源码",
          value: a,
          readOnly: !l,
          spellCheck: !1,
          onChange: (y) => l?.(y.target.value)
        }
      )
    ] }) : n }),
    (p || v) && /* @__PURE__ */ e("p", { role: p ? "alert" : "status", children: p || v }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      f && s && /* @__PURE__ */ e(ye, { disabled: d, onAction: s, children: "运行" }),
      u && /* @__PURE__ */ e(ye, { disabled: d, onAction: u, children: "保存到笔记" })
    ] })
  ] });
}
function pm({
  chapters: t,
  currentTime: n,
  onSeek: r,
  onAddNote: i
}) {
  const a = [...t].sort((s, c) => s.time - c.time), l = a.filter((s) => s.time <= n).at(-1)?.id;
  return /* @__PURE__ */ o("section", { className: "fp-classroom", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "课堂章节" }),
      i && /* @__PURE__ */ e("button", { type: "button", onClick: () => i(n), children: "记录此刻" })
    ] }),
    a.length ? /* @__PURE__ */ e("ol", { children: a.map((s) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": l === s.id ? "step" : void 0,
        onClick: () => r(s.time),
        children: [
          /* @__PURE__ */ o("time", { children: [
            Math.floor(s.time / 60),
            ":",
            String(Math.floor(s.time % 60)).padStart(2, "0")
          ] }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: s.title }),
            s.detail && /* @__PURE__ */ e("small", { children: s.detail })
          ] })
        ]
      }
    ) }, s.id)) }) : /* @__PURE__ */ e("p", { children: "还没有课堂章节，可以在观看时添加笔记。" })
  ] });
}
function hm({
  title: t,
  children: n,
  collapsed: r,
  onCollapsedChange: i,
  onClose: a
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-lecture-dock", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": !r,
          onClick: () => i(!r),
          children: r ? "展开播放器" : "收起播放器"
        }
      ),
      a && /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭播放器", onClick: a, children: "×" })
    ] }),
    /* @__PURE__ */ e(je, { isOpen: !r, children: n })
  ] });
}
function fm({
  items: t,
  onScoreChange: n,
  onComplete: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "答题复盘" }),
    /* @__PURE__ */ o("p", { children: [
      "已得 ",
      t.reduce((i, a) => i + a.awarded, 0),
      " /",
      " ",
      t.reduce((i, a) => i + a.maximum, 0),
      " 分"
    ] }),
    t.map((i) => /* @__PURE__ */ o("div", { className: "fp-scoring-item", children: [
      /* @__PURE__ */ e("strong", { children: i.title }),
      /* @__PURE__ */ o("span", { children: [
        i.awarded,
        " / ",
        i.maximum
      ] }),
      i.detail,
      i.subjective && /* @__PURE__ */ o("label", { children: [
        "自评得分",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": `${i.title}自评得分`,
            type: "range",
            min: 0,
            max: i.maximum,
            step: i.maximum <= 10 ? 0.5 : 1,
            value: Math.max(0, Math.min(i.maximum, i.awarded)),
            onChange: (a) => n(i.id, Number(a.target.value))
          }
        )
      ] })
    ] }, i.id)),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(ye, { onAction: r, children: "完成复盘" }) })
  ] });
}
function mm({
  correct: t,
  total: n,
  score: r,
  maximum: i,
  onReview: a,
  onRetry: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "本次练习" }),
    /* @__PURE__ */ o("strong", { className: "fp-summary-value", children: [
      r,
      /* @__PURE__ */ o("small", { children: [
        " / ",
        i,
        " 分"
      ] })
    ] }),
    /* @__PURE__ */ o("p", { children: [
      n,
      " 道题中答对 ",
      t,
      " 道"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "查看解析" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "再练一次" })
    ] })
  ] });
}
function bm({
  options: t,
  defaultValue: n,
  ...r
}) {
  const [i, a] = k(
    String(n ?? t[0]?.value ?? "")
  ), l = String(r.value ?? i), s = R(null), c = R(null), [u, d] = k("");
  return /* @__PURE__ */ o("span", { ref: c, className: r.className, children: [
    /* @__PURE__ */ e(
      "select",
      {
        ...r,
        hidden: !0,
        onInvalid: (p) => {
          p.preventDefault(), d(p.currentTarget.validationMessage), c.current?.querySelector("button")?.focus(), r.onInvalid?.(p);
        },
        "aria-hidden": "true",
        tabIndex: -1,
        ref: s,
        value: l,
        onChange: (p) => {
          a(p.target.value), r.onChange?.(p);
        },
        children: t.map((p) => /* @__PURE__ */ e("option", { value: p.value, children: p.label }, p.value))
      }
    ),
    /* @__PURE__ */ e(
      Ce,
      {
        label: r["aria-label"] || r.title || "选择选项",
        value: l,
        disabled: r.disabled,
        options: t,
        onChange: (p) => {
          a(p), d(""), s.current && (s.current.value = p, s.current.dispatchEvent(
            new Event("change", { bubbles: !0 })
          ));
        }
      }
    ),
    u && /* @__PURE__ */ e("span", { className: "fp-field-error", role: "alert", children: u })
  ] });
}
function gm({
  label: t,
  options: n,
  value: r,
  onChange: i
}) {
  const a = ve(), [l, s] = k(!1), [c, u] = k(0), d = n.filter(
    (p) => p.toLowerCase().includes(r.toLowerCase())
  );
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: a, children: t }),
    /* @__PURE__ */ o("div", { className: "fp-combobox", children: [
      /* @__PURE__ */ e(
        "input",
        {
          id: a,
          className: "fp-input",
          role: "combobox",
          "aria-expanded": l,
          "aria-controls": a + "-options",
          "aria-autocomplete": "list",
          "aria-activedescendant": l && d.length ? a + "-" + c : void 0,
          value: r,
          onFocus: () => s(!0),
          onBlur: () => s(!1),
          onChange: (p) => {
            i(p.target.value), s(!0), u(0);
          },
          onKeyDown: (p) => {
            if (p.key === "Escape") {
              s(!1);
              return;
            }
            (p.key === "ArrowDown" || p.key === "ArrowUp") && (p.preventDefault(), s(!0), u(
              (h) => (h + (p.key === "ArrowDown" ? 1 : -1) + d.length) % Math.max(d.length, 1)
            )), p.key === "Enter" && l && d[c] && (p.preventDefault(), i(d[c]), s(!1));
          }
        }
      ),
      l && /* @__PURE__ */ o(
        "div",
        {
          id: a + "-options",
          className: "fp-combobox-options",
          role: "listbox",
          "aria-label": t,
          children: [
            d.map((p, h) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": h === c,
                id: a + "-" + h,
                tabIndex: -1,
                onMouseDown: (f) => f.preventDefault(),
                onClick: () => {
                  i(p), s(!1);
                },
                children: p
              },
              p
            )),
            !d.length && /* @__PURE__ */ e("p", { children: "没有匹配的选项" })
          ]
        }
      )
    ] })
  ] });
}
const mp = "https://go.r-l.ink/ico";
function ym({
  size: t = 32,
  decorative: n = !1
}) {
  return /* @__PURE__ */ e(
    "img",
    {
      src: mp,
      alt: n ? "" : "五加一",
      width: t,
      height: t,
      className: "fp-brand-logo"
    }
  );
}
function vm({ brand: t, identity: n, navigation: r, activeId: i, onNavigate: a, title: l, description: s, actions: c, footer: u, children: d }) {
  const [p, h] = k(!1), f = /* @__PURE__ */ e("nav", { className: "fp-account-nav", "aria-label": "账号功能", children: r.map((m) => /* @__PURE__ */ o("button", { type: "button", "aria-current": i === m.id ? "page" : void 0, onClick: () => {
    a(m.id), h(!1);
  }, children: [
    m.icon,
    /* @__PURE__ */ e("span", { children: m.label })
  ] }, m.id)) });
  return /* @__PURE__ */ o("div", { className: "fp-account-workspace", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#account-content", children: "跳到主要内容" }),
    /* @__PURE__ */ o("aside", { className: "fp-account-rail", children: [
      /* @__PURE__ */ e("div", { className: "fp-account-brand", children: t }),
      n && /* @__PURE__ */ e("div", { className: "fp-account-identity", children: n }),
      f,
      /* @__PURE__ */ e("div", { className: "fp-account-rail-footer", children: u })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-account-stage", children: [
      /* @__PURE__ */ o("header", { className: "fp-account-topbar", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e(te, { variant: "ghost", className: "fp-account-menu-button", "aria-label": "打开账号导航", onClick: () => h(!0), children: /* @__PURE__ */ e(un, { size: 20 }) }),
          /* @__PURE__ */ e("span", { children: "账号中心" }),
          /* @__PURE__ */ e(Ae, { size: 14 }),
          /* @__PURE__ */ e("strong", { children: l })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-account-topbar-actions", children: c })
      ] }),
      /* @__PURE__ */ o("main", { id: "account-content", className: "fp-account-page", children: [
        /* @__PURE__ */ o("header", { className: "fp-account-page-heading", children: [
          /* @__PURE__ */ e("h1", { children: l }),
          s && /* @__PURE__ */ e("p", { children: s })
        ] }),
        d
      ] })
    ] }),
    /* @__PURE__ */ o(Ye, { open: p, drawer: !0, title: "账号中心", onClose: () => h(!1), children: [
      n,
      f,
      u
    ] })
  ] });
}
function wm({ title: t, description: n, children: r, actions: i, className: a = "" }) {
  return /* @__PURE__ */ o("section", { className: "fp-account-panel " + a, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h2", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      i
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-account-panel-body", children: r })
  ] });
}
function km({ label: t, value: n, description: r, icon: i, action: a }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-setting", children: [
    i && /* @__PURE__ */ e("span", { className: "fp-account-setting-icon", children: i }),
    /* @__PURE__ */ o("div", { className: "fp-account-setting-copy", children: [
      /* @__PURE__ */ e("h3", { children: t }),
      n && /* @__PURE__ */ e("div", { className: "fp-account-setting-value", children: n }),
      r && /* @__PURE__ */ e("p", { children: r })
    ] }),
    a && /* @__PURE__ */ e("div", { className: "fp-account-setting-action", children: a })
  ] });
}
function Nr(t, n, r, i, a) {
  const l = Math.min(t, n) / Math.max(1, Math.min(4, r));
  return { x: (t - l) / 2 * (1 + Math.max(-1, Math.min(1, i))), y: (n - l) / 2 * (1 + Math.max(-1, Math.min(1, a))), size: l };
}
function Nm({ name: t, avatarUrl: n, onSave: r, onChooseLibrary: i, maxBytes: a = 5 * 1024 * 1024 }) {
  const [l, s] = k(!1), [c, u] = k(""), [d, p] = k(null), [h, f] = k(1), [m, b] = k({ x: 0, y: 0 }), [g, v] = k(""), [w, y] = k(!1), [N, x] = k(!1), C = R(null), z = R(null), L = R(null), j = R(void 0), M = R(!1);
  Y(() => {
    if (!c) {
      p(null);
      return;
    }
    const E = new Image();
    let S = !0;
    return x(!0), E.onload = () => {
      if (S) {
        if (E.naturalWidth * E.naturalHeight > 2e7) {
          v("图片尺寸过大，请选择较小的图片。"), x(!1);
          return;
        }
        p(E), x(!1);
      }
    }, E.onerror = () => {
      S && (v("无法读取这张图片，请重新选择。"), x(!1));
    }, E.src = c, () => {
      S = !1, URL.revokeObjectURL(c);
    };
  }, [c]), Y(() => {
    if (!d) return;
    const E = Nr(d.naturalWidth, d.naturalHeight, h, m.x, m.y);
    for (const S of [z.current, L.current]) {
      if (!S) continue;
      const P = S.getContext("2d");
      P?.clearRect(0, 0, S.width, S.height), P?.drawImage(d, E.x, E.y, E.size, E.size, 0, 0, S.width, S.height);
    }
  }, [d, h, m, l]);
  function A(E) {
    if (v(""), E.size > a) {
      v("图片大小请控制在 5 MB 以内。");
      return;
    }
    if (!["image/jpeg", "image/png", "image/webp"].includes(E.type)) {
      v("请选择 JPG、PNG 或 WebP 图片。");
      return;
    }
    p(null), f(1), b({ x: 0, y: 0 }), u(URL.createObjectURL(E));
  }
  function O(E) {
    if (w || !j.current || !d) return;
    const S = E.currentTarget.getBoundingClientRect(), P = Nr(d.naturalWidth, d.naturalHeight, h, 0, 0), _ = (E.clientX - j.current.x) / S.width * P.size, q = (E.clientY - j.current.y) / S.height * P.size;
    b({ x: Math.max(-1, Math.min(1, j.current.ox - (d.naturalWidth > P.size ? _ / ((d.naturalWidth - P.size) / 2) : 0))), y: Math.max(-1, Math.min(1, j.current.oy - (d.naturalHeight > P.size ? q / ((d.naturalHeight - P.size) / 2) : 0))) });
  }
  const U = () => {
    w || N || (s(!1), u(""), p(null), v(""));
  };
  async function T() {
    if (!(!d || M.current)) {
      M.current = !0, j.current = void 0, y(!0), v("");
      try {
        const E = document.createElement("canvas");
        E.width = E.height = 512;
        const S = Nr(d.naturalWidth, d.naturalHeight, h, m.x, m.y);
        E.getContext("2d").drawImage(d, S.x, S.y, S.size, S.size, 0, 0, 512, 512);
        const P = await new Promise((_, q) => E.toBlob((H) => H ? _(H) : q(new Error("图片处理失败，请重新选择。")), "image/webp", 0.9));
        await r(new File([P], "avatar.webp", { type: "image/webp" })), s(!1), u(""), p(null);
      } catch (E) {
        v(E instanceof Error ? E.message : "头像上传失败，请重试。");
      } finally {
        M.current = !1, y(!1);
      }
    }
  }
  return /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ o("div", { className: "fp-avatar-editor-summary", children: [
      /* @__PURE__ */ e("span", { className: "fp-avatar-editor-current", children: n ? /* @__PURE__ */ e("img", { src: n, alt: "当前头像" }) : /* @__PURE__ */ e("span", { "aria-hidden": "true", children: t.slice(0, 1) }) }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ o(te, { variant: "secondary", onClick: () => s(!0), children: [
          /* @__PURE__ */ e(So, { size: 16 }),
          "更换头像"
        ] }),
        /* @__PURE__ */ e("p", { children: "选择一张喜欢的图片作为头像。" })
      ] })
    ] }),
    /* @__PURE__ */ o(Ye, { open: l, title: c ? "调整头像" : "更换头像", className: "fp-avatar-editor-dialog", onClose: U, dismissible: !w && !N, footer: /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: w || N, onClick: U, children: "取消" }),
      c && /* @__PURE__ */ e(te, { loading: w, disabled: !d || N, onClick: () => {
        T();
      }, children: w ? "正在上传…" : "保存头像" })
    ] }), children: [
      /* @__PURE__ */ e("input", { ref: C, className: "fp-avatar-file", type: "file", accept: "image/jpeg,image/png,image/webp", "aria-label": "选择本地头像图片", disabled: w || N, onChange: (E) => {
        const S = E.target.files?.[0];
        E.target.value = "", S && A(S);
      } }),
      g && /* @__PURE__ */ e("p", { className: "fp-account-feedback", role: "alert", children: g }),
      c ? /* @__PURE__ */ o("div", { className: "fp-avatar-crop-layout", children: [
        /* @__PURE__ */ o("div", { className: "fp-avatar-crop-controls", children: [
          /* @__PURE__ */ o("div", { className: "fp-avatar-crop-stage", "aria-busy": w || N, children: [
            /* @__PURE__ */ e("canvas", { ref: z, width: 512, height: 512, tabIndex: w ? -1 : 0, role: "img", "aria-label": "头像裁切区域，拖动图片或使用方向键调整位置", onPointerDown: (E) => {
              w || (E.currentTarget.setPointerCapture(E.pointerId), j.current = { x: E.clientX, y: E.clientY, ox: m.x, oy: m.y });
            }, onPointerMove: O, onPointerUp: () => {
              j.current = void 0;
            }, onPointerCancel: () => {
              j.current = void 0;
            }, onKeyDown: (E) => {
              if (w) return;
              const S = E.shiftKey ? 0.1 : 0.025, P = E.key;
              ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(P) && (E.preventDefault(), b((_) => ({ x: Math.max(-1, Math.min(1, _.x + (P === "ArrowLeft" ? -S : P === "ArrowRight" ? S : 0))), y: Math.max(-1, Math.min(1, _.y + (P === "ArrowUp" ? -S : P === "ArrowDown" ? S : 0))) })));
            } }),
            /* @__PURE__ */ e("div", { className: "fp-avatar-crop-guide" }),
            (w || N) && /* @__PURE__ */ o("div", { className: "fp-avatar-upload-overlay", role: "status", children: [
              /* @__PURE__ */ e(ri, { size: 28 }),
              /* @__PURE__ */ e("strong", { children: w ? "正在上传头像…" : "正在读取图片…" })
            ] })
          ] }),
          /* @__PURE__ */ e("p", { children: "拖动图片调整位置，使用滑块缩放。" }),
          /* @__PURE__ */ o("label", { className: "fp-avatar-zoom", children: [
            /* @__PURE__ */ e(Hr, { size: 16 }),
            /* @__PURE__ */ e("input", { type: "range", "aria-label": "缩放头像", min: "1", max: "4", step: "0.01", value: h, disabled: w || N, onChange: (E) => f(Number(E.target.value)) }),
            /* @__PURE__ */ e(Kr, { size: 16 })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-avatar-crop-actions", children: [
            /* @__PURE__ */ e(te, { variant: "ghost", disabled: w || N, onClick: () => C.current?.click(), children: "重新选择" }),
            /* @__PURE__ */ o(te, { variant: "ghost", disabled: w || N, onClick: () => {
              f(1), b({ x: 0, y: 0 });
            }, children: [
              /* @__PURE__ */ e(tt, { size: 15 }),
              "重置"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ o("aside", { className: "fp-avatar-preview", children: [
          /* @__PURE__ */ e("p", { children: "头像预览" }),
          /* @__PURE__ */ e("canvas", { ref: L, width: 192, height: 192, "aria-label": "裁切后的圆形头像预览" }),
          /* @__PURE__ */ e("small", { children: "保存后将显示在你的五加一账号中" })
        ] })
      ] }) : /* @__PURE__ */ o("div", { className: "fp-avatar-sources", children: [
        /* @__PURE__ */ e("p", { children: "从设备上传，或使用五加一图床里的图片。" }),
        /* @__PURE__ */ o(te, { variant: "secondary", disabled: N, onClick: () => C.current?.click(), children: [
          /* @__PURE__ */ e(Mo, { size: 20 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "本地上传" }),
            /* @__PURE__ */ e("small", { children: "JPG、PNG、WebP · 最大 5 MB" })
          ] })
        ] }),
        i && /* @__PURE__ */ o(te, { variant: "secondary", loading: N, onClick: () => {
          x(!0), v(""), i().then((E) => {
            E && A(E);
          }).catch((E) => v(E instanceof Error ? E.message : "暂时无法打开图床，请重试。")).finally(() => x(!1));
        }, children: [
          /* @__PURE__ */ e(Eo, { size: 20 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "从五加一图床选择" }),
            /* @__PURE__ */ e("small", { children: "选择已有图片，也可以继续上传" })
          ] })
        ] })
      ] })
    ] })
  ] });
}
function xm({
  renderRow: t,
  items: n,
  selectedId: r,
  onSelect: i,
  defaultExpanded: a = [],
  expandedIds: l,
  onExpandedChange: s,
  onToggle: c,
  onPrefetch: u,
  onOpen: d,
  onMiddleClick: p,
  onNodeDragStart: h,
  onNodeDragOver: f,
  onNodeDrop: m,
  namespace: b = "files",
  onRename: g,
  onRemove: v,
  onCreate: w,
  label: y = "文件目录"
}) {
  let [N, x] = k(new Set(a));
  const C = l === void 0 ? N : new Set(l);
  let z = R(null);
  const L = R(null);
  let [j, M] = k(null), A = [];
  function O(P) {
    P.forEach((_) => {
      A.push(_), C.has(_.id) && _.children && O(_.children);
    });
  }
  O(n);
  function U(P) {
    const _ = new Set(C);
    _.has(P) ? _.delete(P) : _.add(P), l === void 0 && x(_), s?.([..._]), c?.(P, _.has(P));
  }
  function T(P) {
    M(P), requestAnimationFrame(
      () => z.current?.querySelector(`[data-node="${CSS.escape(P)}"]`)?.focus()
    );
  }
  function E(P, _) {
    let q = A.findIndex((H) => H.id === _.id);
    if ([
      "ArrowDown",
      "ArrowUp",
      "Home",
      "End",
      "ArrowRight",
      "ArrowLeft",
      "Enter",
      " "
    ].includes(P.key) && P.preventDefault(), P.key === "ArrowDown" && T(A[Math.min(A.length - 1, q + 1)].id), P.key === "ArrowUp" && T(A[Math.max(0, q - 1)].id), P.key === "Home" && T(A[0].id), P.key === "End" && T(A[A.length - 1].id), P.key === "ArrowRight" && _.kind === "folder" && (C.has(_.id) ? _.children?.[0] && T(_.children[0].id) : U(_.id)), P.key === "ArrowLeft")
      if (C.has(_.id)) U(_.id);
      else {
        let H = function($) {
          for (let B of $) {
            if (B.children?.some((Z) => Z.id === _.id)) return B;
            let J = B.children && H(B.children);
            if (J) return J;
          }
        }, I = H(n);
        I && T(I.id);
      }
    (P.key === "Enter" || P.key === " ") && (_.kind === "folder" ? U(_.id) : (i(_), d?.(_, P)));
  }
  function S(P, _ = 0, q = []) {
    return P.map((H) => /* @__PURE__ */ e(xt, { tabIndex: -1, label: `${H.name}的操作`, onOpen: (I) => {
      L.current = I;
    }, items: [
      { id: "open", label: H.kind === "folder" ? C.has(H.id) ? "收起文件夹" : "展开文件夹" : "打开", onSelect: () => {
        H.kind === "folder" ? U(H.id) : (i(H), L.current && d?.(H, L.current));
      } },
      ...H.kind === "folder" && w ? [{ id: "create", label: "新建文件", onSelect: () => w(H) }] : [],
      ...g ? [{ id: "rename", label: "重命名", onSelect: () => g(H) }] : [],
      ...v ? [{ id: "remove", label: "移除", danger: !0, separator: !0, onSelect: () => v(H) }] : []
    ], children: /* @__PURE__ */ o("div", { role: "none", children: [
      /* @__PURE__ */ e(bp, { node: H, renderRow: t, children: /* @__PURE__ */ o(
        "div",
        {
          role: "treeitem",
          "aria-label": H.name,
          "data-fp-tooltip": H.path || [...q, H.name].join(" / "),
          "aria-level": _ + 1,
          "aria-expanded": H.kind === "folder" ? C.has(H.id) : void 0,
          "aria-selected": r === H.id,
          tabIndex: (A.find((I) => I.id === j)?.id || A.find((I) => I.id === r)?.id || A[0]?.id) === H.id ? 0 : -1,
          "data-node": H.id,
          className: "fp-file-tree-row",
          style: { "--fp-tree-depth": Math.min(_, 4) },
          onFocus: (I) => {
            I.target === I.currentTarget && (M(H.id), u?.(H));
          },
          onMouseEnter: () => u?.(H),
          draggable: !!h,
          onDragStart: (I) => {
            h?.(H, I);
            const $ = document.createElement("div");
            $.className = "fp-file-drag-preview", $.textContent = H.name, document.body.appendChild($), I.dataTransfer.setDragImage?.($, 12, 18), setTimeout(() => $.remove(), 0);
          },
          onDragOver: m ? (I) => {
            f?.(H, I), !(f && !I.defaultPrevented) && (I.preventDefault(), I.stopPropagation(), I.currentTarget.dataset.dropTarget = "true");
          } : void 0,
          onDragLeave: (I) => {
            I.currentTarget.contains(I.relatedTarget) || delete I.currentTarget.dataset.dropTarget;
          },
          onDragEnd: () => z.current?.querySelectorAll("[data-drop-target]").forEach((I) => delete I.dataset.dropTarget),
          onDrop: m ? (I) => {
            I.preventDefault(), I.stopPropagation(), delete I.currentTarget.dataset.dropTarget, m(H, I);
          } : void 0,
          onAuxClick: (I) => {
            I.button === 1 && H.kind === "file" && p && (I.preventDefault(), p(H, I));
          },
          onKeyDown: (I) => E(I, H),
          onClick: (I) => {
            M(H.id), H.kind === "folder" ? U(H.id) : (i(H), d?.(H, I));
          },
          children: [
            H.kind === "folder" ? /* @__PURE__ */ o(ee, { children: [
              /* @__PURE__ */ e(
                Ae,
                {
                  size: 13,
                  className: C.has(H.id) ? "is-expanded" : ""
                }
              ),
              C.has(H.id) ? /* @__PURE__ */ e(ka, { size: 16 }) : /* @__PURE__ */ e(Ht, { size: 16 })
            ] }) : /* @__PURE__ */ o(ee, { children: [
              /* @__PURE__ */ e("span", { className: "fp-tree-chevron-space" }),
              /* @__PURE__ */ e(nt, { size: 16 })
            ] }),
            /* @__PURE__ */ e("span", { className: "fp-tree-name", children: H.name }),
            (g || v || H.kind === "folder" && w) && /* @__PURE__ */ e(
              "span",
              {
                onClick: (I) => I.stopPropagation(),
                onKeyDown: (I) => I.stopPropagation(),
                className: "fp-tree-actions",
                children: /* @__PURE__ */ e(
                  Pa,
                  {
                    label: "操作",
                    icon: /* @__PURE__ */ e(Kt, { size: 16, "aria-hidden": "true" }),
                    items: [
                      ...H.kind === "folder" && w ? [{ label: "新建文件", onClick: () => w(H) }] : [],
                      ...g ? [{ label: "重命名", onClick: () => g(H) }] : [],
                      ...v ? [
                        {
                          label: "移除",
                          danger: !0,
                          onClick: () => v(H)
                        }
                      ] : []
                    ]
                  }
                )
              }
            )
          ]
        }
      ) }),
      H.kind === "folder" && /* @__PURE__ */ e(je, { isOpen: C.has(H.id), children: /* @__PURE__ */ e("div", { role: "group", children: S(H.children || [], _ + 1, [...q, H.name]) }) })
    ] }) }, `${b}/${H.id}`));
  }
  return /* @__PURE__ */ o("div", { ref: z, className: "fp-file-tree", role: "tree", "aria-label": y, children: [
    S(n),
    !n.length && /* @__PURE__ */ e("p", { children: "还没有文件，添加资料后会显示在这里。" })
  ] });
}
function bp({ node: t, renderRow: n, children: r }) {
  return /* @__PURE__ */ e(ee, { children: n ? n(t, r) : r });
}
function gp({ label: t, onReset: n, className: r = "", onDoubleClick: i, onKeyDownCapture: a, ...l }) {
  const s = t + "；方向键微调" + (n ? "，双击或按 Home 恢复默认" : "");
  return /* @__PURE__ */ e(gn, { text: s, children: /* @__PURE__ */ e(Ts, { hitAreaMargins: { coarse: 0, fine: 5 }, ...l, "aria-label": t, className: `fp-workspace-divider ${r}`, onDoubleClick: (c) => {
    i?.(c), c.defaultPrevented || n?.();
  }, onKeyDownCapture: (c) => {
    a?.(c), !c.defaultPrevented && c.key === "Home" && n && (c.preventDefault(), c.stopPropagation(), n());
  } }) });
}
const Cm = Gl(function({ panels: n, direction: r = "horizontal", persistenceKey: i, onLayout: a, className: l = "" }, s) {
  const c = R(null), u = R(/* @__PURE__ */ new Map());
  return Yl(s, () => ({
    getLayout: () => c.current?.getLayout() || [],
    setLayout: (d) => c.current?.setLayout(d),
    collapse: (d) => u.current.get(d)?.collapse(),
    expand: (d) => u.current.get(d)?.expand(),
    resize: (d, p) => u.current.get(d)?.resize(p),
    isCollapsed: (d) => u.current.get(d)?.isCollapsed() || !1
  }), []), /* @__PURE__ */ e(Is, { ref: c, direction: r, autoSaveId: i, onLayout: a, className: `fp-workspace-layout ${l}`, children: n.map((d, p) => /* @__PURE__ */ o(Br, { children: [
    p > 0 && /* @__PURE__ */ e(gp, { label: `调整${n[p - 1].label}与${d.label}`, onReset: d.onResetBefore }),
    /* @__PURE__ */ e(
      Ds,
      {
        ref: (h) => {
          h ? u.current.set(d.id, h) : u.current.delete(d.id);
        },
        id: d.id,
        order: p,
        defaultSize: d.defaultSize,
        minSize: d.minSize ?? 10,
        maxSize: d.maxSize,
        collapsible: d.collapsible,
        collapsedSize: d.collapsedSize ?? 0,
        onCollapse: d.onCollapse,
        onExpand: d.onExpand,
        children: /* @__PURE__ */ e("section", { className: "fp-workspace-pane", "aria-label": d.label, children: d.content })
      }
    )
  ] }, d.id)) });
});
function Sm({
  url: t,
  room: n,
  token: r,
  user: i,
  enabled: a = !0
}) {
  let [l, s] = k(null), [c, u] = k("connecting");
  return Y(() => {
    if (!a) return;
    let d = new Fs.Doc(), p = new Ps({
      url: t,
      name: n,
      document: d,
      token: r,
      onStatus: ({ status: h }) => u(h),
      onAuthenticationFailed: () => u("unauthorized")
    });
    return p.setAwarenessField("user", i), s({ document: d, provider: p }), () => {
      s(null), p.destroy(), d.destroy();
    };
  }, [t, n, r, a, i.id, i.name, i.color]), { session: l, status: c };
}
function Mm({ user: t, status: n = "local", onChange: r, onMarkdownChange: i, ...a }) {
  const l = n === "local" ? "本地编辑" : n === "connected" ? "已连接" : n === "unauthorized" ? "需要重新登录" : n === "disconnected" ? "等待重新连接" : "正在连接";
  return /* @__PURE__ */ o("section", { className: "fp-collab-editor", children: [
    /* @__PURE__ */ o("header", { className: "fp-collab-presence", children: [
      /* @__PURE__ */ e("span", { style: { color: t.color }, children: "●" }),
      /* @__PURE__ */ e("span", { children: t.name }),
      /* @__PURE__ */ e("span", { children: a.editable === !1 ? "只读" : "可以编辑" }),
      /* @__PURE__ */ e("span", { role: "status", children: l })
    ] }),
    /* @__PURE__ */ e(lr, { ...a, user: t, onChange: (s, c) => {
      r?.(c), i?.(s);
    } })
  ] });
}
function Em({ messages: t, isLoading: n = !1, error: r, onClearError: i, onFollowUpClick: a, followUpQuestions: l = [], bottomInset: s = 0, renderMessage: c, emptyState: u, hydrated: d = !0, sessionId: p = "default", scrollContainerRef: h, hasOlder: f, loadingOlder: m, onLoadOlder: b, virtualize: g = t.length > 30, estimateSize: v = 100, footer: w, loadingIndicator: y, className: N = "", style: x }) {
  const C = R(null), z = h || C, L = R(null), j = R(!0), [M, A] = k(!1), O = R(/* @__PURE__ */ new Map()), U = R(p), T = R(null), E = R({ first: t[0]?.id, height: 0, top: 0 }), S = Ia({ count: t.length, getScrollElement: () => z.current, estimateSize: () => v, getItemKey: (q) => t[q].id, overscan: 5, enabled: g }), P = () => {
    const q = z.current;
    q && (q.scrollTop = q.scrollHeight, j.current = !0, A(!1));
  };
  xe(() => {
    const q = z.current;
    if (q) {
      if (U.current !== p) {
        const H = E.current;
        O.current.set(U.current, { top: H.top, pinned: j.current }), U.current = p, T.current = null, E.current = { first: t[0]?.id, height: 0, top: 0 };
      }
      if (d) {
        if (T.current !== p) {
          const H = O.current.get(p);
          j.current = H?.pinned ?? !0, q.scrollTop = j.current ? q.scrollHeight : H?.top || 0, T.current = p;
        } else E.current.first && t[0]?.id !== E.current.first && !j.current ? q.scrollTop = E.current.top + q.scrollHeight - E.current.height : j.current && (q.scrollTop = q.scrollHeight);
        E.current = { first: t[0]?.id, height: q.scrollHeight, top: q.scrollTop }, A(!j.current);
      }
    }
  }, [t, p, d, s, n]), xe(() => {
    const q = z.current, H = L.current;
    if (!q || !H || typeof ResizeObserver > "u") return;
    let I = 0;
    const $ = new ResizeObserver(() => {
      cancelAnimationFrame(I), I = requestAnimationFrame(() => {
        j.current && (q.scrollTop = q.scrollHeight), E.current.height = q.scrollHeight, E.current.top = q.scrollTop;
      });
    });
    return $.observe(H), $.observe(q), () => {
      $.disconnect(), cancelAnimationFrame(I);
    };
  }, [z]);
  const _ = (q) => c ? c(q) : /* @__PURE__ */ e(yp, { message: q });
  return /* @__PURE__ */ o("div", { className: `fp-message-list-container ${N}`, style: x, children: [
    /* @__PURE__ */ e(
      "div",
      {
        ref: z,
        className: "fp-message-list",
        role: "region",
        "aria-label": "对话记录",
        tabIndex: 0,
        onScroll: () => {
          const q = z.current;
          j.current = q.scrollHeight - q.scrollTop - q.clientHeight < 48, A(!j.current), E.current.top = q.scrollTop, E.current.height = q.scrollHeight, O.current.set(p, { top: q.scrollTop, pinned: j.current });
        },
        children: /* @__PURE__ */ o("div", { ref: L, className: "fp-message-list-content", style: { paddingBottom: Math.max(0, Number.isFinite(s) ? s : 0), overflowAnchor: "none" }, children: [
          f && /* @__PURE__ */ e("button", { type: "button", className: "fp-history-load", disabled: m, onClick: b, children: m ? "正在加载…" : "加载更早的消息" }),
          d ? t.length === 0 ? u : g ? /* @__PURE__ */ e("div", { style: { height: S.getTotalSize(), position: "relative" }, children: S.getVirtualItems().map((q) => /* @__PURE__ */ e("div", { "data-index": q.index, ref: S.measureElement, style: { position: "absolute", top: 0, left: 0, width: "100%", transform: `translateY(${q.start}px)` }, children: /* @__PURE__ */ e("div", { className: "fp-message-row", children: _(t[q.index]) }) }, q.key)) }) : t.map((q) => /* @__PURE__ */ e("div", { className: "fp-message-row", children: _(q) }, q.id)) : /* @__PURE__ */ e("p", { role: "status", children: "正在打开对话…" }),
          n && (y === void 0 ? /* @__PURE__ */ e("div", { className: "fp-message-loading", role: "status", children: "正在回复…" }) : y),
          w,
          l.length > 0 && /* @__PURE__ */ e("div", { className: "fp-follow-ups", "aria-label": "继续提问", children: l.map((q) => /* @__PURE__ */ e("button", { type: "button", onClick: () => a?.(q), children: q }, q)) })
        ] })
      }
    ),
    M && /* @__PURE__ */ o("button", { type: "button", className: "fp-message-latest", onClick: P, children: [
      /* @__PURE__ */ e(ha, { size: 14, "aria-hidden": "true" }),
      "回到最新"
    ] }),
    r && /* @__PURE__ */ o("div", { className: "fp-message-error", role: "alert", children: [
      /* @__PURE__ */ e("span", { children: r }),
      i && /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "关闭" })
    ] })
  ] });
}
function yp({ message: t }) {
  return /* @__PURE__ */ o("div", { className: `fp-message-bubble fp-message-${t.role}`, "data-role": t.role, children: [
    /* @__PURE__ */ e("div", { className: "fp-message-content", children: t.content }),
    t.timestamp && /* @__PURE__ */ e("time", { className: "fp-message-time", dateTime: t.timestamp.toISOString(), children: t.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) })
  ] });
}
function $m({
  inputProps: t,
  sendIcon: n,
  stopIcon: r,
  attachmentIcon: i,
  inputRef: a,
  value: l,
  onChange: s,
  onSend: c,
  onStop: u,
  isLoading: d,
  disabled: p,
  disabledReason: h,
  placeholder: f = "输入问题，或添加资料…",
  quotedText: m,
  onClearQuote: b,
  attachments: g = [],
  onRemoveAttachment: v,
  onFiles: w,
  onAttach: y,
  accept: N,
  tools: x,
  footer: C,
  compact: z = !1,
  collapsible: L = !1,
  notice: j,
  onComposerInsetChange: M,
  sendOnEnter: A = !0
}) {
  const O = R(null), U = R(null), T = R(null), E = R(!1), S = R(!1), [P, _] = k(!1), [q, H] = k(""), [I, $] = k(!1), [B, J] = k(!1), Z = R(!1);
  xe(() => {
    !B && Z.current && (Z.current = !1, U.current?.focus());
  }, [B]);
  const pe = !p && !(d || P) && !g.some(
    (K) => K.status === "uploading" || K.status === "error"
  ) && (!!l.trim() || g.length > 0);
  xe(() => {
    const K = U.current;
    if (!K) return;
    let re = 0, le = -1;
    const fe = () => {
      if (cancelAnimationFrame(re), !K.getBoundingClientRect().width) return;
      const W = K.cloneNode(!1);
      W.removeAttribute("id"), W.removeAttribute("aria-label"), W.removeAttribute("placeholder"), W.setAttribute("aria-hidden", "true"), W.tabIndex = -1, W.value = l, Object.assign(W.style, {
        position: "absolute",
        visibility: "hidden",
        pointerEvents: "none",
        height: "0px",
        minHeight: "0px",
        width: `${K.getBoundingClientRect().width}px`,
        transition: "none"
      }), W.style.setProperty("min-height", "0px", "important"), W.style.setProperty("max-height", "none", "important"), W.style.setProperty("height", "0px", "important"), K.parentElement?.append(W);
      const F = getComputedStyle(K), D = parseFloat(F.minHeight) || (z ? 40 : 48), G = parseFloat(F.maxHeight) || 200, de = (parseFloat(F.borderTopWidth) || 0) + (parseFloat(F.borderBottomWidth) || 0), me = Math.min(G, Math.max(D, W.scrollHeight + de));
      W.remove(), K.style.height = `${me}px`;
    }, se = () => {
      cancelAnimationFrame(re), re = requestAnimationFrame(fe);
    };
    fe();
    const we = typeof ResizeObserver > "u" ? null : new ResizeObserver((W) => {
      const F = W[0]?.contentRect.width;
      F !== le && (le = F, se());
    });
    return we?.observe(K), window.addEventListener("resize", se), window.visualViewport?.addEventListener("resize", se), () => {
      we?.disconnect(), cancelAnimationFrame(re), window.removeEventListener("resize", se), window.visualViewport?.removeEventListener("resize", se);
    };
  }, [l, z]), xe(() => {
    const K = O.current?.querySelector(".fp-composer-actions"), re = K?.querySelector(".fp-composer-inline-footer");
    if (!z || !K || !re) {
      $(!1);
      return;
    }
    let le = 0;
    const fe = () => {
      const W = re.cloneNode(!0);
      W.classList.add("fp-composer-footer-measure"), W.setAttribute("aria-hidden", "true"), W.inert = !0, K.append(W);
      const F = W.getBoundingClientRect().width;
      W.remove();
      const D = K.querySelector(".fp-composer-tools")?.getBoundingClientRect().width || 0, G = K.querySelector(".fp-composer-send")?.getBoundingClientRect().width || 0;
      $(F + D + G + 12 > K.clientWidth);
    }, se = () => {
      cancelAnimationFrame(le), le = requestAnimationFrame(fe);
    };
    fe();
    const we = typeof ResizeObserver > "u" ? null : new ResizeObserver(se);
    return we?.observe(K), we?.observe(re), () => {
      we?.disconnect(), cancelAnimationFrame(le);
    };
  }, [z, C, x]), xe(() => {
    if (!O.current || !M) return;
    const K = () => M(O.current?.getBoundingClientRect().height || 0);
    K();
    const re = typeof ResizeObserver > "u" ? null : new ResizeObserver(K);
    return re?.observe(O.current), () => {
      re?.disconnect(), M(0);
    };
  }, [M]);
  async function V() {
    if (!(!pe || S.current)) {
      S.current = !0, _(!0), H("");
      try {
        await c(l.trim());
      } catch (K) {
        H(K instanceof Error ? K.message : "发送失败，请重试");
      } finally {
        S.current = !1, _(!1);
      }
    }
  }
  return /* @__PURE__ */ o("div", { ref: O, className: "fp-chat-composer-wrap", "data-collapsed": B || void 0, children: [
    j && /* @__PURE__ */ e("div", { className: "fp-composer-notices", hidden: L && B, children: j }),
    L && B && /* @__PURE__ */ o("div", { className: "fp-composer-collapsed-bar", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-composer-expand", "aria-label": "展开输入框", onClick: () => {
        Z.current = !0, J(!1);
      }, children: [
        /* @__PURE__ */ e("span", { children: l.trim() ? "继续编辑" : "输入消息" }),
        l.trim() && /* @__PURE__ */ e("small", { children: l.trim() }),
        g.length > 0 && /* @__PURE__ */ o("small", { children: [
          g.length,
          " 个附件"
        ] }),
        /* @__PURE__ */ e($o, { size: 16, "aria-hidden": "true" })
      ] }),
      d && u && /* @__PURE__ */ e("button", { type: "button", className: "fp-composer-send", "aria-label": "停止回复", onClick: u, children: r || /* @__PURE__ */ e(pn, { size: 14 }) })
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: `fp-chat-composer${z ? " fp-composer-compact" : ""}`,
        "data-footer-wrapped": I || void 0,
        "data-collapsible": L || void 0,
        hidden: L && B,
        "data-disabled": p || void 0,
        onDragOver: (K) => {
          w && !p && K.preventDefault();
        },
        onDrop: (K) => {
          w && !p && K.dataTransfer.files.length && (K.preventDefault(), w(Array.from(K.dataTransfer.files)));
        },
        children: [
          m && /* @__PURE__ */ o("div", { className: "fp-composer-quote", children: [
            /* @__PURE__ */ e(fa, { size: 14, "aria-hidden": "true" }),
            /* @__PURE__ */ e("span", { children: m }),
            b && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "移除引用",
                onClick: b,
                children: /* @__PURE__ */ e(ke, { size: 14 })
              }
            )
          ] }),
          g.length > 0 && /* @__PURE__ */ e("ul", { className: "fp-composer-attachments", "aria-label": "已添加的附件", children: g.map((K) => /* @__PURE__ */ o("li", { "data-status": K.status, children: [
            K.previewUrl ? /* @__PURE__ */ e("img", { src: K.previewUrl, alt: "" }) : K.status === "uploading" ? /* @__PURE__ */ e(Ut, { size: 16, className: "fp-spin" }) : /* @__PURE__ */ e(nt, { size: 16 }),
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e("span", { children: K.name }),
              K.status === "uploading" && /* @__PURE__ */ e("small", { children: "正在上传" }),
              K.status === "error" && /* @__PURE__ */ e("small", { role: "alert", children: K.error || "上传失败，请重新添加" })
            ] }),
            v && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": `移除${K.name}`,
                onClick: () => v(K.id),
                children: /* @__PURE__ */ e(ke, { size: 14 })
              }
            )
          ] }, K.id)) }),
          /* @__PURE__ */ o("div", { className: "fp-composer-input-row", children: [
            /* @__PURE__ */ e(
              "textarea",
              {
                ...t,
                ref: (K) => {
                  U.current = K, typeof a == "function" ? a(K) : a && (a.current = K);
                },
                value: l,
                disabled: p,
                "aria-label": "消息",
                placeholder: h || f,
                rows: z ? 1 : 2,
                onChange: (K) => s(K.target.value),
                onCompositionStart: () => {
                  E.current = !0;
                },
                onCompositionEnd: () => {
                  E.current = !1;
                },
                onPaste: (K) => {
                  if (t?.onPaste?.(K), K.defaultPrevented) return;
                  const re = Array.from(K.clipboardData?.files || []);
                  re.length && w && !p && (K.preventDefault(), w(re));
                },
                onKeyDown: (K) => {
                  K.key === "Enter" && !K.shiftKey && !E.current && !K.nativeEvent.isComposing && K.keyCode !== 229 && (A || K.ctrlKey || K.metaKey) && (K.preventDefault(), V());
                }
              }
            ),
            L && /* @__PURE__ */ o("button", { type: "button", className: "fp-composer-collapse", "aria-label": "收起输入框", "data-fp-tooltip": "收起输入框", onPointerDown: (K) => K.preventDefault(), onClick: () => {
              J(!0), U.current?.blur();
            }, children: [
              /* @__PURE__ */ e("span", { children: "收起" }),
              /* @__PURE__ */ e(St, { size: 14, "aria-hidden": "true" })
            ] })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-composer-actions", children: [
            /* @__PURE__ */ o("div", { className: "fp-composer-tools", children: [
              (w || y) && /* @__PURE__ */ o(ee, { children: [
                /* @__PURE__ */ e(
                  "input",
                  {
                    ref: T,
                    type: "file",
                    multiple: !0,
                    accept: N,
                    hidden: !0,
                    onChange: (K) => {
                      const re = Array.from(K.target.files || []);
                      re.length && w?.(re), K.target.value = "";
                    }
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-composer-icon",
                    "aria-label": "添加附件",
                    "data-fp-tooltip": "添加附件",
                    disabled: p,
                    onClick: () => y ? y() : T.current?.click(),
                    children: i || /* @__PURE__ */ e(Sr, { size: 17 })
                  }
                )
              ] }),
              x
            ] }),
            z && C && /* @__PURE__ */ e("div", { className: "fp-composer-inline-footer", children: C }),
            d && u ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "停止回复",
                "data-fp-tooltip": "停止回复",
                onClick: u,
                children: r || /* @__PURE__ */ e(pn, { size: 14, fill: "currentColor" })
              }
            ) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "发送消息",
                "data-fp-tooltip": A ? "发送消息 · Enter" : "发送消息 · Ctrl/⌘+Enter",
                disabled: !pe,
                onClick: () => {
                  V();
                },
                children: P ? /* @__PURE__ */ e(Ut, { size: 16, className: "fp-spin" }) : n || /* @__PURE__ */ e(Vr, { size: 18 })
              }
            )
          ] }),
          !z && C && /* @__PURE__ */ e("div", { className: "fp-composer-footer", children: C })
        ]
      }
    ),
    (q || h) && /* @__PURE__ */ e(
      "p",
      {
        className: q ? "fp-error-text" : "fp-composer-hint",
        role: q ? "alert" : void 0,
        children: q || h
      }
    )
  ] });
}
function zm(t) {
  let n = "", r = 0;
  return t.split(`
`).map((i) => {
    const a = i.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
    if (a) {
      const s = a[1];
      return n ? s[0] === n && s.length >= r && !a[2].trim() && (n = "") : (n = s[0], r = s.length), i;
    }
    if (n || /^(?: {4}|\t)/.test(i)) return i;
    const l = i.match(/^( {0,3})(:{3,})([\w-]+)[ \t]+(\S.*)$/);
    return l && ec.has(Ai(l[3])) && (i = `${l[1]}${l[2]}${Ai(l[3])}
${l[1]}${l[4]}`), i.split(/(`+[^`]*`+)/g).map((s) => s.startsWith("`") ? s : s.replace(
      /(^|[^\\])\*\*([“‘「『《])([^\n]+?)([”’」』》])\*\*/g,
      (c, u, d, p, h) => `${u}${d}**${p}**${h}`
    )).join("");
  }).join(`
`);
}
function vp({ members: t, roles: n, canManage: r = !1, busyIds: i = [], onRoleChange: a, onRemove: l, onInvite: s, defaultInviteRole: c, error: u }) {
  const [d, p] = k(""), [h, f] = k(c || n[0]?.value || ""), [m, b] = k(!1), [g, v] = k(""), [w, y] = k(""), N = R(!1), x = ve();
  return /* @__PURE__ */ o("section", { className: "fp-member-access", "aria-label": "成员与访问权限", children: [
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ e("ul", { className: "fp-access-members", children: t.map((C) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-access-avatar", "aria-hidden": "true", children: /* @__PURE__ */ e(kn, { name: C.name, src: C.avatarUrl, size: 32 }) }),
      /* @__PURE__ */ o("span", { className: "fp-access-identity", children: [
        /* @__PURE__ */ e("strong", { children: C.name }),
        C.detail && /* @__PURE__ */ e("small", { children: C.detail })
      ] }),
      r && C.editable !== !1 && a ? /* @__PURE__ */ e(Ce, { label: `${C.name}的权限`, value: C.role, disabled: i.includes(C.id), onChange: (z) => a(C.id, z), options: n }) : /* @__PURE__ */ e("span", { className: "fp-access-role", children: n.find((z) => z.value === C.role)?.label || C.role }),
      r && C.editable !== !1 && l && /* @__PURE__ */ e("button", { type: "button", className: "fp-access-remove", "aria-label": `移除${C.name}`, disabled: i.includes(C.id), onClick: () => l(C.id), children: /* @__PURE__ */ e(ke, { size: 15 }) })
    ] }, C.id)) }) }),
    !t.length && /* @__PURE__ */ e("p", { className: "fp-access-help", children: "还没有其他成员。" }),
    r && s && /* @__PURE__ */ o("form", { className: "fp-access-invite", onSubmit: async (C) => {
      if (C.preventDefault(), !(N.current || !d.trim() || !h)) {
        N.current = !0, b(!0), v(""), y("");
        try {
          await s(d.trim(), h), p(""), v("邀请已发送");
        } catch (z) {
          y(z instanceof Error ? z.message : "邀请未能发送，请重试");
        } finally {
          N.current = !1, b(!1);
        }
      }
    }, children: [
      /* @__PURE__ */ e("label", { htmlFor: x, children: "邀请成员" }),
      /* @__PURE__ */ o("div", { className: "fp-access-invite-fields", children: [
        /* @__PURE__ */ e("input", { id: x, type: "email", required: !0, placeholder: "输入邮箱地址", value: d, disabled: m, onChange: (C) => p(C.target.value) }),
        /* @__PURE__ */ e(Ce, { label: "邀请权限", value: h, disabled: m, onChange: f, options: n }),
        /* @__PURE__ */ o("button", { type: "submit", disabled: m || !d.trim() || !h, children: [
          /* @__PURE__ */ e(zo, { size: 15, "aria-hidden": "true" }),
          m ? "正在邀请…" : "邀请"
        ] })
      ] }),
      n.find((C) => C.value === h)?.description && /* @__PURE__ */ e("p", { className: "fp-access-help", children: n.find((C) => C.value === h)?.description }),
      g && /* @__PURE__ */ e("p", { className: "fp-access-help", role: "status", children: g })
    ] }),
    (u || w) && /* @__PURE__ */ e("p", { className: "fp-error-text", role: "alert", children: u || w })
  ] });
}
function wp({ onSearch: t, onPick: n, disabled: r, excludedIds: i = [], debounceMs: a = 250, onQueryChange: l }) {
  const [s, c] = k("user"), [u, d] = k(""), [p, h] = k([]), [f, m] = k(!1), [b, g] = k(0), [v, w] = k("idle"), [y, N] = k(""), x = R(null), C = R(null), z = R(null), L = R(t);
  L.current = t;
  const j = Zn(), M = Xt(C, f), A = ve(), [O, U] = k({ left: 8, top: 8, width: 300, maxHeight: 280 }), T = p.filter((S) => !i.includes(S.id));
  Y(() => {
    f && z.current?.querySelector(`[id="${A}-${b}"]`)?.scrollIntoView?.({ block: "nearest" });
  }, [b, f, A]), Y(() => {
    const S = new AbortController();
    if (h([]), g(0), N(""), !u.trim() || r) {
      w("idle");
      return;
    }
    w("loading");
    const P = setTimeout(async () => {
      try {
        const _ = await L.current(u.trim(), s, S.signal);
        S.signal.aborted || (h(_), w("ready"));
      } catch {
        S.signal.aborted || (N("暂时无法查找成员，请重试"), w("error"));
      }
    }, a);
    return () => {
      clearTimeout(P), S.abort();
    };
  }, [u, s, r, a]), xe(() => {
    if (!f) return;
    const S = () => {
      const _ = C.current?.getBoundingClientRect();
      if (!_) return;
      const q = window.innerHeight - _.bottom - 16, H = Math.min(280, Math.max(100, q < 160 ? _.top - 16 : q));
      U({ left: Math.max(8, Math.min(_.left, window.innerWidth - _.width - 8)), top: q < 160 ? Math.max(8, _.top - H - 6) : _.bottom + 6, width: Math.min(_.width, window.innerWidth - 16), maxHeight: H });
    }, P = (_) => {
      const q = _.target;
      !x.current?.contains(q) && !z.current?.contains(q) && m(!1);
    };
    return S(), document.addEventListener("pointerdown", P, !0), document.addEventListener("focusin", P, !0), window.addEventListener("resize", S), window.addEventListener("scroll", S, !0), () => {
      document.removeEventListener("pointerdown", P, !0), document.removeEventListener("focusin", P, !0), window.removeEventListener("resize", S), window.removeEventListener("scroll", S, !0);
    };
  }, [f]);
  const E = (S) => {
    S.disabled || (n(S, s), d(""), m(!1), C.current?.focus());
  };
  return /* @__PURE__ */ o("div", { className: "fp-member-search", ref: x, children: [
    /* @__PURE__ */ e("div", { className: "fp-member-search-kind", "aria-label": "搜索范围", children: ["user", "group"].map((S) => /* @__PURE__ */ o("button", { type: "button", disabled: r, "aria-pressed": s === S, onClick: () => {
      l?.("", S), c(S), d(""), m(!1), C.current?.focus();
    }, children: [
      s === S && /* @__PURE__ */ e(er.span, { className: "fp-choice-highlight", layoutId: `${A}-kind`, transition: { duration: j ? 0 : 0.18, ease: [0.2, 0, 0, 1] }, "aria-hidden": "true" }),
      S === "user" ? /* @__PURE__ */ e(Ao, { size: 14 }) : /* @__PURE__ */ e(In, { size: 14 }),
      /* @__PURE__ */ e("span", { children: S === "user" ? "用户" : "用户组" })
    ] }, S)) }),
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(Ue, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { ref: C, role: "combobox", "aria-label": "搜索成员", "aria-autocomplete": "list", "aria-expanded": f && !!u.trim(), "aria-controls": f && u.trim() ? A : void 0, "aria-activedescendant": f && T[b] ? `${A}-${b}` : void 0, disabled: r, placeholder: s === "user" ? "搜索姓名、账号或邮箱" : "搜索用户组名称", value: u, onFocus: () => m(!0), onChange: (S) => {
        l?.(S.target.value, s), d(S.target.value), m(!0);
      }, onKeyDown: (S) => {
        if (!S.nativeEvent.isComposing && (S.key === "Escape" && (S.preventDefault(), S.stopPropagation(), m(!1)), (S.key === "ArrowDown" || S.key === "ArrowUp") && (S.preventDefault(), m(!0), g((P) => {
          const _ = S.key === "ArrowDown" ? 1 : -1;
          let q = P + _;
          for (; q >= 0 && q < T.length && T[q].disabled; ) q += _;
          return q >= 0 && q < T.length ? q : P;
        })), S.key === "Enter" && f)) {
          S.preventDefault();
          const P = T[b];
          P && E(P);
        }
      } }),
      v === "loading" && /* @__PURE__ */ e(Ut, { size: 15, className: "fp-spin", "aria-hidden": "true" })
    ] }),
    f && !r && u.trim() && Oe(/* @__PURE__ */ o("div", { ref: z, "data-fp-overlay": "", className: "fp-member-results fp-popup-panel", id: A, role: "listbox", "aria-label": "匹配成员", style: { ...M, position: "fixed", ...O, overflowY: "auto" }, children: [
      v === "loading" && /* @__PURE__ */ e("p", { role: "status", children: "正在查找…" }),
      v === "error" && /* @__PURE__ */ e("p", { role: "alert", children: y }),
      v === "ready" && !T.length && /* @__PURE__ */ e("p", { role: "status", children: "没有可添加的匹配成员" }),
      T.map((S, P) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": P === b, id: `${A}-${P}`, disabled: S.disabled, onMouseEnter: () => g(P), onMouseDown: (_) => _.preventDefault(), onClick: () => E(S), children: [
        /* @__PURE__ */ e("span", { className: "fp-member-result-avatar", "aria-hidden": "true", children: /* @__PURE__ */ e(kn, { name: S.name, src: S.avatarUrl, size: 32 }) }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: S.name }),
          S.detail && /* @__PURE__ */ e("small", { children: S.detail })
        ] }),
        /* @__PURE__ */ e("span", { className: "fp-member-result-action", children: "添加" })
      ] }, S.id))
    ] }), C.current?.closest("[data-fp-overlay],[role=dialog],dialog") || document.body)
  ] });
}
function kp({ url: t, enabled: n, onEnabledChange: r, access: i, onAccessChange: a, options: l = [{ value: "read", label: "可以阅读" }, { value: "edit", label: "可以编辑" }], disabled: s, onCopy: c }) {
  const [u, d] = k(!1), [p, h] = k(!1), [f, m] = k(""), b = R(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-link", "aria-label": "链接分享", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e(ft, { size: 17 }),
        /* @__PURE__ */ e("strong", { children: "链接分享" })
      ] }),
      /* @__PURE__ */ e("button", { type: "button", role: "switch", "aria-checked": n, "aria-label": "开启链接分享", disabled: s || u, onClick: async () => {
        if (!b.current) {
          b.current = !0, d(!0), m("");
          try {
            await r(!n);
          } catch {
            m("分享设置未能保存，请重试");
          } finally {
            b.current = !1, d(!1);
          }
        }
      }, children: /* @__PURE__ */ e("span", { className: `fp-switch ${n ? "is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) }) })
    ] }),
    /* @__PURE__ */ e("p", { children: n ? "拥有链接的人可以按以下权限访问。" : "开启后可通过链接邀请他人访问。" }),
    /* @__PURE__ */ e(je, { isOpen: n, children: /* @__PURE__ */ o("div", { className: "fp-share-link-controls", children: [
      /* @__PURE__ */ e(Ce, { label: "链接访问权限", value: i, onChange: a, options: l, disabled: s || u }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary fp-sm", disabled: s || !t, onClick: async () => {
        if (t)
          try {
            c ? await c(t) : await navigator.clipboard.writeText(t), h(!0), m("");
          } catch {
            m("未能复制链接，请重试");
          }
      }, children: [
        p ? /* @__PURE__ */ e(Ie, { size: 14 }) : /* @__PURE__ */ e(vn, { size: 14 }),
        "复制链接"
      ] })
    ] }) }),
    p && /* @__PURE__ */ e("span", { role: "status", className: "fp-sr-only", children: "链接已复制" }),
    f && /* @__PURE__ */ e("p", { role: "alert", children: f })
  ] });
}
function Am({ items: t, selectedIds: n, onChange: r, onConfirm: i, loading: a, error: l, onSearch: s, onLoadMore: c, hasMore: u }) {
  const [d, p] = k(""), [h, f] = k(!1), [m, b] = k(""), g = R(!1), v = s ? t : t.filter((w) => w.name.toLowerCase().includes(d.trim().toLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-attachment-picker", "aria-label": "选择资料", children: [
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(Ue, { size: 16 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索资料", placeholder: "搜索资料名称", value: d, onChange: (w) => {
        p(w.target.value), s?.(w.target.value);
      } })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-attachment-picker-list", "aria-busy": a, children: [
      v.map((w) => /* @__PURE__ */ o("button", { type: "button", role: "checkbox", "aria-checked": n.includes(w.id), disabled: w.disabled || h, onClick: () => r(n.includes(w.id) ? n.filter((y) => y !== w.id) : [...n, w.id]), children: [
        /* @__PURE__ */ e("span", { className: "fp-picker-check", children: n.includes(w.id) && /* @__PURE__ */ e(Ie, { size: 13 }) }),
        /* @__PURE__ */ e(nt, { size: 18 }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: w.name }),
          w.detail && /* @__PURE__ */ e("small", { children: w.detail })
        ] })
      ] }, w.id)),
      a && /* @__PURE__ */ e("p", { role: "status", children: "正在查找资料…" }),
      !a && !v.length && /* @__PURE__ */ e("p", { children: "没有匹配的资料" }),
      u && c && /* @__PURE__ */ e("button", { type: "button", className: "fp-picker-load", disabled: a || h, onClick: c, children: "加载更多" })
    ] }),
    (l || m) && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: l || m }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ o("span", { children: [
        "已选择 ",
        n.length,
        " 项资料"
      ] }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-primary fp-sm", disabled: h || !n.length, onClick: async () => {
        if (!g.current) {
          g.current = !0, f(!0), b("");
          try {
            await i(n);
          } catch {
            b("未能添加资料，请重试");
          } finally {
            g.current = !1, f(!1);
          }
        }
      }, children: h ? "正在添加…" : "添加资料" })
    ] })
  ] });
}
function Lm({ tasks: t, onCancel: n, onRetry: r, onDismiss: i }) {
  return /* @__PURE__ */ e("section", { className: "fp-upload-queue", "aria-label": "上传资料", children: t.length ? /* @__PURE__ */ e("ul", { children: t.map((a) => /* @__PURE__ */ o("li", { "data-status": a.status, children: [
    /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: a.status === "done" ? /* @__PURE__ */ e(Ie, { size: 17 }) : /* @__PURE__ */ e(nt, { size: 17 }) }),
    /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
      /* @__PURE__ */ e("strong", { children: a.name }),
      /* @__PURE__ */ e("span", { children: a.status === "error" ? a.error || "上传失败，请重试" : a.status === "done" ? "已添加" : a.status === "processing" ? "正在整理资料" : a.status === "waiting" ? "等待上传" : `正在上传 ${Math.round(Math.max(0, Math.min(100, a.progress || 0)))}%` }),
      a.status === "uploading" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${a.name}上传进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(Math.max(0, Math.min(100, a.progress || 0))), className: "fp-upload-progress", children: /* @__PURE__ */ e("i", { style: { width: `${Math.max(0, Math.min(100, a.progress || 0))}%` } }) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
      a.status === "error" && r && /* @__PURE__ */ e("button", { type: "button", "aria-label": `重试${a.name}`, onClick: () => r(a.id), children: /* @__PURE__ */ e(Na, { size: 15 }) }),
      ["waiting", "uploading", "processing"].includes(a.status) && n && /* @__PURE__ */ e("button", { type: "button", "aria-label": `取消上传${a.name}`, onClick: () => n(a.id), children: /* @__PURE__ */ e(ke, { size: 15 }) }),
      ["done", "error"].includes(a.status) && i && /* @__PURE__ */ e("button", { type: "button", "aria-label": `移除记录${a.name}`, onClick: () => i(a.id), children: /* @__PURE__ */ e(ke, { size: 15 }) })
    ] })
  ] }, a.id)) }) : /* @__PURE__ */ e("p", { className: "fp-muted", children: "还没有上传任务" }) });
}
function Im({ editor: t, toolbar: n, children: r, className: i = "", contextMenu: a = !0 }) {
  const l = /* @__PURE__ */ e(Ea, { editor: t });
  return /* @__PURE__ */ o("section", { className: `fp-markdown-editor fp-markdown-editor-surface ${i}`, "data-readonly": t && !t.isEditable || void 0, children: [
    n,
    a ? /* @__PURE__ */ e(cl, { editor: t, children: l }) : l,
    r
  ] });
}
function Dm({ className: t = "", ...n }) {
  return /* @__PURE__ */ e("div", { ...n, className: `fp-conversation-viewport ${t}` });
}
const Np = {
  pending: /* @__PURE__ */ e(xa, { size: 14 }),
  running: /* @__PURE__ */ e(Lo, { size: 14, className: "fp-spin" }),
  done: /* @__PURE__ */ e(Ie, { size: 14 }),
  error: /* @__PURE__ */ e(Gr, { size: 14 })
};
function Tm({
  steps: t,
  streaming: n = !1,
  durationMs: r,
  defaultOpen: i = !0,
  title: a = "思考过程"
}) {
  const [l, s] = k(i || n), c = t.filter((d) => d.status === "done").length, u = t.some((d) => d.status === "error");
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-trace",
      "data-streaming": n || void 0,
      "aria-label": a,
      children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-trace-head",
            "aria-expanded": l,
            onClick: () => s((d) => !d),
            children: [
              /* @__PURE__ */ e(Ae, { size: 15, className: "fp-trace-chevron" }),
              /* @__PURE__ */ e("strong", { children: a }),
              /* @__PURE__ */ o("span", { className: "fp-trace-summary", children: [
                u ? "有步骤失败" : n ? "进行中" : `${c} / ${t.length} 步`,
                r ? ` · ${(r / 1e3).toFixed(1)}s` : ""
              ] })
            ]
          }
        ),
        /* @__PURE__ */ e("div", { className: "fp-trace-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("ol", { className: "fp-trace-steps", children: t.map((d) => /* @__PURE__ */ o("li", { "data-status": d.status, children: [
          /* @__PURE__ */ e("span", { className: "fp-trace-icon", "aria-hidden": "true", children: Np[d.status] }),
          /* @__PURE__ */ o("div", { className: "fp-trace-content", children: [
            /* @__PURE__ */ o("div", { className: "fp-trace-title", children: [
              d.title,
              d.meta && /* @__PURE__ */ e("span", { className: "fp-trace-meta", children: d.meta })
            ] }),
            d.detail && /* @__PURE__ */ e("p", { className: "fp-trace-detail fp-trace-commentary", children: d.detail })
          ] })
        ] }, d.id)) }) })
      ]
    }
  );
}
const xp = {
  excerpt: ["摘录 · 原文", "回顾 · 要点"],
  cloze: ["填空 · 回忆内容", "答案"],
  quiz: ["题目 · 先思考", "参考答案"],
  custom: ["正面", "背面"],
  qa: ["问题", "答案"]
};
function Pm({
  kind: t = "qa",
  front: n,
  back: r,
  flipped: i,
  onFlip: a,
  explanation: l,
  className: s
}) {
  const c = ve(), [u, d] = xp[t];
  return /* @__PURE__ */ o("div", { className: `fp-flip ${s || ""}`, "data-flipped": i || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-flip-stage",
        onClick: a,
        "aria-pressed": i,
        "aria-describedby": c,
        "aria-label": i ? "翻回正面" : "翻开背面",
        children: [
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-front", "aria-hidden": i, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: u }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: n }),
            /* @__PURE__ */ e("span", { className: "fp-flip-hint", children: "点击翻面" })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-back", "aria-hidden": !i, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: d }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: r }),
            l && /* @__PURE__ */ e("p", { className: "fp-flip-explanation", children: l })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ o("span", { id: c, className: "fp-sr-only", children: [
      "按下空格或回车翻面，当前显示",
      i ? d : u,
      "。"
    ] })
  ] });
}
function Fm({
  anchor: t,
  actions: n,
  onClose: r,
  preview: i
}) {
  const a = R(null), [l, s] = k(null);
  return xe(() => {
    if (!t || !a.current) {
      s(null);
      return;
    }
    const c = a.current.getBoundingClientRect(), u = Math.max(
      8,
      Math.min(t.x - c.width / 2, window.innerWidth - c.width - 8)
    ), d = t.y - c.height - 8, p = d > 8 ? d : t.y + 12;
    s({ left: u, top: p });
  }, [t]), Y(() => {
    if (!t) return;
    const c = (d) => {
      d.key === "Escape" && r();
    }, u = (d) => {
      a.current?.contains(d.target) || r();
    };
    return document.addEventListener("keydown", c), document.addEventListener("pointerdown", u, !0), () => {
      document.removeEventListener("keydown", c), document.removeEventListener("pointerdown", u, !0);
    };
  }, [t, r]), !t || typeof window > "u" ? null : Oe(
    /* @__PURE__ */ o(
      "div",
      {
        ref: a,
        className: "fp-selection-toolbar",
        role: "toolbar",
        "aria-label": "选区操作",
        style: {
          left: l?.left ?? t.x,
          top: l?.top ?? t.y - 44,
          visibility: l ? "visible" : "hidden"
        },
        children: [
          i && /* @__PURE__ */ o("span", { className: "fp-selection-preview", title: i, children: [
            i.slice(0, 24),
            i.length > 24 ? "…" : ""
          ] }),
          n.map((c) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "fp-selection-action",
              "data-danger": c.danger || void 0,
              onClick: () => {
                c.onClick(), r();
              },
              children: [
                c.icon,
                c.label
              ]
            },
            c.id
          ))
        ]
      }
    ),
    document.body
  );
}
function Om({
  list: t,
  sync: n,
  resolve: r,
  intervalMs: i = 3e4,
  eventName: a = "fp-sync-change"
}) {
  const [l, s] = k([]), [c, u] = k(""), [d, p] = k(!1), h = De(() => {
    t().then((b) => {
      s(b), u("");
    }).catch(() => u("暂时无法同步，内容仍保存在此设备"));
  }, [t]), f = De(() => {
    n().then(h).catch(() => u("暂时无法同步，稍后将重试"));
  }, [n, h]);
  if (Y(() => {
    h(), f();
    const b = () => h(), g = () => f();
    window.addEventListener(a, b), window.addEventListener("online", g);
    const v = i > 0 ? setInterval(f, i) : void 0;
    return () => {
      v && clearInterval(v), window.removeEventListener(a, b), window.removeEventListener("online", g);
    };
  }, [h, f, i, a]), Y(() => {
    p(!1);
  }, [l.length]), !l.length || d) return null;
  const m = l.some((b) => b.conflict);
  return /* @__PURE__ */ o(
    "aside",
    {
      className: "fp-sync-status",
      "data-conflict": m || void 0,
      role: "status",
      "aria-live": "polite",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-sync-icon", "aria-hidden": "true", children: m ? /* @__PURE__ */ e(Io, { size: 16 }) : /* @__PURE__ */ e(Do, { size: 16 }) }),
        /* @__PURE__ */ o("div", { className: "fp-sync-body", children: [
          /* @__PURE__ */ e("strong", { children: m ? "部分内容在其他设备上有更新" : "正在同步学习记录" }),
          /* @__PURE__ */ e("span", { children: m ? "选择要保留的版本，冲突解决后会继续同步。" : "未完成的内容已保存在本机。" }),
          l.filter((b) => b.conflict).map((b, g) => /* @__PURE__ */ o("div", { className: "fp-sync-actions", children: [
            /* @__PURE__ */ o("span", { className: "fp-sync-key", children: [
              "记录 ",
              g + 1
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !0).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "保留此设备版本"
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !1).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "采用云端版本"
              }
            )
          ] }, b.key)),
          c && /* @__PURE__ */ o("p", { className: "fp-sync-error", role: "alert", children: [
            /* @__PURE__ */ e(To, { size: 13 }),
            " ",
            c
          ] })
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-sync-close",
            "aria-label": "收起同步提示",
            onClick: () => p(!0),
            children: /* @__PURE__ */ e(ke, { size: 14 })
          }
        )
      ]
    }
  );
}
function Cp(t) {
  return !t || t <= 0 ? "" : t >= 1e6 ? `${+(t / 1e6).toFixed(1)}M` : t >= 1e3 ? `${+(t / 1e3).toFixed(1)}K` : `${t}`;
}
function Sp({
  value: t,
  onChange: n,
  groups: r,
  disabled: i,
  label: a = "选择模型"
}) {
  const l = r.flatMap((s) => s.models).find((s) => s.id === t);
  return /* @__PURE__ */ e("span", { className: "fp-model-selector", children: /* @__PURE__ */ e(
    Xe,
    {
      label: a,
      role: "listbox",
      disabled: i || !r.some((s) => s.models.length),
      className: "fp-model-selector-panel",
      trigger: /* @__PURE__ */ o(ee, { children: [
        l?.icon || /* @__PURE__ */ e(Oo, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l?.label || t || "选择模型" }),
        /* @__PURE__ */ e(St, { size: 14, "aria-hidden": "true" })
      ] }),
      children: (s) => r.filter((c) => c.models.length).map((c) => /* @__PURE__ */ o(
        "div",
        {
          role: "group",
          "aria-label": c.name,
          className: "fp-model-group",
          children: [
            /* @__PURE__ */ e("div", { className: "fp-model-group-label", children: c.name }),
            c.models.map((u) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": u.id === t,
                disabled: u.disabled,
                tabIndex: -1,
                className: "fp-model-item",
                onClick: () => {
                  s(), n(u.id);
                },
                children: [
                  /* @__PURE__ */ o("span", { className: "fp-model-item-copy", children: [
                    /* @__PURE__ */ o("span", { className: "fp-model-item-main", children: [
                      /* @__PURE__ */ o("span", { className: "fp-model-item-label", children: [
                        u.icon,
                        u.label
                      ] }),
                      /* @__PURE__ */ e("span", { className: "fp-model-item-context", children: Cp(u.contextWindow) })
                    ] }),
                    u.description && /* @__PURE__ */ e("span", { className: "fp-model-item-description", children: u.description }),
                    (u.supportsThinking || u.supportsVision || u.supportsTools) && /* @__PURE__ */ o("span", { className: "fp-model-capabilities", children: [
                      u.supportsThinking && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(Po, { size: 12, "aria-hidden": "true" }),
                        "推理"
                      ] }),
                      u.supportsVision && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(wa, { size: 12, "aria-hidden": "true" }),
                        "视觉"
                      ] }),
                      u.supportsTools && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(Fo, { size: 12, "aria-hidden": "true" }),
                        "工具"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ e(
                    Ie,
                    {
                      size: 16,
                      className: "fp-model-item-check",
                      "aria-hidden": "true",
                      style: {
                        visibility: u.id === t ? "visible" : "hidden"
                      }
                    }
                  )
                ]
              },
              u.id
            ))
          ]
        },
        c.name
      ))
    }
  ) });
}
function Mp({
  balance: t,
  enabled: n = !0,
  isLoading: r = !1,
  onClick: i,
  label: a
}) {
  const l = a || (n ? t !== void 0 ? `${(t / 1e3).toLocaleString(void 0, { maximumFractionDigits: 3 })} 积分` : "积分" : "免费体验");
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-token-dashboard",
      onClick: i,
      disabled: r,
      "aria-label": "查看积分与会员",
      children: [
        /* @__PURE__ */ e(Ro, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l })
      ]
    }
  );
}
function Rm({
  apiEndpoint: t = "/api/me/credits",
  onClick: n
}) {
  const [r, i] = k(), [a, l] = k(!0), [s, c] = k(!0);
  return Y(() => {
    let u = !0;
    return fetch(t).then((d) => {
      if (!d.ok) throw new Error();
      return d.json();
    }).then((d) => {
      u && (i(d.wallet.balance), l(d.config.enabled), c(!1));
    }).catch(() => {
      u && c(!1);
    }), () => {
      u = !1;
    };
  }, [t]), /* @__PURE__ */ e(
    Mp,
    {
      balance: r,
      enabled: a,
      isLoading: s,
      onClick: n
    }
  );
}
function Ep({
  label: t,
  children: n,
  defaultOpen: r = !1,
  meta: i,
  className: a
}) {
  const [l, s] = k(r), c = ve();
  return /* @__PURE__ */ o("div", { className: `fp-collapsible ${a || ""}`, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-collapsible-head",
        "aria-expanded": l,
        "aria-controls": c,
        onClick: () => s((u) => !u),
        children: [
          /* @__PURE__ */ e(Ae, { size: 14, className: "fp-collapsible-chevron" }),
          /* @__PURE__ */ e("span", { className: "fp-collapsible-label", children: t }),
          i != null && /* @__PURE__ */ e("span", { className: "fp-collapsible-meta", children: i })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: c, className: "fp-collapsible-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("div", { className: "fp-collapsible-inner", children: n }) })
  ] });
}
function Bm({
  items: t,
  onRemove: n,
  onOpen: r,
  size: i = 64
}) {
  return t.length ? /* @__PURE__ */ e("ul", { className: "fp-attachment-grid", "aria-label": "图片附件", children: t.map((a) => /* @__PURE__ */ o("li", { className: "fp-attachment", style: { width: i }, children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-thumb",
        style: { width: i, height: i },
        onClick: () => r?.(a),
        disabled: !r,
        "aria-label": a.name ? `查看 ${a.name}` : "查看附件",
        children: a.src ? /* @__PURE__ */ e("img", { src: a.src, alt: a.name || "" }) : /* @__PURE__ */ e("span", { className: "fp-attachment-placeholder", "aria-hidden": "true" })
      }
    ),
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-remove",
        "aria-label": `移除${a.name || "附件"}`,
        onClick: () => n(a.id),
        children: /* @__PURE__ */ e(ke, { size: 12 })
      }
    )
  ] }, a.id)) }) : null;
}
const $p = {
  basic: "基础",
  medium: "中等",
  hard: "提高"
}, zp = "ABCDEFGHIJ";
function jm({
  index: t,
  total: n,
  kind: r = "单项选择",
  difficulty: i = "basic",
  prompt: a,
  options: l,
  selected: s,
  onSelect: c,
  mode: u = "answer",
  explanation: d,
  hint: p
}) {
  const h = Array.isArray(s) ? s : s ? [s] : [];
  return /* @__PURE__ */ o("article", { className: "fp-quiz", "data-mode": u, children: [
    /* @__PURE__ */ o("header", { className: "fp-quiz-meta", children: [
      /* @__PURE__ */ o("strong", { children: [
        "第 ",
        t + 1,
        " / ",
        n,
        " 题"
      ] }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: r }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: $p[i] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-quiz-prompt", children: a }),
    /* @__PURE__ */ e("ol", { className: "fp-quiz-options", children: l.map((f, m) => {
      const b = h.includes(f.id), g = u === "review" && f.correct, v = u === "review" && b && !f.correct;
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-quiz-option",
          "data-selected": b || void 0,
          "data-correct": g || void 0,
          "data-wrong": v || void 0,
          "aria-pressed": b,
          disabled: u === "review" || !c,
          onClick: () => c?.(f.id),
          children: [
            /* @__PURE__ */ e("span", { className: "fp-quiz-letter", children: zp[m] }),
            /* @__PURE__ */ e("span", { className: "fp-quiz-text", children: f.text }),
            g && /* @__PURE__ */ e(Ie, { size: 16, "aria-label": "正确答案" }),
            v && /* @__PURE__ */ e(ke, { size: 16, "aria-label": "选择错误" })
          ]
        }
      ) }, f.id);
    }) }),
    u === "review" && d && /* @__PURE__ */ o("div", { className: "fp-quiz-explanation", children: [
      /* @__PURE__ */ e(Ci, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: d })
    ] }),
    p && /* @__PURE__ */ o("div", { className: "fp-quiz-hint", children: [
      /* @__PURE__ */ e(Ci, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: p })
    ] })
  ] });
}
function qm({
  url: t,
  reason: n,
  onForce: r,
  title: i = "无法内嵌该页面",
  actionLabel: a = "打开原页面"
}) {
  let l = t;
  try {
    l = new URL(t).host;
  } catch {
  }
  return /* @__PURE__ */ o("div", { className: "fp-embed-fallback", children: [
    /* @__PURE__ */ e("span", { className: "fp-embed-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(Bo, { size: 26 }) }),
    /* @__PURE__ */ e("strong", { children: i }),
    /* @__PURE__ */ o("p", { children: [
      /* @__PURE__ */ e("span", { className: "fp-embed-host", children: l }),
      " ",
      "拒绝在当前窗口中显示（安全策略或访问受限）。请到原网站查看，以保留完整功能。"
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-embed-reason", children: n }),
    /* @__PURE__ */ o(
      "a",
      {
        className: "fp-button fp-primary",
        href: t,
        target: "_blank",
        rel: "noopener noreferrer",
        children: [
          /* @__PURE__ */ e(Vt, { size: 15, "aria-hidden": "true" }),
          a
        ]
      }
    ),
    r && /* @__PURE__ */ e("button", { type: "button", className: "fp-embed-force", onClick: r, children: "仍要尝试内嵌（可能显示空白）" })
  ] });
}
function Ap({ src: t, alt: n = "", onClose: r }) {
  const i = ci({ fullscreen: !0, resetKey: t, origin: "center" }), a = R(null), l = R(i);
  return l.current = i, Y(() => {
    if (!t) return;
    const s = document.body.style.overflow, c = document.activeElement;
    document.body.style.overflow = "hidden";
    const u = requestAnimationFrame(() => a.current?.querySelector('[aria-label="关闭"]')?.focus({ preventScroll: !0 })), d = (p) => {
      p.defaultPrevented || p.ctrlKey || p.metaKey || p.altKey || (p.key === "Escape" && (p.preventDefault(), r()), (p.key === "+" || p.key === "=") && (p.preventDefault(), l.current.zoomBy(1.2)), p.key === "-" && (p.preventDefault(), l.current.zoomBy(1 / 1.2)), p.key === "0" && (p.preventDefault(), l.current.reset()));
    };
    return document.addEventListener("keydown", d), () => {
      cancelAnimationFrame(u), document.body.style.overflow = s, document.removeEventListener("keydown", d), c instanceof HTMLElement && c.isConnected && c.focus({ preventScroll: !0 });
    };
  }, [t, r]), !t || typeof window > "u" ? null : Oe(/* @__PURE__ */ o(
    "div",
    {
      ref: a,
      className: "fp-lightbox",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": n || "图片预览",
      onKeyDown: (s) => {
        if (s.key !== "Tab") return;
        const c = Array.from(s.currentTarget.querySelectorAll("button:not(:disabled)")), u = c[0], d = c[c.length - 1];
        s.shiftKey && document.activeElement === u ? (s.preventDefault(), d?.focus()) : !s.shiftKey && document.activeElement === d && (s.preventDefault(), u?.focus());
      },
      children: [
        /* @__PURE__ */ o("div", { className: "fp-lightbox-bar", children: [
          /* @__PURE__ */ o("span", { className: "fp-lightbox-zoom", children: [
            Math.round(i.view.zoom * 100),
            "%"
          ] }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩小", "data-fp-tooltip": "缩小 · −", onClick: () => i.zoomBy(1 / 1.2), children: /* @__PURE__ */ e(Hr, { size: 17 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "放大", "data-fp-tooltip": "放大 · +", onClick: () => i.zoomBy(1.2), children: /* @__PURE__ */ e(Kr, { size: 17 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "复位", "data-fp-tooltip": "复位 · 0", onClick: i.reset, children: /* @__PURE__ */ e(tt, { size: 17 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭", "data-fp-tooltip": "关闭 · Esc", onClick: r, children: /* @__PURE__ */ e(ke, { size: 18 }) })
        ] }),
        /* @__PURE__ */ e("div", { ref: i.ref, ...i.bind, className: "fp-lightbox-stage", onDoubleClick: () => i.view.zoom > 1 ? i.reset() : i.zoomBy(2), children: /* @__PURE__ */ e("img", { src: t, alt: n, draggable: !1, style: { transform: `translate(${i.view.x}px,${i.view.y}px) scale(${i.view.zoom})`, transition: "none" } }) }),
        /* @__PURE__ */ e("button", { type: "button", className: "fp-lightbox-scrim", "aria-label": "关闭预览", onClick: r })
      ]
    }
  ), document.body);
}
function Km({
  title: t,
  icon: n,
  summary: r,
  children: i,
  open: a,
  onToggle: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-settings-section", "data-open": a || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-settings-head",
        "aria-expanded": a,
        "aria-label": t,
        onClick: l,
        children: [
          /* @__PURE__ */ e("span", { className: "fp-settings-icon", "aria-hidden": "true", children: n }),
          /* @__PURE__ */ o("span", { className: "fp-settings-titles", children: [
            /* @__PURE__ */ e("strong", { children: t }),
            r && /* @__PURE__ */ e("small", { children: r })
          ] }),
          /* @__PURE__ */ e(St, { size: 16, className: "fp-settings-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-settings-body", inert: !a, "aria-hidden": !a, children: /* @__PURE__ */ e("div", { className: "fp-settings-inner", children: i }) })
  ] });
}
function Hm({
  subjectName: t = "学习",
  topic: n,
  prompts: r = [],
  onPrompt: i,
  icon: a,
  title: l,
  description: s
}) {
  return /* @__PURE__ */ o("div", { className: "fp-chat-empty", children: [
    /* @__PURE__ */ e("span", { className: "fp-chat-empty-icon", "aria-hidden": "true", children: a || /* @__PURE__ */ e(Dn, { size: 22 }) }),
    /* @__PURE__ */ e("strong", { children: l || `我是你的${t}助教` }),
    /* @__PURE__ */ e("p", { children: s || "遇到不懂的概念随时问我，我可以解释公式、出题练习，或者帮你梳理知识点。" }),
    n && /* @__PURE__ */ o("span", { className: "fp-chat-empty-topic", children: [
      "当前学习 · ",
      n
    ] }),
    r.length > 0 && /* @__PURE__ */ o("div", { className: "fp-chat-prompts", children: [
      /* @__PURE__ */ e("span", { className: "fp-chat-prompts-label", children: "试试这样问我" }),
      r.map((c) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-chat-prompt",
          onClick: () => i?.(c),
          children: c
        },
        c
      ))
    ] })
  ] });
}
function la(t) {
  try {
    return new URL(t).hostname.replace(/^www\./, "");
  } catch {
    return t;
  }
}
function Um({
  sources: t,
  label: n = "联网来源",
  cached: r,
  onOpen: i
}) {
  const [a, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-source-fold", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-head",
        "aria-expanded": a,
        onClick: () => l((s) => !s),
        children: [
          /* @__PURE__ */ e(Ae, { size: 14, className: "fp-source-chevron" }),
          /* @__PURE__ */ e(jo, { size: 15, "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { children: [
            n,
            " · ",
            t.length,
            " 条",
            r ? " · 缓存" : ""
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-source-body", inert: !a, "aria-hidden": !a, "data-open": a || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-source-list", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-item",
        onClick: () => i?.(s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-source-index", children: c + 1 }),
          /* @__PURE__ */ e("span", { className: "fp-source-title", children: s.title || la(s.url) }),
          /* @__PURE__ */ o("span", { className: "fp-source-host", children: [
            /* @__PURE__ */ e(ft, { size: 12, "aria-hidden": "true" }),
            la(s.url)
          ] })
        ]
      }
    ) }, `${s.url}:${c}`)) }) })
  ] }) : null;
}
function Wm({
  groups: t,
  activeId: n,
  onSelect: r,
  onCreate: i,
  onDelete: a,
  onClose: l
}) {
  const [s, c] = k(t[0]?.id), [u, d] = k(null), p = t.find((h) => h.id === s) || t[0];
  return /* @__PURE__ */ o("div", { className: "fp-session-history", children: [
    /* @__PURE__ */ o("header", { className: "fp-session-history-head", children: [
      /* @__PURE__ */ e(Xn, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: "历史记录" }),
      l && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-icon-button fp-sm",
          "aria-label": "关闭历史记录",
          onClick: l,
          children: /* @__PURE__ */ e(ke, { size: 16 })
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { className: "fp-session-tabs", role: "tablist", "aria-label": "记录类型", children: t.map((h) => /* @__PURE__ */ o(
      "button",
      {
        role: "tab",
        type: "button",
        "aria-selected": h.id === p?.id,
        onClick: () => c(h.id),
        children: [
          h.label,
          /* @__PURE__ */ e("span", { children: h.items.length })
        ]
      },
      h.id
    )) }),
    i && p && /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-session-create",
        onClick: () => i(p.id),
        children: [
          /* @__PURE__ */ e(qt, { size: 15, "aria-hidden": "true" }),
          "新建",
          p.label.replace(/记录$/, "")
        ]
      }
    ),
    /* @__PURE__ */ o("ul", { className: "fp-session-list", children: [
      (p?.items || []).map((h) => /* @__PURE__ */ o("li", { "data-active": h.id === n || void 0, children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-session-item",
            onClick: () => r(p.id, h.id),
            "aria-current": h.id === n || void 0,
            children: [
              /* @__PURE__ */ e(qo, { size: 15, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: h.title }),
                h.detail && /* @__PURE__ */ e("small", { children: h.detail })
              ] }),
              h.time && /* @__PURE__ */ e("time", { children: h.time })
            ]
          }
        ),
        a && (u === h.id ? /* @__PURE__ */ o("span", { className: "fp-session-confirm", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                a(p.id, h.id), d(null);
              },
              children: "删除"
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => d(null), children: "取消" })
        ] }) : /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-session-delete",
            "aria-label": `删除 ${h.title}`,
            onClick: () => d(h.id),
            children: /* @__PURE__ */ e(Gt, { size: 14 })
          }
        ))
      ] }, h.id)),
      !p?.items.length && /* @__PURE__ */ e("li", { className: "fp-session-empty", children: "还没有记录，开始第一次对话吧。" })
    ] })
  ] });
}
function _m({ mode: t = "login", title: n = "账号登录", icon: r = /* @__PURE__ */ e(et, { size: 18 }), onClose: i, onBrowser: a, onReload: l, children: s, className: c, browserPending: u = !1 }) {
  return /* @__PURE__ */ e(dl, { children: /* @__PURE__ */ e(
    $l,
    {
      native: !0,
      title: n,
      icon: r,
      closeLabel: t === "task" ? "关闭授权窗口" : "取消登录",
      closeShortcut: "Esc",
      onClose: i,
      className: c,
      actions: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ o(te, { variant: "ghost", onClick: a, "aria-label": t === "task" ? "在浏览器中继续" : "在浏览器中继续登录", "data-fp-tooltip-side": "left", children: [
          /* @__PURE__ */ e(Vt, { size: 16 }),
          t === "task" ? "浏览器继续" : "浏览器登录"
        ] }),
        /* @__PURE__ */ e(te, { variant: "ghost", disabled: u, "aria-label": t === "task" ? "刷新授权信息" : "重新加载登录页", "data-fp-tooltip-side": "left", style: { width: 44, padding: 0 }, onClick: l, children: /* @__PURE__ */ e(Qn, { size: 16 }) })
      ] }),
      children: u ? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: "请在浏览器中完成登录，完成后会自动返回。" }) : s ?? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: t === "task" ? "正在读取授权信息…" : "正在打开登录页…" })
    }
  ) });
}
function Vm({
  label: t = "筛选",
  value: n,
  onChange: r,
  options: i = [],
  groups: a = [],
  disabled: l,
  id: s
}) {
  const c = ve();
  return /* @__PURE__ */ o("div", { className: "fp-filter", children: [
    t && /* @__PURE__ */ e("span", { id: s || c, className: "fp-filter-label", children: t }),
    /* @__PURE__ */ e(Ce, { label: t || "筛选", value: n, onChange: r, disabled: l, options: [...i, ...a.flatMap((d) => d.options.map((p) => ({ ...p, group: d.label })))] })
  ] });
}
function Gm({
  years: t,
  value: n,
  onChange: r,
  compact: i = !1,
  termLabel: a = "学期"
}) {
  const l = t.find((u) => u.id === n), s = Array.from(new Set(t.map((u) => u.grade))), c = l ? t.filter((u) => u.grade === l.grade) : [];
  return /* @__PURE__ */ o("div", { className: "fp-academic", "data-compact": i || void 0, children: [
    /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": "年级", children: s.map((u) => {
      const d = t.find((h) => h.grade === u), p = l?.grade === u;
      return /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-academic-btn",
          "aria-pressed": p,
          onClick: () => r(d.id),
          children: u
        },
        u
      );
    }) }),
    c.length > 1 && /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": a, children: c.map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-academic-btn fp-academic-term",
        "aria-pressed": u.id === n,
        onClick: () => r(u.id),
        children: u.term
      },
      u.id
    )) })
  ] });
}
function Ym({
  hits: t,
  label: n = "引用笔记",
  onOpen: r,
  action: i
}) {
  const [a, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-citation-list", children: [
    /* @__PURE__ */ o("header", { className: "fp-citation-head", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-citation-toggle",
          "aria-expanded": a,
          onClick: () => l((s) => !s),
          children: [
            /* @__PURE__ */ e(Ae, { size: 14, className: "fp-citation-chevron" }),
            /* @__PURE__ */ e(nt, { size: 15, "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { children: [
              n,
              " · ",
              t.length,
              " 条"
            ] })
          ]
        }
      ),
      i && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-citation-action",
          onClick: i.onClick,
          children: i.label
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-citation-body", "data-open": a || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-citation-hits", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-citation-hit",
        onClick: () => r?.(s),
        children: [
          /* @__PURE__ */ e("strong", { children: s.title }),
          /* @__PURE__ */ e("span", { children: s.path }),
          s.snippet && /* @__PURE__ */ e("small", { children: s.snippet })
        ]
      }
    ) }, `${s.path}:${c}`)) }) })
  ] }) : null;
}
const Lp = {
  idle: "等待确认",
  approved: "已批准",
  running: "生成中",
  done: "已完成",
  cancelled: "已取消",
  error: "失败"
};
function Xm({
  title: t = "AI 生图",
  prompt: n,
  details: r = [],
  cost: i,
  status: a = "idle",
  onApprove: l,
  onCancel: s,
  children: c
}) {
  const u = a === "idle";
  return /* @__PURE__ */ o("section", { className: "fp-approval", "data-status": a, children: [
    /* @__PURE__ */ o("header", { className: "fp-approval-head", children: [
      /* @__PURE__ */ e("span", { className: "fp-approval-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(Dn, { size: 16 }) }),
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("span", { className: "fp-approval-status", children: Lp[a] })
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-approval-prompt", children: n }),
    r.length > 0 && /* @__PURE__ */ e("dl", { className: "fp-approval-details", children: r.map((d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: d.label }),
      /* @__PURE__ */ e("dd", { children: d.value })
    ] }, d.label)) }),
    i && /* @__PURE__ */ e("p", { className: "fp-approval-cost", children: i }),
    u ? /* @__PURE__ */ o("div", { className: "fp-approval-actions", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-primary", onClick: l, children: [
        /* @__PURE__ */ e(Ie, { size: 15, "aria-hidden": "true" }),
        "批准并继续"
      ] }),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: s,
          children: [
            /* @__PURE__ */ e(ke, { size: 15, "aria-hidden": "true" }),
            "取消"
          ]
        }
      )
    ] }) : c
  ] });
}
function Fl(t, n = 0) {
  return t.flatMap((r) => [
    { node: r, depth: n },
    ...Fl(r.children || [], n + 1)
  ]);
}
function Qm({
  items: t,
  activeId: n,
  onSelect: r,
  label: i = "目录",
  empty: a = "这篇内容还没有小节标题。"
}) {
  const l = Fl(t);
  return l.length ? /* @__PURE__ */ e("nav", { className: "fp-toc", "aria-label": i, children: l.map(({ node: s, depth: c }) => {
    const u = s.level ?? 1;
    return /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-toc-row",
        "data-level": u,
        "data-active": s.id === n || void 0,
        style: { paddingLeft: 8 + c * 16 },
        title: s.text,
        "aria-current": s.id === n ? "location" : void 0,
        onClick: () => {
          r?.(s.id), document.getElementById(s.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
        },
        children: [
          u === 1 ? /* @__PURE__ */ e(nt, { size: 14, "aria-hidden": "true" }) : /* @__PURE__ */ e("span", { className: "fp-toc-dot", "aria-hidden": "true" }),
          /* @__PURE__ */ e("span", { children: s.text })
        ]
      },
      s.id
    );
  }) }) : /* @__PURE__ */ e("p", { className: "fp-toc-empty", children: a });
}
const Ip = {
  done: ct,
  draft: Ko,
  stub: xa
};
function Jm({
  items: t,
  activeId: n,
  onSelect: r,
  label: i = "同目录内容"
}) {
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-siblings", "aria-label": i, children: [
    /* @__PURE__ */ e("header", { className: "fp-siblings-label", children: i }),
    /* @__PURE__ */ e("ul", { className: "fp-siblings-list", children: t.map((a) => {
      const l = Ip[a.status ?? "stub"];
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-sibling",
          "data-status": a.status ?? "stub",
          "aria-current": a.id === n ? "page" : void 0,
          onClick: () => r(a),
          children: [
            /* @__PURE__ */ e(l, { size: 14, className: "fp-sibling-icon", "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { className: "fp-sibling-text", children: [
              a.title,
              a.detail && /* @__PURE__ */ e("small", { children: a.detail })
            ] })
          ]
        }
      ) }, a.id);
    }) })
  ] }) : null;
}
function Zm({
  steps: t,
  interactive: n = !1,
  label: r = "推导步骤"
}) {
  const [i, a] = k(0);
  if (!t.length) return null;
  const l = n ? [t[i]] : t;
  return /* @__PURE__ */ o("section", { className: "fp-formula", "aria-label": r, children: [
    /* @__PURE__ */ o("header", { className: "fp-formula-head", children: [
      /* @__PURE__ */ e(Pt, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("span", { children: r }),
      n && /* @__PURE__ */ o("span", { className: "fp-formula-count", children: [
        "第 ",
        i + 1,
        " / ",
        t.length,
        " 步"
      ] })
    ] }),
    /* @__PURE__ */ e("ol", { className: "fp-formula-list", children: l.map((s, c) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-formula-index", children: n ? i + 1 : c + 1 }),
      /* @__PURE__ */ e("div", { className: "fp-formula-body", children: s })
    ] }, n ? i : c)) }),
    n && /* @__PURE__ */ o("div", { className: "fp-formula-nav", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i === 0,
          onClick: () => a((s) => Math.max(0, s - 1)),
          children: [
            /* @__PURE__ */ e(Wr, { size: 14, "aria-hidden": "true" }),
            "上一步"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i === t.length - 1,
          onClick: () => a((s) => Math.min(t.length - 1, s + 1)),
          children: [
            "下一步",
            /* @__PURE__ */ e(Ae, { size: 14, "aria-hidden": "true" })
          ]
        }
      )
    ] })
  ] });
}
const Ol = 320, Rr = 170, Be = { l: 30, r: 12, t: 14, b: 26 }, xr = Ol - Be.l - Be.r, Tt = Rr - Be.t - Be.b;
function Dp(t, n, r) {
  const i = Math.max(1e-6, r);
  return 1 / (i * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * ((t - n) / i) ** 2);
}
function Tp(t, n) {
  if (n < 0 || n > t) return 0;
  let r = 1;
  for (let i = 1; i <= n; i++) r = r * (t - n + i) / i;
  return r;
}
function Pp(t, n, r) {
  return Tp(n, t) * r ** t * (1 - r) ** (n - t);
}
function Fp(t, n) {
  let r = 1;
  for (let i = 2; i <= t; i++) r *= i;
  return n ** t * Math.exp(-n) / r;
}
function eb({
  type: t,
  params: n = {},
  interactive: r = !1,
  height: i = 180,
  label: a
}) {
  const l = ve(), [s, c] = k(n.mu ?? 0), [u, d] = k(n.sigma ?? 1), [p, h] = k(n.n ?? 10), [f, m] = k(n.p ?? 0.5), [b, g] = k(n.lambda ?? 3), v = [];
  let w = [], y = 1;
  if (t === "normal") {
    const A = s - 4 * u, O = s + 4 * u, U = 120;
    for (let T = 0; T <= U; T++) {
      const E = A + (O - A) * T / U;
      v.push({ x: E, y: Dp(E, s, u) });
    }
    y = Math.max(...v.map((T) => T.y)), w = [A, s - u, s, s + u, O];
  } else {
    const A = t === "binomial" ? p : Math.max(1, Math.round(b * 4));
    for (let O = 0; O <= A; O++) {
      const U = t === "binomial" ? Pp(O, p, f) : Fp(O, b);
      v.push({ x: O, y: U });
    }
    y = Math.max(...v.map((O) => O.y), 1e-9), w = [0, Math.round(A / 2), A];
  }
  const N = v[0].x, x = v[v.length - 1].x, C = (A) => Be.l + (A - N) / (x - N || 1) * xr, z = (A) => Be.t + Tt - A / y * Tt * 0.92, L = t === "normal" ? v.map((A, O) => `${O === 0 ? "M" : "L"}${C(A.x).toFixed(1)},${z(A.y).toFixed(1)}`).join(" ") : "", j = t === "normal" ? 0 : Math.max(4, xr / v.length - 4), M = /* @__PURE__ */ o(
    "svg",
    {
      viewBox: `0 0 ${Ol} ${Rr}`,
      width: "100%",
      height: i,
      role: "img",
      "aria-labelledby": l,
      className: "fp-dist-chart",
      children: [
        /* @__PURE__ */ e("title", { id: l, children: a || (t === "normal" ? `正态分布 μ=${s} σ=${u}` : t === "binomial" ? `二项分布 n=${p} p=${f}` : `泊松分布 λ=${b}`) }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: Be.l,
            y1: Be.t + Tt,
            x2: Be.l + xr,
            y2: Be.t + Tt,
            className: "fp-dist-axis"
          }
        ),
        /* @__PURE__ */ e("line", { x1: Be.l, y1: Be.t, x2: Be.l, y2: Be.t + Tt, className: "fp-dist-axis" }),
        t === "normal" ? /* @__PURE__ */ e("path", { d: L, className: "fp-dist-line" }) : v.map((A, O) => /* @__PURE__ */ e(
          "rect",
          {
            x: C(A.x) - j / 2,
            y: z(A.y),
            width: j,
            height: Be.t + Tt - z(A.y),
            rx: 2,
            className: "fp-dist-bar"
          },
          O
        )),
        w.map((A, O) => /* @__PURE__ */ e(
          "text",
          {
            x: C(A),
            y: Rr - 8,
            textAnchor: "middle",
            className: "fp-dist-tick",
            children: Number.isInteger(A) ? A : A.toFixed(1)
          },
          O
        ))
      ]
    }
  );
  return r ? /* @__PURE__ */ o("div", { className: "fp-dist", children: [
    M,
    /* @__PURE__ */ e("div", { className: "fp-dist-controls", children: t === "normal" ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "均值 μ · ",
          s.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: -3,
            max: 3,
            step: 0.1,
            value: s,
            onChange: (A) => c(Number(A.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "标准差 σ · ",
          u.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.3,
            max: 3,
            step: 0.1,
            value: u,
            onChange: (A) => d(Number(A.target.value))
          }
        )
      ] })
    ] }) : t === "binomial" ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "试验次数 n · ",
          p
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 1,
            max: 30,
            step: 1,
            value: p,
            onChange: (A) => h(Number(A.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "成功概率 p · ",
          f.toFixed(2)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.05,
            max: 0.95,
            step: 0.05,
            value: f,
            onChange: (A) => m(Number(A.target.value))
          }
        )
      ] })
    ] }) : /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ o("span", { children: [
        "λ · ",
        b.toFixed(1)
      ] }),
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0.5,
          max: 10,
          step: 0.5,
          value: b,
          onChange: (A) => g(Number(A.target.value))
        }
      )
    ] }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-dist", children: M });
}
function tb({
  open: t,
  onClose: n,
  categories: r,
  title: i = "快捷键参考",
  footnote: a
}) {
  return Y(() => {
    if (!t) return;
    const l = (c) => {
      c.key === "Escape" && (c.preventDefault(), n());
    };
    document.addEventListener("keydown", l);
    const s = document.body.style.overflow;
    return document.body.style.overflow = "hidden", () => {
      document.removeEventListener("keydown", l), document.body.style.overflow = s;
    };
  }, [t, n]), !t || typeof window > "u" ? null : Oe(
    /* @__PURE__ */ e("div", { className: "fp-shortcut-scrim", onPointerDown: n, children: /* @__PURE__ */ o(
      "div",
      {
        className: "fp-shortcut",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": i,
        onPointerDown: (l) => l.stopPropagation(),
        children: [
          /* @__PURE__ */ o("header", { className: "fp-shortcut-head", children: [
            /* @__PURE__ */ e(ba, { size: 18, "aria-hidden": "true" }),
            /* @__PURE__ */ e("strong", { children: i }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-icon-button fp-sm",
                "aria-label": "关闭快捷键参考",
                onClick: n,
                children: /* @__PURE__ */ e(ke, { size: 16 })
              }
            )
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-shortcut-body", children: r.map((l) => /* @__PURE__ */ o("section", { className: "fp-shortcut-group", children: [
            /* @__PURE__ */ e("h3", { children: l.label }),
            /* @__PURE__ */ e("dl", { children: l.items.map((s) => /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("dt", { children: s.keys.split(" ").map((c, u) => /* @__PURE__ */ e("span", { className: "fp-kbd", children: c }, u)) }),
              /* @__PURE__ */ e("dd", { children: s.description })
            ] }, s.keys + s.description)) })
          ] }, l.id)) }),
          a && /* @__PURE__ */ e("footer", { className: "fp-shortcut-foot", children: a })
        ]
      }
    ) }),
    document.body
  );
}
function nb({
  items: t,
  value: n,
  onChange: r,
  label: i = "主导航",
  className: a = "",
  busy: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: `fp-bottom-nav ${a}`, "aria-label": i, "aria-busy": l, children: t.map((s) => {
    const c = s.id === n, u = s.href ? "a" : "button";
    return /* @__PURE__ */ o(
      u,
      {
        type: "button",
        href: s.href,
        "aria-disabled": s.disabled || void 0,
        className: "fp-bottom-nav-item",
        "aria-current": c ? "page" : void 0,
        onClick: (d) => {
          s.href && (d.metaKey || d.ctrlKey || d.shiftKey || d.altKey) || (d.preventDefault(), s.disabled || r(s.id));
        },
        children: [
          /* @__PURE__ */ e("span", { className: "fp-bottom-nav-indicator", "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { className: "fp-bottom-nav-icon", children: [
            s.icon,
            s.badge ? /* @__PURE__ */ e("span", { className: "fp-bottom-nav-badge", children: s.badge }) : null
          ] }),
          /* @__PURE__ */ e("span", { children: s.label })
        ]
      },
      s.id
    );
  }) });
}
const Op = 4;
function rb({
  images: t,
  label: n = "笔记图片",
  size: r = 132,
  meta: i
}) {
  const a = R(null), l = R(null), [s, c] = k(null);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-gallery", children: [
    /* @__PURE__ */ o("header", { className: "fp-gallery-head", children: [
      /* @__PURE__ */ e(Ho, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        n,
        " · ",
        t.length,
        " 张"
      ] }),
      i && /* @__PURE__ */ e("small", { children: i })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        ref: a,
        className: "fp-gallery-strip",
        "data-dragging": l.current?.moved || void 0,
        onPointerDown: (u) => {
          const d = a.current;
          !d || u.button !== 0 || (l.current = { x: u.clientX, left: d.scrollLeft, moved: !1 });
        },
        onPointerMove: (u) => {
          const d = a.current, p = l.current;
          if (!d || !p) return;
          const h = u.clientX - p.x;
          !p.moved && Math.abs(h) >= Op && (p.moved = !0, d.setPointerCapture(u.pointerId)), p.moved && (d.scrollLeft = p.left - h);
        },
        onPointerUp: () => {
          l.current = null;
        },
        onPointerCancel: () => {
          l.current = null;
        },
        children: t.map((u, d) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-gallery-item",
            style: { width: r, height: r },
            onClick: () => {
              l.current?.moved || c(u);
            },
            children: [
              /* @__PURE__ */ e("img", { src: u.src, alt: u.alt || u.caption || `图片 ${d + 1}` }),
              u.caption && /* @__PURE__ */ e("span", { children: u.caption })
            ]
          },
          `${u.src}:${d}`
        ))
      }
    ),
    /* @__PURE__ */ e(
      Ap,
      {
        src: s?.src ?? null,
        alt: s?.alt || s?.caption,
        onClose: () => c(null)
      }
    )
  ] }) : null;
}
function ib({
  windows: t,
  onSelect: n,
  max: r = 5,
  label: i = "已打开的窗口"
}) {
  const a = R(null), [l, s] = k(r);
  if (xe(() => {
    const p = a.current;
    if (!p) return;
    const h = () => {
      p.clientWidth && s(
        Math.max(
          1,
          Math.min(r, Math.floor((p.clientWidth - 46) / 132))
        )
      );
    };
    if (h(), typeof ResizeObserver > "u") return;
    const f = new ResizeObserver(h);
    return f.observe(p), () => f.disconnect();
  }, [r, t.length]), !t.length) return null;
  const c = Math.max(1, Math.min(r, l)), u = t.slice(0, c), d = t.slice(c);
  return /* @__PURE__ */ o("div", { ref: a, className: "fp-taskbar", role: "toolbar", "aria-label": i, children: [
    u.map((p) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-taskbar-item",
        "aria-pressed": p.active,
        title: p.title,
        onClick: () => n(p.id),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-taskbar-dot", "aria-hidden": "true" }),
          p.icon,
          /* @__PURE__ */ e("span", { className: "fp-taskbar-title", children: p.title })
        ]
      },
      p.id
    )),
    d.length > 0 && /* @__PURE__ */ e(
      Xe,
      {
        label: `还有 ${d.length} 个窗口`,
        menu: !0,
        trigger: /* @__PURE__ */ o("span", { children: [
          "+",
          d.length
        ] }),
        children: (p) => d.map((h) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            role: "menuitem",
            onClick: () => {
              p(), n(h.id);
            },
            children: [
              h.icon,
              h.title
            ]
          },
          h.id
        ))
      }
    )
  ] });
}
function ab({ title: t, description: n, icon: r, className: i = "", ...a }) {
  return /* @__PURE__ */ o("button", { ...a, type: a.type || "button", className: `fp-navigation-card ${i}`, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-navigation-card-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-navigation-card-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e(Ae, { size: 17, "aria-hidden": "true" })
  ] });
}
function lb({ title: t, description: n, eyebrow: r, art: i, footer: a, className: l = "", ...s }) {
  return /* @__PURE__ */ o("button", { ...s, type: s.type || "button", className: `fp-preview-card ${l}`, children: [
    /* @__PURE__ */ o("span", { className: "fp-preview-card-art", children: [
      /* @__PURE__ */ e("span", { className: "fp-preview-card-eyebrow", children: r }),
      i
    ] }),
    /* @__PURE__ */ o("span", { className: "fp-preview-card-copy", children: [
      /* @__PURE__ */ o("strong", { children: [
        t,
        /* @__PURE__ */ e(Ae, { size: 17 })
      ] }),
      n && /* @__PURE__ */ e("span", { children: n }),
      a && /* @__PURE__ */ e("span", { className: "fp-preview-card-footer", children: a })
    ] })
  ] });
}
const Rp = (t) => t === void 0 ? "—" : t < 1024 ? `${t} B` : t < 1048576 ? `${(t / 1024).toFixed(1)} KB` : `${(t / 1048576).toFixed(1)} MB`;
function Bp({
  fill: t = !1,
  media: n = !1,
  defaultView: r = "list",
  showSearch: i = !0,
  availableActions: a = ["download", "share", "rename", "delete"],
  query: l,
  onQueryChange: s,
  items: c,
  folderId: u = null,
  onFolderChange: d,
  selectedIds: p,
  onSelectionChange: h,
  onOpen: f,
  onAction: m,
  onCreateFolder: b,
  onUpload: g,
  onMove: v,
  loading: w,
  error: y
}) {
  const N = t ? Br : ge, x = R(null), C = R(null), [z, L] = k(null), [j, M] = k(1), [A, O] = k(!1), U = A ? 80 : 52, [T, E] = k(r), [S, P] = k(""), [_, q] = k("name"), H = l ?? S, I = (D) => {
    P(D), s?.(D);
  }, $ = c.find((D) => D.id === u), B = c.filter((D) => p.includes(D.id)), J = [];
  let Z = $;
  const Ne = /* @__PURE__ */ new Set();
  for (; Z && !Ne.has(Z.id); )
    Ne.add(Z.id), J.unshift(Z), Z = c.find((D) => D.id === Z?.parentId);
  const pe = Ke(
    () => c.filter(
      (D) => (D.parentId || null) === u && D.name.toLowerCase().includes(H.toLowerCase())
    ).sort(
      (D, G) => D.kind !== G.kind ? D.kind === "folder" ? -1 : 1 : _ === "name-desc" ? G.name.localeCompare(D.name, "zh-CN") : _ === "modified-asc" ? (D.modifiedAt || "").localeCompare(G.modifiedAt || "") : _ === "size-asc" ? (D.size || 0) - (G.size || 0) : _ === "size" ? (G.size || 0) - (D.size || 0) : _ === "modified" ? (G.modifiedAt || "").localeCompare(D.modifiedAt || "") : D.name.localeCompare(G.name, "zh-CN")
    ),
    [c, u, H, _]
  );
  xe(() => {
    const D = C.current;
    if (!D) return;
    const G = () => {
      O(D.clientWidth < 540), M(Math.max(1, Math.floor((D.clientWidth - 8) / (n ? 228 : 148))));
    };
    if (G(), typeof ResizeObserver > "u") return;
    const de = new ResizeObserver(G);
    return de.observe(D), () => de.disconnect();
  }, [n]);
  const V = T === "list" ? 1 : j, K = Ia({
    count: Math.ceil(pe.length / V),
    getScrollElement: () => C.current,
    estimateSize: () => T === "list" ? U : n ? 244 : 156,
    overscan: 8,
    initialRect: { width: 800, height: 480 }
  }), re = pe.length > 100, le = K.getVirtualItems(), fe = re ? le.flatMap(
    (D) => pe.slice(D.index * V, (D.index + 1) * V)
  ) : pe;
  Y(() => {
    K.scrollToOffset(0);
  }, [u, H, _, T]), Y(() => {
    K.measure();
  }, [U, V, T, n]);
  const se = (D, G) => {
    const de = /* @__PURE__ */ new Set();
    for (; G; ) {
      if (D.includes(G) || de.has(G)) return !1;
      de.add(G), G = c.find((me) => me.id === G)?.parentId || null;
    }
    return !0;
  }, we = (D, G = !1, de = !1) => {
    if (G && x.current) {
      const me = pe.findIndex(($e) => $e.id === x.current), ze = pe.findIndex(($e) => $e.id === D);
      if (me >= 0 && ze >= 0) {
        h(
          pe.slice(Math.min(me, ze), Math.max(me, ze) + 1).map(($e) => $e.id)
        );
        return;
      }
    }
    x.current = D, h(
      de ? p.includes(D) ? p.filter((me) => me !== D) : [...p, D] : [D]
    );
  }, W = (D) => {
    D.kind === "folder" ? (d(D.id), h([]), I("")) : f(D);
  }, F = (D) => [
    {
      id: "open",
      label: "打开",
      icon: /* @__PURE__ */ e(nt, { size: 15 }),
      disabled: D.length !== 1,
      onSelect: () => W(D[0])
    },
    ...m ? [
      { id: "download", label: "下载", icon: /* @__PURE__ */ e(_t, { size: 15 }), disabled: D.some((G) => G.kind === "folder") },
      { id: "restore", label: "恢复", icon: /* @__PURE__ */ e(tt, { size: 15 }) },
      { id: "move", label: "移动到…", icon: /* @__PURE__ */ e(_o, { size: 15 }) },
      { id: "share", label: "分享", icon: /* @__PURE__ */ e(Vo, { size: 15 }) },
      {
        id: "rename",
        label: "重命名",
        icon: /* @__PURE__ */ e(Yn, { size: 15 }),
        disabled: D.length !== 1
      },
      {
        id: "delete",
        label: "移到回收站",
        icon: /* @__PURE__ */ e(Gt, { size: 15 }),
        danger: !0,
        separator: !0
      }
    ].filter((G) => a.includes(G.id)).map((G) => ({
      ...G,
      onSelect: () => m(
        G.id,
        D
      )
    })) : []
  ];
  return /* @__PURE__ */ o("section", { className: "fp-resource-explorer", "data-fill": t || void 0, "data-media": n || void 0, "aria-label": n ? "图片资源管理器" : "文件资源管理器", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { className: "fp-explorer-location", children: [
        /* @__PURE__ */ o("nav", { "aria-label": "文件路径", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                d(null), I("");
              },
              children: "全部文件"
            }
          ),
          J.map((D) => /* @__PURE__ */ o("span", { children: [
            " ",
            "/",
            " ",
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => {
                  d(D.id), I("");
                },
                children: D.name
              }
            )
          ] }, D.id))
        ] }),
        "          ",
        (b || B.length > 0) && /* @__PURE__ */ e(or, { label: "资源操作", actions: [...b ? [{ id: "create", label: "新建文件夹", icon: /* @__PURE__ */ e(Uo, { size: 17 }), onSelect: b }] : [], ...F(B).filter((D) => D.id !== "open" && B.length > 0).map((D) => ({ id: D.id, label: D.label, icon: D.icon, onSelect: () => D.onSelect?.(), disabled: D.disabled }))] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "返回上级",
            disabled: !u,
            onClick: () => d($?.parentId || null),
            children: /* @__PURE__ */ e(Vr, { size: 16 })
          }
        )
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-explorer-tools", children: [
        i && /* @__PURE__ */ o("label", { className: "fp-explorer-search", children: [
          /* @__PURE__ */ e(Ue, { size: 15 }),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "搜索当前文件夹",
              placeholder: "搜索文件",
              value: H,
              onChange: (D) => I(D.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ e(
          Ce,
          {
            className: "fp-explorer-sort",
            label: "文件排序",
            value: _,
            onChange: q,
            options: [
              { value: "name", label: "名称 A → Z" },
              { value: "name-desc", label: "名称 Z → A" },
              { value: "modified", label: "修改时间：新到旧" },
              { value: "modified-asc", label: "修改时间：旧到新" },
              { value: "size", label: "大小：大到小" },
              { value: "size-asc", label: "大小：小到大" }
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "列表视图",
            "aria-pressed": T === "list",
            onClick: () => E("list"),
            children: /* @__PURE__ */ e(dn, { size: 16 })
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "网格视图",
            "aria-pressed": T === "grid",
            onClick: () => E("grid"),
            children: /* @__PURE__ */ e(Wo, { size: 16 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(
      xt,
      {
        label: "文件夹操作",
        items: [
          ...b ? [{ id: "new", label: "新建文件夹", onSelect: b }] : [],
          {
            id: "select-all",
            label: "全选",
            onSelect: () => h(pe.map((D) => D.id))
          },
          {
            id: "view",
            label: "视图",
            children: [
              {
                id: "list",
                label: "列表",
                checked: T === "list",
                onSelect: () => E("list")
              },
              {
                id: "grid",
                label: "网格",
                checked: T === "grid",
                onSelect: () => E("grid")
              }
            ]
          }
        ],
        children: /* @__PURE__ */ e(N, { children: /* @__PURE__ */ o(
          "div",
          {
            ref: C,
            style: {
              position: "relative",
              maxHeight: t ? void 0 : 480,
              overflow: "auto",
              ...re && T === "grid" ? {
                gridTemplateColumns: `repeat(${j},minmax(0,1fr))`,
                rowGap: 0
              } : {}
            },
            onPointerDown: (D) => {
              if (D.button !== 0 || D.pointerType === "touch" || D.target.closest(
                ".fp-explorer-item,button,input,label"
              ))
                return;
              const G = D.currentTarget.getBoundingClientRect(), de = D.clientX - G.left + D.currentTarget.scrollLeft, me = D.clientY - G.top + D.currentTarget.scrollTop;
              D.currentTarget.setPointerCapture(D.pointerId), L({ x: de, y: me, left: de, top: me, width: 0, height: 0 });
            },
            onPointerMove: (D) => {
              if (!z) return;
              const G = D.currentTarget.getBoundingClientRect(), de = D.clientX - G.left + D.currentTarget.scrollLeft, me = D.clientY - G.top + D.currentTarget.scrollTop, ze = {
                ...z,
                left: Math.min(de, z.x),
                top: Math.min(me, z.y),
                width: Math.abs(de - z.x),
                height: Math.abs(me - z.y)
              };
              L(ze);
              const $e = Array.from(
                D.currentTarget.querySelectorAll(
                  "[data-resource-id]"
                )
              ).filter((Se) => {
                const yt = Se.getBoundingClientRect(), Qt = yt.left - G.left + D.currentTarget.scrollLeft, lt = yt.top - G.top + D.currentTarget.scrollTop;
                return Qt < ze.left + ze.width && Qt + yt.width > ze.left && lt < ze.top + ze.height && lt + yt.height > ze.top;
              }).map((Se) => Se.dataset.resourceId);
              h($e);
            },
            onPointerUp: () => L(null),
            onPointerCancel: () => L(null),
            className: `fp-explorer-content fp-explorer-${T}`,
            "aria-busy": w,
            tabIndex: 0,
            onKeyDown: (D) => {
              D.target.closest("input") || ((D.ctrlKey || D.metaKey) && D.key.toLowerCase() === "a" && (D.preventDefault(), h(pe.map((G) => G.id))), D.key === "Escape" && h([]), D.key === "Delete" && B.length && m && a.includes("delete") && (D.preventDefault(), m("delete", B)));
            },
            onDragOver: (D) => {
              (g || v) && D.preventDefault();
            },
            onDrop: (D) => {
              if (D.preventDefault(), D.dataTransfer.files.length)
                g?.(Array.from(D.dataTransfer.files), u);
              else
                try {
                  const G = JSON.parse(
                    D.dataTransfer.getData(
                      "application/x-fiveplusone-resources"
                    )
                  );
                  Array.isArray(G) && G.every((de) => typeof de == "string") && se(G, u) && v?.(G, u);
                } catch {
                }
            },
            children: [
              y ? /* @__PURE__ */ e("p", { role: "alert", children: y }) : w ? /* @__PURE__ */ e(Dl, { variant: "list", label: "正在加载文件" }) : pe.length ? /* @__PURE__ */ o(ee, { children: [
                re && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: le[0]?.start || 0,
                      gridColumn: "1 / -1"
                    }
                  }
                ),
                fe.map((D) => /* @__PURE__ */ e(
                  xt,
                  {
                    label: `${D.name}的操作`,
                    items: F(
                      p.includes(D.id) ? B : [D]
                    ),
                    children: /* @__PURE__ */ o(
                      "div",
                      {
                        className: "fp-explorer-item",
                        "data-resource-id": D.id,
                        style: re ? {
                          height: T === "list" ? U : 148,
                          marginBottom: T === "grid" ? 8 : 0,
                          boxSizing: "border-box"
                        } : void 0,
                        "data-selected": p.includes(D.id) || void 0,
                        draggable: !!v,
                        onDragStart: (G) => {
                          G.dataTransfer.setData(
                            "application/x-fiveplusone-resources",
                            JSON.stringify(
                              p.includes(D.id) ? p : [D.id]
                            )
                          ), G.dataTransfer.effectAllowed = "move";
                        },
                        onDoubleClick: (G) => {
                          G.target.closest(
                            "button,input,label"
                          ) || W(D);
                        },
                        onClick: (G) => {
                          G.target.closest(
                            "button,input,label"
                          ) || we(D.id, G.shiftKey, G.ctrlKey || G.metaKey);
                        },
                        onDragOver: (G) => {
                          D.kind === "folder" && v && (G.preventDefault(), G.stopPropagation());
                        },
                        onDrop: (G) => {
                          if (D.kind === "folder")
                            if (G.preventDefault(), G.stopPropagation(), G.dataTransfer.files.length)
                              g?.(Array.from(G.dataTransfer.files), D.id);
                            else
                              try {
                                const de = JSON.parse(
                                  G.dataTransfer.getData(
                                    "application/x-fiveplusone-resources"
                                  )
                                );
                                Array.isArray(de) && de.every((me) => typeof me == "string") && se(de, D.id) && v?.(de, D.id);
                              } catch {
                              }
                        },
                        children: [
                          /* @__PURE__ */ e(
                            mi,
                            {
                              label: "",
                              "aria-label": `选择${D.name}`,
                              checked: p.includes(D.id),
                              onClick: (G) => {
                                G.shiftKey && (G.preventDefault(), we(D.id, !0));
                              },
                              onChange: () => we(D.id, !1, !0)
                            }
                          ),
                          /* @__PURE__ */ o(
                            "button",
                            {
                              type: "button",
                              className: "fp-explorer-name",
                              "aria-label": D.name,
                              onClick: (G) => {
                                G.shiftKey || G.ctrlKey || G.metaKey ? we(D.id, G.shiftKey, G.ctrlKey || G.metaKey) : W(D);
                              },
                              children: [
                                D.thumbnailUrl ? /* @__PURE__ */ e("img", { src: D.thumbnailUrl, alt: "" }) : D.kind === "folder" ? /* @__PURE__ */ e(Ht, { size: T === "grid" ? 36 : 19 }) : /* @__PURE__ */ e(nt, { size: T === "grid" ? 32 : 19 }),
                                /* @__PURE__ */ e("span", { children: D.name })
                              ]
                            }
                          ),
                          /* @__PURE__ */ e("small", { children: D.kind === "folder" ? "文件夹" : Rp(D.size) }),
                          /* @__PURE__ */ e("time", { children: D.modifiedAt ? new Date(D.modifiedAt).toLocaleDateString(
                            "zh-CN"
                          ) : "" }),
                          /* @__PURE__ */ e(
                            Pa,
                            {
                              label: `${D.name}的更多操作`,
                              icon: /* @__PURE__ */ e(Kt, { size: 16 }),
                              items: F(
                                p.includes(D.id) ? B : [D]
                              ).filter((G) => !G.disabled).map((G) => ({
                                label: G.label,
                                danger: G.danger,
                                onClick: () => G.onSelect?.()
                              }))
                            }
                          )
                        ]
                      }
                    )
                  },
                  D.id
                )),
                re && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: Math.max(
                        0,
                        K.getTotalSize() - (le.at(-1)?.end || 0)
                      ),
                      gridColumn: "1 / -1"
                    }
                  }
                )
              ] }) : /* @__PURE__ */ e("p", { className: "fp-explorer-empty", children: H ? "没有找到匹配的文件" : "文件夹还是空的" }),
              z && /* @__PURE__ */ e(
                "div",
                {
                  "aria-hidden": "true",
                  className: "fp-explorer-selection-box",
                  style: {
                    position: "absolute",
                    left: z.left,
                    top: z.top,
                    width: z.width,
                    height: z.height,
                    pointerEvents: "none"
                  }
                }
              )
            ]
          }
        ) })
      }
    ),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("span", { children: p.length ? `已选择 ${p.length} 项` : `${pe.length} 项` }),
      p.length > 0 && /* @__PURE__ */ e("button", { type: "button", onClick: () => h([]), children: "取消选择" })
    ] })
  ] });
}
function ob({
  items: t,
  selectedIds: n,
  onSelectionChange: r,
  onRestore: i,
  onDelete: a,
  loading: l,
  error: s
}) {
  const [c, u] = k(!1), [d, p] = k(""), h = R(!1), f = async (m, b = !1) => {
    if (!h.current) {
      h.current = !0, u(!0), p("");
      try {
        await (b ? a(m) : i(m));
      } finally {
        h.current = !1, u(!1);
      }
    }
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "回收站" }),
        /* @__PURE__ */ e("small", { children: "还需要的资料可以恢复到原位置。" })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          ye,
          {
            disabled: c || !n.length,
            onAction: () => f(n),
            children: "恢复所选"
          }
        ),
        /* @__PURE__ */ e(
          ye,
          {
            disabled: c || !n.length,
            confirm: "永久删除所选资料后将无法恢复，确认继续？",
            onAction: () => f(n, !0),
            children: "永久删除"
          }
        )
      ] })
    ] }),
    (s || d) && /* @__PURE__ */ e("p", { role: "alert", children: s || d }),
    l ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取回收站…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((m) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ e(
      xt,
      {
        disabled: c,
        items: [
          {
            id: "restore",
            label: "恢复",
            onSelect: () => {
              f([m.id]).catch(
                (b) => p(
                  b instanceof Error ? b.message : "暂时无法恢复，请重试。"
                )
              );
            }
          },
          {
            id: "select",
            label: "选择",
            onSelect: () => r([m.id])
          }
        ],
        children: /* @__PURE__ */ o("div", { className: "fp-recycle-row", children: [
          /* @__PURE__ */ e(
            mi,
            {
              label: "",
              "aria-label": `选择${m.name}`,
              checked: n.includes(m.id),
              disabled: c,
              onChange: () => r(
                n.includes(m.id) ? n.filter((b) => b !== m.id) : [...n, m.id]
              )
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: m.name }),
            /* @__PURE__ */ e("small", { children: m.originalPath })
          ] }),
          /* @__PURE__ */ e("time", { children: m.deletedAt }),
          m.size && /* @__PURE__ */ e("small", { children: m.size })
        ] })
      }
    ) }, m.id)) }) : /* @__PURE__ */ e("p", { children: "回收站是空的。" })
  ] });
}
function sb({
  items: t,
  onReview: n,
  onPreview: r,
  loading: i,
  error: a
}) {
  const [l, s] = k("all"), c = t.filter(
    (u) => l === "all" || u.status === l
  );
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "今日复习" }),
        /* @__PURE__ */ o("small", { children: [
          t.length,
          " 条学习记录"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: !c.length || i,
          onClick: () => n(c.map((u) => u.id)),
          children: "开始复习"
        }
      )
    ] }),
    /* @__PURE__ */ e(
      Ce,
      {
        label: "复习范围",
        value: l,
        onChange: s,
        options: [
          { value: "all", label: "全部记录" },
          { value: "new", label: "初次学习" },
          { value: "learning", label: "正在巩固" },
          { value: "review", label: "定期复习" }
        ]
      }
    ),
    a && /* @__PURE__ */ e("p", { role: "alert", children: a }),
    i ? /* @__PURE__ */ e("p", { role: "status", children: "正在整理复习记录…" }) : /* @__PURE__ */ e("ul", { children: c.map((u) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-review-record",
        onClick: () => r(u.id),
        children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: u.title }),
            /* @__PURE__ */ o("small", { children: [
              u.subject,
              u.detail && ` · ${u.detail}`
            ] })
          ] }),
          /* @__PURE__ */ e("time", { children: u.due })
        ]
      }
    ) }, u.id)) }),
    !i && !c.length && /* @__PURE__ */ e("p", { children: "当前范围没有待复习的记录。" })
  ] });
}
function cb({
  title: t,
  items: n,
  activeId: r,
  onNavigate: i,
  children: a,
  onSubmit: l,
  remainingLabel: s
}) {
  const c = n.filter((u) => u.answered).length;
  return /* @__PURE__ */ o("section", { className: "fp-quiz-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("span", { children: s || `已完成 ${c} / ${n.length} 题` })
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "题目导航", children: n.map((u) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": u.id === r ? "step" : void 0,
        "data-answered": u.answered || void 0,
        onClick: () => i(u.id),
        children: [
          u.label,
          u.flagged && /* @__PURE__ */ e("span", { "aria-label": "已标记", children: " ·" })
        ]
      },
      u.id
    )) }),
    /* @__PURE__ */ e(ge, { children: a }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      ye,
      {
        confirm: c < n.length ? `还有 ${n.length - c} 题未完成，仍要提交？` : "确认提交本次答题？",
        onAction: l,
        children: "提交答题"
      }
    ) })
  ] });
}
function db({
  items: t
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-selection-actions",
      role: "toolbar",
      "aria-label": "所选内容操作",
      children: t.map((n) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n.disabled,
          onMouseDown: (r) => r.preventDefault(),
          onClick: n.onSelect,
          children: n.label
        },
        n.id
      ))
    }
  );
}
function ub({
  title: t,
  detail: n,
  value: r,
  onCancel: i,
  children: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-live": "polite", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      i && /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "取消" })
    ] }),
    n && /* @__PURE__ */ e("p", { children: n }),
    /* @__PURE__ */ e(
      "progress",
      {
        "aria-label": t,
        max: 100,
        value: r === void 0 ? void 0 : Math.min(100, Math.max(0, r))
      }
    ),
    a
  ] });
}
function pb({
  title: t = "打开一份资料，开始学习",
  description: n = "可以从左侧选择笔记，也可以添加新的资料。",
  actions: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-empty", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r })
  ] });
}
function hb({
  title: t,
  status: n,
  actions: r,
  trace: i,
  children: a,
  attachments: l
}) {
  const [s, c] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-run-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] }),
      r
    ] }),
    a,
    l && /* @__PURE__ */ e("aside", { "aria-label": "相关资料", children: l }),
    i && /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": s,
          onClick: () => c((u) => !u),
          children: "工作记录"
        }
      ),
      /* @__PURE__ */ e(je, { isOpen: s, children: i })
    ] })
  ] });
}
function fb({
  title: t,
  frames: n,
  time: r,
  duration: i,
  playing: a,
  onTimeChange: l,
  onPlayingChange: s,
  children: c
}) {
  return /* @__PURE__ */ o("section", { className: "fp-recording-playback", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => s(!a), children: a ? "暂停回放" : "播放回放" })
    ] }),
    /* @__PURE__ */ e("div", { children: c }),
    /* @__PURE__ */ o("label", { children: [
      "回放进度",
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0,
          max: Math.max(0, i),
          step: "0.1",
          value: Math.min(i, Math.max(0, r)),
          onChange: (u) => l(Number(u.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "回放关键帧", children: n.map((u, d) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-current": n.filter((p) => p.time <= r).at(-1) === u ? "step" : void 0,
        onClick: () => l(u.time),
        children: u.label
      },
      d
    )) })
  ] });
}
function mb({
  title: t = "分享与协作",
  access: n,
  search: r,
  onAddMember: i,
  link: a,
  permissionSummary: l
}) {
  const [s, c] = k(!1), [u, d] = k(""), p = R(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-access-panel", "aria-busy": s, children: [
    /* @__PURE__ */ e("h3", { children: t }),
    l,
    n.canManage && /* @__PURE__ */ e(
      wp,
      {
        ...r,
        disabled: s,
        excludedIds: n.members.map((h) => h.id),
        onPick: (h, f) => {
          p.current || (p.current = !0, c(!0), d(""), Promise.resolve().then(() => i(h, f)).catch(
            (m) => d(
              m instanceof Error ? m.message : "暂时无法添加成员，请重试。"
            )
          ).finally(() => {
            p.current = !1, c(!1);
          }));
        }
      }
    ),
    u && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: u }),
    /* @__PURE__ */ e(vp, { ...n }),
    /* @__PURE__ */ e(kp, { ...a, disabled: a.disabled || !n.canManage })
  ] });
}
function bb({
  models: t,
  modelId: n,
  onModelChange: r,
  thinking: i,
  thinkingOptions: a,
  onThinkingChange: l,
  webEnabled: s,
  onWebChange: c,
  disabled: u,
  quota: d,
  children: p
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "对话设置" }),
    /* @__PURE__ */ o("div", { className: "fp-chat-preferences", children: [
      /* @__PURE__ */ o("label", { children: [
        "使用模型",
        /* @__PURE__ */ e(
          Sp,
          {
            groups: t,
            value: n,
            onChange: r,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "思考方式",
        /* @__PURE__ */ e(
          Ce,
          {
            label: "思考方式",
            value: i,
            options: a,
            onChange: l,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ e(
        _p,
        {
          label: "联网查找资料",
          checked: s,
          onChange: c,
          disabled: u
        }
      ),
      d,
      p
    ] })
  ] });
}
function gb({
  explorer: t,
  preview: n,
  previewTitle: r = "资料预览",
  actions: i
}) {
  const [a, l] = k("files");
  return /* @__PURE__ */ o("section", { className: "fp-resource-workspace", children: [
    /* @__PURE__ */ e("div", { className: "fp-resource-mobile-switch", children: /* @__PURE__ */ e(
      Gp,
      {
        value: a,
        onChange: l,
        items: [
          { value: "files", label: "文件" },
          { value: "preview", label: r }
        ]
      }
    ) }),
    /* @__PURE__ */ o("div", { className: "fp-resource-workspace-panes", "data-pane": a, children: [
      /* @__PURE__ */ e("aside", { children: /* @__PURE__ */ e(
        Bp,
        {
          ...t,
          onOpen: (s) => {
            t.onOpen(s), l("preview");
          }
        }
      ) }),
      /* @__PURE__ */ o("section", { "aria-label": r, children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("h3", { children: r }),
          i
        ] }),
        /* @__PURE__ */ e(ge, { children: n })
      ] })
    ] })
  ] });
}
function yb(t, n) {
  const r = document.createElement("header");
  r.style.cssText = "position:fixed;inset:0 0 auto;height:36px;z-index:2147483647";
  const i = r.attachShadow({ mode: "open" });
  i.innerHTML = '<style>:host{color-scheme:inherit}nav{height:36px;display:flex;align-items:center;background:var(--window-bar-background,light-dark(#f5f3f8,#211f26));color:var(--window-bar-color,light-dark(#29252f,#e7e0ed));font:12px system-ui;user-select:none;-webkit-app-region:drag}span{flex:1;padding:0 12px;pointer-events:none}button{width:46px;height:36px;border:0;background:transparent;color:inherit;font:16px system-ui;-webkit-app-region:no-drag;cursor:default}button:hover{background:light-dark(#e2dfe7,#3c3844)}button:focus-visible{outline:2px solid #a78bfa;outline-offset:-3px}button:last-child:hover{background:#c42b1c;color:white}</style><nav aria-label="窗口"><button aria-label="课栈菜单">☰</button><span></span><button aria-label="最小化">−</button><button aria-label="最大化">□</button><button aria-label="关闭窗口">×</button></nav>', i.querySelector("span").textContent = n;
  const a = i.querySelectorAll("button");
  a[0].onclick = () => t.openMenu(), a[1].onclick = () => t.minimize(), a[2].onclick = () => t.toggleMaximize(), a[3].onclick = () => t.closeWindow();
  const l = (c) => {
    a[2].textContent = c.maximized ? "❐" : "□", a[2].setAttribute("aria-label", c.maximized ? "还原窗口" : "最大化"), r.hidden = c.fullscreen, document.documentElement.style.setProperty("--desktop-titlebar-height", c.fullscreen ? "0px" : "36px");
  };
  document.body.prepend(r);
  const s = t.onWindowState(l);
  return t.getWindowState().then(l), () => {
    s(), r.remove();
  };
}
function vb({ maximized: t, fullscreen: n, onMinimize: r, onMaximize: i, onClose: a }) {
  return /* @__PURE__ */ o("div", { className: "fp-window-controls", role: "group", "aria-label": "窗口操作", children: [
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "最小化", onClick: r, children: /* @__PURE__ */ e(jt, { size: 16 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": n ? "退出全屏" : t ? "还原窗口" : "最大化", onClick: i, children: t || n ? /* @__PURE__ */ e(vn, { size: 14 }) : /* @__PURE__ */ e(pn, { size: 14 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭窗口", onClick: a, children: /* @__PURE__ */ e(ke, { size: 18 }) })
  ] });
}
function wb({ enabled: t = !1, as: n = "header", children: r, className: i = "", ...a }) {
  return /* @__PURE__ */ e(n, { ...a, className: `${i}${t ? " fp-window-drag-region" : ""}`, children: r });
}
function kb({ id: t, title: n, brand: r, icon: i, scenes: a, defaultSceneId: l }) {
  const s = ve(), c = t || s, [u, d] = k(l || a[0]?.id), p = a.find((h) => h.id === u) || a[0];
  return p ? /* @__PURE__ */ o(Bt, { className: "fp-product-preview", "aria-label": n, children: [
    /* @__PURE__ */ o("header", { children: [
      i || /* @__PURE__ */ e(Go, { size: 22 }),
      /* @__PURE__ */ e("strong", { children: n }),
      r && /* @__PURE__ */ e("span", { children: r })
    ] }),
    /* @__PURE__ */ e(ii, { id: c, label: "功能预览", items: a.map((h) => ({ value: h.id, label: h.label })), value: p.id, onChange: d }),
    /* @__PURE__ */ e(ge, { children: /* @__PURE__ */ o("div", { className: "fp-product-preview-panel", id: `${c}-panel-${p.id}`, role: "tabpanel", "aria-labelledby": `${c}-tab-${p.id}`, tabIndex: 0, children: [
      /* @__PURE__ */ e(ni, { children: p.eyebrow }),
      /* @__PURE__ */ e("h3", { children: p.title }),
      /* @__PURE__ */ e("p", { children: p.description }),
      /* @__PURE__ */ o("div", { className: "fp-product-preview-callout", children: [
        /* @__PURE__ */ e(Ie, { size: 22 }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: p.callout.title }),
          /* @__PURE__ */ e("p", { children: p.callout.description })
        ] })
      ] }),
      p.metrics && /* @__PURE__ */ e("div", { className: "fp-product-preview-metrics", children: p.metrics.map((h) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { children: h.label }),
        /* @__PURE__ */ e("strong", { children: h.value }),
        h.note && /* @__PURE__ */ e("small", { children: h.note })
      ] }, h.label)) }),
      p.rows && /* @__PURE__ */ e("div", { className: "fp-product-preview-rows", children: p.rows.map((h) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: h.title }),
          /* @__PURE__ */ e("span", { children: h.detail })
        ] }),
        /* @__PURE__ */ e("span", { children: h.value })
      ] }, h.title)) }),
      /* @__PURE__ */ o("footer", { children: [
        /* @__PURE__ */ e("span", { children: p.footnote }),
        p.link && /* @__PURE__ */ o("a", { href: p.link.href, children: [
          p.link.label,
          /* @__PURE__ */ e(Jn, { size: 16 })
        ] })
      ] })
    ] }, p.id) })
  ] }) : null;
}
function jp() {
  const t = () => Array.from(document.querySelectorAll(".VPNavBarMenuGroup")), n = (c) => c.querySelector(":scope > button"), r = (c) => {
    c.dataset.fpDismissed = "";
    const u = n(c);
    u?.getAttribute("aria-expanded") === "true" && u.click();
  }, i = (c) => {
    const u = c.target, d = u.closest(".VPNavBarMenuGroup");
    if (c.key === "Escape") {
      const p = t().filter((h) => n(h)?.getAttribute("aria-expanded") === "true" || h.matches(":hover"));
      if (!p.length) return;
      c.preventDefault(), c.stopPropagation(), p.forEach(r), d && n(d)?.focus();
    } else if (d && u.closest("button") === n(d) && ["Enter", " ", "ArrowDown", "ArrowUp"].includes(c.key) && (delete d.dataset.fpDismissed, c.key.startsWith("Arrow"))) {
      c.preventDefault();
      const p = n(d);
      p?.getAttribute("aria-expanded") !== "true" && p?.click(), queueMicrotask(() => {
        const h = d.querySelectorAll(".menu a[href]");
        (c.key === "ArrowUp" ? h[h.length - 1] : h[0])?.focus();
      });
    }
  }, a = (c) => {
    const u = c.target;
    t().forEach((d) => {
      d.contains(u) ? u.closest("button") === n(d) && delete d.dataset.fpDismissed : r(d);
    });
  }, l = (c) => {
    const u = c.target.closest(".VPNavBarMenuGroup");
    u && !(c.relatedTarget instanceof Node && u.contains(c.relatedTarget)) && delete u.dataset.fpDismissed;
  }, s = () => t().forEach((c) => {
    (n(c)?.getAttribute("aria-expanded") === "true" || c.matches(":hover")) && r(c);
  });
  return document.addEventListener("keydown", i, !0), document.addEventListener("pointerdown", a, !0), document.addEventListener("pointerover", l, !0), window.addEventListener("scroll", s, { passive: !0 }), () => {
    document.removeEventListener("keydown", i, !0), document.removeEventListener("pointerdown", a, !0), document.removeEventListener("pointerover", l, !0), window.removeEventListener("scroll", s), t().forEach((c) => delete c.dataset.fpDismissed);
  };
}
function Nb() {
  const t = jp(), n = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches, r = () => document.querySelector(".VPDoc .content, .VPPage");
  let i, a;
  const l = /* @__PURE__ */ new Map(), s = () => {
    for (const [u, d] of l) u.isConnected || (d.destroy(), l.delete(u));
    for (const u of document.querySelectorAll(".VPNavBarMenu,#VPSidebarNav"))
      l.has(u) || l.set(u, Da(u, u.matches(".VPNavBarMenu") ? { active: ".VPNavBarMenuLink.active,.VPNavBarMenuGroup.active", inset: 12 } : { active: ".VPSidebarItem.level-1.is-active > .item", surface: !0 }));
  }, c = () => {
    s(), a?.disconnect();
    const u = document.querySelectorAll("[data-fp-reveal]");
    if (n() || !("IntersectionObserver" in window)) {
      u.forEach((d) => {
        d.dataset.fpReveal = "visible";
      });
      return;
    }
    a = new IntersectionObserver((d) => {
      for (const p of d) p.isIntersecting && (p.target.dataset.fpReveal = "visible", a?.unobserve(p.target));
    }, { threshold: 0.08 }), u.forEach((d) => {
      d.dataset.fpReveal !== "visible" && a?.observe(d);
    });
  };
  return {
    begin() {
      i?.cancel(), n() || (i = r()?.animate([{ opacity: 1, transform: "translateY(0)" }, { opacity: 0.25, transform: "translateY(-6px)" }], { duration: 160, easing: "cubic-bezier(.4,0,1,1)" }));
    },
    complete() {
      i?.cancel(), n() || (i = r()?.animate([{ opacity: 0, transform: "translateY(12px)" }, { opacity: 1, transform: "translateY(0)" }], { duration: 440, easing: "cubic-bezier(.16,1,.3,1)" })), c();
    },
    reveal: c,
    destroy() {
      t(), i?.cancel(), a?.disconnect(), l.forEach((u) => u.destroy()), l.clear();
    }
  };
}
function xb({ name: t, description: n, avatarUrl: r, items: i, onSelect: a, busy: l = !1 }) {
  const [s, c] = k(""), u = r && s !== r ? /* @__PURE__ */ e("img", { src: r, alt: "", referrerPolicy: "no-referrer", onError: () => c(r) }) : t.trim().slice(0, 1).toUpperCase() || "我";
  return /* @__PURE__ */ e("span", { className: "fp-account-menu-anchor", children: /* @__PURE__ */ e(Xe, { label: "账号与设置", menu: !0, className: "fp-account-menu", disabled: l, trigger: /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: u }), children: (d) => /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ o("div", { className: "fp-account-menu-identity", children: [
      /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: u }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: t }),
        n && /* @__PURE__ */ e("small", { children: n })
      ] })
    ] }),
    i.map((p) => /* @__PURE__ */ e("div", { className: p.separator ? "fp-account-menu-group" : void 0, children: /* @__PURE__ */ o("button", { type: "button", role: "menuitem", disabled: p.disabled, className: p.danger ? "fp-error-text" : void 0, onClick: () => {
      d(), a(p.id);
    }, children: [
      p.icon,
      /* @__PURE__ */ e("span", { children: p.label }),
      (p.detail || p.shortcut) && /* @__PURE__ */ e("small", { children: p.detail || p.shortcut })
    ] }) }, p.id))
  ] }) }) });
}
function Cb({ label: t, value: n, options: r, onChange: i }) {
  const a = ve();
  return /* @__PURE__ */ o("fieldset", { className: "fp-choice-cards", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    r.map((l) => /* @__PURE__ */ o("label", { "data-selected": n === l.value, "data-disabled": l.disabled || void 0, children: [
      /* @__PURE__ */ e("input", { type: "radio", name: a, value: l.value, checked: n === l.value, disabled: l.disabled, onChange: () => i(l.value) }),
      l.icon && /* @__PURE__ */ e("span", { className: "fp-choice-card-icon", "aria-hidden": "true", children: l.icon }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: l.title }),
        /* @__PURE__ */ e("small", { children: l.description })
      ] })
    ] }, l.value))
  ] });
}
function Sb({ brand: t, headerActions: n, serviceName: r, request: i, completed: a, onDone: l, doneLabel: s = "返回应用", codeEntry: c, selectedIds: u = [], onSelectionChange: d, onApprove: p, onCancel: h, connections: f = [], onRevoke: m, loading: b, busy: g, error: v, onRetry: w }) {
  const [y, N] = k(""), [x, C] = k(!1), z = Ke(() => i?.items.filter((E) => E.title.toLocaleLowerCase().includes(y.trim().toLocaleLowerCase())) || [], [y, i?.items]), L = new Set(u), j = z.length > 0 && z.every((E) => L.has(E.id)), M = i?.kind === "full-access", A = i?.kind === "task", O = i?.kind === "change", U = A || O ? "内容" : "笔记本", T = () => d?.(j ? u.filter((E) => !z.some((S) => S.id === E)) : [.../* @__PURE__ */ new Set([...u, ...z.map((E) => E.id)])]);
  return /* @__PURE__ */ o("div", { className: "fp-application-access", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#access-main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-access-header", children: [
      /* @__PURE__ */ e("div", { children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "账号与外观", children: n })
    ] }),
    /* @__PURE__ */ e("main", { id: "access-main", className: i ? "fp-access-main" : "fp-access-main fp-access-management", children: b ? /* @__PURE__ */ o("section", { className: "fp-access-loading", role: "status", children: [
      /* @__PURE__ */ e(ri, { size: 28 }),
      /* @__PURE__ */ e("h1", { children: "正在读取连接信息" }),
      /* @__PURE__ */ e("p", { children: "请稍候，马上就好。" })
    ] }) : a ? /* @__PURE__ */ o("section", { className: "fp-access-card fp-access-completed", role: "status", children: [
      /* @__PURE__ */ e(ct, { size: 40, "aria-hidden": "true" }),
      /* @__PURE__ */ e("h1", { children: a.title }),
      /* @__PURE__ */ e("p", { children: a.description }),
      l && /* @__PURE__ */ e(te, { onClick: l, children: s })
    ] }) : i ? /* @__PURE__ */ o("section", { className: "fp-access-card", "aria-labelledby": "access-title", children: [
      /* @__PURE__ */ o("header", { className: "fp-access-intro", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-symbols", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(et, { size: 28 }) }),
          /* @__PURE__ */ e(Jn, { size: 20 }),
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(ft, { size: 26 }) })
        ] }),
        /* @__PURE__ */ o("p", { className: "fp-eyebrow", children: [
          r,
          " · 应用授权"
        ] }),
        /* @__PURE__ */ e("h1", { id: "access-title", children: M ? `允许 ${i.name} 获得完全权限？` : O ? `确认 ${i.name} 的修改？` : A ? `允许 ${i.name} 完成这项任务？` : `允许 ${i.name} 连接${r}？` }),
        /* @__PURE__ */ e("p", { children: i.purpose || (O ? "查看具体变更，确认后助手将继续执行。" : A ? "助手申请以下内容和操作，确认后即可继续。" : "选择允许访问的笔记本，让它在你指定的范围内提供帮助。") }),
        i.returnLabel && /* @__PURE__ */ o("p", { className: "fp-access-return", children: [
          "完成后返回 ",
          i.returnLabel
        ] })
      ] }),
      i.permissions.length > 0 && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ e("h2", { children: "允许的操作" }),
        /* @__PURE__ */ e("ul", { className: "fp-access-permissions", children: i.permissions.map((E) => /* @__PURE__ */ o("li", { children: [
          /* @__PURE__ */ e(ct, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("strong", { children: E.label }),
            E.description && /* @__PURE__ */ e("p", { children: E.description })
          ] })
        ] }, E.label)) })
      ] }),
      (!i.allowEmptySelection || i.items.length > 0) && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-section-heading", children: [
          /* @__PURE__ */ e("h2", { children: A ? "申请访问的内容" : O ? "本次修改" : "选择笔记本" }),
          /* @__PURE__ */ o("span", { role: "status", children: [
            "已选 ",
            u.length,
            " 项"
          ] })
        ] }),
        /* @__PURE__ */ o("label", { className: "fp-access-search", children: [
          /* @__PURE__ */ e(Ue, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ e("input", { className: "fp-input", "aria-label": `搜索${U}`, placeholder: `搜索${U}`, value: y, onChange: (E) => N(E.target.value) })
        ] }),
        i.items.length > 0 ? /* @__PURE__ */ o(ee, { children: [
          /* @__PURE__ */ o("div", { className: "fp-access-select", children: [
            /* @__PURE__ */ e("span", { children: y ? `找到 ${z.length} 项内容` : `只访问你选中的${U}` }),
            !O && /* @__PURE__ */ e(te, { variant: "ghost", disabled: g || !z.length, onClick: T, children: j ? "取消全选" : "全选" })
          ] }),
          /* @__PURE__ */ o("fieldset", { className: "fp-access-items", disabled: g, children: [
            /* @__PURE__ */ e("legend", { className: "fp-visually-hidden", children: "可访问的内容" }),
            z.map((E) => /* @__PURE__ */ o("label", { "data-selected": L.has(E.id), children: [
              /* @__PURE__ */ e("input", { type: "checkbox", disabled: O, checked: L.has(E.id), onChange: (S) => d?.(S.target.checked ? [...u, E.id] : u.filter((P) => P !== E.id)) }),
              /* @__PURE__ */ e(et, { size: 19, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { className: "fp-access-item-copy", children: [
                /* @__PURE__ */ e("strong", { children: E.title }),
                E.detail && /* @__PURE__ */ e("small", { children: E.detail }),
                E.permissions && /* @__PURE__ */ e("small", { children: E.permissions.join("、") })
              ] }),
              L.has(E.id) && /* @__PURE__ */ e(ct, { size: 18, "aria-hidden": "true" })
            ] }, E.id)),
            z.length === 0 && /* @__PURE__ */ e("p", { className: "fp-access-empty", children: "没有找到匹配的内容，试试其他名称。" })
          ] })
        ] }) : /* @__PURE__ */ o("p", { className: "fp-access-empty", children: [
          "当前没有可授权的内容，请先在",
          r,
          "取得访问权限。"
        ] })
      ] }),
      i.changes && /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: "查看正文变化" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: i.changes.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: i.changes.after })
          ] })
        ] })
      ] }),
      i.changeSet?.map((E, S) => /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: E.title }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: E.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: E.after })
          ] })
        ] })
      ] }, S)),
      /* @__PURE__ */ o("aside", { className: "fp-access-notice", children: [
        /* @__PURE__ */ e(Yr, { size: 21, "aria-hidden": "true" }),
        /* @__PURE__ */ e("p", { children: i.notice || "授权有效期为 30 天，包含所选笔记本中后续新增的内容。你可以随时在“外部连接”撤销访问。" })
      ] }),
      v && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: v }),
        w && /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: w, children: "重试" })
      ] }),
      /* @__PURE__ */ o("footer", { className: "fp-access-actions", children: [
        /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: h, children: "取消" }),
        /* @__PURE__ */ e(te, { "aria-label": M ? "继续" : O ? "确认修改" : A ? "同意并继续" : "允许连接", loading: g, disabled: b || !i.allowEmptySelection && !u.length, onClick: () => M ? C(!0) : p?.(), children: M ? "继续" : O ? "确认修改" : A ? "同意并继续" : "允许连接" })
      ] }),
      M && /* @__PURE__ */ o(Ye, { open: x && !a, onClose: () => !g && C(!1), dismissible: !g, title: i.confirmation?.title || "确认授予完全权限", footer: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: () => C(!1), children: "返回" }),
        /* @__PURE__ */ e(te, { loading: g, onClick: p, children: i.confirmation?.confirmLabel || "允许完全权限" })
      ] }), children: [
        /* @__PURE__ */ e("p", { children: i.confirmation?.description || i.notice }),
        v && /* @__PURE__ */ e("p", { role: "alert", children: v })
      ] })
    ] }) : /* @__PURE__ */ o(ee, { children: [
      c && /* @__PURE__ */ o("form", { className: "fp-access-device-entry", onSubmit: (E) => {
        E.preventDefault(), c.onSubmit();
      }, children: [
        /* @__PURE__ */ e("label", { htmlFor: "access-device-code", children: "连接新设备" }),
        /* @__PURE__ */ e("p", { children: "输入终端中显示的设备代码。" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("input", { className: "fp-input", id: "access-device-code", value: c.value, onChange: (E) => c.onChange(E.target.value), placeholder: "ABCD-EFGH", autoComplete: "off", spellCheck: !1, maxLength: 9 }),
          /* @__PURE__ */ e(te, { type: "submit", disabled: c.value.replace(/-/g, "").trim().length !== 8, children: "继续" })
        ] })
      ] }),
      /* @__PURE__ */ o("header", { className: "fp-access-list-heading", children: [
        /* @__PURE__ */ e("span", { className: "fp-access-list-icon", children: /* @__PURE__ */ e(ft, { size: 28 }) }),
        /* @__PURE__ */ e("h1", { children: "已连接的应用" }),
        /* @__PURE__ */ o("p", { children: [
          "查看哪些应用可以访问你的",
          r,
          "内容，并随时管理连接。"
        ] })
      ] }),
      v && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        v,
        w && /* @__PURE__ */ e(te, { variant: "secondary", onClick: w, children: "重试" })
      ] }),
      f.length ? /* @__PURE__ */ e("div", { className: "fp-access-connections", children: f.map((E) => /* @__PURE__ */ o("section", { className: "fp-access-connection", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-connection-title", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(ft, { size: 22 }) }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("h2", { children: E.name }),
            /* @__PURE__ */ e("p", { "data-status": E.status, children: E.status === "active" ? "已连接" : E.status === "revoked" ? "已撤销" : "已过期" })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { children: E.permissions }),
        /* @__PURE__ */ e("p", { className: "fp-access-detail", children: E.detail }),
        E.status === "active" && /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: () => m?.(E.id), children: "撤销连接" })
      ] }, E.id)) }) : !v && /* @__PURE__ */ o("section", { className: "fp-access-empty-state", children: [
        /* @__PURE__ */ e(et, { size: 32 }),
        /* @__PURE__ */ e("h2", { children: "从第一个连接开始" }),
        /* @__PURE__ */ e("p", { children: "通过 CLI 或支持的 AI 助手发起连接，授权后会显示在这里。" })
      ] })
    ] }) })
  ] });
}
function Mb({ brand: t, showStatusIcon: n = !0, preview: r, productIcon: i, headerActions: a, onDrag: l, phase: s, transitionKey: c, title: u, description: d, version: p, progress: h, progressLabel: f, detail: m, children: b, actions: g, footer: v }) {
  const w = s + ":" + (c || ""), y = R(null), N = R(w);
  Y(() => {
    if (N.current === w) return;
    N.current = w;
    const j = y.current;
    if (!j || typeof j.animate != "function" || window.matchMedia?.("(prefers-reduced-motion:reduce)").matches) return;
    const M = j.animate([{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }], { duration: 320, easing: "cubic-bezier(.22,1,.36,1)" });
    return () => M.cancel();
  }, [w]);
  const x = ["checking", "verifying", "installing"].includes(s), C = s === "downloading" && Number.isFinite(h), z = Math.max(0, Math.min(100, C ? h : 0)), L = f || (s === "checking" ? "正在连接下载服务" : s === "verifying" ? "正在检查文件完整性" : s === "installing" ? "正在安装到此电脑" : "正在下载");
  return /* @__PURE__ */ o("div", { className: "fp-installer", "data-phase": s, "data-preview": !!r, children: [
    /* @__PURE__ */ o("header", { onMouseDown: (j) => {
      j.target.closest("button,a,input") || l?.();
    }, children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: a })
    ] }),
    /* @__PURE__ */ o("main", { children: [
      r && /* @__PURE__ */ e("aside", { className: "fp-installer-preview", children: r }),
      /* @__PURE__ */ o("section", { ref: y, className: "fp-installer-content", children: [
        /* @__PURE__ */ o("div", { className: "fp-installer-heading", children: [
          n && /* @__PURE__ */ e("div", { className: "fp-installer-art", "aria-hidden": "true", children: s === "ready" && i ? i : x ? /* @__PURE__ */ e(Ut, { size: 28 }) : s === "done" ? /* @__PURE__ */ e(ct, { size: 28 }) : s === "error" || s === "confirm" ? /* @__PURE__ */ e(Xr, { size: 28 }) : s === "downloading" ? /* @__PURE__ */ e(Tn, { size: 28 }) : /* @__PURE__ */ e(Yo, { size: 28 }) }),
          /* @__PURE__ */ o("div", { children: [
            p && /* @__PURE__ */ o("p", { className: "fp-installer-version", children: [
              "版本 ",
              p
            ] }),
            /* @__PURE__ */ e("h1", { children: u })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { className: "fp-installer-description", role: s === "error" ? "alert" : "status", children: d }),
        (x || s === "downloading") && /* @__PURE__ */ o("div", { className: "fp-installer-progress", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("span", { children: L }),
            C && /* @__PURE__ */ o("strong", { children: [
              Math.round(z),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": s === "downloading" ? "安装文件下载进度" : L, "data-indeterminate": !C, "aria-valuenow": C ? z : void 0, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: C ? { width: `${z}%` } : void 0 }) })
        ] }),
        m && /* @__PURE__ */ e("p", { className: "fp-installer-detail", children: m }),
        b,
        /* @__PURE__ */ e("div", { className: "fp-installer-actions", children: g })
      ] })
    ] }),
    v && /* @__PURE__ */ e("footer", { children: v })
  ] });
}
function Eb({ cards: t, activeId: n, onSelect: r }) {
  const i = t.find((d) => d.id === n) || t[0], a = R(i?.id), [l, s] = k();
  if (Y(() => {
    if (!i || a.current === i.id) return;
    s(a.current), a.current = i.id;
    const d = setTimeout(() => s(void 0), 650);
    return () => clearTimeout(d);
  }, [i?.id]), !i) return null;
  const c = t.find((d) => d.id === l), u = (d) => /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-feature-card-copy", children: [
      /* @__PURE__ */ e("h2", { children: d.title }),
      /* @__PURE__ */ e("p", { children: d.description })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-preview", children: d.children })
  ] });
  return /* @__PURE__ */ o("section", { className: "fp-feature-stack", "aria-label": "产品功能预览", children: [
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back", "aria-hidden": "true" }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back fp-feature-card-back-second", "aria-hidden": "true" }),
    c && /* @__PURE__ */ e("article", { className: "fp-feature-card-out", "aria-hidden": "true", children: u(c) }, "out-" + c.id),
    /* @__PURE__ */ e("article", { className: "fp-feature-card-front", "data-motion": i.motion, "aria-label": i.title, children: u(i) }, i.id),
    /* @__PURE__ */ e("footer", { "aria-hidden": r ? void 0 : !0, role: r ? "group" : void 0, "aria-label": r ? "产品卡片切换" : void 0, children: t.map((d) => r ? /* @__PURE__ */ e("button", { type: "button", "aria-label": "查看" + d.label, "aria-pressed": d.id === i.id, onClick: () => r(d.id), children: /* @__PURE__ */ e("i", { "data-active": d.id === i.id, "aria-hidden": "true" }) }, d.id) : /* @__PURE__ */ e("i", { "data-active": d.id === i.id }, d.id)) })
  ] });
}
function $b({ brand: t, navigation: n, actions: r, groups: i, currentPath: a, outline: l = [], children: s, footer: c, wide: u = !1 }) {
  const d = R(null), [p, h] = k(!1);
  Y(() => {
    if (!p) return;
    const g = document.body.style.overflow;
    return document.body.style.overflow = "hidden", () => {
      document.body.style.overflow = g;
    };
  }, [p]);
  const f = i.filter((g) => g.prefix ? a.startsWith(g.prefix) : g.links.some((v) => v.href === a)), m = f.length ? f : i.filter((g) => !g.prefix), b = /* @__PURE__ */ e("nav", { "aria-label": "文档章节", children: m.map((g) => /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h2", { children: g.label }),
    g.links.map((v) => /* @__PURE__ */ e("a", { href: v.href, "aria-current": v.href === a ? "page" : void 0, children: v.label }, v.href))
  ] }, g.label)) });
  return /* @__PURE__ */ o("div", { className: "fp-docs", "data-wide": u || void 0, children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-docs-header", children: [
      /* @__PURE__ */ e("div", { className: "fp-docs-brand", children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "主导航", children: n }),
      /* @__PURE__ */ o("div", { className: "fp-docs-actions", children: [
        r,
        /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "打开文档目录", className: "fp-docs-menu", onClick: () => {
          d.current?.showModal(), h(!0);
        }, children: /* @__PURE__ */ e(un, { size: 20 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("dialog", { ref: d, onClose: () => h(!1), className: "fp-docs-drawer", onClick: (g) => {
      g.target === g.currentTarget && d.current?.close();
    }, children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: "文档目录" }),
        /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "关闭文档目录", onClick: () => d.current?.close(), children: /* @__PURE__ */ e(ke, { size: 20 }) })
      ] }),
      /* @__PURE__ */ e("nav", { className: "fp-docs-section-nav", "aria-label": "选择文档分区", children: n }),
      b,
      l.length > 0 && /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ e("summary", { children: "本页目录" }),
        l.map((g) => /* @__PURE__ */ e("a", { href: g.href, onClick: () => d.current?.close(), children: g.label }, g.href))
      ] })
    ] }),
    !u && /* @__PURE__ */ o("div", { className: "fp-docs-mobile-bar", children: [
      /* @__PURE__ */ o(te, { variant: "ghost", onClick: () => {
        d.current?.showModal(), h(!0);
      }, children: [
        /* @__PURE__ */ e(un, { size: 16 }),
        m[0]?.label || "文档目录"
      ] }),
      l.length > 0 && /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ o("summary", { children: [
          /* @__PURE__ */ e(dn, { size: 16 }),
          "本页目录"
        ] }),
        /* @__PURE__ */ e("nav", { children: l.map((g) => /* @__PURE__ */ e("a", { href: g.href, onClick: (v) => v.currentTarget.closest("details")?.removeAttribute("open"), children: g.label }, g.href)) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-docs-grid", children: [
      !u && /* @__PURE__ */ e("aside", { className: "fp-docs-sidebar", children: b }),
      /* @__PURE__ */ e("main", { id: "main", className: "fp-docs-main", children: s }),
      !u && l.length > 0 && /* @__PURE__ */ e("aside", { className: "fp-docs-outline", children: /* @__PURE__ */ o("nav", { "aria-label": "本页目录", children: [
        /* @__PURE__ */ e("strong", { children: "本页目录" }),
        l.map((g) => /* @__PURE__ */ e("a", { href: g.href, children: g.label }, g.href))
      ] }) })
    ] }),
    c && /* @__PURE__ */ e("footer", { className: "fp-docs-footer", children: c })
  ] });
}
function zb({ items: t, label: n = "浏览文档" }) {
  const [r, i] = k(""), a = t.filter((l) => (l.label + " " + (l.description || "")).toLocaleLowerCase().includes(r.trim().toLocaleLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-docs-directory", "aria-label": n, children: [
    /* @__PURE__ */ o("label", { children: [
      n,
      /* @__PURE__ */ e("input", { type: "search", value: r, onChange: (l) => i(l.target.value), placeholder: "输入名称查找" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-docs-cards", children: a.map((l) => /* @__PURE__ */ o("a", { href: l.href, children: [
      /* @__PURE__ */ e("strong", { children: l.label }),
      l.description && /* @__PURE__ */ e("span", { children: l.description }),
      /* @__PURE__ */ e("span", { children: "阅读指南 →" })
    ] }, l.href)) }),
    !a.length && /* @__PURE__ */ e("p", { role: "status", children: "没有找到相关内容，请换个名称试试。" })
  ] });
}
function Ab({ size: t = 32, decorative: n = !1, label: r = "AI 批改助手" }) {
  const i = ve();
  return /* @__PURE__ */ o("svg", { width: t, height: t, viewBox: "0 0 40 40", fill: "none", role: n ? void 0 : "img", "aria-hidden": n || void 0, "aria-labelledby": n ? void 0 : i, style: { flexShrink: 0 }, children: [
    !n && /* @__PURE__ */ e("title", { id: i, children: r }),
    /* @__PURE__ */ e("rect", { x: "2", y: "2", width: "36", height: "36", rx: "11", fill: "var(--fp-action,#13795B)" }),
    /* @__PURE__ */ e("path", { d: "M12 10h12l5 5v15H12V10Z", stroke: "var(--fp-on-action,#FFFFFF)", strokeWidth: "2", strokeLinejoin: "round" }),
    /* @__PURE__ */ e("path", { d: "M24 10v6h5M16 23l3 3 6-7", stroke: "var(--fp-on-action,#FFFFFF)", strokeWidth: "2.4", strokeLinecap: "round", strokeLinejoin: "round" }),
    /* @__PURE__ */ e("path", { d: "m31 3 1.5 3.5L36 8l-3.5 1.5L31 13l-1.5-3.5L26 8l3.5-1.5L31 3Z", fill: "#FD8B07", stroke: "var(--fp-bg,#FFFFFF)", strokeWidth: "1.2" })
  ] });
}
function qp(t, n) {
  const r = n.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return r.length ? t.map((i) => {
    const a = (i.title + " " + (i.heading || "")).toLocaleLowerCase(), l = i.text.toLocaleLowerCase(), s = r.reduce((c, u) => c + (a.includes(u) ? 30 : 0) + (l.includes(u) ? 1 : 0), 0);
    return { entry: i, score: s, match: r.every((c) => a.includes(c) || l.includes(c)) };
  }).filter((i) => i.match).sort((i, a) => a.score - i.score).slice(0, 30).map((i) => i.entry) : [];
}
function Lb({ open: t, onClose: n, entries: r, loading: i, error: a, onRetry: l, initialQuery: s = "" }) {
  const c = R(null), u = R(null), [d, p] = k(s), [h, f] = k(0), m = Ke(() => qp(r, d), [r, d]);
  Y(() => {
    if (t)
      return c.current?.showModal(), u.current?.focus(), () => {
        c.current?.close();
      };
  }, [t]), Y(() => {
    f(0);
  }, [d]), Y(() => {
    s && p(s);
  }, [s]), Y(() => {
    c.current?.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: "nearest" });
  }, [h]);
  const b = (g) => {
    const v = d.trim();
    if (!v) return g;
    const w = g.toLocaleLowerCase().indexOf(v.toLocaleLowerCase());
    return w < 0 ? g : /* @__PURE__ */ o(ee, { children: [
      g.slice(0, w),
      /* @__PURE__ */ e("mark", { children: g.slice(w, w + v.length) }),
      g.slice(w + v.length)
    ] });
  };
  return /* @__PURE__ */ o("dialog", { ref: c, className: "fp-docs-search", "aria-label": "搜索文档", onClose: n, onClick: (g) => {
    g.target === g.currentTarget && n();
  }, children: [
    /* @__PURE__ */ o("div", { className: "fp-docs-search-field", children: [
      /* @__PURE__ */ e(Ue, { size: 22 }),
      /* @__PURE__ */ e("input", { ref: u, "aria-label": "搜索关键词", role: "combobox", "aria-expanded": !!m.length, "aria-controls": "docs-search-results", "aria-activedescendant": m.length ? "docs-result-" + h : void 0, autoComplete: "off", placeholder: "搜索教程、平台和常见问题", value: d, onChange: (g) => p(g.target.value), onKeyDown: (g) => {
        (g.key === "ArrowDown" || g.key === "ArrowUp") && (g.preventDefault(), f((v) => m.length ? (v + (g.key === "ArrowDown" ? 1 : -1) + m.length) % m.length : 0)), g.key === "Enter" && !g.nativeEvent.isComposing && m[h] && window.location.assign(m[h].url);
      } }),
      d && /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "清空搜索", onClick: () => {
        p(""), u.current?.focus();
      }, children: /* @__PURE__ */ e(ke, { size: 16 }) }),
      /* @__PURE__ */ e(te, { variant: "ghost", onClick: n, "aria-label": "关闭搜索", children: "关闭" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-docs-search-results", id: "docs-search-results", role: "listbox", "aria-label": "搜索结果", "aria-busy": i, children: a ? /* @__PURE__ */ o("div", { className: "fp-docs-search-empty", role: "alert", children: [
      "搜索暂时无法加载。",
      /* @__PURE__ */ e(te, { onClick: l, children: "重新加载" })
    ] }) : i ? /* @__PURE__ */ e("p", { className: "fp-docs-search-empty", role: "status", children: "正在准备搜索…" }) : d.trim() ? m.length ? m.map((g, v) => {
      const w = Math.max(0, g.text.toLocaleLowerCase().indexOf(d.trim().toLocaleLowerCase()) - 36);
      return /* @__PURE__ */ o("a", { role: "option", "aria-selected": v === h, id: "docs-result-" + v, className: "fp-docs-search-result", href: g.url, onMouseEnter: () => f(v), children: [
        /* @__PURE__ */ o("small", { children: [
          g.group,
          " / ",
          g.title
        ] }),
        /* @__PURE__ */ o("strong", { children: [
          /* @__PURE__ */ e("span", { children: b(g.heading || g.title) }),
          /* @__PURE__ */ e(_r, { size: 16 })
        ] }),
        /* @__PURE__ */ e("span", { children: b(g.text.slice(w, w + 130)) })
      ] }, g.url);
    }) : /* @__PURE__ */ e("p", { className: "fp-docs-search-empty", role: "status", children: "没有找到相关内容，试试更简短的关键词。" }) : /* @__PURE__ */ o("div", { className: "fp-docs-search-empty", children: [
      /* @__PURE__ */ e("strong", { children: "你想了解什么？" }),
      /* @__PURE__ */ e("p", { children: "试试搜索「安装」「API 密钥」或你的阅卷平台。" }),
      /* @__PURE__ */ e("div", { children: ["安装", "API 密钥", "评分标准", "智学网"].map((g) => /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => {
        p(g), u.current?.focus();
      }, children: g }, g)) })
    ] }) }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("span", { role: "status", children: d.trim() && !i && !a ? `${m.length} 条相关结果` : "搜索全部文档" }),
      /* @__PURE__ */ e("span", { children: "↑ ↓ 选择 · Enter 打开 · Esc 关闭" })
    ] })
  ] });
}
function Ib({ eyebrow: t, title: n, statement: r, description: i, actions: a, meta: l, preview: s, pattern: c = "CREATE" }) {
  return /* @__PURE__ */ o("section", { className: "fp-statement-hero", "data-layout": s ? "split" : "centered", children: [
    /* @__PURE__ */ e("div", { className: "fp-statement-pattern", "aria-hidden": "true", children: Array.from({ length: 4 }, (u, d) => /* @__PURE__ */ e("div", { children: Array.from({ length: 4 }, (p, h) => /* @__PURE__ */ e("span", { children: c }, h)) }, d)) }),
    /* @__PURE__ */ e("div", { className: "fp-statement-scan", "aria-hidden": "true" }),
    /* @__PURE__ */ o("div", { className: "fp-statement-copy", children: [
      /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      /* @__PURE__ */ e("p", { className: "fp-statement-subtitle", children: r }),
      /* @__PURE__ */ e("p", { className: "fp-statement-description", children: i }),
      /* @__PURE__ */ e("div", { className: "fp-statement-actions", children: a })
    ] }),
    l && /* @__PURE__ */ e("div", { className: "fp-statement-meta", "aria-label": "核心能力", children: l }),
    s && /* @__PURE__ */ e("div", { className: "fp-statement-preview", children: s })
  ] });
}
function Db({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-editorial-sections", children: t });
}
function Tb({ kind: t, children: n, label: r }) {
  return /* @__PURE__ */ e("section", { className: "fp-editorial-panel" + (t ? " fp-editorial-panel--" + t : ""), "aria-label": r, children: n });
}
const Fe = (t) => String(t).replace(/[&<>"']/g, (n) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[n]), Cr = (t = []) => t.map((n) => `<span id="${Fe(n)}" class="fp-release-anchor" aria-hidden="true"></span>`).join("");
function Kp({ version: t, versionId: n, date: r, badge: i, description: a, groups: l, emptyMessage: s = "暂无新增更新", history: c = [], historyLabel: u = "历史稳定版本", anchors: d = [] }) {
  const p = l.filter((f) => f.items.length).map((f) => `<section class="fp-release-group"><h3>${Fe(f.title)}</h3><ul>${f.items.map((m) => `<li${m.id ? ` id="${Fe(m.id)}"` : ""}>${Cr(m.aliases)}${Fe(m.text)}</li>`).join("")}</ul></section>`).join(""), h = c.length ? `<details class="fp-release-archive"><summary>${Fe(u)}<span>${c.length}</span></summary><div>${c.map((f) => `<details class="fp-release-history-item"${f.id ? ` id="${Fe(f.id)}"` : ""}><summary><strong>v${Fe(f.version)}</strong>${f.date ? `<time>${Fe(f.date)}</time>` : ""}</summary>${Cr(f.aliases)}<ul>${f.items.map((m) => `<li>${Fe(m)}</li>`).join("")}</ul></details>`).join("")}</div></details>` : "";
  return `<article class="fp-release-notes">${Cr(d)}<header><div><strong${n ? ` id="${Fe(n)}"` : ""}>v${Fe(t)}</strong><span class="fp-release-badge">${Fe(i)}</span></div>${r ? `<time datetime="${Fe(r)}">${Fe(r)}</time>` : ""}<p>${Fe(a)}</p></header><div class="fp-release-groups">${p || `<p class="fp-release-empty">${Fe(s)}</p>`}</div>${h}</article>`;
}
function Pb(t) {
  return /* @__PURE__ */ e("div", { dangerouslySetInnerHTML: { __html: Kp(t) } });
}
function Fb({ variant: t = "primary", size: n = "md", className: r = "", ...i }) {
  return /* @__PURE__ */ e("a", { ...i, className: `fp-button fp-button-link fp-${t} fp-${n} ${r}` });
}
function Ob({ brand: t, eyebrow: n, title: r, description: i, benefits: a = [], children: l, actions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-app-entry", children: [
    /* @__PURE__ */ o("section", { className: "fp-app-entry-story", children: [
      /* @__PURE__ */ e("div", { className: "fp-app-entry-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-app-entry-copy", children: [
        n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
        /* @__PURE__ */ e("h1", { children: r }),
        /* @__PURE__ */ e("p", { children: i }),
        /* @__PURE__ */ e("ul", { children: a.map((u) => /* @__PURE__ */ o("li", { children: [
          u.icon,
          /* @__PURE__ */ e("span", { children: u.label })
        ] }, u.label)) })
      ] }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-app-entry-panel", children: [
      s && /* @__PURE__ */ e("div", { className: "fp-app-entry-window", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-app-entry-content", children: l })
    ] })
  ] });
}
function Rb({ brand: t, title: n, description: r, tone: i = "neutral", children: a, actions: l, headerActions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-status-page", children: [
    /* @__PURE__ */ o("header", { className: "fp-status-page-header", children: [
      t,
      /* @__PURE__ */ e("div", { children: s })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-status-card", "data-tone": i, "aria-labelledby": "status-heading", children: [
      /* @__PURE__ */ e("div", { className: "fp-status-symbol", "aria-hidden": "true", children: i === "success" ? /* @__PURE__ */ e(ct, { size: 32 }) : i === "loading" ? /* @__PURE__ */ e(Ut, { size: 32 }) : /* @__PURE__ */ e(Xr, { size: 32 }) }),
      /* @__PURE__ */ e("h1", { id: "status-heading", children: n }),
      /* @__PURE__ */ e("p", { className: "fp-status-description", role: i === "error" ? "alert" : "status", children: r }),
      a,
      l && /* @__PURE__ */ e("div", { className: "fp-status-actions", children: l }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] })
  ] });
}
function Bb({ brand: t, navigation: n, headerActions: r, eyebrow: i, title: a, description: l, actions: s, meta: c, preview: u, children: d, footer: p }) {
  return /* @__PURE__ */ o("div", { className: "fp-product-landing", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ e("header", { className: "fp-product-header", children: /* @__PURE__ */ o("div", { className: "fp-product-header-inner", children: [
      t,
      /* @__PURE__ */ e("nav", { "aria-label": "页面导航", children: n }),
      /* @__PURE__ */ e("div", { className: "fp-product-header-actions", children: r })
    ] }) }),
    /* @__PURE__ */ o("main", { id: "main", children: [
      /* @__PURE__ */ o("section", { className: "fp-product-hero", children: [
        /* @__PURE__ */ o("div", { className: "fp-product-hero-copy", children: [
          i && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: i }),
          /* @__PURE__ */ e("h1", { children: a }),
          /* @__PURE__ */ e("p", { className: "fp-product-description", children: l }),
          /* @__PURE__ */ e("div", { className: "fp-product-actions", children: s }),
          c && /* @__PURE__ */ e("div", { className: "fp-product-meta", children: c })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-product-preview", children: u })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("footer", { className: "fp-product-footer", children: p })
  ] });
}
function jb({ id: t, eyebrow: n, title: r, description: i, children: a }) {
  return /* @__PURE__ */ o("section", { id: t, className: "fp-product-section", children: [
    /* @__PURE__ */ o("header", { children: [
      n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
      /* @__PURE__ */ e("h2", { children: r }),
      i && /* @__PURE__ */ e("p", { children: i })
    ] }),
    a
  ] });
}
function qb({ items: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-product-features", children: t.map((n) => /* @__PURE__ */ o("article", { children: [
    /* @__PURE__ */ e("div", { className: "fp-product-feature-icon", children: n.icon }),
    /* @__PURE__ */ e("h3", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function Kb({ brand: t = "课栈笔记", label: n = "正在打开工作区", actions: r }) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton", role: "status", "aria-label": n, "aria-busy": "true", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: r })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton-body", children: [
      /* @__PURE__ */ o("aside", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] })
    ] })
  ] });
}
function Hb({ phase: t, title: n, description: r, currentVersion: i, version: a, notes: l, progress: s = 0, required: c = !1, compact: u = !1, actions: d }) {
  const p = Math.max(0, Math.min(100, Number.isFinite(s) ? s : 0));
  return /* @__PURE__ */ o("section", { className: "fp-update-panel", "data-phase": t, "data-compact": u || void 0, children: [
    /* @__PURE__ */ o("div", { className: "fp-update-art", "aria-hidden": "true", children: [
      /* @__PURE__ */ e("span", { children: ["checking", "preparing", "verifying", "installing"].includes(t) ? /* @__PURE__ */ e(Ut, { size: 34 }) : t === "error" ? /* @__PURE__ */ e(Xr, { size: 34 }) : t === "ready" || t === "current" ? /* @__PURE__ */ e(ct, { size: 34 }) : t === "downloading" ? /* @__PURE__ */ e(Tn, { size: 34 }) : /* @__PURE__ */ e(Qn, { size: 34 }) }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-update-heading", children: [
      c && /* @__PURE__ */ e("span", { className: "fp-update-required", children: "需要更新" }),
      /* @__PURE__ */ e("h3", { children: n }),
      /* @__PURE__ */ e("p", { role: t === "error" ? "alert" : "status", children: r })
    ] }),
    (i || a) && /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: i || "—" })
      ] }),
      a && /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(Jn, { size: 18, "aria-hidden": "true" }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("small", { children: "最新版本" }),
          /* @__PURE__ */ e("strong", { children: a })
        ] })
      ] })
    ] }),
    l && /* @__PURE__ */ o("section", { className: "fp-update-notes", children: [
      /* @__PURE__ */ e("h4", { children: "本次更新" }),
      /* @__PURE__ */ e("p", { children: l })
    ] }),
    t === "downloading" && /* @__PURE__ */ o("div", { className: "fp-update-progress", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { children: "正在下载" }),
        /* @__PURE__ */ o("strong", { children: [
          Math.round(p),
          "%"
        ] })
      ] }),
      /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": "更新下载进度", "aria-valuenow": p, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: { width: `${p}%` } }) })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-update-actions", children: d })
  ] });
}
function Ub({ tasks: t, title: n = "传输任务", variant: r = "panel", showHeader: i = !0, onCancel: a, onRetry: l, onDismiss: s, onOpen: c, onReveal: u, headerActions: d, collapsed: p = !1, onCollapsedChange: h }) {
  const f = t.filter((m) => m.status === "queued" || m.status === "active").length;
  return p ? /* @__PURE__ */ o(te, { className: "fp-transfer-summary", variant: "secondary", "aria-label": `展开${n}（${t.length}）`, "aria-expanded": !1, onClick: () => h?.(!1), children: [
    /* @__PURE__ */ e(Tn, { size: 17 }),
    /* @__PURE__ */ e("span", { children: f ? `${f} 项传输中` : `${t.length} 项传输记录` })
  ] }) : /* @__PURE__ */ o("section", { className: "fp-upload-queue fp-transfer-queue", "aria-label": n, "data-variant": r, children: [
    i && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: n }),
        /* @__PURE__ */ e("span", { children: f ? `${f} 项进行中` : "传输记录" })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("ul", { children: t.map((m) => {
      const b = Math.max(0, Math.min(100, Number.isFinite(m.progress) ? m.progress : 0)), g = m.direction === "processing" ? "处理" : m.direction === "download" ? "下载" : "上传";
      return /* @__PURE__ */ o("li", { "data-status": m.status, children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", "aria-hidden": "true", children: m.status === "done" ? /* @__PURE__ */ e(Ie, { size: 17 }) : m.direction === "processing" ? /* @__PURE__ */ e(Xo, { size: 17 }) : m.direction === "download" ? /* @__PURE__ */ e(Tn, { size: 17 }) : /* @__PURE__ */ e(Qo, { size: 17 }) }),
        /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
          /* @__PURE__ */ e("strong", { children: m.direction === "upload" && m.openable && c ? /* @__PURE__ */ e("button", { type: "button", className: "fp-transfer-name", "aria-label": `查看 ${m.name}`, onClick: () => c(m), children: m.name }) : m.name }),
          /* @__PURE__ */ e("span", { children: m.detail || (m.status === "queued" ? `等待${g}` : m.status === "done" ? `${g}完成` : m.status === "cancelled" ? "已取消" : m.status === "error" ? `${g}未完成` : `正在${g}${m.indeterminate ? "" : ` ${Math.round(b)}%`}`) }),
          m.status === "active" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${m.name}${g}进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": m.indeterminate ? void 0 : b, className: "fp-upload-progress", "data-indeterminate": m.indeterminate, children: /* @__PURE__ */ e("i", { style: { width: m.indeterminate ? "40%" : `${b}%` } }) })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
          m.direction !== "upload" && m.status === "done" && /* @__PURE__ */ o(ee, { children: [
            c && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `打开 ${m.name}`, onClick: () => c(m), children: m.direction === "download" ? "打开" : "查看结果" }),
            m.direction === "download" && u && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `定位 ${m.name}`, onClick: () => u(m), children: /* @__PURE__ */ e(ka, { size: 15 }) })
          ] }),
          ["queued", "active"].includes(m.status) && m.cancellable !== !1 && a && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `取消${g} ${m.name}`, onClick: () => a(m), children: /* @__PURE__ */ e(ke, { size: 15 }) }),
          ["error", "cancelled"].includes(m.status) && m.retryable !== !1 && l && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `重试${g} ${m.name}`, onClick: () => l(m), children: /* @__PURE__ */ e(Na, { size: 15 }) }),
          ["done", "error", "cancelled"].includes(m.status) && s && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `移除记录 ${m.name}`, onClick: () => s(m), children: /* @__PURE__ */ e(ke, { size: 15 }) })
        ] })
      ] }, m.id);
    }) })
  ] });
}
function Wb({ title: t, subtitle: n, leading: r, actions: i, onBack: a }) {
  return /* @__PURE__ */ o("header", { className: "fp-touch-header", children: [
    a ? /* @__PURE__ */ e("button", { type: "button", onClick: a, "aria-label": "返回", children: /* @__PURE__ */ e(Qr, { size: 22 }) }) : r,
    /* @__PURE__ */ o("div", { className: "fp-touch-heading", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    i && /* @__PURE__ */ e("div", { className: "fp-touch-header-actions", children: i })
  ] });
}
function _b({ title: t, description: n, action: r, children: i }) {
  return /* @__PURE__ */ o("section", { className: "fp-touch-section", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h2", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r
    ] }),
    i
  ] });
}
function Vb({ items: t, label: n = "快捷操作" }) {
  return /* @__PURE__ */ e("div", { className: "fp-touch-actions", "aria-label": n, children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", disabled: r.disabled, onClick: r.onClick, children: [
    /* @__PURE__ */ e("span", { children: r.icon }),
    /* @__PURE__ */ e("strong", { children: r.label }),
    r.description && /* @__PURE__ */ e("small", { children: r.description })
  ] }, r.id)) });
}
function Gb({ title: t, description: n, icon: r, trailing: i, onClick: a }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-touch-row", onClick: a, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-touch-row-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-touch-row-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    i || /* @__PURE__ */ e(Ae, { size: 18, "aria-hidden": "true" })
  ] });
}
function Yb({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-mobile-notebook-grid", children: t });
}
function Xb({ title: t, description: n, icon: r, onClick: i, color: a }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-mobile-notebook", style: a ? { borderLeft: `4px solid ${a}`, background: `color-mix(in srgb,${a} 9%,var(--fp-surface))` } : void 0, onClick: i, children: [
    /* @__PURE__ */ e("span", { className: "fp-mobile-notebook-mark", "aria-hidden": "true", children: r }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("small", { children: n })
  ] });
}
function Qb({ mark: t, title: n, description: r, children: i, footer: a }) {
  return /* @__PURE__ */ o("main", { className: "fp-mobile-welcome", children: [
    /* @__PURE__ */ o("div", { className: "fp-mobile-welcome-content", children: [
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-mark", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      /* @__PURE__ */ e("p", { children: r }),
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-actions", children: i })
    ] }),
    a && /* @__PURE__ */ e("footer", { children: a })
  ] });
}
function Jb({ state: t, time: n, busy: r, onStart: i, onPause: a, onFinish: l, onUpload: s, onAgain: c }) {
  const u = t === "recording" || t === "paused";
  return /* @__PURE__ */ o("section", { className: "fp-recorder", "aria-label": "课堂录音", "aria-busy": r, children: [
    /* @__PURE__ */ o("div", { className: "fp-recorder-status", role: "status", children: [
      t === "recording" && /* @__PURE__ */ e("i", {}),
      t === "idle" ? "准备记录课堂" : t === "paused" ? "已暂停" : t === "saved" ? "录音已保存" : "正在录音"
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-time", "aria-label": `录音时长 ${n}`, children: n }),
    /* @__PURE__ */ e("p", { children: t === "idle" ? "点击开始，记录课堂里的重点" : t === "saved" ? "已保存在手机，可以试听或上传到资源中心" : t === "paused" ? "继续录音，或结束并保存" : "锁屏或返回笔记后，录音仍会继续" }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-controls", children: u ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: a, className: "fp-recorder-secondary", children: [
        t === "paused" ? /* @__PURE__ */ e(cn, { size: 24 }) : /* @__PURE__ */ e(Vn, { size: 24 }),
        /* @__PURE__ */ e("span", { children: t === "paused" ? "继续录音" : "暂停" })
      ] }),
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: l, className: "fp-recorder-finish", children: [
        /* @__PURE__ */ e(pn, { size: 22 }),
        /* @__PURE__ */ e("span", { children: "结束并保存" })
      ] })
    ] }) : t === "saved" ? /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e("span", { className: "fp-recorder-saved", children: /* @__PURE__ */ e(Ie, { size: 32 }) }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: s, className: "fp-recorder-primary", children: "上传录音" }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: c, children: "录制下一条" })
    ] }) : /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: i, className: "fp-recorder-start", children: [
      /* @__PURE__ */ e(Jo, { size: 30 }),
      /* @__PURE__ */ e("span", { children: "开始录音" })
    ] }) })
  ] });
}
function Zb({ title: t, description: n, metrics: r, tables: i, loading: a, error: l, onRefresh: s, children: c, navigation: u, trend: d, personal: p = !1 }) {
  const h = ve().replaceAll(":", ""), f = d || [], m = Math.max(1, ...f.map((y) => y.value)), b = (y) => 48 + y * 744 / Math.max(1, f.length - 1), g = (y) => 190 - y / m * 154, v = f.map((y, N) => `${b(N)},${g(y.value)}`).join(" "), w = [Zo, Xn, In, va, In, ya];
  return /* @__PURE__ */ o("section", { className: "fp-analytics", "data-personal": p || void 0, children: [
    /* @__PURE__ */ o("header", { className: "fp-analytics-heading", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { className: "fp-analytics-eyebrow", children: p ? "我的学习" : "运营分析" }),
        /* @__PURE__ */ e("h1", { children: t }),
        /* @__PURE__ */ e("p", { children: n })
      ] }),
      /* @__PURE__ */ o(te, { variant: "secondary", loading: a, onClick: s, "aria-label": "刷新数据", children: [
        /* @__PURE__ */ e(Qn, { size: 16 }),
        "刷新数据"
      ] })
    ] }),
    u && /* @__PURE__ */ e("div", { className: "fp-analytics-navigation", children: u }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    r.length > 0 && /* @__PURE__ */ e("div", { className: "fp-analytics-metrics", children: r.map((y, N) => {
      const x = w[N % w.length];
      return /* @__PURE__ */ o(Bt, { children: [
        /* @__PURE__ */ o("div", { className: "fp-analytics-metric-label", children: [
          /* @__PURE__ */ e("span", { children: y.label }),
          /* @__PURE__ */ e(x, { size: 17, "aria-hidden": "true" })
        ] }),
        /* @__PURE__ */ e("strong", { children: typeof y.value == "number" ? y.value.toLocaleString("zh-CN") : y.value })
      ] }, y.label);
    }) }),
    d && /* @__PURE__ */ o(Bt, { className: "fp-analytics-trend", children: [
      /* @__PURE__ */ o("div", { className: "fp-analytics-panel-heading", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h2", { children: p ? "使用时长趋势" : "活跃趋势" }),
          /* @__PURE__ */ e("p", { children: "观察每天的使用变化" })
        ] }),
        /* @__PURE__ */ o("span", { className: "fp-analytics-period", children: [
          "最近 ",
          f.length,
          " 天"
        ] })
      ] }),
      f.length ? /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e("div", { className: "fp-analytics-chart", role: "img", "aria-label": f.map((y) => p ? `${y.label}，有效使用${y.minutes}分钟` : `${y.label}，活跃${y.value}人，有效使用${y.minutes}分钟`).join("；"), children: /* @__PURE__ */ o("svg", { viewBox: "0 0 840 230", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ o("linearGradient", { id: h, x1: "0", y1: "0", x2: "0", y2: "1", children: [
            /* @__PURE__ */ e("stop", { offset: "0%", stopColor: "currentColor", stopOpacity: ".18" }),
            /* @__PURE__ */ e("stop", { offset: "100%", stopColor: "currentColor", stopOpacity: "0" })
          ] }) }),
          [0, 0.5, 1].map((y) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("line", { x1: "48", x2: "792", y1: g(m * y), y2: g(m * y), className: "fp-analytics-gridline" }),
            /* @__PURE__ */ e("text", { x: "36", y: g(m * y) + 4, textAnchor: "end", children: Number((m * y).toFixed(1)) })
          ] }, y)),
          /* @__PURE__ */ e("polygon", { points: `48,190 ${v} ${b(f.length - 1)},190`, fill: `url(#${h})` }),
          /* @__PURE__ */ e("polyline", { points: v, fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinejoin: "round", strokeLinecap: "round" }),
          f.map((y, N) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("circle", { cx: b(N), cy: g(y.value), r: "4", fill: "var(--fp-surface)", stroke: "currentColor", strokeWidth: "2" }),
            (N === 0 || N === f.length - 1 || N % Math.ceil(f.length / 7) === 0 && N < f.length - 2) && /* @__PURE__ */ e("text", { x: b(N), y: "219", textAnchor: "middle", children: y.label.slice(5).replace("-", "/") })
          ] }, y.label))
        ] }) }),
        /* @__PURE__ */ o("div", { className: "fp-analytics-chart-footer", children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", {}),
            p ? "每日有效使用（分钟）" : "每日活跃用户"
          ] }),
          /* @__PURE__ */ o("span", { children: [
            "累计有效使用 ",
            /* @__PURE__ */ e("strong", { children: f.reduce((y, N) => y + N.minutes, 0).toLocaleString("zh-CN") }),
            " 分钟"
          ] })
        ] })
      ] }) : /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示活跃趋势。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-analytics-tables", children: i.map((y) => /* @__PURE__ */ o(Bt, { className: y.columns.length > 4 ? "fp-analytics-wide" : void 0, children: [
      /* @__PURE__ */ e("h2", { children: y.title }),
      /* @__PURE__ */ o("div", { className: "fp-analytics-table", tabIndex: 0, role: "region", "aria-label": y.title, children: [
        /* @__PURE__ */ o("table", { children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: y.columns.map((N) => /* @__PURE__ */ e("th", { children: N }, N)) }) }),
          /* @__PURE__ */ e("tbody", { children: y.rows.map((N, x) => /* @__PURE__ */ e("tr", { children: N.map((C, z) => /* @__PURE__ */ e("td", { children: C }, z)) }, x)) })
        ] }),
        !y.rows.length && /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示统计结果。" })
      ] })
    ] }, y.title)) }),
    c
  ] });
}
function eg({ entries: t, directoryId: n, onNavigate: r, selectedId: i, onSelect: a, rootLabel: l = "全部位置", searchLabel: s = "搜索名称、拼音或英文", emptyLabel: c = "此文件夹为空", disabled: u = !1, preview: d, loading: p = !1, variant: h = "content" }) {
  const [f, m] = k(""), b = R(null), g = Ke(() => new Map(t.map((L) => [L.id, L])), [t]), v = (L) => {
    const j = [], M = /* @__PURE__ */ new Set();
    let A = g.get(L);
    for (; A && !M.has(A.id); )
      M.add(A.id), j.unshift(A), A = A.parentId ? g.get(A.parentId) : void 0;
    return j;
  }, w = v(n), y = t.filter((L) => !L.parentId && L.kind === "folder"), N = Ke(() => new Map(t.map((L) => [L.id, bn(L.label, L.description || "", L.keywords || "", ...v(L.id).map((j) => j.label))])), [t, g]), x = f.trim().toLowerCase(), C = t.filter((L) => x ? N.get(L.id)?.includes(x) : (L.parentId || "") === n), z = (L) => {
    m(""), r(L);
  };
  return /* @__PURE__ */ o("div", { className: "fp-resource-browser", "data-variant": h, "aria-busy": p, children: [
    h === "destination" && /* @__PURE__ */ o("div", { className: "fp-browser-destination-heading", children: [
      /* @__PURE__ */ e("span", { children: "选择保存位置" }),
      /* @__PURE__ */ e("small", { children: "打开文件夹，选择当前位置" })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-search", children: [
      /* @__PURE__ */ e(Ue, { size: 17, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { type: "search", "aria-label": s, placeholder: s, value: f, disabled: u, onChange: (L) => m(L.target.value) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-body", children: [
      h === "content" && /* @__PURE__ */ o("nav", { className: "fp-browser-locations", "aria-label": "浏览位置", children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": n ? void 0 : "location", onClick: () => z(""), children: l }),
        y.map((L) => /* @__PURE__ */ o("button", { type: "button", disabled: u || L.disabled, "aria-current": w[0]?.id === L.id ? "location" : void 0, onClick: () => z(L.id), children: [
          L.icon || /* @__PURE__ */ e(Ht, { size: 17 }),
          /* @__PURE__ */ e("span", { children: L.label })
        ] }, L.id))
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-browser-main", "aria-label": "文件夹内容", children: [
        h === "destination" && y.length > 1 && /* @__PURE__ */ e("div", { className: "fp-browser-root-choice", children: /* @__PURE__ */ e(Ce, { label: "切换位置", value: w[0]?.id || "", onChange: z, options: [{ value: "", label: l }, ...y.map((L) => ({ value: L.id, label: L.label, disabled: L.disabled }))] }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-path", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回上一级", disabled: u || !n, onClick: () => z(g.get(n)?.parentId || ""), children: /* @__PURE__ */ e(Vr, { size: 17 }) }),
          /* @__PURE__ */ o("nav", { "aria-label": "当前位置", children: [
            /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: () => z(""), children: l }),
            w.map((L) => /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(Ae, { size: 13 }),
              /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": L.id === n ? "location" : void 0, onClick: () => z(L.id), children: L.label })
            ] }, L.id))
          ] })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-browser-list", ref: b, role: "group", "aria-label": x ? "搜索结果" : "可选内容", onKeyDown: (L) => {
          if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(L.key)) return;
          const j = Array.from(b.current?.querySelectorAll("button:not(:disabled)") || []), M = j.indexOf(document.activeElement);
          M < 0 || (L.preventDefault(), j[L.key === "Home" ? 0 : L.key === "End" ? j.length - 1 : Math.max(0, Math.min(j.length - 1, M + (L.key === "ArrowDown" ? 1 : -1)))]?.focus());
        }, children: p ? /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }) : C.length ? C.map((L) => /* @__PURE__ */ o("button", { className: "fp-browser-entry", type: "button", disabled: u || L.disabled, "aria-pressed": L.kind === "file" ? i === L.id : void 0, onClick: () => L.kind === "folder" ? z(L.id) : a(L.id), children: [
          /* @__PURE__ */ e("span", { className: "fp-browser-entry-icon", children: L.icon || (L.kind === "folder" ? /* @__PURE__ */ e(Ht, { size: 22 }) : /* @__PURE__ */ e(es, { size: 22 })) }),
          /* @__PURE__ */ o("span", { className: "fp-browser-entry-text", children: [
            /* @__PURE__ */ e("strong", { children: L.label }),
            (x || L.description || h === "destination") && /* @__PURE__ */ e("small", { children: x ? v(L.id).slice(0, -1).map((j) => j.label).join(" / ") : L.description || (L.kind === "folder" ? `${t.filter((j) => j.parentId === L.id && j.kind === "folder").length} 个文件夹` : "") })
          ] }),
          L.kind === "folder" && /* @__PURE__ */ e(Ae, { size: 16 })
        ] }, L.id)) : /* @__PURE__ */ e("p", { role: "status", children: x ? "没有匹配的内容" : c }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-count", "aria-live": "polite", children: [
          C.length,
          " 项",
          x ? " · 搜索全部位置" : ""
        ] })
      ] }),
      d && /* @__PURE__ */ e("aside", { className: "fp-browser-preview", "aria-label": "所选内容", children: d })
    ] })
  ] });
}
function tg({ brand: t, headerActions: n, items: r, value: i, onChange: a, onReturn: l, identity: s, children: c }) {
  const [u, d] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-console", children: [
    /* @__PURE__ */ o("header", { className: "fp-console-topbar", children: [
      /* @__PURE__ */ e("div", { className: "fp-console-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-console-top-actions", children: [
        /* @__PURE__ */ o(te, { variant: "ghost", onClick: l, children: [
          /* @__PURE__ */ e(Qr, { size: 17 }),
          "返回工作区"
        ] }),
        n
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-console-body", children: [
      /* @__PURE__ */ o("div", { className: "fp-console-mobile-bar", children: [
        /* @__PURE__ */ o(te, { variant: "secondary", "aria-expanded": u, "aria-controls": "management-navigation", onClick: () => d(!u), children: [
          u ? /* @__PURE__ */ e(ke, { size: 18 }) : /* @__PURE__ */ e(un, { size: 18 }),
          "管理导航"
        ] }),
        /* @__PURE__ */ e("span", { children: r.find((p) => p.id === i)?.label })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-console-sidebar", "data-open": u, children: [
        /* @__PURE__ */ e("div", { className: "fp-console-sidebar-heading", children: "管理中心" }),
        /* @__PURE__ */ e("nav", { id: "management-navigation", "aria-label": "管理导航", children: r.map((p) => /* @__PURE__ */ o("button", { type: "button", "aria-current": i === p.id ? "page" : void 0, onClick: () => {
          a(p.id), d(!1);
        }, children: [
          p.icon,
          /* @__PURE__ */ e("span", { children: p.label })
        ] }, p.id)) }),
        s && /* @__PURE__ */ e("footer", { children: s })
      ] }),
      /* @__PURE__ */ e("main", { className: "fp-console-content", tabIndex: -1, children: c })
    ] })
  ] });
}
function ng({ title: t, description: n, items: r, value: i, onChange: a, actions: l, status: s, children: c }) {
  return /* @__PURE__ */ o("section", { className: "fp-console-form", children: [
    /* @__PURE__ */ e("header", { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h1", { children: t }),
      n && /* @__PURE__ */ e("p", { children: n })
    ] }) }),
    /* @__PURE__ */ e(ii, { items: r, value: i, onChange: a }),
    /* @__PURE__ */ e("div", { className: "fp-console-form-body", children: c }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("div", { role: "status", "aria-live": "polite", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-console-form-actions", children: l })
    ] })
  ] });
}
function rg({ open: t, version: n, minimum: r, children: i, actions: a, updateContent: l }) {
  return /* @__PURE__ */ e(Ye, { open: t, dismissible: !1, className: "fp-upgrade-dialog", title: "更新课栈，继续学习", onClose: () => {
  }, footer: a, children: l || /* @__PURE__ */ o("div", { className: "fp-upgrade-required", children: [
    /* @__PURE__ */ e("div", { className: "fp-upgrade-symbol", "aria-hidden": "true", children: /* @__PURE__ */ e(_r, { size: 28 }) }),
    /* @__PURE__ */ e("p", { children: "当前版本需要升级，完成后即可继续使用。" }),
    /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: n || "—" })
      ] }),
      /* @__PURE__ */ e(Jn, { size: 18, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "最低支持版本" }),
        /* @__PURE__ */ e("strong", { children: r || "—" })
      ] })
    ] }),
    /* @__PURE__ */ e("p", { className: "fp-upgrade-hint", children: "升级前请保留正在编辑的内容。" }),
    i
  ] }) });
}
function ig({ value: t, onChange: n, models: r, tools: i, syncStatus: a, providers: l, initialTab: s = "preferences", children: c }) {
  const [u, d] = k(s);
  Y(() => d(s), [s]);
  const p = r.filter((f) => f.type !== "image").map((f) => ({ value: f.id, label: f.label })), h = r.filter((f) => f.type === "image").map((f) => ({ value: f.id, label: f.label }));
  return /* @__PURE__ */ o("div", { className: "fp-assistant-preferences", children: [
    /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: a }),
    /* @__PURE__ */ e(Ge, { label: "AI 设置分类", value: u, onChange: d, density: "compact", items: [{ id: "preferences", label: "常用偏好" }, { id: "models", label: "模型与供应商" }, { id: "capabilities", label: "能力与备份" }] }),
    u === "preferences" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "常用偏好", children: [
      /* @__PURE__ */ o(ne, { title: "对话偏好", children: [
        /* @__PURE__ */ e(X, { label: "默认对话模型", value: t.selectedModelId, options: p, onChange: (f) => n("selectedModelId", f) }),
        /* @__PURE__ */ e(Le, { label: "深度思考", description: "新对话默认开启深度思考。", checked: t.defaultThinking, onChange: (f) => n("defaultThinking", f) }),
        /* @__PURE__ */ e(X, { label: "默认思考力度", value: t.defaultThinkingEffort, options: [{ value: "low", label: "轻量" }, { value: "medium", label: "标准" }, { value: "high", label: "深入" }, { value: "max", label: "充分" }], onChange: (f) => n("defaultThinkingEffort", f) }),
        /* @__PURE__ */ e(Le, { label: "联网搜索", description: "新对话默认启用联网搜索。", checked: t.defaultSearch, onChange: (f) => n("defaultSearch", f) })
      ] }),
      /* @__PURE__ */ e(ne, { title: "回答偏好", description: "告诉 AI 你的学习背景、称呼和回答习惯。", children: /* @__PURE__ */ e(X, { label: "希望 AI 记住的偏好", value: t.globalContext, multiline: !0, onChange: (f) => n("globalContext", f) }) })
    ] }),
    u === "models" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "模型与供应商", children: [
      l,
      /* @__PURE__ */ o(ne, { title: "摘录与划词助手", children: [
        /* @__PURE__ */ e(X, { label: "摘录模型", value: t.recordModelId, options: p, onChange: (f) => n("recordModelId", f) }),
        /* @__PURE__ */ e(X, { label: "划词助手模型", value: t.floatingChatModelId, options: [{ value: "", label: "跟随主对话" }, ...p], onChange: (f) => n("floatingChatModelId", f) })
      ] }),
      h.length > 0 && /* @__PURE__ */ o(ne, { title: "图片生成", children: [
        /* @__PURE__ */ e(X, { label: "默认生图模型", value: t.defaultImageModelId || "", options: [{ value: "", label: "自动选择" }, ...h], onChange: (f) => n("defaultImageModelId", f || null) }),
        /* @__PURE__ */ e(X, { label: "图片描述模型", value: t.imageModeTextModel, options: p, onChange: (f) => n("imageModeTextModel", f) }),
        /* @__PURE__ */ e(X, { label: "备用描述模型", value: t.imageModeTextModelFallback, options: p, onChange: (f) => n("imageModeTextModelFallback", f) })
      ] })
    ] }),
    u === "capabilities" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "能力与备份", children: [
      /* @__PURE__ */ e(ne, { title: "助手能力", children: i.map((f) => /* @__PURE__ */ e(Le, { label: f.label, description: f.desc, checked: !t.disabledTools.includes(f.name), onChange: (m) => n("disabledTools", m ? t.disabledTools.filter((b) => b !== f.name) : [...t.disabledTools, f.name]) }, f.name)) }),
      c
    ] })
  ] });
}
const Hp = { name: "", baseUrl: "", protocol: "openai", apiKey: "", models: [] };
function ag({ items: t, loading: n, error: r, credentialNotice: i, imports: a = [], onImportSaved: l, onDiscover: s, onTest: c, onSave: u, onDelete: d }) {
  const [p, h] = k(), [f, m] = k(null), [b, g] = k(""), [v, w] = k(""), [y, N] = k(""), [x, C] = k(""), [z, L] = k([]), [j, M] = k(), A = !f || f.models.every((E) => Number.isInteger(E.contextK ?? 32) && (E.contextK ?? 32) >= 4 && (E.contextK ?? 32) <= 2048), O = (E) => {
    m((S) => S ? { ...S, ...E } : null), N(""), w("");
  }, U = (E) => {
    m(E ? { ...E, apiKey: "" } : { ...Hp, models: [] }), L(E?.models || []), C(""), N(""), w(""), M(void 0), h(void 0);
  }, T = async (E, S) => {
    g(E), w("");
    try {
      await S();
    } catch (P) {
      w(P instanceof Error ? P.message : "操作未完成，请重试");
    } finally {
      g("");
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-provider-manager", children: [
    /* @__PURE__ */ e("p", { children: "连接你自己的 AI 服务。供应商和模型会同步到账号，在其他设备也可使用。" }),
    i && /* @__PURE__ */ o("aside", { className: "fp-provider-privacy", role: "note", "aria-label": "API Key 使用说明", children: [
      /* @__PURE__ */ e(Yr, { size: 20, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: i })
    ] }),
    n && /* @__PURE__ */ e("p", { role: "status", children: "正在读取供应商…" }),
    r && /* @__PURE__ */ e("p", { role: "alert", children: r }),
    a.length > 0 && !f && /* @__PURE__ */ o("section", { className: "fp-provider-imports", "aria-label": "此设备的旧配置", children: [
      /* @__PURE__ */ e("strong", { children: "此设备的旧配置" }),
      /* @__PURE__ */ e("p", { children: "检查并测试后保存到账号，即可在其他设备使用。" }),
      a.map((E) => /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: E.label }),
        /* @__PURE__ */ o(te, { variant: "secondary", disabled: !!b, onClick: () => {
          U(), m({ ...E.draft }), L(E.draft.models), h(E.id);
        }, children: [
          "检查并迁移 ",
          E.label
        ] })
      ] }, E.id))
    ] }),
    t.map((E) => /* @__PURE__ */ o("div", { className: "fp-provider-summary", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: E.name }),
        /* @__PURE__ */ o("small", { children: [
          E.models.length,
          " 个模型 · ",
          E.protocol === "anthropic" ? "Anthropic Messages" : E.protocol === "siliconflow" ? "SiliconFlow" : "OpenAI 兼容"
        ] })
      ] }),
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => U(E), children: "编辑" }),
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => M(E.id), children: "删除" }),
      j === E.id && /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: "删除此供应商？" }),
        /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => M(void 0), children: "取消" }),
        /* @__PURE__ */ e(te, { disabled: !!b, onClick: () => {
          T("delete", async () => {
            await d(E), M(void 0), f?.id === E.id && m(null);
          });
        }, children: "确认删除" })
      ] })
    ] }, E.id)),
    !f && /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => U(), children: "添加供应商" }),
    f && /* @__PURE__ */ o("div", { className: "fp-provider-form", "aria-label": f.id ? "编辑供应商" : "添加供应商", children: [
      /* @__PURE__ */ e(X, { label: "供应商名称", value: f.name, disabled: !!b, onChange: (E) => O({ name: E }) }),
      /* @__PURE__ */ e(X, { label: "API 端点", hint: "填写 HTTPS 地址，例如 https://api.example.com/v1", value: f.baseUrl, disabled: !!b, onChange: (E) => {
        O({ baseUrl: E, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "协议", value: f.protocol, disabled: !!b, options: [{ value: "openai", label: "OpenAI 兼容" }, { value: "anthropic", label: "Anthropic Messages" }, { value: "siliconflow", label: "SiliconFlow" }], onChange: (E) => {
        O({ protocol: E, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "API Key", hint: f.id ? "留空沿用已保存的 Key。" : "Key 仅用于连接你的供应商，保存后不会再显示。", value: f.apiKey, secret: !0, disabled: !!b, onChange: (E) => O({ apiKey: E }) }),
      /* @__PURE__ */ e("div", { className: "fp-provider-actions", children: /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !f.baseUrl || !f.apiKey && !f.id, onClick: () => {
        T("discover", async () => {
          const E = await s(f);
          L(E), O({ models: [] }), w("已获取模型，请选择要添加的模型。");
        });
      }, children: b === "discover" ? "正在获取…" : "获取模型" }) }),
      z.length > 0 && /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ o("p", { "aria-live": "polite", children: [
          "已选择 ",
          f.models.length,
          " / 50 个模型"
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-provider-models", role: "group", "aria-label": "选择模型", children: z.map((E) => /* @__PURE__ */ o("label", { children: [
          /* @__PURE__ */ e("input", { type: "checkbox", disabled: !!b || f.models.length >= 50 && !f.models.some((S) => S.id === E.id), checked: f.models.some((S) => S.id === E.id), onChange: (S) => O({ models: S.target.checked ? [...f.models, E] : f.models.filter((P) => P.id !== E.id) }) }),
          E.label || E.id
        ] }, E.id)) })
      ] }),
      f.models.length > 0 && /* @__PURE__ */ o("section", { className: "fp-provider-contexts", "aria-label": "模型能力设置", children: [
        /* @__PURE__ */ e("h3", { children: "模型能力与容量" }),
        /* @__PURE__ */ e("p", { children: "按供应商实际支持的能力分别设置每个模型。图片输入用于识别图片；工具调用用于读取资料、操作笔记等。1K 为 1000 tokens。" }),
        f.models.map((E) => /* @__PURE__ */ o("fieldset", { className: "fp-provider-context", children: [
          /* @__PURE__ */ e("legend", { children: E.label || E.id }),
          /* @__PURE__ */ e(Le, { label: "支持图片输入", description: "允许在对话中上传图片供此模型识别。", checked: E.vision === !0, disabled: !!b, onChange: (S) => O({ models: f.models.map((P) => P.id === E.id ? { ...P, vision: S } : P) }) }),
          /* @__PURE__ */ e(Le, { label: "启用工具调用", description: "允许此模型读取资料及执行你授权的笔记操作。", checked: E.tools === !0, disabled: !!b, onChange: (S) => O({ models: f.models.map((P) => P.id === E.id ? { ...P, tools: S } : P) }) }),
          /* @__PURE__ */ e(X, { label: "上下文容量（K）", numeric: !0, value: E.contextK ?? 32, disabled: !!b, hint: E.contextSource === "provider" ? "供应商提供的容量，可按实际限制调整。" : E.contextSource === "user" ? "手动设置的容量。" : E.contextSource === "default" || E.contextK === void 0 ? "供应商未提供容量，暂用保守默认值 32K，请按实际限制确认。" : "已保存的容量，请按供应商实际限制确认。", onChange: (S) => O({ models: f.models.map((P) => P.id === E.id ? { ...P, contextK: Number(S), contextSource: "user" } : P) }) }),
          (!Number.isInteger(E.contextK ?? 32) || (E.contextK ?? 32) < 4 || (E.contextK ?? 32) > 2048) && /* @__PURE__ */ e("p", { role: "alert", children: "请填写 4–2048 之间的整数。" })
        ] }, E.id))
      ] }),
      /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ e("summary", { children: "手动添加模型" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e(X, { label: "模型 ID", value: x, hint: "供应商无法列出模型时，可填写模型 ID，多个模型用逗号或换行分隔。", multiline: !0, disabled: !!b, onChange: C }),
          /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !x.trim(), onClick: () => {
            const E = [...new Set(x.split(/[\n,，]/).map((P) => P.trim()).filter(Boolean))].map((P) => ({ id: P, label: P })), S = [...f.models, ...E.filter((P) => !f.models.some((_) => _.id === P.id))];
            L((P) => [...P, ...E.filter((_) => !P.some((q) => q.id === _.id))]), O({ models: S }), C("");
          }, children: "加入模型列表" })
        ] })
      ] }),
      /* @__PURE__ */ e("p", { children: "连接测试只检查所选第一个模型是否可访问，图片和工具能力请按供应商说明设置。测试及对话的费用由你的供应商收取。" }),
      /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !A || !f.name.trim() || !f.models.length || f.models.length > 50, onClick: () => {
          T("test", async () => {
            N(await c(f)), w("连接成功，可以保存供应商。");
          });
        }, children: b === "test" ? "正在测试…" : "测试连接" }),
        /* @__PURE__ */ e(te, { disabled: !!b || !y || !A, onClick: () => {
          T("save", async () => {
            await u(f, y), p && l?.(p), h(void 0), m(null), N(""), w("供应商已保存，可在模型菜单中选择。");
          });
        }, children: b === "save" ? "正在保存…" : f.id ? "保存供应商" : "添加供应商" }),
        /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => {
          m(null), h(void 0), N(""), w("");
        }, children: "取消" })
      ] })
    ] }),
    v && /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: v })
  ] });
}
function lg({ items: t, onSelect: n, label: r = "相关设置" }) {
  return /* @__PURE__ */ e("nav", { className: "fp-settings-links", "aria-label": r, children: t.map((i) => /* @__PURE__ */ o("button", { type: "button", disabled: i.disabled, onClick: () => n(i.id), children: [
    i.icon && /* @__PURE__ */ e("span", { className: "fp-settings-link-icon", "aria-hidden": "true", children: i.icon }),
    /* @__PURE__ */ o("span", { className: "fp-settings-link-copy", children: [
      /* @__PURE__ */ e("strong", { children: i.label }),
      i.description && /* @__PURE__ */ e("small", { children: i.description })
    ] }),
    /* @__PURE__ */ e(Ae, { size: 18, "aria-hidden": "true" })
  ] }, i.id)) });
}
function og({ metrics: t, description: n = "最近 30 天", loading: r, error: i, onRetry: a }) {
  return /* @__PURE__ */ o(ne, { title: "使用统计", description: n, children: [
    /* @__PURE__ */ e(Ee, { error: i }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取使用统计…" }) : /* @__PURE__ */ e("dl", { className: "fp-admin-metrics", children: t.map((l) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, l.label)) }),
    i && a && /* @__PURE__ */ e(te, { onClick: a, children: "重新读取" })
  ] });
}
function sg({ items: t, loading: n, error: r, hasMore: i, onMore: a }) {
  return /* @__PURE__ */ o(ne, { title: "拥有的笔记本", children: [
    /* @__PURE__ */ e(Ee, { error: r }),
    /* @__PURE__ */ e("ul", { className: "fp-admin-notebooks", children: t.map((l) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("div", { children: [
      l.href ? /* @__PURE__ */ e("a", { href: l.href, children: l.title }) : /* @__PURE__ */ e("strong", { children: l.title }),
      /* @__PURE__ */ o("small", { children: [
        l.noteCount,
        " 篇笔记 · 更新于 ",
        l.updatedAt
      ] })
    ] }) }, l.id)) }),
    n ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : !t.length && !r ? /* @__PURE__ */ e("p", { children: "该用户尚未拥有笔记本。" }) : null,
    i && a && /* @__PURE__ */ e(te, { disabled: n, onClick: a, children: "加载更多笔记本" })
  ] });
}
function cg({ entries: t, filters: n, onFiltersChange: r, actions: i, onSearch: a, onReset: l, onNext: s, onPrevious: c, canNext: u, canPrevious: d, loading: p, error: h }) {
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-admin-audit", children: /* @__PURE__ */ o(ne, { title: "审计日志", description: "查看平台操作的时间、操作者、对象与变更说明。", children: [
    /* @__PURE__ */ o("form", { className: "fp-admin-audit-filters", onSubmit: (f) => {
      f.preventDefault(), a();
    }, children: [
      /* @__PURE__ */ e(X, { label: "操作者", value: n.actor, onChange: (f) => r({ ...n, actor: f }) }),
      /* @__PURE__ */ e(X, { label: "操作", value: n.action, options: [{ value: "", label: "全部操作" }, ...i], onChange: (f) => r({ ...n, action: f }) }),
      /* @__PURE__ */ e(X, { label: "操作对象", value: n.target, onChange: (f) => r({ ...n, target: f }) }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "开始日期" }),
        /* @__PURE__ */ e(ra, { className: "fp-input", "aria-label": "开始日期", value: n.from, onChange: (f) => r({ ...n, from: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "结束日期" }),
        /* @__PURE__ */ e(ra, { className: "fp-input", "aria-label": "结束日期", value: n.to, onChange: (f) => r({ ...n, to: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-actions", children: [
        /* @__PURE__ */ e(te, { type: "submit", disabled: p, children: "查询" }),
        /* @__PURE__ */ e(te, { type: "button", disabled: p, onClick: l, children: "重置筛选" })
      ] })
    ] }),
    /* @__PURE__ */ e(Ee, { error: h }),
    p ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取操作记录…" }) : /* @__PURE__ */ e("ol", { className: "fp-admin-audit-list", children: t.map((f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-heading", children: [
        /* @__PURE__ */ e("strong", { children: f.action }),
        /* @__PURE__ */ e("time", { children: f.time })
      ] }),
      /* @__PURE__ */ o("p", { children: [
        /* @__PURE__ */ e("span", { children: f.actor }),
        /* @__PURE__ */ e("span", { "aria-hidden": "true", children: " → " }),
        /* @__PURE__ */ e("span", { children: f.target })
      ] }),
      f.summary && /* @__PURE__ */ e("p", { children: f.summary })
    ] }, f.id)) }),
    !p && !h && !t.length && /* @__PURE__ */ e("p", { children: "没有符合条件的操作记录。" }),
    /* @__PURE__ */ o("nav", { className: "fp-admin-audit-actions", "aria-label": "审计记录分页", children: [
      /* @__PURE__ */ e(te, { disabled: p || !d, onClick: c, children: "上一页" }),
      /* @__PURE__ */ e(te, { disabled: p || !u, onClick: s, children: "下一页" })
    ] })
  ] }) });
}
function dg({ index: t, children: n, className: r = "", duration: i = 0.26, label: a }) {
  const [l, s] = k({ index: t, direction: 1, prior: null }), c = R(n), u = Zn();
  l.index !== t && s({ index: t, direction: t > l.index ? 1 : -1, prior: { index: l.index, children: c.current } }), c.current = n, Y(() => {
    const p = setTimeout(() => s((h) => h.index === t && h.prior ? { ...h, prior: null } : h), u ? 0 : i * 1e3 + 30);
    return () => clearTimeout(p);
  }, [t, i, u]);
  const d = [...l.prior ? [{ ...l.prior, active: !1 }] : [], { index: t, children: n, active: !0 }];
  return /* @__PURE__ */ e("div", { className: `fp-slide-transition ${r}`, "data-direction": l.direction, "data-index": t, "aria-label": a, style: { position: "relative", height: "100%", width: "100%", minHeight: 0, minWidth: 0, overflow: "hidden" }, children: d.map((p) => /* @__PURE__ */ e(
    er.div,
    {
      "data-fp-slide-page": "",
      "data-active": p.active,
      inert: !p.active,
      "aria-hidden": !p.active || void 0,
      initial: p.active && l.prior && !u ? { x: `${l.direction * 100}%`, opacity: 0.35 } : !1,
      animate: { x: p.active || u ? 0 : `${-l.direction * 100}%`, opacity: p.active || u ? 1 : 0.35 },
      transition: { duration: u ? 0 : i, ease: [0.2, 0, 0, 1] },
      style: { position: "absolute", inset: 0, minWidth: 0, minHeight: 0, overflow: "hidden", pointerEvents: p.active ? "auto" : "none" },
      children: p.children
    },
    p.index
  )) });
}
function ug(t, n = !1) {
  if (t.isComposing || t.repeat || !(t.ctrlKey || t.metaKey)) return null;
  const r = t.key.toLowerCase();
  return !n && !t.altKey || n && t.altKey ? null : r === "n" && !t.shiftKey ? "new-note" : r === "w" && !t.shiftKey ? "close-tab" : r === "t" && t.shiftKey ? "reopen-tab" : !n && r === "arrowright" && !t.shiftKey ? "next-tab" : !n && r === "arrowleft" && !t.shiftKey ? "previous-tab" : n && r === "tab" ? t.shiftKey ? "previous-tab" : "next-tab" : !t.shiftKey && /^[1-9]$/.test(r) ? `tab-${Number(r)}` : null;
}
function pg(t) {
  const n = ve(), [r, i] = k("edit"), [a, l] = k("");
  Y(() => {
    i("edit"), l("");
  }, [t.sessionKey]);
  const s = t.mode === "create";
  return /* @__PURE__ */ o("section", { className: "fp-experiment", "aria-label": "实验编辑工作台", onKeyDown: (c) => {
    (c.ctrlKey || c.metaKey) && c.key.toLowerCase() === "s" && (c.preventDefault(), t.onSave());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-experiment-header", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-experiment-back", onClick: t.onBack, children: [
        /* @__PURE__ */ e(Qr, { size: 17 }),
        "我的实验"
      ] }),
      /* @__PURE__ */ e("span", { role: "status", className: "fp-experiment-save", children: t.saveStatus }),
      /* @__PURE__ */ e(or, { label: "实验操作", actions: [
        { id: "save", label: "保存实验（Ctrl+S）", icon: /* @__PURE__ */ e(ma, { size: 18 }), onSelect: t.onSave },
        { id: "insert", label: "加入笔记", icon: /* @__PURE__ */ e(ts, { size: 18 }), onSelect: t.onInsert, disabled: t.busy || !t.source.trim() },
        { id: "copy", label: "另存为新实验", icon: /* @__PURE__ */ e(vn, { size: 18 }), onSelect: t.onDuplicate, disabled: t.busy || !t.source.trim() },
        { id: "download", label: "下载实验", icon: /* @__PURE__ */ e(_t, { size: 18 }), onSelect: t.onExport, disabled: !t.source.trim() }
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-experiment-layout", children: [
      /* @__PURE__ */ o("aside", { className: "fp-experiment-editor", children: [
        /* @__PURE__ */ e("label", { htmlFor: `${n}-title`, children: "实验名称" }),
        /* @__PURE__ */ e("input", { id: `${n}-title`, value: t.title, placeholder: "给实验起个名字", onChange: (c) => t.onTitleChange(c.target.value), maxLength: 100, disabled: t.busy }),
        /* @__PURE__ */ o("div", { className: "fp-experiment-tabs", role: "tablist", "aria-label": "实验编辑", onKeyDown: (c) => {
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(c.key)) return;
          c.preventDefault();
          const u = c.key === "Home" ? "edit" : c.key === "End" || r === "edit" ? "history" : "edit";
          i(u), c.currentTarget.querySelectorAll("[role=tab]")[u === "edit" ? 0 : 1]?.focus();
        }, children: [
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-edit-tab`, role: "tab", tabIndex: r === "edit" ? 0 : -1, "aria-selected": r === "edit", "aria-controls": `${n}-edit`, onClick: () => i("edit"), children: [
            /* @__PURE__ */ e(Dn, { size: 16 }),
            s ? "创建实验" : "继续修改"
          ] }),
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-history-tab`, role: "tab", tabIndex: r === "history" ? 0 : -1, "aria-selected": r === "history", "aria-controls": `${n}-history`, onClick: () => i("history"), children: [
            /* @__PURE__ */ e(ns, { size: 16 }),
            "版本记录"
          ] })
        ] }),
        r === "edit" ? /* @__PURE__ */ o("div", { id: `${n}-edit`, role: "tabpanel", "aria-labelledby": `${n}-edit-tab`, className: "fp-experiment-form", children: [
          t.modelSelector && /* @__PURE__ */ e("div", { className: "fp-experiment-model", children: t.modelSelector }),
          /* @__PURE__ */ e("label", { htmlFor: `${n}-prompt`, children: "描述你的想法" }),
          /* @__PURE__ */ e("textarea", { id: `${n}-prompt`, value: t.prompt, onChange: (c) => t.onPromptChange(c.target.value), disabled: t.busy, rows: 5, placeholder: s ? "例如：用滑块调整电荷大小，观察电场如何变化。" : "例如：保留现有图形，增加一个能调节距离的滑块。" }),
          /* @__PURE__ */ e("button", { type: "button", className: "fp-experiment-primary", onClick: t.busy ? t.onStop : t.onGenerate, disabled: !t.busy && (!t.prompt.trim() || t.canGenerate === !1), children: t.busy ? /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e(pn, { size: 16 }),
            "停止生成"
          ] }) : /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e(Dn, { size: 17 }),
            "生成实验"
          ] }) }),
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: s ? "描述想探索的概念和操作，AI 会为你创建实验。" : "描述要增加或调整的内容，AI 会基于当前实验修改。" }),
          /* @__PURE__ */ o("details", { children: [
            /* @__PURE__ */ e("summary", { children: "编辑实验源代码" }),
            /* @__PURE__ */ e("label", { htmlFor: `${n}-source`, children: "实验内容" }),
            /* @__PURE__ */ e("textarea", { id: `${n}-source`, "aria-label": "交互内容", value: t.source, onChange: (c) => t.onSourceChange(c.target.value), disabled: t.busy, rows: 14, spellCheck: !1 })
          ] })
        ] }) : /* @__PURE__ */ o("div", { id: `${n}-history`, role: "tabpanel", "aria-labelledby": `${n}-history-tab`, className: "fp-experiment-form", children: [
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: "恢复后会保留当前内容，方便再次找回。" }),
          t.versions?.length ? /* @__PURE__ */ o(ee, { children: [
            /* @__PURE__ */ e(Ce, { label: "选择实验版本", value: a, onChange: l, options: t.versions.map((c) => ({ value: c.id, label: c.label })) }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              t.onRestore?.(a), l("");
            }, disabled: !a || t.busy, children: "恢复此版本" })
          ] }) : /* @__PURE__ */ e("p", { children: "保存或完成一次修改后，可以在这里找回之前的内容。" })
        ] }),
        t.message && /* @__PURE__ */ e("p", { role: "status", className: "fp-experiment-message", children: t.message }),
        t.generationSummary && /* @__PURE__ */ e("div", { role: "status", className: "fp-experiment-hint", children: t.generationSummary })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-experiment-preview", "aria-label": "实验预览", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: t.title || "未命名实验" }),
          /* @__PURE__ */ e("span", { children: "动手探索" })
        ] }),
        t.busy && /* @__PURE__ */ e("div", { className: "fp-experiment-progress", "aria-live": "polite", children: t.progress }),
        /* @__PURE__ */ e("div", { className: "fp-experiment-canvas", children: t.preview })
      ] })
    ] })
  ] });
}
function hg({ steps: t, current: n }) {
  return /* @__PURE__ */ e("ol", { className: "fp-account-task-progress", "aria-label": "操作步骤", children: t.map((r, i) => /* @__PURE__ */ o("li", { "data-state": i < n ? "complete" : i === n ? "current" : "upcoming", "aria-current": i === n ? "step" : void 0, children: [
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: i < n ? /* @__PURE__ */ e(Ie, { size: 14 }) : i + 1 }),
    /* @__PURE__ */ e("strong", { children: r })
  ] }, r)) });
}
function Up({ label: t, hint: n, error: r, ...i }) {
  const a = ve(), l = i.id || a, s = l + "-help";
  return /* @__PURE__ */ o("div", { className: "fp-account-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: l, children: t }),
    /* @__PURE__ */ e("input", { ...i, id: l, "aria-invalid": !!r || void 0, "aria-describedby": n || r ? s : void 0 }),
    (r || n) && /* @__PURE__ */ o("p", { id: s, className: r ? "fp-account-field-error" : "fp-account-field-hint", role: r ? "alert" : void 0, children: [
      r && /* @__PURE__ */ e(Gr, { size: 15 }),
      /* @__PURE__ */ e("span", { children: r || n })
    ] })
  ] });
}
function fg({ tone: t = "info", title: n, children: r, action: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-message", "data-tone": t, role: t === "error" ? "alert" : "status", children: [
    /* @__PURE__ */ e(t === "error" ? Gr : t === "success" ? ct : rs, { size: 19 }),
    /* @__PURE__ */ o("div", { children: [
      n && /* @__PURE__ */ e("strong", { children: n }),
      r && /* @__PURE__ */ e("div", { children: r }),
      i && /* @__PURE__ */ e("div", { className: "fp-account-message-action", children: i })
    ] })
  ] });
}
function mg({ description: t }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-verification-intro", children: [
    /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(Yr, { size: 22 }) }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: "确认是你本人" }),
      /* @__PURE__ */ e("p", { children: t || "完成一次验证，即可继续本次安全设置。" })
    ] })
  ] });
}
function bg({ value: t, onChange: n, onSend: r, busy: i = !1, sending: a = !1, sent: l = !1, remaining: s = 0, error: c, label: u = "邮箱验证码", destination: d }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-code-field", children: [
    d && /* @__PURE__ */ o("p", { className: "fp-account-code-destination", children: [
      l ? "验证码已发送至" : "使用此邮箱接收验证码",
      /* @__PURE__ */ e("strong", { children: d })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-account-code-controls", children: [
      /* @__PURE__ */ e(Up, { label: u, value: t, onChange: (p) => n(p.target.value.replace(/[^0-9]/g, "")), inputMode: "numeric", autoComplete: "one-time-code", maxLength: 6, required: !0, disabled: i, error: c, hint: l ? "请输入邮件中的 6 位验证码。" : "请先发送验证码。" }),
      /* @__PURE__ */ e(te, { variant: "secondary", loading: a, disabled: i || s > 0, onClick: r, "aria-label": s > 0 ? `${s} 秒后可以重新发送验证码` : l ? "重新发送验证码" : "发送验证码", children: a ? "正在发送…" : s > 0 ? `${s} 秒后重发` : l ? "重新发送" : "发送验证码" })
    ] })
  ] });
}
const Rl = yn(null);
function gg(t) {
  const n = Wt(Rl), r = ve();
  Y(() => (n?.(r, t), () => n?.(r, !1)), [t, r, n]);
}
function yg({ title: t, onClose: n, children: r, busy: i = !1 }) {
  const [a, l] = k({}), s = De((c, u) => l((d) => d[c] === u ? d : { ...d, [c]: u }), []);
  return /* @__PURE__ */ e(Ye, { open: !0, title: t, onClose: n, dismissible: !i && !Object.values(a).some(Boolean), className: "fp-account-task-dialog", children: /* @__PURE__ */ e(Rl.Provider, { value: s, children: r }) });
}
const oa = (t) => /* @__PURE__ */ e("input", { ...t, className: "fp-input" });
function vg({ groups: t, value: n, onChange: r, onCreate: i, disabled: a = !1, variant: l = "tabs", actions: s = [] }) {
  const c = R(null);
  return l === "picker" ? /* @__PURE__ */ o("div", { className: "fp-notebook-scope-row", children: [
    /* @__PURE__ */ e(Ce, { label: "切换笔记本范围", className: "fp-notebook-scope-picker", value: n, onChange: r, disabled: a, options: t.map((u) => ({ value: u.id, label: u.name, description: `${u.count} 个笔记本${u.shared ? " · 共享组" : ""}`, group: u.section })) }),
    /* @__PURE__ */ e(or, { label: "笔记本组操作", actions: [...i ? [{ id: "create", label: "新建笔记本组", icon: /* @__PURE__ */ e(qt, { size: 17 }), onSelect: i, disabled: a }] : [], ...s] })
  ] }) : /* @__PURE__ */ o("div", { className: "fp-notebook-groups", children: [
    /* @__PURE__ */ e("div", { ref: c, className: "fp-notebook-group-tabs", role: "group", "aria-label": "笔记本组", onKeyDown: (u) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(u.key)) return;
      const d = Array.from(c.current?.querySelectorAll("button") || []), p = d.indexOf(document.activeElement);
      p < 0 || (u.preventDefault(), d[u.key === "Home" ? 0 : u.key === "End" ? d.length - 1 : (p + (u.key === "ArrowRight" ? 1 : -1) + d.length) % d.length]?.focus());
    }, children: t.map((u) => /* @__PURE__ */ o("button", { type: "button", "aria-pressed": u.id === n, "data-fp-tooltip": u.name, onClick: () => r(u.id), children: [
      /* @__PURE__ */ o("span", { className: "fp-notebook-group-name", children: [
        u.shared ? /* @__PURE__ */ e(In, { size: 16 }) : u.id === "all" ? /* @__PURE__ */ e(et, { size: 16 }) : /* @__PURE__ */ e(Ht, { size: 16 }),
        /* @__PURE__ */ e("span", { children: u.name })
      ] }),
      /* @__PURE__ */ e("span", { className: "fp-notebook-group-count", children: u.count })
    ] }, u.id)) }),
    i && /* @__PURE__ */ e(te, { className: "fp-icon-button", variant: "ghost", title: "新建笔记本组", "aria-label": "新建笔记本组", disabled: a, onClick: i, children: /* @__PURE__ */ e(qt, { size: 19 }) })
  ] });
}
function wg({ name: t, onNameChange: n, items: r, selected: i, onSelectionChange: a, disabled: l = !1 }) {
  const [s, c] = k(""), u = ve(), d = Ke(() => r.filter((f) => f.name.toLocaleLowerCase().includes(s.trim().toLocaleLowerCase())), [r, s]), p = d.filter((f) => !f.disabled), h = p.length > 0 && p.every((f) => i.includes(f.id));
  return /* @__PURE__ */ o("div", { className: "fp-notebook-group-editor", children: [
    /* @__PURE__ */ e("label", { htmlFor: u, children: "组名" }),
    /* @__PURE__ */ e(oa, { id: u, value: t, maxLength: 40, placeholder: "例如：本学期课程", disabled: l, onChange: (f) => n(f.target.value) }),
    /* @__PURE__ */ o("div", { className: "fp-notebook-group-selection-heading", children: [
      /* @__PURE__ */ o("strong", { children: [
        "组内笔记本 ",
        /* @__PURE__ */ e("span", { children: i.length })
      ] }),
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: l || !p.length, onClick: () => a(h ? i.filter((f) => !p.some((m) => m.id === f)) : [.../* @__PURE__ */ new Set([...i, ...p.map((f) => f.id)])]), children: h ? "取消全选" : "全选" })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-notebook-group-search", children: [
      /* @__PURE__ */ e(Ue, { size: 17 }),
      /* @__PURE__ */ e(oa, { "aria-label": "查找笔记本", value: s, placeholder: "查找笔记本", onChange: (f) => c(f.target.value) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-notebook-group-items", children: [
      d.map((f) => /* @__PURE__ */ o("label", { className: "fp-notebook-group-item", "data-selected": i.includes(f.id), children: [
        /* @__PURE__ */ e("input", { type: "checkbox", disabled: l || f.disabled, checked: i.includes(f.id), onChange: (m) => a(m.target.checked ? [...i, f.id] : i.filter((b) => b !== f.id)) }),
        /* @__PURE__ */ e("span", { className: "fp-notebook-group-item-icon", children: f.icon || /* @__PURE__ */ e(et, { size: 22 }) }),
        /* @__PURE__ */ o("span", { className: "fp-notebook-group-item-name", children: [
          /* @__PURE__ */ e("strong", { children: f.name }),
          f.detail && /* @__PURE__ */ e("small", { children: f.detail })
        ] }),
        /* @__PURE__ */ e("span", { className: "fp-notebook-group-check", "aria-hidden": "true", children: i.includes(f.id) && /* @__PURE__ */ e(Ie, { size: 15 }) })
      ] }, f.id)),
      !d.length && /* @__PURE__ */ e("p", { className: "fp-notebook-group-empty", children: "没有找到笔记本" })
    ] })
  ] });
}
function kg({ name: t, owner: n, items: r, permission: i = "阅读", children: a }) {
  return /* @__PURE__ */ o("div", { className: "fp-notebook-group-invitation", children: [
    /* @__PURE__ */ e("div", { className: "fp-notebook-group-cover", children: /* @__PURE__ */ e(Ht, { size: 34 }) }),
    /* @__PURE__ */ e("h2", { children: t }),
    /* @__PURE__ */ o("p", { children: [
      n,
      " 邀请你加入笔记本组"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-notebook-group-invite-summary", children: [
      /* @__PURE__ */ o("span", { children: [
        r.length,
        " 个笔记本"
      ] }),
      /* @__PURE__ */ o("span", { children: [
        i,
        "权限"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-notebook-group-items", "aria-label": "邀请中的笔记本", children: r.map((l) => /* @__PURE__ */ o("div", { className: "fp-notebook-group-item", children: [
      /* @__PURE__ */ e("span", { className: "fp-notebook-group-item-icon", children: l.icon || /* @__PURE__ */ e(et, { size: 22 }) }),
      /* @__PURE__ */ o("span", { className: "fp-notebook-group-item-name", children: [
        /* @__PURE__ */ e("strong", { children: l.name }),
        l.detail && /* @__PURE__ */ e("small", { children: l.detail })
      ] })
    ] }, l.id)) }),
    /* @__PURE__ */ e("p", { className: "fp-notebook-group-sync-note", children: "加入后，组内笔记本会随分享者的调整同步更新。" }),
    a
  ] });
}
function Ng({ title: t, description: n, tab: r, tabs: i, onTabChange: a, onClose: l, busy: s, children: c, footer: u, message: d }) {
  return /* @__PURE__ */ o(Ye, { open: !0, title: t, className: "fp-sharing-dialog", onClose: l, dismissible: !s, footer: u, children: [
    n && /* @__PURE__ */ e("p", { className: "fp-sharing-description", children: n }),
    i.length > 1 && /* @__PURE__ */ e(Ge, { label: "分享设置", value: r, items: i, onChange: a }),
    /* @__PURE__ */ e("section", { className: "fp-sharing-content", children: c }),
    d && /* @__PURE__ */ e("p", { role: "status", className: "fp-sharing-message", children: d })
  ] });
}
function xg({ label: t, url: n, detail: r, active: i = !0, busy: a, copied: l, onCopy: s, onRevoke: c }) {
  return /* @__PURE__ */ o("section", { className: "fp-share-link-card", children: [
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("small", { children: r }),
    i && /* @__PURE__ */ o(ee, { children: [
      /* @__PURE__ */ e("input", { className: "fp-input", "aria-label": t, value: n, readOnly: !0, onFocus: (u) => u.target.select() }),
      /* @__PURE__ */ e(or, { showLabels: !0, label: "链接操作", actions: [{ id: "copy", label: l ? "已复制" : "复制链接", icon: /* @__PURE__ */ e(vn, { size: 16 }), onSelect: s, disabled: a }, { id: "revoke", label: "停用链接", icon: /* @__PURE__ */ e(ft, { size: 16 }), onSelect: c, disabled: a }] })
    ] })
  ] });
}
function Cg({ name: t, avatar: n, permission: r }) {
  return /* @__PURE__ */ o("span", { className: "fp-shared-attribution", children: [
    "由 ",
    /* @__PURE__ */ e(kn, { name: t, src: n, size: 20 }),
    /* @__PURE__ */ e("span", { className: "fp-shared-name", children: t }),
    " 分享",
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "·" }),
    /* @__PURE__ */ e("span", { children: r })
  ] });
}
function Sg() {
  return /* @__PURE__ */ e(gn, { text: "他人分享的笔记本", children: /* @__PURE__ */ e("span", { className: "fp-shared-notebook-marker", "aria-label": "他人分享的笔记本", children: /* @__PURE__ */ e(is, { size: 12, "aria-hidden": "true" }) }) });
}
function Mg({ title: t = "导出 PDF", choices: n, value: r, onChange: i, onClose: a, onExport: l, busy: s, disabled: c, summary: u, error: d, children: p, navigation: h, preview: f, completed: m }) {
  return /* @__PURE__ */ e(Ye, { open: !0, title: t, className: "fp-document-export" + (f && !m ? " fp-document-export-preview" : ""), onClose: a, dismissible: !s, footer: m ? /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e(te, { variant: "ghost", onClick: a, children: "关闭" }),
    /* @__PURE__ */ e(te, { onClick: m.onViewQueue, children: "查看处理队列" })
  ] }) : /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e(te, { variant: "ghost", onClick: a, disabled: s, children: "取消" }),
    /* @__PURE__ */ e(te, { "aria-label": s ? "正在加入队列" : "确认导出", onClick: l, loading: s, disabled: c, children: "确认导出" })
  ] }), children: m ? /* @__PURE__ */ o("section", { className: "fp-export-completed", role: "status", children: [
    /* @__PURE__ */ e(ct, { size: 40 }),
    /* @__PURE__ */ e("h3", { children: "已加入处理队列" }),
    /* @__PURE__ */ e("p", { children: m.description }),
    /* @__PURE__ */ e("p", { className: "fp-export-help", children: "可以继续浏览笔记，完成后 PDF 会保存到资源中心。" })
  ] }) : /* @__PURE__ */ o(ee, { children: [
    n.length > 1 && /* @__PURE__ */ o("fieldset", { children: [
      /* @__PURE__ */ e("legend", { children: "导出范围" }),
      n.map((b) => /* @__PURE__ */ o("label", { className: "fp-export-choice", "data-selected": r === b.id, children: [
        /* @__PURE__ */ e("input", { type: "radio", name: "export-scope", value: b.id, checked: r === b.id, disabled: s, onChange: () => {
          s || i(b.id);
        } }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: b.label }),
          b.description && /* @__PURE__ */ e("small", { children: b.description })
        ] })
      ] }, b.id))
    ] }),
    p,
    /* @__PURE__ */ e("p", { className: "fp-export-summary", role: "status", children: u || "正在读取导出范围…" }),
    d && /* @__PURE__ */ e("p", { role: "alert", children: d }),
    f && /* @__PURE__ */ o("div", { className: "fp-export-workspace", children: [
      h && /* @__PURE__ */ e("nav", { "aria-label": "导出内容目录", className: "fp-export-navigation", children: h }),
      /* @__PURE__ */ e("section", { "aria-label": "导出内容预览", className: "fp-export-preview", children: /* @__PURE__ */ e("div", { className: "fp-export-paper", children: f }) })
    ] }),
    /* @__PURE__ */ e("p", { className: "fp-export-help", children: "确认后开始处理。多篇笔记会合并并自动生成目录，PDF 将保存到资源中心。" })
  ] }) });
}
function Eg(t) {
  return /* @__PURE__ */ e(dl, { children: /* @__PURE__ */ o("div", { className: "fp-account-entry-choices", children: [
    /* @__PURE__ */ o("div", { className: "fp-account-entry-choice", "data-emphasis": "primary", children: [
      t.primaryAction,
      !t.helpLabel && /* @__PURE__ */ e("p", { children: t.primaryDescription })
    ] }),
    t.secondaryAction && /* @__PURE__ */ o("div", { className: "fp-account-entry-choice", "data-emphasis": "secondary", children: [
      t.secondaryAction,
      !t.helpLabel && /* @__PURE__ */ e("p", { children: t.secondaryDescription })
    ] }),
    t.helpLabel && /* @__PURE__ */ e(Ep, { className: "fp-account-entry-help", label: /* @__PURE__ */ o("span", { className: "fp-account-entry-help-label", children: [
      /* @__PURE__ */ e(as, { size: 16, "aria-hidden": "true" }),
      t.helpLabel
    ] }), children: /* @__PURE__ */ o("div", { className: "fp-account-entry-help-copy", children: [
      /* @__PURE__ */ e("p", { children: t.primaryDescription }),
      t.secondaryAction && t.secondaryDescription && /* @__PURE__ */ e("p", { children: t.secondaryDescription }),
      t.helpContent
    ] }) })
  ] }) });
}
function $g(t) {
  const [n, r] = k(t.products[0]?.id), i = t.products.find((s) => s.id === n) ?? t.products[0], a = R(null), l = ve();
  return /* @__PURE__ */ o("div", { className: "fp-ecosystem", children: [
    /* @__PURE__ */ o("main", { children: [
      /* @__PURE__ */ o("section", { className: "fp-ecosystem-hero", children: [
        /* @__PURE__ */ o("div", { className: "fp-ecosystem-copy", children: [
          /* @__PURE__ */ e("p", { className: "fp-ecosystem-eyebrow", children: t.eyebrow }),
          /* @__PURE__ */ o("h1", { children: [
            t.title,
            /* @__PURE__ */ e("span", { children: t.statement })
          ] }),
          /* @__PURE__ */ e("p", { className: "fp-ecosystem-description", children: t.description }),
          /* @__PURE__ */ e("div", { className: "fp-ecosystem-actions", children: t.actions })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-ecosystem-map", "aria-label": t.ecosystemLabel, children: [
          /* @__PURE__ */ o("div", { className: "fp-ecosystem-map-heading", children: [
            t.brand,
            /* @__PURE__ */ e("span", { children: t.ecosystemLabel })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-ecosystem-orbit", children: [
            /* @__PURE__ */ o("svg", { className: "fp-ecosystem-flow", viewBox: "0 0 500 360", "aria-hidden": "true", children: [
              /* @__PURE__ */ e("path", { d: "M95 100 Q75 270 250 300 M390 75 Q450 250 250 300 M285 190 Q285 260 250 300" }),
              /* @__PURE__ */ e("path", { className: "fp-ecosystem-current", d: "M95 100 Q75 270 250 300 M390 75 Q450 250 250 300 M285 190 Q285 260 250 300" })
            ] }),
            t.products.map((s, c) => /* @__PURE__ */ e(gn, { text: s.name, children: /* @__PURE__ */ o("button", { type: "button", className: "fp-ecosystem-node", "data-position": c, "data-active": i?.id === s.id, onClick: () => r(s.id), children: [
              /* @__PURE__ */ e("span", { children: s.icon }),
              /* @__PURE__ */ e("strong", { children: s.name }),
              /* @__PURE__ */ e("small", { children: s.category })
            ] }) }, s.id)),
            /* @__PURE__ */ o("div", { className: "fp-ecosystem-foundation", children: [
              /* @__PURE__ */ e("span", { className: "fp-ecosystem-foundation-mark", "aria-hidden": "true", children: "5+1" }),
              /* @__PURE__ */ o("div", { children: [
                /* @__PURE__ */ e("strong", { children: t.title }),
                /* @__PURE__ */ e("span", { children: t.foundationLabel })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-ecosystem-section", "aria-labelledby": "ecosystem-products", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("p", { className: "fp-ecosystem-eyebrow", children: t.ecosystemLabel }),
          /* @__PURE__ */ e("h2", { id: "ecosystem-products", children: t.ecosystemTitle }),
          /* @__PURE__ */ e("p", { children: t.ecosystemDescription })
        ] }),
        i && /* @__PURE__ */ o("div", { className: "fp-ecosystem-showcase", children: [
          /* @__PURE__ */ e("div", { ref: a, className: "fp-ecosystem-tabs", role: "tablist", "aria-label": t.ecosystemLabel, onKeyDown: (s) => {
            const c = t.products.findIndex((d) => d.id === i.id);
            let u = c;
            if (s.key === "ArrowRight" || s.key === "ArrowDown") u = (c + 1) % t.products.length;
            else if (s.key === "ArrowLeft" || s.key === "ArrowUp") u = (c - 1 + t.products.length) % t.products.length;
            else if (s.key === "Home") u = 0;
            else if (s.key === "End") u = t.products.length - 1;
            else return;
            s.preventDefault(), r(t.products[u].id), a.current?.querySelectorAll("[role=tab]")[u]?.focus();
          }, children: t.products.map((s, c) => /* @__PURE__ */ e(gn, { text: s.name, children: /* @__PURE__ */ o("button", { type: "button", role: "tab", id: `${l}-${s.id}`, "aria-controls": `${l}-panel`, "aria-selected": i.id === s.id, tabIndex: i.id === s.id ? 0 : -1, onClick: () => r(s.id), children: [
            /* @__PURE__ */ o("span", { "aria-hidden": "true", children: [
              "0",
              c + 1
            ] }),
            /* @__PURE__ */ o("span", { children: [
              s.category,
              /* @__PURE__ */ e("strong", { children: s.name })
            ] }),
            /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "↗" })
          ] }) }, s.id)) }),
          /* @__PURE__ */ o("div", { className: "fp-ecosystem-story", role: "tabpanel", id: `${l}-panel`, "aria-labelledby": `${l}-${i.id}`, tabIndex: 0, children: [
            /* @__PURE__ */ o("div", { className: "fp-ecosystem-story-art", "aria-hidden": "true", children: [
              /* @__PURE__ */ e("i", {}),
              /* @__PURE__ */ e("i", {}),
              /* @__PURE__ */ e("span", { children: i.icon }),
              /* @__PURE__ */ e("b", { children: "5+1" })
            ] }),
            /* @__PURE__ */ o("div", { className: "fp-ecosystem-story-copy", children: [
              /* @__PURE__ */ e("p", { className: "fp-ecosystem-eyebrow", children: i.category }),
              /* @__PURE__ */ e("h3", { children: i.name }),
              /* @__PURE__ */ e("p", { children: i.description }),
              /* @__PURE__ */ o("a", { href: i.href, target: "_blank", rel: "noopener noreferrer", "aria-label": `${t.visitLabel} ${i.name}`, className: "fp-ecosystem-visit", children: [
                t.visitLabel,
                /* @__PURE__ */ e("span", { "aria-hidden": "true", children: " ↗" })
              ] })
            ] }, i.id)
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-ecosystem-section fp-ecosystem-capabilities", "aria-labelledby": "ecosystem-foundation", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("p", { className: "fp-ecosystem-eyebrow", children: t.foundationLabel }),
          /* @__PURE__ */ e("h2", { id: "ecosystem-foundation", children: t.foundationTitle }),
          /* @__PURE__ */ e("p", { children: t.foundationDescription })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-ecosystem-capability-grid", children: t.capabilities.map((s) => /* @__PURE__ */ o("article", { children: [
          s.icon,
          /* @__PURE__ */ e("h3", { children: s.title }),
          /* @__PURE__ */ e("p", { children: s.description })
        ] }, s.title)) })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-ecosystem-closing", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("p", { className: "fp-ecosystem-eyebrow", children: "5PLUS1 / AI" }),
          /* @__PURE__ */ e("h2", { children: t.closingTitle }),
          /* @__PURE__ */ e("p", { children: t.closingDescription })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-ecosystem-actions", children: t.closingActions })
      ] })
    ] }),
    t.footer
  ] });
}
function zg({
  svg: t,
  title: n,
  width: r,
  height: i,
  sourceSvg: a,
  topic: l,
  onRevisionAccepted: s
}) {
  return /* @__PURE__ */ e(
    di,
    {
      block: {
        kind: "raw-svg",
        title: n,
        width: r,
        height: i,
        source: a || t
      },
      revisionTopic: l,
      onRevisionAccepted: s
    }
  );
}
function Ag(t, n) {
  const r = (c) => {
    const u = /(`+)[\s\S]*?\1/g;
    let d = "", p = 0, h;
    for (; h = u.exec(c); )
      d += n(c.slice(p, h.index)) + h[0], p = u.lastIndex;
    return d + n(c.slice(p));
  }, i = /^ {0,3}(`{3,}|~{3,})[^\r\n]*\r?\n/gm;
  let a = "", l = 0, s;
  for (; s = i.exec(t); ) {
    a += r(t.slice(l, s.index));
    const c = new RegExp(`^ {0,3}${s[1][0]}{${s[1].length},}[\\t ]*(?:\\r?\\n|$)`, "gm");
    if (c.lastIndex = i.lastIndex, !c.exec(t)) return a + t.slice(s.index);
    a += t.slice(s.index, c.lastIndex), l = c.lastIndex, i.lastIndex = l;
  }
  return a + r(t.slice(l));
}
function Lg(t) {
  const n = [], r = (c) => {
    if (!c) return;
    const u = n.at(-1);
    u?.kind === "markdown" ? u.content += c : n.push({ kind: "markdown", content: c });
  }, i = (c) => {
    const u = /(`+)[\s\S]*?\1|<\/?svg\b[^>]*>/gi;
    let d, p = 0, h = 0, f = 0;
    for (; d = u.exec(c); ) {
      if (d[1] && !p || d[0].startsWith("`")) continue;
      const m = /^<\//.test(d[0]), b = /\/\s*>$/.test(d[0]);
      if (!m)
        p === 0 && (h = d.index), b || p++;
      else if (p > 0) p--;
      else continue;
      p === 0 && (r(c.slice(f, h)), n.push({ kind: "svg", content: c.slice(h, u.lastIndex) }), f = u.lastIndex);
    }
    r(c.slice(f));
  }, a = /^ {0,3}(`{3,}|~{3,})([^\r\n]*)\r?\n/gm;
  let l, s = 0;
  for (; l = a.exec(t); ) {
    i(t.slice(s, l.index));
    const c = new RegExp(`^ {0,3}${l[1][0]}{${l[1].length},}[\\t ]*(?:\\r?\\n|$)`, "gm");
    c.lastIndex = a.lastIndex;
    const u = c.exec(t);
    if (!u)
      return r(t.slice(l.index)), n;
    const d = t.slice(a.lastIndex, u.index).trim(), p = l[2].trim().toLowerCase();
    ["", "svg", "xml", "html"].includes(p) && /^<svg\b[\s\S]*<\/svg\s*>$/i.test(d) ? i(d) : r(t.slice(l.index, c.lastIndex)), s = c.lastIndex, a.lastIndex = s;
  }
  return i(t.slice(s)), n;
}
function bt({
  label: t,
  children: n,
  ...r
}) {
  return /* @__PURE__ */ e(
    te,
    {
      variant: "ghost",
      ...r,
      className: Ve("fp-icon-button", r.className),
      "aria-label": t,
      title: t,
      children: n
    }
  );
}
function fi({
  className: t,
  ...n
}) {
  return /* @__PURE__ */ e("input", { ...n, className: Ve("fp-input", t) });
}
function Wp(t) {
  return /* @__PURE__ */ e("textarea", { ...t, className: Ve("fp-input", t.className) });
}
function Ig({
  label: t,
  hint: n,
  error: r,
  children: i
}) {
  let a = ve();
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: a, children: t }),
    mt.cloneElement(i, {
      id: a,
      "aria-describedby": `${a}-help`,
      "aria-invalid": !!r
    }),
    (r || n) && /* @__PURE__ */ e("small", { id: `${a}-help`, className: r ? "fp-error-text" : "", children: r || n })
  ] });
}
function mi({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "checkbox" }),
    t
  ] });
}
function Dg({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "radio" }),
    t
  ] });
}
function _p({
  label: t,
  checked: n,
  onChange: r,
  disabled: i
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-switch-label",
      role: "switch",
      "aria-checked": n,
      disabled: i,
      onClick: () => r(!n),
      children: [
        /* @__PURE__ */ e("span", { children: t }),
        /* @__PURE__ */ e("span", { className: Ve("fp-switch", n && "is-on"), children: /* @__PURE__ */ e("i", {}) })
      ]
    }
  );
}
function Tg({
  label: t,
  min: n = 0,
  max: r = 100,
  step: i = 1,
  value: a,
  defaultValue: l,
  className: s,
  ...c
}) {
  let [u, d] = k(
    () => l === void 0 ? void 0 : Number(l)
  ), p = a !== void 0 ? Number(a) : u, h = Number(n), f = Number(r), m = p === void 0 || f === h ? 0 : (p - h) / (f - h) * 100;
  return /* @__PURE__ */ o("label", { className: Ve("fp-slider", s), children: [
    t,
    /* @__PURE__ */ e(
      "input",
      {
        ...c,
        type: "range",
        min: n,
        max: r,
        step: i,
        value: a,
        defaultValue: l,
        onChange: (b) => {
          d(Number(b.target.value)), c.onChange?.(b);
        },
        style: {
          ...c.style,
          "--fp-slider-fill": `${Math.min(100, Math.max(0, m))}%`
        }
      }
    )
  ] });
}
function Vp({
  children: t,
  selected: n,
  onClick: r,
  onRemove: i
}) {
  return /* @__PURE__ */ o("span", { className: Ve("fp-chip", n && "is-selected"), children: [
    /* @__PURE__ */ e("button", { type: "button", onClick: r, "aria-pressed": n, children: t }),
    i && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-label": `移除 ${typeof t == "string" ? t : "项目"}`,
        onClick: i,
        children: "×"
      }
    )
  ] });
}
function Pg() {
  return /* @__PURE__ */ e("hr", { className: "fp-divider" });
}
function Fg({
  title: t,
  children: n,
  tone: r = "accent"
}) {
  return /* @__PURE__ */ o(
    "div",
    {
      className: `fp-alert fp-tone-${r}`,
      role: r === "error" ? "alert" : "status",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-alert-dot" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: t }),
          n && /* @__PURE__ */ e("p", { children: n })
        ] })
      ]
    }
  );
}
function Og({
  width: t = "100%",
  height: n = 16
}) {
  return /* @__PURE__ */ e("div", { className: "fp-skeleton", style: { width: t, height: n }, "aria-hidden": "true" });
}
function Rg({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-progress-wrap", children: [
    n && /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ o("span", { children: [
        Math.round(t),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "fp-progress",
        role: "progressbar",
        "aria-label": n || "完成进度",
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": Math.min(100, Math.max(0, t)),
        children: /* @__PURE__ */ e("i", { style: { width: `${Math.min(100, Math.max(0, t))}%` } })
      }
    )
  ] });
}
function Gp(t) {
  return /* @__PURE__ */ e("div", { className: "fp-segmented", children: /* @__PURE__ */ e(ii, { ...t }) });
}
function Bg({
  items: t
}) {
  return /* @__PURE__ */ e("nav", { "aria-label": "当前位置", className: "fp-breadcrumbs", children: t.map((n, r) => /* @__PURE__ */ o(mt.Fragment, { children: [
    r > 0 && /* @__PURE__ */ e("span", { children: "/" }),
    n.href ? /* @__PURE__ */ e("a", { href: n.href, children: n.label }) : /* @__PURE__ */ e("span", { "aria-current": "page", children: n.label })
  ] }, n.label)) });
}
function jg({
  page: t,
  total: n,
  onChange: r
}) {
  return /* @__PURE__ */ o("nav", { className: "fp-row", "aria-label": "分页", children: [
    /* @__PURE__ */ e(
      te,
      {
        variant: "secondary",
        size: "sm",
        disabled: t <= 1,
        onClick: () => r(t - 1),
        children: "上一页"
      }
    ),
    /* @__PURE__ */ o("span", { className: "fp-muted", children: [
      t,
      " / ",
      n
    ] }),
    /* @__PURE__ */ e(
      te,
      {
        variant: "secondary",
        size: "sm",
        disabled: t >= n,
        onClick: () => r(t + 1),
        children: "下一页"
      }
    )
  ] });
}
function qg({
  items: t,
  current: n
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-steps", children: t.map((r, i) => /* @__PURE__ */ o(
    "li",
    {
      "aria-current": i === n ? "step" : void 0,
      className: i <= n ? "is-active" : "",
      children: [
        /* @__PURE__ */ e("span", { children: i < n ? "✓" : i + 1 }),
        r
      ]
    },
    r
  )) });
}
function Yp({
  title: t,
  description: n,
  action: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-empty", children: [
    /* @__PURE__ */ e("div", { className: "fp-empty-symbol", children: "＋" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r
  ] });
}
function Kg({
  message: t,
  onClose: n
}) {
  return Y(() => {
    let r = setTimeout(n, 4e3);
    return () => clearTimeout(r);
  }, [t, n]), /* @__PURE__ */ o("div", { className: "fp-toast", role: "status", children: [
    /* @__PURE__ */ e("span", { children: "✓" }),
    t,
    /* @__PURE__ */ e(bt, { label: "关闭提示", onClick: n, children: "×" })
  ] });
}
function Hg({
  columns: t,
  rows: n,
  caption: r
}) {
  return /* @__PURE__ */ e("div", { className: "fp-table-scroll", children: /* @__PURE__ */ o("table", { className: "fp-table", children: [
    r && /* @__PURE__ */ e("caption", { children: r }),
    /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: t.map((i) => /* @__PURE__ */ e("th", { children: i }, i)) }) }),
    /* @__PURE__ */ e("tbody", { children: n.map((i, a) => /* @__PURE__ */ e("tr", { children: i.map((l, s) => /* @__PURE__ */ e("td", { children: l }, s)) }, a)) })
  ] }) });
}
function Ug({
  items: t
}) {
  return /* @__PURE__ */ e("dl", { className: "fp-descriptions", children: t.map((n) => /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ e("dt", { children: n.label }),
    /* @__PURE__ */ e("dd", { children: n.value })
  ] }, n.label)) });
}
function Xp({
  items: t
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-timeline", children: t.map((n) => /* @__PURE__ */ o("li", { children: [
    /* @__PURE__ */ e("strong", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function Wg({
  label: t,
  value: n,
  detail: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-stat", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e("strong", { children: n }),
    r && /* @__PURE__ */ e("small", { children: r })
  ] });
}
function _g({
  onFiles: t,
  accept: n,
  multiple: r = !0
}) {
  let [i, a] = k([]);
  function l(s) {
    let c = Array.from(s || []);
    a(c.map((u) => u.name)), t(c);
  }
  return /* @__PURE__ */ o(
    "label",
    {
      className: "fp-upload",
      onDragOver: (s) => s.preventDefault(),
      onDrop: (s) => {
        s.preventDefault(), l(s.dataTransfer.files);
      },
      children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: "↥" }),
        /* @__PURE__ */ e("strong", { children: "选择文件，或拖放到这里" }),
        /* @__PURE__ */ e("small", { children: i.length ? i.join("、") : "资料会保留在你的设备上" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "file",
            accept: n,
            multiple: r,
            onChange: (s) => l(s.target.files)
          }
        )
      ]
    }
  );
}
function Qp({
  value: t,
  onChange: n,
  placeholder: r = "搜索内容"
}) {
  return /* @__PURE__ */ o("div", { className: "fp-search-input", children: [
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌕" }),
    /* @__PURE__ */ e(
      fi,
      {
        "aria-label": r,
        placeholder: r,
        value: t,
        onChange: (i) => n(i.target.value)
      }
    ),
    t && /* @__PURE__ */ e(bt, { label: "清除搜索", onClick: () => n(""), children: "×" })
  ] });
}
function Vg({
  value: t,
  onChange: n,
  min: r = 0,
  max: i = 100,
  label: a
}) {
  return /* @__PURE__ */ o("div", { className: "fp-number", children: [
    /* @__PURE__ */ e(
      bt,
      {
        label: `减少${a}`,
        disabled: t <= r,
        onClick: () => n(t - 1),
        children: "−"
      }
    ),
    /* @__PURE__ */ e(
      fi,
      {
        "aria-label": a,
        type: "number",
        min: r,
        max: i,
        value: t,
        onChange: (l) => n(Math.min(i, Math.max(r, Number(l.target.value))))
      }
    ),
    /* @__PURE__ */ e(
      bt,
      {
        label: `增加${a}`,
        disabled: t >= i,
        onClick: () => n(t + 1),
        children: "＋"
      }
    )
  ] });
}
function Gg({
  value: t,
  onChange: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-rating", role: "group", "aria-label": "评价", children: [1, 2, 3, 4, 5].map((r) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      "aria-label": `${r} 星`,
      "aria-pressed": r === t,
      onClick: () => n(r),
      className: r <= t ? "is-active" : "",
      children: "★"
    },
    r
  )) });
}
function Yg({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-meter", children: [
    /* @__PURE__ */ e("meter", { min: 0, max: 100, value: t, "aria-label": n }),
    /* @__PURE__ */ o("span", { children: [
      n,
      " · ",
      t,
      "%"
    ] })
  ] });
}
function Xg({
  code: t,
  language: n = "tsx"
}) {
  let [r, i] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-code", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ e(
        te,
        {
          size: "sm",
          variant: "ghost",
          onClick: async () => {
            try {
              await navigator.clipboard.writeText(t), i(!0), setTimeout(() => i(!1), 1800);
            } catch {
              i(!1);
            }
          },
          children: r ? "已复制" : "复制"
        }
      )
    ] }),
    /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: t }) })
  ] });
}
function Qg({ children: t }) {
  return /* @__PURE__ */ e("kbd", { className: "fp-kbd", children: t });
}
function Jg({
  children: t,
  ...n
}) {
  return /* @__PURE__ */ e("a", { ...n, className: Ve("fp-link", n.className), children: t });
}
function Zg({
  items: t
}) {
  return /* @__PURE__ */ e("div", { className: "fp-tree", children: t.map((n) => /* @__PURE__ */ e(Jp, { item: n }, n.label)) });
}
function Jp({
  item: t
}) {
  const [n, r] = mt.useState(!0), i = mt.useId();
  return t.children ? /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-tree-branch",
        "aria-expanded": n,
        "aria-controls": i,
        onClick: () => r((a) => !a),
        children: [
          /* @__PURE__ */ e(
            St,
            {
              size: 14,
              style: { transform: n ? "rotate(0)" : "rotate(-90deg)" }
            }
          ),
          t.label
        ]
      }
    ),
    /* @__PURE__ */ e(je, { isOpen: n, children: /* @__PURE__ */ e("div", { id: i, children: t.children.map((a) => /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: a }, a)) }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: t.label });
}
function ey({
  items: t,
  value: n,
  onChange: r
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-navigation", children: t.map((i) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-current": n === i.value ? "page" : void 0,
      onClick: () => r(i.value),
      children: [
        i.icon,
        i.label
      ]
    },
    i.value
  )) });
}
function ty({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-toolbar", role: "group", "aria-label": "内容操作", children: t });
}
function ny({
  title: t,
  children: n
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-callout", children: [
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function ry({
  title: t,
  detail: n,
  onClick: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-citation", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "↗" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] })
  ] });
}
function iy({
  role: t,
  children: n
}) {
  return /* @__PURE__ */ o("article", { className: `fp-message fp-message-${t}`, children: [
    /* @__PURE__ */ e("strong", { children: t === "user" ? "你" : "五加一 AI" }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function ay({
  onSend: t,
  disabled: n = !1
}) {
  let [r, i] = k("");
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-composer",
      onSubmit: (a) => {
        a.preventDefault(), r.trim() && (t(r.trim()), i(""));
      },
      children: [
        /* @__PURE__ */ e(
          Wp,
          {
            "aria-label": "向 AI 提问",
            placeholder: "从一个想法开始…",
            value: r,
            onChange: (a) => i(a.target.value),
            disabled: n
          }
        ),
        /* @__PURE__ */ o("footer", { children: [
          /* @__PURE__ */ e("span", { children: "让想法继续生长" }),
          /* @__PURE__ */ e(te, { size: "sm", disabled: n || !r.trim(), type: "submit", children: "发送 ↑" })
        ] })
      ]
    }
  );
}
function ly({
  title: t,
  steps: n,
  running: r,
  onToggle: i
}) {
  return /* @__PURE__ */ o(Bt, { children: [
    /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(ni, { tone: r ? "accent" : "neutral", children: r ? "进行中" : "已暂停" })
    ] }),
    /* @__PURE__ */ e(
      Xp,
      {
        items: n.map((a, l) => ({
          title: a,
          description: l === n.length - 1 ? r ? "正在进行" : "等待继续" : "已完成"
        }))
      }
    ),
    /* @__PURE__ */ e(te, { variant: "secondary", size: "sm", onClick: i, children: r ? "暂停整理" : "继续整理" })
  ] });
}
function oy({
  title: t,
  description: n,
  onApply: r
}) {
  return /* @__PURE__ */ o(Bt, { children: [
    /* @__PURE__ */ e(ni, { tone: "success", children: "已完成" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { className: "fp-muted", children: n }),
    /* @__PURE__ */ e(te, { onClick: r, children: "应用到笔记 ↗" })
  ] });
}
function sy({
  name: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-file-card", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "▤" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { children: "↗" })
  ] });
}
function cy({
  eyebrow: t,
  title: n,
  description: r,
  action: i
}) {
  return /* @__PURE__ */ o("header", { className: "fp-page-header", children: [
    /* @__PURE__ */ o("div", { children: [
      t && /* @__PURE__ */ e("span", { className: "fp-eyebrow", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      r && /* @__PURE__ */ e("p", { children: r })
    ] }),
    i
  ] });
}
function dy({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: Ve("fp-container", n), children: t });
}
function uy({
  children: t,
  gap: n,
  direction: r = "column"
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "flex",
        flexDirection: r,
        gap: n ?? (r === "row" ? 12 : 24),
        flexWrap: r === "row" ? "wrap" : void 0
      },
      children: t
    }
  );
}
function py({
  children: t,
  minWidth: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "grid",
        gridTemplateColumns: `repeat(auto-fit,minmax(min(${n}px,100%),1fr))`,
        gap: 20
      },
      children: t
    }
  );
}
function hy({
  children: t,
  height: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-scroll-area",
      tabIndex: 0,
      style: { maxHeight: n, overflow: "auto" },
      children: t
    }
  );
}
function fy({
  children: t,
  ratio: n = 16 / 9
}) {
  return /* @__PURE__ */ e("div", { style: { aspectRatio: n, overflow: "hidden" }, children: t });
}
function my({
  label: t,
  options: n,
  value: r,
  onChange: i
}) {
  return /* @__PURE__ */ o("fieldset", { className: "fp-multiselect", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    n.map((a) => /* @__PURE__ */ e(
      Vp,
      {
        selected: r.includes(a),
        onClick: () => i(
          r.includes(a) ? r.filter((l) => l !== a) : [...r, a]
        ),
        children: a
      },
      a
    ))
  ] });
}
function by({
  label: t = "密码",
  ...n
}) {
  let [r, i] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-password", children: [
    /* @__PURE__ */ e(fi, { ...n, "aria-label": t, type: r ? "text" : "password" }),
    /* @__PURE__ */ e(
      bt,
      {
        label: r ? "隐藏密码" : "显示密码",
        onClick: () => i(!r),
        type: "button",
        children: r ? "隐藏" : "显示"
      }
    )
  ] });
}
function gy({
  children: t,
  onClose: n
}) {
  return /* @__PURE__ */ o("div", { className: "fp-banner", role: "status", children: [
    /* @__PURE__ */ e("span", { children: t }),
    n && /* @__PURE__ */ e(bt, { label: "关闭通知", onClick: n, children: "×" })
  ] });
}
function yy({
  value: t,
  onChange: n
}) {
  let r = t ? /* @__PURE__ */ new Date(t + "T12:00:00") : /* @__PURE__ */ new Date(), [i, a] = k(
    new Date(r.getFullYear(), r.getMonth(), 1)
  ), l = i.getFullYear(), s = i.getMonth(), c = new Date(l, s, 1).getDay(), u = new Date(l, s + 1, 0).getDate();
  return /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e(
        bt,
        {
          label: "上个月",
          onClick: () => a(new Date(l, s - 1, 1)),
          children: "‹"
        }
      ),
      /* @__PURE__ */ o("strong", { children: [
        l,
        " 年 ",
        s + 1,
        " 月"
      ] }),
      /* @__PURE__ */ e(
        bt,
        {
          label: "下个月",
          onClick: () => a(new Date(l, s + 1, 1)),
          children: "›"
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-calendar-grid", children: [
      "日一二三四五六".split("").map((d) => /* @__PURE__ */ e("span", { children: d }, d)),
      Array.from({ length: c }, (d, p) => /* @__PURE__ */ e("span", {}, "s" + p)),
      Array.from({ length: u }, (d, p) => {
        let h = `${l}-${String(s + 1).padStart(2, "0")}-${String(p + 1).padStart(2, "0")}`;
        return /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": h,
            "aria-pressed": t === h,
            onClick: () => n(h),
            children: p + 1
          },
          h
        );
      })
    ] })
  ] });
}
function vy({
  first: t,
  second: n
}) {
  let [r, i] = k(50), a = R(null);
  return /* @__PURE__ */ o(
    "div",
    {
      ref: a,
      className: "fp-resizable",
      style: {
        gridTemplateColumns: `minmax(0,${r}fr) 10px minmax(0,${100 - r}fr)`
      },
      children: [
        /* @__PURE__ */ e("div", { children: t }),
        /* @__PURE__ */ e(
          "div",
          {
            role: "separator",
            "aria-label": "调整面板宽度",
            "aria-orientation": "vertical",
            "aria-valuenow": Math.round(r),
            "aria-valuemin": 25,
            "aria-valuemax": 75,
            tabIndex: 0,
            onKeyDown: (l) => {
              ["ArrowLeft", "ArrowRight", "Home", "End"].includes(l.key) && (l.preventDefault(), i(
                l.key === "Home" ? 25 : l.key === "End" ? 75 : Math.max(
                  25,
                  Math.min(75, r + (l.key === "ArrowRight" ? 5 : -5))
                )
              ));
            },
            onPointerDown: (l) => {
              l.currentTarget.setPointerCapture(l.pointerId);
            },
            onPointerMove: (l) => {
              if (l.currentTarget.hasPointerCapture(l.pointerId)) {
                let s = a.current.getBoundingClientRect();
                i(
                  Math.max(
                    25,
                    Math.min(75, (l.clientX - s.left) / s.width * 100)
                  )
                );
              }
            }
          }
        ),
        /* @__PURE__ */ e("div", { children: n })
      ]
    }
  );
}
function wy({
  open: t,
  onClose: n,
  onConfirm: r,
  title: i,
  description: a
}) {
  return /* @__PURE__ */ e(
    Ye,
    {
      open: t,
      onClose: n,
      title: i,
      footer: /* @__PURE__ */ o(ee, { children: [
        /* @__PURE__ */ e(te, { variant: "secondary", onClick: n, children: "取消" }),
        /* @__PURE__ */ e(te, { variant: "danger", onClick: r, children: "确认移除" })
      ] }),
      children: /* @__PURE__ */ e("p", { children: a })
    }
  );
}
function ky({
  open: t,
  onClose: n,
  items: r
}) {
  let [i, a] = k(""), [l, s] = k(0), c = r.filter(
    (u) => u.label.toLowerCase().includes(i.toLowerCase())
  );
  return Y(() => {
    t && (a(""), s(0));
  }, [t]), /* @__PURE__ */ e(Ye, { open: t, onClose: n, title: "快速前往", children: /* @__PURE__ */ o(
    "div",
    {
      onKeyDown: (u) => {
        u.key === "ArrowDown" && (u.preventDefault(), s((l + 1) % Math.max(1, c.length))), u.key === "ArrowUp" && (u.preventDefault(), s(
          (l - 1 + c.length) % Math.max(1, c.length)
        )), u.key === "Enter" && c[l] && (u.preventDefault(), c[l].onSelect(), n());
      },
      children: [
        /* @__PURE__ */ e(
          Qp,
          {
            value: i,
            onChange: (u) => {
              a(u), s(0);
            },
            placeholder: "搜索页面与组件"
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-command-results", children: [
          c.map((u, d) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: d === l ? "is-active" : "",
              onClick: () => {
                u.onSelect(), n();
              },
              children: [
                u.label,
                /* @__PURE__ */ e("span", { children: "↵" })
              ]
            },
            u.label
          )),
          !c.length && /* @__PURE__ */ e("p", { children: "没有匹配的结果，试试其他关键词。" })
        ] })
      ]
    }
  ) });
}
function Ny({
  items: t,
  onRead: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-notifications", children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
    /* @__PURE__ */ e("span", { className: Ve("fp-notification-dot", !r.read && "is-unread") }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: r.title }),
      /* @__PURE__ */ e("small", { children: r.detail })
    ] }),
    /* @__PURE__ */ e("span", { children: r.read ? "已读" : "查看" })
  ] }, r.id)) });
}
function xy({
  items: t,
  label: n
}) {
  let r = Math.max(1, ...t.map((i) => i.value));
  return /* @__PURE__ */ o("figure", { className: "fp-chart", "aria-label": n, children: [
    /* @__PURE__ */ e("figcaption", { children: n }),
    t.map((i) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("span", { children: i.label }),
      /* @__PURE__ */ e("i", { style: { width: `${i.value / r * 70}%` } }),
      /* @__PURE__ */ e("strong", { children: i.value })
    ] }, i.label))
  ] });
}
function Cy({ src: t, alt: n }) {
  let [r, i] = k(!1);
  return /* @__PURE__ */ o(ee, { children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-image-button",
        onClick: () => i(!0),
        "aria-label": `放大${n}`,
        children: /* @__PURE__ */ e("img", { src: t, alt: n })
      }
    ),
    /* @__PURE__ */ e(Ye, { open: r, onClose: () => i(!1), title: n, children: /* @__PURE__ */ e("img", { style: { width: "100%" }, src: t, alt: n }) })
  ] });
}
function Sy({
  title: t = "暂时无法显示内容",
  description: n,
  onRetry: r
}) {
  return /* @__PURE__ */ e(
    Yp,
    {
      title: t,
      description: n,
      action: /* @__PURE__ */ e(te, { onClick: r, children: "重新加载" })
    }
  );
}
function My({ children: t }) {
  return /* @__PURE__ */ e("footer", { className: "fp-footer", children: t });
}
function Ey({ children: t }) {
  return /* @__PURE__ */ e("span", { className: "fp-sr-only", children: t });
}
export {
  ay as AIComposer,
  iy as AIMessage,
  Gf as AISettingsWorkspace,
  Gm as AcademicYearSwitcher,
  qh as Accordion,
  bg as AccountCodeField,
  Eg as AccountEntryChoices,
  fg as AccountFeedback,
  Up as AccountField,
  Af as AccountLayout,
  xb as AccountMenu,
  wm as AccountPanel,
  km as AccountSetting,
  yg as AccountTaskDialog,
  hg as AccountTaskProgress,
  mg as AccountVerificationIntro,
  vm as AccountWorkspace,
  or as ActionToolbar,
  Il as AdministratorAccess,
  Rf as AdministratorDirectory,
  Tm as AgentTrace,
  Fg as Alert,
  Zb as AnalyticsWorkspace,
  Jf as AnchoredPanel,
  ge as AnimatedSize,
  Ob as AppEntryLayout,
  Xf as AppearanceWorkspace,
  Sb as ApplicationAccess,
  Xm as ApprovalCard,
  om as ArtifactCard,
  sm as ArtifactPreview,
  fy as AspectRatio,
  ig as AssistantPreferences,
  ye as AsyncAction,
  bl as Attachment,
  Bm as AttachmentGrid,
  Am as AttachmentPicker,
  Fn as AudioPlayer,
  cg as AuditLogWorkspace,
  _m as AuthenticationWindow,
  kn as Avatar,
  Nm as AvatarEditor,
  Mf as AvatarGroup,
  mf as BacklinksPanel,
  ni as Badge,
  gy as Banner,
  xy as BarChart,
  $f as Bookshelf,
  nb as BottomNav,
  ym as BrandLogo,
  Bg as Breadcrumbs,
  Xu as BrowserPreferences,
  Ju as BrowserSurface,
  Sf as BrowserWorkspace,
  te as Button,
  Fb as ButtonLink,
  yy as Calendar,
  ny as Callout,
  Ir as CanvasBlockRenderer,
  Fc as CanvasDiagnosticPanel,
  Oc as CanvasRevisionPanel,
  um as CanvasWorkbench,
  Wf as CanvasWorkspace,
  Bf as CapacityDirectory,
  Ll as CapacityEditor,
  of as CapacityOverview,
  Bt as Card,
  _s as CardBodyBoundary,
  rm as CardEditorFrame,
  Ed as CauseEffect,
  $m as ChatComposer,
  Hm as ChatEmptyState,
  bb as ChatPreferencesPanel,
  mi as Checkbox,
  Vp as Chip,
  Cb as ChoiceCards,
  ry as Citation,
  Ym as CitationList,
  pm as ClassroomTimeline,
  Xg as CodeBlock,
  Mm as CollaborativeEditor,
  je as CollapseTransition,
  Ep as CollapsibleSection,
  Pl as ColorPicker,
  gm as Combobox,
  ky as CommandMenu,
  _f as CommerceWorkspace,
  Cd as CompareTable,
  xd as ConceptCard,
  wy as ConfirmDialog,
  dy as Container,
  Dr as ContentImage,
  Dl as ContentSkeleton,
  xt as ContextMenu,
  Dm as ConversationViewport,
  yf as CourseContentWorkspace,
  tp as CreditAdjustment,
  lf as CreditsOverview,
  ra as DatePicker,
  $d as Derivation,
  Ug as DescriptionList,
  Ye as Dialog,
  fl as DirectiveBlock,
  Xs as DirectiveFields,
  Tf as DirectoryPicker,
  Ef as DirectoryWorkspace,
  nm as DiscardChangesPrompt,
  eb as DistributionChart,
  Pg as Divider,
  Mg as DocumentExportDialog,
  zb as DocumentationCards,
  $b as DocumentationLayout,
  Lb as DocumentationSearch,
  Kh as Drawer,
  Pa as Dropdown,
  $g as EcosystemLanding,
  cl as EditorContextMenu,
  cu as EditorUniqueID,
  qm as EmbedFallback,
  Yp as EmptyState,
  Sy as ErrorState,
  Ui as EventCard,
  Gh as ExperimentLibrary,
  pg as ExperimentWorkbench,
  Eb as FeatureCardStack,
  Ig as Field,
  zd as Figure,
  sy as FileCard,
  xm as FileTree,
  _g as FileUpload,
  Vm as FilterSelect,
  Pm as FlipCard,
  Nf as FloatingWindow,
  qf as FollowUpQuestions,
  My as Footer,
  Zm as FormulaSteps,
  Ga as FunctionPlot,
  dm as GraphView,
  py as Grid,
  Zu as GroupEditor,
  Id as HistoryLocationMap,
  Xh as HistoryMap,
  Os as HorizontalScrollbar,
  bt as IconButton,
  pl as ImageConversion,
  rb as ImageGallery,
  bf as ImagePasteOptions,
  Cy as ImagePreview,
  xf as ImportPanel,
  fi as Input,
  Mb as InstallerPanel,
  Df as InvitationList,
  Qg as Kbd,
  Nd as KeyPoint,
  Cf as LazyVisible,
  Ad as LearningAnimation,
  Ua as LearningExperiment,
  Qf as LearningRecords,
  Ku as LearningSourceView,
  hm as LectureDock,
  qu as LectureWorkspace,
  af as LedgerView,
  Jg as Link,
  Lf as LoginForm,
  ng as ManagementForm,
  Hu as ManagementTable,
  tg as ManagementWorkspace,
  Nt as MarkdownContent,
  lr as MarkdownEditor,
  Im as MarkdownEditorSurface,
  Ab as MarkerLogo,
  js as MediaControls,
  Ap as MediaLightbox,
  Er as MediaSlider,
  vp as MemberAccess,
  wp as MemberSearch,
  Yh as MemoryCard,
  al as MermaidPreview,
  yp as MessageBubble,
  lm as MessageContentView,
  Em as MessageList,
  Yg as Meter,
  Vb as MobileActionGrid,
  Gb as MobileCollectionRow,
  Wb as MobileHeader,
  Xb as MobileNotebookCard,
  Yb as MobileNotebookGrid,
  Jb as MobileRecorder,
  _b as MobileSection,
  zf as MobileTopBar,
  Qb as MobileWelcome,
  Sp as ModelSelector,
  my as MultiSelect,
  ef as NOTE_SCHEMA_VERSION,
  ey as Navigation,
  ab as NavigationCard,
  Vu as NoteEditorWorkspace,
  Qh as NoteLink,
  iu as NoteToolbar,
  pf as NotebookAppearancePicker,
  wg as NotebookGroupEditor,
  kg as NotebookGroupInvitation,
  vg as NotebookGroupTabs,
  uf as NotebookManagerWorkspace,
  Uu as NotebookPublishing,
  hf as NotebookQuickFilters,
  Ny as NotificationList,
  Vg as NumberInput,
  cy as PageHeader,
  jg as Pagination,
  by as PasswordInput,
  Bs as PdfPreview,
  sf as PermissionSummary,
  Pf as PlanPicker,
  jf as PlatformReset,
  Of as PlatformWorkspace,
  Uh as Popover,
  Xe as Popup,
  lb as PreviewCard,
  Tb as ProductEditorialSection,
  Db as ProductEditorialSections,
  qb as ProductFeatures,
  Bb as ProductLanding,
  ep as ProductNavigation,
  kb as ProductPreviewCard,
  jb as ProductSection,
  Ib as ProductStatementHero,
  Rg as Progress,
  ag as ProviderManager,
  jm as QuizQuestion,
  fm as QuizScoring,
  mm as QuizSummary,
  cb as QuizWorkspace,
  ia as READING_FONTS,
  Dg as Radio,
  Gg as Rating,
  di as RawSvgRenderer,
  zg as RawSvgViewer,
  Dd as ReadingTimeline,
  Ld as RecallContent,
  fb as RecordingPlayback,
  ob as RecycleBin,
  Pb as ReleaseNotes,
  Hf as ReleaseNotice,
  vy as ResizablePanel,
  eg as ResourceBrowser,
  Bp as ResourceExplorer,
  Ks as ResourcePreview,
  gb as ResourceWorkspace,
  oy as ResultCard,
  sb as ReviewDashboard,
  hb as RunWorkspace,
  ff as SaveConflict,
  hy as ScrollArea,
  Qp as SearchInput,
  im as SearchResults,
  Gp as SegmentedControl,
  bm as Select,
  Ce as SelectField,
  db as SelectionActions,
  Fm as SelectionToolbar,
  Wm as SessionHistory,
  cf as SettingsForm,
  tm as SettingsLayout,
  lg as SettingsLinks,
  Km as SettingsSection,
  Ge as SettingsTabs,
  df as SetupWizard,
  mb as ShareAccessPanel,
  kp as ShareLink,
  xg as ShareLinkCard,
  em as ShareMemberRow,
  Cg as SharedAttribution,
  Sg as SharedNotebookMarker,
  Kf as SharedReadingPage,
  Ng as SharingDialog,
  tb as ShortcutHelp,
  vf as ShortcutProvider,
  kf as ShortcutSettings,
  Jm as SiblingFiles,
  Og as Skeleton,
  cm as SkillsPanel,
  Vf as SkillsWorkspace,
  dg as SlideTransition,
  Tg as Slider,
  Um as SourceFold,
  ri as Spinner,
  uy as Stack,
  Wg as Stat,
  Rb as StatusPage,
  qg as Steps,
  Du as SuggestionList,
  Ec as SurfaceBoundary,
  Va as SvgCanvas,
  _p as Switch,
  Om as SyncStatus,
  Hg as Table,
  ii as Tabs,
  ub as TaskProgress,
  ly as TaskStatus,
  Wp as Textarea,
  Zf as ThemeToggle,
  Yf as TimePicker,
  Xp as Timeline,
  Kg as Toast,
  Qm as TocTree,
  Mp as TokenDashboard,
  Rm as TokenDashboardAuto,
  ty as Toolbar,
  gn as Tooltip,
  dl as TooltipProvider,
  Ub as TransferQueue,
  Zg as Tree,
  Hb as UpdatePanel,
  rg as UpgradeRequiredDialog,
  hl as UploadPlaceholder,
  Lm as UploadQueue,
  Ff as UserDetailsWorkspace,
  sg as UserNotebookList,
  If as UserProfile,
  Al as UserProfileEditor,
  og as UserUsageOverview,
  Jh as VennDiagram,
  gf as VersionDiff,
  _u as VersionHistory,
  on as VideoPlayer,
  md as VisualCodeBlock,
  Ey as VisuallyHidden,
  $l as WindowChrome,
  vb as WindowControls,
  wb as WindowDragRegion,
  ib as WindowTaskbar,
  pb as WorkspaceEmpty,
  Ee as WorkspaceFeedback,
  X as WorkspaceField,
  Cm as WorkspaceLayout,
  gp as WorkspaceResizeHandle,
  dt as WorkspaceSave,
  ne as WorkspaceSection,
  Kb as WorkspaceSkeleton,
  am as WorkspaceTabs,
  Le as WorkspaceToggle,
  Fs as Y,
  Us as acknowledgeCardEdit,
  dp as appearanceStyles,
  Zh as appendUploadPlaceholder,
  pi as baseEditorExtensions,
  nf as bindNestedMathEditor,
  sp as brandColor,
  mp as brandLogoUrl,
  Nr as calculateAvatarCrop,
  qi as calculateTicks,
  Oa as cardEditRequested,
  Mn as cardTypeForCommand,
  Wi as codeLanguageForCommand,
  ui as compileMathExpr,
  _h as configureEditorCommandUsage,
  tf as configureMathPreferences,
  vr as constrainWindowGeometry,
  Ws as continueAfterCard,
  Nb as createDocumentationMotion,
  op as createEditableAIModel,
  wu as createLazyMathExtensions,
  Ve as cx,
  aa as defaultGraphSettings,
  Od as deleteEditorBlock,
  Xi as documentToMarkdown,
  qa as editorCommandFrequencies,
  Vh as editorCommandFrequency,
  zr as editorCommandUsageChanged,
  $r as editorCommandUsageKey,
  sl as editorInsertCommands,
  bn as editorSearchText,
  bc as getLearningExperiment,
  ur as insertDirectiveCard,
  ll as insertMermaidCard,
  Hh as learningAlpha,
  ai as learningExperiments,
  Ag as mapMarkdownOutsideCode,
  gl as markdownToDocument,
  Wh as mergeEditorCommandUsage,
  yb as mountWindowTitleBar,
  Tr as moveEditorBlock,
  tl as nestedEditorNodeViewEvents,
  zm as normalizeAssistantMarkdown,
  _n as normalizeBrowserUrl,
  El as notebookColors,
  ja as notifyEditorCommandUsage,
  rf as openActiveMathEditor,
  Hs as openEditorLink,
  Fa as ownsCardShortcut,
  Ka as parseDirectiveAttributes,
  Rn as parseEditorCommandUsage,
  lp as parseSkillFile,
  cp as productThemes,
  qp as rankDocumentation,
  Gs as recordEditorCommandUse,
  Kp as renderReleaseNotes,
  wr as replaceAIModelReferences,
  up as resolveContentTypography,
  Lc as sanitizeSvg,
  Kd as searchEditorCommands,
  zi as setDirectiveAttribute,
  Lg as splitSvgMarkdown,
  Pr as tableSizeForCommand,
  gg as useAccountTaskBusy,
  ci as useCanvasGesture,
  Sm as useCollaboration,
  Ru as useMathEditor,
  Uf as useReleaseUpdate,
  wf as useShortcut,
  Pe as useWorkspaceAction,
  at as useWorkspaceDraft,
  ta as validateAISettings,
  ip as validateCommerceSettings,
  pp as visibleActionCount,
  ug as workspaceTabShortcut
};
