import type { ReactNode } from 'react';
import './account-entry-choices.css';
export interface AccountEntryChoicesProps {
    primaryAction: ReactNode;
    primaryDescription: string;
    secondaryAction?: ReactNode;
    secondaryDescription?: string;
    /** Put descriptions behind a compact, initially collapsed help control. */
    helpLabel?: string;
    helpContent?: ReactNode;
}
/** Two account entry actions, ordered by the recommended path. The host owns authentication. */
export declare function AccountEntryChoices(props: AccountEntryChoicesProps): import("react").JSX.Element;
