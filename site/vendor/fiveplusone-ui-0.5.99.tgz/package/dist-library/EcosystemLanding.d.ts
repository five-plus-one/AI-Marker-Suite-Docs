import { type ReactNode } from 'react';
import './ecosystem-landing.css';
export interface EcosystemProduct {
    id: string;
    name: string;
    category: string;
    description: string;
    href: string;
    icon: ReactNode;
}
export interface EcosystemLandingProps {
    eyebrow: string;
    title: string;
    statement: string;
    description: string;
    actions: ReactNode;
    ecosystemLabel: string;
    ecosystemTitle: string;
    ecosystemDescription: string;
    products: EcosystemProduct[];
    visitLabel: string;
    foundationLabel: string;
    foundationTitle: string;
    foundationDescription: string;
    capabilities: {
        title: string;
        description: string;
        icon: ReactNode;
    }[];
    closingTitle: string;
    closingDescription: string;
    closingActions: ReactNode;
    brand: ReactNode;
    footer: ReactNode;
}
/** A product story that connects application entry points to their shared foundation. */
export declare function EcosystemLanding(props: EcosystemLandingProps): import("react").JSX.Element;
