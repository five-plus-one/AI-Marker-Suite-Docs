import { type ReactNode, type ComponentProps } from 'react';
import { PanelResizeHandle } from 'react-resizable-panels';
export interface WorkspaceResizeHandleProps extends Omit<ComponentProps<typeof PanelResizeHandle>, 'children'> {
    label: string;
    onReset?: () => void;
}
/** A keyboard and pointer separator with an immediate, themed resizing hint. */
export declare function WorkspaceResizeHandle({ label, onReset, className, onDoubleClick, onKeyDownCapture, ...props }: WorkspaceResizeHandleProps): import("react").JSX.Element;
export interface WorkspacePanel {
    id: string;
    label: string;
    content: ReactNode;
    defaultSize?: number;
    minSize?: number;
    maxSize?: number;
    collapsible?: boolean;
    collapsedSize?: number;
    onCollapse?: () => void;
    onExpand?: () => void;
    /** Restores the divider immediately before this panel. */
    onResetBefore?: () => void;
}
export interface WorkspaceLayoutHandle {
    getLayout: () => number[];
    setLayout: (sizes: number[]) => void;
    collapse: (id: string) => void;
    expand: (id: string) => void;
    resize: (id: string, size: number) => void;
    isCollapsed: (id: string) => boolean;
}
export interface WorkspaceLayoutProps {
    panels: WorkspacePanel[];
    direction?: 'horizontal' | 'vertical';
    /** A product/account-scoped key; omit to keep the layout in memory. */
    persistenceKey?: string;
    onLayout?: (sizes: number[]) => void;
    className?: string;
}
/** Uses the same resize engine as the KeZhan workspace; nested groups provide split views. */
export declare const WorkspaceLayout: import("react").ForwardRefExoticComponent<WorkspaceLayoutProps & import("react").RefAttributes<WorkspaceLayoutHandle>>;
