import { type ReactNode } from 'react';
import './operations.css';
export { ServiceStatusBoard, StatusToolbar, type PublicServiceItem, type StatusHistorySelection, type StatusHistoryGranularity, type StatusHistoryBucket } from './ServiceStatusBoard';
import './operations-layout.css';
import './operations-table.css';
import './operations-groups.css';
import './workspace-forms.css';
export { Button, Badge, Card, Tabs, Spinner } from './PageControls';
export { ManagementWorkspace } from './ManagementWorkspace';
export { OperationsWorkspace, OperationsColumns, CapacityMeter, QuickSearch, type OperationsNavigationGroup, type QuickSearchItem } from './OperationsWorkspace';
export { ManagementTable } from './ManagementViews';
export { ActionToolbar } from './ActionToolbar';
export { Tooltip, TooltipProvider } from './Tooltip';
export { Dialog } from './Dialog';
export { AccountMenu } from './AccountMenu';
export { ThemeToggle } from './ThemeToggle';
export { DesktopWindowFrame } from './OperationsDesktop';
export { TimeSeriesChart, ShareBreakdownChart, type TimeSeries } from './OperationsChart';
export { DashboardWorkspace, PeriodComparison, type ComparisonMetric, type ComparisonPeriod } from './DashboardWorkspace';
export { ResourceBrowser, type BrowserEntry } from './ResourceBrowser';
export { FileSelection, type FileSelectionProps } from './FileSelection';
export { TransferQueue, type TransferTask } from './TransferQueue';
export { WorkspaceField, WorkspaceToggle, WorkspaceSection, WorkspaceFeedback } from './WorkspaceForms';
export type HealthState = 'up' | 'degraded' | 'down' | 'maintenance' | 'unknown' | 'paused';
export declare function HealthBadge({ state }: {
    state: HealthState;
}): import("react").JSX.Element;
export declare function WorkspaceHeading({ eyebrow, title, description, actions }: {
    eyebrow?: string;
    title: string;
    description?: string;
    actions?: ReactNode;
}): import("react").JSX.Element;
export declare function MetricGroup({ items }: {
    items: {
        label: string;
        value: ReactNode;
        detail?: string;
        tone?: 'neutral' | 'warning' | 'error' | 'success';
    }[];
}): import("react").JSX.Element;
export declare function EmptyState({ title, description, actions, icon }: {
    title: string;
    description: string;
    actions?: ReactNode;
    icon?: ReactNode;
}): import("react").JSX.Element;
export declare function OperationsSection({ title, description, actions, children }: {
    title?: string;
    description?: string;
    actions?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function OperationsForm({ children, onSubmit, actions, id }: {
    children: ReactNode;
    onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
    actions?: ReactNode;
    id?: string;
}): import("react").JSX.Element;
export declare function InlineNotice({ children, tone }: {
    children: ReactNode;
    tone?: 'neutral' | 'success' | 'error' | 'warning';
}): import("react").JSX.Element;
export declare function TextViewer({ text, label }: {
    text: string;
    label: string;
}): import("react").JSX.Element;
export declare function DetailGrid({ items }: {
    items: {
        label: string;
        value: ReactNode;
    }[];
}): import("react").JSX.Element;
export interface ServiceHealthItem {
    id: string;
    name: string;
    description?: string;
    state: HealthState;
    availability?: number | null;
    regions: {
        id: string;
        name: string;
        state: HealthState;
        observedAt?: string | null;
        latencyMs?: number | null;
    }[];
    history: {
        date: string;
        state: HealthState;
        up: number;
        down: number;
    }[];
}
export declare function ServiceHistory({ history, timeZone, interactive }: {
    history: ServiceHealthItem['history'];
    timeZone?: string;
    interactive?: boolean;
}): import("react").JSX.Element;
export declare function ServiceHealthCard({ service, onOpen, historyTimeZone }: {
    service: ServiceHealthItem;
    onOpen?: (id: string) => void;
    historyTimeZone?: string;
}): import("react").JSX.Element;
export declare function ServiceGroup({ name, count, state, children, defaultOpen }: {
    name: string;
    count: number;
    state: HealthState;
    children: ReactNode;
    defaultOpen?: boolean;
}): import("react").JSX.Element;
export declare function PublicStatusLayout({ brand, actions, state, updatedAt, stale, children, footer, compact, summaryText }: {
    brand: ReactNode;
    actions?: ReactNode;
    state: HealthState;
    updatedAt?: string;
    stale?: boolean;
    children: ReactNode;
    footer?: ReactNode;
    compact?: boolean;
    summaryText?: string;
}): import("react").JSX.Element;
export declare function ActivityList({ items, empty }: {
    items: {
        id: string;
        title: string;
        description?: string;
        at: string;
        actor?: string;
        tone?: 'success' | 'warning' | 'error' | 'neutral';
    }[];
    empty?: string;
}): import("react").JSX.Element;
export { AccountCostSummary, type CostAccountSummary } from './AccountCostSummary';
