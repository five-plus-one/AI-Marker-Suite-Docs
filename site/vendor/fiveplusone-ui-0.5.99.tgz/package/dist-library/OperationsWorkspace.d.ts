import { type ReactNode } from 'react';
import './operations-workspace.css';
export interface OperationsNavigationGroup {
    id: string;
    label: string;
    items: {
        id: string;
        label: string;
        icon?: ReactNode;
        badge?: ReactNode;
    }[];
}
export interface OperationsWorkspaceProps {
    brand: ReactNode;
    groups: OperationsNavigationGroup[];
    value: string;
    onChange: (id: string) => void;
    headerActions?: ReactNode;
    identity?: ReactNode;
    context?: ReactNode;
    pageKey?: string;
    onReturn?: () => void;
    returnLabel?: string;
    children: ReactNode;
}
export declare function OperationsWorkspace({ brand, groups, value, onChange, headerActions, identity, context, pageKey, onReturn, returnLabel, children }: OperationsWorkspaceProps): import("react").JSX.Element;
export declare function OperationsColumns({ primary, secondary }: {
    primary: ReactNode;
    secondary: ReactNode;
}): import("react").JSX.Element;
export declare function CapacityMeter({ label, value, detail, tone, valueLabel }: {
    label: string;
    value: number | null | undefined;
    detail?: ReactNode;
    tone?: 'neutral' | 'success' | 'warning' | 'error';
    valueLabel?: string;
}): import("react").JSX.Element;
export interface QuickSearchItem {
    id: string;
    label: string;
    description?: string;
    icon?: ReactNode;
}
export declare function QuickSearch({ open, onClose, query, onQueryChange, items, onSelect, title, placeholder, empty }: {
    open: boolean;
    onClose: () => void;
    query: string;
    onQueryChange: (query: string) => void;
    items: QuickSearchItem[];
    onSelect: (id: string) => void;
    title?: string;
    placeholder?: string;
    empty?: string;
}): import("react").JSX.Element;
