import { type ReactNode } from 'react';
export interface NotebookAppearanceValue {
    color: string;
    icon: string;
}
export interface NotebookIconOption {
    id: string;
    label: string;
    icon: ReactNode;
}
export declare const notebookColors: {
    id: string;
    label: string;
}[];
export declare function NotebookAppearancePicker({ value, onChange, icons, title, disabled }: {
    value: NotebookAppearanceValue;
    onChange: (value: NotebookAppearanceValue) => void;
    icons: NotebookIconOption[];
    title?: string;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function NotebookQuickFilters({ query, onQueryChange, color, onColorChange, icon, onIconChange, colors, icons, presets, preset, onPresetChange }: {
    query: string;
    onQueryChange: (value: string) => void;
    color: string;
    onColorChange: (value: string) => void;
    icon: string;
    onIconChange: (value: string) => void;
    colors?: {
        id: string;
        label: string;
    }[];
    icons: NotebookIconOption[];
    presets?: {
        id: string;
        label: string;
    }[];
    preset?: string;
    onPresetChange?: (value: string) => void;
}): import("react").JSX.Element;
