import { type ReactNode } from 'react';
import { type HealthState, type ServiceHealthItem } from './OperationsSurfaces';
import './service-status-board.css';
export type RecentServiceCheck = {
    observedAt: string;
    state: HealthState;
    latencyMs?: number | null;
};
export type StatusHistoryGranularity = 'hour' | 'day' | 'week' | 'month';
export type StatusHistorySelection = {
    granularity: StatusHistoryGranularity;
    from: string;
    to: string;
};
export type StatusHistoryBucket = {
    start: string;
    end: string;
    up: number;
    down: number;
    state: HealthState;
};
export type PublicServiceItem = ServiceHealthItem & {
    group?: string;
    lastKnownState?: HealthState;
    availability?: number | null;
    recentChecks?: RecentServiceCheck[];
    periodHistory?: StatusHistoryBucket[];
};
export declare function StatusToolbar({ children, history }: {
    children: ReactNode;
    history?: {
        value: StatusHistorySelection;
        onChange: (value: StatusHistorySelection) => void;
        onQuery: () => void;
        loading?: boolean;
        error?: string;
    };
}): import("react").JSX.Element;
export declare function ServiceStatusBoard({ services, empty, historyTimeZone, showNavigation, historyMode, periodLabel, presentation }: {
    services: PublicServiceItem[];
    empty?: string;
    historyTimeZone?: string;
    showNavigation?: boolean;
    historyMode?: 'daily' | 'recent' | 'period';
    periodLabel?: string;
    presentation?: 'detailed' | 'summary';
}): import("react").JSX.Element;
