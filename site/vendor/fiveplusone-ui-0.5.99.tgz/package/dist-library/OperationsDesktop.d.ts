import type { ReactNode } from 'react';
import './operations-desktop.css';
export interface DesktopWindowFrameProps {
    title: string;
    maximized: boolean;
    fullscreen?: boolean;
    fillViewport?: boolean;
    onMinimize: () => void;
    onMaximize: () => void;
    onClose: () => void;
    actions?: ReactNode;
    children: ReactNode;
}
/** Shared desktop chrome; native privileges and window state belong to the host. */
export declare function DesktopWindowFrame({ title, maximized, fullscreen, fillViewport, onMinimize, onMaximize, onClose, actions, children }: DesktopWindowFrameProps): import("react").JSX.Element;
