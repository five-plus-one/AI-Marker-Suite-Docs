import { type ReactNode } from 'react';
import './notebook-groups.css';
import { type ToolbarAction } from './ActionToolbar';
export type NotebookGroupOption = {
    id: string;
    name: string;
    count: number;
    shared?: boolean;
    section?: string;
};
/** A horizontal, scrollable set of book groups. Selection belongs to the caller. */
export declare function NotebookGroupTabs({ groups, value, onChange, onCreate, disabled, variant, actions }: {
    groups: NotebookGroupOption[];
    value: string;
    onChange: (id: string) => void;
    onCreate?: () => void;
    disabled?: boolean;
    variant?: 'tabs' | 'picker';
    actions?: ToolbarAction[];
}): import("react").JSX.Element;
export type NotebookGroupItem = {
    id: string;
    name: string;
    icon?: ReactNode;
    detail?: string;
    disabled?: boolean;
};
export declare function NotebookGroupEditor({ name, onNameChange, items, selected, onSelectionChange, disabled }: {
    name: string;
    onNameChange: (name: string) => void;
    items: NotebookGroupItem[];
    selected: string[];
    onSelectionChange: (ids: string[]) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function NotebookGroupInvitation({ name, owner, items, permission, children }: {
    name: string;
    owner: string;
    items: NotebookGroupItem[];
    permission?: string;
    children?: ReactNode;
}): import("react").JSX.Element;
