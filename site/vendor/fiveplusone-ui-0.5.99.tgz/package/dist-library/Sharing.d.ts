import type { ReactNode } from 'react';
import './sharing.css';
export interface SharingDialogProps {
    title: string;
    description?: string;
    tab: string;
    tabs: {
        id: string;
        label: string;
    }[];
    onTabChange: (id: string) => void;
    onClose: () => void;
    busy?: boolean;
    children: ReactNode;
    footer?: ReactNode;
    message?: string;
}
export declare function SharingDialog({ title, description, tab, tabs, onTabChange, onClose, busy, children, footer, message }: SharingDialogProps): import("react").JSX.Element;
export declare function ShareLinkCard({ label, url, detail, active, busy, copied, onCopy, onRevoke }: {
    label: string;
    url: string;
    detail: string;
    active?: boolean;
    busy?: boolean;
    copied?: boolean;
    onCopy: () => void;
    onRevoke: () => void;
}): import("react").JSX.Element;
export declare function SharedAttribution({ name, avatar, permission }: {
    name: string;
    avatar?: string;
    permission: string;
}): import("react").JSX.Element;
export declare function SharedNotebookMarker(): import("react").JSX.Element;
