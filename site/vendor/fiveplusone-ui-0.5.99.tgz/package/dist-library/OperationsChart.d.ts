import { type ReactNode } from 'react';
import './operations-chart.css';
export interface TimeSeries {
    id: string;
    name: string;
    values: (number | null)[];
}
export declare function TimeSeriesChart({ label, times, series, unit, maximum, empty, actions, timeZone, granularity, fractionDigits, height }: {
    label: string;
    times: string[];
    series: TimeSeries[];
    unit?: string;
    maximum?: number;
    empty?: string;
    actions?: ReactNode;
    timeZone?: string;
    granularity?: 'minute' | 'day';
    fractionDigits?: number;
    height?: number;
}): import("react").JSX.Element;
export declare function ShareBreakdownChart({ label, items, empty }: {
    label: string;
    items: {
        id: string;
        label: string;
        value: number;
        displayValue: string;
    }[];
    empty?: string;
}): import("react").JSX.Element;
