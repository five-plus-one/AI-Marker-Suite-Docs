# 管理工作区与账号菜单

ManagementWorkspace 提供管理导航、固定返回入口、用户身份和窄屏导航；权限、路由、数据与持久化由业务端传入。ManagementForm 提供分组标签、表单内容和持续可达的操作区域，宿主保留各组输入并处理提交状态。

AccountMenu 在工作区侧栏底部提供头像入口、账号身份、分组操作和快捷键提示。通过共享 Popup 挂载浮层，支持键盘导航、Esc、外部点击、焦点恢复和窗口边缘避让。宿主按权限构造菜单，负责账号跳转和保存后退出。

课栈管理页使用 ManagementWorkspace，数据中台与模型计费继续使用 AnalyticsWorkspace 与 CommerceWorkspace。菜单与表单通过产品语义色适配深浅主题；窄屏管理导航收起，返回工作区入口持续显示。


AnalyticsWorkspace 的 personal 模式用于个人时长概览，保留语义指标和分钟趋势，日期标签根据点数抽样，适配容器宽度。UpgradeRequiredDialog 提供不可跳过的升级弹窗，操作、版本信息与下载状态由宿主传入；升级、保存与版本策略由业务处理。


## 账号助手偏好与字体

AssistantPreferences 由宿主提供可用模型、工具、账号偏好和同步状态，受控回调逐项修改。对话阅读、摘录和划词、图片生成、回答偏好及助手能力分组显示；技能和导出由 children 扩展。组件不处理密钥、业务计费或保存请求。

AppearanceWorkspace 提供独立于配色的全局字体、界面字号 uiFontSize（默认14）与正文字号 readingFontSize（默认16）。宿主将账号偏好映射到 --fp-font、--fp-ui-font-scale 和 --fp-reading-font-size，并负责同步及字体后备。
