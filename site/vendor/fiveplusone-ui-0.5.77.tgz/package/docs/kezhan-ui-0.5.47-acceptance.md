# 0.5.47 用户管理与审计组件

新增 UserUsageOverview、UserNotebookList、AuditLogWorkspace，扩展 UserDetailsWorkspace 的使用统计与笔记本页。业务方提供请求、权限和持久化，组件负责主题、布局、日期选择、分页与触屏操作。

325 项组件测试和 248 份源码/安装包复制示例通过，构建与类型检查通过。课栈实际页面 12 组宽度/主题检查通过，触屏标签 44 像素；用户资料、额度保存与审计筛选分页可操作。

站点于 2026-10-26 发布至 20261026-ui-0547-2，209 个公开文件摘要匹配。课栈网页与 Windows 0.5.47 已接入。验收包含 [在线摘要](acceptance/0.5.47-online.json)、[布局](acceptance/0.5.47-layout.json)、[触屏](acceptance/0.5.47-touch.json)。

![用户使用统计](acceptance/0.5.47-user-overview.png)
