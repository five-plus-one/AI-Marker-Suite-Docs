# 桌面账号登录窗口

`AuthenticationWindow` 提供自绘标题栏、边框、即时操作提示和主题样式。`createOAuthLoginWindow` 在 Electron 中挂载本地外壳及独立授权视图，可用于 Logto 等基于授权码回调的账号服务。

```js
const electron = require('electron');
const {createOAuthLoginWindow} = require('@fiveplusone/ui/oauth-login-window.cjs');
const view = createOAuthLoginWindow({
  ...electron,
  parent: mainWindow,
  title: '登录学习空间',
  product: 'kezhan',
  issuer: 'https://identity.example/oidc',
  authorizeUrl, // 宿主生成的 PKCE 授权地址，包含 state 和本机回调。
  theme: 'dark',
  themePreference: 'dark', // light / dark / system
  onCancel: () => transaction.cancel(),
});
transaction.completion.finally(() => view.dispose());
// 宿主主题变化时同步；该操作保留授权页和输入内容。
view.setTheme('light', 'light');
// 重复登录时聚焦已有窗口。
view.focus();
```

宿主负责 PKCE、state、nonce、回调服务器、授权码兑换、业务会话和超时。回调必须使用 `http://127.0.0.1:<端口>/<路径>`。组件仅允许身份服务 HTTPS Origin 与当前 state 对应的回调在授权视图导航；其他身份来源可继续使用浏览器。OAuth 原生应用规范要求使用外部用户代理，接入方须结合身份服务策略选择入口，第三方提供商可能限制内嵌授权。

授权页使用临时分区，不加载本地 preload，不共享工作区会话与原生接口。外壳使用独立分区与受主框架身份校验的操作通道。窗口关闭或完成后销毁两个视图并清理临时存储。`nativeTheme` 跟随宿主选择；`system` 保留操作系统主题响应。

登录窗口以原生模态方式打开，主窗口暂停鼠标与键盘交互，并覆盖模糊遮罩。取消、关闭或完成后恢复主窗口；主页面导航期间继续保持遮罩。选择浏览器登录时，弹窗保留等待提示和取消入口，收到回调后由宿主完成并关闭。

打包时将以下三个文件放在同一目录，并从该目录加载工厂；也可直接通过包导出使用：

- `@fiveplusone/ui/oauth-login-window.cjs`
- `@fiveplusone/ui/oauth-window-preload.cjs`
- `@fiveplusone/ui/oauth-window-shell.html`

共享展示目录包含可交互、可复制的 `AuthenticationWindow` 示例。业务界面不展示授权码、令牌和内部参数。

## 应用任务授权

`AuthenticationWindow` 的 `mode="task"` 提供授权窗口的标题与操作名称。`createApplicationAccessWindow` 展示应用自己的任务确认页，内容视图使用宿主传入的账号会话；外壳保留独立会话、受来源校验的操作通道及即时操作提示。

```js
const {createApplicationAccessWindow} = require('@fiveplusone/ui/application-access-window.cjs');
const consent = createApplicationAccessWindow({
  ...electron, parent: mainWindow, contentSession: accountSession,
  url: 'https://desktop.example/connections?access=request',
  origin: 'https://desktop.example', theme: 'dark',
  workArea: electron.screen.getDisplayMatching(mainWindow.getBounds()).workArea,
  onBrowser: () => openFirstPartyConsentInBrowser(),
});
consent.setTheme('light');
```

宿主先核对当前账号与待确认请求，再创建窗口。窗口只允许同源授权页面；返回应用首页时关闭窗口并恢复主界面。内容视图不注入 preload 或 Node 接口，关闭时保留宿主账号会话。授权目标、权限、有效期与是否批准由业务服务验证。`ApplicationAccess` 的完成状态可通过 `onDone` 返回宿主，`doneLabel` 设置返回按钮名称。

打包时将 `application-access-window.cjs`、`oauth-window-preload.cjs` 与 `oauth-window-shell.html` 放在同一目录。窗口根据可用屏幕范围限制尺寸，支持深浅色、Esc、浏览器继续和重新加载。


## 原生授权通知

`@fiveplusone/ui/authorization-notification.cjs` 导出 `createAuthorizationNotifications`。
宿主注入 Electron `Notification`、`title`、`body`、`toProtocol(item)`、`onActivate(item)`、`onChange()` 和 `onError(error)`。
使用 `notify({id,expiresAt,...})` 或 `reconcile(items)` 同步待确认申请；`expiresAt` 为 Unix 秒。
`pending()` 支持托盘入口；`clear()` 用于退出或切换账号；`dispose()` 用于进程退出。

Windows 使用系统通知及应用协议激活，应用关闭后的通知点击也可拉起已安装的宿主。
宿主注册应用协议与 AppUserModelID，在打开授权前重新核对账号、申请状态和有效期。
通知只显示有待确认事项，具体资料与权限在应用内展示。原生通知不可用时保留可操作的托盘入口。
同一申请在有效期内只通知一次；拒绝、过期或完成后由宿主同步移除。关闭通知不等于同意或拒绝授权。
