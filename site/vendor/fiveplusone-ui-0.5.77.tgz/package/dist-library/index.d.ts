import { Tabs } from './PageControls';
export { Button, Spinner, Badge, Card, Tabs, Accordion, cx } from './PageControls';
export { learningAlpha } from './learning/theme';
export * from './LearningSourceView';
export * from './NotebookManagerWorkspace';
export * from './CourseContentWorkspace';
export * from './BrowserWorkspace';
export * from './UserDetailsWorkspace';
export * from './PlatformWorkspace';
export * from './BrowserPreferences';
export * from './FollowUpQuestions';
export * from './NoteEditorWorkspace';
export * from './LectureWorkspace';
export * from './SharedReadingPage';
export * from './CanvasWorkspace';
export * from './LearningExperiments';
export { SurfaceBoundary, type SurfaceBoundaryProps } from "./SurfaceBoundary";
export * from './WorkspaceForms';
export * from './CommerceWorkspace';
export * from './SkillsWorkspace';
export * from './DirectoryWorkspace';
export * from './NotebookPublishing';
export * from './AISettingsWorkspace';
export * from './AppearanceWorkspace';
export * from './Tooltip';
export * from './ActionToolbar';
export * from './AnchoredPanel';
export * from './ThemeToggle';
export * from './ContentSkeleton';
export * from './ShareMemberRow';
export * from './SettingsLayout';
export * from './DiscardChangesPrompt';
export * from './editor/CardEditorFrame';
import React, { type ReactNode, type HTMLAttributes, type ButtonHTMLAttributes, type InputHTMLAttributes } from "react";
import "./styles.css";
import "./product-patterns.css";
export * from "./AudioPlayer";
export * from "./SearchResults";
export * from "./workspace/WorkspaceTabs";
export * from "./editor/EditorPanels";
export * from "./ReadingBlocks";
export * from "./ManagementViews";
export * from "./WorkspaceNavigation";
export * from "./ConversationViews";
export * from "./LearningWorkspace";
export * from "./MarkdownContent";
export * from "./WorkspaceUtilities";
export * from "./AccountViews";
export { MermaidPreview } from "./editor/VisualCodeBlock";
export { UploadPlaceholder, appendUploadPlaceholder, } from "./editor/uploadPlaceholder";
export { ImageConversion } from "./editor/imageConversion";
export { moveEditorBlock, deleteEditorBlock } from "./editor/blockOperations";
export declare function IconButton({ label, children, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & {
    label: string;
}): React.JSX.Element;
export declare function Input({ className, ...p }: InputHTMLAttributes<HTMLInputElement>): React.JSX.Element;
export declare function Textarea(p: React.TextareaHTMLAttributes<HTMLTextAreaElement>): React.JSX.Element;
export declare function Field({ label, hint, error, children, }: {
    label: string;
    hint?: string;
    error?: string;
    children: React.ReactElement<{
        id?: string;
        "aria-describedby"?: string;
        "aria-invalid"?: boolean;
    }>;
}): React.JSX.Element;
export declare function Checkbox({ label, ...p }: InputHTMLAttributes<HTMLInputElement> & {
    label: string;
}): React.JSX.Element;
export declare function Radio({ label, ...p }: InputHTMLAttributes<HTMLInputElement> & {
    label: string;
}): React.JSX.Element;
export declare function Switch({ label, checked, onChange, disabled, }: {
    label: string;
    checked: boolean;
    onChange: (v: boolean) => void;
    disabled?: boolean;
}): React.JSX.Element;
export { Select, Combobox } from "./ChoiceInputs";
export declare function Slider({ label, min, max, step, value, defaultValue, className, ...p }: InputHTMLAttributes<HTMLInputElement> & {
    label: string;
}): React.JSX.Element;
export declare function Chip({ children, selected, onClick, onRemove, }: {
    children: ReactNode;
    selected?: boolean;
    onClick?: () => void;
    onRemove?: () => void;
}): React.JSX.Element;
export declare function Avatar({ name, src, size, }: {
    name: string;
    src?: string;
    size?: number;
}): React.JSX.Element;
export declare function AvatarGroup({ names }: {
    names: string[];
}): React.JSX.Element;
export declare function Divider(): React.JSX.Element;
export declare function Alert({ title, children, tone, }: {
    title: string;
    children?: ReactNode;
    tone?: "accent" | "success" | "warning" | "error";
}): React.JSX.Element;
export declare function Skeleton({ width, height, }: {
    width?: string;
    height?: number;
}): React.JSX.Element;
export declare function Progress({ value, label }: {
    value: number;
    label?: string;
}): React.JSX.Element;
export declare function SegmentedControl(p: Parameters<typeof Tabs>[0]): React.JSX.Element;
export declare function Breadcrumbs({ items, }: {
    items: {
        label: string;
        href?: string;
    }[];
}): React.JSX.Element;
export declare function Pagination({ page, total, onChange, }: {
    page: number;
    total: number;
    onChange: (p: number) => void;
}): React.JSX.Element;
export declare function Steps({ items, current, }: {
    items: string[];
    current: number;
}): React.JSX.Element;
export { Popup, Dropdown, Popover, type PopupProps } from "./Popup";
export declare const brandLogoUrl = "https://go.r-l.ink/ico";
export declare function BrandLogo({ size, decorative, }: {
    size?: number;
    decorative?: boolean;
}): React.JSX.Element;
export declare function Dialog({ open, onClose, title, children, footer, drawer, className, dismissible, }: {
    open: boolean;
    onClose: () => void;
    title: string;
    children: ReactNode;
    footer?: ReactNode;
    drawer?: boolean;
    className?: string;
    dismissible?: boolean;
}): React.ReactPortal | null;
export declare function Drawer(p: Omit<Parameters<typeof Dialog>[0], "drawer">): React.JSX.Element;
export declare function EmptyState({ title, description, action, }: {
    title: string;
    description: string;
    action?: ReactNode;
}): React.JSX.Element;
export declare function Toast({ message, onClose, }: {
    message: string;
    onClose: () => void;
}): React.JSX.Element;
export declare function Table({ columns, rows, caption, }: {
    columns: string[];
    rows: ReactNode[][];
    caption?: string;
}): React.JSX.Element;
export declare function DescriptionList({ items, }: {
    items: {
        label: string;
        value: ReactNode;
    }[];
}): React.JSX.Element;
export declare function Timeline({ items, }: {
    items: {
        title: string;
        description: string;
    }[];
}): React.JSX.Element;
export declare function Stat({ label, value, detail, }: {
    label: string;
    value: string;
    detail?: string;
}): React.JSX.Element;
export declare function FileUpload({ onFiles, accept, multiple, }: {
    onFiles: (files: File[]) => void;
    accept?: string;
    multiple?: boolean;
}): React.JSX.Element;
export declare function SearchInput({ value, onChange, placeholder, }: {
    value: string;
    onChange: (v: string) => void;
    placeholder?: string;
}): React.JSX.Element;
export declare function NumberInput({ value, onChange, min, max, label, }: {
    value: number;
    onChange: (n: number) => void;
    min?: number;
    max?: number;
    label: string;
}): React.JSX.Element;
export { DatePicker, TimePicker, ColorPicker } from "./StyledInputs";
export declare function Rating({ value, onChange, }: {
    value: number;
    onChange: (v: number) => void;
}): React.JSX.Element;
export declare function Meter({ value, label }: {
    value: number;
    label: string;
}): React.JSX.Element;
export declare function CodeBlock({ code, language, }: {
    code: string;
    language?: string;
}): React.JSX.Element;
export declare function Kbd({ children }: {
    children: ReactNode;
}): React.JSX.Element;
export declare function Link({ children, ...p }: React.AnchorHTMLAttributes<HTMLAnchorElement>): React.JSX.Element;
export declare function Tree({ items, }: {
    items: {
        label: string;
        children?: string[];
    }[];
}): React.JSX.Element;
export declare function Navigation({ items, value, onChange, }: {
    items: {
        value: string;
        label: string;
        icon?: ReactNode;
    }[];
    value: string;
    onChange: (v: string) => void;
}): React.JSX.Element;
export declare function Toolbar({ children }: {
    children: ReactNode;
}): React.JSX.Element;
export declare function Callout({ title, children, }: {
    title: string;
    children: ReactNode;
}): React.JSX.Element;
export declare function Citation({ title, detail, onClick, }: {
    title: string;
    detail: string;
    onClick?: () => void;
}): React.JSX.Element;
export declare function AIMessage({ role, children, }: {
    role: "user" | "assistant";
    children: ReactNode;
}): React.JSX.Element;
export declare function AIComposer({ onSend, disabled, }: {
    onSend: (v: string) => void;
    disabled?: boolean;
}): React.JSX.Element;
export declare function TaskStatus({ title, steps, running, onToggle, }: {
    title: string;
    steps: string[];
    running: boolean;
    onToggle: () => void;
}): React.JSX.Element;
export declare function ResultCard({ title, description, onApply, }: {
    title: string;
    description: string;
    onApply: () => void;
}): React.JSX.Element;
export declare function FileCard({ name, detail, onOpen, }: {
    name: string;
    detail: string;
    onOpen: () => void;
}): React.JSX.Element;
export declare function PageHeader({ eyebrow, title, description, action, }: {
    eyebrow?: string;
    title: string;
    description?: string;
    action?: ReactNode;
}): React.JSX.Element;
export declare function Container({ children, className, ...p }: HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function Stack({ children, gap, direction, }: {
    children: ReactNode;
    gap?: number;
    direction?: "row" | "column";
}): React.JSX.Element;
export declare function Grid({ children, minWidth, }: {
    children: ReactNode;
    minWidth?: number;
}): React.JSX.Element;
export declare function ScrollArea({ children, height, }: {
    children: ReactNode;
    height?: number;
}): React.JSX.Element;
export declare function AspectRatio({ children, ratio, }: {
    children: ReactNode;
    ratio?: number;
}): React.JSX.Element;
export declare function MultiSelect({ label, options, value, onChange, }: {
    label: string;
    options: string[];
    value: string[];
    onChange: (v: string[]) => void;
}): React.JSX.Element;
export declare function PasswordInput({ label, ...p }: InputHTMLAttributes<HTMLInputElement> & {
    label?: string;
}): React.JSX.Element;
export declare function Banner({ children, onClose, }: {
    children: ReactNode;
    onClose?: () => void;
}): React.JSX.Element;
export declare function Calendar({ value, onChange, }: {
    value: string;
    onChange: (v: string) => void;
}): React.JSX.Element;
export declare function ResizablePanel({ first, second, }: {
    first: ReactNode;
    second: ReactNode;
}): React.JSX.Element;
export declare function ConfirmDialog({ open, onClose, onConfirm, title, description, }: {
    open: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    description: string;
}): React.JSX.Element;
export declare function CommandMenu({ open, onClose, items, }: {
    open: boolean;
    onClose: () => void;
    items: {
        label: string;
        onSelect: () => void;
    }[];
}): React.JSX.Element;
export declare function NotificationList({ items, onRead, }: {
    items: {
        id: string;
        title: string;
        detail: string;
        read?: boolean;
    }[];
    onRead: (id: string) => void;
}): React.JSX.Element;
export declare function BarChart({ items, label, }: {
    items: {
        label: string;
        value: number;
    }[];
    label: string;
}): React.JSX.Element;
export declare function ImagePreview({ src, alt }: {
    src: string;
    alt: string;
}): React.JSX.Element;
export declare function ErrorState({ title, description, onRetry, }: {
    title?: string;
    description: string;
    onRetry: () => void;
}): React.JSX.Element;
export declare function Footer({ children }: {
    children: ReactNode;
}): React.JSX.Element;
export declare function VisuallyHidden({ children }: {
    children: ReactNode;
}): React.JSX.Element;
export { default as PdfPreview } from "./workspace/PdfPreview";
export { default as HorizontalScrollbar } from "./workspace/HorizontalScrollbar";
export * from "./workspace/ResourcePreview";
export * from "./workspace/FileTree";
export * from "./workspace/WorkspaceLayout";
export * from "./workspace/CollaborativeEditor";
export { MessageList, MessageBubble, type Message, type MessageListProps, } from "./MessageList";
export * from "./ChatComposer";
export * from "./MemberAccess";
export * from "./SelectField";
export * from "./MemberSearch";
export * from "./ShareLink";
export * from "./AttachmentPicker";
export * from "./UploadQueue";
export * from "./editor/MarkdownEditor";
export * from "./editor/MarkdownEditorSurface";
export * from "./ConversationViewport";
export { default as NoteToolbar } from "./editor/NoteToolbar";
export { createLazyMathExtensions, type MathNodeHost } from "./editor/LazyMathExtensions";
export { VisualCodeBlock } from "./editor/VisualCodeBlock";
export { insertMermaidCard } from "./editor/mermaid";
export { markdownToDocument, documentToMarkdown, baseEditorExtensions, NOTE_SCHEMA_VERSION, } from "./editor/schema";
export { configureMathPreferences, type MathPreferenceStorage, } from "./editor/mathPreferences";
export { Attachment } from "./editor/attachment";
export { DirectiveBlock } from "./editor/directiveBlock";
export { CollapseTransition, type CollapseTransitionProps, } from "./CollapseTransition";
export { AgentTrace, type AgentTraceProps, type TraceStep, type TraceStatus, } from "./AgentTrace";
export { FlipCard, type FlipCardProps, type FlipCardKind } from "./FlipCard";
export { SelectionToolbar, type SelectionToolbarProps, type SelectionAction, } from "./SelectionToolbar";
export { SyncStatus, type SyncStatusProps, type PendingSync, } from "./SyncStatus";
export { ModelSelector, type ModelSelectorProps, type ModelInfo, type ModelGroup, } from "./ModelSelector";
export { TokenDashboard, TokenDashboardAuto, type TokenDashboardProps, } from "./TokenDashboard";
export { CollapsibleSection, type CollapsibleSectionProps, } from "./CollapsibleSection";
export { AttachmentGrid, type AttachmentGridProps, type AttachmentItem, } from "./AttachmentGrid";
export { QuizQuestion, type QuizQuestionProps, type QuizOption, type QuizDifficulty, } from "./QuizQuestion";
export { EmbedFallback, type EmbedFallbackProps } from "./EmbedFallback";
export { MediaLightbox, type MediaLightboxProps } from "./MediaLightbox";
export { SettingsSection, type SettingsSectionProps } from "./SettingsSection";
export { ChatEmptyState, type ChatEmptyStateProps } from "./ChatEmptyState";
export { SourceFold, type SourceFoldProps, type SourceItem, } from "./SourceFold";
export { SessionHistory, type SessionHistoryProps, type SessionGroup, type SessionItem, } from "./SessionHistory";
export { ContentImage, type ContentImageProps } from "./ContentImage";
export { WindowChrome, type WindowChromeProps } from "./WindowChrome";
export { AuthenticationWindow, type AuthenticationWindowProps } from './AuthenticationWindow';
export { FilterSelect, type FilterSelectProps, type FilterOption, type FilterGroup, } from "./FilterSelect";
export { AcademicYearSwitcher, type AcademicYearSwitcherProps, type AcademicYear, } from "./AcademicYearSwitcher";
export { KeyPoint, ConceptCard, CompareTable, CauseEffect, Derivation, type KeyPointProps, type ConceptCardProps, type CompareTableProps, type CauseEffectProps, type CauseEffectItem, type DerivationProps, } from "./NoteBlocks";
export { CitationList, type CitationListProps, type CitationHit, } from "./CitationList";
export { ApprovalCard, type ApprovalCardProps } from "./ApprovalCard";
export { TocTree, type TocTreeProps, type TocItemNode } from "./TocTree";
export { SiblingFiles, type SiblingFilesProps, type SiblingItem, type SiblingStatus, } from "./SiblingFiles";
export { FormulaSteps, type FormulaStepsProps } from "./FormulaSteps";
export { DistributionChart, type DistributionChartProps, type DistributionKind, } from "./DistributionChart";
export { VideoPlayer, type VideoPlayerProps } from "./VideoPlayer";
export { ShortcutHelp, type ShortcutHelpProps, type ShortcutCategory, type ShortcutItem, } from "./ShortcutHelp";
export { BottomNav, type BottomNavProps, type BottomNavItem, } from "./BottomNav";
export { ImageGallery, type ImageGalleryProps, type GalleryImage, } from "./ImageGallery";
export { WindowTaskbar, type WindowTaskbarProps, type TaskbarWindow, } from "./WindowTaskbar";
export * from "./themes";
import "./workspace/preview.css";
import "./workspace/workspace.css";
import "./workspace/controls.css";
import "./graph-view.css";
import "./editor/editor.css";
import "./product-themes.css";
import "./content-rhythm.css";
export * from "./AnimatedSize";
export * from "./ContextMenu";
export * from "./MediaControls";
export * from "./NavigationCard";
export * from "./ResourceExplorer";
export * from "./TaskViews";
export * from "./ProductCompositions";
export { DirectiveFields, parseDirectiveAttributes, setDirectiveAttribute, } from "./editor/DirectiveFields";
export { useMathEditor, bindNestedMathEditor, openActiveMathEditor } from "./editor/MathEditor";
import './canvas/canvas-base.css';
import './canvas/canvas-theme.css';
import './reading-workspace.css';
import './learning-utilities.css';
import './learning-theme.css';
import './workspace-forms.css';
export { mountWindowTitleBar } from './window-titlebar';
export type { WindowTitleBarHost } from './window-titlebar';
export * from './WindowControls';
export * from './AppSurfaces';
export * from './TransferQueue';
export { ChoiceCards, type ChoiceCardOption } from './ChoiceCards';
export * from "./editor/editorSearch";
export * from "./editor/EditorContextMenu";
export * from './SuggestionList';
export * from './MobileSurfaces';
export * from './AnalyticsWorkspace';
export * from './ResourceBrowser';
export * from './ManagementWorkspace';
export * from './AccountMenu';
export * from './UpgradeRequiredDialog';
export * from './AssistantPreferences';
export * from './ProviderManager';
export * from './SettingsLinks';
export * from './editor/nestedEditorEvents';
import './assistant-preferences.css';
export * from './AdminInsights';
export { SlideTransition, type SlideTransitionProps } from './SlideTransition';
export * from "./workspaceShortcuts";
export * from "./editor/commandUsage";
export * from "./editor/cardEditing";
export * from "./editor/linkEditing";
export * from "./editor/editorIdentity";
export * from './ExperimentWorkbench';
export * from './DocumentationLayout';
