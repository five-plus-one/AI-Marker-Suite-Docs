import { jsx as e, jsxs as o, Fragment as Z } from "react/jsx-runtime";
import Lt, { useRef as B, useState as k, useEffect as Y, useLayoutEffect as Ce, useId as Ne, useCallback as xe, Fragment as Pa, lazy as xl, Suspense as Cl, createContext as Dn, useContext as rn, Component as Sl, useMemo as He, Children as Ml, isValidElement as Oa, cloneElement as Fa, forwardRef as El, useImperativeHandle as $l } from "react";
import { Minus as Tt, Plus as gn, Minimize2 as xr, Maximize2 as Cr, Download as Ot, RotateCcw as rt, ChevronDown as Ft, Check as Re, Play as Qt, Pause as Pn, VolumeX as Ra, Volume2 as Ba, PictureInPicture as zl, Maximize as On, ZoomIn as ja, ZoomOut as qa, ExternalLink as Rt, Pencil as Fn, Code2 as Sr, Trash2 as Bt, IndentIncrease as Il, IndentDecrease as Al, CornerDownLeft as Ka, ArrowDown as Ua, BookOpen as ht, ChevronRight as Ie, ImageOff as Ll, Undo2 as Tl, Redo2 as Dl, Paintbrush as Pl, Bold as Ol, Italic as Fl, Baseline as Rl, Highlighter as Bl, List as yn, Link2 as ft, Paperclip as cr, Sigma as zt, Table2 as Jn, Strikethrough as jl, Underline as ql, Eraser as Kl, Quote as Ha, Braces as Ul, Layers3 as Yr, Video as Gr, Workflow as Hl, FlaskConical as _l, Save as _a, MoreHorizontal as Dt, ListOrdered as Wl, Search as Je, Star as Jr, ChevronLeft as Mr, Keyboard as Wa, Settings2 as Vl, Grid2X2 as Xl, FileText as Ye, Clock as Rn, Minimize as Yl, X as ge, Home as Gl, RefreshCw as Bn, Monitor as Va, Smartphone as Jl, Settings as Ql, Menu as Er, Copy as jn, CalendarDays as Xa, Sun as Zl, Moon as eo, Columns2 as to, Network as Qr, SlidersHorizontal as no, ArrowUpRight as Ya, Eye as Ga, Code as ro, FolderOpen as Ja, Folder as vn, LoaderCircle as Pt, Square as qn, ArrowUp as $r, UserPlus as ao, UserRound as io, Users as dr, RotateCw as Qa, AlertCircle as lo, Loader as oo, Circle as Za, AlertTriangle as so, Cloud as co, CloudOff as uo, Brain as po, Wrench as ho, Cpu as fo, Coins as mo, Lightbulb as Zr, ShieldAlert as bo, Sparkles as wn, Globe as go, MessageSquare as yo, CircleDashed as vo, CheckCircle2 as mt, ImageIcon as wo, FolderPlus as ko, LayoutGrid as No, FolderInput as xo, Share2 as Co, ArrowRight as zr, ShieldCheck as ei, CircleAlert as Ir, ArrowDownToLine as kn, PackageOpen as So, ArrowUpFromLine as Mo, ArrowLeft as Ar, Mic as Eo, Activity as $o, File as zo, BookPlus as Io, History as Ao } from "lucide-react";
import { useReducedMotion as Kn, motion as Un } from "framer-motion";
import { createPortal as Te } from "react-dom";
import { Extension as Lr, InputRule as Lo, Node as Hn, mergeAttributes as Tr } from "@tiptap/core";
import { Plugin as an, TextSelection as Ge, NodeSelection as Yt, PluginKey as ti, Selection as Nn } from "@tiptap/pm/state";
import ni from "react-markdown";
import To from "remark-gfm";
import ri from "remark-math";
import Do from "remark-directive";
import ai from "rehype-katex";
import Po from "rehype-raw";
import Oo, { defaultSchema as Ct } from "rehype-sanitize";
import { visit as Zt } from "unist-util-visit";
import Fo from "dompurify";
import { ReactNodeViewRenderer as _t, NodeViewWrapper as It, NodeViewContent as ea, useEditor as Ro, EditorContent as ii } from "@tiptap/react";
import { CodeBlockLowlight as li } from "@tiptap/extension-code-block-lowlight";
import { createLowlight as Bo, common as jo } from "lowlight";
import { closeHistory as oi } from "@tiptap/pm/history";
import { yUndoPluginKey as si } from "@tiptap/y-tiptap";
import "katex/contrib/mhchem";
import { DecorationSet as ur, Decoration as ci } from "@tiptap/pm/view";
import { DOMSerializer as qo } from "@tiptap/pm/model";
import Ko from "@tiptap/extension-collaboration";
import Uo from "@tiptap/extension-collaboration-caret";
import Ho from "@tiptap/extension-placeholder";
import { pinyin as _o } from "pinyin-pro";
import Wo from "@tiptap/starter-kit";
import Vo from "@tiptap/extension-link";
import { Mathematics as Xo, InlineMath as Yo, BlockMath as Go } from "@tiptap/extension-mathematics";
import { TableKit as Jo } from "@tiptap/extension-table";
import { Markdown as Qo, MarkdownManager as di } from "@tiptap/markdown";
import Zo from "@tiptap/extension-image";
import es from "@tiptap/extension-unique-id";
import { TextStyle as ts } from "@tiptap/extension-text-style";
import { Color as ns } from "@tiptap/extension-color";
import rs from "@tiptap/extension-highlight";
import ui from "katex";
import { PanelGroup as as, PanelResizeHandle as is, Panel as ls } from "react-resizable-panels";
import { HocuspocusProvider as os } from "@hocuspocus/provider";
import * as ss from "yjs";
import { useVirtualizer as pi } from "@tanstack/react-virtual";
function Oe({ isOpen: t, children: n, duration: r = 240, easing: a = "cubic-bezier(0.2, 0, 0, 1)" }) {
  return /* @__PURE__ */ e("div", { className: "fp-collapse-transition", "data-open": t || void 0, "aria-hidden": !t, inert: !t, style: { display: "grid", gridTemplateRows: t ? "1fr" : "0fr", transition: `grid-template-rows ${r}ms ${a}, opacity ${r}ms ${a}`, opacity: t ? 1 : 0 }, children: /* @__PURE__ */ e("div", { style: { minHeight: 0, overflow: "hidden" }, children: n }) });
}
const Ue = (...t) => t.filter(Boolean).join(" ");
function le({
  variant: t = "primary",
  size: n = "md",
  loading: r,
  multiline: a = !1,
  children: i,
  className: l,
  title: s,
  type: c = "button",
  ...u
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      ...u,
      "data-multiline": a || void 0,
      "data-fp-tooltip": s || u["data-fp-tooltip"] || u["aria-label"],
      type: c,
      disabled: u.disabled || r,
      className: Ue("fp-button", `fp-${t}`, `fp-${n}`, l),
      "aria-busy": r,
      children: [
        r && /* @__PURE__ */ e(fi, { size: 16 }),
        i
      ]
    }
  );
}
function hi({
  children: t,
  tone: n = "neutral"
}) {
  return /* @__PURE__ */ e("span", { className: `fp-badge fp-tone-${n}`, children: t });
}
function Gt({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: Ue("fp-card", n), children: t });
}
function fi({ size: t = 22 }) {
  return /* @__PURE__ */ e(
    "span",
    {
      role: "status",
      "aria-label": "正在处理",
      className: "fp-spinner",
      style: { width: t, height: t }
    }
  );
}
function mi({
  items: t,
  value: n,
  onChange: r
}) {
  let a = B(null);
  const [i, l] = k({ left: 0, width: 0 }), s = t.map((c) => c.label).join("\0");
  return Y(() => {
    const c = a.current;
    if (!c) return;
    const u = () => {
      const p = c.querySelector('[aria-selected="true"]');
      p && l({ left: p.offsetLeft, width: p.offsetWidth });
    };
    u();
    const d = typeof ResizeObserver > "u" ? null : new ResizeObserver(u);
    return d?.observe(c), c.querySelectorAll("button").forEach((p) => d?.observe(p)), () => d?.disconnect();
  }, [n, s]), /* @__PURE__ */ o(
    "div",
    {
      ref: a,
      className: "fp-tabs",
      role: "tablist",
      onKeyDown: (c) => {
        if (!t.length || c.altKey || c.ctrlKey || c.metaKey) return;
        let u = t.findIndex((p) => p.value === n), d = c.key === "ArrowRight" ? (u + 1) % t.length : c.key === "ArrowLeft" ? (u - 1 + t.length) % t.length : c.key === "Home" ? 0 : c.key === "End" ? t.length - 1 : -1;
        d >= 0 && (c.preventDefault(), r(t[d].value), a.current?.children[d]?.focus());
      },
      children: [
        t.map((c) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            role: "tab",
            "aria-selected": c.value === n,
            tabIndex: c.value === n ? 0 : -1,
            onClick: () => r(c.value),
            children: c.label
          },
          c.value
        )),
        /* @__PURE__ */ e(
          "span",
          {
            className: "fp-tab-indicator",
            "aria-hidden": "true",
            style: {
              width: i.width,
              transform: `translateX(${i.left}px)`
            }
          }
        )
      ]
    }
  );
}
function ih({
  items: t
}) {
  const [n, r] = Lt.useState(/* @__PURE__ */ new Set()), a = Lt.useId();
  return /* @__PURE__ */ e("div", { className: "fp-accordion", children: t.map((i, l) => /* @__PURE__ */ o("div", { className: "fp-accordion-item", children: [
    /* @__PURE__ */ o(
      "button",
      {
        className: "fp-accordion-trigger",
        type: "button",
        "aria-expanded": n.has(l),
        "aria-controls": `${a}-${l}`,
        onClick: () => r((s) => {
          const c = new Set(s);
          return c.has(l) ? c.delete(l) : c.add(l), c;
        }),
        children: [
          i.title,
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "＋" })
        ]
      }
    ),
    /* @__PURE__ */ e(Oe, { isOpen: n.has(l), children: /* @__PURE__ */ e("div", { id: `${a}-${l}`, className: "fp-accordion-content", children: i.content }) })
  ] }, i.title)) });
}
function lh(t, n) {
  const r = Math.max(0, Math.min(255, parseInt(n, 16) || 0));
  return `color-mix(in srgb, ${t} ${Math.round(r / 255 * 1e4) / 100}%, transparent)`;
}
function cs({
  value: t,
  max: n,
  viewport: r,
  controls: a,
  onChange: i
}) {
  const l = B(null), s = B(
    null
  ), [c, u] = k(!1), d = Math.max(0, n), p = d <= 0 ? 1 : Math.max(0.08, Math.min(1, r / Math.max(1, r + d))), f = (d > 0 ? Math.min(1, Math.max(0, t / d)) : 0) * (1 - p), m = (y) => Math.max(0, Math.min(d, y)), b = (y) => i(m(y));
  return /* @__PURE__ */ o(
    "div",
    {
      ref: l,
      className: "horizontal-scrollbar",
      role: "scrollbar",
      "aria-label": "横向滚动预览",
      "aria-orientation": "horizontal",
      "aria-controls": a,
      "aria-valuemin": 0,
      "aria-valuemax": Math.round(d),
      "aria-valuenow": Math.round(t),
      "data-dragging": c || void 0,
      tabIndex: 0,
      onPointerDown: (y) => {
        if (y.button !== 0 || !l.current) return;
        const w = l.current.getBoundingClientRect(), v = w.width * (1 - p), g = y.target === y.currentTarget ? (y.clientX - w.left - w.width * p / 2) / Math.max(1, v) * d : t;
        b(g), s.current = {
          x: y.clientX,
          value: m(g),
          travel: v
        }, u(!0), y.currentTarget.setPointerCapture(y.pointerId);
      },
      onPointerMove: (y) => {
        s.current && b(
          s.current.value + (y.clientX - s.current.x) / Math.max(1, s.current.travel) * d
        );
      },
      onPointerUp: (y) => {
        s.current = null, u(!1), y.currentTarget.hasPointerCapture(y.pointerId) && y.currentTarget.releasePointerCapture(y.pointerId);
      },
      onPointerCancel: () => {
        s.current = null, u(!1);
      },
      onKeyDown: (y) => {
        const w = y.key === "ArrowLeft" ? -48 : y.key === "ArrowRight" ? 48 : y.key === "PageUp" ? -r : y.key === "PageDown" ? r : 0;
        (w || y.key === "Home" || y.key === "End") && (y.preventDefault(), b(
          y.key === "Home" ? 0 : y.key === "End" ? d : t + w
        ));
      },
      children: [
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-fill",
            style: { width: `${(f + p) * 100}%` },
            "aria-hidden": "true"
          }
        ),
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-thumb",
            style: { width: `${p * 100}%`, left: `${f * 100}%` },
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function fe({ children: t, initialHeight: n, className: r }) {
  const a = B(null), [i, l] = k(n), s = Kn();
  return Ce(() => {
    const c = a.current;
    if (!c) return;
    const u = () => l(c.getBoundingClientRect().height);
    if (u(), typeof ResizeObserver > "u") return;
    const d = new ResizeObserver(u);
    return d.observe(c), () => d.disconnect();
  }, []), /* @__PURE__ */ e(
    Un.div,
    {
      className: r,
      "data-animated-size": "",
      initial: n === void 0 ? !1 : { height: n, opacity: 0 },
      animate: { height: i ?? "auto", opacity: 1 },
      exit: { height: n ?? 0, opacity: 0 },
      transition: { duration: s ? 0 : 0.24, ease: [0.2, 0, 0, 1] },
      style: { overflow: "clip", minWidth: 0 },
      children: /* @__PURE__ */ e("div", { ref: a, style: { display: "flow-root", minWidth: 0 }, children: t })
    }
  );
}
function ds({
  page: t,
  zoom: n,
  aspect: r,
  onAspect: a,
  expanded: i
}) {
  const l = B(null), [s, c] = k(t.n <= 2), [u, d] = k(!1), [p, h] = k(0), [f, m] = k(!1);
  Y(() => {
    if (s || !l.current) return;
    const y = i ? l.current.closest(".resource-detail") : l.current.closest(".pdf-preview-pages"), w = new IntersectionObserver(
      (v) => {
        v.some((g) => g.isIntersecting) && (c(!0), w.disconnect());
      },
      { root: y, rootMargin: "700px 0px" }
    );
    return w.observe(l.current), () => w.disconnect();
  }, [s, i]), Y(() => {
    d(!1), h(0);
  }, [t.url]);
  const b = `${Math.round(n * 100)}%`;
  return /* @__PURE__ */ e(
    "div",
    {
      ref: l,
      "data-pdf-sheet": t.n,
      style: {
        width: b,
        aspectRatio: f ? void 0 : String(r),
        margin: n <= 1 ? "0 auto 12px" : "0 0 12px",
        background: "#fff",
        boxShadow: "0 1px 4px rgba(0,0,0,.12)"
      },
      children: s && (u ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
        "第 ",
        t.n,
        " 页加载失败。",
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              d(!1), h((y) => y + 1);
            },
            children: "重试"
          }
        )
      ] }) : /* @__PURE__ */ e(
        "img",
        {
          src: p ? `${t.url}${t.url.includes("?") ? "&" : "?"}retry=${p}` : t.url,
          alt: `第 ${t.n} 页`,
          draggable: !1,
          onLoad: (y) => {
            const w = y.currentTarget;
            t.n === 1 && w.naturalWidth > 0 && w.naturalHeight > 0 && a(w.naturalWidth / w.naturalHeight), m(!0);
          },
          onError: () => {
            m(!1), d(!0);
          },
          style: { display: "block", width: "100%", height: "auto" }
        }
      ))
    }
  );
}
function us({
  url: t,
  name: n,
  downloadUrl: r
}) {
  const a = B(null), i = B(null), l = Ne(), s = B(null), [c, u] = k(!1), [d, p] = k(null), [h, f] = k("loading"), [m, b] = k(1), [y, w] = k(""), [v, g] = k(!1), [x, N] = k(1), [C, A] = k(0.707), [L, U] = k(0), [S, I] = k({ left: 0, max: 0 });
  Y(() => {
    b(1), w(""), A(0.707), i.current && (i.current.scrollTop = 0);
  }, [t]), Y(() => {
    if (!a.current) return;
    const R = new IntersectionObserver(
      (O) => {
        O.some((M) => M.isIntersecting) && (u(!0), R.disconnect());
      },
      { rootMargin: "200px" }
    );
    return R.observe(a.current), () => R.disconnect();
  }, []), Y(() => {
    if (!c) return;
    const R = new AbortController();
    let O, M = 0, K = "";
    p(null), f("loading");
    const j = async () => {
      try {
        const P = new URL(t, window.location.href);
        P.searchParams.set("view", "pages"), P.searchParams.delete("download"), K && P.searchParams.set("hash", K);
        const $ = await fetch(P.href, {
          credentials: "include",
          signal: R.signal,
          cache: "no-store"
        });
        if (!$.ok) throw new Error("preview unavailable");
        const z = await $.json();
        if (R.signal.aborted) return;
        typeof z.contentHash == "string" && (K = z.contentHash), z.status === "ready" && z.manifest?.pages?.length ? (p({
          pages: z.manifest.pages,
          pageCount: z.manifest.pageCount || z.manifest.pages.length
        }), f("ready"), M = 0, O = setTimeout(() => {
          j();
        }, 1800 * 1e3)) : z.status === "failed" ? f("error") : (M++, f("rendering"), O = setTimeout(
          () => {
            j();
          },
          M < 15 ? 2e3 : M < 60 ? 5e3 : 1e4
        ));
      } catch {
        R.signal.aborted || f("error");
      }
    };
    return j(), () => {
      R.abort(), clearTimeout(O);
    };
  }, [t, c, L]);
  const T = xe(
    (R) => {
      const O = Math.max(1, Math.min(d?.pageCount || 1, R)), M = i.current, K = M?.querySelector(
        `[data-pdf-sheet="${O}"]`
      );
      M && K && (v ? K.scrollIntoView({ block: "start", behavior: "smooth" }) : M.scrollTo({
        top: M.scrollTop + K.getBoundingClientRect().top - M.getBoundingClientRect().top,
        behavior: "smooth"
      })), b(O);
    },
    [d?.pageCount, v]
  );
  Y(() => {
    const R = i.current;
    R && (R.scrollLeft = Math.max(
      0,
      (R.scrollWidth - R.clientWidth) / 2
    ));
  }, [x, h]), Y(() => {
    const R = i.current;
    if (!R) return;
    const O = () => I({
      left: R.scrollLeft,
      max: Math.max(0, R.scrollWidth - R.clientWidth)
    }), M = typeof ResizeObserver > "u" ? null : new ResizeObserver(O);
    M?.observe(R);
    const K = requestAnimationFrame(O);
    return () => {
      cancelAnimationFrame(K), M?.disconnect();
    };
  }, [x, h, d]);
  const H = (R) => {
    i.current && (i.current.scrollLeft = R), I((O) => ({ ...O, left: R }));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: a,
      className: `pdf-preview pdf-preview-scroll${v ? " pdf-preview-expanded" : " pdf-preview-windowed"}`,
      "aria-label": `${n} 预览`,
      children: [
        /* @__PURE__ */ o("div", { className: "pdf-preview-controls", children: [
          /* @__PURE__ */ o("div", { className: "pdf-page-navigation", children: [
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(
                "input",
                {
                  type: "number",
                  min: 1,
                  max: d?.pageCount || 1,
                  value: y || m,
                  onChange: (R) => w(R.target.value),
                  onKeyDown: (R) => {
                    R.key === "Enter" && (T(Number(y || m)), w(""));
                  },
                  "aria-label": "跳转到页码"
                }
              ),
              " ",
              "/ ",
              d?.pageCount || "…",
              " 页"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h !== "ready",
                onClick: () => {
                  T(Number(y || m)), w("");
                },
                children: "跳转"
              }
            )
          ] }),
          /* @__PURE__ */ o("div", { className: "pdf-zoom-controls", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: x <= 0.5 || h !== "ready",
                onClick: () => N((R) => Math.max(0.5, R - 0.25)),
                "aria-label": "缩小",
                children: /* @__PURE__ */ e(Tt, {})
              }
            ),
            /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                className: "pdf-zoom-value",
                title: "恢复适合宽度",
                onClick: () => N(1),
                children: [
                  Math.round(x * 100),
                  "%"
                ]
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: x >= 3 || h !== "ready",
                onClick: () => N((R) => Math.min(3, R + 0.25)),
                "aria-label": "放大",
                children: /* @__PURE__ */ e(gn, {})
              }
            )
          ] }),
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "pdf-expand-toggle",
              "aria-label": v ? "固定窗口" : "完整展开",
              title: v ? "固定窗口" : "完整展开",
              "aria-pressed": v,
              "aria-controls": l,
              onClick: () => g((R) => !R),
              children: [
                v ? /* @__PURE__ */ e(xr, { "aria-hidden": "true" }) : /* @__PURE__ */ e(Cr, { "aria-hidden": "true" }),
                /* @__PURE__ */ e("span", { children: v ? "固定窗口" : "完整展开" })
              ]
            }
          ),
          /* @__PURE__ */ e(
            "a",
            {
              className: "pdf-download",
              "aria-label": "下载原文件",
              title: "下载原文件",
              href: r || `${t}${t.includes("?") ? "&" : "?"}download=1`,
              download: !0,
              children: /* @__PURE__ */ e(Ot, {})
            }
          ),
          S.max > 1 && /* @__PURE__ */ e("div", { className: "pdf-preview-horizontal", children: /* @__PURE__ */ e(
            cs,
            {
              value: S.left,
              max: S.max,
              viewport: i.current?.clientWidth || 1,
              controls: l,
              onChange: H
            }
          ) })
        ] }),
        /* @__PURE__ */ e(fe, { children: h === "error" ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
          "暂时无法预览此文件。",
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => U((R) => R + 1),
              children: [
                /* @__PURE__ */ e(rt, {}),
                "重试"
              ]
            }
          )
        ] }) : h !== "ready" ? /* @__PURE__ */ e("div", { role: "status", className: "pdf-preview-message", children: "正在准备预览…" }) : /* @__PURE__ */ e(
          "div",
          {
            ref: i,
            id: l,
            className: "pdf-preview-pages",
            style: { cursor: x > 1 ? "grab" : void 0 },
            onScroll: (R) => {
              const O = R.currentTarget.scrollLeft;
              I(
                (M) => M.left === O ? M : { ...M, left: O }
              );
            },
            onPointerDown: (R) => {
              x <= 1 || R.pointerType !== "mouse" || R.button !== 0 || (s.current = {
                x: R.clientX,
                left: R.currentTarget.scrollLeft
              }, R.currentTarget.setPointerCapture(R.pointerId), R.currentTarget.style.cursor = "grabbing");
            },
            onPointerMove: (R) => {
              s.current && (R.currentTarget.scrollLeft = s.current.left - (R.clientX - s.current.x));
            },
            onPointerUp: (R) => {
              s.current = null, R.currentTarget.style.cursor = "grab";
            },
            onPointerCancel: () => {
              s.current = null;
            },
            children: d?.pages.map((R) => /* @__PURE__ */ e(
              ds,
              {
                page: R,
                zoom: x,
                aspect: C,
                onAspect: A,
                expanded: v
              },
              R.n
            ))
          }
        ) })
      ]
    }
  );
}
function ps({ progress: t, children: n, className: r = "", ...a }) {
  return /* @__PURE__ */ o("div", { ...a, "data-theme": "dark", className: `fp-media-controls ${r}`, children: [
    t && /* @__PURE__ */ e("div", { className: "fp-media-progress", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-media-toolbar", children: n })
  ] });
}
function pr({ className: t = "", style: n, min: r = 0, max: a = 100, value: i, ...l }) {
  const s = Math.max(0, Math.min(100, (Number(i ?? r) - Number(r)) / (Number(a) - Number(r) || 1) * 100));
  return /* @__PURE__ */ e("input", { ...l, type: "range", min: r, max: a, value: i, className: `fp-media-slider ${t}`, style: { ...n, "--fp-media-fill": `${s}%` } });
}
function jt(t, n, r) {
  const [a, i] = k({});
  return Ce(() => {
    if (!n || !t.current) return;
    const l = () => {
      if (!t.current) return;
      const u = getComputedStyle(t.current), d = {
        color: u.color,
        colorScheme: u.colorScheme,
        fontFamily: u.fontFamily
      };
      for (let p = 0; p < u.length; p++) {
        const h = u.item(p);
        h.startsWith("--fp-") && (d[h] = u.getPropertyValue(h));
      }
      i((p) => {
        const h = d;
        return JSON.stringify(p) === JSON.stringify(h) ? p : h;
      });
    };
    l();
    const s = new MutationObserver(l);
    for (let u = t.current; u; u = u.parentElement)
      s.observe(u, { attributes: !0, attributeFilter: ["class", "style", "data-theme", "data-product"] });
    const c = window.matchMedia?.("(prefers-color-scheme: dark)");
    return c?.addEventListener("change", l), () => {
      s.disconnect(), c?.removeEventListener("change", l);
    };
  }, [t, n, r]), a;
}
function Qe({
  label: t,
  triggerRole: n,
  triggerId: r,
  children: a,
  menu: i = !1,
  icon: l,
  trigger: s,
  disabled: c,
  className: u = "",
  role: d,
  onOpenChange: p,
  density: h = "comfortable"
}) {
  const [f, m] = k(!1), [b, y] = k(!1), w = () => {
    y(!0), m(!1);
  };
  Y(() => {
    if (!b) return;
    const H = setTimeout(() => y(!1), 120);
    return () => clearTimeout(H);
  }, [b]);
  const v = B(null), g = B(null), x = jt(v, f), N = Ne(), C = B(p);
  C.current = p, Y(() => {
    C.current?.(f);
  }, [f]);
  const A = d || (i ? "menu" : "dialog"), [L, U] = k({ left: 8, top: 8, maxHeight: 400 }), S = () => {
    w(), v.current?.focus();
  }, I = A === "listbox" ? '[role="option"]:not(:disabled)' : '[role="menuitem"]:not(:disabled)', T = (H = !1) => requestAnimationFrame(() => {
    const R = g.current?.querySelectorAll(I), O = g.current?.querySelector(
      '[aria-selected="true"]:not(:disabled)'
    );
    (H ? R?.[R.length - 1] : O || R?.[0])?.focus();
  });
  return Ce(() => {
    if (!f) return;
    const H = () => {
      const O = v.current?.getBoundingClientRect(), M = g.current?.getBoundingClientRect();
      if (!O || !M) return;
      const K = window.innerHeight - O.bottom - 16, j = O.top - 16, P = K < Math.min(M.height, 240) && j > K, $ = Math.max(80, P ? j : K), z = {
        left: Math.max(
          8,
          Math.min(O.left, window.innerWidth - M.width - 8)
        ),
        top: P ? Math.max(8, O.top - Math.min(M.height, $) - 8) : O.bottom + 8,
        maxHeight: $
      };
      U(
        (E) => E.left === z.left && E.top === z.top && E.maxHeight === z.maxHeight ? E : z
      );
    };
    H(), window.addEventListener("resize", H), window.addEventListener("scroll", H, !0);
    const R = typeof ResizeObserver > "u" ? null : new ResizeObserver(H);
    return g.current && R?.observe(g.current), () => {
      R?.disconnect(), window.removeEventListener("resize", H), window.removeEventListener("scroll", H, !0);
    };
  }, [f]), Y(() => {
    c && f && w();
  }, [c]), Y(() => {
    if (!f) return;
    const H = (O) => {
      const M = O.target;
      !v.current?.contains(M) && !g.current?.contains(M) && w();
    }, R = (O) => {
      O.key === "Escape" && (!O.target.closest?.("[data-fp-overlay]") || O.target.closest?.("[data-fp-overlay]") === g.current) && (O.preventDefault(), O.stopPropagation(), S());
    };
    return document.addEventListener("pointerdown", H, !0), document.addEventListener("focusin", H, !0), document.addEventListener("keydown", R, !0), A === "listbox" && g.current?.querySelector(".fp-select-search input") ? requestAnimationFrame(
      () => g.current?.querySelector(".fp-select-search input")?.focus({ preventScroll: !0 })
    ) : A !== "dialog" ? T() : requestAnimationFrame(
      () => (g.current?.querySelector(
        '[aria-pressed="true"]:not(:disabled)'
      ) || g.current?.querySelector(
        'input:not(:disabled), button:not(:disabled), [tabindex="0"]'
      ))?.focus({ preventScroll: !0 })
    ), () => {
      document.removeEventListener("pointerdown", H, !0), document.removeEventListener("focusin", H, !0), document.removeEventListener("keydown", R, !0);
    };
  }, [f]), /* @__PURE__ */ o("span", { className: "fp-dropdown", children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        ref: v,
        role: n,
        id: r,
        disabled: c,
        "aria-label": t,
        "aria-expanded": f,
        "aria-controls": f ? N : void 0,
        "aria-haspopup": A,
        className: `fp-popup-trigger${l ? " fp-popup-icon" : ""}`,
        onClick: () => {
          f ? w() : (y(!1), m(!0));
        },
        onKeyDown: (H) => {
          A !== "dialog" && (H.key === "ArrowDown" || H.key === "ArrowUp") && (H.preventDefault(), m(!0), T(H.key === "ArrowUp"));
        },
        children: s || l || /* @__PURE__ */ o(Z, { children: [
          /* @__PURE__ */ e("span", { children: t }),
          /* @__PURE__ */ e(Ft, { size: 15, "aria-hidden": "true" })
        ] })
      }
    ),
    (f || b) && Te(
      /* @__PURE__ */ e(
        "div",
        {
          ref: g,
          "data-fp-overlay": "",
          id: N,
          role: A,
          "aria-label": t,
          "aria-hidden": b || void 0,
          inert: b,
          "data-exiting": b || void 0,
          className: `fp-popup-panel ${A === "menu" ? "fp-popup-menu" : A === "listbox" ? "fp-popup-listbox" : "fp-popover-content"} ${h === "compact" ? "fp-popup-compact" : ""} ${u}`,
          style: {
            ...x,
            position: "fixed",
            ...L,
            overflowY: "auto",
            maxWidth: "calc(100vw - 16px)"
          },
          onKeyDown: (H) => {
            if (A === "dialog") return;
            if (H.key === "Tab") {
              w(), v.current?.focus();
              return;
            }
            const R = Array.from(
              g.current?.querySelectorAll(I) || []
            ), O = R.indexOf(
              document.activeElement
            ), M = H.key === "ArrowDown" ? (O + 1) % R.length : H.key === "ArrowUp" ? (O - 1 + R.length) % R.length : H.key === "Home" ? 0 : H.key === "End" ? R.length - 1 : -1;
            M >= 0 && (H.preventDefault(), H.stopPropagation(), R[M]?.focus());
          },
          children: a(S)
        }
      ),
      v.current?.closest("[data-fp-overlay],dialog") || document.body
    )
  ] });
}
function bi({
  label: t,
  items: n,
  icon: r
}) {
  return /* @__PURE__ */ e(Qe, { label: t, icon: r, menu: !0, children: (a) => n.map((i) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      role: "menuitem",
      className: i.danger ? "fp-error-text" : "",
      onClick: () => {
        a(), i.onClick();
      },
      children: i.label
    },
    i.label
  )) });
}
function oh({
  label: t,
  children: n
}) {
  return /* @__PURE__ */ e(Qe, { label: t, children: () => n });
}
function we({ value: t, onChange: n, options: r, label: a, id: i, disabled: l, placeholder: s = "请选择", className: c = "", searchable: u = r.length > 8 }) {
  return /* @__PURE__ */ e("span", { className: `fp-select-field ${c}`, children: /* @__PURE__ */ e(Qe, { label: a, triggerRole: "combobox", triggerId: i, role: "listbox", disabled: l, className: "fp-select-options", trigger: /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: r.find((d) => d.value === t)?.fontFamily }, children: [
      r.find((d) => d.value === t)?.color && /* @__PURE__ */ e("i", { style: { background: r.find((d) => d.value === t)?.color } }),
      r.find((d) => d.value === t)?.label || s
    ] }),
    /* @__PURE__ */ e(Ft, { size: 14, "aria-hidden": "true" })
  ] }), children: (d) => /* @__PURE__ */ e(hs, { options: r, value: t, searchable: u, onSelect: (p) => {
    n(p), d();
  } }) }) });
}
function hs({ options: t, value: n, searchable: r, onSelect: a }) {
  const [i, l] = k(""), s = t.filter((c) => `${c.label} ${c.value} ${c.description || ""}`.toLowerCase().includes(i.trim().toLowerCase()));
  return /* @__PURE__ */ o(Z, { children: [
    r && /* @__PURE__ */ e("div", { className: "fp-select-search", children: /* @__PURE__ */ e("input", { "aria-label": "搜索选项", placeholder: "搜索…", value: i, onChange: (c) => l(c.target.value), onKeyDown: (c) => {
      if (!c.nativeEvent.isComposing) {
        if (c.key === "ArrowDown" && (c.preventDefault(), c.currentTarget.parentElement?.nextElementSibling?.querySelector('[role="option"]:not(:disabled)')?.focus()), c.key === "Enter") {
          c.preventDefault();
          const u = s.find((d) => !d.disabled);
          u && a(u.value);
        }
        c.key !== "Escape" && c.stopPropagation();
      }
    } }) }),
    /* @__PURE__ */ o("div", { className: "fp-select-scroll", children: [
      s.map((c, u) => /* @__PURE__ */ o("div", { role: "none", children: [
        c.group && s[u - 1]?.group !== c.group && /* @__PURE__ */ e("div", { className: "fp-select-group", children: c.group }),
        /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": n === c.value, disabled: c.disabled, tabIndex: -1, onClick: () => a(c.value), children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: c.fontFamily }, children: [
              c.color && /* @__PURE__ */ e("i", { style: { background: c.color } }),
              c.label
            ] }),
            c.description && /* @__PURE__ */ e("small", { children: c.description })
          ] }),
          n === c.value && /* @__PURE__ */ e(Re, { size: 14, "aria-hidden": "true" })
        ] })
      ] }, c.value)),
      !s.length && /* @__PURE__ */ e("p", { className: "fp-select-empty", children: "没有匹配的选项" })
    ] })
  ] });
}
function ta(t) {
  if (!Number.isFinite(t)) return "0:00";
  const n = Math.floor(t / 60), r = Math.floor(t % 60);
  return `${n}:${String(r).padStart(2, "0")}`;
}
function Jt({
  src: t,
  poster: n,
  title: r,
  startAt: a = 0,
  autoPlay: i = !1,
  onReady: l,
  onWindowPlayback: s,
  onTimeUpdate: c,
  onEnded: u,
  resolveSource: d,
  videoRef: p,
  onSeek: h,
  onPlaybackRateChange: f,
  onPlaybackError: m,
  tracks: b = [],
  onPictureInPictureChange: y,
  keyboardShortcuts: w = !0
}) {
  const v = B(null), g = B(null), x = B(a), N = B(t), C = B(null), [A, L] = k(b.findIndex((_) => _.default)), [U, S] = k(!1), [I, T] = k(a), [H, R] = k(0), [O, M] = k(1), [K, j] = k(!1), [P, $] = k(d ? "" : t), [z, E] = k(""), [D, ne] = k(""), [ae, ye] = k(0), [he, W] = k(1), G = B({ onPlaybackError: m });
  G.current = { onPlaybackError: m };
  const ue = (_) => {
    E(_), G.current.onPlaybackError?.(_);
  };
  Y(() => {
    const _ = new AbortController();
    if (N.current !== t && (N.current = t, x.current = a), E(""), ne(""), S(!1), T(x.current), R(0), !d) {
      $(t);
      return;
    }
    return $(""), d(t, _.signal).then((F) => {
      _.signal.aborted || $(F);
    }).catch((F) => {
      _.signal.aborted || ue(F instanceof Error ? F.message : "视频暂时无法播放");
    }), () => _.abort();
  }, [t, d, ae]), Y(() => {
    const _ = g.current;
    _ && (x.current = a, _.currentTime = a);
  }, [t, a]), Y(() => {
    const _ = g.current;
    if (!_) return;
    const F = () => y?.(!0), Q = () => y?.(!1);
    return _.addEventListener("enterpictureinpicture", F), _.addEventListener("leavepictureinpicture", Q), () => {
      _.removeEventListener("enterpictureinpicture", F), _.removeEventListener("leavepictureinpicture", Q);
    };
  }, [y]);
  const me = () => {
    const _ = g.current;
    _ && (_.paused ? _.play().catch(() => ue("暂时无法播放，请重试")) : _.pause());
  }, q = async () => {
    const _ = g.current;
    if (_)
      try {
        document.pictureInPictureElement ? await document.exitPictureInPicture() : document.pictureInPictureEnabled && await _.requestPictureInPicture();
      } catch {
        ne("暂时无法打开画中画，请重试。");
      }
  }, V = async () => {
    try {
      ne(""), document.fullscreenElement === v.current ? await document.exitFullscreen() : await v.current?.requestFullscreen?.();
    } catch {
      ne("暂时无法进入全屏，请重试");
    }
  }, oe = (_) => {
    const F = g.current;
    !F || !Number.isFinite(F.duration) || F.duration <= 0 || (F.currentTime = Math.max(0, Math.min(F.duration, _)), T(F.currentTime));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-video",
      ref: v,
      tabIndex: 0,
      role: "region",
      "aria-label": r ? `${r}视频播放器` : "视频播放器",
      "aria-keyshortcuts": w ? "Space k j l ArrowLeft ArrowRight ArrowUp ArrowDown m f Home End" : void 0,
      onKeyDown: (_) => {
        if (!w || _.defaultPrevented || _.nativeEvent.isComposing || _.ctrlKey || _.altKey || _.metaKey || _.target.closest('input,textarea,select,button,[contenteditable="true"],[role="combobox"],[role="menu"]')) return;
        const F = g.current;
        if (!F) return;
        const Q = _.key.toLowerCase();
        ![" ", "k", "j", "l", "arrowleft", "arrowright", "arrowup", "arrowdown", "m", "f", "home", "end", ",", "."].includes(Q) && !/^[0-9]$/.test(Q) || (_.preventDefault(), _.stopPropagation(), !(_.repeat && [" ", "k", "m", "f"].includes(Q)) && (Q === " " || Q === "k" ? me() : Q === "j" || Q === "arrowleft" ? oe(F.currentTime - (Q === "j" ? 10 : 5)) : Q === "l" || Q === "arrowright" ? oe(F.currentTime + (Q === "l" ? 10 : 5)) : Q === "home" ? oe(0) : Q === "end" ? oe(F.duration) : /^[0-9]$/.test(Q) ? oe(F.duration * Number(Q) / 10) : Q === "arrowup" || Q === "arrowdown" ? (F.volume = Math.max(0, Math.min(1, F.volume + (Q === "arrowup" ? 0.05 : -0.05))), Q === "arrowup" && (F.muted = !1), M(F.volume), j(F.muted)) : Q === "m" ? (F.muted = !F.muted, j(F.muted)) : Q === "f" ? V() : F.paused && oe(F.currentTime + (Q === "." ? 1 / 30 : -1 / 30))));
      },
      children: [
        /* @__PURE__ */ o("div", { className: "fp-video-stage", children: [
          /* @__PURE__ */ e(
            "video",
            {
              ref: (_) => {
                g.current = _, typeof p == "function" ? p(_) : p && (p.current = _);
              },
              src: P || void 0,
              poster: n,
              playsInline: !0,
              preload: "metadata",
              onCanPlay: (_) => {
                const F = _.currentTarget;
                l?.(F), i && C.current !== t && (C.current = t, F.play().catch(() => {
                }));
              },
              onClick: () => {
                v.current?.focus({ preventScroll: !0 }), me();
              },
              onPlay: () => S(!0),
              onPause: () => S(!1),
              onLoadedMetadata: (_) => {
                _.currentTarget.playbackRate = he, _.currentTarget.volume = O, _.currentTarget.muted = K, Array.from(_.currentTarget.textTracks).forEach((F, Q) => {
                  F.mode = Q === A ? "showing" : "disabled";
                }), R(_.currentTarget.duration), _.currentTarget.currentTime = Math.max(0, Math.min(x.current, _.currentTarget.duration || x.current));
              },
              onError: () => {
                P && ue("视频暂时无法播放，请重试");
              },
              onSeeked: (_) => h?.(_.currentTarget.currentTime),
              onRateChange: (_) => {
                W(_.currentTarget.playbackRate), f?.(_.currentTarget.playbackRate);
              },
              onVolumeChange: (_) => {
                M(_.currentTarget.volume), j(_.currentTarget.muted);
              },
              onTimeUpdate: (_) => {
                x.current = _.currentTarget.currentTime, T(_.currentTarget.currentTime), c?.(_.currentTarget.currentTime);
              },
              onEnded: () => {
                S(!1), u?.();
              },
              "aria-label": r || "视频",
              children: b.map((_) => /* @__PURE__ */ e("track", { kind: "subtitles", src: _.src, srcLang: _.language, label: _.label, default: _.default }, _.src))
            }
          ),
          z && /* @__PURE__ */ o("div", { className: "fp-video-error", role: "alert", children: [
            /* @__PURE__ */ e("span", { children: z }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              d || g.current?.load(), ye((_) => _ + 1);
            }, children: "重新加载" })
          ] }),
          !z && !P && /* @__PURE__ */ e("div", { className: "fp-video-error", role: "status", children: "正在准备视频…" }),
          !U && !z && P && /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-video-bigplay",
              "aria-label": "播放",
              onClick: () => {
                v.current?.focus({ preventScroll: !0 }), me();
              },
              children: /* @__PURE__ */ e(Qt, { size: 26, fill: "currentColor" })
            }
          )
        ] }),
        /* @__PURE__ */ o(ps, { progress: /* @__PURE__ */ e(
          pr,
          {
            type: "range",
            min: 0,
            max: H || 0,
            step: 0.1,
            value: I,
            "aria-label": "播放进度",
            onChange: (_) => {
              const F = Number(_.target.value);
              T(F), g.current && (g.current.currentTime = F);
            }
          }
        ), children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": U ? "暂停" : "播放",
              title: "播放／暂停（空格或 K）",
              onClick: me,
              children: U ? /* @__PURE__ */ e(Pn, { size: 16 }) : /* @__PURE__ */ e(Qt, { size: 16 })
            }
          ),
          /* @__PURE__ */ o("span", { className: "fp-media-time", children: [
            ta(I),
            " / ",
            ta(H)
          ] }),
          b.length > 0 && /* @__PURE__ */ e(we, { label: "字幕", value: String(A), options: [{ value: "-1", label: "关闭字幕" }, ...b.map((_, F) => ({ value: String(F), label: _.label }))], onChange: (_) => {
            const F = Number(_);
            L(F), g.current && Array.from(g.current.textTracks).forEach((Q, ve) => {
              Q.mode = ve === F ? "showing" : "disabled";
            });
          } }),
          /* @__PURE__ */ e(we, { label: "播放速度", value: String(he), onChange: (_) => {
            g.current && (g.current.playbackRate = Number(_));
          }, options: [0.5, 0.75, 1, 1.25, 1.5, 2].map((_) => ({ value: String(_), label: `${_}×` })) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": K ? "取消静音" : "静音",
              title: "静音（M）",
              onClick: () => {
                const _ = g.current;
                _ && (_.muted = !_.muted, j(_.muted));
              },
              children: K ? /* @__PURE__ */ e(Ra, { size: 16 }) : /* @__PURE__ */ e(Ba, { size: 16 })
            }
          ),
          /* @__PURE__ */ e(
            pr,
            {
              className: "fp-media-volume",
              min: 0,
              max: 1,
              step: 0.05,
              value: O,
              "aria-label": "音量",
              onChange: (_) => {
                const F = Number(_.target.value);
                M(F), g.current && (g.current.volume = F);
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": s ? "小窗播放" : "画中画", disabled: !s && typeof document < "u" && !document.pictureInPictureEnabled, onClick: s ? () => s(g.current?.currentTime || 0) : q, children: /* @__PURE__ */ e(zl, { size: 16 }) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "全屏",
              title: "全屏（F）",
              onClick: () => {
                V();
              },
              children: /* @__PURE__ */ e(On, { size: 16 })
            }
          )
        ] }),
        D && /* @__PURE__ */ e("div", { className: "fp-video-notice", role: "status", children: D })
      ]
    }
  );
}
const na = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function xn({
  src: t,
  title: n = "音频",
  startAt: r = 0,
  onTimeUpdate: a,
  onEnded: i,
  resolveSource: l,
  audioRef: s,
  onSeek: c,
  onPlaybackRateChange: u
}) {
  const d = B(null), p = B(0), h = B(r), f = B(t), [m, b] = k(1), [y, w] = k(l ? "" : t), [v, g] = k(!1), [x, N] = k(0), [C, A] = k(0), [L, U] = k(1), [S, I] = k(""), [T, H] = k(0);
  Y(() => {
    const M = new AbortController(), K = ++p.current;
    return f.current !== t && (f.current = t, h.current = r), I(""), g(!1), N(h.current), A(0), w(""), Promise.resolve(l ? l(t, M.signal) : t).then((j) => {
      !M.signal.aborted && K === p.current && w(j);
    }).catch(() => {
      M.signal.aborted || I("音频暂时无法加载，请重试。");
    }), () => M.abort();
  }, [t, l, T]);
  const R = (M) => {
    if (d.current) {
      const K = Math.max(0, Math.min(C || 0, M));
      d.current.currentTime = K, N(K), h.current = K;
    }
  }, O = () => {
    const M = d.current;
    M && (M.paused ? M.play().catch(() => I("暂时无法播放，请重试。")) : M.pause());
  };
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-audio-player",
      "aria-label": n,
      tabIndex: 0,
      onKeyDown: (M) => {
        if (!M.target.closest("button,input") && [" ", "k", "ArrowLeft", "ArrowRight", "m"].includes(M.key))
          if (M.preventDefault(), M.key === " " || M.key === "k") O();
          else if (M.key === "m") {
            const K = L ? 0 : 1;
            U(K), d.current && (d.current.volume = K);
          } else R(x + (M.key === "ArrowLeft" ? -5 : 5));
      },
      children: [
        /* @__PURE__ */ e(
          "audio",
          {
            ref: (M) => {
              d.current = M, typeof s == "function" ? s(M) : s && (s.current = M);
            },
            src: y || void 0,
            preload: "metadata",
            onLoadedMetadata: () => {
              const M = d.current;
              A(Number.isFinite(M.duration) ? M.duration : 0), M.currentTime = Math.max(0, Math.min(h.current, M.duration || 0)), M.playbackRate = m, M.volume = L;
            },
            onSeeked: () => c?.(d.current.currentTime),
            onRateChange: () => {
              const M = d.current.playbackRate;
              b(M), u?.(M);
            },
            onTimeUpdate: () => {
              h.current = d.current.currentTime, N(h.current), a?.(d.current.currentTime);
            },
            onPlay: () => g(!0),
            onPause: () => g(!1),
            onEnded: () => {
              g(!1), i?.();
            },
            onError: () => {
              y && I("音频暂时无法加载，请重试。");
            }
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-audio-heading", children: [
          /* @__PURE__ */ e("strong", { children: n }),
          /* @__PURE__ */ o("span", { children: [
            na(x),
            " / ",
            na(C)
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-audio-controls", children: [
          /* @__PURE__ */ e(we, { label: "播放速度", value: String(m), options: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((M) => ({ value: String(M), label: `${M}×` })), onChange: (M) => {
            b(Number(M)), d.current && (d.current.playbackRate = Number(M));
          } }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": v ? "暂停" : "播放",
              disabled: !y || !!S,
              onClick: O,
              children: v ? /* @__PURE__ */ e(Pn, { size: 18 }) : /* @__PURE__ */ e(Qt, { size: 18 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "播放进度",
              type: "range",
              min: 0,
              max: C || 0,
              step: 0.1,
              value: Math.min(x, C),
              disabled: !C,
              onChange: (M) => R(Number(M.target.value))
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": L ? "静音" : "恢复音量",
              onClick: () => {
                const M = L ? 0 : 1;
                U(M), d.current && (d.current.volume = M);
              },
              children: L ? /* @__PURE__ */ e(Ba, { size: 17 }) : /* @__PURE__ */ e(Ra, { size: 17 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "音量",
              type: "range",
              min: 0,
              max: 1,
              step: 0.05,
              value: L,
              onChange: (M) => {
                const K = Number(M.target.value);
                U(K), d.current && (d.current.volume = K);
              }
            }
          )
        ] }),
        S && /* @__PURE__ */ o("p", { role: "alert", children: [
          S,
          /* @__PURE__ */ e("button", { type: "button", onClick: () => H((M) => M + 1), children: "重试" })
        ] })
      ]
    }
  );
}
function fs({
  resource: t,
  renderVideoExtra: n,
  videoProps: r,
  audioProps: a
}) {
  let { name: i, url: l, mediaType: s = "", previewUrl: c, bytes: u = 0 } = t, [d, p] = k(""), [h, f] = k(!1), m = /^(text\/(plain|markdown|csv)|application\/json)$/.test(s) || /\.(txt|md|csv|json)$/i.test(i), b = /\.(pdf|pptx?|docx?|xlsx?|odt|odp|ods)$/i.test(i) || s === "application/pdf";
  const y = b ? Pa : fe;
  return Y(() => {
    if (p(""), f(!1), !m || u > 2e6) return;
    let w = new AbortController();
    return fetch(l, { signal: w.signal, credentials: "include" }).then((v) => {
      if (!v.ok) throw Error();
      return v.text();
    }).then((v) => {
      w.signal.aborted || p(v);
    }).catch(() => {
      w.signal.aborted || f(!0);
    }), () => w.abort();
  }, [l, m, u]), /* @__PURE__ */ o("section", { className: "fp-resource-preview", children: [
    /* @__PURE__ */ o("header", { className: "fp-resource-header", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: i }),
        /* @__PURE__ */ e("small", { children: b ? "文档预览" : s.startsWith("image/") ? "图片预览" : "文件预览" })
      ] }),
      !b && /* @__PURE__ */ o("a", { href: t.downloadUrl || l, download: i, children: [
        /* @__PURE__ */ e(Ot, { size: 16, "aria-hidden": "true" }),
        "下载原文件"
      ] })
    ] }),
    /* @__PURE__ */ e(y, { children: b ? /* @__PURE__ */ e(
      us,
      {
        url: c || l,
        name: i,
        downloadUrl: t.downloadUrl || l
      }
    ) : s.startsWith("image/") ? /* @__PURE__ */ e("img", { className: "fp-preview-image", src: l, alt: i }) : s.startsWith("video/") ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e(Jt, { ...r, src: l, title: i }),
      n
    ] }) : s.startsWith("audio/") ? /* @__PURE__ */ e(xn, { ...a, src: l, title: i }) : m && u <= 2e6 ? /* @__PURE__ */ e("pre", { className: "fp-preview-text", children: h ? "暂时无法读取，请下载查看。" : d || "正在阅读文件…" }) : /* @__PURE__ */ e("div", { className: "pdf-preview-message", children: "此文件可以下载后查看。" }) })
  ] });
}
function ms(t, n) {
  const a = (t.target instanceof Element ? t.target : t.target instanceof Node ? t.target.parentElement : null)?.closest("a[href]");
  if (!a) return !1;
  let i;
  try {
    i = new URL(a.href, window.location.href);
  } catch {
    return !1;
  }
  return ["http:", "https:", "mailto:", "tel:"].includes(i.protocol) ? (t.preventDefault(), t.stopPropagation(), n(i.href, a.textContent || ""), !0) : !1;
}
const Cn = /* @__PURE__ */ new WeakMap();
function gi(t, n) {
  return typeof n == "string" && Cn.get(t) === n;
}
function bs(t, n) {
  gi(t, n) && Cn.delete(t);
}
function Qn(t, n = "note") {
  if (!t.isEditable) return !1;
  const r = crypto.randomUUID();
  Cn.set(t, r);
  const a = t.chain().focus().insertContent({ type: "directiveBlock", attrs: { name: n, attributes: "", body: "", id: r } }).command(({ tr: i }) => {
    let l;
    return i.doc.descendants((s, c) => {
      if (s.type.name === "directiveBlock" && s.attrs.id === r)
        return l = c, !1;
    }), l === void 0 ? !1 : (i.setSelection(Yt.create(i.doc, l)), !0);
  }).run();
  return a || Cn.delete(t), a;
}
function gs(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const r = n();
  if (r === void 0) return !1;
  const a = t.state.doc.nodeAt(r);
  if (a?.type.name !== "directiveBlock") return !1;
  const i = r + a.nodeSize, l = t.chain().command(({ tr: s }) => (s.doc.nodeAt(i)?.type.name !== "paragraph" && s.insert(i, t.schema.nodes.paragraph.create()), s.setSelection(Ge.create(s.doc, i + 1)).setStoredMarks(null).scrollIntoView(), !0)).run();
  return l && t.view.focus(), l;
}
function ra(t) {
  let n = 0;
  return t.descendants((r) => {
    if (r.type.name === "directiveBlock")
      return n++, !1;
  }), n;
}
const ys = Lr.create({ name: "cardBodyBoundary", addProseMirrorPlugins() {
  return [new an({ filterTransaction: (t, n) => !t.docChanged || ra(t.doc) <= ra(n.doc) })];
} }), hr = "fp.editor.commands.v1", fr = "fp:editor-command-usage";
let yi, St;
const mr = (t) => /^[a-zA-Z0-9:_-]{1,80}$/.test(t) && !["__proto__", "constructor", "prototype"].includes(t);
function Sn(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    const r = JSON.parse(t || "null");
    if (r?.version !== 1 || !r.counts || typeof r.counts != "object") return n;
    for (const [a, i] of Object.entries(r.counts).slice(0, 128)) {
      if (!mr(a) || !i || typeof i != "object") continue;
      const l = /* @__PURE__ */ Object.create(null);
      for (const [s, c] of Object.entries(i).slice(0, 256)) mr(s) && typeof c == "number" && Number.isSafeInteger(c) && c > 0 && c <= 1e9 && (l[s] = c);
      n[a] = l;
    }
  } catch {
  }
  return n;
}
function sh(t, n) {
  const r = Sn(t);
  for (const [a, i] of Object.entries(Sn(n))) {
    const l = r[a] ??= /* @__PURE__ */ Object.create(null);
    for (const [s, c] of Object.entries(i)) l[s] = Math.max(l[s] || 0, c);
  }
  return JSON.stringify({ version: 1, counts: r });
}
const vi = () => yi ?? (typeof window < "u" ? window.localStorage : void 0);
function ch(t) {
  yi = t, wi();
}
function wi() {
  typeof window < "u" && window.dispatchEvent(new Event(fr));
}
function ki(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    for (const [r, a] of Object.entries(Sn(t === void 0 ? vi()?.getItem(hr) ?? null : t))) n[r] = Object.values(a).reduce((i, l) => i + l, 0);
  } catch {
  }
  return n;
}
function dh(t, n) {
  return ki(n)[t] || 0;
}
function vs() {
  if (St) return St;
  const t = "fp.editor.command-device";
  try {
    St = window.localStorage.getItem(t) || crypto.randomUUID(), window.localStorage.setItem(t, St);
  } catch {
    St = crypto.randomUUID();
  }
  return St;
}
function ws(t) {
  if (!mr(t) || typeof window > "u") return;
  const n = () => {
    try {
      const r = vi();
      if (!r) return;
      const a = Sn(r.getItem(hr)), i = vs(), l = a[t] ??= /* @__PURE__ */ Object.create(null);
      l[i] = Math.min(1e9, (l[i] || 0) + 1), r.setItem(hr, JSON.stringify({ version: 1, counts: a })), wi();
    } catch {
    }
  };
  navigator.locks ? navigator.locks.request("fp-editor-command-usage", n).catch(() => {
  }) : n();
}
function Ni(t) {
  const n = {}, r = /([\w-]+)=(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^\s}]+))/g;
  for (const a of t.matchAll(r))
    n[a[1]] = (a[2] ?? a[3] ?? a[4] ?? "").replace(
      /\\([\\"'])/g,
      "$1"
    );
  return n;
}
function aa(t, n, r) {
  const a = Ni(t);
  return r ? a[n] = r : delete a[n], Object.entries(a).map(
    ([i, l]) => `${i}="${l.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`
  ).join(" ");
}
const ks = {
  video: [
    ["src", "视频地址"],
    ["poster", "封面地址"]
  ],
  audio: [["src", "音频地址"]],
  figure: [
    ["src", "图片地址"],
    ["alt", "图片说明"],
    ["caption", "图片标题"],
    ["credit", "图片来源"]
  ],
  interactive: [["src", "内容地址"]],
  plot: [
    ["fn", "函数表达式"],
    ["xmin", "横轴最小值"],
    ["xmax", "横轴最大值"],
    ["ymin", "纵轴最小值"],
    ["ymax", "纵轴最大值"]
  ],
  historymap: [
    ["points", "地点与坐标"],
    ["caption", "地图说明"]
  ],
  learninganimation: [
    ["src", "演示地址"],
    ["source", "源文件地址"],
    ["caption", "演示说明"]
  ],
  event: [
    ["year", "事件时间"],
    ["location", "地点"],
    ["people", "人物"],
    ["result", "结果"],
    ["impact", "影响"]
  ],
  attachment: [
    ["src", "附件地址"],
    ["name", "附件名称"]
  ]
};
function Ns({
  name: t,
  value: n,
  onChange: r,
  disabled: a
}) {
  const i = Ni(n), s = {
    "learning-animation": "learninganimation",
    figuremedia: "figure",
    functionplot: "plot",
    eventcard: "event",
    noteattachment: "attachment",
    memorycard: "memory"
  }[t] || t, c = ks[s] || [];
  return !c.length && s !== "memory" ? null : /* @__PURE__ */ o("div", { className: "fp-directive-fields", children: [
    s === "memory" && /* @__PURE__ */ o("label", { children: [
      "回忆方式",
      /* @__PURE__ */ e(
        we,
        {
          label: "回忆方式",
          value: i.mode || "checklist",
          onChange: (u) => r(aa(n, "mode", u)),
          disabled: a,
          options: [
            { value: "checklist", label: "逐项回忆" },
            { value: "cloze", label: "重点挖空" }
          ]
        }
      )
    ] }),
    c.map(([u, d]) => /* @__PURE__ */ o("label", { children: [
      d,
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": d,
          value: i[u] || "",
          disabled: a,
          onChange: (p) => r(aa(n, u, p.target.value))
        }
      )
    ] }, u))
  ] });
}
function xs() {
  return (t) => {
    function n(r, a = !1) {
      if (r.type === "element" && ["code", "pre", "script", "style", "math"].includes(r.tagName)) return;
      const i = a || r.type === "element" && ["td", "th"].includes(r.tagName);
      for (let l = 0; l < r.children.length; l++) {
        const s = r.children[l];
        if (s.type === "element") {
          n(s, i);
          continue;
        }
        if (!i || s.type !== "text" || !s.value.includes("$")) continue;
        const c = [], u = new RegExp("(?<!\\\\)\\$(?!\\$)([^$\\n]+?)(?<!\\\\)\\$(?!\\$)", "g");
        let d = 0, p;
        for (; p = u.exec(s.value); )
          p.index > d && c.push({ type: "text", value: s.value.slice(d, p.index) }), c.push({ type: "element", tagName: "span", properties: { className: ["math-inline", "language-math"] }, children: [{ type: "text", value: p[1] }] }), d = p.index + p[0].length;
        c.length && (d < s.value.length && c.push({ type: "text", value: s.value.slice(d) }), r.children.splice(l, 1, ...c), l += c.length - 1);
      }
    }
    n(t);
  };
}
function Cs() {
  return (t) => {
    Zt(t, "containerDirective", (n) => {
      n.name === "callout" && Zt(
        n,
        "text",
        (r, a, i) => {
          if (a == null || i == null || i.children == null) return;
          const l = r.value;
          if (typeof l != "string" || !l.includes(`
`)) return;
          const s = l.split(`
`), c = [];
          return s.forEach((u, d) => {
            d > 0 && c.push({ type: "break" }), u && c.push({ type: "text", value: u });
          }), i.children.splice(a, 1, ...c), [void 0, a + c.length];
        }
      );
    });
  };
}
const Ss = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
];
new Set(Ss);
const Mn = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function Ms(t) {
  const n = t.toLowerCase();
  return n in Mn ? Mn[n] ?? "note" : "note";
}
function Es(t) {
  const n = t.toLowerCase();
  return n in Mn && Mn[n] === null;
}
const $s = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, zs = /^(\s*)>( ?)(.*)$/;
function Is(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (a) => {
    if (a === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const i = r ? "‘" : "’";
    return r = !r, i;
  });
}
function As(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const w = c[1][0];
      a ? w === i && (a = !1, i = "") : (a = !0, i = w), r.push(s), l++;
      continue;
    }
    if (a) {
      r.push(s), l++;
      continue;
    }
    const u = s.match($s);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (Es(p)) {
      r.push(s), l++;
      continue;
    }
    const m = Ms(p), b = f.trim(), y = [`kind=${m}`];
    for (b && y.push(`label="${Is(b)}"`), h === "-" && y.push("collapsed=true"), r.push(`${d}:::callout{${y.join(" ")}}`), l++; l < n.length; ) {
      const w = n[l];
      if (!/^\s*>/.test(w) || w.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const g = w.match(zs);
      g ? r.push(g[3]) : r.push(w.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function Ls(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      a ? u === i && (a = !1, i = "") : (a = !0, i = u), r.push(l);
      continue;
    }
    if (a) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const Ts = /^(\s*:{1,4}[A-Za-z][\w-]*)(\{[^}\n]*\})([^\n]*)$/, Ds = /^\{(label|title)=([\s\S]*)\}$/;
function Ps(t) {
  return /^\{(?:label|title)=(?:"[^"]*"|'[^']*')(?:\s+[\s\S]*)?\}$/.test(t) ? t : t.replace(Ds, (n, r, a) => {
    let i = a.trim();
    return i.length >= 2 && i.startsWith('"') && i.endsWith('"') && (i = i.slice(1, -1)), i = i.replace(/"([^"]*)"/g, "“$1”").replace(/"/g, "“"), i = i.replace(/'([^']*)'/g, "‘$1’").replace(/'/g, "‘"), `{${r}="${i}"}`;
  });
}
function Os(t) {
  if (!t || (t = Ls(t), t = As(t), t.indexOf("::") === -1)) return t;
  const n = t.split(`
`);
  let r = !1, a = "";
  for (let i = 0; i < n.length; i++) {
    const l = n[i], s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const f = s[1][0];
      r ? f === a && (r = !1, a = "") : (r = !0, a = f);
      continue;
    }
    if (r) continue;
    const c = l.match(Ts);
    if (!c) continue;
    const [, u, d, p] = c, h = Ps(d);
    h !== d && (n[i] = u + h + p);
  }
  return n.join(`
`);
}
const Fs = { ...Ct, clobberPrefix: "fp-content-", tagNames: [...Ct.tagNames || [], "fp-directive", "mark"], attributes: { ...Ct.attributes, "fp-directive": ["dataName", "dataAttributes", "data-name", "data-attributes"], span: [...Ct.attributes?.span || [], "style", ["className", "math-inline", "language-math"]], mark: ["dataColor", "style"], td: [...Ct.attributes?.td || [], "rowSpan", "colSpan"], th: [...Ct.attributes?.th || [], "rowSpan", "colSpan"] } }, ia = /^(?:#[\da-f]{3,8}|[a-z]{1,24}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\))$/i;
function Rs() {
  return (t) => {
    Zt(t, "element", (n) => {
      if (n.tagName !== "span" && n.tagName !== "mark") return;
      const r = n.properties, i = String(r.style || "").split(";").map((s) => s.split(":")).filter(([s, c]) => /^(?:color|background-color|background)$/.test(s?.trim()) && ia.test(c?.trim())).map(([s, c]) => `${s.trim()}:${c.trim()}`), l = String(r.dataColor || "");
      n.tagName === "mark" && ia.test(l) && i.push(`background-color:${l}`), i.length ? r.style = i.join(";") : delete r.style;
    });
  };
}
function Bs() {
  return (t) => {
    const n = /* @__PURE__ */ new Map();
    Zt(t, "element", (r) => {
      if (!/^h[1-6]$/.test(r.tagName)) return;
      const a = (s) => s.children.map((c) => c.type === "text" ? c.value : c.type === "element" ? a(c) : "").join(""), i = a(r).toLowerCase().trim().replace(/[^\p{L}\p{N}\s_-]/gu, "").replace(/\s+/g, "-") || "section", l = (n.get(i) || 0) + 1;
      n.set(i, l), r.properties.id = l === 1 ? i : `${i}-${l}`;
    });
  };
}
const xi = {
  "\\placeholder": "\\mathord{\\square}\\phantom{#1}",
  "\\displaylines": "\\begin{gathered}#1\\end{gathered}"
};
function J(t, n) {
  const r = xl(async () => {
    const a = await t();
    return typeof a == "function" ? { default: a } : a;
  });
  return () => /* @__PURE__ */ e(Cl, { fallback: /* @__PURE__ */ e("p", { role: "status", children: "正在打开实验…" }), children: /* @__PURE__ */ e(r, {}) });
}
const Dr = [
  {
    id: "probability-disk-conditional-lab",
    subjectId: "probability",
    chapterId: "ch03",
    sectionId: "conditional-density",
    title: "圆盘条件密度切片",
    description: "拖动横坐标，比较弦长与归一后的条件密度。",
    Component: J(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.DiskConditionalLab)
    )
  },
  {
    id: "probability-occupancy-lab",
    subjectId: "probability",
    chapterId: "ch01",
    sectionId: "finite-occupancy",
    title: "每个窗口非空的分配",
    description: "调整人数和窗口数，观察条件计数与指定窗口人数分布。",
    Component: J(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.OccupancyLab)
    )
  },
  {
    id: "physics-electrostatics-lab",
    subjectId: "physics",
    chapterId: "learning",
    sectionId: "physics-electrostatics-lab",
    title: "静电场与叠加",
    Component: J(() => import("./ElectrostaticsLab-M7oVnK6H.js"))
  },
  {
    id: "discrete-set-counting",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-set-counting",
    title: "集合运算与计数",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.SetCountingLab)
    )
  },
  {
    id: "discrete-order-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-order-lab",
    title: "整除偏序与上下界",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.OrderLab)
    )
  },
  {
    id: "discrete-graph-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-graph-lab",
    title: "图的度数与二染色",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then(
        (t) => t.GraphStructureLab
      )
    )
  },
  {
    id: "discrete-matching-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-matching-lab",
    title: "图的最大匹配",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.MatchingLab)
    )
  },
  {
    id: "numerical-lu-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-lu-lab",
    title: "保存消元乘子的LU分解",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then((t) => t.LULab)
    )
  },
  {
    id: "numerical-cholesky-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-cholesky-lab",
    title: "平方根分解与正定条件",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.CholeskyLab
      )
    )
  },
  {
    id: "numerical-thomas-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-thomas-lab",
    title: "追赶法的递推与回代",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ThomasLab
      )
    )
  },
  {
    id: "numerical-condition-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-condition-lab",
    title: "条件数与扰动放大",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ConditionLab
      )
    )
  },
  {
    id: "numerical-divided-difference-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-divided-difference-lab",
    title: "差商与插值曲线",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.DividedDifferenceLab
      )
    )
  },
  {
    id: "discrete-prop-truth-table",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "propositional-logic",
    title: "真值表实验台",
    description: "切换公式与赋值，观察蕴含、双条件和德摩根律。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.TruthTableLab
      )
    )
  },
  {
    id: "discrete-predicate-quantifier",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "predicate-logic",
    title: "量词作用域实验台",
    description: "调整有限论域和谓词条件，对比全称量词与存在量词。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.QuantifierScopeLab
      )
    )
  },
  {
    id: "discrete-relation-properties",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "binary-relations",
    title: "关系性质实验台",
    description: "编辑三阶关系矩阵，实时判断自反、对称、反对称和传递性。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.RelationPropertyLab
      )
    )
  },
  {
    id: "discrete-function-mapping",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "orders-functions",
    title: "函数映射实验台",
    description: "改变有限函数的映射，实时判断单射、满射与双射。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.FunctionMappingLab
      )
    )
  },
  {
    id: "numerical-linear-lab",
    subjectId: "numerical-methods",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "两种线性迭代的计算过程",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.LinearLab)
    )
  },
  {
    id: "numerical-interpolation-lab",
    subjectId: "numerical-methods",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "等距高次插值的变化",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.InterpolationLab
      )
    )
  },
  {
    id: "numerical-fitting-lab",
    subjectId: "numerical-methods",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "观测点与最小二乘拟合",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.FittingLab)
    )
  },
  {
    id: "numerical-quadrature-lab",
    subjectId: "numerical-methods",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "加密网格与积分精度",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.QuadratureLab
      )
    )
  },
  {
    id: "numerical-ode-lab",
    subjectId: "numerical-methods",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "常微分方程的逐步求解",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.OdeLab)
    )
  },
  {
    id: "numerical-power-lab",
    subjectId: "numerical-methods",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "幂法收敛过程",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.PowerLab)
    )
  },
  {
    id: "numerical-source-rec-01",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01",
    title: "第一课 · 原始录音",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.RecordingOne)
    )
  },
  {
    id: "numerical-source-rec-02",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02",
    title: "第二课 · 原始录音",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.RecordingTwo)
    )
  },
  {
    id: "numerical-source-slides-03-04",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-03-04",
    title: "课件 · 第三、四章",
    Component: J(
      () => Promise.resolve().then(() => Xe).then(
        (t) => t.SlidesThreeFour
      )
    )
  },
  {
    id: "numerical-source-slides-05-06",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-05-06",
    title: "课件 · 第五、六章",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.SlidesFiveSix)
    )
  },
  {
    id: "numerical-source-slides-07-08",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-07-08",
    title: "课件 · 第七、八章",
    Component: J(
      () => Promise.resolve().then(() => Xe).then(
        (t) => t.SlidesSevenEight
      )
    )
  },
  {
    id: "numerical-source-slides",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides",
    title: "课件 · 第一、二章",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.Slides)
    )
  },
  {
    id: "numerical-source-textbook-6",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-6",
    title: "教材 · 第六版完整 PDF",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.Textbook)
    )
  },
  {
    id: "numerical-source-textbook-reference",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-reference",
    title: "补充教材 · 完整 PDF",
    Component: J(
      () => Promise.resolve().then(() => Xe).then(
        (t) => t.ReferenceTextbook
      )
    )
  },
  {
    id: "numerical-source-rec-01-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01-transcript",
    title: "第一课 · 原始转录稿",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.TranscriptOne)
    )
  },
  {
    id: "numerical-source-rec-02-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02-transcript",
    title: "第二课 · 原始转录稿",
    Component: J(
      () => Promise.resolve().then(() => Xe).then((t) => t.TranscriptTwo)
    )
  },
  {
    id: "numerical-error-lab",
    subjectId: "numerical-methods",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "面积误差实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.ErrorLab)
    )
  },
  {
    id: "numerical-bisection-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二分法实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.BisectionLab)
    )
  },
  {
    id: "numerical-iteration-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "不动点迭代实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.IterationLab)
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.1-events",
    chapterId: "ch01",
    sectionId: "1.1",
    title: "样本空间构造器",
    description: "点击骰子结果归入事件 A / B，实时显示集合表示与并交差补，直观体会「事件=子集」。",
    Component: J(() => import("./SampleSpaceBuilder-DKDCubKb.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.2-venn",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "事件运算 · 维恩图实验台",
    description: "选择并、交、差、补、对称差与德摩根律，实时高亮对应区域。",
    Component: J(() => import("./VennPlayground-yDIe19eQ.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.3-frequency",
    chapterId: "ch01",
    sectionId: "1.3",
    title: "频率趋于概率 · 抛硬币模拟",
    description: "批量抛硬币，观察正面频率随试验次数增大向 0.5 收敛。",
    Component: J(
      () => import("./FrequencyConvergence-D_R7GMec.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.4-coins",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "古典概型实验室",
    description: "切换掷两骰子之和 / 摸球场景，蒙特卡洛模拟对比理论概率与频率收敛。",
    Component: J(() => import("./ClassicalProbLab-CsFOyWKB.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.5-bayes-lab",
    chapterId: "ch01",
    sectionId: "1.5",
    title: "贝叶斯推断可视化",
    description: "调患病率 / 灵敏度 / 特异度，用方块图直观显示后验 P(病|阳性) 与基率谬误。",
    Component: J(() => import("./BayesExplorer-BRx_irdu.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.6-reliability",
    chapterId: "ch01",
    sectionId: "1.6",
    title: "串/并联系统可靠度探索器",
    description: "拖动各元件可靠度，实时计算系统可靠度并高亮工作/失效路径。",
    Component: J(() => import("./ReliabilityExplorer-BZLcH3fY.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.1-rv-mapper",
    chapterId: "ch02",
    sectionId: "2.1",
    title: "随机变量映射器",
    description: "点击样本点为其指定一个实数值，构造自定义随机变量 X，实时展示 X 的分布律。",
    Component: J(() => import("./RVMapper-65hp8cRq.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.2-binomial-explorer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二项/泊松分布探索器",
    description: "滑块调 n、p（或 λ），实时绘制分布律柱状图，切换二项/泊松，直观体会参数变化对形状的影响。",
    Component: J(() => import("./BinomialExplorer-BUimg2bl.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.3-cdf-visualizer",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "分布函数可视化",
    description: "切换离散/连续分布，拖动 x 轴上的竖线，左侧阴影面积实时显示 F(x)=P(X≤x) 的数值。",
    Component: J(() => import("./CDFVisualizer-1I8Pictu.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.4-pdf-explorer",
    chapterId: "ch02",
    sectionId: "2.4",
    title: "连续分布密度函数探索器",
    description: "切换均匀/指数/正态分布，调参数，拖动区间端点，实时计算 P(a≤X≤b)（面积）。",
    Component: J(() => import("./PDFExplorer-82a47XZM.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.5-func-dist-demo",
    chapterId: "ch02",
    sectionId: "2.5",
    title: "随机变量函数分布演示",
    description: "选 X 的分布，选变换 Y=g(X)，并排展示 X 和 Y 的 PDF/PMF，直观看到「折叠/拉伸」效果。",
    Component: J(() => import("./FuncDistDemo-CVrNS8dD.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.1-joint-dist-explorer",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "联合分布律探索器",
    description: "3×3 表格可编辑 p(xi,yj)，自动归一化，热力图实时展示联合分布，底部/右侧显示边缘分布。",
    Component: J(() => import("./JointDistExplorer-DhO5cBsX.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.2-marginal-explorer",
    chapterId: "ch03",
    sectionId: "3.2",
    title: "边缘分布提取演示",
    description: "从联合分布热力图中，点击某行/列即「投影」出该边缘分布，直观体会「对另一变量求和」的含义。",
    Component: J(() => import("./MarginalExplorer-CV5J9xv-.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.3-conditional-explorer",
    chapterId: "ch03",
    sectionId: "3.3",
    title: "条件分布可视化",
    description: "点击选定 Y=yj 的行，右侧自动计算并展示归一化后的 P(X|Y=yj)，与边缘 P(X) 并排对比。",
    Component: J(() => import("./ConditionalExplorer-14dDs9eY.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.4-independence-checker",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "独立性检验器",
    description: "编辑联合分布表，实时检验 p(xi,yj)=pi·qj 是否成立，用颜色高亮违反独立性的格子。",
    Component: J(() => import("./IndependenceChecker-BDQA5czh.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.5-convolution-demo",
    chapterId: "ch03",
    sectionId: "3.5",
    title: "卷积：两独立随机变量之和",
    description: "选 X 和 Y 各自的分布类型和参数，用蒙特卡洛模拟 Z=X+Y，展示 Z 的经验分布与理论 PDF。",
    Component: J(() => import("./ConvolutionDemo-BfkHEOoN.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.1-expectation-explorer",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "期望：加权重心探索器",
    description: "可拖动数轴上的概率质量块，实时看到期望「重心」移动，直观体会期望=加权平均。",
    Component: J(() => import("./ExpectationExplorer-C-WMDKGL.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.2-variance-explorer",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "方差与分布扩散度可视化",
    description: "并排两个正态分布，独立调 μ 和 σ，实时看到曲线形状变化，量化均值/方差/标准差。",
    Component: J(() => import("./VarianceExplorer-Bv_PRTxx.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.3-correlation-explorer",
    chapterId: "ch04",
    sectionId: "4.3",
    title: "相关系数可视化实验室",
    description: "拖动 ρ 滑块实时生成对应散点云，展示相关系数的几何意义；额外演示不相关但不独立的案例。",
    Component: J(() => import("./CorrelationExplorer-Ch9T7o1B.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.4-cov-matrix-demo",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "协方差矩阵与等高线椭圆",
    description: "调整 2×2 协方差矩阵的四个元素，实时看到二维正态分布等高线椭圆的形状和方向变化。",
    Component: J(() => import("./CovMatrixDemo-B-1WZEsk.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.1-chebyshev-demo",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "切比雪夫不等式演示",
    description: "调 ε 和 σ，实时看到概率尾部与切比雪夫上界的数值对比，直观体会不等式的松紧程度。",
    Component: J(() => import("./ChebyshevDemo-CZm0Kt2n.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.2-lln-simulator",
    chapterId: "ch05",
    sectionId: "5.2",
    title: "大数定律模拟器",
    description: "选分布、调 ε，批量模拟样本均值折线，可视化展示「n 越大，超出 ε 带的折线比例越小」。",
    Component: J(() => import("./LLNSimulator-pLGn9nLM.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.3-clt-simulator",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "中心极限定理模拟实验室",
    description: "任选底层分布（均匀/指数/泊松/二项），拖动 n，实时看样本均值的标准化直方图收敛到 N(0,1)。",
    Component: J(() => import("./CLTSimulator-BZqx08Ja.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.1-statistic-calculator",
    chapterId: "ch06",
    sectionId: "6.1",
    title: "统计量计算器",
    description: "输入或随机生成一组样本数据，实时计算 X̄、S²（n-1）、S、顺序统计量，并展示每步计算过程。",
    Component: J(() => import("./StatisticCalculator-qUSdZTwp.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.2-sampling-dist-explorer",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "三大抽样分布探索器",
    description: "切换 χ²/t/F 分布，调自由度参数，实时展示 PDF 曲线与临界值（α=0.05/0.01）。",
    Component: J(
      () => import("./SamplingDistExplorer-UxlLcTBn.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch06-6.3-normal-sampling-demo",
    chapterId: "ch06",
    sectionId: "6.3",
    title: "正态总体抽样分布仿真",
    description: "设定正态总体参数和样本量 n，大量重复抽样，实证验证四大定理（X̄、S²、t统计量的分布）。",
    Component: J(() => import("./NormalSamplingDemo-CwxsNJo3.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.4-quantile-explorer",
    chapterId: "ch06",
    sectionId: "6.4",
    title: "样本分位数与 Q-Q 图",
    description: "生成样本，展示各顺序统计量，绘制 Q-Q 图（与正态理论分位数对比），判断是否来自正态总体。",
    Component: J(() => import("./QuantileExplorer-DGChs3kW.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.1-moment-estimator",
    chapterId: "ch07",
    sectionId: "7.1",
    title: "矩估计量计算器",
    description: "选分布（指数/正态/均匀），输入样本，自动推导矩估计量公式并代入样本矩给出数值估计。",
    Component: J(() => import("./MomentEstimator-KE5isNUD.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.2-mle-explorer",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "极大似然估计可视化",
    description: "输入样本数据，展示对数似然函数曲线，标注 MLE 峰值，并允许用户拖动参数感受似然如何随 θ 变化。",
    Component: J(() => import("./MLEExplorer-Dq7T8fU7.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.3-estimator-comparator",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "估计量性质比较器",
    description: "大量重复抽样，可视化比较 X̄（均值估计）、S²（无偏方差）和 Sn²（有偏方差）的分布，验证无偏性和相合性。",
    Component: J(() => import("./EstimatorComparator-Dk3lkNZs.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.4-conf-interval-explorer",
    chapterId: "ch07",
    sectionId: "7.4",
    title: "置信区间捕获率可视化",
    description: "设定置信水平、样本量，批量模拟抽样，可视化每次的置信区间，统计实际覆盖率是否接近声称的 1-α。",
    Component: J(
      () => import("./ConfidenceIntervalExplorer-BxRdZEkH.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.1-hyp-test-demo",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "假设检验直觉演示",
    description: "调显著性水平 α 和观测到的检验统计量 z，实时看到拒绝域变化和决策结果（拒绝/不拒绝 H0）。",
    Component: J(() => import("./HypTestDemo-rrTfTpPc.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.2-mean-test-explorer",
    chapterId: "ch08",
    sectionId: "8.2",
    title: "均值假设检验计算器",
    description: "输入样本统计量，选 Z/t 检验和检验方向，自动计算检验统计量和 p 值，判断在给定 α 下是否拒绝 H0。",
    Component: J(() => import("./MeanTestExplorer-CusKecP0.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.3-variance-test-explorer",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "方差假设检验计算器",
    description: "输入样本方差 S²、样本量 n、假设方差 σ₀²，计算 χ² 统计量，在分布图上标注位置，给出检验结论。",
    Component: J(
      () => import("./VarianceTestExplorer-DMdp9C2G.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.4-error-type-demo",
    chapterId: "ch08",
    sectionId: "8.4",
    title: "两类错误权衡可视化",
    description: "调整显著性水平 α（或等价地移动拒绝域边界），实时看到 α（第一类）和 β（第二类）错误概率的此消彼长。",
    Component: J(() => import("./ErrorTypeDemo-Ci-t9P-0.js"))
  },
  // ─── 有机化学交互组件 ───────────────────────────────────────────────────────
  {
    subjectId: "chemistry",
    id: "ch01-1.2-bond-polarity",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "电负性与键极性探索器",
    description: "选择两个成键原子，按电负性差 Δχ 判定非极性/极性共价键/离子键，并画出偶极箭头。",
    Component: J(() => import("./BondPolarityExplorer-CoRShQhQ.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch02-2.2-iupac-namer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "IUPAC 命名练习器",
    description: "选择支链烷烃结构，逐步演示选主链、编号、列取代基、组合系统名的命名过程。",
    Component: J(() => import("./IUPACNamingPractice-Ba2XNKYT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch03-3.1-boiling-point",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "分子间作用力与沸点比较",
    description: "对烷烃同系列/同分异构体/氢键组排序沸点，验证分子间作用力对物理性质的影响。",
    Component: J(
      () => import("./BoilingPointComparator-sWZRZAmF.js")
    )
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.1-newman",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "纽曼投影构象能量",
    description: "拖动二面角观察纽曼投影旋转与势能曲线，对比乙烷/丁烷的交叉式与重叠式。",
    Component: J(() => import("./NewmanProjection-C1EvLXJm.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.2-chair-flip",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "环己烷椅式翻转",
    description: "演示椅式翻转时直立键 a 与平伏键 e 的互换，体会大取代基偏好赤道键。",
    Component: J(() => import("./ChairFlip-Md0U2D_M.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch05-5.3-carbocation",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "碳正离子稳定性",
    description: "比较甲基/伯/仲/叔碳正离子的超共轭数目与稳定性排序，理解电荷分散。",
    Component: J(() => import("./CarbocationStability-qUHSlIsS.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch06-6.2-markovnikov",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "马氏规则加成预测",
    description: "选不对称烯烃与 HX，对比两条路径碳正离子稳定性预测主产物；过氧化物切换反马氏。",
    Component: J(() => import("./MarkovnikovPredictor-DwurHVMV.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch07-7.3-diene",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "共轭二烯 1,2 vs 1,4 加成",
    description: "用温度滑块切换动力学（1,2，低温）与热力学（1,4，高温）产物比例。",
    Component: J(() => import("./DieneAddition-BoBJrygY.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch08-8.3-directing",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "芳环定位效应预测",
    description: "选苯环上已有取代基，判定致活/致钝与邻对位/间位定向，高亮下一取代位置。",
    Component: J(() => import("./DirectingEffect-C6D3YGBy.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.1-chirality",
    chapterId: "ch09",
    sectionId: "9.1",
    title: "手性与镜像",
    description: "尝试旋转手性分子的镜像使其重叠，体会对映异构体不可重叠即手性。",
    Component: J(() => import("./ChiralityMirror-CEewePpu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.3-rs-config",
    chapterId: "ch09",
    sectionId: "9.3",
    title: "R/S 构型判定",
    description: "分步引导：顺序规则排优先级、最小基朝后、看大中小转向判定 R/S。",
    Component: J(() => import("./RSConfigPractice-BBihDfok.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.1-sn1-sn2",
    chapterId: "ch10",
    sectionId: "10.1",
    title: "SN1/SN2 机理对比",
    description: "选底物/亲核试剂/溶剂，判定倾向 SN1 还是 SN2，演示背面进攻翻转与碳正离子外消旋。",
    Component: J(() => import("./SN1SN2Compare-De50UNKU.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.2-elimination",
    chapterId: "ch10",
    sectionId: "10.2",
    title: "E1/E2 与扎伊采夫规则",
    description: "选卤代烷展示不同 β-氢消除得到的烯烃，按扎伊采夫规则标出主产物。",
    Component: J(() => import("./EliminationZaitsev-BuPuwKj3.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch11-11.3-epoxide",
    chapterId: "ch11",
    sectionId: "11.3",
    title: "环氧乙烷开环区域选择",
    description: "切换酸/碱催化，对比亲核试剂进攻位阻大碳（酸）或位阻小碳（碱）。",
    Component: J(() => import("./EpoxideOpening-MXwtj4vu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch12-12.1-carbonyl",
    chapterId: "ch12",
    sectionId: "12.1",
    title: "羰基亲核加成",
    description: "选不同亲核试剂进攻羰基碳，演示电子流向与对应产物（α-羟基腈/醇/缩醛/亚胺等）。",
    Component: J(() => import("./CarbonylAddition-DVZgPquT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch13-13.2-acyl-reactivity",
    chapterId: "ch13",
    sectionId: "13.2",
    title: "羧酸衍生物活性序列",
    description: "酰氯>酸酐>酯>酰胺活性排序，点击查看离去能力与电子效应的原因。",
    Component: J(() => import("./AcylReactivity-wN8j1BXK.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.1-diazonium",
    chapterId: "ch14",
    sectionId: "14.1",
    title: "重氮盐转化网络",
    description: "点击不同试剂展示重氮盐的桑德迈尔/席曼/还原/水解/偶联等转化产物。",
    Component: J(() => import("./DiazoniumNetwork-Cd5Wc6HL.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.2-amine-basicity",
    chapterId: "ch14",
    sectionId: "14.2",
    title: "胺碱性比较",
    description: "对脂肪胺/氨/芳胺/吡啶/吡咯排序碱性，解释电子效应与芳香共轭的影响。",
    Component: J(() => import("./AmineBasicity-C1sxuYtu.js"))
  }
];
(() => {
  const t = /* @__PURE__ */ new Set();
  for (const n of Dr) {
    if (t.has(n.id))
      throw new Error(
        `[registry] 重复的交互 id: "${n.id}"（交互 id 必须全局唯一）`
      );
    t.add(n.id);
  }
})();
function js(t) {
  if (t)
    return Dr.find((n) => n.id === t);
}
const Pr = Dn(null);
function Ze({
  id: t,
  kind: n = "document"
}) {
  const r = rn(Pr);
  return /* @__PURE__ */ e("section", { className: "fp-learning-source", children: r ? r(t, n) : /* @__PURE__ */ e("p", { children: "请从课程资料中打开此内容。" }) });
}
const qs = () => /* @__PURE__ */ e(Ze, { id: "rec-01", kind: "audio" }), Ks = () => /* @__PURE__ */ e(Ze, { id: "rec-02", kind: "audio" }), Us = () => /* @__PURE__ */ e(Ze, { id: "slides" }), Hs = () => /* @__PURE__ */ e(Ze, { id: "textbook-6" }), _s = () => /* @__PURE__ */ e(Ze, { id: "textbook-reference" }), Ws = () => /* @__PURE__ */ e(Ze, { id: "rec-01", kind: "transcript" }), Vs = () => /* @__PURE__ */ e(Ze, { id: "rec-02", kind: "transcript" }), Xs = () => /* @__PURE__ */ e(Ze, { id: "slides-03-04" }), Ys = () => /* @__PURE__ */ e(Ze, { id: "slides-05-06" }), Gs = () => /* @__PURE__ */ e(Ze, { id: "slides-07-08" }), Xe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LearningSourceContext: Pr,
  RecordingOne: qs,
  RecordingTwo: Ks,
  ReferenceTextbook: _s,
  Slides: Us,
  SlidesFiveSix: Ys,
  SlidesSevenEight: Gs,
  SlidesThreeFour: Xs,
  Textbook: Hs,
  TranscriptOne: Ws,
  TranscriptTwo: Vs
}, Symbol.toStringTag, { value: "Module" }));
class Js extends Sl {
  state = { failed: !1, attempt: 0 };
  static getDerivedStateFromError() {
    return { failed: !0 };
  }
  componentDidCatch(n, r) {
    this.props.onError?.(n, r);
  }
  componentDidUpdate(n) {
    n.resetKey !== this.props.resetKey && this.state.failed && this.retry();
  }
  retry = () => this.setState(({ attempt: n }) => ({ failed: !1, attempt: n + 1 }));
  render() {
    return this.state.failed ? /* @__PURE__ */ o("section", { className: "fp-surface-recovery", role: "alert", children: [
      /* @__PURE__ */ e(rt, { size: 24, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: this.props.title || "内容暂时无法显示" }),
      /* @__PURE__ */ e("p", { children: this.props.description || "请重新打开，继续查看内容。" }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary", onClick: this.retry, children: [
        /* @__PURE__ */ e(rt, { size: 15, "aria-hidden": "true" }),
        "重新打开"
      ] })
    ] }) : /* @__PURE__ */ e("div", { className: "fp-surface-boundary", children: this.props.children }, this.state.attempt);
  }
}
function ee({
  title: t,
  description: n,
  actions: r,
  children: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-section", children: [
    (t || n || r) && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        t && /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r && /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: r })
    ] }),
    a
  ] });
}
function Qs({
  label: t,
  value: n,
  onChange: r,
  disabled: a,
  required: i
}) {
  const [l, s] = k(String(n)), c = B(!1), u = B(l);
  return u.current = l, Y(() => {
    (!c.current || !(typeof n == "number" && Object.is(Number(u.current), n)) && u.current !== String(n)) && s(String(n));
  }, [n]), /* @__PURE__ */ e(
    "input",
    {
      "aria-label": t,
      className: "fp-input",
      type: "text",
      inputMode: "decimal",
      value: l,
      onFocus: () => {
        c.current = !0;
      },
      onBlur: () => {
        c.current = !1, (typeof n == "string" || Number.isFinite(n)) && s(String(n));
      },
      onChange: (d) => {
        const p = d.target.value;
        u.current = p, s(p), r(p);
      },
      disabled: a,
      required: i
    }
  );
}
function X({
  label: t,
  value: n,
  onChange: r,
  hint: a,
  options: i,
  multiline: l,
  secret: s,
  numeric: c,
  disabled: u,
  required: d
}) {
  return /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    i ? /* @__PURE__ */ e(
      we,
      {
        label: t,
        value: String(n),
        options: i,
        onChange: r,
        disabled: u
      }
    ) : l ? /* @__PURE__ */ e(
      "textarea",
      {
        "aria-label": t,
        className: "fp-input",
        value: n,
        onChange: (p) => r(p.target.value),
        rows: 5,
        disabled: u,
        required: d
      }
    ) : c ? /* @__PURE__ */ e(
      Qs,
      {
        label: t,
        value: n,
        onChange: r,
        disabled: u,
        required: d
      }
    ) : /* @__PURE__ */ e(
      "input",
      {
        "aria-label": t,
        className: "fp-input",
        type: s ? "password" : "text",
        value: n,
        onChange: (p) => r(p.target.value),
        disabled: u,
        required: d,
        autoComplete: s ? "new-password" : void 0
      }
    ),
    a && /* @__PURE__ */ e("small", { children: a })
  ] });
}
function ze({
  label: t,
  checked: n,
  onChange: r,
  description: a,
  disabled: i
}) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-toggle", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      a && /* @__PURE__ */ e("p", { children: a })
    ] }),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        role: "switch",
        "aria-label": t,
        "aria-checked": n,
        disabled: i,
        className: "fp-switch-label",
        onClick: () => r(!n),
        children: /* @__PURE__ */ e("span", { "aria-hidden": "true", className: `fp-switch${n ? " is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) })
      }
    )
  ] });
}
function _e({
  label: t,
  value: n,
  onChange: r,
  items: a,
  density: i = "comfortable"
}) {
  const l = Ne(), s = Kn();
  return /* @__PURE__ */ e("div", { className: "fp-settings-tabs", "data-density": i, role: "tablist", "aria-label": t, children: a.map((c) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      role: "tab",
      "aria-selected": n === c.id,
      tabIndex: n === c.id ? 0 : -1,
      onClick: () => r(c.id),
      onKeyDown: (u) => {
        const d = a.findIndex((h) => h.id === c.id), p = u.key === "ArrowRight" ? (d + 1) % a.length : u.key === "ArrowLeft" ? (d - 1 + a.length) % a.length : u.key === "Home" ? 0 : u.key === "End" ? a.length - 1 : -1;
        p >= 0 && (u.preventDefault(), r(a[p].id), u.currentTarget.parentElement?.children[p]?.focus());
      },
      children: [
        n === c.id && /* @__PURE__ */ e(
          Un.span,
          {
            className: "fp-settings-tab-indicator",
            layoutId: `settings-tab-${l}`,
            transition: {
              duration: s ? 0 : 0.18,
              ease: [0.2, 0.8, 0.2, 1]
            }
          }
        ),
        /* @__PURE__ */ e("span", { children: c.label })
      ]
    },
    c.id
  )) });
}
function Le() {
  const [t, n] = k(!1), [r, a] = k(""), [i, l] = k(""), s = B(!1), c = B(!0);
  return Y(() => (c.current = !0, () => {
    c.current = !1;
  }), []), { busy: t, error: r, message: i, run: async (d, p = "") => {
    if (s.current) return !1;
    s.current = !0, n(!0), a(""), l("");
    try {
      return await d(), c.current && p && l(p), !0;
    } catch (h) {
      return c.current && a(
        h instanceof Error ? h.message : "操作暂未完成，请重试。"
      ), !1;
    } finally {
      s.current = !1, c.current && n(!1);
    }
  }, setError: a, setMessage: l };
}
function Se({
  error: t,
  message: n
}) {
  return /* @__PURE__ */ e(
    fe,
    {
      className: `fp-feedback-size${t || n ? " fp-feedback-visible" : ""}`,
      children: /* @__PURE__ */ o("div", { className: "fp-workspace-feedback", children: [
        t && /* @__PURE__ */ e("p", { role: "alert", children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] })
    }
  );
}
function it({
  busy: t,
  dirty: n = !0,
  onClick: r,
  label: a = "保存更改"
}) {
  return /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-primary",
      disabled: t || !n,
      onClick: r,
      children: t ? "正在保存…" : a
    }
  );
}
function et(t) {
  const [n, r] = k(t), [a, i] = k(() => JSON.stringify(t)), l = JSON.stringify(t), s = JSON.stringify(n) !== a, c = B(l);
  return Y(() => {
    l !== c.current && (c.current = l, s || (r(t), i(l)));
  }, [l, a, s]), { draft: n, setDraft: r, dirty: s, accept: (d) => {
    r(d), i(JSON.stringify(d));
  } };
}
function Ci({
  id: t,
  renderSource: n,
  sources: r
}) {
  const a = js(t);
  if (!a) return /* @__PURE__ */ e("p", { children: "暂时无法打开此实验，请重新选择。" });
  const i = a.Component;
  return /* @__PURE__ */ e(
    Pr.Provider,
    {
      value: n || (r ? (l, s) => r[`${l}:${s}`] || r[l] ? /* @__PURE__ */ e(
        uu,
        {
          source: r[`${l}:${s}`] || r[l]
        },
        `${l}:${s}`
      ) : /* @__PURE__ */ e("p", { children: "此资料暂不可用。" }) : null),
      children: /* @__PURE__ */ e(Js, { resetKey: t, children: /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { className: "fp-lab-content", "aria-label": a.title, children: /* @__PURE__ */ e(i, {}) }) }) })
    }
  );
}
function uh({
  value: t,
  onSelect: n,
  onSave: r,
  renderSource: a,
  sources: i
}) {
  const [l, s] = k(""), [c, u] = k("all"), [d, p] = k(""), h = Le(), f = t ?? d, m = {
    probability: "概率论",
    chemistry: "有机化学",
    physics: "大学物理",
    "discrete-math": "离散数学",
    "numerical-methods": "数值计算"
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "交互实验",
      description: "改变条件，观察结果，检验自己的理解。",
      children: [
        /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
          /* @__PURE__ */ e(X, { label: "搜索实验", value: l, onChange: s }),
          /* @__PURE__ */ e(
            X,
            {
              label: "实验学科",
              value: c,
              onChange: u,
              options: [
                { value: "all", label: "全部学科" },
                ...Object.entries(m).map(([b, y]) => ({
                  value: b,
                  label: y
                }))
              ]
            }
          )
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ e(
            "nav",
            {
              className: "fp-workspace-item-list fp-experiment-list",
              "aria-label": "交互实验列表",
              children: Dr.filter(
                (b) => (c === "all" || c === b.subjectId) && `${b.title} ${b.description || ""}`.includes(l)
              ).map((b) => /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-pressed": f === b.id,
                  onClick: () => {
                    p(b.id), n?.(b.id);
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: b.title }),
                    /* @__PURE__ */ e("small", { children: m[b.subjectId] || b.subjectId })
                  ]
                },
                b.id
              ))
            }
          ),
          /* @__PURE__ */ e("div", { children: f ? /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e(
              Ci,
              {
                id: f,
                renderSource: a,
                sources: i
              }
            ),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h.busy,
                className: "fp-button fp-secondary",
                onClick: () => {
                  h.run(() => r(f), "实验已保存到笔记。");
                },
                children: "保存到笔记"
              }
            )
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个实验开始探索。" }) })
        ] }),
        /* @__PURE__ */ e(Se, { ...h })
      ]
    }
  ) });
}
const Zs = [
  "svg",
  "g",
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "textPath",
  "defs",
  "marker",
  "use",
  "symbol",
  "clipPath",
  "mask",
  "pattern",
  "linearGradient",
  "radialGradient",
  "stop",
  "title",
  "desc",
  "image"
], ec = [
  "viewBox",
  "xmlns",
  "width",
  "height",
  "x",
  "y",
  "cx",
  "cy",
  "r",
  "rx",
  "ry",
  "x1",
  "y1",
  "x2",
  "y2",
  "d",
  "points",
  "fill",
  "stroke",
  "stroke-width",
  "stroke-dasharray",
  "stroke-linecap",
  "stroke-linejoin",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "transform",
  "font-size",
  "font-family",
  "font-weight",
  "text-anchor",
  "dominant-baseline",
  "dx",
  "dy",
  "markerWidth",
  "markerHeight",
  "refX",
  "refY",
  "orient",
  "id",
  "class",
  "clip-path",
  "mask",
  "filter",
  "gradientUnits",
  "offset",
  "stop-color",
  "stop-opacity",
  "patternUnits",
  "preserveAspectRatio",
  "role",
  "aria-label",
  "startOffset",
  "textLength",
  "lengthAdjust",
  "marker-end",
  "marker-start",
  "marker-mid",
  "fill-rule",
  "clip-rule",
  "letter-spacing",
  "word-spacing",
  "writing-mode",
  "alignment-baseline",
  "baseline-shift"
];
function tc(t, n = !0) {
  if (typeof window > "u") return t;
  let r;
  try {
    r = Fo.sanitize(t, {
      USE_PROFILES: { svg: !0, svgFilters: !0 },
      ADD_TAGS: Zs,
      ADD_ATTR: ec,
      FORBID_TAGS: ["script", "foreignObject", "iframe", "object", "embed"],
      FORBID_ATTR: ["onclick", "onload", "onerror", "onmouseover", "onmouseout", "onfocus", "onblur"]
    });
  } catch {
    return "";
  }
  return n && (r = r.replace(/(fill|stroke)="(?:black|#000(?:000)?|rgb\(0,\s*0,\s*0\))"/g, '$1="currentColor"').replace(/fill="(?:white|#fff(?:fff)?|rgb\(255,\s*255,\s*255\))"/g, 'fill="var(--diagram-surface)"')), r;
}
const nc = /* @__PURE__ */ new Set([
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "use",
  "image"
]);
function rc(t) {
  const n = t.getAttribute("viewBox") ?? t.getAttribute("viewbox");
  if (!n) return null;
  const r = n.trim().split(/[\s,]+/).map(Number).filter(Number.isFinite);
  return r.length !== 4 || r[2] <= 0 || r[3] <= 0 ? null : { minX: r[0], minY: r[1], width: r[2], height: r[3] };
}
function ot(t, n) {
  const r = t.getAttribute(n);
  if (!r) return null;
  const a = Number.parseFloat(r);
  return Number.isFinite(a) ? a : null;
}
function ac(t, n) {
  const r = n.minX + n.width, a = n.minY + n.height, i = t.tagName.toLowerCase(), l = [];
  if (i === "circle" || i === "ellipse") {
    const s = ot(t, "cx"), c = ot(t, "cy");
    s !== null && c !== null && l.push({ x: s, y: c });
  } else if (i === "rect" || i === "image" || i === "text" || i === "use") {
    const s = ot(t, "x") ?? 0, c = ot(t, "y") ?? 0;
    l.push({ x: s, y: c });
  } else if (i === "line") {
    const s = ot(t, "x1"), c = ot(t, "y1"), u = ot(t, "x2"), d = ot(t, "y2");
    s !== null && c !== null && l.push({ x: s, y: c }), u !== null && d !== null && l.push({ x: u, y: d });
  } else
    return !0;
  return l.length === 0 ? !0 : l.some(
    (s) => s.x >= n.minX && s.x <= r && s.y >= n.minY && s.y <= a
  );
}
function ic(t) {
  const n = t.trim();
  if (!n) return { ok: !1, reason: "empty", visibleElementCount: 0 };
  if (typeof DOMParser > "u") {
    const s = (n.match(/<(?:circle|ellipse|rect|line|polyline|polygon|path|text|tspan|use|image)\b/gi) ?? []).length;
    return s > 0 ? { ok: !0, reason: "ok", visibleElementCount: s } : { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  }
  const a = new DOMParser().parseFromString(n, "image/svg+xml").querySelector("svg");
  if (!a) return { ok: !1, reason: "no-svg-root", visibleElementCount: 0 };
  const i = Array.from(a.querySelectorAll("*")).filter((s) => nc.has(s.tagName.toLowerCase()));
  if (i.length === 0) return { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  const l = rc(a);
  return l && !i.some((s) => ac(s, l)) ? { ok: !1, reason: "out-of-viewbox", visibleElementCount: i.length } : { ok: !0, reason: "ok", visibleElementCount: i.length };
}
function Or() {
  const [t, n] = k(!1), r = xe(() => n((i) => !i), []), a = xe(() => n(!1), []);
  return Y(() => {
    if (!t) return;
    const i = document.activeElement, l = (s) => {
      s.key === "Escape" && (s.preventDefault(), s.stopPropagation(), a());
    };
    return document.addEventListener("keydown", l, !0), () => {
      document.removeEventListener("keydown", l, !0), i?.focus({ preventScroll: !0 });
    };
  }, [t, a]), { fullscreen: t, toggle: r, exit: a };
}
function Fr({
  onReset: t,
  onZoomIn: n,
  onZoomOut: r,
  onDownload: a,
  onOpenExternal: i,
  onMaximize: l,
  fullscreen: s = !1
}) {
  return /* @__PURE__ */ o("div", { className: "svg-canvas-controls", children: [
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: n,
        title: "放大",
        "aria-label": "放大",
        children: /* @__PURE__ */ e(ja, { size: 11 })
      }
    ),
    r && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: r,
        title: "缩小",
        "aria-label": "缩小",
        children: /* @__PURE__ */ e(qa, { size: 11 })
      }
    ),
    t && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: t,
        title: "重置视图",
        "aria-label": "重置视图",
        children: /* @__PURE__ */ e(rt, { size: 11 })
      }
    ),
    a && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: a,
        title: "下载 HTML",
        "aria-label": "下载 HTML",
        children: /* @__PURE__ */ e(Ot, { size: 11 })
      }
    ),
    i && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: i,
        title: "新页面展开",
        "aria-label": "新页面展开",
        children: /* @__PURE__ */ e(Rt, { size: 11 })
      }
    ),
    l && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: l,
        title: s ? "退出全屏" : "放大查看",
        "aria-label": s ? "退出全屏" : "放大查看",
        children: s ? /* @__PURE__ */ e(xr, { size: 11 }) : /* @__PURE__ */ e(Cr, { size: 11 })
      }
    )
  ] });
}
function lc({
  diagnostic: t
}) {
  return !t || t.ok ? null : /* @__PURE__ */ o("div", { className: "fp-canvas-status", role: "status", children: [
    /* @__PURE__ */ e("strong", { children: "画布暂时无法显示" }),
    /* @__PURE__ */ e("p", { children: "请检查内容，或通过“修改画布”调整后再试。" })
  ] });
}
function oc({
  busy: t,
  error: n,
  onCancel: r,
  onSubmit: a
}) {
  const [i, l] = k(""), s = Le(), c = t || s.busy;
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-canvas-revision",
      onSubmit: (u) => {
        u.preventDefault(), !(!i.trim() || c || !a) && s.run(async () => {
          await a(i.trim()), l(""), r();
        });
      },
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "希望如何调整画布",
            value: i,
            multiline: !0,
            disabled: c,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(Se, { error: n || s.error }),
        /* @__PURE__ */ o("footer", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-secondary",
              type: "button",
              disabled: c,
              onClick: r,
              children: "取消"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-primary",
              type: "submit",
              disabled: c || !i.trim() || !a,
              children: c ? "正在调整…" : "生成修改"
            }
          )
        ] })
      ]
    }
  );
}
function ln({
  title: t,
  source: n,
  diagnostic: r,
  controls: a,
  children: i,
  className: l,
  style: s,
  onPointerDown: c,
  onPointerMove: u,
  onPointerUp: d,
  onPointerCancel: p,
  onWheel: h,
  revisionBlock: f,
  revisionTopic: m,
  revisionBusy: b = !1,
  revisionError: y,
  onRevisionSubmit: w,
  onRevisionAccepted: v
}) {
  const [g, x] = k(!1), [N, C] = k(!1), A = !!n?.trim();
  return /* @__PURE__ */ o(
    "div",
    {
      className: `svg-canvas-wrapper canvas-frame ${l ?? ""}`,
      style: s,
      onPointerDown: c,
      onPointerMove: u,
      onPointerUp: d,
      onPointerCancel: p,
      onWheel: h,
      children: [
        /* @__PURE__ */ e("div", { className: "svg-canvas-controls svg-canvas-controls-left", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "press",
            disabled: !w,
            onClick: () => x((L) => !L),
            title: "修改画布",
            "aria-label": "修改画布",
            children: /* @__PURE__ */ e(Fn, { size: 11 })
          }
        ) }),
        a,
        t ? /* @__PURE__ */ e("div", { className: "canvas-frame-title", children: t }) : null,
        /* @__PURE__ */ e("div", { className: "canvas-frame-body", children: i }),
        /* @__PURE__ */ e(lc, { diagnostic: r }),
        /* @__PURE__ */ e(fe, { children: g ? /* @__PURE__ */ e(
          oc,
          {
            block: f,
            topic: m,
            busy: b,
            error: y,
            onCancel: () => x(!1),
            onSubmit: w,
            onRevisionAccepted: v
          }
        ) : null }),
        A ? /* @__PURE__ */ o("div", { className: "canvas-source-panel", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "viz-error-toggle press",
              onClick: () => C((L) => !L),
              children: N ? "收起内容" : "查看内容"
            }
          ),
          /* @__PURE__ */ e(fe, { children: N ? /* @__PURE__ */ e("pre", { className: "viz-error-source", children: n }) : null })
        ] }) : null
      ]
    }
  );
}
function _n({
  open: t,
  onExit: n,
  children: r,
  label: a = "学习画布"
}) {
  const i = B(null), l = B(null), s = B(null), [c, u] = k(null);
  return Ce(() => {
    const d = document.createElement("div");
    return d.className = "fp-canvas-portal-content", u(d), () => d.remove();
  }, []), Ce(() => {
    c && (t ? l.current : i.current)?.append(c);
  }, [c, t]), Y(() => {
    if (!t) return;
    s.current = document.activeElement;
    const d = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const p = requestAnimationFrame(
      () => l.current?.querySelector('button:not(:disabled),[tabindex="0"]')?.focus({ preventScroll: !0 })
    );
    return () => {
      cancelAnimationFrame(p), document.body.style.overflow = d, s.current?.focus({ preventScroll: !0 });
    };
  }, [t]), /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ e("div", { ref: i }),
    c && Te(r, c),
    t && Te(
      /* @__PURE__ */ e("div", { className: "canvas-fullscreen-backdrop", onClick: n, children: /* @__PURE__ */ e(
        "div",
        {
          ref: l,
          className: "canvas-fullscreen-stage",
          role: "dialog",
          "aria-modal": "true",
          "aria-label": a,
          onClick: (d) => d.stopPropagation(),
          onKeyDown: (d) => {
            if (d.key === "Escape" && d.target.closest("[data-fp-overlay]") || (d.key === "Escape" && (d.preventDefault(), d.stopPropagation(), n()), d.key !== "Tab")) return;
            const p = [
              ...d.currentTarget.querySelectorAll(
                'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]'
              )
            ].filter((m) => m.getClientRects().length), h = p[0], f = p.at(-1);
            d.shiftKey && document.activeElement === h ? (d.preventDefault(), f?.focus()) : !d.shiftKey && document.activeElement === f && (d.preventDefault(), h?.focus());
          }
        }
      ) }),
      document.body
    )
  ] });
}
const la = 0.25, oa = 4;
function sc(t, n, r) {
  const a = t.match(/<svg\b[^>]*>/i);
  if (!a) return t;
  const i = a[0];
  if (/\bviewbox\s*=/i.test(i)) return t;
  const l = i.match(/\bwidth\s*=\s*["']?\s*(\d+(?:\.\d+)?)/i), s = i.match(/\bheight\s*=\s*["']?\s*(\d+(?:\.\d+)?)/i), c = l ? parseFloat(l[1]) : n, u = s ? parseFloat(s[1]) : r;
  return t.replace(
    i,
    i.replace(/<svg\b/i, `<svg viewBox="0 0 ${c} ${u}"`)
  );
}
function Si({
  block: t,
  revisionBlock: n = t,
  revisionTopic: r,
  onRevisionSubmit: a,
  onRevisionAccepted: i
}) {
  const l = t.width ?? 400, s = t.height ?? 300, [c, u] = k({ x: 0, y: 0 }), [d, p] = k(1), h = B(null), { fullscreen: f, toggle: m, exit: b } = Or(), y = He(() => tc(t.source), [t.source]), w = y.trimStart().startsWith("<svg"), v = He(() => {
    const I = w ? y : `<svg viewBox="0 0 ${l} ${s}" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">${y}</svg>`;
    return sc(I, l, s);
  }, [y, w, s, l]), g = He(() => ic(v), [v]), x = g.ok ? null : {
    ok: !1,
    reason: g.reason,
    message: "Canvas has no visible SVG content.",
    details: { visibleElementCount: g.visibleElementCount }
  }, N = xe(
    (I) => {
      I.target.closest(
        ".svg-canvas-controls, .canvas-revision-panel, .canvas-source-panel"
      ) || (I.currentTarget.setPointerCapture(I.pointerId), h.current = {
        startX: I.clientX,
        startY: I.clientY,
        panX: c.x,
        panY: c.y
      });
    },
    [c]
  ), C = xe(
    (I) => {
      h.current && u({
        x: h.current.panX + I.clientX - h.current.startX,
        y: h.current.panY + I.clientY - h.current.startY
      });
    },
    []
  ), A = xe(() => {
    h.current = null;
  }, []), L = xe((I) => {
    if (!I.ctrlKey && !I.metaKey) return;
    I.preventDefault();
    const T = I.deltaY > 0 ? 0.9 : 1.1;
    p((H) => Math.max(la, Math.min(oa, H * T)));
  }, []), U = xe(() => {
    u({ x: 0, y: 0 }), p(1);
  }, []), S = /* @__PURE__ */ e(
    Fr,
    {
      onReset: U,
      onZoomIn: () => p((I) => Math.min(oa, I * 1.2)),
      onZoomOut: () => p((I) => Math.max(la, I / 1.2)),
      onMaximize: m,
      fullscreen: f
    }
  );
  return /* @__PURE__ */ e(_n, { open: f, onExit: b, children: /* @__PURE__ */ e(
    ln,
    {
      title: t.title,
      source: t.source,
      diagnostic: x,
      controls: S,
      className: "svg-raw-content",
      style: { touchAction: "none" },
      onPointerDown: N,
      onPointerMove: C,
      onPointerUp: A,
      onPointerCancel: A,
      onWheel: L,
      revisionBlock: n,
      revisionTopic: r,
      onRevisionSubmit: a,
      onRevisionAccepted: i,
      children: /* @__PURE__ */ e(
        "div",
        {
          className: "svg-raw-inner",
          style: {
            transform: `translate(${c.x}px, ${c.y}px) scale(${d})`,
            transformOrigin: "center center",
            width: "100%",
            height: "auto",
            minHeight: s
          },
          dangerouslySetInnerHTML: { __html: v }
        }
      )
    }
  ) });
}
const sa = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, ca = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
}, cc = /\\[A-Za-z]+/;
function da(t) {
  const n = [];
  let r = 0, a = 0;
  for (let i = 0; i < t.length; i += 1) {
    const l = t[i];
    l === "(" && (r += 1), l === ")" && (r -= 1), l === "," && r === 0 && (n.push(t.slice(a, i).trim()), a = i + 1);
  }
  return n.push(t.slice(a).trim()), n;
}
function ua(t, n, r) {
  return `(1/((${r})*sqrt(2*pi)))*exp(-(((${t})-(${n}))^2)/(2*(${r})^2))`;
}
function Mi(t, n = {}) {
  const r = String(n.mu ?? 0), a = String(n.sigma ?? 1);
  let i = (t ?? "").trim().replace(/\u2212/g, "-").replace(/\bMath\./g, "").replace(/μ/g, r).replace(/σ/g, a);
  return i = i.replace(/\b(?:normal_pdf|gaussian)\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x", u = "0", d = "1"] = da(s);
    return ua(c, u, d);
  }), i = i.replace(/\bphi\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x"] = da(s);
    return ua(c, "0", "1");
  }), i;
}
function dc(t) {
  const n = Object.keys(sa), r = Object.values(sa), a = Object.keys(ca), i = Object.values(ca), l = t.replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), s = new Function(
    "x",
    ...n,
    ...a,
    `"use strict"; return (${l});`
  );
  return (c) => {
    const u = s(c, ...r, ...i);
    return typeof u == "number" ? u : NaN;
  };
}
function uc(t, n = {}) {
  const r = Mi(t, n);
  if (!r)
    return {
      ok: !1,
      reason: "empty-fn",
      normalizedFn: r,
      message: "Function expression is empty."
    };
  if (cc.test(r))
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function plots do not accept LaTeX syntax. Use plain expressions such as normal_pdf(x,0,1)."
    };
  let a;
  try {
    a = dc(r);
  } catch {
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function expression could not be parsed."
    };
  }
  const i = n.xmin ?? -10, l = n.xmax ?? 10, s = Math.max(2, Math.floor(n.samples ?? 200)), c = (l - i) / (s - 1);
  let u = 0;
  for (let d = 0; d < s; d += 1)
    try {
      const p = a(i + d * c);
      Number.isFinite(p) && (u += 1);
    } catch {
      return {
        ok: !1,
        reason: "unsupported-syntax",
        normalizedFn: r,
        message: "Function expression failed while sampling."
      };
    }
  return u === 0 ? {
    ok: !1,
    reason: "no-finite-samples",
    normalizedFn: r,
    message: "Function expression produced no finite sample points."
  } : {
    ok: !0,
    normalizedFn: r,
    sampledPoints: u
  };
}
const pa = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, ha = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
};
function Rr(t) {
  const n = Mi(t).replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), r = Object.keys(pa), a = Object.values(pa), i = Object.keys(ha), l = Object.values(ha);
  try {
    const s = new Function(
      "x",
      ...r,
      ...i,
      `"use strict"; return (${n});`
    );
    return (c) => {
      try {
        const u = s(c, ...a, ...l);
        return typeof u == "number" ? u : NaN;
      } catch {
        return NaN;
      }
    };
  } catch {
    return () => NaN;
  }
}
function fa(t, n, r = 8) {
  const a = n - t;
  if (a <= 0 || !isFinite(a)) return [];
  const i = a / r, l = Math.pow(10, Math.floor(Math.log10(i))), s = i / l;
  let c;
  s <= 1.5 ? c = 1 * l : s <= 3.5 ? c = 2 * l : s <= 7.5 ? c = 5 * l : c = 10 * l;
  const u = Math.ceil(t / c) * c, d = [];
  for (let p = u; p <= n + c * 0.01; p += c) {
    const h = Math.round(p * 1e12) / 1e12;
    h >= t && h <= n && d.push({ value: h, label: pc(h, c) });
  }
  return d;
}
function pc(t, n) {
  if (t === 0) return "0";
  const r = Math.max(0, -Math.floor(Math.log10(n)));
  return t.toFixed(r).replace(/\.?0+$/, "");
}
function hc(t, n, r, a, i, l, s, c) {
  const u = (r - n) / (a - 1), p = (c - s) * 2;
  let h = "", f = null, m = !1;
  for (let b = 0; b < a; b++) {
    const y = n + b * u, w = t(y);
    if (!isFinite(w) || isNaN(w)) {
      m = !1, f = null;
      continue;
    }
    const v = i(y), g = l(w);
    f !== null && Math.abs(w - f) > p && (m = !1), m ? h += `L${v.toFixed(2)},${g.toFixed(2)}` : (h += `M${v.toFixed(2)},${g.toFixed(2)}`, m = !0), f = w;
  }
  return h;
}
function Ei(t, n, r, a = 200) {
  let i = 1 / 0, l = -1 / 0;
  const s = (r - n) / (a - 1);
  for (let u = 0; u < a; u++) {
    const d = n + u * s, p = t(d);
    isFinite(p) && (p < i && (i = p), p > l && (l = p));
  }
  if (!isFinite(i) || !isFinite(l)) return { yMin: -1, yMax: 1 };
  const c = (l - i) * 0.1 || 1;
  return { yMin: i - c, yMax: l + c };
}
const Zn = [
  "var(--md-sys-color-primary)",
  "var(--md-sys-color-tertiary)",
  "var(--md-sys-color-error)",
  "var(--color-formula, #1976d2)",
  "var(--color-success, #2e7d32)",
  "var(--color-warning, #f57c00)"
];
function fc(t, n) {
  return n ? Zn.some((r) => r.includes(n)) ? `var(--md-sys-color-${n})` : n : Zn[t % Zn.length];
}
const ce = { top: 20, right: 20, bottom: 36, left: 48 }, ma = 0.25, ba = 4;
function $i({
  width: t = 600,
  height: n = 400,
  xMin: r = -10,
  xMax: a = 10,
  yMin: i = -5,
  yMax: l = 5,
  showGrid: s = !0,
  showAxes: c = !0,
  axisLabels: u,
  pannable: d = !0,
  zoomable: p = !0,
  className: h,
  children: f
}) {
  const m = B(null), [b, y] = k({ x: 0, y: 0 }), [w, v] = k(1), { fullscreen: g, toggle: x, exit: N } = Or(), C = B(null), A = t - ce.left - ce.right, L = n - ce.top - ce.bottom, U = a - r || 1e-6, S = l - i || 1e-6, I = xe(
    (D) => {
      d && (D.target.closest?.(".svg-canvas-controls") || (D.currentTarget.setPointerCapture(D.pointerId), C.current = {
        startX: D.clientX,
        startY: D.clientY,
        panX: b.x,
        panY: b.y
      }));
    },
    [d, b]
  ), T = xe((D) => {
    if (!C.current) return;
    const ne = D.clientX - C.current.startX, ae = D.clientY - C.current.startY;
    y({ x: C.current.panX + ne, y: C.current.panY + ae });
  }, []), H = xe(() => {
    C.current = null;
  }, []), R = xe(
    (D) => {
      if (!p || !D.ctrlKey && !D.metaKey) return;
      D.preventDefault();
      const ne = D.deltaY > 0 ? 0.9 : 1.1;
      v((ae) => Math.max(ma, Math.min(ba, ae * ne)));
    },
    [p]
  ), O = xe(() => {
    y({ x: 0, y: 0 }), v(1);
  }, []), M = fa(r, a), K = fa(i, l), j = (D) => ce.left + (D - r) / U * A, P = (D) => ce.top + (l - D) / S * L, $ = j(0), z = P(0), E = 0 >= r && 0 <= a && 0 >= i && 0 <= l;
  return /* @__PURE__ */ e(_n, { open: g, onExit: N, children: /* @__PURE__ */ o("div", { className: `svg-canvas-wrapper ${h ?? ""}`, children: [
    /* @__PURE__ */ o(
      "svg",
      {
        ref: m,
        viewBox: `0 0 ${t} ${n}`,
        width: t,
        height: n,
        onPointerDown: I,
        onPointerMove: T,
        onPointerUp: H,
        onPointerCancel: H,
        onWheel: R,
        style: { touchAction: "none" },
        children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e("clipPath", { id: "plot-area", children: /* @__PURE__ */ e(
            "rect",
            {
              x: ce.left,
              y: ce.top,
              width: A,
              height: L
            }
          ) }) }),
          /* @__PURE__ */ o(
            "g",
            {
              transform: `translate(${b.x + t / 2}, ${b.y + n / 2}) scale(${w}) translate(${-t / 2}, ${-n / 2})`,
              children: [
                s && /* @__PURE__ */ o("g", { className: "svg-canvas-grid", clipPath: "url(#plot-area)", children: [
                  M.map((D) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: j(D.value),
                      y1: ce.top,
                      x2: j(D.value),
                      y2: ce.top + L
                    },
                    `gx-${D.value}`
                  )),
                  K.map((D) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: ce.left,
                      y1: P(D.value),
                      x2: ce.left + A,
                      y2: P(D.value)
                    },
                    `gy-${D.value}`
                  ))
                ] }),
                c && /* @__PURE__ */ o("g", { className: "svg-canvas-axis", children: [
                  E || i <= 0 ? /* @__PURE__ */ o(Z, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: ce.left,
                        y1: E ? z : ce.top + L,
                        x2: ce.left + A,
                        y2: E ? z : ce.top + L
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${ce.left + A},${E ? z : ce.top + L} ${ce.left + A - 6},${(E ? z : ce.top + L) - 3} ${ce.left + A - 6},${(E ? z : ce.top + L) + 3}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  E || r <= 0 ? /* @__PURE__ */ o(Z, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: E ? $ : ce.left,
                        y1: ce.top,
                        x2: E ? $ : ce.left,
                        y2: ce.top + L
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${E ? $ : ce.left},${ce.top} ${(E ? $ : ce.left) - 3},${ce.top + 6} ${(E ? $ : ce.left) + 3},${ce.top + 6}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  M.map(
                    (D) => D.value === 0 && E ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: j(D.value),
                          y1: (E ? z : ce.top + L) - 3,
                          x2: j(D.value),
                          y2: (E ? z : ce.top + L) + 3
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: j(D.value),
                          y: (E ? z : ce.top + L) + 16,
                          textAnchor: "middle",
                          children: D.label
                        }
                      )
                    ] }, `xt-${D.value}`)
                  ),
                  K.map(
                    (D) => D.value === 0 && E ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: (E ? $ : ce.left) - 3,
                          y1: P(D.value),
                          x2: (E ? $ : ce.left) + 3,
                          y2: P(D.value)
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: (E ? $ : ce.left) - 8,
                          y: P(D.value) + 4,
                          textAnchor: "end",
                          children: D.label
                        }
                      )
                    ] }, `yt-${D.value}`)
                  ),
                  u?.x && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: ce.left + A - 4,
                      y: (E ? z : ce.top + L) + 32,
                      textAnchor: "end",
                      children: u.x
                    }
                  ),
                  u?.y && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: (E ? $ : ce.left) + 12,
                      y: ce.top + 4,
                      textAnchor: "start",
                      children: u.y
                    }
                  ),
                  E && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-tick",
                      x: $ - 8,
                      y: z + 16,
                      textAnchor: "end",
                      fill: "var(--md-sys-color-on-surface-variant)",
                      fontSize: "10",
                      fontFamily: "var(--font-mono)",
                      children: "O"
                    }
                  )
                ] }),
                /* @__PURE__ */ e("g", { clipPath: "url(#plot-area)", children: f })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e(
      Fr,
      {
        onReset: d || p ? O : void 0,
        onZoomIn: p ? () => v((D) => Math.min(ba, D * 1.2)) : void 0,
        onZoomOut: p ? () => v((D) => Math.max(ma, D / 1.2)) : void 0,
        onMaximize: x,
        fullscreen: g
      }
    )
  ] }) });
}
function zi({
  fn: t,
  xMin: n,
  xMax: r,
  yMin: a,
  yMax: i,
  plotLeft: l,
  plotTop: s,
  plotWidth: c,
  plotHeight: u,
  color: d,
  colorIndex: p = 0,
  label: h,
  strokeWidth: f = 2,
  samples: m = 500
}) {
  const b = He(
    () => uc(t, { xmin: n, xmax: r, samples: m }),
    [t, m, r, n]
  ), y = b.normalizedFn, w = He(
    () => Rr(y),
    [y]
  ), v = (C) => l + (C - n) / (r - n) * c, g = (C) => s + (i - C) / (i - a) * u, x = He(
    () => b.ok ? hc(
      w,
      n,
      r,
      m,
      v,
      g,
      a,
      i
    ) : "",
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      b.ok,
      y,
      n,
      r,
      a,
      i,
      l,
      s,
      c,
      u,
      m
    ]
  ), N = fc(p, d);
  return !b.ok || !x.trim() ? /* @__PURE__ */ e(
    "g",
    {
      "data-testid": "plot-diagnostic",
      "aria-label": b.ok ? "empty plot path" : b.message,
      children: /* @__PURE__ */ e(
        "text",
        {
          x: l + 8,
          y: s + 20,
          fontSize: 12,
          fill: "var(--md-sys-color-error)",
          children: b.ok ? "No drawable curve points." : b.message
        }
      )
    }
  ) : /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ e(
      "path",
      {
        d: x,
        className: "svg-canvas-curve",
        stroke: N,
        strokeWidth: f
      }
    ),
    h && /* @__PURE__ */ e("title", { children: h })
  ] });
}
const Mt = { top: 20, right: 20, bottom: 36, left: 48 };
function mc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = t.width ?? 600, l = t.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = Ei(Rr(t.fn), s, c), d = t.attrs.ymin ?? u.yMin, p = t.attrs.ymax ?? u.yMax, h = i - Mt.left - Mt.right, f = l - Mt.top - Mt.bottom;
  return /* @__PURE__ */ e(
    ln,
    {
      title: t.title,
      source: t.fn,
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        $i,
        {
          width: i,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: /* @__PURE__ */ e(
            zi,
            {
              fn: t.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: Mt.left,
              plotTop: Mt.top,
              plotWidth: h,
              plotHeight: f,
              color: t.attrs.color,
              label: t.attrs.label,
              samples: t.attrs.samples
            }
          )
        }
      )
    }
  );
}
const Et = { top: 20, right: 20, bottom: 36, left: 48 };
function bc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = t.width ?? t.attrs.width ?? 600, l = t.height ?? t.attrs.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = t.plots.reduce(
    (m, b) => {
      const y = Ei(Rr(b.fn), s, c);
      return {
        yMin: Math.min(m.yMin, y.yMin),
        yMax: Math.max(m.yMax, y.yMax)
      };
    },
    { yMin: 1 / 0, yMax: -1 / 0 }
  ), d = t.attrs.ymin ?? (Number.isFinite(u.yMin) ? u.yMin : -5), p = t.attrs.ymax ?? (Number.isFinite(u.yMax) ? u.yMax : 5), h = i - Et.left - Et.right, f = l - Et.top - Et.bottom;
  return /* @__PURE__ */ e(
    ln,
    {
      title: t.title,
      source: JSON.stringify(t.plots, null, 2),
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        $i,
        {
          width: i,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: t.plots.map((m, b) => /* @__PURE__ */ e(
            zi,
            {
              fn: m.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: Et.left,
              plotTop: Et.top,
              plotWidth: h,
              plotHeight: f,
              color: m.color,
              colorIndex: b,
              label: m.label,
              samples: m.samples
            },
            `${m.fn}-${b}`
          ))
        }
      )
    }
  );
}
const Ii = Dn(null);
function gc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = rn(Ii), [l, s] = k({ key: "", svg: "", error: "" });
  Y(() => {
    if (!i) return;
    const u = new AbortController();
    return s({ key: t.source, svg: "", error: "" }), i(t.source, {
      width: t.width || 380,
      height: t.height || 300,
      signal: u.signal
    }).then((d) => {
      u.signal.aborted || s({ key: t.source, svg: d, error: "" });
    }).catch(() => {
      u.signal.aborted || s({
        key: t.source,
        svg: "",
        error: "分子结构暂时无法显示，请检查后重试。"
      });
    }), () => u.abort();
  }, [i, t.source, t.width, t.height]);
  const c = { revisionTopic: n, onRevisionSubmit: r, onRevisionAccepted: a };
  return l.key === t.source && l.svg ? /* @__PURE__ */ e(
    Si,
    {
      ...c,
      block: { ...t, kind: "raw-svg", source: l.svg }
    }
  ) : /* @__PURE__ */ e(
    ln,
    {
      ...c,
      title: t.title || "分子结构",
      source: t.source,
      revisionBlock: t,
      children: /* @__PURE__ */ e("p", { role: "status", children: l.error || (i ? "正在绘制分子结构…" : "选择分子结构，查看对应内容。") })
    }
  );
}
function yc(t, n) {
  const r = n.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 60) || "demo", a = new Blob([t], { type: "text/html;charset=utf-8" }), i = URL.createObjectURL(a), l = document.createElement("a");
  l.href = i, l.download = `${r}.html`, document.body.appendChild(l), l.click(), l.remove(), setTimeout(() => URL.revokeObjectURL(i), 1e3);
}
function vc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const { fullscreen: i, toggle: l, exit: s } = Or(), c = t.title || "互动内容", u = t.height ?? 360, d = xe(() => {
    const f = URL.createObjectURL(
      new Blob([t.source], { type: "text/html" })
    );
    window.open(f, "_blank", "noopener"), setTimeout(() => URL.revokeObjectURL(f), 6e4);
  }, [t.source]), p = xe(
    () => yc(t.source, c),
    [t.source, c]
  ), h = /* @__PURE__ */ e(
    Fr,
    {
      onDownload: p,
      onOpenExternal: d,
      onMaximize: l,
      fullscreen: i
    }
  );
  return /* @__PURE__ */ e(_n, { open: i, onExit: s, children: /* @__PURE__ */ e(
    ln,
    {
      title: t.title,
      source: t.source,
      controls: h,
      className: "html-canvas-layer",
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        "iframe",
        {
          title: c,
          srcDoc: `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none';">${t.source}`,
          sandbox: "allow-scripts",
          referrerPolicy: "no-referrer",
          className: "html-canvas-frame",
          style: { height: i ? "100%" : u }
        }
      )
    }
  ) });
}
function br({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  switch (t.kind) {
    case "raw-svg":
      return /* @__PURE__ */ e(
        Si,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "plot":
      return /* @__PURE__ */ e(
        mc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "multi-plot":
      return /* @__PURE__ */ e(
        bc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "molecule":
      return /* @__PURE__ */ e(
        gc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "html":
      return /* @__PURE__ */ e(
        vc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
  }
}
const wc = /^<svg\b[\s\S]*<\/svg>$/i, kc = /<(?:g|path|rect|circle|ellipse|line|polyline|polygon|text|tspan|textPath|defs|marker|stop|linearGradient|radialGradient|clipPath|mask|pattern|image|use|symbol)\b[\s\S]*>/i;
function nt(t) {
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function Be(t) {
  if (t === "" || t === null || t === void 0) return;
  const n = Number(t);
  return Number.isFinite(n) ? n : void 0;
}
function En(t) {
  if (t === !0 || t === "true") return !0;
  if (t === !1 || t === "false") return !1;
}
function Nc(t) {
  return {
    title: nt(t.title),
    width: Be(t.width),
    height: Be(t.height)
  };
}
function xc(t, n, r) {
  const a = String(t ?? "").trim();
  if (!a) return "";
  if (wc.test(a) || !kc.test(a)) return a;
  const i = Number.isFinite(n) && n && n > 0 ? Math.round(n) : 600, l = Number.isFinite(r) && r && r > 0 ? Math.round(r) : 360;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${i} ${l}" width="${i}" height="${l}">${a}</svg>`;
}
function Ai(t) {
  return {
    xmin: Be(t.xmin),
    xmax: Be(t.xmax),
    ymin: Be(t.ymin),
    ymax: Be(t.ymax),
    label: nt(t.label),
    xlabel: nt(t.xlabel),
    ylabel: nt(t.ylabel),
    color: nt(t.color),
    samples: Be(t.samples),
    grid: En(t.grid),
    axes: En(t.axes)
  };
}
function Cc(t) {
  return {
    xmin: Be(t.xmin),
    xmax: Be(t.xmax),
    ymin: Be(t.ymin),
    ymax: Be(t.ymax),
    xlabel: nt(t.xlabel),
    ylabel: nt(t.ylabel),
    width: Be(t.width),
    height: Be(t.height),
    grid: En(t.grid),
    axes: En(t.axes)
  };
}
function Sc(t, n) {
  const r = nt(t.mode)?.toLowerCase() ?? "raw", a = (n ?? "").trim(), i = Nc(t);
  return r === "molecule" ? {
    ...i,
    kind: "molecule",
    source: a
  } : r === "math" ? {
    ...i,
    kind: "plot",
    fn: nt(t.fn) ?? a,
    attrs: Ai(t)
  } : r === "html" ? {
    ...i,
    kind: "html",
    source: a
  } : {
    ...i,
    kind: "raw-svg",
    source: xc(a, i.width, i.height)
  };
}
const Li = Bo(jo), Wn = [
  { value: "javascript", label: "JavaScript" },
  { value: "typescript", label: "TypeScript" },
  { value: "python", label: "Python" },
  { value: "bash", label: "Bash" },
  { value: "json", label: "JSON" },
  { value: "html", label: "HTML" },
  { value: "css", label: "CSS" },
  { value: "markdown", label: "Markdown" },
  { value: "xml", label: "XML" },
  { value: "yaml", label: "YAML" },
  { value: "mermaid", label: "Mermaid" },
  { value: "cpp", label: "C++" },
  { value: "java", label: "Java" },
  { value: "c", label: "C" },
  { value: "csharp", label: "C#" },
  { value: "go", label: "Go" },
  { value: "rust", label: "Rust" },
  { value: "sql", label: "SQL" }
];
function er() {
  return null;
}
function Mc(t) {
  if (!t || typeof t != "object") return er();
  const r = t.attrs?.language;
  if (typeof r != "string") return er();
  const a = r.trim();
  return a || er();
}
const Ti = 4;
function Di(t, n, r, a = !1, i = Ti) {
  const l = " ".repeat(i);
  if (n === r && !a) return [{ from: n, to: r, text: l }];
  const s = t.slice(0, n).lastIndexOf(`
`) + 1, c = r > n && t[r - 1] === `
` ? r - 1 : r, u = [];
  for (let d = s; d <= c; ) {
    const p = t[d] === "	" ? 1 : t.slice(d).match(/^ */)?.[0].length || 0;
    a ? p && u.push({ from: d, to: d + Math.min(p, i), text: "" }) : u.push({ from: d, to: d, text: l });
    const h = t.indexOf(`
`, d);
    if (h < 0) break;
    d = h + 1;
  }
  return u;
}
function $n(t, n) {
  let r = 0;
  for (const a of n) {
    if (t < a.from) break;
    if (t <= a.to) return a.from + r + a.text.length;
    r += a.text.length - (a.to - a.from);
  }
  return t + r;
}
function zn(t, n = !1) {
  if (!t.isEditable || t.isDestroyed || t.view.composing) return !1;
  const { selection: r } = t.state;
  if (!(r instanceof Ge) || !r.$from.sameParent(r.$to) || r.$from.parent.type.name !== "codeBlock") return !1;
  const a = r.$from.start(), i = Di(r.$from.parent.textContent, r.from - a, r.to - a, n);
  return t.commands.command(({ tr: l }) => {
    for (const s of [...i].reverse()) l.insertText(s.text, a + s.from, a + s.to);
    return l.setSelection(Ge.create(
      l.doc,
      a + $n(r.anchor - a, i),
      a + $n(r.head - a, i)
    )), i.length && l.scrollIntoView(), !0;
  });
}
function Pi(t, n, r) {
  const a = t.slice(0, n).lastIndexOf(`
`) + 1, i = t.slice(a, n), l = i.match(/^[\t ]*/)?.[0] || "";
  return n === r && r === t.length && i && i === l ? { from: a, to: r, text: `
` } : { from: n, to: r, text: `
${l}` };
}
function Ec(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!(n instanceof Ge) || !n.$from.sameParent(n.$to) || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.start(), a = Pi(n.$from.parent.textContent, n.from - r, n.to - r);
  return t.commands.command(({ tr: i }) => (i.insertText(a.text, r + a.from, r + a.to), i.setSelection(Ge.create(i.doc, r + a.from + a.text.length)).scrollIntoView(), !0));
}
function $c(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parentOffset, a = n.$from.parent.textContent.slice(0, r), i = a.slice(a.lastIndexOf(`
`) + 1);
  if (!i || !/^[\t ]+$/.test(i)) return !1;
  const l = i.endsWith("	") ? 1 : Math.min(i.match(/ +$/)?.[0].length || 0, (i.length - 1) % Ti + 1);
  return t.commands.deleteRange({ from: n.from - l, to: n.from });
}
function zc(t, n) {
  const r = t.currentTarget;
  if (r.readOnly || r.disabled || t.nativeEvent.isComposing || t.ctrlKey || t.metaKey || t.altKey) return !1;
  const { value: a, selectionStart: i, selectionEnd: l, selectionDirection: s } = r, c = t.key === "Tab" ? Di(a, i, l, t.shiftKey) : t.key === "Enter" && !t.shiftKey ? [Pi(a, i, l)] : null;
  if (!c) return !1;
  if (t.preventDefault(), !c.length) return !0;
  let u = a;
  for (const b of [...c].reverse()) u = u.slice(0, b.from) + b.text + u.slice(b.to);
  const d = c[0].from, p = c.at(-1).to, h = u.slice(d, u.length - (a.length - p)), f = t.key === "Enter" ? d + c[0].text.length : $n(i, c), m = t.key === "Enter" ? f : $n(l, c);
  return r.setSelectionRange(d, p), document.execCommand?.("insertText", !1, h) || n(u), r.setSelectionRange(f, m, s), requestAnimationFrame(() => {
    document.activeElement === r && r.value === u && r.setSelectionRange(f, m, s);
  }), !0;
}
const Oi = {
  stopEvent: ({ event: t }) => !!(t.target instanceof Element ? t.target : t.target instanceof globalThis.Node ? t.target.parentElement : null)?.closest("[data-nested-editor-boundary]")
}, en = { "(": ")", "[": "]", "{": "}", "<": ">", '"': '"', "'": "'", "`": "`" }, Ic = new Set(Object.values(en));
function Fi(t, n, r) {
  let a = "", i = !1, l = !1;
  const s = /^(python|py|bash|sh|shell|ruby|rb|yaml|yml|r)$/i.test(r);
  for (let c = 0; c < n; c++) {
    const u = t[c], d = t[c + 1];
    if (i) {
      u === `
` && (i = !1);
      continue;
    }
    if (l) {
      u === "*" && d === "/" && (l = !1, c++);
      continue;
    }
    if (a) {
      u === "\\" ? c++ : u === a && (a = "");
      continue;
    }
    u === "/" && d === "/" ? (i = !0, c++) : u === "/" && d === "*" ? (l = !0, c++) : s && u === "#" ? i = !0 : "\"'`".includes(u) && (a = u);
  }
  return { quote: a, comment: i || l };
}
function Ac(t, n, r) {
  const a = t.slice(0, n), i = a.slice(a.lastIndexOf(`
`) + 1);
  return /^(html|xml|vue|svelte|jsx|tsx)$/i.test(r) || /^\s*$/.test(i) || /^\s*#\s*include\s*$/.test(i) ? !0 : /^(c|cpp|c\+\+|java|rust|rs|csharp|cs|typescript|ts)$/i.test(r) && /[\w>:]$/.test(a);
}
function Ri(t, n, r, a, i = "") {
  if (a.length !== 1) return null;
  const l = Math.min(n, r), s = Math.max(n, r), c = Fi(t, l, i);
  if (c.comment) return null;
  const u = a === '"' || a === "'" || a === "`";
  if ((t.slice(0, l).match(/\\+$/)?.[0].length ?? 0) % 2 === 1) return null;
  if (l === s && t[l] === a && Ic.has(a) && (u ? c.quote === a : !c.quote))
    return { from: l, to: s, text: "", anchor: l + 1, head: l + 1 };
  const p = en[a];
  return !p || c.quote || a === "<" && !Ac(t, l, i) || u && a === "'" && /[\p{L}\p{N}_]/u.test(t[l - 1] ?? "") || l === s && t[s] && !/[\s)\]}>;,.:]/.test(t[s]) ? null : { from: l, to: s, text: a + t.slice(l, s) + p, anchor: n + 1, head: r + 1 };
}
function Lc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, a = n.$from.parentOffset, i = r[a - 1];
  return !en[i] || en[i] !== r[a] || !Ri(r.slice(0, a - 1) + r.slice(a + 1), a - 1, a - 1, i, String(n.$from.parent.attrs.language || "")) ? !1 : t.commands.deleteRange({ from: n.from - 1, to: n.from + 1 });
}
function Tc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, a = n.$from.parentOffset;
  if (!"([{".includes(r[a - 1] || " ") || en[r[a - 1]] !== r[a]) return !1;
  const i = Fi(r, a, String(n.$from.parent.attrs.language || ""));
  if (i.quote || i.comment) return !1;
  const l = r.slice(0, a), s = l.slice(l.lastIndexOf(`
`) + 1).match(/^[\t ]*/)?.[0] || "";
  return t.commands.command(({ tr: c }) => (c.insertText(`
` + s + `    
` + s, n.from), c.setSelection(Ge.create(c.doc, n.from + s.length + 5)).scrollIntoView(), !0));
}
function Dc(t) {
  return new an({ props: { handleTextInput(n, r, a, i) {
    if (!t.isEditable || n.composing) return !1;
    const l = n.state.selection;
    if (!(l instanceof Ge) || !l.$from.sameParent(l.$to) || l.$from.parent.type.name !== "codeBlock" || r !== l.from || a !== l.to) return !1;
    const s = l.$from.start(), c = Ri(l.$from.parent.textContent, l.anchor - s, l.head - s, i, String(l.$from.parent.attrs.language || ""));
    if (!c) return !1;
    const u = n.state.tr;
    return c.text && u.insertText(c.text, s + c.from, s + c.to), u.setSelection(Ge.create(u.doc, s + c.anchor, s + c.head)).scrollIntoView(), n.dispatch(u), !0;
  } } });
}
const tn = new ti("codeFence"), Bi = /^[a-zA-Z][a-zA-Z0-9_+#.-]*$/;
function Pc(t) {
  return new Lo({
    find: /^```$/,
    handler: ({ state: n, range: r }) => {
      const a = n.doc.resolve(r.from);
      if (!a.node(-1).canReplaceWith(a.index(-1), a.indexAfter(-1), t)) return null;
      const i = n.tr.delete(r.from, r.to).setBlockType(r.from, r.from, t);
      i.setMeta(tn, i.selection.$from.before());
    }
  });
}
function Oc() {
  return new an({
    key: tn,
    state: {
      init: () => null,
      apply(t, n) {
        const r = t.getMeta(tn);
        if (r !== void 0) return r;
        if (n === null || t.selectionSet && !t.docChanged) return null;
        const a = t.mapping.map(n, -1), i = t.doc.nodeAt(a), { selection: l } = t;
        return i?.type.name !== "codeBlock" || i.attrs.language || !l.empty || l.$from.start() !== a + 1 || l.$from.parentOffset !== i.content.size || i.textContent && !Bi.test(i.textContent) ? null : a;
      }
    }
  });
}
function ga(t) {
  const n = tn.getState(t.state);
  if (n == null || !t.isEditable || t.view.composing) return !1;
  const r = t.state.doc.nodeAt(n);
  return r?.type.name !== "codeBlock" || r.textContent && !Bi.test(r.textContent) ? !1 : t.commands.command(({ tr: a }) => {
    const i = r.textContent || null;
    return a.delete(n + 1, n + r.nodeSize - 1), a.setNodeMarkup(n, void 0, { ...r.attrs, language: i }), a.setSelection(Ge.create(a.doc, n + 1)).setMeta(tn, null), !0;
  });
}
const ya = [
  { value: "flow", label: "流程图", code: `flowchart LR
  A[开始] --> B{理解}
  B --> C[应用]` },
  { value: "sequence", label: "时序图", code: `sequenceDiagram
  participant U as 用户
  participant S as 服务
  U->>S: 请求
  S-->>U: 响应` },
  { value: "state", label: "状态图", code: `stateDiagram-v2
  [*] --> 待办
  待办 --> 进行中
  进行中 --> 完成` }
];
function ji({ code: t }) {
  const n = Ne().replace(/[^a-zA-Z0-9]/g, ""), r = B(0), [a, i] = k(""), [l, s] = k(""), [c, u] = k("");
  return Y(() => {
    const d = () => u(`${document.documentElement.dataset.theme}/${document.documentElement.dataset.product}`);
    d();
    const p = new MutationObserver(d);
    return p.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product"] }), () => p.disconnect();
  }, []), Y(() => {
    const d = ++r.current, p = setTimeout(async () => {
      try {
        const { default: h } = await import("mermaid"), f = getComputedStyle(document.documentElement);
        h.initialize({ startOnLoad: !1, securityLevel: "strict", suppressErrorRendering: !0, theme: "base", themeVariables: { fontFamily: "system-ui, sans-serif", primaryColor: f.getPropertyValue("--fp-primary-soft").trim() || "#fff2e2", primaryTextColor: f.getPropertyValue("--fp-ink").trim() || "#202124", primaryBorderColor: f.getPropertyValue("--fp-line-strong").trim() || "#b9a68e", lineColor: f.getPropertyValue("--fp-muted").trim() || "#757575" } });
        const m = await h.render(`fp-mermaid-${n}-${d}`, t);
        r.current === d && (i(m.svg), s(""));
      } catch {
        r.current === d && s("图表语法有误，请检查连线、括号和节点名称。");
      }
    }, 250);
    return () => {
      clearTimeout(p), r.current++;
    };
  }, [t, n, c]), /* @__PURE__ */ e("div", { className: "fp-mermaid-preview", "aria-label": "图表预览", children: /* @__PURE__ */ e(fe, { children: l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : a ? /* @__PURE__ */ e("div", { dangerouslySetInnerHTML: { __html: a } }) : /* @__PURE__ */ e("p", { role: "status", children: "正在绘制图表…" }) }) });
}
function Fc({ node: t, editor: n, getPos: r, deleteNode: a, selected: i }) {
  const l = String(t.attrs.language).toLowerCase() === "mermaid", [s, c] = k(!1), [u, d] = k(!1), p = B(null), h = B(null), f = B(!1);
  Y(() => {
    s ? p.current?.focus({ preventScroll: !0 }) : f.current && h.current?.focus({ preventScroll: !0 }), f.current = s;
  }, [s]);
  const m = t.textContent, [b, y] = k(m);
  Y(() => {
    y(m);
  }, [m]);
  const w = () => {
    si.getState(n.state)?.undoManager.stopCapturing(), n.view.dispatch(oi(n.state.tr));
  }, v = (x) => {
    const N = r();
    N === void 0 || n.isDestroyed || !n.isEditable || (y(x), n.commands.command(({ tr: C }) => {
      const A = C.doc.nodeAt(N);
      return A ? (C.replaceWith(N + 1, N + A.nodeSize - 1, x ? n.schema.text(x) : []), !0) : !1;
    }));
  }, g = () => {
    const x = r();
    if (x === void 0 || !n.isEditable) return !1;
    const N = n.state.doc.nodeAt(x);
    if (N?.type.name !== "codeBlock") return !1;
    const { $from: C, $to: A } = n.state.selection;
    return (!C.sameParent(A) || C.start() !== x + 1) && n.commands.setTextSelection({ from: x + 1, to: x + N.nodeSize - 1 }), n.commands.focus(void 0, { scrollIntoView: !1 }), !0;
  };
  return /* @__PURE__ */ o(It, { className: l ? "fp-mermaid-node" : "fp-code-node", "data-selected": i || void 0, "data-note-object": l ? "diagram" : void 0, children: [
    l && /* @__PURE__ */ e("pre", { hidden: !0, "aria-hidden": "true", children: /* @__PURE__ */ e(ea, {}) }),
    l ? /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", children: [
      /* @__PURE__ */ o("header", { className: "fp-code-header", children: [
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e(Sr, { size: 14 }),
          "Mermaid 图表"
        ] }),
        /* @__PURE__ */ o("div", { children: [
          n.isEditable && /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ o("button", { ref: h, type: "button", "aria-label": s ? "完成图表编辑" : "编辑图表", "aria-expanded": s, onClick: () => {
              w(), c((x) => !x);
            }, children: [
              s ? /* @__PURE__ */ e(Re, { size: 14 }) : /* @__PURE__ */ e(Fn, { size: 14 }),
              s ? "完成" : "编辑"
            ] }),
            /* @__PURE__ */ o("button", { type: "button", "aria-label": "删除图表", onClick: () => {
              w(), a(), n.commands.focus();
            }, children: [
              /* @__PURE__ */ e(Bt, { size: 14 }),
              "删除"
            ] })
          ] }),
          /* @__PURE__ */ e("button", { type: "button", "aria-pressed": u, onClick: () => d((x) => !x), children: "源码" })
        ] })
      ] }),
      /* @__PURE__ */ e(Oe, { isOpen: s, children: /* @__PURE__ */ o("div", { className: "fp-mermaid-source", children: [
        /* @__PURE__ */ e(we, { label: "图表模板", value: "", placeholder: "插入模板", options: ya, onChange: (x) => {
          const N = ya.find((C) => C.value === x);
          N && v(N.code);
        } }),
        /* @__PURE__ */ e("textarea", { ref: p, readOnly: !n.isEditable, "aria-label": "Mermaid 源码", value: b, spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", onChange: (x) => v(x.target.value), onKeyDown: (x) => {
          x.stopPropagation(), !x.nativeEvent.isComposing && (zc(x, v) || (x.key === "Escape" || x.key === "Enter" && (x.ctrlKey || x.metaKey)) && (x.preventDefault(), c(!1)));
        } })
      ] }) }),
      /* @__PURE__ */ e(Oe, { isOpen: !s && u, children: /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: m }) }) }),
      /* @__PURE__ */ e(ji, { code: m })
    ] }) : /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", className: "fp-code-header", children: [
        /* @__PURE__ */ e(we, { label: "代码块语言", value: t.attrs.language || "", disabled: !n.isEditable, options: [{ value: "", label: "纯文本" }, ...Wn], onChange: (x) => {
          const N = r();
          N !== void 0 && n.commands.command(({ tr: C }) => (C.setNodeMarkup(N, void 0, { ...t.attrs, language: x || null }), !0));
        } }),
        n.isEditable && /* @__PURE__ */ o("div", { className: "fp-code-actions", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩进", "data-fp-tooltip": "缩进 · Tab", "aria-keyshortcuts": "Tab", onMouseDown: (x) => x.preventDefault(), onClick: () => {
            g() && zn(n);
          }, children: /* @__PURE__ */ e(Il, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "减少缩进", "data-fp-tooltip": "减少缩进 · Shift+Tab", "aria-keyshortcuts": "Shift+Tab", onMouseDown: (x) => x.preventDefault(), onClick: () => {
            g() && zn(n, !0);
          }, children: /* @__PURE__ */ e(Al, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "在代码块下方继续", "data-fp-tooltip": "在代码块下方继续 · Ctrl/⌘+Enter", "aria-keyshortcuts": "Control+Enter Meta+Enter", onMouseDown: (x) => x.preventDefault(), onClick: () => {
            g() && n.commands.exitCode();
          }, children: /* @__PURE__ */ e(Ka, { size: 16 }) })
        ] })
      ] }),
      /* @__PURE__ */ e("pre", { spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", children: /* @__PURE__ */ e("code", { children: /* @__PURE__ */ e(ea, { style: { whiteSpace: "pre" } }) }) })
    ] })
  ] });
}
const Rc = li.extend({
  priority: 110,
  addNodeView() {
    return _t(Fc, Oi);
  },
  addInputRules() {
    return [Pc(this.type), ...this.parent?.() || []];
  },
  addProseMirrorPlugins() {
    return [...this.parent?.() || [], Oc(), Dc(this.editor)];
  },
  addKeyboardShortcuts() {
    const t = this.parent?.() || {};
    return {
      ...t,
      Tab: () => zn(this.editor),
      "Shift-Tab": () => zn(this.editor, !0),
      Space: () => ga(this.editor),
      Enter: (n) => this.editor.isEditable && !this.editor.view.composing && (ga(this.editor) || Tc(this.editor) || t.Enter?.(n) || Ec(this.editor)),
      Backspace: (n) => this.editor.isEditable && !this.editor.view.composing && (Lc(this.editor) || $c(this.editor) || t.Backspace?.(n) || !1),
      "Mod-Enter": () => this.editor.isEditable && this.editor.isActive(this.name) && this.editor.commands.exitCode(),
      Escape: () => {
        const { editor: n } = this;
        if (!n.isEditable || n.state.selection.$from.parent.type.name !== this.name) return !1;
        const r = n.view.nodeDOM(n.state.selection.$from.before()), a = r instanceof Element ? r.querySelector(".fp-code-header button:not(:disabled)") : null;
        return a ? (a.focus({ preventScroll: !0 }), !0) : !1;
      }
    };
  }
}).configure({ lowlight: Li }), Bc = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
];
new Set(Bc);
const jc = {
  animation: "learninganimation",
  map: "historymap",
  "cause-effect": "causeeffect",
  "learning-animation": "learninganimation",
  intuition: "insight",
  technique: "tip",
  comparison: "compare",
  summary: "keypoint",
  question: "note",
  task: "note"
};
function qc(t) {
  return jc[t] ?? t;
}
const Kc = {
  definition: { label: "定义", cls: "callout-definition" },
  theorem: { label: "定理", cls: "callout-theorem" },
  example: { label: "例", cls: "callout-example" },
  insight: { label: "直觉", cls: "callout-insight" },
  pitfall: { label: "易错点", cls: "callout-pitfall" },
  note: { label: "注", cls: "callout-note" },
  tip: { label: "提示", cls: "callout-tip" },
  memory: { label: "记忆卡", cls: "callout-memory" }
}, In = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function Uc(t) {
  const n = t.toLowerCase();
  return n in In ? In[n] ?? "note" : "note";
}
function Hc(t) {
  const n = t.toLowerCase();
  return n in In && In[n] === null;
}
function _c({ label: t = "核心要点", children: n }) {
  return /* @__PURE__ */ o("aside", { className: "fp-keypoint", children: [
    /* @__PURE__ */ e("span", { className: "fp-keypoint-label", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-keypoint-body", children: n })
  ] });
}
function Wc({
  term: t,
  children: n,
  defaultOpen: r = !1
}) {
  const [a, i] = k(r), l = Ne();
  return /* @__PURE__ */ o("section", { className: "fp-concept", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-concept-head",
        "aria-expanded": a,
        "aria-controls": l,
        onClick: () => i((s) => !s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-concept-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(ht, { size: 16 }) }),
          /* @__PURE__ */ e("span", { className: "fp-concept-term", children: t }),
          /* @__PURE__ */ e("span", { className: "fp-concept-hint", children: a ? "点击收起" : "点击展开" }),
          /* @__PURE__ */ e(Ie, { size: 16, className: "fp-concept-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: l, className: "fp-concept-body", inert: !a, "aria-hidden": !a, "data-open": a || void 0, children: /* @__PURE__ */ e("div", { className: "fp-concept-clip", children: /* @__PURE__ */ e("div", { className: "fp-concept-inner", children: n }) }) })
  ] });
}
function Vc({ title: t, children: n }) {
  return /* @__PURE__ */ o("section", { className: "fp-compare", children: [
    t && /* @__PURE__ */ e("header", { className: "fp-compare-title", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-compare-body", children: n })
  ] });
}
const Xc = {
  cause: "因",
  effect: "影响",
  result: "结果"
};
function Yc(t) {
  return t.split(`
`).map((n) => n.trim().replace(/^[-*]\s*/, "")).filter(Boolean).map((n) => /^(因|原因)[：:]/.test(n) ? { kind: "cause", text: n.replace(/^(因|原因)[：:]/, "").trim() } : /^(果|结果)[：:]/.test(n) ? { kind: "result", text: n.replace(/^(果|结果)[：:]/, "").trim() } : /^(影响|后果)[：:]/.test(n) ? { kind: "effect", text: n.replace(/^(影响|后果)[：:]/, "").trim() } : { kind: void 0, text: n });
}
function Gc({ items: t, text: n, children: r }) {
  const a = t ?? (n ? Yc(n) : []);
  return /* @__PURE__ */ o("div", { className: "fp-cause-effect", children: [
    a.map((i, l) => {
      const s = i.kind ?? (l === 0 ? "cause" : "effect");
      return /* @__PURE__ */ o("div", { className: "fp-cause-node", "data-kind": s, children: [
        /* @__PURE__ */ e("span", { className: "fp-cause-label", children: Xc[s] }),
        /* @__PURE__ */ e("div", { className: "fp-cause-text", children: i.text }),
        l < a.length - 1 && /* @__PURE__ */ e(Ua, { size: 16, className: "fp-cause-arrow", "aria-hidden": "true" })
      ] }, l);
    }),
    r
  ] });
}
function Jc({
  label: t = "推导过程",
  children: n,
  defaultOpen: r = !1
}) {
  const [a, i] = k(r), l = Ne();
  return /* @__PURE__ */ o("section", { className: "fp-derivation", "data-open": a || void 0, children: [
    /* @__PURE__ */ o("button", { type: "button", className: "fp-derivation-trigger", "aria-expanded": a, "aria-controls": l, onClick: () => i((s) => !s), children: [
      /* @__PURE__ */ e(Ie, { size: 15, className: "fp-derivation-chevron" }),
      t
    ] }),
    /* @__PURE__ */ e(Oe, { isOpen: a, children: /* @__PURE__ */ e("div", { id: l, className: "fp-derivation-body", children: n }) })
  ] });
}
function gr({ src: t, alt: n, title: r, onError: a, ...i }) {
  const [l, s] = k(void 0), c = l === t || !t ? /* @__PURE__ */ o("span", { className: "fp-content-image-error", role: "img", "aria-label": n || "图片", children: [
    /* @__PURE__ */ e(Ll, { size: 22, "aria-hidden": "true" }),
    /* @__PURE__ */ e("span", { children: n || "图片加载失败" })
  ] }) : /* @__PURE__ */ e(
    "img",
    {
      src: t,
      alt: n || "",
      title: r,
      loading: "lazy",
      decoding: "async",
      ...i,
      onError: (u) => {
        s(t), a?.(u);
      }
    }
  );
  return r ? /* @__PURE__ */ o("figure", { className: "fp-content-image", children: [
    c,
    /* @__PURE__ */ e("figcaption", { children: r })
  ] }) : /* @__PURE__ */ e("span", { className: "fp-content-image-plain", children: c });
}
function va({
  title: t,
  date: n,
  children: r,
  defaultOpen: a = !1,
  fields: i = []
}) {
  const [l, s] = k(a);
  return /* @__PURE__ */ o("article", { className: "fp-event-card", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": l,
        onClick: () => s((c) => !c),
        children: [
          /* @__PURE__ */ e(
            Ie,
            {
              size: 16,
              style: { transform: l ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: t }),
            n && /* @__PURE__ */ e("time", { children: n })
          ] })
        ]
      }
    ),
    !!i.length && /* @__PURE__ */ e("dl", { className: "fp-event-fields", children: i.map((c) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: c.label }),
      /* @__PURE__ */ e("dd", { children: c.value })
    ] }, c.label)) }),
    /* @__PURE__ */ e(Oe, { isOpen: l, children: /* @__PURE__ */ e("div", { className: "fp-reading-body", children: r }) })
  ] });
}
function Qc({
  src: t,
  alt: n,
  caption: r,
  credit: a,
  onOpen: i
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-reading-figure", children: [
    i ? /* @__PURE__ */ e("button", { type: "button", "aria-label": `查看${n}`, onClick: i, children: /* @__PURE__ */ e(gr, { src: t, alt: n }) }) : /* @__PURE__ */ e(gr, { src: t, alt: n }),
    (r || a) && /* @__PURE__ */ o("figcaption", { children: [
      r,
      a && /* @__PURE__ */ e("small", { children: a })
    ] })
  ] });
}
function ph({
  question: t,
  answer: n,
  revealed: r,
  onReveal: a,
  onGrade: i
}) {
  return /* @__PURE__ */ o("article", { className: "fp-memory-card", children: [
    /* @__PURE__ */ e("div", { children: t }),
    /* @__PURE__ */ e(Oe, { isOpen: r, children: /* @__PURE__ */ e("div", { className: "fp-memory-answer", children: n }) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r ? i && ["again", "hard", "good", "easy"].map((l, s) => /* @__PURE__ */ e("button", { type: "button", onClick: () => i(l), children: ["再学一次", "有些困难", "已经掌握", "很轻松"][s] }, l)) : /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "查看答案" }) })
  ] });
}
function hh({
  events: t,
  selectedId: n,
  onSelect: r
}) {
  return /* @__PURE__ */ e("section", { className: "fp-history-map", "aria-label": "历史脉络", children: /* @__PURE__ */ e("ol", { children: t.map((a) => /* @__PURE__ */ o("li", { "data-active": n === a.id || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": n === a.id,
        onClick: () => r(a.id),
        children: [
          /* @__PURE__ */ e("time", { children: a.date }),
          /* @__PURE__ */ e("strong", { children: a.title })
        ]
      }
    ),
    /* @__PURE__ */ e(Oe, { isOpen: n === a.id, children: /* @__PURE__ */ o("div", { className: "fp-reading-body", children: [
      a.description,
      a.relatedIds?.map((i) => {
        const l = t.find((s) => s.id === i);
        return l ? /* @__PURE__ */ o("button", { type: "button", onClick: () => r(i), children: [
          "关联：",
          l.title
        ] }, i) : null;
      })
    ] }) })
  ] }, a.id)) }) });
}
function Zc({
  title: t,
  children: n,
  sourceUrl: r,
  caption: a
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-learning-animation", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      r && /* @__PURE__ */ o("a", { href: r, download: !0, children: [
        "下载源文件",
        /* @__PURE__ */ e(Rt, { size: 13 })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { children: n }),
    a && /* @__PURE__ */ e("figcaption", { children: a })
  ] });
}
function fh({
  title: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-note-link", onClick: r, children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e(Rt, { size: 15 })
  ] });
}
function mh({
  leftLabel: t,
  rightLabel: n,
  leftCount: r,
  rightCount: a,
  intersection: i,
  total: l
}) {
  return /* @__PURE__ */ e(
    "figure",
    {
      className: "fp-venn",
      "aria-label": `${t} ${r}，${n} ${a}，交集 ${i}${l === void 0 ? "" : `，总数 ${l}`}`,
      children: /* @__PURE__ */ o("svg", { viewBox: "0 0 360 210", role: "img", children: [
        /* @__PURE__ */ e("title", { children: "集合关系" }),
        /* @__PURE__ */ e(
          "rect",
          {
            x: "8",
            y: "8",
            width: "344",
            height: "194",
            rx: "8",
            fill: "none",
            stroke: "var(--fp-line)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "139",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "221",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            fillOpacity: ".65",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e("text", { x: "112", y: "70", textAnchor: "middle", children: t }),
        /* @__PURE__ */ e("text", { x: "249", y: "70", textAnchor: "middle", children: n }),
        /* @__PURE__ */ e("text", { x: "112", y: "120", textAnchor: "middle", children: Math.max(0, r - i) }),
        /* @__PURE__ */ e("text", { x: "180", y: "120", textAnchor: "middle", children: i }),
        /* @__PURE__ */ e("text", { x: "249", y: "120", textAnchor: "middle", children: Math.max(0, a - i) }),
        l !== void 0 && /* @__PURE__ */ e("text", { x: "325", y: "184", textAnchor: "end", children: Math.max(0, l - r - a + i) })
      ] })
    }
  );
}
function ed({
  children: t,
  mode: n = "cloze"
}) {
  const [r, a] = k([]), i = (l, s = "root") => Ml.map(l, (c, u) => {
    const d = `${s}.${u}`;
    if (!Oa(c)) return c;
    const p = c;
    return n === "cloze" && p.type === "strong" || n !== "cloze" && p.type === "li" ? /* @__PURE__ */ e("span", { className: "fp-recall-item", children: /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-expanded": r.includes(d),
        onClick: () => a(
          (f) => f.includes(d) ? f.filter((m) => m !== d) : [...f, d]
        ),
        children: r.includes(d) ? p.props.children : "点击回忆"
      }
    ) }) : Fa(p, {}, i(p.props.children, d));
  });
  return /* @__PURE__ */ e("div", { className: "fp-recall-content", children: i(t) });
}
function td({
  title: t = "历史地图",
  points: n,
  caption: r,
  onSelect: a
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-location-map", children: [
    /* @__PURE__ */ e("figcaption", { children: t }),
    /* @__PURE__ */ e("div", { children: n.map((i, l) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        style: {
          left: `${Math.max(0, Math.min(100, i.x))}%`,
          top: `${Math.max(0, Math.min(100, i.y))}%`
        },
        onClick: () => a?.(i),
        children: [
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "●" }),
          i.name
        ]
      },
      l
    )) }),
    r && /* @__PURE__ */ e("p", { children: r })
  ] });
}
function nd({
  title: t = "时间轴",
  children: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-reading-timeline", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    n
  ] });
}
function rd({
  title: t,
  kind: n,
  collapsed: r,
  children: a
}) {
  const [i, l] = k(!r);
  return /* @__PURE__ */ o("aside", { className: "fp-reader-callout", "data-kind": n, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-reader-callout-toggle",
        "aria-expanded": i,
        onClick: () => l(!i),
        children: [
          /* @__PURE__ */ e(
            Ft,
            {
              size: 16,
              style: { transform: i ? void 0 : "rotate(-90deg)" }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t })
        ]
      }
    ),
    /* @__PURE__ */ e(Oe, { isOpen: i, children: a })
  ] });
}
function ad() {
  return (t) => {
    Zt(t, (n) => {
      const r = n;
      if (!["containerDirective", "leafDirective", "textDirective"].includes(
        r.type
      ))
        return;
      const a = { ...r.attributes }, i = (l) => (l || []).map(
        (s) => s.value || i(s.children)
      ).join(`
`);
      r.name === "canvas" && r.children && (a.plots = JSON.stringify(
        r.children.filter((l) => l.name === "plot").map((l) => l.attributes || {})
      )), r.data = {
        ...r.data,
        hName: "fp-directive",
        hProperties: {
          "data-name": r.name,
          "data-attributes": JSON.stringify({
            ...a,
            __source: i(r.children)
          })
        }
      };
    });
  };
}
const id = (t) => /^\s*(?:javascript|vbscript|data):/i.test(t) ? "" : t;
function bt({
  markdown: t,
  resolveResourceUrl: n,
  renderDirective: r,
  onOpenResource: a,
  onOpenLink: i,
  components: l,
  remarkPlugins: s,
  rehypePlugins: c
}) {
  const u = (h) => id(n?.(h) ?? h), d = ({
    name: h,
    attributes: f,
    children: m,
    source: b
  }) => {
    const y = qc(h), w = f.title || f.label || Kc[y]?.label || "学习内容";
    if (r) {
      const v = r({
        name: y,
        attributes: f,
        children: m,
        source: b
      });
      if (v !== void 0) return v;
    }
    if (y === "interactive" && f.id)
      return /* @__PURE__ */ e(Ci, { id: f.id });
    if (["plot", "functionplot"].includes(y))
      return /* @__PURE__ */ e(
        br,
        {
          block: {
            kind: "plot",
            title: f.title || f.label,
            fn: f.fn || b || "x",
            attrs: Ai(f)
          }
        }
      );
    if (["canvas", "svgcanvas", "svg"].includes(y)) {
      let v = [];
      try {
        v = JSON.parse(f.plots || "[]");
      } catch {
      }
      return /* @__PURE__ */ e(
        br,
        {
          block: v.length ? {
            kind: "multi-plot",
            title: f.title,
            attrs: Cc(f),
            plots: v
          } : Sc(f, b || "")
        }
      );
    }
    return ["concept", "conceptcard"].includes(y) ? /* @__PURE__ */ e(Wc, { term: f.term || w, children: m }) : y === "derivation" ? /* @__PURE__ */ e(Jc, { label: w, children: m }) : y === "keypoint" ? /* @__PURE__ */ e(_c, { label: w, children: m }) : ["compare", "comparetable"].includes(y) ? /* @__PURE__ */ e(Vc, { title: w, children: m }) : y === "causeeffect" ? /* @__PURE__ */ e(Gc, { children: m }) : ["event", "eventcard"].includes(y) ? /* @__PURE__ */ e(
      va,
      {
        title: w,
        date: f.date || f.year,
        fields: [
          ["location", "地点"],
          ["people", "人物"],
          ["result", "结果"],
          ["impact", "影响"]
        ].filter(([v]) => !!f[v]).map(([v, g]) => ({ label: g, value: f[v] })),
        children: m
      }
    ) : ["figure", "figuremedia"].includes(y) && f.src ? /* @__PURE__ */ e(
      Qc,
      {
        src: u(f.src),
        alt: f.alt || w,
        caption: f.caption,
        credit: f.credit
      }
    ) : ["memory", "memorycard"].includes(y) ? /* @__PURE__ */ e(va, { title: w, children: /* @__PURE__ */ e(ed, { mode: f.mode || "checklist", children: m }) }) : y === "timeline" ? /* @__PURE__ */ e(
      nd,
      {
        title: f.period ? `时间轴 · ${f.period}` : w,
        children: m
      }
    ) : y === "historymap" ? /* @__PURE__ */ e(
      td,
      {
        title: w,
        caption: f.caption,
        points: (f.points || "").split(",").filter(Boolean).map((v) => {
          const [g, x, N] = v.split(":");
          return {
            name: g,
            x: Number.isFinite(Number(x)) ? Number(x) : 50,
            y: Number.isFinite(Number(N)) ? Number(N) : 50
          };
        })
      }
    ) : ["learninganimation", "learning-animation"].includes(y) ? /* @__PURE__ */ e(
      Zc,
      {
        title: w,
        sourceUrl: f.source ? u(f.source) : void 0,
        caption: f.caption,
        children: f.src ? /* @__PURE__ */ e(Jt, { src: u(f.src), title: w }) : m
      }
    ) : y === "mediaembed" && f.src ? /audio/i.test(f.type || "") ? /* @__PURE__ */ e(xn, { src: u(f.src), title: w }) : /* @__PURE__ */ e(Jt, { src: u(f.src), title: w }) : y === "video" && f.src ? /* @__PURE__ */ e(Jt, { src: u(f.src), title: w }) : y === "audio" && f.src ? /* @__PURE__ */ e(xn, { src: u(f.src), title: w }) : [
      "interactive",
      "plot",
      "functionplot",
      "canvas",
      "svgcanvas",
      "svg",
      "attachment",
      "noteattachment",
      "learning-animation"
    ].includes(y) && a ? /* @__PURE__ */ o("section", { className: "fp-reader-resource", children: [
      /* @__PURE__ */ e("strong", { children: w }),
      m,
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => a(f, y),
          children: "打开内容"
        }
      )
    ] }) : /* @__PURE__ */ e(
      rd,
      {
        title: w,
        kind: y === "callout" ? f.kind || "note" : y,
        collapsed: f.collapsed === "true",
        children: m
      }
    );
  };
  return /* @__PURE__ */ e("article", { className: "fp-markdown-content", children: /* @__PURE__ */ e(
    ni,
    {
      remarkPlugins: s || [
        To,
        ri,
        Do,
        Cs,
        ad
      ],
      rehypePlugins: c || [
        Po,
        Rs,
        [Oo, Fs],
        xs,
        [
          ai,
          { throwOnError: !1, strict: !1, macros: xi }
        ],
        Bs
      ],
      components: { ...{
        "fp-directive": ({
          node: h,
          children: f
        }) => {
          const m = h?.properties || {};
          let b = {};
          try {
            b = JSON.parse(
              String(
                m["data-attributes"] || m.dataAttributes || "{}"
              )
            );
          } catch {
          }
          const y = b.__source;
          return delete b.__source, d({
            name: String(m["data-name"] || m.dataName || "note"),
            attributes: b,
            children: f,
            source: y
          });
        },
        img: ({ src: h, alt: f }) => u(h || "") ? /* @__PURE__ */ e(gr, { src: u(h || ""), alt: f || "" }) : /* @__PURE__ */ e("span", { children: f || "图片暂时无法显示。" }),
        a: ({ href: h, children: f }) => /* @__PURE__ */ e(
          "a",
          {
            href: h,
            onClick: (m) => {
              h && i && !m.ctrlKey && !m.metaKey && !m.shiftKey && (m.preventDefault(), i(h));
            },
            children: f
          }
        ),
        pre: ({ children: h }) => /* @__PURE__ */ e("div", { className: "fp-reader-code", children: h }),
        code: ({
          className: h,
          children: f
        }) => h?.includes("language-mermaid") ? /* @__PURE__ */ e(ji, { code: String(f).trimEnd() }) : /* @__PURE__ */ e("code", { className: h, children: f })
      }, ...l },
      children: Os(t)
    }
  ) });
}
function yr(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const { state: r } = t, a = r.selection.$from.index(0), i = [];
  r.doc.forEach((p, h) => i.push(h));
  const l = a + (n === "up" ? -1 : 1);
  if (l < 0 || l >= r.doc.childCount) return !1;
  const s = r.doc.child(a), c = i[a], u = r.doc.child(l), d = n === "up" ? i[l] : i[l] + u.nodeSize - s.nodeSize;
  return t.commands.command(({ tr: p }) => (p.delete(c, c + s.nodeSize), p.insert(d, s), p.setSelection(
    Nn.near(
      p.doc.resolve(Math.min(p.doc.content.size, d + 1))
    )
  ), !0));
}
function ld(t) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const n = t.state.selection.$from.index(0);
  let r = 0;
  for (let a = 0; a < n; a++)
    r += t.state.doc.child(a).nodeSize;
  return t.commands.deleteRange({
    from: r,
    to: r + t.state.doc.child(n).nodeSize
  });
}
const od = Lr.create({
  name: "blockDragHandles",
  addProseMirrorPlugins() {
    const t = this.editor;
    return [
      new an({
        props: {
          decorations(n) {
            if (!t.isEditable) return ur.empty;
            const r = [];
            return n.doc.forEach((a, i) => {
              Yt.isSelectable(a) && r.push(
                ci.widget(
                  i,
                  (l, s) => {
                    const c = document.createElement("span");
                    c.className = "fp-block-handle", c.contentEditable = "false";
                    const u = document.createElement("button");
                    return u.type = "button", u.draggable = !0, u.tabIndex = 0, u.title = "拖动段落", u.setAttribute("aria-label", "拖动段落"), u.textContent = "⠿", u.addEventListener("dragstart", (d) => {
                      const p = s();
                      if (p === void 0 || !d.dataTransfer) return;
                      d.stopPropagation();
                      const h = Yt.create(
                        l.state.doc,
                        p
                      );
                      l.dispatch(l.state.tr.setSelection(h));
                      const f = h.content(), m = document.createElement("div");
                      m.append(
                        qo.fromSchema(
                          l.state.schema
                        ).serializeFragment(f.content)
                      ), d.dataTransfer.clearData(), d.dataTransfer.setData(
                        "text/html",
                        m.innerHTML
                      ), d.dataTransfer.setData(
                        "text/plain",
                        h.node.textContent
                      ), d.dataTransfer.effectAllowed = "copyMove", l.dragging = {
                        slice: f,
                        move: !d.ctrlKey && !d.altKey
                      };
                    }), u.addEventListener("keydown", (d) => {
                      if (!d.altKey || !["ArrowUp", "ArrowDown"].includes(d.key))
                        return;
                      const p = s();
                      p !== void 0 && (d.preventDefault(), d.stopPropagation(), t.commands.setTextSelection(
                        Math.min(p + 1, l.state.doc.content.size)
                      ), yr(
                        t,
                        d.key === "ArrowUp" ? "up" : "down"
                      ));
                    }), u.addEventListener("mousedown", (d) => {
                      const p = s();
                      p === void 0 || d.button !== 0 || (d.stopPropagation(), l.dispatch(
                        l.state.tr.setSelection(
                          Yt.create(l.state.doc, p)
                        )
                      ), l.focus());
                    }), c.append(u), c;
                  },
                  { side: -1, key: `block-${i}` }
                )
              );
            }), ur.create(n.doc, r);
          }
        }
      })
    ];
  }
});
function qi(t) {
  return t.chain().focus().insertContent({ type: "codeBlock", attrs: { language: "mermaid" }, content: [{ type: "text", text: `flowchart LR
  A[开始] --> B[理解] --> C[应用]` }] }).run();
}
function nn(...t) {
  const n = t.join(" "), r = _o(n, { toneType: "none", type: "array" });
  return `${n} ${r.join("")} ${r.map((a) => a[0]).join("")}`.toLowerCase();
}
const sd = [
  ["text", "文本", "普通段落", "paragraph wenben wb"],
  ["h1", "一级标题", "大标题", "heading title yijibiaoti yjbt"],
  ["h2", "二级标题", "章节标题", "heading erjibiaoti ejbt"],
  ["h3", "三级标题", "小节标题", "heading sanjibiaoti sjbt"],
  ["h4", "四级标题", "细分内容", "heading sijibiaoti sjbt"],
  ["h5", "五级标题", "细分内容", "heading wujibiaoti wjbt"],
  ["h6", "六级标题", "细分内容", "heading liujibiaoti ljbt"],
  ["bullet", "无序列表", "项目列表", "list unordered wuxuliebiao wxlb"],
  ["ordered", "有序列表", "编号列表", "list numbered youxuliebiao yxlb"],
  ["quote", "引用", "引用段落", "blockquote yinyong yy"],
  ["code", "代码块", "代码内容", "codeblock daima dm dmk"],
  ["divider", "分隔线", "划分内容", "horizontal rule fengexian fgx"],
  ["table", "表格", "3 × 3", "biaoge bg"],
  ["inlineMath", "行内公式", "在段落中输入公式", "formula equation gongshi gs latex hangneigongshi hngs"],
  ["math", "独立公式", "独立成行的公式", "blockmath equation duligongshi dlgs"],
  ["card", "卡片", "说明与重点", "callout kapian kp"],
  ["mermaid", "Mermaid 图表", "流程图与时序图", "diagram flowchart liuchengtu lct tuxing tx"],
  ["interactive", "交互实验", "插入可探索的实验", "experiment lab jiaohushiyan jhsy hudong hd"],
  ["attachment", "附件", "图片、视频或 PDF", "file image pdf audio upload 图片 音频 文件 上传 fujian fj tupian tp"],
  ["video", "视频", "边看边记", "movie shipin sp"]
], cd = { javascript: "js node nodejs", typescript: "ts", python: "py", bash: "sh shell terminal 终端", cpp: "c++ cc cxx", csharp: "c# cs", rust: "rs", yaml: "yml", markdown: "md" }, Ki = [
  ["definition", "定义", "明确概念", "概念定义 dy"],
  ["theorem", "定理", "记录条件与结论", "定律 dl"],
  ["example", "例题", "题目与解答", "例子 示例 lt"],
  ["tip", "技巧", "记录解题方法", "提示 jq"],
  ["pitfall", "易错点", "记录常见错误", "warning 注意 ycd"],
  ["memory", "记忆卡", "整理记忆要点", "记忆 flashcard jyk"],
  ["derivation", "推导", "分步说明推导", "推导过程 td"],
  ["compare", "对比", "比较概念与方法", "比较 comparison db"],
  ["keypoint", "核心要点", "突出重要内容", "重点 key hxyd"],
  ["concept", "概念", "整理概念边界", "术语 gn"],
  ["insight", "直觉", "解释直观理解", "理解 intuition zj"],
  ["note", "说明", "补充说明", "备注 callout sm"],
  ["cause-effect", "因果", "梳理原因与结果", "因果关系 cause effect yg"]
].map(([t, n, r, a]) => ["card:" + t, n + "卡片", r, t + " " + a]), Ui = [
  ...sd,
  ...Wn.filter((t) => t.value !== "mermaid").map((t) => [
    "code:" + t.value,
    t.label + " 代码块",
    "输入 " + t.label + " 代码",
    t.value + " " + (cd[t.value] || "") + " code 代码"
  ]),
  ["code:plaintext", "纯文本代码块", "按原样记录文本", "text txt plaintext 纯文本"],
  ...Ki
], dd = new Map(Ui.map((t) => [t[0], nn(...t)]));
function ud(t) {
  const n = t.trim().replace(/^\//, "").toLowerCase(), r = vr(n);
  if (r) return [[`table:${r.rows}x${r.cols}`, `${r.rows} × ${r.cols} 表格`, `${r.rows} 行 × ${r.cols} 列`, n]];
  const a = n.split(/\s+/), i = Ui.filter((d) => a.every((p) => dd.get(d[0]).includes(p))), l = (d) => [d[0], d[0].split(":").at(-1), ...d[3].toLowerCase().split(/\s+/)].includes(n), s = n ? i.filter(l) : [], c = s.length ? s : i, u = ki();
  return c.sort((d, p) => Number(l(p)) - Number(l(d)) || (u[p[0]] || 0) - (u[d[0]] || 0));
}
function wa(t) {
  return t === "code:plaintext" ? null : Wn.find((n) => t === "code:" + n.value)?.value;
}
function pn(t) {
  return Ki.find((n) => n[0] === t)?.[0].slice(5);
}
function vr(t) {
  const n = t.trim().toLowerCase().replace(/^\//, "").match(/^(?:bg|table:?)([1-9]\d?)[x*×]([1-9]\d?)$/);
  if (!n) return;
  const r = Number(n[1]), a = Number(n[2]);
  return r <= 20 && a <= 20 ? { rows: r, cols: a } : void 0;
}
function gt({
  children: t,
  items: n,
  label: r = "快捷操作",
  disabled: a,
  tabIndex: i = 0,
  onOpen: l
}) {
  const s = B(null), c = B(null), u = B(null), [d, p] = k(null), [h, f] = k([]), m = Ne(), b = jt(s, !!d), y = (g = !0) => {
    p(null), f([]), g && u.current?.focus({ preventScroll: !0 });
  }, w = (g, x) => {
    u.current = document.activeElement, f([]), p({ x: g, y: x });
  };
  Ce(() => {
    if (!d || !c.current) return;
    const g = c.current.getBoundingClientRect();
    c.current.style.left = `${Math.max(8, Math.min(d.x, window.innerWidth - g.width - 8))}px`, c.current.style.top = `${Math.max(8, Math.min(d.y, window.innerHeight - g.height - 8))}px`, c.current.querySelector('[role="menuitem"]:not(:disabled)')?.focus({ preventScroll: !0 });
  }, [d, h]), Y(() => {
    if (!d) return;
    const g = (C) => {
      c.current?.contains(C.target) || y(!1);
    }, x = (C) => {
      C.key === "Escape" && (C.preventDefault(), y());
    }, N = () => y(!1);
    return document.addEventListener("pointerdown", g, !0), document.addEventListener("keydown", x, !0), window.addEventListener("resize", N), window.addEventListener("blur", N), window.addEventListener("scroll", g, !0), () => {
      document.removeEventListener("pointerdown", g, !0), document.removeEventListener("keydown", x, !0), window.removeEventListener("resize", N), window.removeEventListener("blur", N), window.removeEventListener("scroll", g, !0);
    };
  }, [d]);
  let v = typeof n == "function" ? n() : n;
  for (const g of h)
    v = v.find((x) => x.id === g)?.children || [];
  return /* @__PURE__ */ o(
    "div",
    {
      ref: s,
      className: "fp-context-host",
      tabIndex: i,
      onContextMenu: (g) => {
        a || l?.(g) === !1 || (g.preventDefault(), g.stopPropagation(), w(g.clientX, g.clientY));
      },
      onKeyDown: (g) => {
        if (!a && (g.key === "ContextMenu" || g.shiftKey && g.key === "F10")) {
          if (l?.(g) === !1) return;
          g.preventDefault(), g.stopPropagation();
          const x = s.current.getBoundingClientRect();
          w(x.left + 16, x.top + 16);
        }
      },
      children: [
        t,
        d && Te(
          /* @__PURE__ */ o(
            "div",
            {
              ref: c,
              "data-fp-overlay": "",
              id: m,
              role: "menu",
              "aria-label": r,
              className: "fp-popup-panel fp-popup-menu fp-context-menu",
              style: {
                ...b,
                position: "fixed",
                left: d.x,
                top: d.y,
                maxHeight: "calc(100vh - 16px)",
                overflowY: "auto"
              },
              onContextMenu: (g) => g.preventDefault(),
              onKeyDown: (g) => {
                const x = Array.from(
                  c.current?.querySelectorAll(
                    '[role="menuitem"]:not(:disabled)'
                  ) || []
                ), N = x.indexOf(
                  document.activeElement
                ), C = g.key === "ArrowDown" ? (N + 1) % x.length : g.key === "ArrowUp" ? (N - 1 + x.length) % x.length : g.key === "Home" ? 0 : g.key === "End" ? x.length - 1 : -1;
                if (C >= 0 && (g.preventDefault(), x[C]?.focus()), g.key === "ArrowLeft" && h.length && (g.preventDefault(), f(h.slice(0, -1))), g.key === "ArrowRight") {
                  const A = document.activeElement?.dataset.item, L = v.find((U) => U.id === A);
                  L?.children && (g.preventDefault(), f([...h, L.id]));
                }
                g.key === "Tab" && y(!1);
              },
              children: [
                h.length > 0 && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: () => f(h.slice(0, -1)),
                    children: "‹ 返回"
                  }
                ),
                v.map((g) => /* @__PURE__ */ o("div", { children: [
                  g.separator && /* @__PURE__ */ e("div", { role: "separator", className: "fp-context-separator" }),
                  /* @__PURE__ */ o(
                    "button",
                    {
                      type: "button",
                      role: "menuitem",
                      "data-item": g.id,
                      disabled: g.disabled,
                      "aria-haspopup": g.children ? "menu" : void 0,
                      className: g.danger ? "fp-error-text" : "",
                      onClick: () => {
                        g.children ? f([...h, g.id]) : (y(), g.onSelect?.());
                      },
                      children: [
                        /* @__PURE__ */ e("span", { className: "fp-context-icon", children: g.checked ? /* @__PURE__ */ e(Re, { size: 15 }) : g.icon }),
                        /* @__PURE__ */ e("span", { children: g.label }),
                        g.children ? /* @__PURE__ */ e(Ie, { size: 14 }) : g.shortcut ? /* @__PURE__ */ e("kbd", { children: g.shortcut }) : null
                      ]
                    }
                  )
                ] }, g.id))
              ]
            }
          ),
          s.current?.closest("dialog") || document.body
        )
      ]
    }
  );
}
function Hi({
  editor: t,
  children: n,
  getExtraItems: r
}) {
  const [a, i] = k(""), l = B(""), s = B(null), c = async (d) => {
    if (!t) return;
    const { from: p, to: h } = t.state.selection, f = t.state.doc;
    try {
      if (d === "paste") {
        const m = await navigator.clipboard.readText();
        if (!m) return;
        !t.isDestroyed && t.state.doc === f && t.chain().focus().insertContentAt({ from: p, to: h }, { type: "text", text: m }).run();
      } else {
        const { dom: m, text: b } = t.view.serializeForClipboard(t.state.selection.content());
        navigator.clipboard.write && typeof ClipboardItem < "u" ? await navigator.clipboard.write([new ClipboardItem({
          "text/html": new Blob([m.innerHTML], { type: "text/html" }),
          "text/plain": new Blob([b], { type: "text/plain" })
        })]) : await navigator.clipboard.writeText(b), d === "cut" && !t.isDestroyed && t.state.doc === f && t.chain().focus().deleteRange({ from: p, to: h }).run();
      }
      i(
        d === "paste" ? "已粘贴" : d === "cut" ? "已剪切" : "已复制"
      );
    } catch {
      i("暂时无法访问剪贴板，请使用键盘快捷键。");
    }
  };
  return /* @__PURE__ */ o(
    gt,
    {
      label: "笔记快捷操作",
      tabIndex: -1,
      disabled: !t,
      items: () => {
        if (!t) return [];
        const d = !t.isEditable, p = t.state.selection.empty;
        return [
          ...s.current ? r?.(s.current) ?? [] : [],
          {
            id: "cut",
            label: "剪切",
            shortcut: "Ctrl+X",
            disabled: d || p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("cut");
            }
          },
          {
            id: "copy",
            label: "复制",
            shortcut: "Ctrl+C",
            disabled: p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("copy");
            }
          },
          {
            id: "paste",
            label: "粘贴为纯文本",
            shortcut: "Ctrl+Shift+V",
            disabled: d || !navigator.clipboard?.readText,
            onSelect: () => {
              c("paste");
            }
          },
          {
            id: "all",
            label: "全选",
            shortcut: "Ctrl+A",
            onSelect: () => t.chain().focus().selectAll().run()
          },
          ...l.current ? [
            {
              id: "copy-link",
              label: "复制链接地址",
              disabled: !navigator.clipboard?.writeText,
              onSelect: () => {
                navigator.clipboard.writeText(l.current).then(
                  () => i("链接已复制"),
                  () => i("请使用键盘快捷键复制链接。")
                );
              }
            },
            {
              id: "unlink",
              label: "取消链接",
              disabled: d,
              onSelect: () => t.chain().focus().extendMarkRange("link").unsetLink().run()
            }
          ] : [],
          {
            id: "format",
            label: "文字格式",
            separator: !0,
            disabled: d,
            children: [
              {
                id: "bold",
                label: "粗体",
                checked: t.isActive("bold"),
                onSelect: () => t.chain().focus().toggleBold().run()
              },
              {
                id: "italic",
                label: "斜体",
                checked: t.isActive("italic"),
                onSelect: () => t.chain().focus().toggleItalic().run()
              },
              {
                id: "clear",
                label: "清除格式",
                onSelect: () => t.chain().focus().unsetAllMarks().run()
              }
            ]
          },
          {
            id: "block",
            label: "段落操作",
            disabled: d,
            children: [
              {
                id: "move-up",
                label: "向上移动",
                disabled: t.state.selection.$from.index(0) === 0,
                onSelect: () => yr(t, "up")
              },
              {
                id: "move-down",
                label: "向下移动",
                disabled: t.state.selection.$from.index(0) >= t.state.doc.childCount - 1,
                onSelect: () => yr(t, "down")
              },
              {
                id: "delete-block",
                label: "删除这一块",
                danger: !0,
                onSelect: () => ld(t)
              }
            ]
          },
          ...t.isActive("table") ? [
            {
              id: "table",
              label: "表格操作",
              disabled: d,
              children: [
                {
                  id: "row-before",
                  label: "向上插入行",
                  onSelect: () => t.chain().focus().addRowBefore().run()
                },
                {
                  id: "row-after",
                  label: "向下插入行",
                  onSelect: () => t.chain().focus().addRowAfter().run()
                },
                {
                  id: "column-before",
                  label: "向左插入列",
                  onSelect: () => t.chain().focus().addColumnBefore().run()
                },
                {
                  id: "column-after",
                  label: "向右插入列",
                  onSelect: () => t.chain().focus().addColumnAfter().run()
                },
                {
                  id: "merge",
                  label: "合并单元格",
                  disabled: !t.can().mergeCells(),
                  onSelect: () => t.chain().focus().mergeCells().run()
                },
                {
                  id: "split",
                  label: "拆分单元格",
                  disabled: !t.can().splitCell(),
                  onSelect: () => t.chain().focus().splitCell().run()
                },
                {
                  id: "delete-row",
                  label: "删除当前行",
                  danger: !0,
                  separator: !0,
                  onSelect: () => t.chain().focus().deleteRow().run()
                },
                {
                  id: "delete-column",
                  label: "删除当前列",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteColumn().run()
                },
                {
                  id: "delete-table",
                  label: "删除表格",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteTable().run()
                }
              ]
            }
          ] : [],
          {
            id: "undo",
            label: "撤销",
            separator: !0,
            shortcut: "Ctrl+Z",
            disabled: d || !t.can().undo(),
            onSelect: () => t.chain().focus().undo().run()
          },
          {
            id: "redo",
            label: "重做",
            shortcut: "Ctrl+Shift+Z",
            disabled: d || !t.can().redo(),
            onSelect: () => t.chain().focus().redo().run()
          }
        ];
      },
      onOpen: (d) => {
        if (!t) return !1;
        const p = d.target;
        if (p.closest("input,textarea,math-field,button")) return !1;
        if (s.current = p, l.current = p.closest("a")?.getAttribute("href") || "", "clientX" in d) {
          const h = t.view.posAtCoords({
            left: d.clientX,
            top: d.clientY
          }), f = p.closest("[data-note-object], .fp-mermaid-node");
          if (f && t.view.dom.contains(f) && t.isEditable) {
            const m = t.view.posAtDOM(f, 0), b = t.state.doc.nodeAt(m), y = b && (b.isAtom || b.type.name === "codeBlock") ? m : Math.max(0, m - 1);
            t.state.doc.nodeAt(y) && t.commands.setNodeSelection(y);
          } else h && (t.state.selection.empty || h.pos < t.state.selection.from || h.pos > t.state.selection.to) && t.commands.setTextSelection(h.pos);
        }
        i("");
      },
      children: [
        n,
        a && /* @__PURE__ */ e("span", { className: "fp-visually-hidden", role: "status", children: a })
      ]
    }
  );
}
const An = Dn(!1), pd = '[data-fp-tooltip],button,[role="button"],a[title],a[aria-label],[tabindex][title]';
function hd({ children: t }) {
  return rn(An) ? /* @__PURE__ */ e(Z, { children: t }) : /* @__PURE__ */ o(An.Provider, { value: !0, children: [
    /* @__PURE__ */ e(_i, {}),
    t
  ] });
}
function _i({ owner: t }) {
  const [n, r] = k(null), a = B(null), i = B(null), l = Ne(), s = jt(a, !!n, n?.node), [c, u] = k({ left: 8, top: 8 });
  return Y(() => {
    let d = !1, p = !1;
    const h = () => r(null), f = (w) => {
      if ("pointerType" in w && (d = w.pointerType === "touch"), w.type === "focusin" && p || d) return;
      const v = w.target instanceof Element ? w.target : null, g = v?.closest(pd);
      if (t && g?.dataset.fpTooltipOwner !== t) {
        h();
        return;
      }
      if (!g || g.closest('[inert],[aria-hidden="true"]') || g.dataset.fpTooltip === "off" || g.matches('[role="menuitem"],[role="option"],[aria-expanded="true"]')) {
        h();
        return;
      }
      for (let C = v; C; C = C.parentElement) {
        const A = C.getAttribute("title");
        A && (C.dataset.fpTooltip ||= A, C.removeAttribute("title"));
      }
      const x = g.dataset.fpTooltip || g.getAttribute("aria-label") || g.textContent?.trim();
      if (!x) {
        h();
        return;
      }
      a.current = g;
      const N = g.dataset.fpTooltipSide || (g.closest('[data-variant="rail"]') ? "right" : "bottom");
      r((C) => C?.node === g && C.text === x ? C : { node: g, text: x, side: N });
    }, m = (w) => {
      const v = w.relatedTarget;
      (!(v instanceof Node) || !a.current?.contains(v)) && h();
    }, b = (w) => {
      d = !1, p = !1, w.key === "Escape" && h();
    }, y = (w) => {
      d = w.pointerType === "touch", p = !0, h();
    };
    return document.addEventListener("pointerover", f, !0), document.addEventListener("pointerout", m, !0), document.addEventListener("focusin", f, !0), document.addEventListener("focusout", h, !0), document.addEventListener("pointerdown", y, !0), document.addEventListener("keydown", b, !0), window.addEventListener("blur", h), window.addEventListener("scroll", h, !0), window.addEventListener("resize", h), () => {
      document.removeEventListener("pointerover", f, !0), document.removeEventListener("pointerout", m, !0), document.removeEventListener("focusin", f, !0), document.removeEventListener("focusout", h, !0), document.removeEventListener("pointerdown", y, !0), document.removeEventListener("keydown", b, !0), window.removeEventListener("blur", h), window.removeEventListener("scroll", h, !0), window.removeEventListener("resize", h);
    };
  }, [t]), Ce(() => {
    if (!n || !i.current) return;
    const d = n.node, p = d.getAttribute("aria-describedby");
    d.setAttribute("aria-describedby", [p, l].filter(Boolean).join(" "));
    const h = d.getBoundingClientRect(), f = i.current.getBoundingClientRect(), m = 8, b = 8;
    let y = n.side;
    y === "bottom" && h.bottom + m + f.height > innerHeight - b && (y = "top"), y === "top" && h.top - m - f.height < b && (y = "bottom"), y === "right" && h.right + m + f.width > innerWidth - b && (y = "left"), y === "left" && h.left - m - f.width < b && (y = "right");
    const w = y === "left" ? h.left - m - f.width : y === "right" ? h.right + m : h.left + (h.width - f.width) / 2, v = y === "top" ? h.top - m - f.height : y === "bottom" ? h.bottom + m : h.top + (h.height - f.height) / 2;
    u({ left: Math.max(b, Math.min(w, innerWidth - f.width - b)), top: Math.max(b, Math.min(v, innerHeight - f.height - b)) });
    const g = new MutationObserver(() => {
      (!d.isConnected || d.closest('[inert],[aria-hidden="true"]') || d.getAttribute("aria-expanded") === "true") && r(null);
    });
    return g.observe(document.body, { childList: !0, subtree: !0, attributes: !0, attributeFilter: ["aria-expanded", "inert", "aria-hidden"] }), () => {
      g.disconnect(), p ? d.setAttribute("aria-describedby", p) : d.removeAttribute("aria-describedby");
    };
  }, [n, l]), n && typeof document < "u" ? Te(/* @__PURE__ */ e("div", { ref: i, id: l, role: "tooltip", className: "fp-tooltip-bubble", style: { ...s, color: "var(--fp-surface)", ...c }, children: n.text }), document.body) : null;
}
function fd({ text: t, children: n, side: r = "bottom" }) {
  const a = rn(An), i = Ne(), l = { "data-fp-tooltip": t, "data-fp-tooltip-side": r, "data-fp-tooltip-owner": a ? void 0 : i, title: void 0 }, s = Oa(n) ? Fa(n, l) : /* @__PURE__ */ e("span", { ...l, children: n });
  return a ? s : /* @__PURE__ */ o(An.Provider, { value: !0, children: [
    /* @__PURE__ */ e(_i, { owner: i }),
    s
  ] });
}
function md({ tip: t, children: n }) {
  return /* @__PURE__ */ e(fd, { text: t, children: n });
}
const mn = ["bold", "italic", "strike", "code", "underline"];
function bd(t) {
  const { from: n, to: r, empty: a } = t.state.selection;
  if (a || n >= r)
    return mn.filter((l) => t.isActive(l));
  const i = /* @__PURE__ */ new Set();
  return t.state.doc.nodesBetween(n, r, (l) => {
    if (l.isText)
      for (const s of l.marks)
        mn.includes(s.type.name) && i.add(s.type.name);
  }), mn.filter((l) => i.has(l));
}
function gd(t, n, r, a) {
  if (r >= a) return !1;
  const i = t.chain().focus().setTextSelection({ from: r, to: a });
  for (const l of mn)
    n.includes(l) ? i.setMark(l) : i.unsetMark(l);
  return i.run();
}
function yd(t) {
  return t === null ? "once" : t === "once" ? "locked" : null;
}
function vd({ language: t, onChange: n, className: r }) {
  return /* @__PURE__ */ e(we, { label: "代码块语言", className: r, value: t ?? "", onChange: (i) => n(i || null), options: [{ value: "", label: "无语言" }, ...Wn] });
}
const wd = [
  { label: "墨色", value: "#1f2937" },
  { label: "白", value: "#ffffff" },
  { label: "红", value: "#dc2626" },
  { label: "橙", value: "#ea580c" },
  { label: "黄", value: "#ca8a04" },
  { label: "绿", value: "#16a34a" },
  { label: "青", value: "#0891b2" },
  { label: "蓝", value: "#2563eb" },
  { label: "紫", value: "#7c3aed" },
  { label: "粉", value: "#db2777" }
], kd = [
  "#000000",
  "#7f1d1d",
  "#9a3412",
  "#854d0e",
  "#166534",
  "#0e7490",
  "#1d4ed8",
  "#6d28d9",
  "#9d174d",
  "#525252"
], Nd = [
  "#fef08a",
  "#bbf7d0",
  "#a5f3fc",
  "#ddd6fe",
  "#fecdd3",
  "#fde68a",
  "#86efac",
  "#67e8f9",
  "#c4b5fd",
  "#fda4af"
], xd = [
  "rgba(17,24,39,0.55)",
  "rgba(220,38,38,0.45)",
  "rgba(234,88,12,0.45)",
  "rgba(22,163,74,0.45)",
  "rgba(37,99,235,0.45)",
  "rgba(124,58,237,0.45)"
];
function wr() {
  try {
    const t = localStorage.getItem("fp-toolbar-recent-colors"), n = t ? JSON.parse(t) : null;
    return Array.isArray(n) ? n.filter((r) => typeof r == "string").slice(0, 8) : [];
  } catch {
    return [];
  }
}
function Cd(t) {
  const n = [t, ...wr().filter((r) => r !== t)].slice(0, 8);
  try {
    localStorage.setItem("fp-toolbar-recent-colors", JSON.stringify(n));
  } catch {
  }
}
function Sd({
  mode: t,
  current: n,
  onApply: r,
  onClose: a
}) {
  const [i, l] = k([]), [s, c] = k(n?.startsWith("#") ? n : "#FD8B07"), u = B(null);
  Y(() => l(wr()), []), Y(() => {
    const h = (m) => {
      u.current?.contains(m.target) || a();
    }, f = (m) => m.key === "Escape" && a();
    return window.addEventListener("pointerdown", h), window.addEventListener("keydown", f), () => {
      window.removeEventListener("pointerdown", h), window.removeEventListener("keydown", f);
    };
  }, [a]);
  const d = (h) => {
    h && Cd(h), l(wr()), r(h), a();
  }, p = (h) => h.map((f) => {
    const m = typeof f == "string" ? f : f.value, b = typeof f == "string" ? m : f.label;
    return /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        title: b,
        "aria-label": b,
        className: "toolbar-color-swatch",
        style: { background: m },
        "data-active": n === m || void 0,
        onClick: () => d(m)
      },
      m
    );
  });
  return /* @__PURE__ */ o("div", { ref: u, className: "toolbar-color-picker", role: "listbox", "aria-label": t === "text" ? "字体颜色" : "荧光笔颜色", children: [
    i.length > 0 && /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "最近使用" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(i) })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: t === "text" ? "主题色" : "荧光笔" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(t === "text" ? wd : Nd) })
    ] }),
    t === "text" && /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "标准色" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(kd) })
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "半透明" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(xd) })
      ] })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "自定义" }),
      /* @__PURE__ */ o("div", { className: "toolbar-color-custom", children: [
        /* @__PURE__ */ e(
          "input",
          {
            type: "text",
            "aria-label": "自定义颜色",
            value: s,
            placeholder: "#FD8B07",
            onChange: (h) => c(h.target.value)
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: !/^#[0-9a-f]{6}$/i.test(s), onClick: () => d(s), children: "应用" }),
        /* @__PURE__ */ e("button", { type: "button", onClick: () => d(t === "text" ? null : "#fef08a"), children: t === "text" ? "默认颜色" : "默认高亮" })
      ] })
    ] })
  ] });
}
function Md(t, n, r = (i) => i.width ?? 0, a = 4) {
  const i = new Set(t.map((s) => s.id)), l = () => t.reduce((s, c) => s + (i.has(c.id) ? r(c) : 0), 0) + Math.max(0, i.size - 1) * a;
  for (const s of [...t].sort((c, u) => c.priority - u.priority || t.indexOf(u) - t.indexOf(c))) {
    if (l() <= Math.max(0, n)) break;
    i.delete(s.id);
  }
  return { visible: t.filter((s) => i.has(s.id)), overflow: t.filter((s) => !i.has(s.id)) };
}
function Ed(t, n, r, a = 40, i = 4) {
  let l = null;
  const s = (p, h, f, m) => {
    if (h > n) return;
    if (p === t.length) {
      (!l || f > l.score) && (l = { modes: { ...m }, score: f });
      return;
    }
    const b = t[p], y = b.actions?.length ?? 1;
    for (const w of ["full", "icons", "group"]) {
      const v = w === "group" ? 0 : y, g = v * 1e5 + v * b.priority * 100 + (w === "full" ? y * b.priority : 0);
      m[b.id] = w, s(p + 1, h + r(b, w) + (p ? i : 0), f + g, m);
    }
  };
  if (s(0, 0, 0, {}), l) return { modes: l.modes, visible: [...t], overflow: [] };
  const c = Object.fromEntries(t.map((p) => [p.id, "full"])), u = [...t].sort((p, h) => p.priority - h.priority), d = () => t.reduce((p, h) => p + r(h, c[h.id]), 0) + Math.max(0, t.length - 1) * i;
  for (const p of ["icons", "group"])
    for (const h of u) {
      if (d() <= n) return { modes: c, visible: [...t], overflow: [] };
      r(h, p) < r(h, c[h.id]) && (c[h.id] = p);
    }
  return d() <= n ? { modes: c, visible: [...t], overflow: [] } : { modes: c, ...Md(t, n - a, (p) => r(p, c[p.id]), i) };
}
function $d(t) {
  const n = B(null), r = B(null), [a, i] = k({ modes: {}, ids: [] });
  return Ce(() => {
    const l = n.current, s = r.current;
    if (!l || !s || !l.parentElement) return;
    const c = l.parentElement;
    let u = 0, d = !0;
    const p = () => {
      if (!d) return;
      const m = new Map(Array.from(s.querySelectorAll("[data-measure-mode] [data-group]")).map((A) => [`${A.parentElement.dataset.measureMode}:${A.dataset.group}`, A.getBoundingClientRect().width])), b = getComputedStyle(c), y = parseFloat(getComputedStyle(l).columnGap) || 0, w = c.clientWidth - parseFloat(b.paddingLeft || "0") - parseFloat(b.paddingRight || "0"), v = c.querySelector(".note-toolbar-hint"), g = v && getComputedStyle(v).position !== "absolute" ? v.getBoundingClientRect().width + y : 0, x = (s.querySelector("[data-measure-overflow]")?.getBoundingClientRect().width ?? 40) + y, N = Ed(t, Math.max(0, Math.floor(w - g)), (A, L) => m.get(`${L}:${A.id}`) ?? 1 / 0, x, y), C = { modes: N.modes, ids: N.visible.map((A) => A.id) };
      i((A) => JSON.stringify(A) === JSON.stringify(C) ? A : C);
    }, h = () => {
      cancelAnimationFrame(u), u = requestAnimationFrame(p);
    };
    p();
    const f = typeof ResizeObserver > "u" ? null : new ResizeObserver(h);
    return f?.observe(c), f?.observe(s), window.addEventListener("resize", h), document.fonts?.addEventListener("loadingdone", h), document.fonts?.ready.then(() => {
      d && h();
    }), () => {
      d = !1, cancelAnimationFrame(u), f?.disconnect(), window.removeEventListener("resize", h), document.fonts?.removeEventListener("loadingdone", h);
    };
  }), { hostRef: n, measureRef: r, modes: a.modes, visible: t.filter((l) => a.ids.includes(l.id)), overflow: t.filter((l) => !a.ids.includes(l.id)) };
}
function zd({ editor: t, onHistory: n, onAttachment: r, onVideo: a, onInteractive: i, onInsertCard: l, onMath: s, onSnapshot: c, onExport: u, formatPainterMode: d, onFormatPainterMode: p, formatPainterMarks: h, onFormatPainterMarks: f, hiddenActions: m = [] }) {
  const [b, y] = k(null), [w, v] = k(null), [g, x] = k({ rows: 3, cols: 3 }), [N, C] = k(""), [, A] = k(0), L = B(null), U = B(null), S = B(null), I = B(null), T = B([]);
  Y(() => {
    const F = ({ transaction: Q }) => {
      I.current && Q.docChanged && (I.current = {
        from: Q.mapping.map(I.current.from),
        to: Q.mapping.map(I.current.to)
      }), A((ve) => ve + 1);
    };
    return t.on("transaction", F), () => {
      t.off("transaction", F);
    };
  }, [t]), Y(() => {
    if (!b) return;
    const F = (je) => {
      const Fe = je.target;
      !L.current?.contains(Fe) && !U.current?.contains(Fe) && !Fe.closest?.(".fp-popup-panel") && y(null);
    }, Q = (je) => {
      je.key === "Escape" && (y(null), S.current?.focus());
    }, ve = () => y(null), Me = L.current?.clientWidth, Ee = typeof ResizeObserver > "u" ? null : new ResizeObserver(() => {
      L.current?.clientWidth !== Me && ve();
    });
    return L.current && Ee?.observe(L.current), window.addEventListener("pointerdown", F), window.addEventListener("keydown", Q), window.addEventListener("resize", ve), () => {
      Ee?.disconnect(), window.removeEventListener("pointerdown", F), window.removeEventListener("keydown", Q), window.removeEventListener("resize", ve);
    };
  }, [b]);
  const H = () => {
    const { from: F, to: Q } = t.state.selection;
    I.current = { from: F, to: Q };
  }, R = () => {
    const F = I.current;
    F && F.to <= t.state.doc.content.size ? t.chain().focus().setTextSelection(F).run() : t.commands.focus();
  }, O = () => {
    y(null), I.current = null;
  }, M = (F) => {
    F(), O();
  }, K = [1, 2, 3, 4, 5, 6].find((F) => t.isActive("heading", { level: F })), j = t.getAttributes("textStyle").color || null, P = t.getAttributes("highlight").color || "#fde047", $ = () => {
    const F = yd(d);
    p(F), f(F ? T.current : []);
  }, z = [
    { id: "history", priority: 100, actions: [
      { id: "undo", label: "撤销", icon: /* @__PURE__ */ e(Tl, { size: 16 }), disabled: !t.can().undo(), run: () => {
        t.chain().focus().undo().run();
      } },
      { id: "redo", label: "重做", icon: /* @__PURE__ */ e(Dl, { size: 16 }), disabled: !t.can().redo(), run: () => {
        t.chain().focus().redo().run();
      } }
    ] },
    { id: "painter", priority: 40, actions: [{ id: "painter", label: "格式刷", icon: /* @__PURE__ */ e(Pl, { size: 16 }), active: !!d, before: () => {
      T.current = bd(t);
    }, run: $ }] },
    { id: "heading", priority: 95, actions: [{ id: "heading", label: "标题级别", icon: /* @__PURE__ */ e("b", { children: K ? `H${K}` : "Hn" }), menu: "heading" }] },
    { id: "bold", priority: 90, actions: [{ id: "bold", label: "粗体", icon: /* @__PURE__ */ e(Ol, { size: 16 }), active: t.isActive("bold"), run: () => {
      t.chain().focus().toggleBold().run();
    } }] },
    { id: "italic", priority: 65, actions: [{ id: "italic", label: "斜体", icon: /* @__PURE__ */ e(Fl, { size: 16 }), active: t.isActive("italic"), run: () => {
      t.chain().focus().toggleItalic().run();
    } }] },
    { id: "colors", priority: 60, actions: [
      { id: "color", label: "字体颜色", icon: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e(Rl, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: j || "var(--fp-ink)" } })
      ] }), menu: "color", before: H },
      { id: "highlight", label: "荧光笔", icon: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e(Bl, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: P } })
      ] }), menu: "highlight", before: H }
    ] },
    { id: "list", priority: 70, actions: [{ id: "list", label: "列表", icon: /* @__PURE__ */ e(yn, { size: 16 }), menu: "list" }] },
    { id: "link", priority: 45, actions: [{ id: "link", label: "链接", icon: /* @__PURE__ */ e(ft, { size: 16 }), active: t.isActive("link"), menu: "link", before: H }] },
    { id: "attachment", priority: 42, actions: [{ id: "attachment", label: "附件", icon: /* @__PURE__ */ e(cr, { size: 16 }), run: r }] },
    { id: "math", priority: 99, actions: [{ id: "math", label: "公式", icon: /* @__PURE__ */ e(zt, { size: 16 }), menu: "math" }] },
    { id: "insert", priority: 98, actions: [{ id: "insert", label: "插入", icon: /* @__PURE__ */ e(Jn, { size: 16 }), menu: "insert" }] },
    { id: "decoration", priority: 35, actions: [
      { id: "strike", label: "删除线", icon: /* @__PURE__ */ e(jl, { size: 16 }), active: t.isActive("strike"), run: () => {
        t.chain().focus().toggleStrike().run();
      } },
      { id: "underline", label: "下划线", icon: /* @__PURE__ */ e(ql, { size: 16 }), active: t.isActive("underline"), run: () => {
        t.chain().focus().toggleUnderline().run();
      } }
    ] },
    { id: "clear", priority: 20, actions: [{ id: "clear", label: "清除格式", icon: /* @__PURE__ */ e(Kl, { size: 16 }), run: () => {
      t.chain().focus().unsetAllMarks().clearNodes().run();
    } }] },
    { id: "quote", priority: 30, actions: [{ id: "quote", label: "引用", icon: /* @__PURE__ */ e(Ha, { size: 16 }), active: t.isActive("blockquote"), run: () => {
      t.chain().focus().toggleBlockquote().run();
    } }] },
    { id: "code", priority: 25, actions: [
      { id: "code", label: "行内代码", icon: /* @__PURE__ */ e(Sr, { size: 16 }), active: t.isActive("code"), run: () => {
        t.chain().focus().toggleCode().run();
      } },
      { id: "codeBlock", label: "代码块", icon: /* @__PURE__ */ e(Ul, { size: 16 }), active: t.isActive("codeBlock"), run: () => {
        t.chain().focus().toggleCodeBlock().run();
      } }
    ] },
    { id: "versions", priority: 15, actions: [{ id: "versions", label: "历史", icon: /* @__PURE__ */ e("span", { children: "历史" }), run: n }] }
  ];
  t.isActive("codeBlock") && z.push({ id: "language", priority: 85, actions: [], custom: /* @__PURE__ */ e(vd, { language: Mc(t.state.selection.$head.parent), onChange: (F) => t.chain().focus().updateAttributes("codeBlock", { language: F }).run() }) }), t.isActive("table") && z.push({ id: "tableActions", priority: 80, actions: [
    { id: "addRow", label: "添加行", icon: /* @__PURE__ */ e("span", { children: "+行" }), run: () => {
      t.chain().focus().addRowAfter().run();
    } },
    { id: "deleteRow", label: "删除行", icon: /* @__PURE__ */ e("span", { children: "−行" }), run: () => {
      t.chain().focus().deleteRow().run();
    } },
    { id: "addColumn", label: "添加列", icon: /* @__PURE__ */ e("span", { children: "+列" }), run: () => {
      t.chain().focus().addColumnAfter().run();
    } },
    { id: "deleteColumn", label: "删除列", icon: /* @__PURE__ */ e("span", { children: "−列" }), run: () => {
      t.chain().focus().deleteColumn().run();
    } },
    { id: "deleteTable", label: "删除表格", icon: /* @__PURE__ */ e("span", { children: "删表" }), run: () => {
      t.chain().focus().deleteTable().run();
    } }
  ] });
  const E = z.flatMap((F) => F.actions), D = (...F) => E.filter((Q) => F.includes(Q.id)), ae = [
    { id: "history", label: "撤销重做", priority: 100, actions: D("undo", "redo") },
    { id: "text", label: "文字格式", priority: 80, actions: D("heading", "bold", "italic", "underline", "strike", "color", "highlight", "painter", "clear") },
    { id: "paragraph", label: "段落", priority: 60, actions: D("list", "quote", "code", "codeBlock") },
    { id: "insertions", label: "插入", priority: 90, actions: [
      ...D("math"),
      { id: "table", label: "表格", icon: /* @__PURE__ */ e(Jn, { size: 16 }), menu: "table" },
      { id: "card", label: "卡片", icon: /* @__PURE__ */ e(Yr, { size: 16 }), run: l },
      ...D("link", "attachment"),
      { id: "video", label: "视频 · 边看边记", icon: /* @__PURE__ */ e(Gr, { size: 16 }), run: a || r },
      { id: "mermaid", label: "Mermaid 图", icon: /* @__PURE__ */ e(Hl, { size: 16 }), run: () => {
        qi(t);
      } },
      ...i ? [{ id: "interactive", label: "交互实验", icon: /* @__PURE__ */ e(_l, { size: 16 }), run: i }] : [],
      { id: "divider", label: "分隔线", icon: /* @__PURE__ */ e(Tt, { size: 16 }), run: () => {
        t.chain().focus().setHorizontalRule().run();
      } }
    ] },
    { id: "versions", label: "历史与导出", priority: 40, actions: [
      ...D("versions"),
      { id: "snapshot", label: "建立版本", icon: /* @__PURE__ */ e(_a, { size: 16 }), run: c },
      { id: "export", label: "导出", icon: /* @__PURE__ */ e(Ot, { size: 16 }), run: u }
    ] },
    ...z.filter((F) => ["language", "tableActions"].includes(F.id)).map((F) => ({ ...F, label: F.id === "language" ? "代码语言" : "表格操作" }))
  ].map((F) => ({ ...F, actions: F.actions.filter((Q) => !m.includes(Q.id)) })).filter((F) => F.actions.length || F.custom), { hostRef: ye, measureRef: he, modes: W, visible: G, overflow: ue } = $d(ae), me = (F, Q = !1, ve = !1, Me = !1) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "data-fp-tooltip": Q ? "off" : F.label,
      "aria-label": F.label,
      "aria-pressed": F.active || void 0,
      "aria-expanded": F.menu ? b === F.menu : void 0,
      disabled: F.disabled,
      className: Q ? "toolbar-menu-item" : void 0,
      onMouseDown: (Ee) => {
        ve || (Ee.preventDefault(), F.before?.());
      },
      onClick: (Ee) => {
        ve || (F.before?.(), F.menu ? (v(Q ? w ?? Ee.currentTarget.getBoundingClientRect() : Ee.currentTarget.getBoundingClientRect()), y((je) => je === F.menu ? null : F.menu), F.menu === "link" && C(t.getAttributes("link").href || "")) : F.run && M(F.run));
      },
      children: [
        F.icon,
        (Q || Me) && F.id !== "versions" && /* @__PURE__ */ e("span", { children: F.label })
      ]
    },
    F.id
  ), q = (F, Q = !1, ve = !1, Me = W[F.id] ?? "full") => /* @__PURE__ */ e("div", { "data-group": F.id, className: Q ? "toolbar-overflow-group" : "toolbar-group", children: Me === "group" && !Q && F.id !== "history" ? /* @__PURE__ */ o("button", { type: "button", "aria-label": F.label, "aria-expanded": b === `group:${F.id}`, onMouseDown: (Ee) => Ee.preventDefault(), onClick: (Ee) => {
    v(Ee.currentTarget.getBoundingClientRect()), y(`group:${F.id}`);
  }, children: [
    F.label,
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌄" })
  ] }) : /* @__PURE__ */ o(Z, { children: [
    F.actions.map((Ee) => me(Ee, Q, ve, Me === "full" && F.id !== "history")),
    F.custom
  ] }) }, F.id), V = (F, Q, ve) => /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onMouseDown: (Me) => Me.preventDefault(), onClick: () => M(ve), children: [
    Q,
    /* @__PURE__ */ e("span", { children: F })
  ] }), oe = w ? Math.max(8, Math.min(w.left, window.innerWidth - 256)) : 8, _ = w ? Math.min(w.bottom + 6, window.innerHeight - 160) : 8;
  return /* @__PURE__ */ o("div", { className: "fp-note-toolbar note-editor-topbar", ref: L, role: "toolbar", "aria-label": "笔记编辑工具", children: [
    /* @__PURE__ */ e("div", { ref: ye, className: "visual-note-editor-toolbar", children: G.map((F) => q(F)) }),
    ue.length > 0 && /* @__PURE__ */ e(md, { tip: "更多", children: /* @__PURE__ */ e("button", { ref: S, type: "button", "aria-label": "更多", title: "更多", "aria-expanded": b === "more", onMouseDown: (F) => F.preventDefault(), onClick: () => {
      v(S.current?.getBoundingClientRect() ?? null), y(b === "more" ? null : "more");
    }, children: /* @__PURE__ */ e(Dt, { size: 17 }) }) }),
    /* @__PURE__ */ o("div", { ref: he, className: "visual-note-editor-toolbar toolbar-measure", "aria-hidden": "true", inert: !0, children: [
      ["full", "icons", "group"].map((F) => /* @__PURE__ */ e("div", { "data-measure-mode": F, className: "toolbar-measure-row", children: ae.map((Q) => q(Q, !1, !0, F)) }, F)),
      /* @__PURE__ */ e("button", { type: "button", "data-measure-overflow": !0, "aria-label": "更多", children: /* @__PURE__ */ e(Dt, { size: 17 }) })
    ] }),
    d && t.state.selection.empty && !h.length && /* @__PURE__ */ e("span", { className: "note-toolbar-hint", role: "status", children: "请先选中带格式的文字，再点格式刷" }),
    b && w && Te(/* @__PURE__ */ o("div", { ref: U, className: "fp-editor-menu note-toolbar-portal-menu", role: "dialog", "aria-label": "编辑工具选项", style: { left: oe, top: _, maxHeight: Math.max(100, window.innerHeight - _ - 12) }, children: [
      b === "more" && /* @__PURE__ */ e(Z, { children: ue.map((F) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: F.label }),
        q(F, !0)
      ] }, F.id)) }),
      b.startsWith("group:") && ae.filter((F) => `group:${F.id}` === b).map((F) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: F.label }),
        q(F, !0)
      ] }, F.id)),
      b === "heading" && /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: "标题级别" }),
        /* @__PURE__ */ e("div", { className: "toolbar-menu-grid", children: [1, 2, 3, 4, 5, 6].map((F) => /* @__PURE__ */ o("button", { type: "button", className: K === F ? "is-active" : "", onClick: () => M(() => {
          t.chain().focus().toggleHeading({ level: F }).run();
        }), children: [
          "H",
          F
        ] }, F)) }),
        V("正文", null, () => {
          t.chain().focus().setParagraph().run();
        })
      ] }),
      (b === "color" || b === "highlight") && /* @__PURE__ */ e(Sd, { mode: b === "color" ? "text" : "highlight", current: b === "color" ? j : P, onApply: (F) => {
        R(), b === "color" ? F === null ? t.chain().unsetMark("textStyle").removeEmptyTextStyle().run() : t.chain().setColor(F).run() : F === null ? t.chain().unsetHighlight().run() : t.chain().setHighlight({ color: F }).run();
      }, onClose: O }),
      b === "list" && /* @__PURE__ */ o(Z, { children: [
        V("无序列表", /* @__PURE__ */ e(yn, { size: 15 }), () => {
          t.chain().focus().toggleBulletList().run();
        }),
        V("有序列表", /* @__PURE__ */ e(Wl, { size: 15 }), () => {
          t.chain().focus().toggleOrderedList().run();
        })
      ] }),
      b === "link" && /* @__PURE__ */ o("form", { className: "toolbar-link-form", onSubmit: (F) => {
        F.preventDefault(), R(), N.trim() ? t.chain().extendMarkRange("link").setLink({ href: N.trim() }).run() : t.chain().extendMarkRange("link").unsetLink().run(), O();
      }, children: [
        /* @__PURE__ */ o("label", { children: [
          "链接地址",
          /* @__PURE__ */ e("input", { "aria-label": "链接地址", value: N, onChange: (F) => C(F.target.value), placeholder: "https://" })
        ] }),
        /* @__PURE__ */ e("button", { type: "submit", children: "应用" }),
        V("移除链接", null, () => {
          R(), t.chain().extendMarkRange("link").unsetLink().run();
        })
      ] }),
      b === "math" && /* @__PURE__ */ o(Z, { children: [
        V("行内公式", /* @__PURE__ */ e(zt, { size: 15 }), () => s(!1)),
        V("独立公式", /* @__PURE__ */ e(zt, { size: 15 }), () => s(!0))
      ] }),
      b === "insert" && /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onClick: () => y("table"), children: [
          /* @__PURE__ */ e(Jn, { size: 15 }),
          "表格…"
        ] }),
        V("行内公式", /* @__PURE__ */ e(zt, { size: 15 }), () => s(!1)),
        V("独立公式", /* @__PURE__ */ e(zt, { size: 15 }), () => s(!0)),
        !m.includes("card") && V("说明卡片", /* @__PURE__ */ e(Yr, { size: 15 }), l),
        !m.includes("video") && V("视频 · 边看边记", /* @__PURE__ */ e(Gr, { size: 15 }), a || r),
        !m.includes("attachment") && V("附件", /* @__PURE__ */ e(cr, { size: 15 }), r),
        V("分隔线", /* @__PURE__ */ e(Tt, { size: 15 }), () => {
          t.chain().focus().setHorizontalRule().run();
        })
      ] }),
      b === "table" && /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ o("strong", { className: "toolbar-menu-label", children: [
          g.rows,
          " × ",
          g.cols,
          " 表格"
        ] }),
        /* @__PURE__ */ e("div", { className: "toolbar-table-grid", children: Array.from({ length: 64 }, (F, Q) => {
          const ve = Math.floor(Q / 8) + 1, Me = Q % 8 + 1;
          return /* @__PURE__ */ e("button", { type: "button", "aria-label": `${ve} 行 ${Me} 列`, className: ve <= g.rows && Me <= g.cols ? "is-active" : "", onFocus: () => x({ rows: ve, cols: Me }), onMouseEnter: () => x({ rows: ve, cols: Me }), onClick: () => M(() => {
            t.chain().focus().insertTable({ rows: ve, cols: Me, withHeaderRow: !0 }).run();
          }) }, Q);
        }) })
      ] })
    ] }), document.body)
  ] });
}
const Wi = Hn.create({
  name: "imageConversion",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return Object.fromEntries(["src", "alt", "jobId", "markdown", "error"].map((t) => [t, { default: "" }]));
  },
  parseHTML() {
    return [{ tag: "figure[data-image-conversion]" }];
  },
  renderHTML({ node: t }) {
    return ["figure", { "data-image-conversion": "" }, ["img", { src: t.attrs.src, alt: t.attrs.alt }]];
  },
  renderMarkdown(t) {
    return `![${String(t.attrs?.alt || "图片").replace(/[\[\]]/g, "")}](${t.attrs?.src || ""})`;
  }
});
function bh(t, n) {
  const r = t.state.selection.to;
  return t.chain().focus().insertContentAt(r, [n, { type: "paragraph" }]).run();
}
const Ut = (t) => String(t ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), Vi = Hn.create({
  name: "uploadPlaceholder",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return {
      uploadId: { default: "" },
      name: { default: "附件" },
      mediaType: { default: "application/octet-stream" },
      error: { default: "" },
      convert: { default: !1, parseHTML: (t) => t.getAttribute("convert") === "true" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-upload-placeholder]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["div", Tr(t, { "data-upload-placeholder": "" }), `正在上传 ${t.name || "附件"}`];
  },
  renderMarkdown(t) {
    const n = t.attrs || {};
    return `<div data-upload-placeholder="" uploadid="${Ut(n.uploadId)}" name="${Ut(n.name)}" mediatype="${Ut(n.mediaType)}" error="${Ut(n.error)}" convert="${n.convert === !0 ? "true" : "false"}">正在上传 ${Ut(n.name || "附件")}</div>

`;
  }
});
function Id(t) {
  const n = (r) => {
    if (!r.content) return [r];
    const a = r.content.flatMap(n);
    if (!["paragraph", "heading"].includes(r.type || "") || !a.some((u) => u.type === "image")) return [{ ...r, content: a }];
    const i = [];
    let l = [], s = !1;
    const c = () => {
      if (!l.length) return;
      const u = { ...r.attrs };
      s && delete u.id, i.push({ ...r, attrs: u, content: l }), s = !0, l = [];
    };
    for (const u of a)
      u.type === "image" ? (c(), i.push(u)) : l.push(u);
    return c(), i;
  };
  return n(t)[0];
}
function Ad(t) {
  const n = t.match(
    /^::(video|audio|interactive|figure|plot)\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/
  );
  if (n)
    return {
      type: "directiveBlock",
      raw: n[0],
      name: n[1],
      attributes: n[2] || "",
      body: ""
    };
  const r = t.match(/^:::([a-zA-Z][\w-]*)(?:\{([^\n}]*)\})?[ \t]*\r?\n/);
  if (!r) return;
  let a = 1, i = r[0].length;
  for (; i <= t.length; ) {
    const l = t.indexOf(`
`, i), s = l < 0 ? t.length : l + 1, c = t.slice(i, s).replace(/\r?\n$/, "");
    if (/^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/.test(c) && (a += 1), /^:::[ \t]*$/.test(c) && (a -= 1, a === 0)) {
      const u = t.slice(r[0].length, i).replace(/\r?\n$/, "");
      return {
        type: "directiveBlock",
        raw: t.slice(0, s),
        name: r[1],
        attributes: r[2] || "",
        body: u
      };
    }
    if (l < 0) break;
    i = s;
  }
}
const Xi = Hn.create({
  name: "directiveBlock",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "note" },
      attributes: { default: "" },
      body: { default: "" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-directive-block]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return [
      "div",
      Tr(t, { "data-directive-block": "" })
    ];
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("directiveBlock", {
      name: r.name,
      attributes: r.attributes,
      body: r.body
    });
  },
  renderMarkdown(t) {
    const n = String(t.attrs?.attributes || "").trim(), r = String(t.attrs?.body || ""), a = t.attrs?.name || "note";
    return ["video", "audio", "interactive", "figure", "plot"].includes(a) ? `::${a}${n ? `{${n}}` : ""}` : `:::${a}${n ? `{${n}}` : ""}
${r}${r.endsWith(`
`) ? "" : `
`}:::`;
  },
  markdownTokenizer: {
    name: "directiveBlock",
    level: "block",
    start: (t) => t.search(
      /^::(?:interactive|video|audio|figure|plot)\{[^\n}]*\}[ \t]*$|^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/m
    ),
    tokenize: (t) => Ad(t)
  }
}), Ld = [
  ["definition", "定义"],
  ["theorem", "定理"],
  ["example", "例题"],
  ["insight", "直觉"],
  ["pitfall", "易错点"],
  ["note", "说明"],
  ["tip", "技巧"],
  ["memory", "记忆卡"],
  ["derivation", "推导"],
  ["timeline", "时间线"],
  ["event", "事件"],
  ["concept", "概念"],
  ["compare", "对比"],
  ["cause-effect", "因果"],
  ["keypoint", "核心要点"],
  ["interactive", "互动内容"],
  ["video", "视频"],
  ["figure", "图片"],
  ["plot", "函数图"],
  ["audio", "音频"],
  ["historymap", "历史地图"],
  ["learninganimation", "学习动画"],
  ["attachment", "附件"]
];
function Yi(t) {
  return t === "timeline" ? "period" : t === "concept" ? "term" : ["event", "compare", "cause-effect"].includes(t) ? "title" : "label";
}
function ka(t, n) {
  const r = Yi(n);
  for (const a of [r, "label", "title", "term", "period"]) {
    const i = t.match(
      new RegExp(`(?:^|\\s)${a}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)
    );
    if (i) return i[1] ?? i[2] ?? i[3] ?? "";
  }
  return "";
}
function Na(t, n, r) {
  const a = Yi(n), i = t.replace(
    /(?:^|\s)(?:label|title|period|term)=(?:"[^"]*"|'[^']*'|[^\s}]+)/g,
    ""
  ).trim(), l = r.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return [`${a}="${l}"`, i].filter(Boolean).join(" ");
}
const Td = Zo.extend({
  addOptions() {
    return { ...this.parent?.(), resolveUrl: (t) => t };
  },
  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: null,
        parseHTML: (t) => t.getAttribute("data-width") || t.style.width || null,
        renderHTML: (t) => t.width ? { "data-width": t.width, style: `width:${t.width};max-width:100%` } : {}
      }
    };
  },
  addNodeView() {
    return ({ node: t, getPos: n, editor: r }) => {
      let a = t;
      const i = document.createElement("span");
      i.className = "visual-image-node", i.contentEditable = "false", i.dataset.noteObject = "image";
      const l = document.createElement("img"), s = document.createElement("input");
      s.type = "text", s.className = "visual-image-caption", s.setAttribute("aria-label", "图片名称"), s.placeholder = "添加图片名称", s.addEventListener("keydown", (d) => {
        d.stopPropagation(), d.key === "Enter" && !d.isComposing && (d.preventDefault(), s.blur());
      }), s.addEventListener("blur", () => {
        const d = n();
        typeof d == "number" && s.value !== String(a.attrs.title || a.attrs.alt || "") && r.view.dispatch(r.state.tr.setNodeMarkup(d, void 0, { ...a.attrs, alt: s.value, title: s.value }));
      });
      const c = document.createElement("button");
      c.type = "button", c.className = "visual-image-resize", c.setAttribute("aria-label", "调整图片大小");
      const u = () => {
        l.src = this.options.resolveUrl(String(a.attrs.src || "")), l.alt = String(a.attrs.alt || ""), l.title = String(a.attrs.title || ""), document.activeElement !== s && (s.value = String(a.attrs.title || a.attrs.alt || "")), l.style.width = a.attrs.width ? String(a.attrs.width) : "";
      };
      return c.addEventListener("pointerdown", (d) => {
        d.preventDefault(), d.stopPropagation();
        const p = d.clientX, h = l.getBoundingClientRect().width;
        c.setPointerCapture(d.pointerId);
        const f = (b) => {
          const y = Math.max(180, i.parentElement?.clientWidth || 900);
          l.style.width = `${Math.round(Math.min(y, Math.max(120, h + b.clientX - p)))}px`;
        }, m = (b) => {
          c.releasePointerCapture(b.pointerId), c.removeEventListener("pointermove", f), c.removeEventListener("pointerup", m);
          const y = n();
          typeof y == "number" && r.view.dispatch(r.state.tr.setNodeMarkup(y, void 0, { ...a.attrs, width: l.style.width }));
        };
        c.addEventListener("pointermove", f), c.addEventListener("pointerup", m);
      }), i.append(l, c, s), u(), {
        dom: i,
        stopEvent(d) {
          return d.target === s;
        },
        update(d) {
          return d.type !== a.type ? !1 : (a = d, u(), !0);
        },
        selectNode() {
          i.classList.add("is-selected");
        },
        deselectNode() {
          i.classList.remove("is-selected");
        }
      };
    };
  }
}), Dd = es.extend({
  onCreate(t) {
    if (this.parent?.(t), !this.options.updateDocument || !this.editor.extensionManager.extensions.find((u) => ["collaboration", "collaborationCaret"].includes(u.name) && u.options.provider)?.options.provider?.synced) return;
    const { state: r, view: a } = this.editor, { attributeName: i, generateID: l, types: s } = this.options, c = r.tr;
    r.doc.descendants((u, d) => {
      (s === "all" ? !["doc", "text"].includes(u.type.name) : s.includes(u.type.name)) && u.attrs[i] === null && c.setNodeMarkup(d, void 0, { ...u.attrs, [i]: l({ node: u, pos: d }) });
    }), c.steps.length && a.dispatch(c.setStoredMarks(r.storedMarks).setMeta("addToHistory", !1).setMeta("__uniqueIDTransaction", !0));
  }
});
function tr(t, n) {
  const r = t.match(new RegExp(`(?:^|\\s)${n}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)), a = r?.[1] ?? r?.[2] ?? r?.[3] ?? "";
  try {
    return decodeURIComponent(a);
  } catch {
    return a;
  }
}
function nr(t) {
  return encodeURIComponent(t);
}
function Pd(t) {
  const n = t.match(/^::attachment\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/);
  if (n)
    return {
      type: "attachment",
      raw: n[0],
      name: tr(n[1], "name") || "附件",
      url: tr(n[1], "url"),
      mediaType: tr(n[1], "mediaType") || "application/octet-stream"
    };
}
const Gi = Hn.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "附件" },
      url: { default: "" },
      mediaType: { default: "application/octet-stream" }
    };
  },
  parseHTML() {
    return [{
      tag: "figure[data-note-attachment]",
      getAttrs: (t) => {
        const n = t;
        return {
          name: n.dataset.name || "附件",
          url: n.dataset.url || "",
          mediaType: n.dataset.mediaType || "application/octet-stream"
        };
      }
    }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["figure", Tr(t, {
      "data-note-attachment": "",
      "data-name": t.name,
      "data-url": t.url,
      "data-media-type": t.mediaType
    }), ["a", { href: t.url, target: "_blank", rel: "noreferrer" }, t.name || "附件"]];
  },
  renderMarkdown(t) {
    const n = nr(String(t.attrs?.name || "附件")), r = nr(String(t.attrs?.url || "")), a = nr(String(t.attrs?.mediaType || "application/octet-stream"));
    return `::attachment{name="${n}" url="${r}" mediaType="${a}"}

`;
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("attachment", { name: r.name, url: r.url, mediaType: r.mediaType });
  },
  markdownTokenizer: {
    name: "attachment",
    level: "block",
    start: (t) => t.search(/^::attachment\{[^\n}]*\}[ \t]*$/m),
    tokenize: (t) => Pd(t)
  }
}), Od = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, Fd = /^(\s*)>( ?)(.*)$/;
function Rd(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (a) => {
    if (a === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const i = r ? "‘" : "’";
    return r = !r, i;
  });
}
function Bd(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const w = c[1][0];
      a ? w === i && (a = !1, i = "") : (a = !0, i = w), r.push(s), l++;
      continue;
    }
    if (a) {
      r.push(s), l++;
      continue;
    }
    const u = s.match(Od);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (Hc(p)) {
      r.push(s), l++;
      continue;
    }
    const m = Uc(p), b = f.trim(), y = [`kind=${m}`];
    for (b && y.push(`label="${Rd(b)}"`), h === "-" && y.push("collapsed=true"), r.push(`${d}:::callout{${y.join(" ")}}`), l++; l < n.length; ) {
      const w = n[l];
      if (!/^\s*>/.test(w) || w.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const g = w.match(Fd);
      g ? r.push(g[3]) : r.push(w.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function jd(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      a ? u === i && (a = !1, i = "") : (a = !0, i = u), r.push(l);
      continue;
    }
    if (a) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const xa = /#[\p{L}\p{N}_][\p{L}\p{N}_-]{0,48}/gu, qd = Lr.create({
  name: "hashtagHighlight",
  addProseMirrorPlugins() {
    return [
      new an({
        key: new ti("hashtagHighlight"),
        props: {
          decorations(t) {
            const { doc: n, selection: r } = t, a = [];
            return n.descendants((i, l) => {
              if (i.type.spec.code) return !1;
              if (!i.isText || !i.text || i.marks.some((d) => d.type.spec.code) || r.empty && r.from >= l && r.from <= l + i.nodeSize) return;
              const c = i.text;
              xa.lastIndex = 0;
              let u;
              for (; (u = xa.exec(c)) !== null; ) {
                const d = l + u.index, p = d + u[0].length;
                a.push(
                  ci.inline(d, p, { class: "note-inline-tag" })
                );
              }
            }), ur.create(n, a);
          }
        }
      })
    ];
  }
}), Kd = [
  "paragraph",
  "heading",
  "blockquote",
  "codeBlock",
  "bulletList",
  "orderedList",
  "table",
  "horizontalRule",
  "image",
  "attachment",
  "blockMath",
  "directiveBlock"
], gh = 2;
function Br(t = !0, n, r = Xi, a, i = Gi, l = li.configure({ lowlight: Li })) {
  return [
    Wo.configure({
      undoRedo: t ? void 0 : !1,
      link: !1,
      codeBlock: !1
    }),
    Vo.configure({ openOnClick: !1, autolink: !0, defaultProtocol: "https" }),
    ts,
    ns,
    rs.configure({ multicolor: !0 }),
    l,
    Td.configure({ allowBase64: !1, inline: !1 }),
    i,
    Wi,
    Vi,
    Jo.configure({ table: { resizable: !0 } }),
    Dd.configure({ types: Kd }),
    r,
    ...a || [Xo.configure({
      katexOptions: { throwOnError: !1 },
      inlineOptions: { onClick: (s, c) => n?.onInlineClick?.(String(s.attrs.latex || ""), c) },
      blockOptions: { onClick: (s, c) => n?.onBlockClick?.(String(s.attrs.latex || ""), c) }
    })],
    Qo.configure({ markedOptions: { gfm: !0, breaks: !1 } }),
    qd
  ];
}
function Ji(t) {
  return Id(new di({ extensions: Br(!1) }).parse(
    Bd(jd(t))
  ));
}
function Ca(t) {
  return new di({ extensions: Br(!1) }).serialize(t);
}
const Ln = /* @__PURE__ */ new WeakMap();
let Wt = null;
function Ud() {
  return typeof IntersectionObserver > "u" ? null : (Wt || (Wt = new IntersectionObserver((t) => {
    for (const n of t) {
      if (!n.isIntersecting) continue;
      const r = Ln.get(n.target);
      r && (Ln.delete(n.target), Wt?.unobserve(n.target), r());
    }
  }, { rootMargin: "600px 0px" })), Wt);
}
function Sa({ node: t, getPos: n, editor: r }, a, i) {
  let l = t, s = !1, c = !1;
  const u = document.createElement(a ? "div" : "span");
  u.mathPosition = () => c ? void 0 : n();
  const d = document.createElement(a ? "div" : "span");
  u.className = "tiptap-mathematics-render is-deferred", u.dataset.type = a ? "block-math" : "inline-math", u.contentEditable = "false", u.draggable = !1, d.className = "math-node-content", u.append(d);
  const p = document.createElement(a ? "div" : "span");
  p.className = "math-node-editor-slot", u.append(p);
  const h = (x) => {
    x.preventDefault(), x.stopPropagation();
  };
  u.addEventListener("dragstart", h);
  const f = document.createElement("button");
  f.type = "button", f.className = "math-node-edit", f.textContent = "编辑公式", f.setAttribute("aria-label", "编辑公式"), i && u.append(f);
  const m = () => {
    const x = String(l.attrs.latex || "");
    u.dataset.latex = x, u.setAttribute("aria-label", `公式：${x}`), d.textContent = x;
  }, b = () => {
    if (c) return;
    const x = String(l.attrs.latex || "");
    try {
      ui.render(x || "\\;", d, { throwOnError: !0, displayMode: a, macros: xi }), u.classList.remove(a ? "block-math-error" : "inline-math-error"), u.removeAttribute("title");
    } catch {
      d.textContent = x, u.classList.add(a ? "block-math-error" : "inline-math-error"), u.title = "公式暂时无法显示，点击编辑后可检查写法";
    }
    x || (d.textContent = "点击输入公式"), u.classList.toggle("is-empty-math", !x), u.classList.remove("is-deferred"), s = !0;
  }, y = () => {
    const x = Ud();
    if (!x) {
      b();
      return;
    }
    Ln.set(u, b), x.observe(u);
  }, w = () => {
    Ln.delete(u), Wt?.unobserve(u);
  }, v = (x) => {
    if (p.contains(x.target) || !r.isEditable) return;
    x.preventDefault(), x.stopPropagation();
    const N = n();
    typeof N == "number" && i?.(String(l.attrs.latex || ""), N);
  }, g = (x) => {
    if (p.contains(x.target)) return;
    x.preventDefault(), x.stopPropagation();
    const N = n();
    typeof N == "number" && r.isEditable && (r.commands.setNodeSelection(N), i?.(String(l.attrs.latex || ""), N));
  };
  return f.addEventListener("click", v), u.addEventListener("dblclick", v), m(), y(), i && u.addEventListener("click", g), {
    dom: u,
    selectNode() {
      u.classList.add("ProseMirror-selectednode"), u.draggable = !1;
    },
    deselectNode() {
      u.classList.remove("ProseMirror-selectednode"), u.draggable = !1;
    },
    stopEvent: (x) => p.contains(x.target) || f.contains(x.target),
    ignoreMutation: () => !0,
    update(x) {
      return x.type !== l.type ? !1 : (l = x, u.dataset.latex = String(l.attrs.latex || ""), u.setAttribute("aria-label", `公式：${l.attrs.latex || ""}`), s ? b() : m(), !0);
    },
    destroy() {
      c = !0, u.removeEventListener("dragstart", h), w(), u.removeEventListener("click", g), u.removeEventListener("dblclick", v), f.removeEventListener("click", v);
    }
  };
}
function Hd(t) {
  const n = (i, l, s) => ({
    Enter: () => {
      const c = i.state.selection;
      return !(c instanceof Yt) || c.node.type.name !== l || !s ? !1 : (s(String(c.node.attrs.latex || ""), c.from), !0);
    }
  }), r = Yo.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "inlineMath", t.onInlineClick);
    },
    addNodeView() {
      return (i) => Sa(i, !1, t.onInlineClick);
    }
  });
  return [Go.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "blockMath", t.onBlockClick);
    },
    addNodeView() {
      return (i) => Sa(i, !0, t.onBlockClick);
    }
  }), r];
}
const Qi = {
  sin: "正弦",
  cos: "余弦",
  tan: "正切",
  cot: "余切",
  sec: "正割",
  csc: "余割",
  arcsin: "反正弦",
  arccos: "反余弦",
  arctan: "反正切",
  sinh: "双曲正弦",
  cosh: "双曲余弦",
  tanh: "双曲正切",
  coth: "双曲余切",
  exp: "指数函数",
  ln: "自然对数",
  log: "对数",
  lg: "常用对数",
  min: "最小值",
  max: "最大值",
  inf: "下确界",
  sup: "上确界",
  liminf: "下极限",
  limsup: "上极限",
  gcd: "最大公约数",
  arg: "辐角"
}, _d = { "e^x": "自然指数", "\\log_a": "任意底对数", "\\sqrt[n]{x}": "高次根号", "f'(x)": "一阶导数", "\\frac{d^2}{dx^2}": "二阶导数", "|x|": "绝对值", "\\{x\\}": "集合", "\\operatorname{span}": "线性张成", "\\ker": "核空间", "\\operatorname{Im}": "像空间", "\\operatorname{diag}": "对角矩阵", "\\frac{1}{n}": "倒数", "x^2": "平方" }, te = (t, n = t, r) => ({ latex: `\\textstyle ${t}`, insert: n, tooltip: r ?? _d[t] ?? Qi[t.replace(/^\\/, "")], class: "small" }), Wd = ["[undo]", "[redo]", "[left]", "[right]", { label: "下一格", tooltip: "移到下一个占位框", command: ["performWithFeedback", "moveToNextPlaceholder"], width: 2 }, { label: "[backspace]", width: 2 }], Ht = (t, n) => ({ id: t, label: "", displayEditToolbar: !1, rows: [...n, Wd] }), Vd = [
  { id: "basic", label: "常用", layout: Ht("note-basic", [
    ["7", "8", "9", "+", "-", te("\\frac{a}{b}", "\\frac{#0}{#?}", "分数"), te("\\sqrt{x}", "\\sqrt{#0}", "根号"), te("x^n", "#0^{#?}", "上标")],
    ["4", "5", "6", "\\times", "\\div", "(", ")", te("x_n", "#0_{#?}", "下标")],
    ["1", "2", "3", "=", "\\ne", "<", ">", "\\pi"],
    ["0", ".", "x", "y", "\\le", "\\ge", "\\pm", "\\infty"]
  ]) },
  { id: "calculus", label: "高等数学", layout: Ht("note-calculus", [
    [te("\\lim", "\\lim_{x\\to #?} #?", "极限"), te("\\frac{d}{dx}", "\\frac{d #?}{d x}", "导数"), te("\\frac{\\partial}{\\partial x}", "\\frac{\\partial #?}{\\partial x}", "偏导数"), te("\\int", "\\int #?\\,d x", "不定积分"), te("\\int_a^b", "\\int_{#?}^{#?} #?\\,d x", "定积分"), te("\\iint", "\\iint_{#?} #?\\,d x\\,d y", "二重积分"), te("\\iiint", "\\iiint_{#?} #?\\,d V", "三重积分"), te("\\oint", "\\oint_{#?} #?\\,d s", "曲线积分")],
    [te("\\sum", "\\sum_{n=#?}^{#?} #?", "求和"), te("\\prod", "\\prod_{n=#?}^{#?} #?", "连乘"), te("e^x", "e^{#?}"), te("\\ln", "\\ln\\left(#?\\right)"), te("\\log_a", "\\log_{#?}\\left(#?\\right)"), te("\\sqrt[n]{x}", "\\sqrt[#?]{#0}"), "\\infty", "\\to"],
    [te("\\sin", "\\sin\\left(#?\\right)"), te("\\cos", "\\cos\\left(#?\\right)"), te("\\tan", "\\tan\\left(#?\\right)"), te("\\arcsin", "\\arcsin\\left(#?\\right)"), "\\pi", "\\theta", "\\Delta", "\\nabla"],
    [te("f'(x)", "f^{\\prime}(#?)"), te("\\frac{d^2}{dx^2}", "\\frac{d^2 #?}{d x^2}"), te("|x|", "\\left|#0\\right|"), te("\\{\\cdots", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}", "分段函数"), "x", "n", "=", "\\approx"]
  ]) },
  { id: "discrete", label: "离散数学", layout: Ht("note-discrete", [
    ["\\neg", "\\land", "\\lor", "\\oplus", "\\implies", "\\iff", "\\forall", "\\exists"],
    ["\\in", "\\notin", "\\subset", "\\subseteq", "\\cup", "\\cap", "\\setminus", "\\varnothing"],
    [te("\\{x\\}", "\\left\\{#0\\right\\}"), te("|A|", "\\left|#0\\right|", "集合基数"), "\\mathbb{N}", "\\mathbb{Z}", "\\mathbb{Q}", "\\mathbb{R}", "\\times", "\\mathcal{P}"],
    [te("\\binom{n}{k}", "\\binom{#?}{#?}", "组合数"), te("n!", "#0!", "阶乘"), te("\\sum", "\\sum_{#?}^{#?}#?"), "\\equiv", te("\\pmod{n}", "\\pmod{#?}", "模运算"), "\\mapsto", "\\vdash", "\\models"]
  ]) },
  { id: "linear", label: "线性代数", layout: Ht("note-linear", [
    [te("\\vec{a}", "\\vec{#0}", "向量"), te("\\mathbf{A}", "\\mathbf{#0}", "粗体矩阵"), te("A^{\\mathsf T}", "#0^{\\mathsf T}", "转置"), te("A^{-1}", "#0^{-1}", "逆矩阵"), te("\\det A", "\\det\\left(#?\\right)", "行列式"), te("\\operatorname{rank}", "\\operatorname{rank}\\left(#?\\right)", "秩"), te("\\operatorname{tr}", "\\operatorname{tr}\\left(#?\\right)", "迹"), "\\lambda"],
    [te("\\lVert x\\rVert", "\\left\\lVert #0\\right\\rVert", "范数"), te("\\langle u,v\\rangle", "\\left\\langle #?,#?\\right\\rangle", "内积"), "\\cdot", "\\times", "\\otimes", "\\perp", "\\mathbb{R}", "\\mathbb{C}"],
    [te("\\operatorname{span}", "\\operatorname{span}\\left(#?\\right)"), te("\\ker", "\\ker\\left(#?\\right)"), te("\\operatorname{Im}", "\\operatorname{Im}\\left(#?\\right)"), te("\\operatorname{diag}", "\\operatorname{diag}\\left(#?\\right)"), "\\alpha", "\\beta", "\\mu", "\\sigma"],
    ["a", "b", "x", "=", "\\sim", "\\cdots", "\\vdots", "\\ddots"]
  ]) },
  { id: "probability", label: "概率统计", layout: Ht("note-probability", [
    [te("P(A)", "P\\left(#?\\right)", "概率"), te("P(A\\mid B)", "P\\left(#?\\mid #?\\right)", "条件概率"), te("E(X)", "E\\left(#?\\right)", "期望"), te("\\operatorname{Var}", "\\operatorname{Var}\\left(#?\\right)", "方差"), te("\\operatorname{Cov}", "\\operatorname{Cov}\\left(#?,#?\\right)", "协方差"), "\\mu", "\\sigma", "\\rho"],
    [te("\\bar{x}", "\\bar{#0}", "均值"), te("\\hat{\\theta}", "\\hat{#0}", "估计量"), te("\\binom{n}{k}", "\\binom{#?}{#?}"), te("n!", "#0!"), te("\\sum", "\\sum_{i=1}^{#?}#?"), te("\\prod", "\\prod_{i=1}^{#?}#?"), te("\\frac{1}{n}", "\\frac{1}{#?}"), te("x^2", "#0^2")],
    [te("\\mathcal{N}", "\\mathcal{N}\\left(#?,#?\\right)", "正态分布"), te("\\operatorname{Bin}", "\\operatorname{Bin}\\left(#?,#?\\right)", "二项分布"), te("\\operatorname{Pois}", "\\operatorname{Pois}\\left(#?\\right)", "泊松分布"), "\\sim", "\\Phi", "\\phi", "\\chi^2", "\\alpha"],
    ["X", "Y", "n", "p", "\\cap", "\\cup", "\\le", "\\ge"]
  ]) },
  { id: "letters", label: "abc", layout: "alphabetic" },
  { id: "greek", label: "αβγ", layout: "greek" }
], Zi = [
  ["pmatrix", "圆括号 ( )"],
  ["bmatrix", "方括号 [ ]"],
  ["vmatrix", "行列式 | |"],
  ["Vmatrix", "双竖线 ‖ ‖"],
  ["Bmatrix", "花括号 { }"],
  ["matrix", "无括号"]
];
function el(t, n, r) {
  if (!Number.isInteger(t) || !Number.isInteger(n) || t < 1 || n < 1 || t > 10 || n > 10) throw new RangeError("Matrix dimensions must be between 1 and 10");
  if (!Zi.some(([a]) => a === r)) throw new RangeError("Unsupported matrix style");
  return `\\begin{${r}}${Array.from({ length: t }, () => Array(n).fill("#?").join(" & ")).join(" \\\\ ")}\\end{${r}}`;
}
const Xd = [
  ["basic", "常用"],
  ["letters", "字母"],
  ["calculus", "微积分"],
  ["discrete", "集合与逻辑"],
  ["linear", "线性代数"],
  ["probability", "概率统计"],
  ["relations", "关系与运算"],
  ["arrows", "箭头"],
  ["greek", "希腊字母"],
  ["accents", "修饰与括号"],
  ["fonts", "数学字体"]
], tl = [], kr = /* @__PURE__ */ new Map();
function ct(t, n, r, a = n) {
  const i = kr.get(a);
  if (i) {
    i.categories.includes(t) || i.categories.push(t), i.aliases += ` ${nn(r)}`, !/[\u3400-\u9fff]/.test(i.label) && /[\u3400-\u9fff]/.test(r) && (i.label = r);
    return;
  }
  const l = { id: encodeURIComponent(a), category: t, categories: [t], latex: n, label: r, insert: a, aliases: nn(r, n, a) };
  kr.set(a, l), tl.push(l);
}
for (const t of Vd)
  if (!(typeof t.layout == "string" || !("rows" in t.layout)))
    for (const n of t.layout.rows.slice(0, -1)) for (const r of n) {
      const a = typeof r == "string" ? r : r.latex;
      !a || a.startsWith("[") || ct(t.id, a, typeof r == "string" ? r.replaceAll("\\", "") : r.tooltip ?? a.replace(/\\textstyle\s*/g, "").replaceAll("\\", ""), typeof r == "string" ? r : r.insert ?? a);
    }
function vt(t, n) {
  for (const r of n.split("|")) {
    const [a, i] = r.split(":");
    ct(t, `\\${a}`, i?.split(" ")[0] ?? a), i && (kr.get(`\\${a}`).aliases += ` ${nn(i)}`);
  }
}
vt("relations", "sim:相似 服从分布 波浪号 similar distributed|approx:约等于 近似等于 approximately|times:乘 叉乘 multiplication|cdot:点乘 点积|otimes:张量积 克罗内克积|perp:垂直 正交|pm:正负|ne:不等于|le:小于等于|ge:大于等于|equiv:恒等 等价|cdots:横向省略号|vdots:竖向省略号|ddots:对角省略号");
vt("discrete", "neg:逻辑非|land:逻辑与 合取|lor:逻辑或 析取|oplus:异或 直和|implies:蕴含 推出|iff:当且仅当 等价|forall:任意 全称量词|exists:存在 存在量词|in:属于|notin:不属于|subset:真子集|subseteq:子集 包含于|cup:并集|cap:交集|setminus:差集|varnothing:空集|mapsto:映射到|vdash:推导|models:满足 模型");
vt("relations", "leq:小于等于|geq:大于等于|neq:不等于|ll:远小于|gg:远大于|lesssim:小于或近似|gtrsim:大于或近似|lessapprox:小于或约等于|gtrapprox:大于或约等于|prec:先于|succ:后于|preceq:先于或等于|succeq:后于或等于|simeq:渐近相等|simcolon:相似冒号|simcoloncolon:相似双冒号|cong:全等|asymp:渐近等价|propto:成比例|doteq:定义等于|triangleq:定义等于三角|leqq:小于双等号|geqq:大于双等号|lneq:小于且不等于|gneq:大于且不等于|nless:不小于|ngtr:不大于|nleq:不小于等于|ngeq:不大于等于|ncong:不全等|nsim:不相似|parallel:平行|nparallel:不平行|mid:整除|nmid:不整除|mp:减加|div:除法|ast:星号乘法|star:星形运算|circ:复合运算|bullet:点积实心点|diamond:菱形运算|odot:圈点积|ominus:圈减|oslash:圈除|bigcirc:圆运算|amalg:并合|wr:环绕积|dagger:匕首伴随|ddagger:双匕首|angle:角|measuredangle:有向角|sphericalangle:球面角|degree:度");
vt("discrete", "ni:包含元素|subsetneq:真子集|supset:超集|supseteq:超集或相等|supsetneq:真超集|nsubseteq:不是子集|nsupseteq:不是超集|emptyset:空集|uplus:不交并|sqcup:方并|sqcap:方交|sqsubseteq:方子集|sqsupseteq:方超集|bigcup:大并集|bigcap:大交集|biguplus:大不交并|bigsqcup:大方并|bigvee:大析取|bigwedge:大合取|wedge:合取|vee:析取|lnot:逻辑非|nexists:不存在|top:真|bot:假|vDash:语义蕴涵|Vdash:强制|dashv:逆推出|nvdash:不可推导|nvDash:不语义蕴涵|therefore:所以|because:因为|aleph:阿列夫基数|beth:贝斯基数|complement:补集|triangleleft:左三角关系|triangleright:右三角关系");
vt("arrows", "leftarrow:左箭头|rightarrow:右箭头|leftrightarrow:双向箭头|Leftarrow:左双箭头|Rightarrow:右双箭头|Leftrightarrow:左右双箭头|longleftarrow:长左箭头|longrightarrow:长右箭头|longleftrightarrow:长双向箭头|Longleftarrow:长左双箭头|Longrightarrow:长右双箭头|Longleftrightarrow:长左右双箭头|longmapsto:长映射箭头|hookleftarrow:左钩箭头|hookrightarrow:右钩箭头|uparrow:上箭头|downarrow:下箭头|updownarrow:上下箭头|Uparrow:上双箭头|Downarrow:下双箭头|Updownarrow:上下双箭头|nearrow:右上箭头|searrow:右下箭头|swarrow:左下箭头|nwarrow:左上箭头|leftharpoonup:左上鱼叉|leftharpoondown:左下鱼叉|rightharpoonup:右上鱼叉|rightharpoondown:右下鱼叉|rightleftharpoons:可逆反应|leftrightharpoons:左右鱼叉|twoheadrightarrow:满射|twoheadleftarrow:左双头箭头|rightarrowtail:单射尾箭头|leftarrowtail:左尾箭头|rightsquigarrow:波浪箭头|leadsto:导向|curvearrowleft:左弯箭头|curvearrowright:右弯箭头|circlearrowleft:逆时针箭头|circlearrowright:顺时针箭头|nrightarrow:非右箭头|nleftarrow:非左箭头|nRightarrow:不蕴涵|nLeftrightarrow:不等价");
vt("greek", "alpha:阿尔法 alpha|beta:贝塔 beta|gamma:伽马 gamma|delta:德尔塔 delta|epsilon:艾普西隆 epsilon|zeta:泽塔 zeta|eta:伊塔 eta|theta:西塔 theta|iota:约塔 iota|kappa:卡帕 kappa|lambda:兰姆达 lambda|mu:缪 mu|nu:纽 nu|xi:克西 xi|omicron:奥米克戎 omicron|pi:派 pi|rho:柔 rho|sigma:西格玛 sigma|tau:陶 tau|upsilon:宇普西隆 upsilon|phi:斐 phi|chi:卡 chi|psi:普西 psi|omega:欧米伽 omega|Gamma:大写伽马|Delta:大写德尔塔|Theta:大写西塔|Lambda:大写兰姆达|Xi:大写克西|Pi:大写派|Sigma:大写西格玛|Upsilon:大写宇普西隆|Phi:大写斐|Psi:大写普西|Omega:大写欧米伽|varepsilon:变体艾普西隆|vartheta:变体西塔|varpi:变体派|varrho:变体柔|varsigma:末尾西格玛|varphi:变体斐|varkappa:变体卡帕");
vt("calculus", "partial:偏导 partial|infty:无穷 infinity|nabla:梯度 nabla|hbar:约化普朗克常量|ell:花体长度|Re:实部|Im:虚部|prime:一阶导撇号");
for (const [t, n] of Object.entries(Qi)) ct("calculus", `\\${t}`, `${n} ${t}`, `\\${t}\\left(#?\\right)`);
for (const [t, n] of [["hat", "帽"], ["widehat", "宽帽"], ["bar", "横线"], ["overline", "上划线"], ["underline", "下划线"], ["vec", "向量"], ["overrightarrow", "右向量"], ["overleftarrow", "左向量"], ["overleftrightarrow", "双向量"], ["dot", "一阶点导数"], ["ddot", "二阶点导数"], ["tilde", "波浪修饰"], ["widetilde", "宽波浪"], ["check", "抑扬符"], ["breve", "短音符"], ["acute", "尖音符"], ["grave", "重音符"]]) ct("accents", `\\${t}{x}`, n, `\\${t}{#0}`);
for (const [t, n, r] of [["(", ")", "圆括号"], ["[", "]", "方括号"], ["\\{", "\\}", "集合花括号"], ["|", "|", "绝对值"], ["\\lVert", "\\rVert", "范数"], ["\\langle", "\\rangle", "内积括号"], ["\\lfloor", "\\rfloor", "向下取整"], ["\\lceil", "\\rceil", "向上取整"]]) ct("accents", `\\left${t} x\\right${n}`, r, `\\left${t} #0\\right${n}`);
for (const [t, n, r] of [["mathbb", "NZQRCFHP", "黑板粗体"], ["mathcal", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "花体"], ["mathfrak", "gabh", "哥特体"], ["mathbf", "ABuvx", "粗体"]]) for (const a of n) ct("fonts", `\\${t}{${a}}`, `${r} ${a}`);
for (const [t, n, r] of [
  ["\\underbrace{x+y}_{n}", "下括注", "\\underbrace{#0}_{#?}"],
  ["\\overbrace{x+y}^{n}", "上括注", "\\overbrace{#0}^{#?}"],
  ["\\overset{a}{=}", "上方标注", "\\overset{#?}{#0}"],
  ["\\underset{a}{=}", "下方标注", "\\underset{#?}{#0}"],
  ["\\xrightarrow{f}", "带标注箭头", "\\xrightarrow{#?}"],
  ["\\begin{aligned}a&=b\\\\c&=d\\end{aligned}", "多行对齐方程", "\\begin{aligned}#? &= #? \\\\ #? &= #?\\end{aligned}"]
]) ct("accents", t, n, r);
for (const t of "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") ct("letters", t, `字母 ${t}`);
const st = tl;
function Yd(t) {
  const n = t.trim().toLowerCase().split(/\s+/);
  return st.filter((r) => n.every((a) => r.aliases.includes(a)));
}
const yt = "fp:math-preferences-changed";
let At;
function yh(t) {
  At = t, typeof window < "u" && window.dispatchEvent(new Event(yt));
}
const Vn = {
  getItem(t) {
    if (At) return At.getItem(t);
    try {
      return globalThis.localStorage?.getItem(t) ?? null;
    } catch {
      return null;
    }
  },
  setItem(t, n) {
    At ? At.setItem(t, n) : globalThis.localStorage?.setItem(t, n), typeof window < "u" && window.dispatchEvent(new Event(yt));
  }
};
async function Gd() {
  await At?.refresh?.(), typeof window < "u" && window.dispatchEvent(new Event(yt));
}
const nl = "fp.math.symbols.v1";
function Ma() {
  try {
    const t = JSON.parse(Vn.getItem(nl) ?? "{}");
    return { favorites: Array.isArray(t.favorites) ? t.favorites.filter((n) => typeof n == "string") : [], recent: Array.isArray(t.recent) ? t.recent.filter((n) => typeof n == "string") : [] };
  } catch {
    return { favorites: [], recent: [] };
  }
}
const Jd = new Map(st.map((t) => [t.id, ui.renderToString(t.latex, { throwOnError: !1, trust: !1, strict: !1 })]));
function Qd({ onInsert: t, shortcuts: n, onCommand: r }) {
  const [a, i] = k("basic"), [l, s] = k(""), [c, u] = k({}), [d, p] = k(8), [h, f] = k(Ma), [m, b] = k(null), y = B(null);
  Y(() => {
    const S = () => f(Ma());
    return window.addEventListener(yt, S), window.addEventListener("storage", S), () => {
      window.removeEventListener(yt, S), window.removeEventListener("storage", S);
    };
  }, []), Y(() => {
    if (!y.current) return;
    const S = () => {
      const T = y.current?.clientWidth ?? 0;
      p(Math.max(4, Math.min(20, Math.floor(T / 56))));
    };
    S();
    const I = new ResizeObserver(S);
    return I.observe(y.current), () => I.disconnect();
  }, []);
  const w = He(() => {
    if (l.trim()) {
      const S = new Set(n.filter((T) => T.trigger.toLowerCase().includes(l.toLowerCase())).map((T) => T.replacement)), I = new Set(Yd(l));
      return st.filter((T) => I.has(T) || S.has(T.insert));
    }
    return a === "recent" ? h.recent.map((S) => st.find((I) => I.id === S)).filter((S) => !!S) : a === "favorites" ? st.filter((S) => h.favorites.includes(S.id)) : st.filter((S) => S.categories.includes(a));
  }, [a, l, h, n]), v = d * (d <= 7 ? 3 : 4), g = l ? `search:${l}` : a, x = Math.max(1, Math.ceil(w.length / v)), N = Math.min(c[g] ?? 0, x - 1), C = w.slice(N * v, (N + 1) * v), A = st.find((S) => S.id === m), L = A && n.find((S) => S.enabled && S.replacement === A.insert), U = (S) => {
    f(S);
    try {
      Vn.setItem(nl, JSON.stringify(S));
    } catch {
    }
  };
  return /* @__PURE__ */ o("div", { className: "math-symbol-palette", ref: y, children: [
    /* @__PURE__ */ e("div", { className: "math-keyboard-navigation", "aria-label": "键盘操作", children: [["undo", "撤销"], ["redo", "重做"], ["moveToPreviousChar", "←"], ["moveToNextChar", "→"], ["moveToPreviousPlaceholder", "上一空位"], ["moveToNextPlaceholder", "下一空位"], ["deleteBackward", "退格"]].map(([S, I]) => /* @__PURE__ */ e("button", { type: "button", onMouseDown: (T) => T.preventDefault(), onClick: () => r?.(S), children: I }, S)) }),
    /* @__PURE__ */ e("div", { className: "math-symbol-categories", role: "tablist", "aria-label": "符号分类", children: [["recent", "最近"], ["favorites", "收藏"], ...Xd].map(([S, I]) => /* @__PURE__ */ e("button", { type: "button", role: "tab", "aria-selected": !l && a === S, onMouseDown: (T) => T.preventDefault(), onClick: () => {
      i(S), s("");
    }, children: I }, S)) }),
    /* @__PURE__ */ o("div", { className: "math-symbol-search", children: [
      /* @__PURE__ */ e(Je, { size: 15 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索数学符号", placeholder: "搜索名称、LaTeX 或快捷词", value: l, onChange: (S) => s(S.target.value) }),
      /* @__PURE__ */ o("span", { children: [
        w.length,
        " 项"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "math-symbol-grid", style: { gridTemplateColumns: `repeat(${d}, minmax(0, 1fr))` }, children: C.map((S) => /* @__PURE__ */ o("div", { className: "math-symbol-cell", children: [
      /* @__PURE__ */ e("button", { type: "button", className: "math-symbol-insert", "aria-label": `插入${S.label}`, title: `${S.label} · ${S.insert}`, onMouseDown: (I) => I.preventDefault(), onFocus: () => b(S.id), onMouseEnter: () => b(S.id), onClick: () => {
        t(S.insert), b(S.id), U({ ...h, recent: [S.id, ...h.recent.filter((I) => I !== S.id)].slice(0, 40) });
      }, children: /* @__PURE__ */ e("span", { "aria-hidden": "true", dangerouslySetInnerHTML: { __html: Jd.get(S.id) ?? "" } }) }),
      /* @__PURE__ */ e("button", { type: "button", className: `math-symbol-star${h.favorites.includes(S.id) ? " is-favorite" : ""}`, "aria-label": `${h.favorites.includes(S.id) ? "取消收藏" : "收藏"}${S.label}`, "aria-pressed": h.favorites.includes(S.id), onMouseDown: (I) => I.preventDefault(), onClick: () => U({ ...h, favorites: h.favorites.includes(S.id) ? h.favorites.filter((I) => I !== S.id) : [...h.favorites, S.id] }), children: /* @__PURE__ */ e(Jr, { size: 10 }) })
    ] }, S.id)) }),
    !w.length && /* @__PURE__ */ e("p", { className: "note-math-status", children: l ? "没有找到匹配符号，请尝试名称或 LaTeX 命令。" : a === "favorites" ? "选择符号后点按星标，将常用符号放在这里。" : "使用过的符号会显示在这里。" }),
    /* @__PURE__ */ o("div", { className: "math-symbol-footer", children: [
      A && /* @__PURE__ */ e("button", { type: "button", className: "math-mobile-favorite", "aria-label": `${h.favorites.includes(A.id) ? "取消收藏" : "收藏"}${A.label}`, onClick: () => U({ ...h, favorites: h.favorites.includes(A.id) ? h.favorites.filter((S) => S !== A.id) : [...h.favorites, A.id] }), children: /* @__PURE__ */ e(Jr, { size: 18 }) }),
      /* @__PURE__ */ e("span", { className: "math-symbol-detail", children: A ? /* @__PURE__ */ o(Z, { children: [
        A.label,
        " ",
        /* @__PURE__ */ e("code", { children: A.insert }),
        L && /* @__PURE__ */ o("kbd", { children: [
          L.trigger,
          L.mode === "tab" ? " ⇥" : ""
        ] })
      ] }) : "选中公式片段后，点击符号可替换选区" }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上一页符号", disabled: N === 0, onMouseDown: (S) => S.preventDefault(), onClick: () => u((S) => ({ ...S, [g]: N - 1 })), children: /* @__PURE__ */ e(Mr, { size: 14 }) }),
        /* @__PURE__ */ o("span", { "aria-live": "polite", children: [
          N + 1,
          " / ",
          x
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下一页符号", disabled: N + 1 >= x, onMouseDown: (S) => S.preventDefault(), onClick: () => u((S) => ({ ...S, [g]: N + 1 })), children: /* @__PURE__ */ e(Ie, { size: 14 }) })
      ] })
    ] })
  ] });
}
const rl = "fp.math.shortcuts.v1", Zd = { a: "alpha", b: "beta", g: "gamma", d: "delta", e: "epsilon", z: "zeta", h: "eta", t: "theta", i: "iota", k: "kappa", l: "lambda", m: "mu", n: "nu", x: "xi", p: "pi", r: "rho", s: "sigma", u: "upsilon", f: "phi", c: "chi", j: "psi", o: "omega", G: "Gamma", D: "Delta", T: "Theta", L: "Lambda", X: "Xi", P: "Pi", S: "Sigma", U: "Upsilon", F: "Phi", J: "Psi", O: "Omega" }, al = [
  { trigger: "mat", replacement: "\\begin{pmatrix}#?\\end{pmatrix}", mode: "tab", enabled: !0, kind: "matrix" },
  ...Object.entries(Zd).map(([t, n]) => ({ trigger: `@${t}`, replacement: `\\${n}`, mode: "auto", enabled: !0 })),
  { trigger: "//", replacement: "\\frac{#?}{#?}", mode: "auto", enabled: !0 },
  ...[["sum", "\\sum_{#?}^{#?}#?"], ["lim", "\\lim_{#?\\to #?}#?"], ["sqrt", "\\sqrt{#?}"], ["int", "\\int_{#?}^{#?}#?\\,d x"], ["cases", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}"], ["vec", "\\vec{#?}"], ["frac", "\\frac{#?}{#?}"]].map(([t, n]) => ({ trigger: t, replacement: n, mode: "tab", enabled: !0 }))
];
function eu(t, n) {
  const r = t.match(/(10|[1-9])x(10|[1-9])$/);
  if (!r) return null;
  const a = n.find((i) => i.kind === "matrix" && i.enabled && t.endsWith(i.trigger + r[0]));
  return a ? { length: a.trigger.length + r[0].length, replacement: el(Number(r[1]), Number(r[2]), "pmatrix") } : null;
}
function il(t) {
  const n = /* @__PURE__ */ new Set();
  for (const a of t) {
    if (!a.trigger.trim() || /\s/.test(a.trigger) || a.trigger.length > 40 || !a.replacement.trim()) return "请填写有效的触发词和公式，触发词不能含空格。";
    if (n.has(a.trigger)) return `触发词 ${a.trigger} 重复，请修改。`;
    n.add(a.trigger);
  }
  const r = t.filter((a) => a.enabled && a.mode === "auto");
  for (const a of r) for (const i of r) if (a !== i && i.trigger.startsWith(a.trigger)) return `${a.trigger} 与 ${i.trigger} 会提前触发，请改用 Tab 展开。`;
  return null;
}
function Ea() {
  try {
    const t = JSON.parse(Vn.getItem(rl) ?? "null");
    if (Array.isArray(t) && t.every((n) => n && typeof n.trigger == "string" && typeof n.replacement == "string" && ["auto", "tab"].includes(n.mode) && typeof n.enabled == "boolean") && !il(t)) return t;
  } catch {
  }
  return al.map((t) => ({ ...t }));
}
function tu(t, n, r) {
  const a = t.inlineShortcuts, i = { ...a };
  for (const u of Object.keys(i))
    (u === "@" || n.some((d) => d.enabled && d.trigger.startsWith(u) && d.trigger !== u)) && delete i[u];
  for (const u of n)
    delete i[u.trigger], u.enabled && u.mode === "auto" && (i[u.trigger] = u.replacement);
  i["*"] = "\\ast", t.inlineShortcuts = i, t.inlineShortcutTimeout = 0;
  let l = [];
  const s = () => {
    l = [];
  }, c = (u) => {
    if (u.isComposing || u.keyCode === 229 || u.ctrlKey || u.metaKey || u.altKey) {
      s();
      return;
    }
    if (u.key === "Tab" && !u.shiftKey) {
      const d = l.map((y) => y.key).join(""), p = [...n].filter((y) => y.enabled && y.mode === "tab" && d.endsWith(y.trigger)).sort((y, w) => w.trigger.length - y.trigger.length)[0], h = eu(d, n), f = p?.replacement ?? h?.replacement, m = p?.trigger.length ?? h?.length ?? 0, b = l[l.length - m]?.position;
      if (f && b !== void 0 && t.position >= b) {
        u.preventDefault(), u.stopImmediatePropagation(), t.selection = { ranges: [[b, t.position]] }, t.insert(f, { selectionMode: "placeholder" }), r(), s();
        return;
      }
    }
    u.key.length === 1 ? (l.push({ key: u.key, position: t.position }), l = l.slice(-64)) : s();
  };
  return t.addEventListener("keydown", c, !0), t.addEventListener("pointerdown", s), t.addEventListener("blur", s), () => {
    t.removeEventListener("keydown", c, !0), t.removeEventListener("pointerdown", s), t.removeEventListener("blur", s), t.isConnected && (t.inlineShortcuts = a);
  };
}
function nu({ rules: t, onSave: n, onClose: r }) {
  const [a, i] = k(t.map((p) => ({ ...p }))), [l, s] = k(""), [c, u] = k(""), d = (p, h) => {
    i((f) => f.map((m, b) => b === p ? { ...m, ...h } : m)), u("");
  };
  return /* @__PURE__ */ o("section", { className: "math-shortcut-settings", "aria-label": "公式快捷输入设置", children: [
    /* @__PURE__ */ o("div", { className: "math-shortcut-heading", children: [
      /* @__PURE__ */ e("strong", { children: "快捷输入" }),
      /* @__PURE__ */ e("input", { "aria-label": "查找快捷规则", placeholder: "查找触发词或命令", value: l, onChange: (p) => s(p.target.value) }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        i(al.map((p) => ({ ...p }))), u("");
      }, children: "恢复默认" })
    ] }),
    /* @__PURE__ */ e("p", { children: "触屏可使用数学键盘；使用实体键盘时，在公式中输入 @a 得到 α；sum 后按 Tab 展开求和。mat3x4 后按 Tab 插入矩阵。Tab / Shift+Tab 切换占位框。" }),
    /* @__PURE__ */ e("div", { className: "math-shortcut-list", children: a.map((p, h) => `${p.trigger} ${p.replacement}`.toLowerCase().includes(l.toLowerCase()) ? /* @__PURE__ */ o("div", { className: "math-shortcut-row", children: [
      /* @__PURE__ */ e("input", { type: "checkbox", "aria-label": `启用规则 ${h + 1}`, checked: p.enabled, onChange: (f) => d(h, { enabled: f.target.checked }) }),
      /* @__PURE__ */ e("input", { "aria-label": `触发词 ${h + 1}`, value: p.trigger, onChange: (f) => d(h, { trigger: f.target.value }) }),
      /* @__PURE__ */ e("input", { "aria-label": `替换公式 ${h + 1}`, readOnly: p.kind === "matrix", value: p.kind === "matrix" ? "接行数 x 列数，例如 3x4（1–10）" : p.replacement, onChange: (f) => d(h, { replacement: f.target.value }) }),
      /* @__PURE__ */ e(we, { label: `触发方式 ${h + 1}`, disabled: p.kind === "matrix", value: p.mode, onChange: (f) => d(h, { mode: f }), options: [{ value: "auto", label: "自动" }, { value: "tab", label: "Tab" }] }),
      /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除规则 ${h + 1}`, onClick: () => i((f) => f.filter((m, b) => b !== h)), children: "×" })
    ] }, h) : null) }),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    /* @__PURE__ */ o("div", { className: "math-shortcut-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        s(""), i((p) => [...p, { trigger: "", replacement: "", mode: "tab", enabled: !0 }]);
      }, children: "添加规则" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => i((p) => p.map((h) => ({ ...h, enabled: !1 }))), children: "全部停用" }),
      /* @__PURE__ */ e("span", {}),
      /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "取消" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        const p = il(a);
        if (p) {
          u(p);
          return;
        }
        try {
          Vn.setItem(rl, JSON.stringify(a));
        } catch {
          u("浏览器无法保存设置，请检查存储权限。");
          return;
        }
        n(a), r();
      }, children: "保存规则" })
    ] })
  ] });
}
function ru({ anchor: t, items: n, activeId: r, onSelect: a, label: i = "输入建议" }) {
  const l = B(null), s = jt(t, n.length > 0), [c, u] = k({ left: 8, top: 8, maxHeight: 280 });
  return Ce(() => {
    if (!n.length) return;
    const d = () => {
      if (!t.current || !l.current) return;
      const p = t.current.getBoundingClientRect(), h = l.current.getBoundingClientRect(), f = innerHeight - p.bottom - 16, m = p.top - 16, b = f < Math.min(h.height, 180) && m > f, y = Math.max(80, Math.min(280, b ? m : f));
      u({ left: Math.max(8, Math.min(p.left, innerWidth - h.width - 8)), top: b ? Math.max(8, p.top - Math.min(h.height, y) - 6) : p.bottom + 6, maxHeight: y });
    };
    return d(), window.addEventListener("resize", d), document.addEventListener("scroll", d, !0), () => {
      window.removeEventListener("resize", d), document.removeEventListener("scroll", d, !0);
    };
  }, [t, n]), Ce(() => {
    l.current?.querySelector('[aria-selected="true"]')?.scrollIntoView?.({ block: "nearest" });
  }, [r]), n.length ? Te(/* @__PURE__ */ e("div", { ref: l, role: "listbox", "aria-label": i, className: "fp-popup-panel fp-suggestion-list", style: { ...s, ...c }, onPointerDown: (d) => d.preventDefault(), children: n.map((d) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": d.id === r, onClick: () => a(d.id), children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: d.label }),
      d.detail && /* @__PURE__ */ e("small", { children: d.detail })
    ] }),
    d.preview && /* @__PURE__ */ e("span", { className: "fp-suggestion-preview", children: d.preview })
  ] }, d.id)) }), document.body) : null;
}
let $a = 0;
function au({ anchor: t }) {
  const n = B(null), [r, a] = k([]);
  return Y(() => {
    let i;
    const l = () => {
      const u = n.current, d = t.current?.contains(document.activeElement) && u?.classList.contains("is-visible") ? [...u.querySelectorAll("li[data-command]")].map((p) => {
        const h = p.dataset.command;
        return { id: h, label: st.find((f) => f.latex === h)?.label || h, markup: p.querySelector(".ML__popover__command")?.innerHTML || "", active: p.classList.contains("ML__popover__current") };
      }) : [];
      a((p) => JSON.stringify(p) === JSON.stringify(d) ? p : d);
    }, s = () => {
      const u = document.getElementById("mathlive-suggestion-popover");
      u !== n.current && (i?.disconnect(), n.current = u, u && (u.setAttribute("aria-hidden", "true"), i = new MutationObserver(l), i.observe(u, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["class", "style"] })), l());
    };
    $a++, document.documentElement.dataset.fpMathCandidates = "true", document.addEventListener("focusin", l), document.addEventListener("focusout", l);
    const c = new MutationObserver(s);
    return c.observe(document.body, { childList: !0 }), s(), () => {
      c.disconnect(), i?.disconnect(), document.removeEventListener("focusin", l), document.removeEventListener("focusout", l), --$a === 0 && (n.current?.removeAttribute("aria-hidden"), delete document.documentElement.dataset.fpMathCandidates);
    };
  }, []), /* @__PURE__ */ e(ru, { anchor: t, label: "公式输入建议", activeId: r.find((i) => i.active)?.id, items: r.map((i) => ({ id: i.id, label: i.label, detail: i.id, preview: /* @__PURE__ */ e("span", { dangerouslySetInnerHTML: { __html: i.markup } }) })), onSelect: (i) => {
    [...n.current?.querySelectorAll("li[data-command]") || []].find((s) => s.dataset.command === i)?.dispatchEvent(new MouseEvent("click", { bubbles: !0 }));
  } });
}
const bn = /* @__PURE__ */ new WeakMap();
function ll(t) {
  bn.get(t)?.();
}
function iu(t, n, r, a) {
  ll(t);
  const i = { duration: 220, easing: "cubic-bezier(.2,0,0,1)" }, l = t.animate([{ height: `${r}px`, overflow: "clip" }, { height: `${a}px`, overflow: "clip" }], i), s = t.animate([{ opacity: 0 }, { opacity: 0, offset: 0.35 }, { opacity: 1 }], i), c = n.animate([{ height: `${r}px`, opacity: 1 }, { height: `${a}px`, opacity: 0 }], i), u = () => {
    bn.get(t) === u && (bn.delete(t), n.remove(), l.cancel(), s.cancel(), c.cancel());
  };
  bn.set(t, u), c.onfinish = u, c.oncancel = u;
}
const lu = [
  ["分数", "\\frac{#0}{#?}"],
  ["根号", "\\sqrt{#0}"],
  ["上标", "#0^{#?}"],
  ["下标", "#0_{#?}"],
  ["积分", "\\int_{#?}^{#?} #? \\,d#?"],
  ["求和", "\\sum_{#?}^{#?} #?"]
], Vt = /* @__PURE__ */ new WeakMap();
function vh(t, n, r) {
  const a = () => Vt.set(t, { editor: n, open: r }), i = (l) => {
    (!(l.target instanceof Element) || !l.target.closest(".visual-directive-editor,.fp-card-editor-frame")) && Vt.delete(t);
  };
  return n.on("focus", a), t.view.dom.addEventListener("pointerdown", i, !0), a(), () => {
    n.off("focus", a), t.view.dom.removeEventListener("pointerdown", i, !0), Vt.get(t)?.editor === n && Vt.delete(t);
  };
}
function wh(t, n, r) {
  const a = Vt.get(t);
  a && !a.editor.isDestroyed && a.editor.view.dom.isConnected ? a.open(a.editor, n) : r(t, n);
}
function rr(t) {
  si.getState(t.state)?.undoManager.stopCapturing(), t.view.dispatch(oi(t.state.tr));
}
function ou() {
  const [t, n] = k(null), r = B(null), a = xe((l) => {
    if (l && r.current?.id !== l) return;
    const s = r.current;
    r.current = null, n(null), s && !s.editor.isDestroyed && rr(s.editor);
  }, []);
  return {
    open: xe(
      (l, s, c, u) => {
        if (!l.isEditable) return;
        if (c === void 0) {
          rr(l);
          const f = u ?? l.state.selection;
          l.chain().insertContentAt(
            { from: f.from, to: f.to },
            {
              type: s ? "blockMath" : "inlineMath",
              attrs: { latex: "" }
            }
          ).command(({ tr: m }) => (m.mapping.maps.at(-1)?.forEach((b, y, w, v) => {
            m.doc.nodesBetween(w, v, (g, x) => {
              if (g.type.name === (s ? "blockMath" : "inlineMath"))
                return c = x, !1;
            });
          }), !0)).run();
        }
        if (c === void 0) return;
        const d = l.view.nodeDOM(c), p = d?.querySelector(".math-node-editor-slot");
        if (!d?.mathPosition || !p || r.current?.host === d)
          return;
        a(), rr(l);
        const h = {
          id: crypto.randomUUID(),
          editor: l,
          display: s,
          host: d,
          slot: p,
          collapsedHeight: d.getBoundingClientRect().height,
          original: String(l.state.doc.nodeAt(c)?.attrs.latex ?? "")
        };
        r.current = h, n(h);
      },
      [a]
    ),
    card: t ? /* @__PURE__ */ e(su, { session: t, onClose: a }, t.id) : null
  };
}
function su({
  session: t,
  onClose: n
}) {
  const r = xe(
    () => n(t.id),
    [n, t.id]
  ), [a, i] = k(t.original), l = B(t.original), [s, c] = k(!1), [u, d] = k(
    "loading"
  ), [p, h] = k(
    () => typeof window < "u" && !!window.matchMedia?.("(pointer: coarse)").matches
  ), [f, m] = k(!1), [b, y] = k(Ea), w = B(!1), [v, g] = k(!1), [x, N] = k(3), [C, A] = k(3), [L, U] = k("pmatrix"), [S, I] = k(""), T = B(null), H = B(null), R = B(null), O = B(null), M = xe(
    ($) => {
      const z = t.host.mathPosition();
      if (z === void 0 || t.editor.isDestroyed) return;
      const E = t.editor.state.doc.nodeAt(z);
      !E || !["inlineMath", "blockMath"].includes(E.type.name) || (l.current = $, i($), E.attrs.latex !== $ && t.editor.view.dispatch(
        t.editor.state.tr.setNodeMarkup(z, void 0, {
          ...E.attrs,
          latex: $
        })
      ));
    },
    [t]
  );
  Ce(() => {
    ll(
      t.display ? t.host : t.host.closest("p, li, td") || t.host
    ), t.host.classList.add("is-math-editing"), t.host.setAttribute("draggable", "false");
    const $ = t.display ? null : t.host.closest("p"), z = t.editor.view.dom, E = z.style.getPropertyValue(
      "--fp-inline-math-space"
    ), D = () => {
      $ && z.style.setProperty(
        "--fp-inline-math-space",
        `${t.slot.getBoundingClientRect().height + 12}px`
      );
    };
    D();
    const ne = $ && typeof ResizeObserver < "u" ? new ResizeObserver(D) : null;
    ne?.observe(t.slot);
    const ae = () => {
      const he = t.host.mathPosition();
      if (he === void 0 || !t.host.isConnected) {
        r();
        return;
      }
      const W = t.editor.state.doc.nodeAt(he);
      if (!W || !["inlineMath", "blockMath"].includes(W.type.name)) {
        r();
        return;
      }
      const G = String(W.attrs.latex ?? "");
      G !== l.current && (l.current = G, i(G), R.current?.setValue(G, { silenceNotifications: !0 }));
    }, ye = (he) => {
      !t.host.contains(he.target) && !he.target.closest?.(".fp-popup-panel, #mathlive-suggestion-popover") && r();
    };
    return t.editor.on("transaction", ae), t.editor.on("destroy", r), document.addEventListener("pointerdown", ye), () => {
      const he = t.host, W = t.display ? he : he.closest("p, li, td") || he, G = W.getBoundingClientRect(), ue = W.cloneNode(!0);
      ue.querySelectorAll("math-field").forEach((V) => {
        const oe = he.querySelector(".math-node-content")?.cloneNode(!0);
        oe ? (oe.style.display = "block", V.replaceWith(oe)) : V.remove();
      }), ne?.disconnect(), t.slot.style.display = "none";
      const me = z.style.getPropertyValue(
        "--fp-inline-math-space"
      );
      E ? z.style.setProperty("--fp-inline-math-space", E) : z.style.removeProperty("--fp-inline-math-space"), he.classList.remove("is-math-editing");
      const q = W.getBoundingClientRect();
      if (t.slot.style.removeProperty("display"), W.isConnected && typeof W.animate == "function" && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
        const V = document.createElement("div");
        V.className = "fp-markdown-editor fp-formula-closing", V.style.setProperty("--fp-inline-math-space", me), V.inert = !0, V.setAttribute("aria-hidden", "true"), Object.assign(V.style, {
          position: "absolute",
          left: `${G.left + window.scrollX}px`,
          top: `${G.top + window.scrollY}px`,
          width: `${G.width}px`,
          height: `${G.height}px`,
          overflow: "clip",
          pointerEvents: "none",
          zIndex: "20"
        }), ue.style.margin = "0", ue.querySelectorAll("[id]").forEach((_) => _.removeAttribute("id"));
        const oe = document.createElement("div");
        oe.className = "fp-editor-prose", Object.assign(oe.style, { padding: "0", minHeight: "0" }), oe.append(ue), V.append(oe), document.body.append(V), iu(W, V, G.height, q.height);
      }
      t.editor.off("transaction", ae), t.editor.off("destroy", r), document.removeEventListener("pointerdown", ye);
    };
  }, [t, r]), Y(() => {
    let $ = !0, z = () => {
    };
    return document.documentElement.dataset.mathEditing = "true", document.dispatchEvent(new Event("fp:math-open")), T.current?.focus(), (async () => {
      try {
        const { MathfieldElement: E } = await import("mathlive");
        if (await Promise.resolve({                   }), !$ || !H.current) return;
        const D = new E();
        D.className = "note-math-live", D.mathVirtualKeyboardPolicy = "manual", D.smartFence = !0, D.smartMode = !1, D.environmentPopoverPolicy = "off", D.maxMatrixCols = 10, D.setAttribute("aria-label", "公式内容");
        const ne = new Promise(
          (W) => D.addEventListener("mount", () => W(), { once: !0 })
        );
        if (H.current.append(D), z = () => {
          D.remove(), R.current = null;
        }, await ne, !$) return;
        D.menuItems = [], D.setValue(l.current, { silenceNotifications: !0 }), R.current = D;
        const ae = window.mathVirtualKeyboard;
        ae.hide();
        const ye = () => M(D.getValue("latex-unstyled"));
        D.addEventListener("input", ye);
        const he = () => {
          w.current = !1;
        };
        D.addEventListener("focus", he), z = () => {
          ae.hide(), D.removeEventListener("input", ye), D.removeEventListener("focus", he), D.remove(), R.current = null;
        }, d("ready"), document.activeElement !== O.current && D.focus();
      } catch (E) {
        z(), console.warn("Formula input initialization failed", E), $ && (d("fallback"), c(!0));
      }
    })(), () => {
      $ = !1, z(), delete document.documentElement.dataset.mathEditing;
    };
  }, [M]), Y(() => {
    const $ = () => y(Ea()), z = () => {
      Gd();
    };
    return window.addEventListener(yt, $), window.addEventListener("storage", $), window.addEventListener("focus", z), z(), () => {
      window.removeEventListener(yt, $), window.removeEventListener("storage", $), window.removeEventListener("focus", z);
    };
  }, []), Y(() => {
    if (u !== "ready" || !R.current) return;
    const $ = R.current;
    return tu(
      $,
      b,
      () => M($.getValue("latex-unstyled"))
    );
  }, [u, b, M]);
  const K = ($) => {
    const z = R.current;
    if (!z) return;
    z.focus();
    const E = z.executeCommand($);
    I(E ? "" : "请将光标放在矩阵内；每行最多 10 列。"), E && M(z.getValue("latex-unstyled"));
  }, j = ($ = !1) => {
    const z = t.editor, E = t.host.mathPosition();
    if (E === void 0 || z.isDestroyed) {
      r();
      return;
    }
    const D = z.state.doc.nodeAt(E);
    if ($ && D && z.commands.deleteRange({ from: E, to: E + D.nodeSize }), r(), !z.isDestroyed) {
      const ne = Math.min(
        E + ($ ? 0 : D?.nodeSize ?? 0),
        z.state.doc.content.size
      );
      z.view.dispatch(
        z.state.tr.setSelection(
          Nn.near(z.state.doc.resolve(ne), 1)
        )
      ), z.commands.focus(void 0, { scrollIntoView: !1 });
    }
  }, P = ($) => {
    const z = R.current;
    if (z && !w.current)
      z.focus(), z.insert($, { selectionMode: "placeholder" }), M(z.getValue("latex-unstyled"));
    else {
      const E = O.current, D = E?.selectionStart ?? l.current.length, ne = E?.selectionEnd ?? D, ae = $.replaceAll("#0", l.current.slice(D, ne)).replaceAll("#?", ""), ye = l.current.slice(0, D) + ae + l.current.slice(ne);
      M(ye), z?.setValue(ye, { silenceNotifications: !0 }), E?.focus(), requestAnimationFrame(
        () => E?.setSelectionRange(D + ae.length, D + ae.length)
      );
    }
  };
  return Te(
    /* @__PURE__ */ o(fe, { initialHeight: t.collapsedHeight, children: [
      /* @__PURE__ */ e(au, { anchor: H }),
      /* @__PURE__ */ o(
        "div",
        {
          className: "note-math-card inline-card-expansion",
          ref: T,
          role: "group",
          "aria-label": t.display ? "编辑独立公式" : "编辑行内公式",
          tabIndex: -1,
          onPointerDown: ($) => $.stopPropagation(),
          onClick: ($) => $.stopPropagation(),
          onDoubleClick: ($) => $.stopPropagation(),
          onContextMenu: ($) => $.stopPropagation(),
          onKeyDownCapture: ($) => {
            if (!($.nativeEvent.isComposing || $.nativeEvent.keyCode === 229) && !($.target === R.current && R.current?.mode === "latex")) {
              if (!t.display && $.key === "Enter" && !$.shiftKey && !($.target instanceof HTMLButtonElement)) {
                $.preventDefault(), $.stopPropagation(), j();
                return;
              }
              if (t.display && $.key === "Enter" && !$.ctrlKey && !$.metaKey && $.target === R.current) {
                $.preventDefault(), $.stopPropagation(), R.current?.executeCommand("addRowAfter"), R.current && M(R.current.getValue("latex-unstyled"));
                return;
              }
              ($.key === "Escape" || $.key === "Enter" && ($.ctrlKey || $.metaKey)) && ($.preventDefault(), $.stopPropagation(), j());
            }
          },
          onKeyDown: ($) => $.stopPropagation(),
          children: [
            /* @__PURE__ */ o("div", { className: "note-math-topline", children: [
              /* @__PURE__ */ o("span", { className: "note-math-title", children: [
                "∑ ",
                /* @__PURE__ */ e("span", { children: t.display ? "独立公式" : "行内公式" })
              ] }),
              /* @__PURE__ */ o("div", { className: "note-math-controls", children: [
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    title: "LaTeX 源码",
                    "aria-label": "LaTeX 源码",
                    "aria-expanded": s,
                    disabled: u === "fallback",
                    onClick: () => c(($) => !$),
                    children: [
                      /* @__PURE__ */ e(Sr, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "源码" })
                    ]
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    "aria-label": "数学键盘",
                    "aria-expanded": p,
                    onClick: () => {
                      h(($) => !$), window.mathVirtualKeyboard?.hide();
                    },
                    children: [
                      /* @__PURE__ */ e(Wa, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "键盘" })
                    ]
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "快捷输入设置",
                    "aria-expanded": f,
                    onClick: () => m(($) => !$),
                    children: /* @__PURE__ */ e(Vl, { size: 15 })
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "note-math-delete",
                    title: "删除公式",
                    "aria-label": "删除公式",
                    onClick: () => j(!0),
                    children: /* @__PURE__ */ e(Bt, { size: 15 })
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    className: "note-math-done",
                    "aria-label": "收起",
                    title: "收起 · Ctrl/⌘+Enter",
                    onClick: () => j(),
                    children: [
                      /* @__PURE__ */ e(Re, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "完成" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-writing", children: [
              u === "loading" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "正在准备公式输入…" }),
              /* @__PURE__ */ e(
                "div",
                {
                  ref: H,
                  className: "note-math-live-host",
                  hidden: u === "fallback"
                }
              ),
              s && /* @__PURE__ */ o("label", { className: "note-math-source-label", children: [
                "LaTeX",
                /* @__PURE__ */ e(
                  "textarea",
                  {
                    ref: O,
                    "aria-label": "LaTeX 源码",
                    className: "note-math-source",
                    rows: 2,
                    value: a,
                    spellCheck: !1,
                    onFocus: () => {
                      w.current = !0;
                    },
                    onChange: ($) => {
                      M($.target.value), R.current?.setValue($.target.value, {
                        silenceNotifications: !0
                      });
                    }
                  }
                )
              ] }),
              u === "fallback" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "可直接输入 LaTeX 公式。" })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-tools", role: "toolbar", "aria-label": "公式结构", children: [
              lu.map(([$, z]) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  disabled: u === "loading" && !s,
                  onMouseDown: (E) => E.preventDefault(),
                  onClick: () => P(z),
                  children: $
                },
                $
              )),
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-expanded": v,
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => {
                    g(($) => !$), I("");
                  },
                  children: [
                    /* @__PURE__ */ e(Xl, { size: 14 }),
                    "矩阵"
                  ]
                }
              )
            ] }),
            v && /* @__PURE__ */ o(
              "div",
              {
                className: "note-matrix-builder",
                role: "group",
                "aria-label": "矩阵设置",
                children: [
                  /* @__PURE__ */ o("div", { className: "note-matrix-settings", children: [
                    /* @__PURE__ */ o("label", { children: [
                      "行",
                      /* @__PURE__ */ e(
                        we,
                        {
                          label: "矩阵行数",
                          value: String(x),
                          onChange: ($) => N(Number($)),
                          options: Array.from({ length: 10 }, ($, z) => ({
                            value: String(z + 1),
                            label: String(z + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "×" }),
                    /* @__PURE__ */ o("label", { children: [
                      "列",
                      /* @__PURE__ */ e(
                        we,
                        {
                          label: "矩阵列数",
                          value: String(C),
                          onChange: ($) => A(Number($)),
                          options: Array.from({ length: 10 }, ($, z) => ({
                            value: String(z + 1),
                            label: String(z + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o("label", { children: [
                      "括号",
                      /* @__PURE__ */ e(
                        we,
                        {
                          label: "矩阵括号",
                          value: L,
                          onChange: ($) => U($),
                          options: Zi.map(([$, z]) => ({
                            value: $,
                            label: z
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        className: "note-matrix-insert",
                        disabled: u === "loading" && !s,
                        onMouseDown: ($) => $.preventDefault(),
                        onClick: () => {
                          P(
                            el(x, C, L)
                          ), g(!1);
                        },
                        children: [
                          "插入 ",
                          x,
                          " × ",
                          C
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-presets", children: [
                    /* @__PURE__ */ e("span", { children: "常用" }),
                    [
                      [1, 3],
                      [3, 1],
                      [2, 2],
                      [3, 3],
                      [4, 4],
                      [3, 4]
                    ].map(([$, z]) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": x === $ && C === z,
                        onClick: () => {
                          N($), A(z);
                        },
                        children: [
                          $,
                          " × ",
                          z
                        ]
                      },
                      `${$}-${z}`
                    ))
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-actions", children: [
                    /* @__PURE__ */ e("span", { children: "光标所在矩阵" }),
                    [
                      ["增行", "addRowAfter"],
                      ["增列", "addColumnAfter"],
                      ["删行", "removeRow"],
                      ["删列", "removeColumn"]
                    ].map(([$, z]) => /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        disabled: u !== "ready" || s,
                        onMouseDown: (E) => E.preventDefault(),
                        onClick: () => K(z),
                        children: $
                      },
                      z
                    ))
                  ] }),
                  S && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: S })
                ]
              }
            ),
            t.display && /* @__PURE__ */ o("div", { className: "note-math-line-actions", children: [
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => {
                    const $ = R.current;
                    $ && ($.focus(), $.executeCommand("addRowAfter"), M($.getValue("latex-unstyled")));
                  },
                  children: [
                    /* @__PURE__ */ e(Ka, { size: 14 }),
                    "换行"
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => P("\\begin{aligned}#0 &= #? \\\\ #? &= #?\\end{aligned}"),
                  children: "对齐多行"
                }
              ),
              /* @__PURE__ */ e("span", { children: "Enter 换行 · Ctrl/⌘+Enter 完成" })
            ] }),
            f && /* @__PURE__ */ e(
              nu,
              {
                rules: b,
                onSave: y,
                onClose: () => m(!1)
              }
            ),
            p && /* @__PURE__ */ e(
              Qd,
              {
                onInsert: P,
                shortcuts: b,
                onCommand: ($) => {
                  const z = R.current;
                  z && (z.focus(), z.executeCommand($), M(z.getValue("latex-unstyled")));
                }
              }
            )
          ]
        }
      )
    ] }),
    t.slot
  );
}
function cu(t) {
  const { node: n, updateAttributes: r, editor: a, deleteNode: i, getPos: l } = t, [s, c] = k(() => gi(a, n.attrs.id)), u = B(null), d = B(!1), p = () => {
    c(!1), gs(a, l);
  }, h = B(null), f = B(String(n.attrs.body || ""));
  Y(() => {
    s && (bs(a, n.attrs.id), requestAnimationFrame(() => u.current?.focus()));
  }, [s]), Y(() => {
    const b = String(n.attrs.body || "");
    h.current && !h.current.isDestroyed && b !== f.current && (h.current.commands.setContent(Ji(b), {
      emitUpdate: !1
    }), f.current = b);
  }, [n.attrs.body]);
  const m = String(n.attrs.name);
  return /* @__PURE__ */ o(
    It,
    {
      onKeyDownCapture: (b) => {
        s && !b.nativeEvent.isComposing && b.key === "Enter" && (b.ctrlKey || b.metaKey) && (b.preventDefault(), b.stopPropagation(), p());
      },
      className: "fp-directive-node",
      contentEditable: !1,
      "data-selected": t.selected || void 0,
      "data-card-type": m,
      "data-nested-editor-boundary": s ? "" : void 0,
      children: [
        /* @__PURE__ */ o("div", { className: "fp-directive-heading", contentEditable: !1, "data-nested-editor-boundary": "", children: [
          /* @__PURE__ */ e(
            we,
            {
              label: "卡片类型",
              value: m,
              disabled: !a.isEditable,
              onChange: (b) => {
                const y = ka(n.attrs.attributes, m);
                r({
                  name: b,
                  attributes: Na(
                    n.attrs.attributes,
                    b,
                    y
                  )
                });
              },
              options: Ld.map(([b, y]) => ({
                value: b,
                label: y
              }))
            }
          ),
          a.isEditable && /* @__PURE__ */ o("span", { className: "fp-directive-actions", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": s ? "完成卡片编辑" : "编辑卡片内容",
                onClick: () => s ? p() : c(!0),
                children: s ? /* @__PURE__ */ e(Re, { size: 14 }) : /* @__PURE__ */ e(Fn, { size: 14 })
              }
            ),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "删除卡片", onClick: i, children: /* @__PURE__ */ e(Bt, { size: 14 }) })
          ] })
        ] }),
        s && /* @__PURE__ */ e(
          "input",
          {
            ref: u,
            onKeyDown: (b) => {
              b.key === "Enter" && !b.nativeEvent.isComposing && !b.ctrlKey && !b.metaKey && (b.preventDefault(), b.stopPropagation(), h.current ? h.current.commands.focus("start") : d.current = !0);
            },
            "aria-label": "卡片标题",
            value: ka(n.attrs.attributes, m),
            disabled: !a.isEditable,
            placeholder: "添加标题",
            onChange: (b) => r({
              attributes: Na(
                n.attrs.attributes,
                m,
                b.target.value
              )
            })
          }
        ),
        /* @__PURE__ */ o(fe, { children: [
          s && /* @__PURE__ */ e(
            Ns,
            {
              name: m,
              value: String(n.attrs.attributes || ""),
              onChange: (b) => r({ attributes: b }),
              disabled: !a.isEditable
            }
          ),
          " ",
          s ? /* @__PURE__ */ e(
            Xn,
            {
              allowCards: !1,
              markdown: String(n.attrs.body || ""),
              editable: a.isEditable,
              onOpenLink: t.onOpenLink,
              resolveResourceUrl: t.resolveResourceUrl,
              toolbar: !0,
              onReady: (b) => {
                h.current = b, d.current && (d.current = !1, b.commands.focus("start"));
              },
              onChange: (b) => {
                f.current = b, r({ body: b });
              }
            }
          ) : /* @__PURE__ */ e(
            bt,
            {
              resolveResourceUrl: t.resolveResourceUrl,
              markdown: ":::" + m + (n.attrs.attributes ? "{" + n.attrs.attributes + "}" : "") + `
` + String(n.attrs.body || "") + `
:::`
            }
          )
        ] })
      ]
    }
  );
}
function Xn(t) {
  const {
    markdown: n = "",
    documentKey: r = "default",
    document: a,
    provider: i,
    user: l,
    editable: s = !0,
    placeholder: c = "写下你的理解…",
    extensions: u = [],
    status: d
  } = t, p = B(t);
  p.current = t;
  const h = ou(), f = B(null), m = B(h);
  m.current = h;
  const [b, y] = k(null), [w, v] = k(null), [g, x] = k([]), [N, C] = k(0), [A, L] = k(""), U = B({ suggestion: w, suggestions: g, suggestionActive: N });
  U.current = { suggestion: w, suggestions: g, suggestionActive: N }, Y(() => {
    const z = new AbortController();
    if (x([]), C(0), L(""), !w || !t.getSuggestions) return () => z.abort();
    const E = setTimeout(() => {
      t.getSuggestions(
        w.query,
        w.kind,
        z.signal
      ).then((D) => {
        z.signal.aborted || x(D);
      }).catch(() => {
        z.signal.aborted || L("暂时无法查找，请继续输入或重试。");
      });
    }, 180);
    return () => {
      clearTimeout(E), z.abort();
    };
  }, [w?.query, w?.kind, t.getSuggestions]), Y(() => {
    const z = () => y((E) => E && { ...E });
    return window.addEventListener(fr, z), () => window.removeEventListener(fr, z);
  }, []);
  const S = B(b);
  S.current = b;
  const I = (z) => ud(z).filter((E) => !(["attachment", "video"].includes(E[0]) && !t.onAttachment) && !(E[0] === "interactive" && !t.onInteractive) && !(t.allowCards === !1 && (E[0] === "card" || pn(E[0]))));
  function T(z) {
    const { $from: E, from: D, empty: ne } = z.state.selection, ae = ne && z.isEditable && !E.parent.type.spec.code ? E.parent.textBetween(0, E.parentOffset).match(/(?:^|\s)\/([^\s/]*)$/u) : null, ye = E.parent.textBetween(0, E.parentOffset), he = t.getSuggestions && ne && z.isEditable && !E.parent.type.spec.code ? ye.match(/(?:^|\s)(#([^\s#]*)|\[\[([^\]\n]*))$/u) : null;
    if (he) {
      const G = z.view.coordsAtPos(D), ue = he[2] !== void 0 ? "tag" : "link", me = he[2] ?? he[3];
      v({
        from: D - me.length - (ue === "tag" ? 1 : 2),
        to: D,
        kind: ue,
        query: me,
        top: Math.max(8, Math.min(G.bottom + 6, window.innerHeight - 290)),
        left: Math.max(8, Math.min(G.left, window.innerWidth - 280))
      });
    } else v(null);
    if (!ae) {
      y(null);
      return;
    }
    const W = z.view.coordsAtPos(D);
    y((G) => ({
      from: D - ae[1].length - 1,
      to: D,
      query: ae[1],
      top: Math.max(8, Math.min(W.bottom + 6, window.innerHeight - 300)),
      left: Math.max(8, Math.min(W.left, window.innerWidth - 272)),
      active: G?.query === ae[1] ? G.active : 0
    }));
  }
  function H(z) {
    const E = f.current, D = S.current;
    !E || !D || p.current.allowCards === !1 && (z === "card" || pn(z)) || (y(null), ws(z), E.chain().focus().deleteRange(D).run(), z === "text" ? E.commands.setParagraph() : /^h[1-6]$/.test(z) ? E.commands.setHeading({ level: Number(z[1]) }) : z === "bullet" ? E.commands.toggleBulletList() : z === "ordered" ? E.commands.toggleOrderedList() : z === "quote" ? E.commands.toggleBlockquote() : z === "code" ? E.commands.toggleCodeBlock() : wa(z) !== void 0 ? E.commands.setCodeBlock({ language: wa(z) || "" }) : pn(z) ? Qn(E, pn(z)) : z === "divider" ? E.commands.setHorizontalRule() : vr(z) ? E.commands.insertTable({ ...vr(z), withHeaderRow: !0 }) : z === "table" ? E.commands.insertTable({ rows: 3, cols: 3, withHeaderRow: !0 }) : z === "inlineMath" || z === "math" ? m.current.open(E, z === "math") : z === "card" ? Qn(E) : z === "mermaid" ? qi(E) : z === "interactive" ? p.current.onInteractive?.(E) : (z === "attachment" || z === "video") && p.current.onAttachment?.(
      E,
      z === "video" ? "video" : "file"
    ));
  }
  function R(z) {
    const E = f.current, D = U.current.suggestion;
    !E || !D || (E.chain().focus().deleteRange({ from: D.from, to: D.to }).run(), D.kind === "link" && z.href ? E.chain().insertContent({
      type: "text",
      text: z.label,
      marks: [{ type: "link", attrs: { href: z.href } }]
    }).run() : E.commands.insertContent({
      type: "text",
      text: z.insertText ?? (D.kind === "tag" ? `#${z.label} ` : z.label)
    }), v(null));
  }
  const [O, M] = k(null), [K, j] = k([]), P = B({ mode: O, marks: K });
  P.current = { mode: O, marks: K };
  const $ = Ro(
    {
      immediatelyRender: !1,
      editable: s,
      extensions: [
        od,
        ...(t.baseExtensions || Br(
          !a,
          void 0,
          Xi.extend({
            addNodeView: () => _t(
              (z) => p.current.renderDirective ? /* @__PURE__ */ e(It, { children: p.current.renderDirective(z) }) : /* @__PURE__ */ e(
                cu,
                {
                  ...z,
                  onOpenLink: p.current.onOpenLink,
                  resolveResourceUrl: p.current.resolveResourceUrl
                }
              ),
              Oi
            )
          }),
          Hd({
            onInlineClick: (z, E) => f.current && m.current.open(f.current, !1, E),
            onBlockClick: (z, E) => f.current && m.current.open(f.current, !0, E)
          }),
          Gi.extend({
            addNodeView: () => _t(
              ({ node: z, editor: E, deleteNode: D }) => /* @__PURE__ */ o(It, { className: "fp-attachment-node", children: [
                /* @__PURE__ */ e(Ye, { size: 20 }),
                /* @__PURE__ */ e("span", { children: String(z.attrs.name) }),
                p.current.onOpenAttachment && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    onClick: () => p.current.onOpenAttachment?.({
                      name: z.attrs.name,
                      url: z.attrs.url,
                      mediaType: z.attrs.mediaType
                    }),
                    children: "查看附件"
                  }
                ),
                E.isEditable && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "删除附件",
                    onClick: D,
                    children: /* @__PURE__ */ e(Bt, { size: 14 })
                  }
                )
              ] })
            )
          }),
          Rc
        )).map(
          (z) => z.name === "image" ? z.configure({
            resolveUrl: (E) => p.current.resolveResourceUrl?.(E) || E
          }) : z.name === "uploadPlaceholder" ? Vi.extend({
            addNodeView: () => _t(({ node: E, deleteNode: D }) => /* @__PURE__ */ o(
              It,
              {
                className: "fp-editor-upload",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e("strong", { children: String(E.attrs.name) }),
                  /* @__PURE__ */ e("p", { role: E.attrs.error ? "alert" : "status", children: E.attrs.error || "正在上传…" }),
                  f.current?.isEditable && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    E.attrs.error && p.current.onUploadAction && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onUploadAction?.(
                          String(E.attrs.uploadId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          p.current.onUploadAction?.(
                            String(E.attrs.uploadId),
                            "cancel"
                          ), D();
                        },
                        children: "取消上传"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : z.name === "imageConversion" ? Wi.extend({
            addNodeView: () => _t(({ node: E }) => /* @__PURE__ */ o(
              It,
              {
                className: "fp-editor-conversion",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e(
                    "img",
                    {
                      src: p.current.resolveResourceUrl?.(
                        E.attrs.src
                      ) || E.attrs.src,
                      alt: E.attrs.alt || "识别中的图片"
                    }
                  ),
                  /* @__PURE__ */ e("p", { role: E.attrs.error ? "alert" : "status", children: E.attrs.error || (E.attrs.markdown ? "内容已识别" : "正在识别图片…") }),
                  f.current?.isEditable && p.current.onConversionAction && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    E.attrs.markdown && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String(E.attrs.jobId),
                          "insert"
                        ),
                        children: "插入识别内容"
                      }
                    ),
                    E.attrs.error && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String(E.attrs.jobId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String(E.attrs.jobId),
                          "keep-image"
                        ),
                        children: "保留图片"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : z
        ),
        Ho.configure({ placeholder: c }),
        ...t.allowCards === !1 ? [ys] : [],
        ...a ? [Ko.configure({ document: a })] : [],
        ...i && l ? [Uo.configure({ provider: i, user: l })] : [],
        ...u
      ],
      content: a ? void 0 : t.content ?? Ji(n),
      onCreate: ({ editor: z }) => p.current.onReady?.(z),
      onUpdate: ({ editor: z }) => {
        p.current.onChange?.(
          Ca(z.getJSON()),
          z.getJSON()
        ), T(z);
      },
      onSelectionUpdate: ({ editor: z }) => T(z),
      onBlur: () => {
        y(null), v(null);
      },
      editorProps: {
        handleDoubleClick: (z, E, D) => ms(D, (ne, ae) => {
          p.current.onOpenLink ? p.current.onOpenLink(ne, ae) : window.open(ne, "_blank", "noopener,noreferrer");
        }),
        attributes: { "aria-label": "笔记正文", class: "fp-editor-prose" },
        handleKeyDown(z, E) {
          if (!E.isComposing && (E.ctrlKey || E.metaKey) && (E.key === "Home" || E.key === "End")) {
            const ye = E.key === "Home" ? Nn.atStart(z.state.doc) : Nn.atEnd(z.state.doc), he = E.shiftKey ? Ge.create(z.state.doc, z.state.selection.anchor, ye.head) : ye;
            return z.dispatch(z.state.tr.setSelection(he).scrollIntoView()), !0;
          }
          const D = U.current;
          if (D.suggestion && !E.isComposing) {
            if (E.key === "Escape")
              return v(null), !0;
            if (D.suggestions.length) {
              if (E.key === "ArrowDown" || E.key === "ArrowUp")
                return C(
                  (D.suggestionActive + (E.key === "ArrowDown" ? 1 : -1) + D.suggestions.length) % D.suggestions.length
                ), !0;
              if (E.key === "Enter")
                return R(
                  D.suggestions[D.suggestionActive] || D.suggestions[0]
                ), !0;
            }
          }
          const ne = S.current;
          if (!ne || E.isComposing) return !1;
          const ae = I(ne.query);
          return E.key === "Escape" ? (y(null), !0) : ae.length ? E.key === "ArrowDown" || E.key === "ArrowUp" ? (y({
            ...ne,
            active: (ne.active + (E.key === "ArrowDown" ? 1 : -1) + ae.length) % ae.length
          }), !0) : E.key === "Enter" ? (H(ae[Math.min(ne.active, ae.length - 1)][0]), !0) : !1 : !1;
        },
        handlePaste(z, E) {
          const D = Array.from(E.clipboardData?.files || []), ne = f.current;
          return D.length && p.current.onFiles && ne ? (p.current.onFiles(D, ne), !0) : !1;
        },
        handleDrop(z, E, D, ne) {
          const ae = Array.from(E.dataTransfer?.files || []), ye = f.current;
          if (!ne && ae.length && p.current.onFiles && ye) {
            const he = z.posAtCoords({
              left: E.clientX,
              top: E.clientY
            });
            return he && ye.commands.setTextSelection(he.pos), p.current.onFiles(ae, ye), !0;
          }
          return !1;
        },
        handleDOMEvents: {
          mouseup: () => {
            const z = f.current;
            if (z && P.current.mode && !z.state.selection.empty) {
              const { from: E, to: D } = z.state.selection;
              gd(z, P.current.marks, E, D), P.current.mode === "once" && M(null);
            }
            return !1;
          }
        }
      }
    },
    [r, a, i]
  );
  return f.current = $, Y(() => {
    $?.setEditable(s);
  }, [$, s]), /* @__PURE__ */ o(
    "section",
    {
      className: "fp-markdown-editor",
      "data-readonly": !s || void 0,
      children: [
        $ && s && t.toolbar !== !1 && /* @__PURE__ */ e(
          zd,
          {
            editor: $,
            onHistory: () => p.current.onHistory?.(),
            onSnapshot: () => p.current.onSnapshot?.(),
            hiddenActions: [
              ...t.allowCards === !1 ? ["card"] : [],
              ...t.onHistory ? [] : ["versions"],
              ...t.onSnapshot ? [] : ["snapshot"],
              ...t.onExport ? [] : ["export"],
              ...t.onAttachment ? [] : ["attachment", "video"]
            ],
            onExport: () => p.current.onExport?.(Ca($.getJSON())),
            onAttachment: () => p.current.onAttachment?.($, "file"),
            onInteractive: t.onInteractive ? () => p.current.onInteractive?.($) : void 0,
            onVideo: () => p.current.onAttachment?.($, "video"),
            onInsertCard: () => {
              p.current.allowCards !== !1 && Qn($);
            },
            onMath: (z) => h.open($, z),
            formatPainterMode: O,
            onFormatPainterMode: M,
            formatPainterMarks: K,
            onFormatPainterMarks: j
          }
        ),
        /* @__PURE__ */ e(Hi, { editor: $, children: /* @__PURE__ */ e(ii, { editor: $ }) }),
        h.card,
        b && $ && Te(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": "插入内容",
              style: { left: b.left, top: b.top, maxHeight: 280 },
              children: [
                I(b.query).map(([z, E, D], ne) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": ne === b.active,
                    tabIndex: -1,
                    onMouseDown: (ae) => ae.preventDefault(),
                    onClick: () => H(z),
                    children: [
                      /* @__PURE__ */ e("strong", { children: E }),
                      /* @__PURE__ */ e("small", { children: D })
                    ]
                  },
                  z
                )),
                !I(b.query).length && /* @__PURE__ */ e("p", { className: "fp-muted", children: "没有匹配的内容" })
              ]
            }
          ),
          $.view.dom.closest("dialog") || window.document.body
        ),
        d && /* @__PURE__ */ e("footer", { className: "fp-markdown-status", children: d }),
        w && $ && Te(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": w.kind === "tag" ? "标签建议" : "笔记链接建议",
              style: {
                left: w.left,
                top: w.top,
                maxHeight: 260
              },
              children: [
                g.map((z, E) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": E === N,
                    onMouseDown: (D) => D.preventDefault(),
                    onClick: () => R(z),
                    children: [
                      /* @__PURE__ */ e("strong", { children: z.label }),
                      z.detail && /* @__PURE__ */ e("small", { children: z.detail })
                    ]
                  },
                  z.id
                )),
                !g.length && /* @__PURE__ */ e("p", { role: A ? "alert" : "status", children: A || "输入关键词查找…" })
              ]
            }
          ),
          $.view.dom.closest("dialog") || window.document.body
        )
      ]
    }
  );
}
const ar = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function du({
  title: t,
  media: n,
  transcript: r,
  chapters: a = [],
  notes: i,
  onNotesChange: l,
  onPositionChange: s,
  onCite: c
}) {
  const [u, d] = k(n.startAt || 0), [p, h] = k("transcript"), [f, m] = k(!0), b = B(null), y = B(null), w = r.findIndex(
    (N) => u >= N.start && u < N.end
  ), v = [...a].reverse().find((N) => N.start <= u);
  Y(() => {
    if (!f || p !== "transcript" || !y.current) return;
    const N = y.current, C = N.parentElement;
    if (!C) return;
    const A = N.getBoundingClientRect(), L = C.getBoundingClientRect();
    (A.top < L.top || A.bottom > L.bottom) && C.scrollTo?.({
      top: C.scrollTop + A.top - L.top - 16,
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
    });
  }, [w, f, p]), Y(() => {
    d(n.startAt || 0);
  }, [n.src, n.startAt]), Y(() => {
    p === "chapter" && !v?.markdown && h("transcript");
  }, [p, v?.markdown]);
  const g = (N) => {
    d(N), s?.(N), n.onTimeUpdate?.(N);
  }, x = (N) => {
    b.current && (b.current.currentTime = Math.max(0, N), g(N));
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-lecture-workspace", children: /* @__PURE__ */ o(ee, { title: t, children: [
    n.kind === "audio" ? /* @__PURE__ */ e(
      xn,
      {
        ...n,
        audioRef: (N) => {
          b.current = N;
          const C = n.audioRef;
          typeof C == "function" ? C(N) : C && (C.current = N);
        },
        onTimeUpdate: g
      }
    ) : /* @__PURE__ */ e(
      Jt,
      {
        ...n,
        videoRef: (N) => {
          b.current = N;
          const C = n.videoRef;
          typeof C == "function" ? C(N) : C && (C.current = N);
        },
        onTimeUpdate: g
      }
    ),
    a.length > 0 && /* @__PURE__ */ e("nav", { className: "fp-lecture-chapters", "aria-label": "课堂章节", children: a.map((N) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        "aria-current": v?.id === N.id ? "step" : void 0,
        onClick: () => x(N.start),
        children: [
          /* @__PURE__ */ e("span", { children: ar(N.start) }),
          N.title
        ]
      },
      N.id
    )) }),
    /* @__PURE__ */ e(
      _e,
      {
        label: "课堂内容",
        value: p,
        onChange: h,
        items: [
          { id: "transcript", label: "讲稿" },
          { id: "notes", label: "课堂笔记" },
          ...v?.markdown ? [{ id: "chapter", label: "章节内容" }] : []
        ]
      }
    ),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { className: "fp-lecture-content", children: p === "notes" ? /* @__PURE__ */ e(
      Xn,
      {
        markdown: i,
        onChange: l,
        placeholder: "记录课堂中的想法…"
      }
    ) : p === "chapter" ? /* @__PURE__ */ e(bt, { markdown: v?.markdown || "" }) : /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          "aria-pressed": f,
          onClick: () => m(!f),
          children: "跟随播放"
        }
      ) }),
      /* @__PURE__ */ e("div", { className: "fp-lecture-transcript", "aria-label": "课堂讲稿", children: r.length ? r.map((N, C) => /* @__PURE__ */ o(
        "div",
        {
          ref: C === w ? y : void 0,
          className: "fp-lecture-line",
          "data-active": C === w || void 0,
          children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-timestamp",
                onClick: () => x(N.start),
                "aria-label": `跳转至 ${ar(N.start)}`,
                children: ar(N.start)
              }
            ),
            /* @__PURE__ */ e("p", { children: N.words?.length ? N.words.map((A, L) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                "data-active": u >= A.start && u < A.end || void 0,
                onClick: () => x(A.start),
                children: A.text
              },
              L
            )) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                onClick: () => x(N.start),
                children: N.text
              }
            ) }),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => c({
                  title: t,
                  time: N.start,
                  text: N.text
                }),
                children: "引用"
              }
            )
          ]
        },
        N.id || `${N.start}-${C}`
      )) : /* @__PURE__ */ e("p", { className: "fp-workspace-empty", children: "还没有可用的课堂讲稿。" }) })
    ] }) }) })
  ] }) });
}
function uu({
  source: t
}) {
  const [n, r] = k("");
  return t.audio ? /* @__PURE__ */ e(
    du,
    {
      title: t.title,
      media: { kind: "audio", ...t.audio },
      transcript: t.transcript || [],
      chapters: t.chapters,
      notes: n,
      onNotesChange: r
    }
  ) : t.resource ? /* @__PURE__ */ e(fs, { resource: t.resource }) : /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h3", { children: t.title }),
    /* @__PURE__ */ e(
      bt,
      {
        markdown: t.markdown || "此资料还没有可阅读的正文。"
      }
    )
  ] });
}
function be({
  children: t,
  onAction: n,
  disabled: r = !1,
  confirm: a
}) {
  const [i, l] = k(!1), [s, c] = k(""), [u, d] = k(!1), p = B(!1), h = async () => {
    if (!p.current) {
      p.current = !0, l(!0), c("");
      try {
        await n(), d(!1);
      } catch (f) {
        c(
          f instanceof Error ? f.message : "操作未能完成，请重试。"
        );
      } finally {
        p.current = !1, l(!1);
      }
    }
  };
  return /* @__PURE__ */ o("span", { className: "fp-async-action", children: [
    u ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e("span", { children: a }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i || r,
          onClick: () => {
            h();
          },
          children: i ? "正在处理…" : "确认"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i,
          onClick: () => d(!1),
          children: "取消"
        }
      )
    ] }) : /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary fp-sm",
        disabled: i || r,
        onClick: () => a ? d(!0) : void h(),
        children: i ? "正在处理…" : t
      }
    ),
    s && /* @__PURE__ */ e("span", { role: "alert", children: s })
  ] });
}
function pu({
  title: t,
  items: n,
  columns: r,
  actions: a = [],
  loading: i,
  error: l,
  toolbar: s,
  onLoadMore: c,
  hasMore: u
}) {
  return /* @__PURE__ */ o("section", { className: "fp-management", "aria-label": t, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      s
    ] }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    /* @__PURE__ */ e("div", { className: "fp-management-scroll", children: /* @__PURE__ */ o("table", { children: [
      /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ o("tr", { children: [
        r.map((d) => /* @__PURE__ */ e("th", { scope: "col", children: d.label }, d.id)),
        !!a.length && /* @__PURE__ */ e("th", { scope: "col", children: "操作" })
      ] }) }),
      /* @__PURE__ */ e("tbody", { children: n.map((d) => /* @__PURE__ */ o("tr", { children: [
        r.map((p) => /* @__PURE__ */ e("td", { "data-label": p.label, children: p.render(d) }, p.id)),
        !!a.length && /* @__PURE__ */ e("td", { "data-label": "操作", children: /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: a.map((p) => /* @__PURE__ */ e(
          be,
          {
            disabled: p.disabled?.(d) || i,
            confirm: p.confirm?.(d),
            onAction: () => p.run(d),
            children: p.label
          },
          p.id
        )) }) })
      ] }, d.id)) })
    ] }) }),
    i && /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }),
    !n.length && !i && /* @__PURE__ */ e("p", { children: "这里还没有内容。" }),
    u && c && /* @__PURE__ */ e("button", { type: "button", disabled: i, onClick: c, children: "加载更多" })
  ] });
}
function kh({
  entries: t,
  loading: n,
  error: r
}) {
  return /* @__PURE__ */ e(
    pu,
    {
      title: "收支明细",
      items: t,
      loading: n,
      error: r,
      columns: [
        { id: "title", label: "事项", render: (a) => a.title },
        { id: "date", label: "时间", render: (a) => a.date },
        {
          id: "amount",
          label: "变动",
          render: (a) => /* @__PURE__ */ o("span", { "data-positive": a.amount > 0 || void 0, children: [
            a.amount > 0 ? "+" : "",
            a.amount.toLocaleString()
          ] })
        },
        {
          id: "balance",
          label: "余额",
          render: (a) => a.balance?.toLocaleString() ?? "—"
        },
        { id: "status", label: "状态", render: (a) => a.status || "已完成" }
      ]
    }
  );
}
function Nh({
  balance: t,
  reserved: n = 0,
  children: r,
  onTopUp: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的积分" }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "补充积分" })
    ] }),
    /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: t.toLocaleString() }),
    /* @__PURE__ */ o("p", { children: [
      "可用积分",
      n > 0 && ` · 使用中 ${n.toLocaleString()}`
    ] }),
    r
  ] });
}
function xh({
  items: t,
  onManage: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "使用情况" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-capacity-row", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: r.label }),
        /* @__PURE__ */ o("span", { children: [
          r.used.toLocaleString(),
          " / ",
          r.limit.toLocaleString(),
          " ",
          r.unit
        ] })
      ] }),
      /* @__PURE__ */ e(
        "progress",
        {
          "aria-label": r.label,
          value: Math.min(r.limit, Math.max(0, r.used)),
          max: Math.max(1, r.limit)
        }
      ),
      n && /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
        "管理",
        r.label
      ] })
    ] }, r.id))
  ] });
}
function Ch({
  items: t,
  canManage: n,
  onManage: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-label": "访问权限来源", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "访问权限" }),
      n && r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "管理权限" })
    ] }),
    t.length ? /* @__PURE__ */ e("ul", { children: t.map((a, i) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("strong", { children: a.source }),
      /* @__PURE__ */ e("span", { children: a.role }),
      /* @__PURE__ */ e("small", { children: a.inherited ? "来自上级目录" : "单独设置" })
    ] }, `${a.source}-${i}`)) }) : /* @__PURE__ */ e("p", { children: "仅自己可以访问。" })
  ] });
}
function Sh({
  title: t,
  fields: n,
  onChange: r,
  onSave: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-settings-fields", children: n.map((i) => /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ e("span", { children: i.label }),
      i.options ? /* @__PURE__ */ e(
        we,
        {
          label: i.label,
          value: i.value,
          options: i.options,
          disabled: i.disabled,
          onChange: (l) => r(i.id, l)
        }
      ) : /* @__PURE__ */ e(
        "input",
        {
          "aria-label": i.label,
          type: i.secret ? "password" : "text",
          value: i.value,
          disabled: i.disabled,
          onChange: (l) => r(i.id, l.target.value)
        }
      ),
      " ",
      i.description && /* @__PURE__ */ e("small", { children: i.description })
    ] }, i.id)) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(be, { onAction: a, children: "保存设置" }) })
  ] });
}
function Mh({
  steps: t,
  step: n,
  onStepChange: r,
  onComplete: a
}) {
  const i = t[n];
  return i ? /* @__PURE__ */ o("section", { className: "fp-onboarding", children: [
    /* @__PURE__ */ e("ol", { "aria-label": "设置进度", children: t.map((l, s) => /* @__PURE__ */ o("li", { "aria-current": s === n ? "step" : void 0, children: [
      /* @__PURE__ */ e("span", { children: s + 1 }),
      l.title
    ] }, l.id)) }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: i.title }),
      i.description && /* @__PURE__ */ e("p", { children: i.description }),
      i.content
    ] }) }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      n < t.length - 1 ? /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: i.canContinue === !1,
          onClick: () => r(n + 1),
          children: "继续"
        }
      ) : /* @__PURE__ */ e(
        be,
        {
          disabled: i.canContinue === !1,
          onAction: a,
          children: "完成设置"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n === 0,
          onClick: () => r(n - 1),
          children: "上一步"
        }
      )
    ] })
  ] }) : /* @__PURE__ */ e("section", { className: "fp-onboarding", children: /* @__PURE__ */ e("p", { children: "暂时没有可用的设置步骤。" }) });
}
function hu(t) {
  return /* @__PURE__ */ e(fu, { ...t }, t.notebook?.id || "new");
}
function fu({
  notebook: t,
  drafts: n = [],
  versions: r = [],
  onPrepare: a,
  onPublish: i,
  onSetSource: l,
  onRestore: s,
  onLoadVersions: c,
  onRefresh: u,
  resolveResourceUrl: d
}) {
  const [p, h] = k("update"), {
    draft: f,
    setDraft: m,
    dirty: b,
    accept: y
  } = et({
    sourcePrefix: t?.sourcePrefix || "",
    syncMode: t?.syncMode || "review"
  }), w = f.sourcePrefix, v = f.syncMode, g = (M) => m({ ...f, sourcePrefix: M }), x = (M) => m({ ...f, syncMode: M }), [N, C] = k(), [A, L] = k(""), [U, S] = k(null), [I, T] = k(""), H = Le(), R = U?.items.find((M) => M.id === I) || U?.items[0], O = () => {
    H.run(async () => {
      if (!w.trim()) throw new Error("请填写资料来源目录。");
      const M = await a({
        notebookId: t?.id,
        sourcePrefix: w.trim(),
        manifest: N
      });
      S(M), T(M.items[0]?.id || "");
    }, "内容已准备好，请检查后发布。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "笔记本发布", children: /* @__PURE__ */ o(
    ee,
    {
      title: t?.title || "新建笔记本",
      description: "预览课程内容，为读者发布新的阅读版本。",
      actions: u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          disabled: H.busy,
          onClick: () => {
            H.run(u);
          },
          children: "刷新"
        }
      ),
      children: [
        /* @__PURE__ */ e(
          _e,
          {
            label: "笔记本管理",
            value: p,
            onChange: (M) => {
              h(M), M === "history" && c && H.run(c);
            },
            items: [
              { id: "update", label: "预览与发布" },
              { id: "source", label: "来源与更新" },
              { id: "history", label: "发布历史" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...H }),
        /* @__PURE__ */ e("fieldset", { disabled: H.busy, children: /* @__PURE__ */ o(fe, { children: [
          p === "update" && /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ o(ee, { title: "准备课程资料", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "资料来源目录",
                  value: w,
                  onChange: (M) => {
                    g(M), S(null);
                  },
                  hint: "选择已经上传的课程资料目录。"
                }
              ),
              /* @__PURE__ */ o(
                "label",
                {
                  className: "fp-workspace-upload",
                  role: "button",
                  tabIndex: 0,
                  onKeyDown: (M) => {
                    (M.key === "Enter" || M.key === " ") && (M.preventDefault(), M.currentTarget.querySelector("input")?.click());
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: A || "选择目录清单" }),
                    /* @__PURE__ */ e("span", { children: "JSON 文件，最大 2 MB" }),
                    /* @__PURE__ */ e(
                      "input",
                      {
                        hidden: !0,
                        type: "file",
                        "aria-label": "选择目录清单",
                        accept: ".json,application/json",
                        onChange: (M) => {
                          const K = M.target.files?.[0];
                          M.target.value = "", K && (C(void 0), L(""), S(null), H.run(async () => {
                            if (K.size > 2e6)
                              throw new Error("清单文件不能超过 2 MB。");
                            let j;
                            try {
                              j = JSON.parse(await K.text());
                            } catch {
                              throw new Error(
                                "无法读取清单，请选择有效的 JSON 文件。"
                              );
                            }
                            C(j), L(K.name), S(null);
                          }));
                        }
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: O,
                  children: H.busy ? "正在检查…" : "检查并预览"
                }
              )
            ] }),
            n.length > 0 && /* @__PURE__ */ e(ee, { title: "待发布内容", children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: n.map((M) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                onClick: () => {
                  S(M), T(M.items[0]?.id || "");
                },
                children: [
                  /* @__PURE__ */ e("strong", { children: M.title }),
                  /* @__PURE__ */ o("small", { children: [
                    M.sections,
                    " 个章节 · ",
                    M.resources,
                    " 份资料"
                  ] })
                ]
              },
              M.id
            )) }) }),
            U && /* @__PURE__ */ o(
              ee,
              {
                title: U.title,
                description: `${U.sections} 个章节 · ${U.resources} 份资料${U.structureChanged ? " · 目录有调整" : ""}`,
                children: [
                  /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
                    /* @__PURE__ */ e(
                      "nav",
                      {
                        className: "fp-workspace-item-list",
                        "aria-label": "草稿章节",
                        children: U.items.map((M) => /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            "aria-pressed": M.id === R?.id,
                            onClick: () => T(M.id),
                            children: M.title
                          },
                          M.id
                        ))
                      }
                    ),
                    /* @__PURE__ */ e("article", { children: R ? /* @__PURE__ */ e(
                      bt,
                      {
                        markdown: R.content,
                        resolveResourceUrl: d
                      }
                    ) : /* @__PURE__ */ e("p", { children: "此草稿还没有可预览的章节。" }) })
                  ] }),
                  /* @__PURE__ */ e(
                    be,
                    {
                      disabled: !U.items.length,
                      confirm: `将“${U.title}”发布给读者？`,
                      onAction: async () => {
                        await i(U.id, t?.currentRelease), S(null), H.setMessage("发布完成，读者可以看到新内容。");
                      },
                      children: "确认发布"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-ghost",
                      onClick: () => S(null),
                      children: "返回修改"
                    }
                  )
                ]
              }
            )
          ] }),
          p === "source" && /* @__PURE__ */ o(ee, { title: "资料来源与更新方式", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "来源目录",
                value: w,
                onChange: (M) => {
                  g(M), S(null);
                }
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "发布方式",
                value: v,
                options: [
                  {
                    value: "review",
                    label: "确认后发布",
                    description: "先预览内容，再决定发布时间。"
                  },
                  {
                    value: "auto",
                    label: "自动发布",
                    description: "正文变化自动更新，目录调整仍需确认。"
                  }
                ],
                onChange: (M) => x(M)
              }
            ),
            l && /* @__PURE__ */ e(
              it,
              {
                busy: H.busy,
                dirty: b,
                onClick: () => {
                  H.run(async () => {
                    if (!w.trim()) throw new Error("请填写来源目录。");
                    const M = {
                      sourcePrefix: w.trim(),
                      syncMode: v
                    };
                    await l(M), y(M);
                  }, "来源与更新方式已保存。");
                }
              }
            )
          ] }),
          p === "history" && /* @__PURE__ */ o(ee, { title: "发布历史", children: [
            r.map((M) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
              /* @__PURE__ */ o("div", { children: [
                /* @__PURE__ */ e("strong", { children: M.label || new Date(M.createdAt).toLocaleString("zh-CN") }),
                /* @__PURE__ */ e("p", { children: M.id === t?.currentRelease ? "当前阅读版本" : "历史阅读版本" })
              ] }),
              s && t && M.id !== t.currentRelease && /* @__PURE__ */ e(
                be,
                {
                  confirm: "恢复此版本？后续更新将等待你确认。",
                  onAction: async () => {
                    await s(
                      M.id,
                      t.currentRelease
                    ), H.setMessage("阅读版本已恢复。");
                  },
                  children: "恢复版本"
                }
              )
            ] }, M.id)),
            !r.length && /* @__PURE__ */ e("p", { children: "暂无发布历史。" })
          ] })
        ] }) })
      ]
    }
  ) });
}
function Eh({
  notebooks: t,
  drafts: n,
  versions: r = {},
  loading: a,
  error: i,
  onPrepare: l,
  onPublish: s,
  onSetSource: c,
  onRestore: u,
  onLoadVersions: d,
  onRefresh: p,
  resolveResourceUrl: h
}) {
  const [f, m] = k(""), [b, y] = k("all"), [w, v] = k(null), g = t.find((A) => A.id === w), x = n.filter(
    (A) => w === "new" ? !A.notebookId : A.notebookId === w
  ), N = t.filter(
    (A) => A.title.toLowerCase().includes(f.trim().toLowerCase()) && (b === "all" || n.some((L) => L.notebookId === A.id))
  ), C = n.filter(
    (A) => !A.notebookId || !t.some((L) => L.id === A.notebookId)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "笔记本",
      description: "整理课程资料，检查更新并发布阅读版本。",
      actions: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          onClick: () => v("new"),
          children: "新建笔记本"
        }
      ),
      children: [
        /* @__PURE__ */ e(X, { label: "搜索笔记本", value: f, onChange: m }),
        /* @__PURE__ */ e(
          _e,
          {
            label: "笔记本筛选",
            value: b,
            onChange: y,
            items: [
              { id: "all", label: "全部笔记本" },
              { id: "pending", label: "有待发布内容" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { error: i }),
        a ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ o("div", { className: "fp-workspace-item-list", children: [
          N.map((A) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              "aria-pressed": w === A.id,
              onClick: () => v(A.id),
              children: [
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: A.title }),
                  /* @__PURE__ */ e("small", { children: n.some((L) => L.notebookId === A.id) ? "有内容等待发布" : "课程内容已发布" })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            A.id
          )),
          !N.length && /* @__PURE__ */ e("p", { children: f ? "没有找到匹配的笔记本。" : "选择新建笔记本，开始整理课程。" }),
          C.filter(
            (A) => A.title.toLowerCase().includes(f.toLowerCase())
          ).map((A) => /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => v("new"),
              children: /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: A.title }),
                /* @__PURE__ */ e("small", { children: "首次发布待确认" })
              ] })
            },
            A.id
          ))
        ] }),
        /* @__PURE__ */ e(fe, { children: w && /* @__PURE__ */ e(
          ee,
          {
            title: g?.title || "准备新的笔记本",
            actions: /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => v(null),
                children: "返回笔记本列表"
              }
            ),
            children: /* @__PURE__ */ e(
              hu,
              {
                notebook: g,
                drafts: x,
                versions: r[w],
                onPrepare: l,
                onPublish: s,
                onSetSource: g && c ? (A) => c(g.id, A) : void 0,
                onRestore: g && u ? (A, L) => u(g.id, A, L) : void 0,
                onLoadVersions: g && d ? () => d(g.id) : void 0,
                onRefresh: p,
                resolveResourceUrl: h
              },
              w
            )
          }
        ) })
      ]
    }
  ) });
}
function mu({
  versions: t,
  selectedId: n,
  onSelect: r,
  onRestore: a,
  loading: i,
  error: l
}) {
  const [s, c] = k(null), [u, d] = k(!1), [p, h] = k(""), f = B(!1), m = t.find((b) => b.id === n);
  return /* @__PURE__ */ o("section", { className: "fp-version-history", "aria-label": "笔记历史", children: [
    /* @__PURE__ */ e("div", { className: "fp-version-list", "aria-busy": i, children: i ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取历史…" }) : t.length ? t.map((b) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": b.id === n,
        onClick: () => {
          c(null), h(""), r(b.id);
        },
        children: [
          /* @__PURE__ */ e(Rn, { size: 15 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: b.label }),
            /* @__PURE__ */ o("small", { children: [
              b.date,
              b.author && ` · ${b.author}`
            ] })
          ] })
        ]
      },
      b.id
    )) : /* @__PURE__ */ e("p", { children: "还没有保存的历史版本。" }) }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o("div", { className: "fp-version-preview", children: [
      m ? /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e("h3", { children: m.label }),
        m.preview,
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: s === m.id ? /* @__PURE__ */ o(Z, { children: [
          /* @__PURE__ */ e("span", { children: "将当前笔记恢复到此版本？" }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: async () => {
                if (!f.current) {
                  f.current = !0, d(!0), h("");
                  try {
                    await a(m.id), c(null);
                  } catch {
                    h("恢复未能完成，当前内容已保留。");
                  } finally {
                    f.current = !1, d(!1);
                  }
                }
              },
              children: u ? "正在恢复…" : "确认恢复"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: () => c(null),
              children: "取消"
            }
          )
        ] }) : /* @__PURE__ */ o("button", { type: "button", onClick: () => c(m.id), children: [
          /* @__PURE__ */ e(rt, { size: 15 }),
          "恢复此版本"
        ] }) })
      ] }) : /* @__PURE__ */ e("p", { children: "选择一个版本查看内容。" }),
      (l || p) && /* @__PURE__ */ e("p", { role: "alert", children: l || p })
    ] }) })
  ] });
}
function $h({
  local: t,
  remote: n,
  onResolve: r
}) {
  const [a, i] = k(!1), [l, s] = k(""), c = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-save-conflict", "aria-label": "处理笔记冲突", children: [
    /* @__PURE__ */ e("h3", { children: "笔记有新的修改" }),
    /* @__PURE__ */ e("p", { children: "比较两个版本，选择要继续使用的内容。" }),
    /* @__PURE__ */ o("div", { className: "fp-compare-panes", children: [
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "我的修改" }),
        t
      ] }),
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "最新版本" }),
        n
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: ["local", "remote"].map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        disabled: a,
        onClick: async () => {
          if (!c.current) {
            c.current = !0, i(!0), s("");
            try {
              await r(u);
            } catch {
              s("暂时无法应用，请重试。");
            } finally {
              c.current = !1, i(!1);
            }
          }
        },
        children: u === "local" ? "使用我的修改" : "使用最新版本"
      },
      u
    )) }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l })
  ] });
}
function zh({
  items: t,
  onOpen: n,
  loading: r = !1
}) {
  return /* @__PURE__ */ o("section", { className: "fp-backlinks", "aria-label": "关联笔记", children: [
    /* @__PURE__ */ e("h3", { children: "引用这篇笔记" }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在查找关联…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((a) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("button", { type: "button", onClick: () => n(a.id), children: [
      /* @__PURE__ */ e(ft, { size: 15 }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: a.title }),
        a.excerpt && /* @__PURE__ */ e("small", { children: a.excerpt })
      ] })
    ] }) }, a.id)) }) : /* @__PURE__ */ e("p", { children: "还没有其他笔记引用这里。" })
  ] });
}
function Ih({
  previewUrl: t,
  onChoose: n,
  onCancel: r,
  busy: a = !1,
  error: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-image-paste", "aria-label": "添加图片", children: [
    /* @__PURE__ */ e("img", { src: t, alt: "待添加的图片" }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: "如何添加这张图片？" }),
      /* @__PURE__ */ e("p", { children: "保留图片，或识别其中的文字与公式。" }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: a,
            onClick: () => n("image"),
            children: "插入图片"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: a,
            onClick: () => n("recognize"),
            children: "识别内容"
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: a, onClick: r, children: "取消" })
      ] }),
      a && /* @__PURE__ */ e("p", { role: "status", children: "正在处理图片…" }),
      i && /* @__PURE__ */ e("p", { role: "alert", children: i })
    ] })
  ] });
}
function Ah({ lines: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-version-diff", "aria-label": "版本变化", children: t.map((n, r) => /* @__PURE__ */ o("div", { "data-kind": n.kind, children: [
    /* @__PURE__ */ e(
      "span",
      {
        "aria-label": n.kind === "added" ? "新增" : n.kind === "removed" ? "删除" : "保留",
        children: n.kind === "added" ? "+" : n.kind === "removed" ? "−" : " "
      }
    ),
    /* @__PURE__ */ e("code", { children: n.text || " " })
  ] }, r)) });
}
function bu(t) {
  return /* @__PURE__ */ e(gu, { ...t }, t.document.id);
}
function gu({
  document: t,
  onSave: n,
  autosaveDelay: r = 1600,
  readOnly: a,
  editorProps: i,
  versions: l = [],
  onRestore: s,
  onExportDraft: c,
  registerNavigationGuard: u,
  onDirtyChange: d
}) {
  const [p, h] = k(t), [f, m] = k(t.markdown), [b, y] = k(
    "clean"
  ), [w, v] = k(""), [g, x] = k(null), [N, C] = k(!1), [A, L] = k(l[0]?.id), [U, S] = k(!1), I = B(!1), T = p.markdown !== f, H = B(p), R = B(n), O = B(null), M = B(null), K = B(!0), j = B(t.revision);
  H.current = p, R.current = n, Y(() => (K.current = !0, () => {
    K.current = !1, O.current?.abort();
  }), []), Y(() => {
    d?.(T);
  }, [T, d]), Y(() => {
    t.revision !== j.current && (T || M.current ? x(t) : (j.current = t.revision, h(t), m(t.markdown)));
  }, [t, T]);
  const P = xe(() => {
    if (M.current) return M.current;
    if (a || g) return Promise.resolve(!T);
    const $ = H.current, z = new AbortController();
    O.current = z, y("saving"), v("");
    const E = (async () => {
      try {
        const D = await R.current($, z.signal);
        if (z.signal.aborted || !K.current) return !1;
        if (D.id !== $.id)
          throw new Error("保存的笔记不匹配，请重试。");
        return j.current = D.revision, m(D.markdown), h(
          (ne) => ne.markdown === $.markdown ? D : { ...ne, revision: D.revision }
        ), y("saved"), !0;
      } catch (D) {
        return K.current && !z.signal.aborted && (y("error"), v(
          D instanceof Error ? D.message : "保存未完成，当前内容已保留。"
        )), !1;
      } finally {
        M.current = null;
      }
    })();
    return M.current = E, E;
  }, [a, g, T]);
  return Y(() => {
    if (!T || a || g || b === "error" || b === "saving" || r <= 0)
      return;
    const $ = setTimeout(() => {
      P();
    }, r);
    return () => clearTimeout($);
  }, [T, p.markdown, a, g, b, r, P]), Y(
    () => u?.(async () => T ? await P() ? H.current.markdown === p.markdown : !1 : !0),
    [u, T, P, p.markdown]
  ), Y(() => {
    const $ = (z) => {
      T && (z.preventDefault(), z.returnValue = "");
    };
    return window.addEventListener("beforeunload", $), () => window.removeEventListener("beforeunload", $);
  }, [T]), /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form",
      onKeyDown: ($) => {
        ($.ctrlKey || $.metaKey) && $.key.toLowerCase() === "s" && ($.preventDefault(), T && P());
      },
      children: /* @__PURE__ */ o(
        ee,
        {
          title: p.title,
          actions: /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e("span", { role: "status", children: a ? "只读" : b === "saving" ? "正在保存…" : T ? "有待保存的更改" : "已保存" }),
            l.length > 0 && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                "aria-expanded": N,
                onClick: () => C(!N),
                children: "版本历史"
              }
            ),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: () => c(p),
                children: "导出笔记"
              }
            ),
            !a && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-primary",
                disabled: !T || b === "saving" || !!g || U,
                onClick: () => {
                  P();
                },
                children: "保存"
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(Se, { error: w }),
            /* @__PURE__ */ e(fe, { children: g && /* @__PURE__ */ o("div", { className: "fp-workspace-subsection", role: "alert", children: [
              /* @__PURE__ */ e("strong", { children: "这篇笔记有新的版本" }),
              /* @__PURE__ */ e("p", { children: "当前编辑内容已保留，请先导出需要保留的内容，再选择继续使用的版本。" }),
              /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      j.current = g.revision, h(g), m(g.markdown), x(null), v(""), y("clean");
                    },
                    children: "读取最新版本"
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      j.current = g.revision, h(($) => ({
                        ...$,
                        revision: g.revision
                      })), x(null), y("clean");
                    },
                    children: "继续编辑当前内容"
                  }
                )
              ] })
            ] }) }),
            /* @__PURE__ */ e(
              Xn,
              {
                ...i,
                documentKey: t.id,
                markdown: p.markdown,
                editable: !a && !U,
                onChange: ($) => {
                  h((z) => ({ ...z, markdown: $ })), b !== "saving" && y("clean");
                }
              }
            ),
            /* @__PURE__ */ e(fe, { children: N && /* @__PURE__ */ e(
              mu,
              {
                versions: l,
                selectedId: A,
                onSelect: L,
                onRestore: async ($) => {
                  if (!s) throw new Error("暂时无法恢复此版本。");
                  if (!I.current) {
                    I.current = !0, S(!0);
                    try {
                      const z = H.current;
                      if (T && !await P())
                        throw new Error("请先保存当前更改。");
                      if (H.current.markdown !== z.markdown)
                        throw new Error("请先保存当前更改。");
                      const E = new AbortController();
                      O.current = E;
                      const D = await s(
                        $,
                        H.current.revision,
                        E.signal
                      );
                      if (!K.current || E.signal.aborted) return;
                      if (D.id !== t.id)
                        throw new Error("恢复的笔记不匹配，请重试。");
                      j.current = D.revision, h(D), m(D.markdown), y("saved");
                    } finally {
                      I.current = !1, K.current && S(!1);
                    }
                  }
                }
              }
            ) })
          ]
        }
      )
    }
  );
}
function Lh(t) {
  return /* @__PURE__ */ e(yu, { ...t }, t.document.id);
}
function yu({
  document: t,
  onSave: n,
  autosaveDelay: r,
  versions: a,
  onRestore: i,
  editorProps: l,
  onExportDraft: s,
  subject: c,
  summary: u,
  examples: d = [],
  quiz: p,
  readOnly: h,
  loading: f,
  error: m,
  onRetry: b,
  actions: y,
  contentProps: w,
  renderedContent: v
}) {
  const [g, x] = k("content"), [N, C] = k(!1), [A, L] = k(!1), [U, S] = k(d[0]?.id || ""), I = B(null), T = Le(), H = (O) => {
    T.run(async () => {
      if (N && I.current && !await I.current())
        throw new Error("当前修改已保留，请保存后继续。");
      C(!1), x(O);
    });
  }, R = d.find((O) => O.id === U) || d[0];
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ e(
    _n,
    {
      open: A,
      onExit: () => L(!1),
      label: t.title,
      children: /* @__PURE__ */ e("div", { className: "fp-course-content", children: /* @__PURE__ */ o(
        ee,
        {
          title: t.title,
          description: [c, u].filter(Boolean).join(" · "),
          actions: /* @__PURE__ */ o(Z, { children: [
            y,
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": A ? "退出全屏" : "全屏阅读",
                onClick: () => L(!A),
                children: A ? /* @__PURE__ */ e(Yl, { size: 17 }) : /* @__PURE__ */ e(On, { size: 17 })
              }
            ),
            A && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": "关闭全屏阅读",
                onClick: () => L(!1),
                children: /* @__PURE__ */ e(ge, { size: 17 })
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(
              _e,
              {
                label: "课程内容",
                value: g,
                onChange: H,
                items: [
                  { id: "content", label: "正文" },
                  ...d.length ? [{ id: "examples", label: `例题 ${d.length}` }] : [],
                  ...p ? [{ id: "quiz", label: "练习" }] : []
                ]
              }
            ),
            /* @__PURE__ */ e(Se, { error: m || T.error }),
            /* @__PURE__ */ e(fe, { children: f ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开课程内容…" }) : m ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: b,
                children: "重新打开"
              }
            ) : g === "quiz" ? p : g === "examples" ? /* @__PURE__ */ o(Z, { children: [
              /* @__PURE__ */ e("nav", { className: "fp-workspace-actions", "aria-label": "例题列表", children: d.map((O) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  "aria-pressed": R?.id === O.id,
                  onClick: () => S(O.id),
                  children: O.title
                },
                O.id
              )) }),
              R && /* @__PURE__ */ e(
                bt,
                {
                  ...w,
                  markdown: R.markdown
                }
              )
            ] }) : N ? /* @__PURE__ */ e(
              bu,
              {
                document: t,
                onSave: n,
                autosaveDelay: r,
                versions: a,
                onRestore: i,
                editorProps: l,
                onExportDraft: s,
                registerNavigationGuard: (O) => (I.current = O, () => {
                  I.current = null;
                })
              }
            ) : v ?? /* @__PURE__ */ e(
              bt,
              {
                ...w,
                markdown: t.markdown
              }
            ) }),
            g === "content" && !h && !f && !m && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                disabled: T.busy,
                onClick: () => {
                  T.run(async () => {
                    if (N && I.current && !await I.current())
                      throw new Error("当前修改已保留，请保存后继续。");
                    C(!N);
                  });
                },
                children: N ? "完成编辑" : "编辑笔记"
              }
            )
          ]
        }
      ) })
    }
  ) });
}
function Tn(t) {
  try {
    const n = new URL(
      /^[a-z][a-z\d+.-]*:/i.test(t.trim()) ? t.trim() : `https://${t.trim()}`
    );
    return ["http:", "https:"].includes(n.protocol) && n.hostname ? n.href : "";
  } catch {
    return "";
  }
}
function vu({
  bookmarks: t,
  homeUrl: n,
  onAdd: r,
  onRemove: a,
  onOpen: i,
  onHomeChange: l
}) {
  const [s, c] = k(""), [u, d] = k(""), p = Le(), {
    draft: h,
    setDraft: f,
    dirty: m,
    accept: b
  } = et(n);
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "浏览与收藏", children: [
    /* @__PURE__ */ e(Se, { ...p }),
    /* @__PURE__ */ o(ee, { title: "添加收藏", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "收藏名称",
          value: s,
          onChange: c,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        X,
        {
          label: "网页地址",
          value: u,
          onChange: d,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: p.busy || !u.trim(),
          onClick: () => {
            p.run(async () => {
              const y = Tn(u);
              if (!y) throw new Error("请填写有效的网页地址。");
              await r({
                name: s.trim() || new URL(y).hostname,
                url: y
              }), c(""), d("");
            }, "收藏已添加。");
          },
          children: "添加收藏"
        }
      )
    ] }),
    /* @__PURE__ */ o(ee, { title: "我的收藏", children: [
      t.map((y) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-ghost",
            onClick: () => i(y.id),
            children: y.name
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            confirm: `移除“${y.name}”收藏？`,
            onAction: () => a(y.id),
            children: "移除"
          }
        )
      ] }, y.id)),
      !t.length && /* @__PURE__ */ e("p", { children: "添加常用网页，下次可以快速打开。" })
    ] }),
    /* @__PURE__ */ o(ee, { title: "浏览器主页", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "主页地址",
          value: h,
          onChange: f,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        it,
        {
          busy: p.busy,
          dirty: m,
          label: "保存主页",
          onClick: () => {
            p.run(async () => {
              const y = Tn(h);
              if (!y) throw new Error("请填写有效的主页地址。");
              await l(y), b(y);
            }, "主页已更新。");
          }
        }
      )
    ] })
  ] }) });
}
function ol({
  title: t,
  icon: n,
  onClose: r,
  onMinimize: a,
  onFullscreen: i,
  isFullscreen: l = !1,
  children: s,
  onDragStart: c,
  actions: u,
  className: d,
  native: p = !1,
  closeLabel: h = "关闭窗口",
  closeShortcut: f
}) {
  return /* @__PURE__ */ o("div", { className: `fp-window${p ? " fp-window-native" : ""} ${d || ""}`, children: [
    /* @__PURE__ */ o(
      "header",
      {
        className: "fp-window-bar",
        onPointerDown: (m) => {
          m.button === 0 && !m.target.closest(
            "button,a,input,textarea,select,[data-no-drag]"
          ) && c?.(m);
        },
        "data-draggable": c ? !0 : void 0,
        children: [
          /* @__PURE__ */ o("div", { className: "fp-window-title", children: [
            n,
            /* @__PURE__ */ e("span", { "data-fp-tooltip": t, "data-fp-tooltip-side": "left", children: t })
          ] }),
          u && /* @__PURE__ */ e("div", { className: "fp-window-actions", "data-no-drag": !0, children: u }),
          /* @__PURE__ */ o("div", { className: "fp-window-controls", "data-no-drag": !0, children: [
            a && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": "最小化窗口",
                "data-fp-tooltip": "最小化",
                "data-fp-tooltip-side": "left",
                onClick: a,
                children: /* @__PURE__ */ e(Tt, { size: 16 })
              }
            ),
            i && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": l ? "退出全屏" : "全屏",
                "data-fp-tooltip": l ? "退出全屏" : "全屏",
                "data-fp-tooltip-side": "left",
                onClick: i,
                children: l ? /* @__PURE__ */ e(xr, { size: 16 }) : /* @__PURE__ */ e(Cr, { size: 16 })
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control fp-window-control-close",
                "aria-label": h,
                "data-fp-tooltip": f ? `${h}（${f}）` : h,
                "data-fp-tooltip-side": "left",
                onClick: r,
                children: /* @__PURE__ */ e(ge, { size: 16 })
              }
            )
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-window-body", children: s })
  ] });
}
const sl = Dn(
  () => () => {
  }
);
function wu(t, n) {
  const r = n.toLowerCase().split("+").map((l) => l.trim()), a = r.at(-1), i = (l) => r.includes(l);
  return t.key.toLowerCase() === a && (i("mod") ? t.ctrlKey || t.metaKey : t.ctrlKey === i("ctrl") && t.metaKey === i("meta")) && t.altKey === i("alt") && t.shiftKey === i("shift");
}
function Th({
  children: t,
  paused: n = !1
}) {
  const r = B(/* @__PURE__ */ new Map());
  Y(() => {
    const i = (l) => {
      if (n || l.defaultPrevented || l.isComposing || l.key === "Process")
        return;
      const s = l.target instanceof Element && !!l.target.closest(
        "input,textarea,[contenteditable=true],math-field,[role=dialog],[role=menu]"
      ), c = [...r.current.values()].sort(
        (u, d) => (d.priority || 0) - (u.priority || 0)
      );
      for (const u of c)
        if (!(u.enabled === !1 || s && !u.allowInInput || !wu(l, u.keys))) {
          l.preventDefault(), u.run();
          break;
        }
    };
    return window.addEventListener("keydown", i), () => window.removeEventListener("keydown", i);
  }, [n]);
  const a = B((i) => {
    const l = Symbol(i.id);
    return r.current.set(l, i), () => {
      r.current.delete(l);
    };
  });
  return /* @__PURE__ */ e(sl.Provider, { value: a.current, children: t });
}
function Dh(t) {
  const n = rn(sl);
  Y(
    () => n(t),
    [
      n,
      t.id,
      t.keys,
      t.enabled,
      t.allowInInput,
      t.priority,
      t.run
    ]
  );
}
function Ph({
  items: t,
  onChange: n,
  onReset: r
}) {
  const [a, i] = k(""), [l, s] = k(null), [c, u] = k("");
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "快捷键" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-pattern-input",
        "aria-label": "搜索快捷键",
        placeholder: "查找操作",
        value: a,
        onChange: (d) => i(d.target.value)
      }
    ),
    t.filter((d) => d.label.includes(a)).map((d) => /* @__PURE__ */ o("div", { className: "fp-shortcut-setting", children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `设置${d.label}快捷键`,
          onClick: () => {
            u(""), s(d.id);
          },
          onKeyDown: (p) => {
            if (l !== d.id) return;
            if (p.preventDefault(), p.stopPropagation(), p.key === "Escape") {
              s(null);
              return;
            }
            if (["Control", "Shift", "Alt", "Meta"].includes(p.key)) return;
            const h = [
              p.ctrlKey ? "Ctrl" : "",
              p.metaKey ? "Meta" : "",
              p.altKey ? "Alt" : "",
              p.shiftKey ? "Shift" : "",
              p.key
            ].filter(Boolean).join("+");
            if (t.some(
              (f) => f.id !== d.id && f.enabled && f.keys.toLowerCase() === h.toLowerCase()
            )) {
              u("这个快捷键已被其他操作使用。");
              return;
            }
            n(d.id, h, d.enabled), s(null);
          },
          children: l === d.id ? "按下新的快捷键…" : d.keys
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-pressed": d.enabled,
          onClick: () => n(d.id, d.keys, !d.enabled),
          children: d.enabled ? "已启用" : "已停用"
        }
      )
    ] }, d.id)),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "恢复默认" })
  ] });
}
function ir(t, n, r = { width: 300, height: 200 }) {
  const a = Math.min(n.width, Math.max(r.width, t.width)), i = Math.min(
    n.height,
    Math.max(r.height, t.height)
  );
  return {
    width: a,
    height: i,
    x: Math.max(0, Math.min(n.width - a, t.x)),
    y: Math.max(0, Math.min(n.height - i, t.y))
  };
}
function Oh({
  title: t,
  geometry: n,
  onGeometryChange: r,
  onClose: a,
  onMinimize: i,
  onFocus: l,
  children: s,
  zIndex: c = 40,
  minWidth: u = 300,
  minHeight: d = 200,
  contained: p = !1
}) {
  const [h, f] = k(!1), m = B(null), b = B(null), [y, w] = k(null);
  Ce(() => {
    const N = () => {
      const A = p ? b.current?.parentElement : null, L = {
        width: A?.clientWidth || window.innerWidth,
        height: A?.clientHeight || window.innerHeight
      };
      w(
        (U) => U?.width === L.width && U.height === L.height ? U : L
      );
    };
    N();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(N);
    return p && b.current?.parentElement && C?.observe(b.current.parentElement), window.addEventListener("resize", N), () => {
      C?.disconnect(), window.removeEventListener("resize", N);
    };
  }, [p]);
  const v = y ? ir(n, y, {
    width: u,
    height: d
  }) : n, g = B(n);
  g.current = v;
  const x = (N, C) => {
    N.button !== 0 || h || N.target.closest(
      "button,input,textarea,a,[data-no-drag]"
    ) || (N.preventDefault(), N.currentTarget.setPointerCapture(N.pointerId), m.current = {
      mode: C,
      x: N.clientX,
      y: N.clientY,
      value: g.current
    }, l?.());
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: b,
      className: "fp-floating-window",
      role: "region",
      "aria-label": t,
      style: h ? { position: p ? "absolute" : "fixed", inset: 8, zIndex: c } : {
        position: p ? "absolute" : "fixed",
        left: v.x,
        top: v.y,
        width: v.width,
        height: v.height,
        zIndex: c
      },
      onPointerDown: l,
      onPointerMove: (N) => {
        const C = m.current;
        if (!C) return;
        const A = y || {
          width: window.innerWidth,
          height: window.innerHeight
        }, L = N.clientX - C.x, U = N.clientY - C.y;
        r(
          ir(
            C.mode === "move" ? {
              ...C.value,
              x: C.value.x + L,
              y: C.value.y + U
            } : {
              ...C.value,
              width: Math.max(
                u,
                Math.min(
                  A.width - C.value.x,
                  C.value.width + L
                )
              ),
              height: Math.max(
                d,
                Math.min(
                  A.height - C.value.y,
                  C.value.height + U
                )
              )
            },
            A,
            { width: u, height: d }
          )
        );
      },
      onPointerUp: () => {
        m.current = null;
      },
      onPointerCancel: () => {
        m.current = null;
      },
      children: [
        /* @__PURE__ */ e(
          ol,
          {
            title: t,
            onClose: a,
            onMinimize: i,
            onFullscreen: () => f((N) => !N),
            isFullscreen: h,
            onDragStart: (N) => x(N, "move"),
            children: s
          }
        ),
        !h && /* @__PURE__ */ e(
          "div",
          {
            className: "fp-window-resize",
            role: "separator",
            "aria-label": "调整窗口大小",
            "aria-orientation": "horizontal",
            tabIndex: 0,
            onPointerDown: (N) => x(N, "resize"),
            onKeyDown: (N) => {
              ["ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown"].includes(
                N.key
              ) && (N.preventDefault(), r(
                ir(
                  {
                    ...v,
                    width: Math.max(
                      u,
                      v.width + (N.key === "ArrowRight" ? 16 : N.key === "ArrowLeft" ? -16 : 0)
                    ),
                    height: Math.max(
                      d,
                      v.height + (N.key === "ArrowDown" ? 16 : N.key === "ArrowUp" ? -16 : 0)
                    )
                  },
                  y || {
                    width: window.innerWidth,
                    height: window.innerHeight
                  },
                  { width: u, height: d }
                )
              ));
            }
          }
        )
      ]
    }
  );
}
function ku({
  url: t,
  onNavigate: n,
  onBack: r,
  onForward: a,
  canBack: i,
  canForward: l,
  loading: s,
  error: c,
  children: u
}) {
  const [d, p] = k(t), [h, f] = k("");
  return Y(() => p(t), [t]), /* @__PURE__ */ o("section", { className: "fp-browser-surface", children: [
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: (m) => {
          m.preventDefault();
          try {
            const b = Tn(d);
            if (!b) throw Error();
            f(""), n(b);
          } catch {
            f("请输入有效的网址。");
          }
        },
        children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "后退",
              disabled: !i,
              onClick: r,
              children: "←"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "前进",
              disabled: !l,
              onClick: a,
              children: "→"
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "网页地址",
              value: d,
              onChange: (m) => p(m.target.value)
            }
          ),
          /* @__PURE__ */ e("button", { type: "submit", children: "前往" })
        ]
      }
    ),
    (c || h) && /* @__PURE__ */ e("p", { role: "alert", children: c || h }),
    s && /* @__PURE__ */ e("p", { role: "status", children: "正在打开网页…" }),
    /* @__PURE__ */ e("div", { children: u })
  ] });
}
function Fh({
  title: t = "导入学习资料",
  accept: n,
  multiple: r = !0,
  onImport: a,
  children: i
}) {
  const l = B(null), [s, c] = k([]), [u, d] = k(""), p = (h) => {
    d(""), c(r ? h : h.slice(0, 1));
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "fp-import-drop",
        onDragOver: (h) => h.preventDefault(),
        onDrop: (h) => {
          h.preventDefault(), p(Array.from(h.dataTransfer.files));
        },
        children: [
          /* @__PURE__ */ e("p", { children: "将文件拖到这里，或选择文件。" }),
          /* @__PURE__ */ e(
            "input",
            {
              ref: l,
              type: "file",
              accept: n,
              multiple: r,
              hidden: !0,
              onChange: (h) => {
                p(Array.from(h.target.files || [])), h.target.value = "";
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => l.current?.click(), children: "选择文件" })
        ]
      }
    ),
    s.length > 0 && /* @__PURE__ */ e("ul", { children: s.map((h, f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { children: h.name }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `移除${h.name}`,
          onClick: () => c((m) => m.filter((b, y) => y !== f)),
          children: "移除"
        }
      )
    ] }, `${h.name}-${f}`)) }),
    i,
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !s.length,
        onAction: async () => {
          const h = s;
          try {
            await a(h), c((f) => f === h ? [] : f);
          } catch (f) {
            throw d("资料已保留，可以重试。"), f;
          }
        },
        children: "开始导入"
      }
    ) }),
    u && /* @__PURE__ */ e("p", { role: "status", children: u })
  ] });
}
function Rh({
  children: t,
  fallback: n = null,
  margin: r = "240px"
}) {
  const a = B(null), [i, l] = k(!1);
  return Y(() => {
    if (!a.current) return;
    if (typeof IntersectionObserver > "u") {
      l(!0);
      return;
    }
    const s = new IntersectionObserver(
      (c) => {
        c.some((u) => u.isIntersecting) && (l(!0), s.disconnect());
      },
      { rootMargin: r }
    );
    return s.observe(a.current), () => s.disconnect();
  }, [r]), /* @__PURE__ */ e("div", { ref: a, children: i ? t : n });
}
function Bh({
  url: t,
  onNavigate: n,
  children: r,
  homeUrl: a,
  canBack: i,
  canForward: l,
  onBack: s,
  onForward: c,
  onRefresh: u,
  onOpenExternal: d,
  loading: p,
  error: h,
  viewport: f = "desktop",
  onViewportChange: m,
  bookmarks: b = [],
  onAddBookmark: y,
  onRemoveBookmark: w,
  onHomeChange: v
}) {
  const [g, x] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form fp-browser-workspace", children: [
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", "aria-label": "浏览器操作", children: [
      a && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "打开主页",
          onClick: () => {
            const N = Tn(a);
            N && n(N);
          },
          children: /* @__PURE__ */ e(Gl, { size: 17 })
        }
      ),
      u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "刷新网页",
          onClick: u,
          children: /* @__PURE__ */ e(Bn, { size: 17 })
        }
      ),
      m && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: () => m(f === "desktop" ? "mobile" : "desktop"),
          children: [
            f === "desktop" ? /* @__PURE__ */ e(Va, { size: 17 }) : /* @__PURE__ */ e(Jl, { size: 17 }),
            /* @__PURE__ */ e("span", { children: f === "desktop" ? "桌面视图" : "手机视图" })
          ]
        }
      ),
      d && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "在浏览器中打开",
          onClick: () => d(t),
          children: /* @__PURE__ */ e(Rt, { size: 17 })
        }
      ),
      y && w && v && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "浏览与收藏设置",
          "aria-expanded": g,
          onClick: () => x(!g),
          children: /* @__PURE__ */ e(Ql, { size: 17 })
        }
      )
    ] }),
    /* @__PURE__ */ e(fe, { children: g && y && w && v && /* @__PURE__ */ e(
      vu,
      {
        bookmarks: b,
        homeUrl: a || "",
        onAdd: y,
        onRemove: w,
        onHomeChange: v,
        onOpen: (N) => {
          const C = b.find((A) => A.id === N);
          C && (n(C.url), x(!1));
        }
      }
    ) }),
    /* @__PURE__ */ e(
      ku,
      {
        url: t,
        onNavigate: n,
        canBack: i,
        canForward: l,
        onBack: s,
        onForward: c,
        loading: p,
        error: h,
        children: /* @__PURE__ */ e("div", { className: "fp-browser-viewport", "data-viewport": f, children: r })
      }
    )
  ] });
}
function jh({
  users: t,
  groups: n,
  protectedUserIds: r = [],
  onSaveUser: a,
  onSaveGroup: i,
  onDeleteGroup: l,
  renderUserDetails: s,
  onRefresh: c,
  loading: u,
  error: d
}) {
  const [p, h] = k("users"), [f, m] = k(""), [b, y] = k(0), [w, v] = k(
    null
  ), g = Le(), x = (p === "users" ? t.map((C) => ({
    id: C.sub,
    label: C.name,
    description: C.email || C.sub,
    value: C
  })) : n.map((C) => ({
    id: C.id,
    label: C.name,
    description: `${C.members.length} 位成员 · ${C.description}`,
    value: C
  }))).filter(
    (C) => `${C.label} ${C.description}`.toLowerCase().includes(f.toLowerCase())
  ), N = Math.min(
    b,
    Math.max(0, Math.ceil(x.length / 20) - 1)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "用户与用户组", children: /* @__PURE__ */ o(
    ee,
    {
      title: "用户与授权",
      description: "管理成员资料、用户组和访问权限。",
      actions: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            disabled: u,
            onClick: () => v(
              p === "users" ? { sub: "", name: "", email: "", disabled: !1 } : {
                id: crypto.randomUUID(),
                name: "",
                description: "",
                members: []
              }
            ),
            children: p === "users" ? "添加用户" : "新建用户组"
          }
        ),
        c && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: g.busy,
            onClick: () => {
              g.run(c);
            },
            children: "刷新"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(
          _e,
          {
            label: "成员类型",
            value: p,
            onChange: (C) => {
              h(C), y(0), m("");
            },
            items: [
              { id: "users", label: `用户 ${t.length}` },
              { id: "groups", label: `用户组 ${n.length}` }
            ]
          }
        ),
        /* @__PURE__ */ e(
          X,
          {
            label: "搜索成员",
            value: f,
            onChange: (C) => {
              m(C), y(0);
            }
          }
        ),
        /* @__PURE__ */ e(Se, { error: d || g.error, message: g.message }),
        u ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取成员…" }) : /* @__PURE__ */ o(Z, { children: [
          /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: x.slice(N * 20, N * 20 + 20).map((C) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => v(C.value),
              children: [
                /* @__PURE__ */ e("span", { className: "fp-workspace-avatar", children: C.label.slice(0, 1) }),
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: C.label }),
                  /* @__PURE__ */ e("small", { children: C.description })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            C.id
          )) }),
          !x.length && /* @__PURE__ */ e("p", { children: "没有匹配的成员，试试其他关键词。" }),
          /* @__PURE__ */ o("footer", { className: "fp-workspace-pagination", children: [
            /* @__PURE__ */ o("span", { children: [
              x.length,
              " 项"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: !N,
                onClick: () => y(N - 1),
                children: "上一页"
              }
            ),
            /* @__PURE__ */ o("span", { children: [
              N + 1,
              " /",
              " ",
              Math.max(1, Math.ceil(x.length / 20))
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: (N + 1) * 20 >= x.length,
                onClick: () => y(N + 1),
                children: "下一页"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(fe, { children: w && ("members" in w ? /* @__PURE__ */ e(
          Nu,
          {
            group: w,
            users: t,
            onSave: i,
            onDelete: n.some((C) => C.id === w.id) ? l : void 0,
            onClose: () => v(null)
          },
          w.id
        ) : s?.(w, () => v(null)) || /* @__PURE__ */ e(
          cl,
          {
            protectedUser: r.includes(w.sub),
            user: w,
            existing: t.some((C) => C.sub === w.sub),
            onSave: a,
            onClose: () => v(null)
          },
          w.sub || "new"
        )) })
      ]
    }
  ) });
}
function Nu({
  group: t,
  users: n,
  onSave: r,
  onDelete: a,
  onClose: i
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = et(t), d = Le(), [p, h] = k("");
  return /* @__PURE__ */ o(
    ee,
    {
      title: l.name || "新建用户组",
      actions: /* @__PURE__ */ e(
        be,
        {
          confirm: c ? "放弃尚未保存的更改？" : void 0,
          disabled: d.busy,
          onAction: i,
          children: "关闭用户组"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组名称",
              value: l.name,
              onChange: (f) => s({ ...l, name: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组说明",
              value: l.description,
              onChange: (f) => s({ ...l, description: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "搜索候选成员",
              value: p,
              onChange: h
            }
          ),
          /* @__PURE__ */ e("div", { className: "fp-workspace-picker", children: n.filter(
            (f) => `${f.name} ${f.email || ""} ${f.sub}`.toLowerCase().includes(p.toLowerCase())
          ).map((f) => /* @__PURE__ */ e(
            ze,
            {
              label: f.name,
              description: f.email,
              checked: l.members.includes(f.sub),
              onChange: (m) => s({
                ...l,
                members: m ? [...l.members, f.sub] : l.members.filter((b) => b !== f.sub)
              })
            },
            f.sub
          )) }),
          /* @__PURE__ */ o("p", { children: [
            "已选 ",
            l.members.length,
            " 位成员"
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
            /* @__PURE__ */ e(
              it,
              {
                busy: d.busy,
                dirty: c,
                label: "保存用户组",
                onClick: () => {
                  if (!l.name.trim()) {
                    d.setError("请填写用户组名称。");
                    return;
                  }
                  d.run(async () => {
                    await r(l), u(l);
                  }, "用户组已保存。");
                }
              }
            ),
            a && /* @__PURE__ */ e(
              be,
              {
                confirm: "删除此用户组？通过该组获得的访问权限将失效。",
                onAction: async () => {
                  await a(l.id), i();
                },
                children: "删除用户组"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(Se, { ...d })
      ]
    }
  );
}
function cl({
  user: t,
  existing: n = !0,
  protectedUser: r,
  onSave: a,
  emailEditable: i = !0,
  onClose: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = et(t), p = Le();
  return /* @__PURE__ */ o(
    ee,
    {
      title: t.name || "添加用户",
      actions: l && /* @__PURE__ */ e(
        be,
        {
          confirm: u ? "放弃尚未保存的更改？" : void 0,
          disabled: p.busy,
          onAction: l,
          children: "关闭用户"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: p.busy, children: [
          /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "账号",
                value: s.sub,
                disabled: n,
                onChange: (h) => c({ ...s, sub: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "显示名称",
                value: s.name,
                onChange: (h) => c({ ...s, name: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "邮箱",
                disabled: !i,
                hint: i ? void 0 : "邮箱由账号中心同步。",
                value: s.email || "",
                onChange: (h) => c({ ...s, email: h })
              }
            )
          ] }),
          /* @__PURE__ */ e(
            ze,
            {
              label: "停用此用户",
              checked: !!s.disabled,
              disabled: r,
              description: r ? "此账号受到保护。" : "保存后生效。",
              onChange: (h) => c({ ...s, disabled: h })
            }
          ),
          /* @__PURE__ */ e(
            it,
            {
              busy: p.busy,
              dirty: u,
              label: "保存资料",
              onClick: () => {
                if (!/^[\w-]{1,128}$/.test(s.sub) || !s.name.trim()) {
                  p.setError("请填写有效的账号和显示名称。");
                  return;
                }
                p.run(async () => {
                  await a(s), d(s);
                }, "用户资料已保存。");
              }
            }
          )
        ] }),
        /* @__PURE__ */ e(Se, { ...p })
      ]
    }
  );
}
function dl({
  usedBytes: t,
  capacityBytes: n,
  onSave: r
}) {
  const {
    draft: a,
    setDraft: i,
    dirty: l,
    accept: s
  } = et(
    String(Math.round(n / 1073741824 * 100) / 100)
  ), c = Le();
  return /* @__PURE__ */ o(
    ee,
    {
      title: "存储额度",
      description: `已使用 ${(t / 1024 ** 3).toFixed(2)} GB`,
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "总存储额度（GB）",
            numeric: !0,
            value: a,
            onChange: i,
            hint: "调整额度会保留已上传的资料。"
          }
        ),
        /* @__PURE__ */ e(
          it,
          {
            busy: c.busy,
            dirty: l,
            onClick: () => {
              const u = Number(a);
              if (!Number.isFinite(u) || u < 1 || u > 102400) {
                c.setError("请输入 1 至 102400 GB 的有效额度。");
                return;
              }
              c.run(async () => {
                await r(u, n), s(a);
              }, "存储额度已保存。");
            }
          }
        ),
        /* @__PURE__ */ e(Se, { ...c })
      ]
    }
  );
}
function ul({
  name: t,
  enabled: n,
  protectedUser: r,
  onSave: a
}) {
  const {
    draft: i,
    setDraft: l,
    dirty: s,
    accept: c
  } = et(n);
  return /* @__PURE__ */ o(
    ee,
    {
      title: "平台管理权限",
      description: "平台管理员可以管理课程、用户和计费配置。",
      children: [
        /* @__PURE__ */ e(
          ze,
          {
            label: "允许进入管理中心",
            checked: i,
            disabled: r,
            description: r ? "当前账号或平台负责人的权限受到保护。" : void 0,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            disabled: r || !s,
            confirm: `确认${i ? "授予" : "收回"} ${t} 的平台管理权限？`,
            onAction: async () => {
              await a(i), c(i);
            },
            children: "保存权限"
          }
        )
      ]
    }
  );
}
function xu({
  items: t,
  value: n,
  onChange: r,
  label: a = "产品导航",
  variant: i = "tabs",
  compact: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-product-navigation", "data-variant": i, "data-compact": l || void 0, "aria-label": a, children: t.map((s) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-label": l ? s.label : void 0,
      "data-fp-tooltip": s.label,
      "data-fp-tooltip-side": i === "rail" ? "right" : "bottom",
      "aria-current": s.id === n ? "page" : void 0,
      disabled: s.disabled,
      onClick: () => r(s.id),
      children: [
        s.icon,
        /* @__PURE__ */ e("span", { children: s.label }),
        s.detail && /* @__PURE__ */ e("small", { children: s.detail })
      ]
    },
    s.id
  )) });
}
function qh({
  items: t,
  onOpen: n,
  actions: r,
  loading: a,
  error: i,
  onCreate: l
}) {
  const [s, c] = k(""), u = t.filter(
    (d) => `${d.title} ${d.subtitle || ""} ${d.group || ""}`.toLowerCase().includes(s.toLowerCase())
  );
  return /* @__PURE__ */ o("section", { className: "fp-bookshelf", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的笔记本" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "新建笔记本" })
    ] }),
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(Je, { size: 16 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索笔记本",
          value: s,
          placeholder: "搜索笔记本",
          onChange: (d) => c(d.target.value)
        }
      )
    ] }),
    i && /* @__PURE__ */ e("p", { role: "alert", children: i }),
    a ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ e("div", { className: "fp-bookshelf-grid", children: u.map((d) => /* @__PURE__ */ e(
      gt,
      {
        disabled: !r,
        items: () => r?.(d) || [],
        label: `${d.title}的操作`,
        children: /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-book",
            onClick: () => n(d.id),
            children: [
              d.coverUrl ? /* @__PURE__ */ e("img", { src: d.coverUrl, alt: "" }) : /* @__PURE__ */ e("span", { className: "fp-book-cover", children: /* @__PURE__ */ e(ht, { size: 25 }) }),
              /* @__PURE__ */ e("strong", { children: d.title }),
              d.subtitle && /* @__PURE__ */ e("small", { children: d.subtitle }),
              d.detail && /* @__PURE__ */ e("small", { children: d.detail }),
              d.progress !== void 0 && /* @__PURE__ */ e(
                "progress",
                {
                  "aria-label": `${d.title}的学习进度`,
                  value: Math.min(100, Math.max(0, d.progress)),
                  max: 100
                }
              )
            ]
          }
        )
      },
      d.id
    )) }),
    !u.length && !a && /* @__PURE__ */ e("p", { children: s ? "没有找到匹配的笔记本。" : "创建一本笔记本，开始整理学习内容。" })
  ] });
}
function Kh({
  title: t,
  onBack: n,
  actions: r
}) {
  return /* @__PURE__ */ o("header", { className: "fp-mobile-topbar", children: [
    n && /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回", onClick: n, children: "‹" }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: r })
  ] });
}
function Uh({
  title: t,
  navigation: n,
  activeId: r,
  onNavigate: a,
  profile: i,
  children: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-account-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: t }),
      i,
      /* @__PURE__ */ e(
        xu,
        {
          items: n,
          value: r,
          onChange: a,
          label: "账户功能"
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-account-content", children: l })
  ] });
}
function Hh({
  onLogin: t,
  heading: n = "登录课栈",
  description: r = "继续整理笔记，与同学一起学习。",
  alternate: a
}) {
  const [i, l] = k(""), [s, c] = k(""), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(!1), b = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel fp-login-form", children: [
    /* @__PURE__ */ e("h2", { children: n }),
    /* @__PURE__ */ e("p", { children: r }),
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: async (y) => {
          if (y.preventDefault(), !(b.current || !i.trim() || !s)) {
            b.current = !0, d(!0), h("");
            try {
              await t(i.trim(), s);
            } catch (w) {
              h(
                w instanceof Error ? w.message : "登录未能完成，请检查账号和密码。"
              );
            } finally {
              b.current = !1, d(!1);
            }
          }
        },
        children: [
          /* @__PURE__ */ o("label", { children: [
            "账号",
            /* @__PURE__ */ e(
              "input",
              {
                "aria-label": "账号",
                autoComplete: "username",
                required: !0,
                value: i,
                disabled: u,
                onChange: (y) => l(y.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ o("label", { children: [
            "密码",
            /* @__PURE__ */ o("div", { className: "fp-password-entry", children: [
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "密码",
                  autoComplete: "current-password",
                  required: !0,
                  type: f ? "text" : "password",
                  value: s,
                  disabled: u,
                  onChange: (y) => c(y.target.value)
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  "aria-label": f ? "隐藏密码" : "显示密码",
                  onClick: () => m((y) => !y),
                  children: f ? "隐藏" : "显示"
                }
              )
            ] })
          ] }),
          p && /* @__PURE__ */ e("p", { role: "alert", children: p }),
          /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e("button", { type: "submit", disabled: u || !i.trim() || !s, children: u ? "正在登录…" : "登录" }) })
        ]
      }
    ),
    a
  ] });
}
function _h({
  name: t,
  avatarUrl: n,
  description: r,
  details: a,
  actions: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { className: "fp-profile-heading", children: [
        n ? /* @__PURE__ */ e("img", { src: n, alt: "" }) : /* @__PURE__ */ e("span", { "aria-hidden": "true", children: t.slice(0, 1) }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: t }),
          r && /* @__PURE__ */ e("small", { children: r })
        ] })
      ] }),
      i
    ] }),
    /* @__PURE__ */ e("dl", { className: "fp-detail-list", children: a.map((l, s) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, s)) })
  ] });
}
function Cu({
  name: t,
  balance: n,
  onSubmit: r
}) {
  const [a, i] = k(""), [l, s] = k(""), c = Number(a);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("h3", { children: [
      "调整",
      t,
      "的积分"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "当前可用 ",
      n.toLocaleString(),
      " 积分"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-settings-fields", children: [
      /* @__PURE__ */ o("label", { children: [
        "调整数量",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整数量",
            inputMode: "numeric",
            value: a,
            onChange: (u) => i(u.target.value)
          }
        ),
        /* @__PURE__ */ e("small", { children: "正数增加，负数扣减。" })
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "调整原因",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整原因",
            value: l,
            onChange: (u) => s(u.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !a.trim() || !Number.isSafeInteger(c) || c === 0 || !l.trim() || n + c < 0,
        confirm: `将${c >= 0 ? "增加" : "扣减"} ${Math.abs(c) || 0} 积分，确认继续？`,
        onAction: () => r(c, l.trim()),
        children: "确认调整"
      }
    ) })
  ] });
}
function Su({
  item: t,
  onRespond: n
}) {
  const [r, a] = k(!1), i = B(!1), l = async (s) => {
    if (!i.current) {
      i.current = !0, a(!0);
      try {
        await n(t.id, s);
      } finally {
        i.current = !1, a(!1);
      }
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
    /* @__PURE__ */ e(be, { disabled: r, onAction: () => l(!0), children: "接受" }),
    /* @__PURE__ */ e(be, { disabled: r, onAction: () => l(!1), children: "婉拒" })
  ] });
}
function Wh({
  items: t,
  onRespond: n,
  loading: r,
  error: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "协作邀请" }),
    a && /* @__PURE__ */ e("p", { role: "alert", children: a }),
    /* @__PURE__ */ e(fe, { children: r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取邀请…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((i) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: i.name }),
        /* @__PURE__ */ o("small", { children: [
          i.from,
          " 邀请你",
          i.role,
          i.date && ` · ${i.date}`
        ] })
      ] }),
      /* @__PURE__ */ e(Su, { item: i, onRespond: n })
    ] }, i.id)) }) : /* @__PURE__ */ e("p", { children: "暂时没有待处理的邀请。" }) })
  ] });
}
function Vh({
  items: t,
  value: n,
  onChange: r,
  label: a = "选择目录",
  onConfirm: i
}) {
  const l = (s) => {
    const c = [s.name], u = /* @__PURE__ */ new Set([s.id]);
    let d = s;
    for (; d.parentId; ) {
      const p = t.find((h) => h.id === d.parentId);
      if (!p || u.has(p.id)) break;
      c.unshift(p.name), u.add(p.id), d = p;
    }
    return c.join(" / ");
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: a }),
    /* @__PURE__ */ e(
      we,
      {
        label: a,
        value: n,
        onChange: r,
        searchable: !0,
        options: t.map((s) => ({
          value: s.id,
          label: s.name,
          description: l(s),
          disabled: s.disabled
        }))
      }
    ),
    i && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !t.some((s) => s.id === n && !s.disabled),
        onAction: i,
        children: "选择此目录"
      }
    ) })
  ] });
}
function Xh({
  plans: t,
  onSelect: n
}) {
  return /* @__PURE__ */ e("section", { className: "fp-plan-picker", "aria-label": "选择方案", children: t.map((r) => /* @__PURE__ */ o(
    "article",
    {
      className: "fp-pattern-panel",
      "data-current": r.current || void 0,
      children: [
        /* @__PURE__ */ e("h3", { children: r.name }),
        /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: r.price }),
        /* @__PURE__ */ e("p", { children: r.description }),
        /* @__PURE__ */ e("ul", { children: r.features.map((a) => /* @__PURE__ */ e("li", { children: a }, a)) }),
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: r.current || r.disabled,
            onClick: () => n(r.id),
            children: r.current ? "当前方案" : "查看方案"
          }
        ) })
      ]
    },
    r.id
  )) });
}
function Yh(t) {
  return /* @__PURE__ */ e(Mu, { ...t }, t.user.sub || "new");
}
function Mu({
  user: t,
  groups: n,
  existing: r = !0,
  protectedUser: a,
  storage: i,
  credits: l,
  administrator: s,
  loading: c,
  error: u,
  onSaveProfile: d,
  onSaveCapacity: p,
  onAdjustCredits: h,
  onSaveAdministrator: f,
  onRetry: m,
  canManageAdministrator: b = !0,
  emailEditable: y = !0,
  usage: w,
  notebooks: v
}) {
  const [g, x] = k("profile");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: g === "profile" ? void 0 : t.name || "添加用户", children: [
    /* @__PURE__ */ e(
      _e,
      {
        label: "用户详情",
        value: g,
        onChange: x,
        items: [
          { id: "profile", label: "资料" },
          ...r ? [
            ...w ? [{ id: "usage", label: "使用统计" }] : [],
            ...v ? [{ id: "notebooks", label: "笔记本" }] : [],
            { id: "storage", label: "存储" },
            { id: "credits", label: "积分" },
            { id: "access", label: "平台权限" }
          ] : []
        ]
      }
    ),
    /* @__PURE__ */ e(Se, { error: u }),
    u && m && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: m,
        children: "重试"
      }
    ),
    /* @__PURE__ */ o(fe, { children: [
      /* @__PURE__ */ e("div", { hidden: g !== "usage", children: w }),
      /* @__PURE__ */ e("div", { hidden: g !== "notebooks", children: v }),
      /* @__PURE__ */ o("div", { hidden: g !== "profile", children: [
        /* @__PURE__ */ e(
          cl,
          {
            user: t,
            emailEditable: y,
            existing: r,
            protectedUser: a,
            onSave: d
          }
        ),
        /* @__PURE__ */ e(ee, { title: "所在用户组", children: /* @__PURE__ */ e("p", { children: n.filter((N) => N.members.includes(t.sub)).map((N) => N.name).join("、") || "尚未加入用户组" }) })
      ] }),
      /* @__PURE__ */ e("div", { hidden: g !== "storage", children: i && p ? /* @__PURE__ */ e(
        dl,
        {
          usedBytes: i.used,
          capacityBytes: i.capacity,
          onSave: p
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取存储信息…" : "存储信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: g !== "credits", children: l !== void 0 && h ? /* @__PURE__ */ e(
        Cu,
        {
          name: t.name,
          balance: l,
          onSubmit: h
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取积分…" : "积分信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: g !== "access", children: b ? s !== void 0 && f ? /* @__PURE__ */ e(
        ul,
        {
          name: t.name,
          enabled: s,
          protectedUser: a,
          onSave: f
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取管理权限…" : "管理权限暂不可用。" }) : /* @__PURE__ */ o(ee, { title: "平台管理权限", children: [
        /* @__PURE__ */ e("p", { children: s ? "平台管理员" : "普通用户" }),
        /* @__PURE__ */ e("p", { children: "仅超级管理员可以调整平台管理权限。" })
      ] }) })
    ] })
  ] }) });
}
function Gh({
  value: t,
  onSave: n,
  onConfigureStorage: r
}) {
  const { draft: a, setDraft: i, dirty: l, accept: s } = et(t), c = Le(), u = a.documentProcessing.quark, d = (h, f) => i({
    ...a,
    providers: a.providers.map(
      (m, b) => b === h ? { ...m, ...f } : m
    )
  }), p = (h) => i({
    ...a,
    documentProcessing: {
      ...a.documentProcessing,
      quark: { ...u, ...h }
    }
  });
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "站点与学习服务",
      description: "管理站点信息、模型连接和资料识别。",
      actions: /* @__PURE__ */ e(
        it,
        {
          busy: c.busy,
          dirty: l,
          onClick: () => {
            if (!a.siteName.trim() || !a.accountName.trim() || a.supportUrl && !/^https?:\/\//.test(a.supportUrl) || !Number.isInteger(u.pagesPerRequest) || u.pagesPerRequest < 1 || u.pagesPerRequest > 4 || new Set(a.providers.map((h) => h.id)).size !== a.providers.length || a.providers.some(
              (h) => !/^[a-z0-9-]+$/.test(h.id) || !h.name.trim() || h.enabled && !/^https?:\/\//.test(h.baseUrl)
            )) {
              c.setError("请检查站点名称、服务地址和识别页数。");
              return;
            }
            c.run(
              async () => s(await n(a) || a),
              "平台设置已保存。"
            );
          }
        }
      ),
      children: [
        /* @__PURE__ */ e(Se, { ...c }),
        /* @__PURE__ */ o("fieldset", { disabled: c.busy, children: [
          /* @__PURE__ */ o(ee, { title: "站点信息", children: [
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "站点名称",
                  value: a.siteName,
                  onChange: (h) => i({ ...a, siteName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "账号品牌",
                  value: a.accountName,
                  onChange: (h) => i({ ...a, accountName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "帮助中心地址",
                  value: a.supportUrl,
                  onChange: (h) => i({ ...a, supportUrl: h })
                }
              )
            ] }),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: r,
                children: "配置资料存储"
              }
            )
          ] }),
          /* @__PURE__ */ e(
            ee,
            {
              title: "模型供应商",
              description: "保存密钥后，仅显示配置状态。",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => i({
                    ...a,
                    providers: [
                      ...a.providers,
                      {
                        id: `service-${crypto.randomUUID().slice(0, 8)}`,
                        name: "模型服务",
                        baseUrl: "",
                        apiKey: "",
                        enabled: !1,
                        models: []
                      }
                    ]
                  }),
                  children: "添加供应商"
                }
              ),
              children: a.providers.map((h, f) => /* @__PURE__ */ o(ee, { title: h.name || "模型服务", children: [
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "连接标识",
                      value: h.id,
                      onChange: (m) => d(f, { id: m }),
                      hint: "使用小写字母、数字和连字符。"
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务名称",
                      value: h.name,
                      onChange: (m) => d(f, { name: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务地址",
                      value: h.baseUrl,
                      onChange: (m) => d(f, { baseUrl: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务密钥",
                      secret: !0,
                      value: h.apiKey,
                      hint: h.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (m) => d(f, { apiKey: m })
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "可用模型",
                    multiline: !0,
                    value: h.models.join(`
`),
                    hint: "每行填写一个模型名称。",
                    onChange: (m) => d(f, {
                      models: m.split(`
`).map((b) => b.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  ze,
                  {
                    label: `启用 ${h.name}`,
                    checked: h.enabled,
                    onChange: (m) => d(f, { enabled: m })
                  }
                ),
                /* @__PURE__ */ e(
                  be,
                  {
                    confirm: "移除此供应商？保存后生效。",
                    onAction: () => i({
                      ...a,
                      providers: a.providers.filter((m, b) => b !== f)
                    }),
                    children: "移除供应商"
                  }
                )
              ] }, f))
            }
          ),
          /* @__PURE__ */ o(
            ee,
            {
              title: "扫描识别",
              description: "将扫描资料中的文字、表格与公式转为可阅读内容。",
              children: [
                /* @__PURE__ */ e(
                  ze,
                  {
                    label: "启用扫描识别",
                    checked: u.enabled,
                    onChange: (h) => p({ enabled: h })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "识别服务密钥",
                      secret: !0,
                      value: u.apiKey,
                      hint: u.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (h) => p({ apiKey: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "默认识别方式",
                      value: u.scene,
                      options: [
                        { value: "general-ocr", label: "通用识别" },
                        { value: "formula-recognition", label: "公式识别" },
                        { value: "table-recognition", label: "表格识别" }
                      ],
                      onChange: (h) => p({ scene: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "每批处理页数",
                      numeric: !0,
                      value: u.pagesPerRequest,
                      onChange: (h) => p({ pagesPerRequest: Number(h) })
                    }
                  )
                ] })
              ]
            }
          )
        ] })
      ]
    }
  ) });
}
function Jh({
  users: t,
  enabledIds: n,
  protectedIds: r,
  onSave: a
}) {
  const [i, l] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "平台管理员", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索管理员账户",
        value: i,
        onChange: l
      }
    ),
    t.filter(
      (s) => `${s.name} ${s.email || ""} ${s.sub}`.toLowerCase().includes(i.toLowerCase())
    ).map((s) => /* @__PURE__ */ e(
      ul,
      {
        name: s.name,
        enabled: n.includes(s.sub),
        protectedUser: r.includes(s.sub),
        onSave: (c) => a(s.sub, c)
      },
      `${s.sub}-${n.includes(s.sub)}`
    ))
  ] }) });
}
function Qh({
  entries: t,
  onSave: n
}) {
  const [r, a] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "用户存储", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索存储账户",
        value: r,
        onChange: a
      }
    ),
    t.filter(
      (i) => i.name.toLowerCase().includes(r.toLowerCase())
    ).map((i) => /* @__PURE__ */ e(ee, { title: i.name, children: /* @__PURE__ */ e(
      dl,
      {
        usedBytes: i.used,
        capacityBytes: i.capacity,
        onSave: (l, s) => n(i.id, l, s)
      }
    ) }, i.id))
  ] }) });
}
function Zh({
  canReset: t,
  confirmation: n = "重置课栈平台",
  onReset: r
}) {
  const [a, i] = k(""), l = Le();
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "重新配置平台",
      description: "重新设置平台服务，已保存的课程、笔记和资料会保留。",
      children: [
        t ? /* @__PURE__ */ o(Z, { children: [
          /* @__PURE__ */ e(
            X,
            {
              label: `输入“${n}”确认`,
              value: a,
              onChange: i,
              disabled: l.busy
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              disabled: l.busy || a !== n,
              onClick: () => {
                l.run(r, "平台配置已重置。");
              },
              children: l.busy ? "正在重新配置…" : "重置并重新配置"
            }
          )
        ] }) : /* @__PURE__ */ e("p", { children: "请联系平台负责人进行此项操作。" }),
        /* @__PURE__ */ e(Se, { ...l })
      ]
    }
  ) });
}
function ef({
  questions: t,
  onSelect: n,
  sourceCount: r = 0,
  onOpenSources: a,
  title: i = "你可能还想问"
}) {
  return /* @__PURE__ */ e(fe, { children: (t.length > 0 || r > 0) && /* @__PURE__ */ o("section", { className: "fp-followup-questions", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t.length ? i : "参考资料" }),
      r > 0 && a && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          onClick: a,
          children: [
            "来源 · ",
            r
          ]
        }
      )
    ] }),
    t.map((l, s) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-followup-question",
        onClick: () => n(l),
        children: /* @__PURE__ */ e(
          ni,
          {
            remarkPlugins: [ri],
            rehypePlugins: [ai],
            components: {
              a: ({ children: c }) => /* @__PURE__ */ e("span", { children: c }),
              img: ({ alt: c }) => /* @__PURE__ */ e("span", { children: c })
            },
            children: l
          }
        )
      },
      s
    ))
  ] }) });
}
function pl({ label: t = "正在打开内容", variant: n = "document" }) {
  return /* @__PURE__ */ o("div", { className: `fp-content-skeleton fp-content-skeleton-${n}`, role: "status", "aria-label": t, "aria-busy": "true", children: [
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-title" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" }),
    /* @__PURE__ */ e("div", { className: "fp-content-skeleton-block" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" })
  ] });
}
function tf({
  title: t,
  markdown: n,
  entries: r = [],
  selectedId: a,
  onNavigate: i,
  headings: l = [],
  loading: s,
  error: c,
  onRetry: u,
  access: d = "granted",
  onSignIn: p,
  toolbar: h,
  footer: f,
  onCopyReference: m,
  contentProps: b,
  content: y,
  navigation: w,
  brand: v,
  account: g,
  collection: x
}) {
  const [N, C] = k(null), [A, L] = k(""), U = Le(), S = Ne().replace(/:/g, ""), [I, T] = k(""), H = B(null);
  Y(() => {
    if (!N) return;
    const j = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const P = ($) => {
      $.key === "Escape" && C(null);
    };
    return window.addEventListener("keydown", P), () => {
      window.removeEventListener("keydown", P), document.body.style.overflow = j, H.current?.focus({ preventScroll: !0 });
    };
  }, [N]), Y(() => {
    if (!l.length || typeof IntersectionObserver > "u") return;
    const j = document.getElementById(S);
    if (!j) return;
    const P = /* @__PURE__ */ new Map(), $ = new IntersectionObserver(
      (z) => {
        for (const D of z)
          D.isIntersecting ? P.set(D.target.id, D.boundingClientRect.top) : P.delete(D.target.id);
        const E = [...P].sort((D, ne) => D[1] - ne[1])[0];
        E && L(E[0]);
      },
      { rootMargin: "-10% 0px -65% 0px" }
    );
    for (const z of j.querySelectorAll("h2[id],h3[id],h4[id]"))
      $.observe(z);
    return () => $.disconnect();
  }, [S, n, l.length, s, d]), Y(() => {
    C(null), L("");
  }, [a]);
  const O = n.trimStart().match(/^#\s+(.+?)(?:\s+#+)?\s*(?:\r?\n|$)/)?.[1].trim() !== t.trim(), M = w ?? /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ e("h2", { children: "笔记目录" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-input",
        "aria-label": "搜索分享笔记",
        value: I,
        placeholder: "搜索笔记",
        onChange: (j) => T(j.target.value)
      }
    ),
    /* @__PURE__ */ e("nav", { "aria-label": "分享笔记", children: r.filter(
      (j) => `${j.title} ${j.group || ""}`.toLowerCase().includes(I.toLowerCase())
    ).map((j, P, $) => /* @__PURE__ */ o("div", { children: [
      j.group && (P === 0 || $[P - 1].group !== j.group) && /* @__PURE__ */ e("h3", { children: j.group }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-note",
          "aria-current": a === j.id ? "page" : void 0,
          onClick: () => {
            i?.(j.id), C(null);
          },
          children: j.title
        }
      )
    ] }, j.id)) })
  ] }), K = /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ e("h2", { children: "本页目录" }),
    /* @__PURE__ */ e("nav", { "aria-label": "本页目录", children: l.map((j) => /* @__PURE__ */ e(
      "a",
      {
        href: `#${j.id}`,
        "aria-current": A === j.id ? "location" : void 0,
        style: {
          paddingInlineStart: Math.max(0, j.level - 1) * 12 + 12
        },
        onClick: (P) => {
          P.preventDefault(), document.getElementById(S)?.querySelector(`[id="${CSS.escape(j.id)}"]`)?.scrollIntoView({
            behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
            block: "start"
          }), L(j.id), C(null);
        },
        children: j.title
      },
      j.id
    )) })
  ] });
  return /* @__PURE__ */ o("div", { className: "fp-shared-reading", children: [
    /* @__PURE__ */ o("header", { className: "fp-shared-header", children: [
      v ?? /* @__PURE__ */ e("a", { href: "https://fiveplus.one/", "aria-label": "五加一主页", children: /* @__PURE__ */ e(
        "img",
        {
          src: "https://go.r-l.ink/ico",
          alt: "五加一",
          width: 28,
          height: 28
        }
      ) }),
      /* @__PURE__ */ e("strong", { children: x?.title || t }),
      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
        h,
        g,
        p && d !== "granted" && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-shared-mobile-bar", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (j) => {
            H.current = j.currentTarget, C("notes");
          },
          children: [
            /* @__PURE__ */ e(Er, { size: 16 }),
            "笔记"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (j) => {
            H.current = j.currentTarget, C("contents");
          },
          children: [
            /* @__PURE__ */ e(yn, { size: 16 }),
            "目录"
          ]
        }
      )
    ] }),
    N && /* @__PURE__ */ e(
      "div",
      {
        className: "fp-shared-drawer-backdrop",
        onClick: () => C(null),
        children: /* @__PURE__ */ o(
          "aside",
          {
            className: "fp-shared-drawer",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": N === "notes" ? "笔记目录" : "本页目录",
            onClick: (j) => j.stopPropagation(),
            onKeyDown: (j) => {
              if (j.key !== "Tab") return;
              const P = [
                ...j.currentTarget.querySelectorAll(
                  "button,a,input"
                )
              ], $ = P[0], z = P.at(-1);
              j.shiftKey && document.activeElement === $ ? (j.preventDefault(), z?.focus()) : !j.shiftKey && document.activeElement === z && (j.preventDefault(), $?.focus());
            },
            children: [
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  autoFocus: !0,
                  className: "fp-shared-close",
                  "aria-label": "关闭目录",
                  onClick: () => C(null),
                  children: /* @__PURE__ */ e(ge, { size: 18 })
                }
              ),
              N === "notes" ? M : K
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ o("div", { className: "fp-shared-layout", children: [
      /* @__PURE__ */ e("aside", { className: "fp-shared-navigation", children: M }),
      /* @__PURE__ */ e("main", { id: S, children: /* @__PURE__ */ e(fe, { children: s ? /* @__PURE__ */ e(pl, { label: "正在打开笔记" }) : c ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: c }),
        u && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            onClick: u,
            children: "重试"
          }
        )
      ] }) : d !== "granted" ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", children: [
        /* @__PURE__ */ e("h1", { children: d === "sign-in" ? "登录后阅读" : "这篇笔记尚未向你分享" }),
        /* @__PURE__ */ e("p", { children: d === "sign-in" ? "登录账户，继续查看分享内容。" : "请联系分享者获取访问权限。" }),
        d === "sign-in" && p && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录并继续"
          }
        )
      ] }) : /* @__PURE__ */ o(Z, { children: [
        x && /* @__PURE__ */ o("section", { className: "fp-shared-collection", "aria-label": "分享笔记本", children: [
          /* @__PURE__ */ o("div", { className: "fp-shared-collection-title", children: [
            /* @__PURE__ */ e(ht, { size: 23, "aria-hidden": "true" }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("strong", { children: x.title }),
              x.byline && /* @__PURE__ */ e("span", { children: x.byline })
            ] })
          ] }),
          x.description && /* @__PURE__ */ e("p", { children: x.description }),
          x.actions && /* @__PURE__ */ e("div", { className: "fp-shared-collection-actions", children: x.actions })
        ] }),
        O && /* @__PURE__ */ e("h1", { children: t }),
        m && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: U.busy,
            onClick: () => {
              U.run(
                () => m({
                  title: t,
                  text: (() => {
                    const j = window.getSelection();
                    return j?.anchorNode && document.getElementById(S)?.contains(j.anchorNode) && j.toString() || t;
                  })(),
                  heading: A || void 0
                }),
                "引用已复制"
              );
            },
            children: [
              /* @__PURE__ */ e(jn, { size: 15 }),
              "复制引用"
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...U }),
        y ?? /* @__PURE__ */ e(bt, { ...b, markdown: n }),
        f
      ] }) }) }),
      /* @__PURE__ */ e("aside", { className: "fp-shared-contents", children: K })
    ] })
  ] });
}
function nf({
  available: t,
  onRefresh: n,
  onDismiss: r,
  beforeRefresh: a
}) {
  const i = Le();
  return /* @__PURE__ */ e(fe, { children: t && /* @__PURE__ */ o("aside", { className: "fp-release-notice", "aria-label": "应用更新", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: "新版本已就绪" }),
      /* @__PURE__ */ e("p", { children: "更新后继续使用最新功能。" }),
      /* @__PURE__ */ e(Se, { ...i })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: i.busy,
          onClick: () => {
            i.run(async () => {
              if (a && !await a()) {
                i.setMessage("请先保存当前内容。");
                return;
              }
              await n();
            });
          },
          children: i.busy ? "正在更新…" : "立即更新"
        }
      ),
      r && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-close",
          "aria-label": "稍后更新",
          onClick: r,
          children: /* @__PURE__ */ e(ge, { size: 17 })
        }
      )
    ] })
  ] }) });
}
function rf({
  currentVersion: t,
  checkVersion: n,
  interval: r = 6e4,
  enabled: a = !0,
  onError: i
}) {
  const [l, s] = k(t), [c, u] = k(""), d = B({ checkVersion: n, onError: i });
  return d.current = { checkVersion: n, onError: i }, Y(() => {
    if (!a) return;
    let p = null, h = !0;
    const f = async () => {
      if (p || document.visibilityState === "hidden") return;
      const y = new AbortController();
      p = y;
      try {
        const w = await d.current.checkVersion(y.signal);
        h && !y.signal.aborted && w && s(w);
      } catch (w) {
        y.signal.aborted || d.current.onError?.(w);
      } finally {
        p === y && (p = null);
      }
    }, m = () => {
      f();
    }, b = setInterval(m, Math.max(1e3, r));
    return window.addEventListener("focus", m), document.addEventListener("visibilitychange", m), m(), () => {
      h = !1, p?.abort(), clearInterval(b), window.removeEventListener("focus", m), document.removeEventListener("visibilitychange", m);
    };
  }, [t, r, a]), {
    available: l !== t && l !== c,
    version: l,
    dismiss: () => u(l)
  };
}
function af({
  value: t,
  onChange: n,
  onRevise: r,
  renderMolecule: a,
  recorder: i,
  onDiagnostic: l
}) {
  const [s, c] = k(null), [u, d] = k("current"), p = Le(), h = B(null), f = B(t);
  return f.current = t, Y(() => () => h.current?.abort(), []), Y(() => {
    c(null), d("current"), h.current?.abort();
  }, [t]), /* @__PURE__ */ e(Ii.Provider, { value: a || null, children: /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-canvas-workspace", children: /* @__PURE__ */ o(
    ee,
    {
      title: t.title || "学习画布",
      description: "探索图形，提出修改，再确认需要保留的版本。",
      children: [
        /* @__PURE__ */ e(
          _e,
          {
            label: "画布版本",
            value: u,
            onChange: d,
            items: [
              { id: "current", label: "当前版本" },
              ...s ? [{ id: "candidate", label: "修改预览" }] : [],
              ...i ? [{ id: "recording", label: "操作回放" }] : []
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...p }),
        /* @__PURE__ */ e(fe, { children: u === "recording" ? i : /* @__PURE__ */ e(
          br,
          {
            block: u === "candidate" && s ? s : t,
            onRevisionSubmit: r ? async (m) => {
              h.current?.abort();
              const b = new AbortController();
              h.current = b;
              let y;
              const w = t;
              if (!await p.run(async () => {
                try {
                  const g = await r(
                    w,
                    m,
                    b.signal
                  );
                  if (b.signal.aborted || f.current !== w)
                    return;
                  c(g), d("candidate");
                } catch (g) {
                  throw y = g, g;
                }
              }))
                throw l?.(y), new Error("画布修改未完成，请保留输入后重试。");
            } : void 0
          }
        ) }),
        s && /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-primary",
              onClick: () => {
                n(s), c(null), d("current");
              },
              children: "采用此版本"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              onClick: () => {
                c(null), d("current");
              },
              children: "保留当前版本"
            }
          )
        ] })
      ]
    }
  ) }) });
}
const hn = (t) => Number.isFinite(t) && t >= 0;
function Eu(t) {
  if (!(t.creditsPerYuan > 0 && t.creditsPerYuan <= 1e4) || !((t.costMultiplier ?? 1) > 0 && (t.costMultiplier ?? 1) <= 100))
    return "请填写有效的积分比例和成本倍率。";
  if (Object.values(t.serviceRates).some((n) => !hn(n) || n > 1e4))
    return "请填写有效的资料处理价格。";
  if (Object.entries(t.modelRates || {}).some(
    ([n, r]) => !n.trim() || Object.values(r).some((a) => !hn(a) || a > 1e5)
  ))
    return "请检查模型名称和价格。";
  if (new Set(t.plans.map((n) => n.id)).size !== t.plans.length || t.plans.length > 30 || t.plans.some(
    (n) => !n.name.trim() || !Number.isInteger(n.days) || n.days < 1 || n.days > 3660 || !hn(n.priceYuan) || n.priceYuan <= 0 || n.priceYuan > 1e4 || !hn(n.credits) || n.credits > 1e6 || !(n.discount >= 0 && n.discount <= 1)
  ))
    return "请检查会员名称、天数、价格及折扣。";
  if (t.enabled && (!/^https?:\/\//.test(t.gateway) || !t.pid.trim()))
    return "启用支付前，请填写支付网关和商户号。";
}
function lf({
  value: t,
  onSave: n,
  onSyncPrices: r,
  readOnly: a
}) {
  const { draft: i, setDraft: l, dirty: s, accept: c } = et(t), u = Le(), [d, p] = k("credits"), [h, f] = k(""), [m, b] = k(""), y = (g, x) => l({ ...i, [g]: x }), w = (g = []) => {
    if (r) {
      if (s) {
        u.setError("请先保存当前更改，再同步价格。");
        return;
      }
      u.run(
        async () => c(await r(g)),
        "模型价格已同步。"
      );
    }
  }, v = () => {
    const g = Eu(i);
    if (g) {
      u.setError(g);
      return;
    }
    u.run(
      async () => c(await n(i) || i),
      "积分与会员设置已保存。"
    );
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "积分与会员设置", children: /* @__PURE__ */ o(
    ee,
    {
      title: "积分与会员",
      description: "管理充值、会员权益和服务价格。",
      actions: /* @__PURE__ */ e(
        it,
        {
          busy: u.busy,
          dirty: s && !a,
          onClick: v
        }
      ),
      children: [
        /* @__PURE__ */ e(
          _e,
          {
            label: "计费设置",
            value: d,
            onChange: p,
            items: [
              { id: "credits", label: "充值与积分" },
              { id: "plans", label: "会员计划" },
              { id: "payment", label: "支付接入" },
              { id: "models", label: "模型价格" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...u }),
        /* @__PURE__ */ e("fieldset", { disabled: u.busy || a, children: /* @__PURE__ */ o(fe, { children: [
          d === "credits" && /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e(ee, { title: "积分规则", children: /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "每元兑换积分",
                  numeric: !0,
                  value: i.creditsPerYuan,
                  onChange: (g) => y("creditsPerYuan", Number(g))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "成本倍率",
                  numeric: !0,
                  value: i.costMultiplier ?? 1,
                  onChange: (g) => y("costMultiplier", Number(g))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "单次回复积分",
                  numeric: !0,
                  value: i.replyCredits ?? 0,
                  onChange: (g) => y("replyCredits", Number(g))
                }
              )
            ] }) }),
            /* @__PURE__ */ e(
              ee,
              {
                title: "资料处理价格",
                description: "按实际处理次数计费。",
                children: /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                  ["quarkOcrRequest", "扫描识别（每次）"],
                  ["documentOrganization", "资料整理（每次）"],
                  ["webSearch", "联网搜索（每次）"]
                ].map(([g, x]) => /* @__PURE__ */ e(
                  X,
                  {
                    label: x,
                    numeric: !0,
                    value: i.serviceRates[g],
                    onChange: (N) => y("serviceRates", {
                      ...i.serviceRates,
                      [g]: Number(N)
                    })
                  },
                  g
                )) })
              }
            )
          ] }),
          d === "plans" && /* @__PURE__ */ o(
            ee,
            {
              title: "会员计划",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  disabled: i.plans.length >= 30,
                  onClick: () => y("plans", [
                    ...i.plans,
                    {
                      id: crypto.randomUUID(),
                      name: "学习会员",
                      days: 30,
                      priceYuan: 10,
                      credits: 100,
                      discount: 0.9,
                      enabled: !1
                    }
                  ]),
                  children: "添加会员计划"
                }
              ),
              children: [
                i.plans.map((g, x) => /* @__PURE__ */ o(
                  ee,
                  {
                    title: g.name || "新会员计划",
                    children: [
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["name", "计划名称"],
                        ["days", "有效天数"],
                        ["priceYuan", "价格（元）"],
                        ["credits", "附赠积分"],
                        ["discount", "对话价格系数"]
                      ].map(([N, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: C,
                          numeric: N !== "name",
                          value: g[N],
                          onChange: (A) => y(
                            "plans",
                            i.plans.map(
                              (L, U) => U === x ? {
                                ...L,
                                [N]: N === "name" ? A : Number(A)
                              } : L
                            )
                          )
                        },
                        N
                      )) }),
                      /* @__PURE__ */ e(
                        ze,
                        {
                          label: `上架 ${g.name}`,
                          checked: g.enabled,
                          onChange: (N) => y(
                            "plans",
                            i.plans.map(
                              (C, A) => A === x ? { ...C, enabled: N } : C
                            )
                          )
                        }
                      ),
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-ghost",
                          onClick: () => y(
                            "plans",
                            i.plans.filter((N) => N.id !== g.id)
                          ),
                          children: "移除计划"
                        }
                      )
                    ]
                  },
                  g.id
                )),
                !i.plans.length && /* @__PURE__ */ e("p", { children: "添加会员计划，设置学习权益。" })
              ]
            }
          ),
          d === "payment" && /* @__PURE__ */ o(ee, { title: "支付接入", children: [
            /* @__PURE__ */ e(
              ze,
              {
                label: "启用充值",
                checked: i.enabled,
                onChange: (g) => y("enabled", g)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "支付网关",
                value: i.gateway,
                onChange: (g) => y("gateway", g)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户号",
                  value: i.pid,
                  onChange: (g) => y("pid", g)
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户密钥",
                  secret: !0,
                  value: i.secret,
                  hint: "留空时保留已保存的密钥。",
                  onChange: (g) => y("secret", g)
                }
              )
            ] })
          ] }),
          d === "models" && /* @__PURE__ */ o(
            ee,
            {
              title: "模型价格",
              description: "价格单位：元 / 百万 Token。",
              actions: r && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => w(),
                  children: "同步上游价格"
                }
              ),
              children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "搜索模型价格",
                    value: h,
                    onChange: f
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "新模型名称",
                      value: m,
                      onChange: b
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-secondary",
                      disabled: !m.trim(),
                      onClick: () => {
                        const g = m.trim();
                        if (i.modelRates?.[g]) {
                          u.setError("模型名称已存在。");
                          return;
                        }
                        y("modelRates", {
                          ...i.modelRates,
                          [g]: { input: 0, cachedInput: 0, output: 0 }
                        }), b("");
                      },
                      children: "添加模型"
                    }
                  )
                ] }),
                Object.entries(i.modelRates || {}).filter(
                  ([g]) => g.toLowerCase().includes(h.toLowerCase())
                ).map(([g, x]) => /* @__PURE__ */ o(
                  ee,
                  {
                    title: g,
                    description: i.rateOverrides?.includes(g) ? "使用手动价格" : "使用上游价格",
                    children: [
                      /* @__PURE__ */ e(
                        $u,
                        {
                          name: g,
                          onRename: (N) => {
                            const C = N.trim();
                            if (!C || C !== g && i.modelRates?.[C])
                              return u.setError("请填写尚未使用的模型名称。"), !1;
                            const A = { ...i.modelRates, [C]: x };
                            return C !== g && delete A[g], l({
                              ...i,
                              modelRates: A,
                              rateOverrides: i.rateOverrides?.map(
                                (L) => L === g ? C : L
                              )
                            }), !0;
                          }
                        }
                      ),
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["input", "输入价格"],
                        ["cachedInput", "缓存命中价格"],
                        ["output", "输出价格"]
                      ].map(([N, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: `${g} · ${C}`,
                          numeric: !0,
                          value: x[N],
                          onChange: (A) => l({
                            ...i,
                            modelRates: {
                              ...i.modelRates,
                              [g]: { ...x, [N]: Number(A) }
                            },
                            rateOverrides: [
                              .../* @__PURE__ */ new Set([
                                ...i.rateOverrides || [],
                                g
                              ])
                            ]
                          })
                        },
                        N
                      )) }),
                      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                        r && /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-secondary",
                            onClick: () => w([g]),
                            children: "恢复上游价格"
                          }
                        ),
                        /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-ghost",
                            onClick: () => {
                              const N = { ...i.modelRates };
                              delete N[g], l({
                                ...i,
                                modelRates: N,
                                rateOverrides: i.rateOverrides?.filter(
                                  (C) => C !== g
                                )
                              });
                            },
                            children: "移除模型"
                          }
                        )
                      ] })
                    ]
                  },
                  g
                ))
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
function $u({
  name: t,
  onRename: n
}) {
  const [r, a] = k(!1), [i, l] = k(t);
  return r ? /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: `${t} · 模型名称`,
        value: i,
        onChange: l
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: () => {
          n(i) && a(!1);
        },
        children: "确认名称"
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-ghost",
        onClick: () => {
          l(t), a(!1);
        },
        children: "取消"
      }
    )
  ] }) : /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-ghost",
      onClick: () => a(!0),
      children: "修改模型名称"
    }
  );
}
function zu(t, n) {
  const r = t.replace(/^\uFEFF/, "").replace(/\r\n/g, `
`), a = r.match(/^---\n([\s\S]*?)\n---(?:\n|$)/), i = Object.fromEntries(
    (a?.[1] || "").split(`
`).flatMap((l) => {
      const s = l.match(/^(name|description):\s*(.*?)\s*$/);
      return s ? [[s[1], s[2].replace(/^(['"])(.*)\1$/, "$2")]] : [];
    })
  );
  return {
    name: i.name || n.replace(/\.(md|markdown)$/i, ""),
    description: i.description || "",
    content: a ? r.slice(a[0].length) : r
  };
}
function of({
  skills: t,
  maxSkills: n = 100,
  maxFileBytes: r = 2e6,
  onSave: a,
  onExport: i
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = et(t), d = Le(), [p, h] = k(""), [f, m] = k(null), b = l.find((v) => v.id === f), y = (v) => s(l.map((g) => g.id === f ? { ...g, ...v } : g)), w = async (v) => {
    await d.run(async () => {
      const g = [];
      if (l.length + v.length > n)
        throw new Error(`最多可保留 ${n} 个技能，请先整理后再导入。`);
      for (const x of v) {
        if (!/\.(md|markdown)$/i.test(x.name))
          throw new Error("请选择 Markdown 技能文件。");
        if (x.size > r)
          throw new Error(`${x.name} 超出文件大小限制。`);
        g.push({
          ...zu(await x.text(), x.name),
          id: crypto.randomUUID(),
          pinned: !1
        });
      }
      s([...l, ...g]), g[0] && m(g[0].id);
    }, "文件已读入，保存后即可使用。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "技能管理", children: /* @__PURE__ */ o(
    ee,
    {
      title: "技能库",
      description: `${l.length} / ${n} 个技能`,
      actions: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ o(
          "label",
          {
            className: "fp-button fp-secondary",
            role: "button",
            tabIndex: 0,
            onKeyDown: (v) => {
              !d.busy && (v.key === "Enter" || v.key === " ") && (v.preventDefault(), v.currentTarget.querySelector("input")?.click());
            },
            children: [
              "导入文件",
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "导入技能文件",
                  hidden: !0,
                  type: "file",
                  accept: ".md,.markdown,text/markdown",
                  multiple: !0,
                  disabled: d.busy,
                  onChange: (v) => {
                    const g = Array.from(v.target.files || []);
                    v.target.value = "", g.length && w(g);
                  }
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: d.busy || l.length >= n,
            onClick: () => {
              const v = {
                id: crypto.randomUUID(),
                name: "新技能",
                description: "",
                content: "",
                pinned: !1
              };
              s([...l, v]), m(v.id);
            },
            children: "新建技能"
          }
        ),
        /* @__PURE__ */ e(
          it,
          {
            busy: d.busy,
            dirty: c,
            onClick: () => {
              if (l.some((v) => !v.name.trim())) {
                d.setError("请填写技能名称。");
                return;
              }
              d.run(async () => {
                await a(l), u(l);
              }, "技能库已保存。");
            }
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(Se, { ...d }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ o("aside", { children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "搜索技能",
                value: p,
                onChange: h
              }
            ),
            /* @__PURE__ */ e("nav", { "aria-label": "技能列表", className: "fp-workspace-item-list", children: l.filter(
              (v) => `${v.name} ${v.description}`.toLowerCase().includes(p.toLowerCase())
            ).map((v) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                "aria-pressed": f === v.id,
                onClick: () => m(v.id),
                children: [
                  /* @__PURE__ */ e("strong", { children: v.name }),
                  /* @__PURE__ */ o("small", { children: [
                    v.pinned ? "始终使用" : "按需使用",
                    " ·",
                    " ",
                    new Blob([v.content]).size.toLocaleString(),
                    " B"
                  ] })
                ]
              },
              v.id
            )) }),
            !l.length && /* @__PURE__ */ e("p", { children: "添加技能，为学习助手补充工作方法。" })
          ] }),
          /* @__PURE__ */ e("div", { children: b ? /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "技能名称",
                value: b.name,
                onChange: (v) => y({ name: v })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能说明",
                value: b.description,
                onChange: (v) => y({ description: v })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能正文",
                multiline: !0,
                value: b.content,
                onChange: (v) => y({ content: v })
              }
            ),
            /* @__PURE__ */ e(
              ze,
              {
                label: "始终使用此技能",
                description: "关闭后，助手会按任务需要使用。",
                checked: b.pinned,
                onChange: (v) => y({ pinned: v })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
              i && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => i(b),
                  children: "导出技能"
                }
              ),
              /* @__PURE__ */ e(
                be,
                {
                  confirm: `删除“${b.name}”？保存后生效。`,
                  onAction: () => {
                    s(l.filter((v) => v.id !== f)), m(null);
                  },
                  children: "删除技能"
                }
              )
            ] })
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个技能，查看和编辑内容。" }) })
        ] })
      ]
    }
  ) });
}
const Iu = () => ({
  id: "",
  label: "",
  modelType: "text",
  contextK: 128,
  cacheTtlSec: 3600,
  inputPrice: 0,
  outputPrice: 0,
  vision: !1,
  tools: !0,
  thinking: !1,
  thinkingRequired: !1,
  thinkingLevels: ["low", "medium", "high", "max"],
  apiProtocol: "openai",
  thinkingRequestStyle: "none",
  imageApiStyle: "auto",
  sizes: ["1024x1024"],
  maxCount: 1
});
function za(t) {
  if (!t || typeof t != "object") return !1;
  const n = t, r = (i) => Array.isArray(i) && i.length <= 1e3 && i.every((l) => typeof l == "string" && l.length <= 2e3), a = (i, l = !1) => l && i === void 0 || typeof i == "number" && Number.isFinite(i) && i >= 0 && i <= 1e5;
  return Array.isArray(n.groups) && n.groups.length <= 100 && new Set(n.groups.map((i) => i?.id)).size === n.groups.length && n.groups.every(
    (i) => i && typeof i == "object" && typeof i.id == "string" && i.id.length <= 128 && typeof i.name == "string" && typeof i.baseUrl == "string" && typeof i.apiKey == "string" && Array.isArray(i.models) && i.models.length <= 1e3 && i.models.every(
      (l) => l && typeof l == "object" && typeof l.id == "string" && typeof l.label == "string" && ["text", "image"].includes(l.modelType) && Number.isFinite(l.contextK) && l.contextK > 0 && l.contextK <= 1e5 && Number.isFinite(l.cacheTtlSec) && l.cacheTtlSec >= 0 && a(l.inputPrice) && a(l.outputPrice) && a(l.cachedInputPrice, !0) && a(l.cacheWritePrice, !0) && ["vision", "tools", "thinking", "thinkingRequired"].every(
        (s) => typeof l[s] == "boolean"
      ) && r(l.thinkingLevels) && r(l.sizes) && typeof l.thinkingRequestStyle == "string" && ["openai", "anthropic", "siliconflow"].includes(l.apiProtocol) && ["auto", "openai", "siliconflow"].includes(l.imageApiStyle) && Number.isInteger(l.maxCount) && l.maxCount > 0 && l.maxCount <= 100
    )
  ) && [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel",
    "thinkingEffort",
    "globalContext"
  ].every((i) => typeof n[i] == "string") && ["defaultThinking", "defaultSearch", "imageEnabled"].every(
    (i) => typeof n[i] == "boolean"
  ) && r(n.disabledTools) && (n.fontSize === void 0 || Number.isFinite(n.fontSize) && n.fontSize >= 10 && n.fontSize <= 32) && (n.fontFamily === void 0 || typeof n.fontFamily == "string");
}
function lr(t, n) {
  const r = { ...t };
  for (const a of [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel"
  ])
    Object.hasOwn(n, r[a]) && (r[a] = n[r[a]]);
  return r;
}
function sf({
  value: t,
  builtInModels: n = [],
  tools: r = [],
  onSave: a,
  onExportChats: i,
  onExportSettings: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = et(t), p = Le(), [h, f] = k("models"), [m, b] = k(s.groups[0]?.id || ""), [y, w] = k(null), v = s.groups.find((S) => S.id === m), g = y === null ? void 0 : v?.models[y], x = (S, I) => c({ ...s, [S]: I }), N = (S) => {
    const I = {};
    if (S.models && v)
      for (const T of v.models)
        S.models.some((H) => H.id === T.id) || (I[`${m}:${T.id}`] = "");
    c(
      lr(
        {
          ...s,
          groups: s.groups.map(
            (T) => T.id === m ? { ...T, ...S } : T
          )
        },
        I
      )
    );
  }, C = (S) => {
    if (!v || !g) return;
    const I = S.id !== void 0 && S.id !== g.id ? {
      [`${m}:${g.id}`]: S.id ? `${m}:${S.id}` : ""
    } : {};
    c(
      lr(
        {
          ...s,
          groups: s.groups.map(
            (T) => T.id === m ? {
              ...T,
              models: T.models.map(
                (H, R) => R === y ? { ...H, ...S } : H
              )
            } : T
          )
        },
        I
      )
    );
  }, A = [
    ...n,
    ...s.groups.flatMap(
      (S) => S.models.filter((I) => I.id).map((I) => ({
        id: `${S.id}:${I.id}`,
        label: `${S.name} · ${I.label || I.id}`
      }))
    )
  ], L = [
    { value: "", label: "跟随主对话" },
    ...A.map((S) => ({ value: S.id, label: S.label }))
  ], U = () => {
    if (!za(s) || s.groups.some(
      (S) => !S.name.trim() || !/^https?:\/\//.test(S.baseUrl) || S.models.some((I) => !I.id.trim()) || new Set(S.models.map((I) => I.id)).size !== S.models.length
    )) {
      p.setError("请检查分组地址、模型名称和数值设置。");
      return;
    }
    p.run(async () => {
      await a(s), d(s);
    }, "助手设置已保存。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "助手完整设置", children: /* @__PURE__ */ o(
    ee,
    {
      title: "学习助手设置",
      description: "管理模型、学习偏好和技能使用方式。",
      actions: /* @__PURE__ */ e(it, { busy: p.busy, dirty: u, onClick: U }),
      children: [
        /* @__PURE__ */ e(
          _e,
          {
            label: "助手设置分区",
            value: h,
            onChange: f,
            items: [
              { id: "models", label: "模型与连接" },
              { id: "defaults", label: "学习偏好" },
              { id: "images", label: "图片创作" },
              { id: "tools", label: "工具" },
              { id: "data", label: "导入与导出" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...p }),
        /* @__PURE__ */ e("fieldset", { disabled: p.busy, children: /* @__PURE__ */ o(fe, { children: [
          h === "models" && /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ o(ee, { title: "对话模型", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "默认对话模型",
                  value: s.defaultModel,
                  options: [
                    { value: "", label: "自动选择" },
                    ...L.slice(1)
                  ],
                  onChange: (S) => x("defaultModel", S)
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "摘录模型",
                    value: s.excerptModel,
                    options: L,
                    onChange: (S) => x("excerptModel", S)
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "划词助手模型",
                    value: s.selectionModel,
                    options: L,
                    onChange: (S) => x("selectionModel", S)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o(
              ee,
              {
                title: "自定义连接",
                actions: /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      const S = {
                        id: crypto.randomUUID(),
                        name: "新连接",
                        baseUrl: "",
                        apiKey: "",
                        models: []
                      };
                      x("groups", [...s.groups, S]), b(S.id), w(null);
                    },
                    children: "添加连接"
                  }
                ),
                children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "当前连接",
                      value: m,
                      options: s.groups.map((S) => ({
                        value: S.id,
                        label: S.name
                      })),
                      onChange: (S) => {
                        b(S), w(null);
                      }
                    }
                  ),
                  v && /* @__PURE__ */ o(Z, { children: [
                    /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "连接名称",
                          value: v.name,
                          onChange: (S) => N({ name: S })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "服务地址",
                          value: v.baseUrl,
                          onChange: (S) => N({ baseUrl: S })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "API 密钥",
                          secret: !0,
                          value: v.apiKey,
                          onChange: (S) => N({ apiKey: S })
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: v.models.map((S, I) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": I === y,
                        onClick: () => w(I),
                        children: [
                          /* @__PURE__ */ e("strong", { children: S.label || S.id || "新模型" }),
                          /* @__PURE__ */ o("small", { children: [
                            S.modelType === "image" ? "图片模型" : "文本模型",
                            " ",
                            "· ",
                            S.contextK,
                            " K"
                          ] })
                        ]
                      },
                      I
                    )) }),
                    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-secondary",
                          onClick: () => {
                            w(v.models.length), N({
                              models: [
                                ...v.models,
                                Iu()
                              ]
                            });
                          },
                          children: "添加模型"
                        }
                      ),
                      /* @__PURE__ */ e(
                        be,
                        {
                          confirm: `删除“${v.name}”及其模型？保存后生效。`,
                          onAction: () => {
                            c(
                              lr(
                                {
                                  ...s,
                                  groups: s.groups.filter(
                                    (S) => S.id !== m
                                  )
                                },
                                Object.fromEntries(
                                  v.models.map((S) => [
                                    `${m}:${S.id}`,
                                    ""
                                  ])
                                )
                              )
                            ), b(""), w(null);
                          },
                          children: "删除连接"
                        }
                      )
                    ] })
                  ] })
                ]
              }
            ),
            g && /* @__PURE__ */ o(ee, { title: g.label || "编辑模型", children: [
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型名称",
                    value: g.id,
                    onChange: (S) => C({ id: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "显示名称",
                    value: g.label,
                    onChange: (S) => C({ label: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型类型",
                    value: g.modelType,
                    options: [
                      { value: "text", label: "文本" },
                      { value: "image", label: "图片" }
                    ],
                    onChange: (S) => C({
                      modelType: S
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "上下文长度（K）",
                    value: g.contextK,
                    numeric: !0,
                    onChange: (S) => C({ contextK: Number(S) })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "缓存有效期（秒）",
                    value: g.cacheTtlSec,
                    numeric: !0,
                    onChange: (S) => C({ cacheTtlSec: Number(S) })
                  }
                ),
                [
                  "inputPrice",
                  "cachedInputPrice",
                  "cacheWritePrice",
                  "outputPrice"
                ].map((S, I) => /* @__PURE__ */ e(
                  X,
                  {
                    label: [
                      "输入价格",
                      "缓存读取价格",
                      "缓存写入价格",
                      "输出价格"
                    ][I],
                    value: g[S] ?? 0,
                    numeric: !0,
                    onChange: (T) => C({ [S]: Number(T) })
                  },
                  S
                )),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "服务协议",
                    value: g.apiProtocol,
                    options: ["openai", "anthropic", "siliconflow"].map(
                      (S) => ({ value: S, label: S })
                    ),
                    onChange: (S) => C({
                      apiProtocol: S
                    })
                  }
                )
              ] }),
              [
                "vision",
                "tools",
                "thinking",
                "thinkingRequired"
              ].map((S, I) => /* @__PURE__ */ e(
                ze,
                {
                  label: ["理解图片", "使用工具", "支持思考", "始终启用思考"][I],
                  checked: g[S],
                  onChange: (T) => C({ [S]: T })
                },
                S
              )),
              /* @__PURE__ */ e(
                X,
                {
                  label: "可用思考力度",
                  value: g.thinkingLevels.join(", "),
                  hint: "以逗号分隔。",
                  onChange: (S) => C({
                    thinkingLevels: S.split(",").map((I) => I.trim()).filter(Boolean)
                  })
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "思考参数格式",
                    value: g.thinkingRequestStyle,
                    options: [
                      "none",
                      "siliconflow",
                      "mimo-thinking",
                      "openai-reasoning-effort",
                      "openrouter-reasoning",
                      "anthropic-thinking"
                    ].map((S) => ({
                      value: S,
                      label: S === "none" ? "自动使用默认格式" : S
                    })),
                    onChange: (S) => C({ thinkingRequestStyle: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "推理内容字段",
                    value: g.reasoningField || "",
                    onChange: (S) => C({ reasoningField: S })
                  }
                )
              ] }),
              g.modelType === "image" && /* @__PURE__ */ o(Z, { children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片接口",
                    value: g.imageApiStyle,
                    options: ["auto", "openai", "siliconflow"].map(
                      (S) => ({
                        value: S,
                        label: S === "auto" ? "自动识别" : S
                      })
                    ),
                    onChange: (S) => C({
                      imageApiStyle: S
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片尺寸",
                    value: g.sizes.join(", "),
                    hint: "例如 1024x1024，以逗号分隔。",
                    onChange: (S) => C({
                      sizes: S.split(",").map((I) => I.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "最多生成张数",
                    numeric: !0,
                    value: g.maxCount,
                    onChange: (S) => C({ maxCount: Number(S) })
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                be,
                {
                  confirm: "移除此模型？保存后生效。",
                  onAction: () => {
                    N({
                      models: v.models.filter(
                        (S, I) => I !== y
                      )
                    }), w(null);
                  },
                  children: "移除模型"
                }
              )
            ] })
          ] }),
          h === "defaults" && /* @__PURE__ */ o(ee, { title: "新对话偏好", children: [
            /* @__PURE__ */ e(
              ze,
              {
                label: "深度思考",
                checked: s.defaultThinking,
                onChange: (S) => x("defaultThinking", S)
              }
            ),
            /* @__PURE__ */ e(
              ze,
              {
                label: "联网搜索",
                checked: s.defaultSearch,
                onChange: (S) => x("defaultSearch", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "默认思考力度",
                value: s.thinkingEffort,
                options: ["low", "medium", "high", "max"].map((S, I) => ({
                  value: S,
                  label: ["轻度", "适中", "深入", "充分"][I]
                })),
                onChange: (S) => x("thinkingEffort", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "补充学习背景",
                multiline: !0,
                value: s.globalContext,
                hint: "介绍你的课程、称呼和回答偏好。",
                onChange: (S) => x("globalContext", S)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字号",
                  numeric: !0,
                  value: s.fontSize || 15,
                  onChange: (S) => x("fontSize", Number(S))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字体",
                  value: s.fontFamily || "inherit",
                  options: [
                    { value: "inherit", label: "跟随全局" },
                    { value: "sans-serif", label: "清晰黑体" },
                    { value: "serif", label: "阅读衬线" },
                    { value: "monospace", label: "等宽" }
                  ],
                  onChange: (S) => x("fontFamily", S)
                }
              )
            ] })
          ] }),
          h === "images" && /* @__PURE__ */ o(ee, { title: "图片创作", children: [
            /* @__PURE__ */ e(
              ze,
              {
                label: "开启图片创作",
                checked: s.imageEnabled,
                onChange: (S) => x("imageEnabled", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "图片创作理解模型",
                value: s.imageTextModel,
                options: L,
                onChange: (S) => x("imageTextModel", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "备用模型",
                value: s.fallbackModel,
                options: L,
                onChange: (S) => x("fallbackModel", S)
              }
            )
          ] }),
          h === "tools" && /* @__PURE__ */ o(ee, { title: "可用工具", children: [
            r.map((S) => /* @__PURE__ */ e(
              ze,
              {
                label: S.label,
                description: S.description,
                checked: !s.disabledTools.includes(S.id),
                onChange: (I) => x(
                  "disabledTools",
                  I ? s.disabledTools.filter((T) => T !== S.id) : [...s.disabledTools, S.id]
                )
              },
              S.id
            )),
            !r.length && /* @__PURE__ */ e("p", { children: "当前没有可配置的工具。" })
          ] }),
          h === "data" && /* @__PURE__ */ o(
            ee,
            {
              title: "导入与导出",
              description: "配置文件可能包含连接密钥，请妥善保管。",
              children: [
                /* @__PURE__ */ o(
                  "label",
                  {
                    className: "fp-workspace-upload",
                    role: "button",
                    tabIndex: 0,
                    onKeyDown: (S) => {
                      (S.key === "Enter" || S.key === " ") && (S.preventDefault(), S.currentTarget.querySelector("input")?.click());
                    },
                    children: [
                      "导入助手设置",
                      /* @__PURE__ */ e(
                        "input",
                        {
                          type: "file",
                          hidden: !0,
                          "aria-label": "导入助手设置",
                          accept: ".json,application/json",
                          onChange: (S) => {
                            const I = S.target.files?.[0];
                            S.target.value = "", I && p.run(async () => {
                              if (I.size > 2e6)
                                throw new Error("设置文件不能超过 2 MB。");
                              let T;
                              try {
                                T = JSON.parse(await I.text());
                              } catch {
                                throw new Error(
                                  "无法读取设置文件，请选择有效的 JSON 文件。"
                                );
                              }
                              if (!za(T))
                                throw new Error("文件内容与助手设置不匹配。");
                              c(T), b(T.groups[0]?.id || ""), w(null);
                            }, "设置已读入，请检查后保存。");
                          }
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                  l && /* @__PURE__ */ e(be, { onAction: () => l(s), children: "导出助手设置" }),
                  i && /* @__PURE__ */ e(be, { onAction: i, children: "导出对话记录" })
                ] })
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
const Au = "#FD8B07", Lu = {
  brand: { name: "五加一", primary: Au, onPrimary: "#542D0C", action: "#B85E00", onAction: "#FFFFFF", darkAction: "#FFB65C", darkOnAction: "#492600", soft: "#FFF2E2", ink: "#914600", darkSoft: "#422D18", darkInk: "#FFC98F" },
  kezhan: { name: "课栈笔记", primary: "#1A73E8", onPrimary: "#FFFFFF", soft: "#E8F0FE", ink: "#185ABC", darkPrimary: "#A8C7FA", darkSoft: "#263751", darkInk: "#C2D7FA", darkOnPrimary: "#142D50" },
  marker: { name: "AI 批改助手", primary: "#13795B", onPrimary: "#FFFFFF", soft: "#E6F4ED", ink: "#0C6248", darkPrimary: "#8DD8B6", darkSoft: "#193C30", darkInk: "#B1E8CE", darkOnPrimary: "#103C2B" },
  onepass: { name: "OnePass", primary: "#7252C7", onPrimary: "#FFFFFF", soft: "#F0EAFC", ink: "#5D3DA8", darkPrimary: "#CDB8FF", darkSoft: "#35294B", darkInk: "#DFD0FF", darkOnPrimary: "#342052" }
}, Xt = (t) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
function Ia(t) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const n = /* @__PURE__ */ new Date(t + "T12:00:00");
  return Number.isFinite(n.getTime()) && Xt(n) === t ? n : null;
}
function hl(t) {
  const [n, r] = k(String(t.defaultValue ?? "")), a = B(null), i = String(t.value ?? n), l = (c) => {
    if (r(c), a.current) {
      a.current.value = c;
      const u = new Event("change", { bubbles: !0 });
      t.onChange?.({ target: a.current, currentTarget: a.current, nativeEvent: u, type: "change", bubbles: !0, cancelable: !1, defaultPrevented: !1, eventPhase: 3, isTrusted: !1, timeStamp: u.timeStamp, preventDefault: () => u.preventDefault(), stopPropagation: () => u.stopPropagation(), isDefaultPrevented: () => u.defaultPrevented, isPropagationStopped: () => !1, persist: () => {
      } });
    }
  }, s = (c) => {
    a.current = c, typeof t.ref == "function" ? t.ref(c) : t.ref && (t.ref.current = c);
  };
  return Y(() => {
    const c = a.current?.form, u = () => r(String(t.defaultValue ?? ""));
    return c?.addEventListener("reset", u), () => c?.removeEventListener("reset", u);
  }, [t.defaultValue]), { input: a, bind: s, value: i, change: l };
}
function Aa({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: a, bind: i, value: l, change: s } = hl(r), c = Ia(l) || /* @__PURE__ */ new Date(), [u, d] = k(new Date(c.getFullYear(), c.getMonth(), 1)), p = u.getFullYear(), h = u.getMonth(), f = r.disabled || r.readOnly, m = (b) => (!r.min || b >= String(r.min)) && (!r.max || b <= String(r.max));
  return Y(() => {
    a.current?.setCustomValidity(l && (!Ia(l) || !m(l)) ? "请填写有效范围内的日期" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: i, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "YYYY-MM-DD", onChange: (b) => s(b.target.value) }),
    /* @__PURE__ */ e(Qe, { label: "选择日期", disabled: f, trigger: /* @__PURE__ */ e(Xa, { size: 17 }), className: "fp-date-popup", onOpenChange: (b) => {
      b && d(new Date(c.getFullYear(), c.getMonth(), 1));
    }, children: (b) => /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上个月", onClick: () => d(new Date(p, h - 1, 1)), children: /* @__PURE__ */ e(Mr, { size: 17 }) }),
        /* @__PURE__ */ o("strong", { children: [
          p,
          " 年 ",
          h + 1,
          " 月"
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下个月", onClick: () => d(new Date(p, h + 1, 1)), children: /* @__PURE__ */ e(Ie, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-calendar-grid", role: "group", "aria-label": "日期", children: [
        "日一二三四五六".split("").map((y) => /* @__PURE__ */ e("span", { children: y }, y)),
        Array.from({ length: new Date(p, h, 1).getDay() }, (y, w) => /* @__PURE__ */ e("span", {}, "blank" + w)),
        Array.from({ length: new Date(p, h + 1, 0).getDate() }, (y, w) => {
          const v = Xt(new Date(p, h, w + 1));
          return /* @__PURE__ */ e("button", { type: "button", "data-date": v, "aria-label": v, "aria-pressed": l === v, disabled: !m(v), onClick: () => {
            s(v), b();
          }, onKeyDown: (g) => {
            const x = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[g.key];
            if (!x) return;
            g.preventDefault();
            const N = new Date(p, h, w + 1 + x), C = Xt(N), A = g.currentTarget.closest(".fp-calendar");
            d(new Date(N.getFullYear(), N.getMonth(), 1)), requestAnimationFrame(() => A?.querySelector(`[data-date="${C}"]`)?.focus());
          }, children: w + 1 }, v);
        })
      ] }),
      /* @__PURE__ */ o("footer", { children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: r.required, onClick: () => {
          s(""), b();
        }, children: "清除" }),
        /* @__PURE__ */ e("button", { type: "button", disabled: !m(Xt(/* @__PURE__ */ new Date())), onClick: () => {
          s(Xt(/* @__PURE__ */ new Date())), b();
        }, children: "今天" })
      ] })
    ] }) })
  ] });
}
function cf({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: a, bind: i, value: l, change: s } = hl(r), [c, u] = l.split(":");
  return Y(() => {
    a.current?.setCustomValidity(l && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(l) || r.min && l < String(r.min) || r.max && l > String(r.max)) ? "请填写有效范围内的时间" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: i, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "HH:mm", onChange: (d) => s(d.target.value) }),
    /* @__PURE__ */ e(Qe, { label: "选择时间", disabled: r.disabled || r.readOnly, trigger: /* @__PURE__ */ e(Rn, { size: 17 }), className: "fp-time-popup", children: (d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-time-columns", children: [["小时", 24, c], ["分钟", 60, u]].map(([p, h, f], m) => /* @__PURE__ */ e("div", { role: "group", "aria-label": String(p), children: Array.from({ length: Number(h) }, (b, y) => {
        const w = String(y).padStart(2, "0"), v = m === 0 ? `${w}:${u || "00"}` : `${c || "00"}:${w}`, g = m === 0 ? r.min && v < String(r.min) ? String(r.min) : r.max && v > String(r.max) ? String(r.max) : v : v, x = m === 0 ? (!r.min || `${w}:59` >= String(r.min)) && (!r.max || `${w}:00` <= String(r.max)) : (!r.min || g >= String(r.min)) && (!r.max || g <= String(r.max));
        return /* @__PURE__ */ e("button", { type: "button", "aria-pressed": f === w, disabled: !x, onClick: () => s(g), children: w }, w);
      }) }, p)) }),
      /* @__PURE__ */ e("footer", { children: /* @__PURE__ */ e("button", { type: "button", onClick: d, children: "完成" }) })
    ] }) })
  ] });
}
function fl({ label: t, value: n, onChange: r, disabled: a = !1 }) {
  const [i, l] = k(n), s = ["#FD8B07", "#B85E00", "#1A73E8", "#13795B", "#7252C7", "#D44A61", "#202124", "#FFFFFF"];
  Y(() => l(n), [n]);
  const c = /^#[0-9a-f]{6}$/i.test(n) ? n : "#FD8B07", u = (p) => parseInt(c.slice(p * 2 + 1, p * 2 + 3), 16), d = Ne();
  return /* @__PURE__ */ o("div", { className: "fp-color-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e(Qe, { disabled: a, label: t, trigger: /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e("i", { className: "fp-color-swatch", style: { background: c } }),
      /* @__PURE__ */ e("code", { children: n })
    ] }), className: "fp-color-popup", children: () => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-color-swatches", children: s.map((p) => /* @__PURE__ */ e("button", { type: "button", "aria-label": p, "aria-pressed": n.toLowerCase() === p.toLowerCase(), style: { background: p }, onClick: () => {
        l(p), r(p);
      } }, p)) }),
      ["红", "绿", "蓝"].map((p, h) => /* @__PURE__ */ o("label", { className: "fp-color-channel", children: [
        p,
        /* @__PURE__ */ e("input", { type: "range", "aria-label": p, min: 0, max: 255, value: u(h), onChange: (f) => {
          const m = [u(0), u(1), u(2)];
          m[h] = Number(f.target.value);
          const b = "#" + m.map((y) => y.toString(16).padStart(2, "0")).join("");
          l(b), r(b);
        } }),
        /* @__PURE__ */ e("output", { children: u(h) })
      ] }, p)),
      /* @__PURE__ */ e("label", { htmlFor: d, children: "HEX" }),
      /* @__PURE__ */ e("input", { id: d, className: "fp-input", "aria-label": "十六进制颜色", value: i, onFocus: () => l(n), onChange: (p) => {
        l(p.target.value), /^#[0-9a-f]{6}$/i.test(p.target.value) && r(p.target.value);
      } })
    ] }) })
  ] });
}
const jr = {
  system: "system-ui, sans-serif",
  songti: '"Noto Serif SC", SimSun, serif',
  kaiti: "KaiTi, STKaiti, serif",
  hei: '"Microsoft YaHei", sans-serif',
  serif: "Georgia, serif",
  mono: "Consolas, monospace"
}, La = [
  { value: "system", label: "系统默认" },
  { value: "songti", label: "宋体阅读" },
  { value: "kaiti", label: "楷体手写" },
  { value: "hei", label: "黑体清晰" },
  { value: "serif", label: "英文衬线" },
  { value: "mono", label: "等宽" }
].map((t) => ({ ...t, fontFamily: jr[t.value] }));
function Tu(t, n = !1, r = "brand") {
  const a = t.theme === "dark" || t.theme === "system" && n, i = a ? "#1d1f22" : "#ffffff", l = {
    colorScheme: a ? "dark" : "light",
    fontFamily: jr[t.font] || t.font,
    "--fp-bg": a ? "#141517" : "#fbfaf8",
    "--fp-surface": i,
    "--fp-surface-muted": a ? "#26282c" : "#f4f2ef",
    "--fp-surface-sunken": a ? "#101113" : "#eeebe7",
    "--fp-ink": a ? "#e8eaed" : "#202124",
    "--fp-muted": a ? "#a9adb4" : "#6b7075",
    "--fp-faint": a ? "#7c828a" : "#9aa0a6",
    "--fp-line": a ? "#34373c" : "#e6e3df",
    "--fp-line-strong": a ? "#464a50" : "#d3cfca"
  }, s = Lu[r];
  Object.assign(l, {
    "--fp-primary": a && s.darkPrimary || s.primary,
    "--fp-on-primary": a && s.darkOnPrimary || s.onPrimary,
    "--fp-primary-soft": a ? s.darkSoft : s.soft,
    "--fp-primary-ink": a ? s.darkInk : s.ink,
    "--fp-action": a ? s.darkAction || s.darkPrimary || s.primary : s.action || s.primary,
    "--fp-on-action": a ? s.darkOnAction || s.darkOnPrimary || s.onPrimary : s.onAction || s.onPrimary
  });
  const c = a ? t.darkAccent : t.lightAccent;
  if (t.mode === "custom" && /^#[\da-f]{6}$/i.test(c)) {
    const u = [1, 3, 5].map((f) => parseInt(c.slice(f, f + 2), 16)), d = (f, m) => "#" + u.map(
      (b) => Math.round(b + (m - b) * f).toString(16).padStart(2, "0")
    ).join(""), p = (f) => {
      const m = [1, 3, 5].map((b) => parseInt(f.slice(b, b + 2), 16) / 255).map((b) => b <= 0.04045 ? b / 12.92 : ((b + 0.055) / 1.055) ** 2.4);
      return m[0] * 0.2126 + m[1] * 0.7152 + m[2] * 0.0722;
    };
    let h = c;
    for (let f = 0; f <= 0.9; f += 0.05) {
      h = d(f, a ? 255 : 0);
      const m = p(h);
      if (a ? (m + 0.05) / 0.05 >= 7 : 1.05 / (m + 0.05) >= 4.5) break;
    }
    Object.assign(l, {
      "--fp-primary": c,
      "--fp-on-primary": p(c) > 0.179 ? "#202124" : "#ffffff",
      "--fp-primary-soft": `color-mix(in srgb, ${c} 14%, ${i})`,
      "--fp-primary-ink": a ? d(0.5, 255) : d(0.35, 0),
      "--fp-action": h,
      "--fp-on-action": a ? "#101113" : "#ffffff"
    });
  }
  return /^#[\da-f]{6}$/i.test(t.selection) && (l["--fp-selection"] = t.selection), l["--fp-heading-color"] = t.mode === "colorful" ? l["--fp-primary-ink"] : l["--fp-ink"], l;
}
function Du(t, n) {
  const r = t.regions[n];
  return {
    fontFamily: jr[!r || r.inherit ? t.font : r.font] || (!r || r.inherit ? t.font : r.font),
    fontSize: r && !r.inherit ? r.fontSize : void 0,
    lineHeight: r && !r.inherit ? r.lineHeight : void 0
  };
}
function df({
  value: t,
  onChange: n,
  onReset: r,
  product: a = "brand",
  heading: i = !0,
  regions: l = [
    { id: "reading", label: "笔记阅读" },
    { id: "editor", label: "笔记编辑" },
    { id: "chat", label: "助手对话" }
  ]
}) {
  const [s, c] = k(
    () => typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches
  );
  Y(() => {
    if (typeof matchMedia > "u") return;
    const d = matchMedia("(prefers-color-scheme: dark)"), p = () => c(d.matches);
    return d.addEventListener("change", p), () => d.removeEventListener("change", p);
  }, []);
  const u = (d) => n({ ...t, ...d });
  return /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form fp-appearance-workspace",
      "data-mode": t.mode,
      style: Tu(t, s, a),
      "aria-label": "外观设置",
      children: /* @__PURE__ */ o(
        ee,
        {
          title: i ? "外观" : void 0,
          description: i ? "让阅读、写作和对话保持适合自己的节奏。" : void 0,
          children: [
            /* @__PURE__ */ e(
              _e,
              {
                label: "明暗主题",
                value: t.theme,
                onChange: (d) => u({ theme: d }),
                items: [
                  { id: "light", label: "浅色" },
                  { id: "dark", label: "深色" },
                  { id: "system", label: "跟随系统" }
                ]
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "配色方式",
                value: t.mode,
                options: [
                  { value: "default", label: "产品默认" },
                  { value: "colorful", label: "内容彩色" },
                  { value: "custom", label: "自定义" }
                ],
                onChange: (d) => u({ mode: d })
              }
            ),
            /* @__PURE__ */ e(fe, { children: t.mode === "custom" && /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: ["lightAccent", "darkAccent", "selection"].map(
              (d, p) => /* @__PURE__ */ e(
                fl,
                {
                  label: ["白天主色", "夜间主色", "划词颜色"][p],
                  value: t[d],
                  onChange: (h) => u({ [d]: h, mode: "custom" })
                },
                d
              )
            ) }) }),
            /* @__PURE__ */ e(
              X,
              {
                label: "全局字体",
                value: t.font,
                options: La,
                onChange: (d) => u({ font: d })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "界面字号 · ",
                  t.uiFontSize ?? 14,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "界面字号", type: "range", min: "12", max: "20", step: "1", value: t.uiFontSize ?? 14, onChange: (d) => u({ uiFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整导航、按钮和设置中的文字大小。" })
              ] }),
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "正文字号 · ",
                  t.readingFontSize ?? 16,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "正文字号", type: "range", min: "14", max: "28", step: "1", value: t.readingFontSize ?? 16, onChange: (d) => u({ readingFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整笔记、编辑器和 AI 对话中的正文大小。" })
              ] })
            ] }),
            /* @__PURE__ */ e("p", { className: "fp-workspace-type-preview", style: { fontSize: `${t.readingFontSize ?? 16}px` }, children: "从阅读到理解，把想法变成自己的笔记。" }),
            l.map((d) => {
              const p = t.regions[d.id] || {
                font: t.font,
                fontSize: 16,
                lineHeight: 1.9,
                inherit: !0
              }, h = (f) => u({
                regions: {
                  ...t.regions,
                  [d.id]: { ...p, ...f }
                }
              });
              return /* @__PURE__ */ o(ee, { title: d.label, children: [
                /* @__PURE__ */ e(
                  ze,
                  {
                    label: `${d.label}跟随全局字体`,
                    checked: p.inherit,
                    onChange: (f) => h({ inherit: f })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字体`,
                      value: p.font,
                      options: La,
                      disabled: p.inherit,
                      onChange: (f) => h({ font: f })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字号`,
                      value: p.fontSize,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        Number.isFinite(m) && m >= 10 && m <= 32 && h({ fontSize: m });
                      }
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}行高`,
                      value: p.lineHeight,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        m >= 1.2 && m <= 2.5 && h({ lineHeight: m });
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  "p",
                  {
                    className: "fp-workspace-type-preview",
                    style: Du(t, d.id),
                    children: "从阅读到理解，把想法变成自己的笔记。"
                  }
                )
              ] }, d.id);
            }),
            /* @__PURE__ */ e(be, { confirm: "恢复产品默认外观？", onAction: r, children: "恢复默认外观" })
          ]
        }
      )
    }
  );
}
function uf({
  records: t,
  onOpen: n,
  onClear: r,
  shortcuts: a,
  appearance: i
}) {
  const l = [...new Set(t.map((u) => u.subject))], s = t.reduce((u, d) => u + d.attempts, 0), c = t.length ? Math.round(t.reduce((u, d) => u + d.best, 0) / t.length) : 0;
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form", "aria-label": "学习设置", children: [
    /* @__PURE__ */ o(
      ee,
      {
        title: "学习记录",
        description: `${t.length} 个章节 · 平均最佳分 ${c} · ${s} 次测验`,
        children: [
          l.map((u) => /* @__PURE__ */ e(ee, { title: u, children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: t.filter((d) => d.subject === u).map((d) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(d.id), children: [
            /* @__PURE__ */ e("strong", { children: d.chapter }),
            /* @__PURE__ */ o("small", { children: [
              "上次 ",
              d.last,
              " 分 · 最佳 ",
              d.best,
              " 分 · ",
              d.attempts,
              " 次"
            ] })
          ] }, d.id)) }) }, u)),
          !t.length && /* @__PURE__ */ e("p", { children: "完成章节测验后，可以在这里查看学习记录。" }),
          /* @__PURE__ */ e(
            be,
            {
              disabled: !t.length,
              confirm: "清空全部测验成绩？题目和笔记会保留。",
              onAction: r,
              children: "清空测验成绩"
            }
          )
        ]
      }
    ),
    a && /* @__PURE__ */ e(ee, { title: "快捷键", children: a }),
    i
  ] });
}
function Pu(t, n, r, a) {
  if (t.reduce((s, c) => s + c, 0) + Math.max(0, t.length - 1) * a <= n) return t.length;
  let i = r, l = 0;
  for (const s of t) {
    if (i + a + s > n) break;
    i += a + s, l++;
  }
  return l;
}
function ml({ actions: t, label: n = "操作", moreLabel: r = "更多操作", className: a = "" }) {
  const i = B(null), l = B(null), [s, c] = k(0), u = t.map((p) => p.id).join("\0");
  Ce(() => {
    const p = i.current, h = l.current;
    if (!p || !h) return;
    const f = () => {
      const b = getComputedStyle(p), y = parseFloat(b.columnGap) || 4, v = Array.from(h.querySelectorAll("[data-action-width]")).map((x) => x.getBoundingClientRect().width || 32), g = h.querySelector("[data-more-width]")?.getBoundingClientRect().width || 32;
      c(Pu(v, p.clientWidth - (parseFloat(b.paddingLeft) || 0) - (parseFloat(b.paddingRight) || 0), g, y));
    };
    f();
    const m = typeof ResizeObserver > "u" ? null : new ResizeObserver(f);
    return m?.observe(p), m?.observe(h), document.fonts?.ready.then(f), () => m?.disconnect();
  }, [u]);
  const d = (p, h = !1) => /* @__PURE__ */ e("button", { type: "button", "data-action-width": h ? "" : void 0, "data-fp-tooltip": p.label, "aria-label": p.label, disabled: p.disabled, "data-danger": p.danger || void 0, onClick: h ? void 0 : p.onSelect, children: p.icon }, p.id);
  return /* @__PURE__ */ o("div", { ref: i, className: `fp-action-toolbar ${a}`, role: "toolbar", "aria-label": n, onKeyDown: (p) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(p.key)) return;
    const h = Array.from(i.current?.querySelectorAll(":scope > button:not(:disabled), :scope > .fp-dropdown > button:not(:disabled)") || []), f = h.indexOf(document.activeElement);
    f < 0 || (p.preventDefault(), h[p.key === "Home" ? 0 : p.key === "End" ? h.length - 1 : (f + (p.key === "ArrowRight" ? 1 : -1) + h.length) % h.length]?.focus());
  }, children: [
    t.slice(0, s).map((p) => d(p)),
    s < t.length && /* @__PURE__ */ e(Qe, { label: r, icon: /* @__PURE__ */ e(Dt, { size: 18 }), menu: !0, density: "compact", children: (p) => /* @__PURE__ */ e("div", { className: "fp-action-menu", children: t.slice(s).map((h) => /* @__PURE__ */ o("button", { role: "menuitem", type: "button", disabled: h.disabled, "data-danger": h.danger || void 0, onClick: () => {
      p(), h.onSelect();
    }, children: [
      h.icon,
      /* @__PURE__ */ e("span", { children: h.label })
    ] }, h.id)) }) }),
    /* @__PURE__ */ o("div", { ref: l, className: "fp-action-measure", "aria-hidden": "true", inert: !0, children: [
      t.map((p) => d(p, !0)),
      /* @__PURE__ */ e("button", { type: "button", "data-more-width": !0, children: /* @__PURE__ */ e(Dt, { size: 18 }) })
    ] })
  ] });
}
function pf({
  anchor: t,
  open: n,
  onClose: r,
  children: a,
  label: i,
  id: l,
  role: s = "dialog",
  width: c,
  maxHeight: u = 320,
  className: d = "",
  initialFocus: p,
  autoFocus: h = s !== "listbox"
}) {
  const f = B(null), m = B(r);
  m.current = r;
  const [b, y] = k(!1), [w, v] = k({
    left: 8,
    top: 8,
    width: c || 240,
    maxHeight: u
  }), g = B(!1), x = jt(t, n);
  return Ce(() => {
    g.current && !n && y(!0), g.current = n;
  }, [n]), Y(() => {
    if (!b) return;
    const N = setTimeout(() => y(!1), 120);
    return () => clearTimeout(N);
  }, [b]), Ce(() => {
    if (!n) return;
    const N = () => {
      const A = t.current?.getBoundingClientRect();
      if (!A) {
        m.current();
        return;
      }
      const L = Math.max(
        0,
        Math.min(c || Math.max(A.width, 240), window.innerWidth - 16)
      ), U = window.innerHeight - A.bottom - 16, S = A.top - 16, I = U < Math.min(f.current?.scrollHeight || u, 200) && S > U, T = Math.max(0, Math.min(u, I ? S : U));
      v({
        left: Math.max(8, Math.min(A.left, window.innerWidth - L - 8)),
        top: I ? Math.max(
          8,
          A.top - Math.min(f.current?.scrollHeight || T, T) - 8
        ) : A.bottom + 8,
        width: L,
        maxHeight: T
      });
    };
    N();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(N);
    return t.current && C?.observe(t.current), f.current && C?.observe(f.current), window.addEventListener("resize", N), window.addEventListener("scroll", N, !0), () => {
      C?.disconnect(), window.removeEventListener("resize", N), window.removeEventListener("scroll", N, !0);
    };
  }, [n, t, c, u]), Y(() => {
    if (!n) return;
    const N = requestAnimationFrame(() => {
      !h && !p?.current || (p?.current || f.current?.querySelector(
        'input,button,[tabindex="0"]'
      ) || f.current)?.focus({ preventScroll: !0 });
    }), C = (L) => {
      !f.current?.contains(L.target) && !t.current?.contains(L.target) && m.current();
    }, A = (L) => {
      L.key === "Escape" && (!L.target.closest?.("[data-fp-overlay]") || L.target.closest?.("[data-fp-overlay]") === f.current) && (L.preventDefault(), L.stopPropagation(), m.current(), t.current?.focus({ preventScroll: !0 }));
    };
    return document.addEventListener("pointerdown", C, !0), document.addEventListener("focusin", C, !0), document.addEventListener("keydown", A, !0), () => {
      cancelAnimationFrame(N), document.removeEventListener("pointerdown", C, !0), document.removeEventListener("focusin", C, !0), document.removeEventListener("keydown", A, !0);
    };
  }, [n, t, p, h]), !n && !b ? null : Te(
    /* @__PURE__ */ e(
      "div",
      {
        ref: f,
        "data-fp-overlay": "",
        id: l,
        role: s,
        "aria-label": i,
        tabIndex: -1,
        "data-exiting": !n || void 0,
        "aria-hidden": !n || void 0,
        inert: !n,
        className: `fp-popup-panel fp-anchored-panel ${d}`,
        style: { ...x, position: "fixed", ...w, overflow: "auto" },
        onKeyDown: (N) => {
          if (s === "dialog" || N.target.closest("[data-fp-overlay]") !== f.current || N.target.matches("input,textarea"))
            return;
          const C = [
            ...N.currentTarget.querySelectorAll(
              '[role="menuitem"]:not(:disabled),[role="option"]:not(:disabled)'
            )
          ], A = C.indexOf(document.activeElement), L = N.key === "ArrowDown" ? (A + 1) % C.length : N.key === "ArrowUp" ? (A - 1 + C.length) % C.length : N.key === "Home" ? 0 : N.key === "End" ? C.length - 1 : -1;
          L >= 0 && (N.preventDefault(), N.stopPropagation(), C[L]?.focus());
        },
        children: a
      }
    ),
    t.current?.closest("[data-fp-overlay],dialog") || document.body
  );
}
function hf({ dark: t, onChange: n, disabled: r }) {
  return /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": t ? "切换为浅色" : "切换为深色", disabled: r, onClick: () => n(!t), children: t ? /* @__PURE__ */ e(Zl, { size: 19, "aria-hidden": "true" }) : /* @__PURE__ */ e(eo, { size: 19, "aria-hidden": "true" }) });
}
function ff({ name: t, detail: n, avatar: r, role: a, actions: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-share-member-row", children: [
    /* @__PURE__ */ e("span", { className: "fp-share-member-avatar", "aria-hidden": "true", children: r || t.slice(0, 1) }),
    /* @__PURE__ */ o("span", { className: "fp-share-member-identity", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-share-member-role", children: a }),
    i && /* @__PURE__ */ e("div", { className: "fp-share-member-actions", children: i })
  ] });
}
function mf({ items: t, value: n, onChange: r, onClose: a, children: i }) {
  const [l, s] = k("");
  return /* @__PURE__ */ o("div", { className: "fp-settings-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: "设置" }),
      /* @__PURE__ */ o("label", { className: "fp-settings-search", children: [
        /* @__PURE__ */ e(Je, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索设置", placeholder: "搜索设置", value: l, onChange: (c) => s(c.target.value) })
      ] }),
      /* @__PURE__ */ e("nav", { "aria-label": "设置分类", children: t.filter((c) => c.label.includes(l.trim())).map((c) => /* @__PURE__ */ o("button", { type: "button", "aria-current": n === c.id ? "page" : void 0, onClick: () => r(c.id), children: [
        c.icon,
        /* @__PURE__ */ e("span", { children: c.label })
      ] }, c.id)) })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-settings-page", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("h2", { children: t.find((c) => c.id === n)?.label }),
        /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": "关闭", onClick: a, children: /* @__PURE__ */ e(ge, { size: 20 }) })
      ] }),
      /* @__PURE__ */ e("div", { className: "fp-settings-page-content", children: i })
    ] })
  ] });
}
function bf({ onContinue: t, onDiscard: n }) {
  const r = B(null), a = Ne();
  return Y(() => {
    const i = document.activeElement;
    return r.current?.focus(), () => {
      i?.isConnected && i.focus();
    };
  }, []), /* @__PURE__ */ e("div", { className: "fp-discard-backdrop", children: /* @__PURE__ */ o("section", { className: "fp-discard-prompt", role: "alertdialog", "aria-modal": "true", "aria-label": "保存当前更改", "aria-describedby": a, children: [
    /* @__PURE__ */ e("h2", { children: "保留这次更改？" }),
    /* @__PURE__ */ e("p", { id: a, children: "更改尚未保存。你可以继续编辑，或放弃后关闭。" }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("button", { ref: r, type: "button", className: "fp-button fp-secondary", onClick: t, children: "继续编辑" }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-danger", onClick: n, children: "放弃更改" })
    ] })
  ] }) });
}
function gf({ header: t, children: n, actions: r, onFinish: a }) {
  return /* @__PURE__ */ o("section", { className: "fp-card-editor-frame", "data-nested-editor-boundary": "", onKeyDownCapture: (i) => {
    a && !i.nativeEvent.isComposing && i.key === "Enter" && (i.ctrlKey || i.metaKey) && (i.preventDefault(), i.stopPropagation(), a());
  }, children: [
    /* @__PURE__ */ e("header", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-card-editor-content", children: n }),
    /* @__PURE__ */ e("footer", { children: r })
  ] });
}
function yf({
  query: t,
  onQueryChange: n,
  onSearch: r,
  onOpen: a,
  placeholder: i = "搜索笔记与资料",
  debounceMs: l = 220
}) {
  const [s, c] = k([]), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(0), [b, y] = k(0), w = B(0), v = B(null);
  Y(() => {
    const x = new AbortController(), N = ++w.current;
    if (c([]), m(0), h(""), d(!!t.trim()), !t.trim()) return () => x.abort();
    const C = setTimeout(() => {
      r(t.trim(), x.signal).then((A) => {
        !x.signal.aborted && N === w.current && c(A);
      }).catch(() => {
        x.signal.aborted || h("暂时无法搜索，请重试。");
      }).finally(() => {
        !x.signal.aborted && N === w.current && d(!1);
      });
    }, l);
    return () => {
      clearTimeout(C), x.abort();
    };
  }, [t, r, l, b]);
  const g = s.filter((x) => !x.disabled);
  return /* @__PURE__ */ o("section", { className: "fp-search-results", children: [
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(Je, { size: 17 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索内容",
          placeholder: i,
          value: t,
          onChange: (x) => n(x.target.value),
          onKeyDown: (x) => {
            if (!x.nativeEvent.isComposing) {
              if (x.key === "ArrowDown" || x.key === "ArrowUp") {
                x.preventDefault();
                const N = (f + (x.key === "ArrowDown" ? 1 : -1) + Math.max(g.length, 1)) % Math.max(g.length, 1);
                m(N), v.current?.querySelectorAll("button[data-hit]")[N]?.scrollIntoView?.({ block: "nearest" });
              }
              x.key === "Enter" && g[f] && (x.preventDefault(), a(g[f]));
            }
          }
        }
      )
    ] }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { ref: v, className: "fp-search-hits", "aria-busy": u, children: u ? /* @__PURE__ */ e("p", { role: "status", children: "正在搜索…" }) : p ? /* @__PURE__ */ o("p", { role: "alert", children: [
      p,
      /* @__PURE__ */ e("button", { type: "button", onClick: () => y((x) => x + 1), children: "重试" })
    ] }) : t.trim() ? s.length ? s.map((x) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "data-hit": x.disabled ? void 0 : "",
        "data-active": g[f]?.id === x.id || void 0,
        disabled: x.disabled,
        onClick: () => a(x),
        children: [
          x.icon,
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: x.title }),
            x.path && /* @__PURE__ */ e("small", { children: x.path }),
            x.excerpt && /* @__PURE__ */ e("span", { children: x.excerpt })
          ] })
        ]
      },
      x.id
    )) : /* @__PURE__ */ e("p", { children: "没有找到匹配的内容。" }) : /* @__PURE__ */ e("p", { children: "输入关键词查找内容。" }) }) })
  ] });
}
function vf({
  tabs: t,
  activeId: n,
  paneId: r = "main",
  onSelect: a,
  onClose: i,
  onMove: l,
  onSplit: s
}) {
  const c = B(null), u = (d, p) => {
    d.preventDefault();
    try {
      const h = JSON.parse(
        d.dataTransfer.getData("application/x-fiveplusone-tab")
      );
      typeof h.id == "string" && l?.(h.id, r, p);
    } catch {
    }
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-workspace-tabs",
      onDragOver: (d) => {
        l && d.dataTransfer.types.includes("application/x-fiveplusone-tab") && d.preventDefault();
      },
      onDrop: (d) => u(d, t.length),
      children: [
        /* @__PURE__ */ e(
          "div",
          {
            ref: c,
            role: "tablist",
            "aria-label": "打开的文档",
            onKeyDown: (d) => {
              const p = t.findIndex((f) => f.id === n);
              let h = p;
              if (d.key === "ArrowRight") h = (p + 1) % t.length;
              else if (d.key === "ArrowLeft")
                h = (p - 1 + t.length) % t.length;
              else if (d.key === "Home") h = 0;
              else if (d.key === "End") h = t.length - 1;
              else return;
              t[h] && (d.preventDefault(), a(t[h].id), c.current?.querySelectorAll("[role=tab]")[h]?.focus());
            },
            children: t.map((d, p) => /* @__PURE__ */ e(
              gt,
              {
                label: `${d.title}的操作`,
                items: [
                  {
                    id: "close",
                    label: "关闭",
                    disabled: d.closable === !1,
                    onSelect: () => i(d.id)
                  },
                  ...l ? [
                    {
                      id: "left",
                      label: "移到最前",
                      onSelect: () => l(d.id, r, 0)
                    }
                  ] : []
                ],
                children: /* @__PURE__ */ o(
                  "div",
                  {
                    className: "fp-workspace-tab",
                    "data-active": n === d.id || void 0,
                    draggable: !!l,
                    onDragStart: (h) => {
                      h.dataTransfer.setData(
                        "application/x-fiveplusone-tab",
                        JSON.stringify({ id: d.id, paneId: r })
                      ), h.dataTransfer.effectAllowed = "move";
                    },
                    onDrop: (h) => {
                      h.stopPropagation(), u(h, p);
                    },
                    children: [
                      /* @__PURE__ */ o(
                        "button",
                        {
                          type: "button",
                          role: "tab",
                          "aria-selected": n === d.id,
                          tabIndex: n === d.id ? 0 : -1,
                          onClick: () => a(d.id),
                          children: [
                            d.icon,
                            /* @__PURE__ */ e("span", { children: d.title }),
                            d.dirty && /* @__PURE__ */ e("span", { "aria-label": "尚未保存", className: "fp-tab-dirty", children: "•" })
                          ]
                        }
                      ),
                      d.closable !== !1 && /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          "aria-label": `关闭${d.title}`,
                          onClick: () => i(d.id),
                          children: /* @__PURE__ */ e(ge, { size: 13 })
                        }
                      )
                    ]
                  }
                )
              },
              d.id
            ))
          }
        ),
        s && /* @__PURE__ */ e("button", { type: "button", "aria-label": "切换分屏", onClick: s, children: /* @__PURE__ */ e(to, { size: 16 }) })
      ]
    }
  );
}
function Ou({ section: t }) {
  const [n, r] = k(
    t.defaultOpen ?? t.kind === "content"
  );
  return /* @__PURE__ */ o("section", { className: "fp-message-section", "data-status": t.status, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": n,
        onClick: () => r((a) => !a),
        children: [
          /* @__PURE__ */ e(
            Ie,
            {
              size: 14,
              style: { transform: n ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t.label }),
          t.status && /* @__PURE__ */ e("small", { children: t.status === "running" ? "进行中" : t.status === "done" ? "已完成" : "需要处理" })
        ]
      }
    ),
    /* @__PURE__ */ e(Oe, { isOpen: n, children: /* @__PURE__ */ e("div", { children: t.content }) })
  ] });
}
function wf({
  sections: t,
  actions: n
}) {
  return /* @__PURE__ */ o("article", { className: "fp-message-content-view", children: [
    t.map((r) => /* @__PURE__ */ e(Ou, { section: r }, r.id)),
    n && /* @__PURE__ */ e("footer", { children: n })
  ] });
}
function kf({
  title: t,
  description: n,
  kind: r = "文档",
  onOpen: a
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-artifact-card", onClick: a, children: [
    /* @__PURE__ */ e(Ye, { size: 24 }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("small", { children: r }),
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "↗" })
  ] });
}
function Nf({
  title: t,
  children: n,
  onDownload: r,
  onSave: a,
  loading: i,
  error: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-artifact", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "下载" }),
        a && /* @__PURE__ */ e(be, { disabled: i, onAction: a, children: "保存到资料" })
      ] })
    ] }),
    i ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开内容…" }) : l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : /* @__PURE__ */ e("div", { className: "fp-artifact-content", children: n })
  ] });
}
function xf({
  items: t,
  onToggle: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "学习助手能力" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-skill-row", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: r.name }),
        /* @__PURE__ */ e("small", { children: r.description })
      ] }),
      /* @__PURE__ */ e(
        be,
        {
          disabled: r.disabled,
          onAction: () => n(r.id, !r.enabled),
          children: r.enabled ? "停用" : "启用"
        }
      )
    ] }, r.id))
  ] });
}
class Fu {
  nodes = [];
  links = [];
  heat = 1;
  byId = /* @__PURE__ */ new Map();
  reconcile(n, r) {
    const a = /* @__PURE__ */ new Map();
    n.forEach((l, s) => {
      if (a.has(l)) return;
      const c = s * 2.399963229728653, u = 24 * Math.sqrt(s + 1), d = this.byId.get(l) || { id: l, x: Math.cos(c) * u, y: Math.sin(c) * u, vx: 0, vy: 0, degree: 0 };
      d.degree = 0, a.set(l, d);
    }), this.byId = a, this.nodes = [...a.values()];
    const i = /* @__PURE__ */ new Set();
    this.links = [], r.forEach((l) => {
      const s = a.get(l.source), c = a.get(l.target), u = JSON.stringify([l.source, l.target].sort());
      !s || !c || s === c || i.has(u) || (i.add(u), s.degree++, c.degree++, this.links.push([s, c]));
    }), this.wake();
  }
  get(n) {
    return this.byId.get(n);
  }
  wake() {
    this.heat = 1;
  }
  pin(n, r, a) {
    const i = this.get(n);
    i && (i.fixed = { x: r, y: a }, i.x = r, i.y = a, i.vx = i.vy = 0, this.wake());
  }
  release(n) {
    const r = this.get(n);
    r && (delete r.fixed, this.wake());
  }
  step(n) {
    if (this.heat < 2e-3) return !1;
    const r = this.nodes, a = Math.max(0, n.repelForce) * 180, i = Math.max(0.15, this.heat);
    for (let c = 0; c < r.length; c++) for (let u = c + 1; u < r.length; u++) {
      const d = r[c], p = r[u];
      let h = p.x - d.x, f = p.y - d.y;
      Math.abs(h) + Math.abs(f) < 1e-3 && (h = 0.1 * Math.cos(c + u), f = 0.1 * Math.sin(c + u));
      const m = Math.sqrt(h * h + f * f), b = 16 * n.nodeSize, y = Math.min(8, a / Math.max(64, m * m) + Math.max(0, b - m) * 0.12) * i, w = h / m * y, v = f / m * y;
      d.vx -= w, d.vy -= v, p.vx += w, p.vy += v;
    }
    for (const [c, u] of this.links) {
      const d = u.x - c.x, p = u.y - c.y, h = Math.max(1, Math.hypot(d, p)), f = 74 + Math.min(40, (c.degree + u.degree) * 1.2), m = (h - f) * 0.025 * n.linkForce * i, b = d / h * m, y = p / h * m;
      c.vx += b / Math.sqrt(c.degree), c.vy += y / Math.sqrt(c.degree), u.vx -= b / Math.sqrt(u.degree), u.vy -= y / Math.sqrt(u.degree);
    }
    let l = 0, s = !1;
    for (const c of r) {
      if (c.fixed) {
        c.x = c.fixed.x, c.y = c.fixed.y, c.vx = c.vy = 0, s = !0;
        continue;
      }
      c.vx = Math.max(-14, Math.min(14, (c.vx - c.x * n.centerForce * 1e-3) * 0.82)), c.vy = Math.max(-14, Math.min(14, (c.vy - c.y * n.centerForce * 1e-3) * 0.82)), c.x += c.vx, c.y += c.vy, l += c.vx * c.vx + c.vy * c.vy;
    }
    return this.heat = s ? Math.max(0.35, this.heat * 0.985) : this.heat * (l / Math.max(1, r.length) < 2e-3 ? 0.85 : 0.995), !0;
  }
}
const Ta = { showArrows: !1, textOpacity: 1, nodeSize: 1, lineThickness: 1, centerForce: 0.5, repelForce: 9, linkForce: 0.8, colorGroups: [] }, fn = (t) => Math.max(0.08, Math.min(4, t)), or = (t, n) => (4 + Math.min(5, Math.sqrt(t.degree) * 0.7)) * n;
function Cf({ nodes: t, edges: n, selectedId: r, onSelect: a, settings: i, onSettingsChange: l, onRefresh: s, onClose: c, loading: u, error: d }) {
  const [p, h] = k(Ta), [f, m] = k(""), [b, y] = k(!1), [w, v] = k(r || ""), [g, x] = k(""), [N, C] = k(!1), [A, L] = k(""), U = i || p, S = B(null), I = B(new Fu()), T = B({ x: 0, y: 0, zoom: 1 }), H = B({ x: 0, y: 0, zoom: 1 }), R = B({ width: 1, height: 1 }), O = B(!1), M = B(!1), K = B(!0), j = B({ nodes: t, settings: U, active: w, hovered: g, paused: N, query: f, onSelect: a });
  j.current = { nodes: t, settings: U, active: w, hovered: g, paused: N, query: f, onSelect: a };
  const P = () => {
    const W = I.current.nodes;
    if (!W.length) return;
    const G = Math.min(...W.map((F) => F.x)), ue = Math.max(...W.map((F) => F.x)), me = Math.min(...W.map((F) => F.y)), q = Math.max(...W.map((F) => F.y)), { width: V, height: oe } = R.current, _ = fn(Math.min((V - 100) / Math.max(120, ue - G), (oe - 140) / Math.max(120, q - me), 1.5));
    H.current = { x: -(G + ue) / 2 * _, y: -(me + q) / 2 * _, zoom: _ }, K.current = !0;
  }, $ = B(P);
  $.current = P;
  const z = (W) => {
    M.current = !0;
    const G = H.current, ue = fn(G.zoom * W);
    H.current = { x: G.x * ue / G.zoom, y: G.y * ue / G.zoom, zoom: ue }, K.current = !0;
  }, E = (W) => {
    v(W);
    const G = I.current.get(W);
    if (!G) return;
    M.current = !0;
    const ue = Math.max(0.8, H.current.zoom);
    H.current = { x: -G.x * ue, y: -G.y * ue, zoom: ue }, K.current = !0;
  }, D = (W) => {
    const G = { ...U, ...W };
    h(G), l?.(G), I.current.wake(), K.current = !0;
  };
  Y(() => {
    v(r || "");
  }, [r]), Y(() => {
    I.current.reconcile(t.map((W) => W.id), n), K.current = !0, !O.current && t.length && (M.current = !1, $.current()), O.current = t.length > 0;
  }, [t, n]), Y(() => {
    I.current.wake(), K.current = !0;
  }, [U, f, w, g, N]), Y(() => {
    const W = S.current;
    if (!W || typeof CanvasRenderingContext2D > "u") return;
    const G = W.getContext("2d");
    if (!G) {
      L("画布暂时无法显示，请通过搜索打开笔记。");
      return;
    }
    let ue = 0, me = 0, q = 0, V = !0, oe = "sans-serif", _ = { ink: "#202124", muted: "#747981", line: "#d5d8de", surface: "#fff", action: "#7255b4", groups: [] };
    const F = () => {
      const se = getComputedStyle(W), re = (de, ie) => se.getPropertyValue(de).trim() || ie;
      oe = se.fontFamily, _ = { ink: re("--fp-ink", _.ink), muted: re("--fp-muted", _.muted), line: re("--fp-line-strong", _.line), surface: re("--fp-surface", _.surface), action: re("--fp-primary", _.action), groups: [re("--fp-primary", "#7255b4"), re("--fp-success", "#368b75"), re("--fp-warning", "#ae782f"), "#6d91b6", "#b67c96", "#8b94a8"] }, K.current = !0;
    };
    F();
    const Q = new MutationObserver(F);
    Q.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product", "class", "style"] });
    const ve = () => {
      const se = W.getBoundingClientRect(), re = Math.min(window.devicePixelRatio || 1, 2);
      R.current = { width: Math.max(1, se.width), height: Math.max(1, se.height) }, W.width = Math.round(R.current.width * re), W.height = Math.round(R.current.height * re), G.setTransform(re, 0, 0, re, 0, 0), K.current = !0, M.current || $.current();
    }, Me = new ResizeObserver(ve);
    Me.observe(W), ve();
    const Ee = (se) => {
      const re = W.getBoundingClientRect();
      return { x: se.clientX - re.left - R.current.width / 2, y: se.clientY - re.top - R.current.height / 2 };
    }, je = (se) => {
      const re = T.current, de = { x: (se.x - re.x) / re.zoom, y: (se.y - re.y) / re.zoom };
      return I.current.nodes.reduce((ie, De) => {
        const We = Math.hypot(De.x - de.x, De.y - de.y), qe = Math.max(or(De, j.current.settings.nodeSize), 12 / re.zoom);
        return We <= qe && (!ie || We < Math.hypot(ie.x - de.x, ie.y - de.y)) ? De : ie;
      }, void 0);
    }, Fe = /* @__PURE__ */ new Map();
    let $e;
    const Ur = (se) => {
      if (se.button !== 0) return;
      const re = Ee(se);
      if (Fe.set(se.pointerId, re), W.setPointerCapture(se.pointerId), M.current = !0, x(""), Fe.size > 1) {
        $e?.node && I.current.release($e.node), $e = void 0;
        return;
      }
      const de = je(re);
      $e = { id: se.pointerId, node: de?.id, start: re, last: re, moved: !1 }, de && I.current.pin(de.id, de.x, de.y), W.style.cursor = "grabbing";
    }, Hr = (se) => {
      const re = Ee(se), de = Fe.get(se.pointerId);
      if (de && Fe.size === 2) {
        const ie = [...Fe.entries()].find(([Ae]) => Ae !== se.pointerId)[1], De = Math.hypot(de.x - ie.x, de.y - ie.y), We = Math.hypot(re.x - ie.x, re.y - ie.y), qe = T.current, dt = fn(qe.zoom * We / Math.max(1, De)), kt = { x: (de.x + ie.x) / 2, y: (de.y + ie.y) / 2 }, sn = { x: (re.x + ie.x) / 2, y: (re.y + ie.y) / 2 };
        T.current = H.current = { x: sn.x - (kt.x - qe.x) * dt / qe.zoom, y: sn.y - (kt.y - qe.y) * dt / qe.zoom, zoom: dt }, Fe.set(se.pointerId, re), K.current = !0;
        return;
      }
      if (de && Fe.set(se.pointerId, re), $e && $e.id === se.pointerId) {
        if ($e.moved ||= Math.hypot(re.x - $e.start.x, re.y - $e.start.y) > 4, $e.node) {
          const ie = T.current;
          I.current.pin($e.node, (re.x - ie.x) / ie.zoom, (re.y - ie.y) / ie.zoom);
        } else {
          const ie = T.current;
          T.current = H.current = { ...ie, x: ie.x + re.x - $e.last.x, y: ie.y + re.y - $e.last.y };
        }
        $e.last = re, K.current = !0;
      } else if (!Fe.size) {
        const ie = je(re);
        x(ie?.id || ""), W.style.cursor = "grab";
      }
    }, wt = (se) => {
      Fe.delete(se.pointerId), $e?.id === se.pointerId && ($e.node && I.current.release($e.node), !$e.moved && se.type !== "pointercancel" && v($e.node || ""), $e = void 0), W.hasPointerCapture(se.pointerId) && W.releasePointerCapture(se.pointerId), K.current = !0, W.style.cursor = "grab";
    }, _r = () => {
      Fe.size || x("");
    }, Wr = (se) => {
      const re = je(Ee(se));
      re && j.current.onSelect(re.id);
    }, Vr = (se) => {
      se.preventDefault(), M.current = !0;
      const re = Ee(se), de = H.current, ie = fn(de.zoom * Math.exp(-Math.max(-100, Math.min(100, se.deltaY)) * 2e-3));
      H.current = { x: re.x - (re.x - de.x) * ie / de.zoom, y: re.y - (re.y - de.y) * ie / de.zoom, zoom: ie }, K.current = !0;
    };
    W.addEventListener("pointerdown", Ur), W.addEventListener("pointermove", Hr), W.addEventListener("pointerup", wt), W.addEventListener("pointercancel", wt), W.addEventListener("lostpointercapture", wt), W.addEventListener("pointerleave", _r), W.addEventListener("dblclick", Wr), W.addEventListener("wheel", Vr, { passive: !1 });
    const yl = () => {
      const { width: se, height: re } = R.current, de = T.current, { settings: ie, active: De, hovered: We, query: qe, nodes: dt } = j.current;
      G.clearRect(0, 0, se, re);
      const kt = I.current, sn = new Map(dt.map((pe) => [pe.id, pe])), Ae = We || De, Nt = new Set(Ae ? [Ae] : []);
      if (Ae) for (const [pe, ke] of kt.links)
        pe.id === Ae && Nt.add(ke.id), ke.id === Ae && Nt.add(pe.id);
      const vl = new Set(qe.trim() ? dt.filter((pe) => pe.label.toLocaleLowerCase().includes(qe.trim().toLocaleLowerCase())).map((pe) => pe.id) : []), cn = (pe) => ({ x: pe.x * de.zoom + de.x + se / 2, y: pe.y * de.zoom + de.y + re / 2 }), Yn = (pe) => {
        const ke = cn(pe);
        return ke.x > -30 && ke.y > -30 && ke.x < se + 30 && ke.y < re + 30;
      }, wl = (pe) => Ae ? !Nt.has(pe) : qe.trim() ? !vl.has(pe) : !1;
      for (const [pe, ke] of kt.links) {
        if (!Yn(pe) && !Yn(ke)) continue;
        const Ke = cn(pe), Ve = cn(ke), ut = Ae && (pe.id === Ae || ke.id === Ae);
        if (G.globalAlpha = ut ? 0.8 : Ae || qe.trim() ? 0.08 : 0.58, G.strokeStyle = ut ? _.action : _.line, G.lineWidth = ie.lineThickness * (ut ? 1.4 : 0.7), G.beginPath(), G.moveTo(Ke.x, Ke.y), G.lineTo(Ve.x, Ve.y), G.stroke(), ie.showArrows && (ut || de.zoom > 0.7)) {
          const pt = Math.atan2(Ve.y - Ke.y, Ve.x - Ke.x), qt = or(ke, ie.nodeSize) * de.zoom + 3, xt = Ve.x - Math.cos(pt) * qt, lt = Ve.y - Math.sin(pt) * qt;
          G.beginPath(), G.moveTo(xt - Math.cos(pt - 0.5) * 5, lt - Math.sin(pt - 0.5) * 5), G.lineTo(xt, lt), G.lineTo(xt - Math.cos(pt + 0.5) * 5, lt - Math.sin(pt + 0.5) * 5), G.stroke();
        }
      }
      const kl = [...new Set(dt.map((pe) => pe.kind).filter(Boolean))], Nl = [...kt.nodes].sort((pe, ke) => +(ke.id === Ae) - +(pe.id === Ae) || Number(Nt.has(ke.id)) - Number(Nt.has(pe.id)) || ke.degree - pe.degree), Gn = [];
      for (const pe of Nl) {
        if (!Yn(pe)) continue;
        const ke = cn(pe), Ke = sn.get(pe.id), Ve = Math.max(2, or(pe, ie.nodeSize) * de.zoom), ut = wl(pe.id), qt = ie.colorGroups.find((tt) => tt.query.trim() && Ke?.label.includes(tt.query))?.color || (Ke?.kind ? _.groups[Math.max(0, kl.indexOf(Ke.kind)) % _.groups.length] : _.action);
        if (G.globalAlpha = ut ? 0.18 : 1, G.fillStyle = qt, G.beginPath(), G.arc(ke.x, ke.y, Ve, 0, Math.PI * 2), G.fill(), pe.id === Ae && (G.strokeStyle = qt, G.lineWidth = 1.5, G.beginPath(), G.arc(ke.x, ke.y, Ve + 5, 0, Math.PI * 2), G.stroke()), ut || !Ke || !ie.textOpacity || (Ae ? !Nt.has(pe.id) : de.zoom < 0.55 && Gn.length >= 12)) continue;
        const xt = Ke.label.length > 22 ? Ke.label.slice(0, 21) + "…" : Ke.label;
        G.font = `${pe.id === Ae ? 600 : 400} 12px ${oe}`;
        const lt = G.measureText(xt).width + 10, dn = 20, un = ke.x - lt / 2, Kt = ke.y + Ve + 6;
        Gn.some((tt) => un < tt.x + tt.w + 6 && un + lt + 6 > tt.x && Kt < tt.y + tt.h + 3 && Kt + dn + 3 > tt.y) || (Gn.push({ x: un, y: Kt, w: lt, h: dn }), G.globalAlpha = ie.textOpacity * 0.94, G.fillStyle = _.surface, G.fillRect(un, Kt, lt, dn), G.fillStyle = _.ink, G.textBaseline = "middle", G.textAlign = "center", G.fillText(xt, ke.x, Kt + dn / 2));
      }
      G.globalAlpha = 1;
    }, Xr = (se) => {
      if (!V) return;
      const re = Math.min(50, se - me);
      if (me = se, q += re, document.hidden)
        q = 0;
      else {
        let de = !1;
        if (j.current.paused) q = 0;
        else for (; q >= 1e3 / 60; )
          de = I.current.step(j.current.settings) || de, q -= 1e3 / 60;
        !M.current && de && $.current();
        const ie = T.current, De = H.current;
        if (Math.abs(ie.x - De.x) + Math.abs(ie.y - De.y) + Math.abs(ie.zoom - De.zoom) > 0.01) {
          const We = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : 0.2;
          T.current = { x: ie.x + (De.x - ie.x) * We, y: ie.y + (De.y - ie.y) * We, zoom: ie.zoom + (De.zoom - ie.zoom) * We }, de = !0;
        }
        (de || K.current) && (yl(), K.current = !1);
      }
      ue = requestAnimationFrame(Xr);
    };
    return ue = requestAnimationFrame(Xr), () => {
      V = !1, cancelAnimationFrame(ue), Me.disconnect(), Q.disconnect(), W.removeEventListener("pointerdown", Ur), W.removeEventListener("pointermove", Hr), W.removeEventListener("pointerup", wt), W.removeEventListener("pointercancel", wt), W.removeEventListener("lostpointercapture", wt), W.removeEventListener("pointerleave", _r), W.removeEventListener("dblclick", Wr), W.removeEventListener("wheel", Vr);
    };
  }, []);
  const ne = t.filter((W) => W.label.toLocaleLowerCase().includes(f.trim().toLocaleLowerCase())), ae = t.find((W) => W.id === w), ye = new Set(n.flatMap((W) => W.source === w ? [W.target] : W.target === w ? [W.source] : []).filter((W) => W !== w)), he = [...new Set(t.map((W) => W.kind).filter(Boolean))];
  return /* @__PURE__ */ o("section", { className: "fp-graph", "aria-label": "关系图谱", onKeyDown: (W) => {
    W.key === "Escape" && (b ? y(!1) : f ? m("") : w ? v("") : c?.());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-graph-toolbar", children: [
      /* @__PURE__ */ o("div", { className: "fp-graph-heading", children: [
        /* @__PURE__ */ e(Qr, { size: 18 }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: "关系图谱" }),
          /* @__PURE__ */ o("span", { children: [
            t.length,
            " 篇笔记 · ",
            n.length,
            " 条关联"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-graph-search", children: [
        /* @__PURE__ */ e(Je, { size: 16 }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索关联笔记", placeholder: "搜索笔记…", value: f, onChange: (W) => m(W.target.value) }),
        f && /* @__PURE__ */ e("button", { type: "button", "aria-label": "清空搜索", onClick: () => m(""), children: /* @__PURE__ */ e(ge, { size: 14 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-actions", children: [
        /* @__PURE__ */ e("button", { type: "button", title: "适应画布", "aria-label": "适应画布", onClick: () => {
          M.current = !0, P();
        }, children: /* @__PURE__ */ e(On, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": N ? "继续动态布局" : "暂停动态布局", title: N ? "继续动态布局" : "暂停动态布局", onClick: () => {
          C(!N), I.current.wake();
        }, children: N ? /* @__PURE__ */ e(Qt, { size: 17 }) : /* @__PURE__ */ e(Pn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "显示设置", title: "图谱设置", "aria-expanded": b, onClick: () => y(!b), children: /* @__PURE__ */ e(no, { size: 17 }) }),
        c && /* @__PURE__ */ e("button", { type: "button", title: "关闭图谱", "aria-label": "关闭图谱", onClick: c, children: /* @__PURE__ */ e(ge, { size: 19 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-graph-viewport", children: [
      /* @__PURE__ */ e("canvas", { ref: S, className: "fp-graph-canvas", tabIndex: 0, role: "img", "aria-label": "可拖动的笔记关系图；使用搜索选择笔记", onKeyDown: (W) => {
        W.key === "+" || W.key === "=" ? (W.preventDefault(), z(1.2)) : W.key === "-" ? (W.preventDefault(), z(1 / 1.2)) : W.key === "0" ? (W.preventDefault(), P()) : ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(W.key) ? (W.preventDefault(), M.current = !0, H.current = { ...H.current, x: H.current.x + (W.key === "ArrowLeft" ? 40 : W.key === "ArrowRight" ? -40 : 0), y: H.current.y + (W.key === "ArrowUp" ? 40 : W.key === "ArrowDown" ? -40 : 0) }, K.current = !0) : W.key === "Enter" && w && a(w);
      } }),
      u && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "status", children: [
        /* @__PURE__ */ o("div", { className: "fp-graph-skeleton", children: [
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {})
        ] }),
        /* @__PURE__ */ e("p", { children: "正在展开笔记关系…" })
      ] }),
      (d || A) && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: d || A }),
        s && /* @__PURE__ */ e("button", { type: "button", onClick: s, children: "重新加载" })
      ] }),
      !u && !d && !t.length && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", children: [
        /* @__PURE__ */ e(Qr, { size: 32 }),
        /* @__PURE__ */ e("p", { children: "把笔记链接起来，知识会在这里连接成图。" })
      ] }),
      f.trim() && /* @__PURE__ */ o("nav", { className: "fp-graph-results", "aria-label": "选择关联笔记", children: [
        /* @__PURE__ */ e("small", { children: ne.length ? `${ne.length} 篇匹配的笔记` : "没有找到匹配的笔记" }),
        ne.slice(0, 30).map((W) => /* @__PURE__ */ e("button", { type: "button", "aria-pressed": W.id === w, onClick: () => E(W.id), children: W.label }, W.id)),
        ne.length > 30 && /* @__PURE__ */ e("small", { children: "继续输入可缩小范围" })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-graph-options", "data-open": b, inert: !b, "aria-hidden": !b, "aria-label": "图谱设置", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: "图谱设置" }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭设置", onClick: () => y(!1), children: /* @__PURE__ */ e(ge, { size: 16 }) })
        ] }),
        /* @__PURE__ */ e("p", { children: "拖动节点时，周围的笔记会随之调整。" }),
        /* @__PURE__ */ e(Kr, { label: "显示箭头", checked: U.showArrows, onChange: (W) => D({ showArrows: W.target.checked }) }),
        [["repelForce", "节点间距", 1, 20, 1], ["linkForce", "连线牵引", 0.1, 2, 0.1], ["centerForce", "中心吸引", 0, 2, 0.1], ["nodeSize", "节点大小", 0.5, 3, 0.1], ["lineThickness", "连线粗细", 0.5, 3, 0.1], ["textOpacity", "文字清晰度", 0, 1, 0.1]].map(([W, G, ue, me, q]) => /* @__PURE__ */ o("label", { className: "fp-graph-setting", children: [
          /* @__PURE__ */ o("span", { children: [
            G,
            /* @__PURE__ */ e("output", { children: U[W] })
          ] }),
          /* @__PURE__ */ e(pr, { "aria-label": G, min: ue, max: me, step: q, value: U[W], onChange: (V) => D({ [W]: Number(V.target.value) }) })
        ] }, W)),
        he.length > 0 && /* @__PURE__ */ o("div", { className: "fp-graph-group-legend", children: [
          /* @__PURE__ */ e("strong", { children: "笔记分组" }),
          he.map((W, G) => /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", { "data-color": G % 6 }),
            W
          ] }, W))
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-graph-color-groups", children: [
          /* @__PURE__ */ e("strong", { children: "关键词颜色" }),
          U.colorGroups.map((W, G) => /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("input", { className: "fp-pattern-input", "aria-label": `第 ${G + 1} 组关键词`, value: W.query, placeholder: "标题包含", onChange: (ue) => D({ colorGroups: U.colorGroups.map((me, q) => q === G ? { ...me, query: ue.target.value } : me) }) }),
            /* @__PURE__ */ e(fl, { label: `第 ${G + 1} 组颜色`, value: W.color, onChange: (ue) => D({ colorGroups: U.colorGroups.map((me, q) => q === G ? { ...me, color: ue } : me) }) }),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除第 ${G + 1} 组`, onClick: () => D({ colorGroups: U.colorGroups.filter((ue, me) => me !== G) }), children: /* @__PURE__ */ e(ge, { size: 14 }) })
          ] }, G)),
          /* @__PURE__ */ o("button", { type: "button", onClick: () => D({ colorGroups: [...U.colorGroups, { query: "", color: "#7255b4" }] }), children: [
            /* @__PURE__ */ e(gn, { size: 14 }),
            "添加分组"
          ] })
        ] }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => {
          D(Ta), I.current.wake();
        }, children: [
          /* @__PURE__ */ e(rt, { size: 14 }),
          "恢复默认"
        ] }),
        s && /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: s, children: "刷新笔记关系" })
      ] }),
      ae && /* @__PURE__ */ o("div", { className: "fp-graph-inspector", children: [
        /* @__PURE__ */ e("button", { className: "fp-graph-inspector-close", type: "button", "aria-label": "取消选择", onClick: () => v(""), children: /* @__PURE__ */ e(ge, { size: 14 }) }),
        /* @__PURE__ */ o("small", { children: [
          ae.kind || "笔记",
          " · ",
          ye.size,
          " 篇关联"
        ] }),
        /* @__PURE__ */ e("strong", { children: ae.label }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => a(ae.id), children: [
          "打开笔记",
          /* @__PURE__ */ e(Ya, { size: 15 })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-zoom", children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "放大图谱", onClick: () => z(1.2), children: /* @__PURE__ */ e(gn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩小图谱", onClick: () => z(1 / 1.2), children: /* @__PURE__ */ e(Tt, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("p", { className: "fp-graph-hint", children: [
        "拖动节点 · 滚轮缩放 · 双击打开笔记",
        N ? " · 布局已暂停" : ""
      ] })
    ] })
  ] });
}
function Sf({
  title: t,
  children: n,
  tools: r,
  inspector: a,
  source: i,
  onSourceChange: l,
  onRun: s,
  onReset: c,
  onSave: u,
  loading: d,
  error: p
}) {
  const h = B(null), [f, m] = k(!1), [b, y] = k(!1), [w, v] = k("");
  return /* @__PURE__ */ o("section", { ref: h, className: "fp-workbench", "aria-label": t, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r,
        i !== void 0 && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            "aria-pressed": f,
            onClick: () => m((g) => !g),
            children: [
              f ? /* @__PURE__ */ e(Ga, { size: 15 }) : /* @__PURE__ */ e(ro, { size: 15 }),
              " ",
              f ? "查看内容" : "编辑源码"
            ]
          }
        ),
        a && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-expanded": b,
            onClick: () => y((g) => !g),
            children: "参数"
          }
        ),
        c && /* @__PURE__ */ o("button", { type: "button", onClick: c, children: [
          /* @__PURE__ */ e(rt, { size: 15 }),
          "重置"
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "全屏查看",
            onClick: () => {
              if (!h.current?.requestFullscreen) {
                v("当前设备暂不支持全屏。");
                return;
              }
              h.current.requestFullscreen().catch(() => v("暂时无法进入全屏，请重试。"));
            },
            children: /* @__PURE__ */ e(On, { size: 15 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(Oe, { isOpen: b, children: /* @__PURE__ */ e("div", { className: "fp-workbench-inspector", children: a }) }),
    /* @__PURE__ */ e("div", { className: "fp-workbench-stage", "aria-busy": d, children: d ? /* @__PURE__ */ e("p", { role: "status", children: "正在准备内容…" }) : f ? /* @__PURE__ */ o("label", { children: [
      "源码",
      /* @__PURE__ */ e(
        "textarea",
        {
          "aria-label": "内容源码",
          value: i,
          readOnly: !l,
          spellCheck: !1,
          onChange: (g) => l?.(g.target.value)
        }
      )
    ] }) : n }),
    (p || w) && /* @__PURE__ */ e("p", { role: p ? "alert" : "status", children: p || w }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      f && s && /* @__PURE__ */ e(be, { disabled: d, onAction: s, children: "运行" }),
      u && /* @__PURE__ */ e(be, { disabled: d, onAction: u, children: "保存到笔记" })
    ] })
  ] });
}
function Mf({
  chapters: t,
  currentTime: n,
  onSeek: r,
  onAddNote: a
}) {
  const i = [...t].sort((s, c) => s.time - c.time), l = i.filter((s) => s.time <= n).at(-1)?.id;
  return /* @__PURE__ */ o("section", { className: "fp-classroom", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "课堂章节" }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: () => a(n), children: "记录此刻" })
    ] }),
    i.length ? /* @__PURE__ */ e("ol", { children: i.map((s) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": l === s.id ? "step" : void 0,
        onClick: () => r(s.time),
        children: [
          /* @__PURE__ */ o("time", { children: [
            Math.floor(s.time / 60),
            ":",
            String(Math.floor(s.time % 60)).padStart(2, "0")
          ] }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: s.title }),
            s.detail && /* @__PURE__ */ e("small", { children: s.detail })
          ] })
        ]
      }
    ) }, s.id)) }) : /* @__PURE__ */ e("p", { children: "还没有课堂章节，可以在观看时添加笔记。" })
  ] });
}
function Ef({
  title: t,
  children: n,
  collapsed: r,
  onCollapsedChange: a,
  onClose: i
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-lecture-dock", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": !r,
          onClick: () => a(!r),
          children: r ? "展开播放器" : "收起播放器"
        }
      ),
      i && /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭播放器", onClick: i, children: "×" })
    ] }),
    /* @__PURE__ */ e(Oe, { isOpen: !r, children: n })
  ] });
}
function $f({
  items: t,
  onScoreChange: n,
  onComplete: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "答题复盘" }),
    /* @__PURE__ */ o("p", { children: [
      "已得 ",
      t.reduce((a, i) => a + i.awarded, 0),
      " /",
      " ",
      t.reduce((a, i) => a + i.maximum, 0),
      " 分"
    ] }),
    t.map((a) => /* @__PURE__ */ o("div", { className: "fp-scoring-item", children: [
      /* @__PURE__ */ e("strong", { children: a.title }),
      /* @__PURE__ */ o("span", { children: [
        a.awarded,
        " / ",
        a.maximum
      ] }),
      a.detail,
      a.subjective && /* @__PURE__ */ o("label", { children: [
        "自评得分",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": `${a.title}自评得分`,
            type: "range",
            min: 0,
            max: a.maximum,
            step: a.maximum <= 10 ? 0.5 : 1,
            value: Math.max(0, Math.min(a.maximum, a.awarded)),
            onChange: (i) => n(a.id, Number(i.target.value))
          }
        )
      ] })
    ] }, a.id)),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(be, { onAction: r, children: "完成复盘" }) })
  ] });
}
function zf({
  correct: t,
  total: n,
  score: r,
  maximum: a,
  onReview: i,
  onRetry: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "本次练习" }),
    /* @__PURE__ */ o("strong", { className: "fp-summary-value", children: [
      r,
      /* @__PURE__ */ o("small", { children: [
        " / ",
        a,
        " 分"
      ] })
    ] }),
    /* @__PURE__ */ o("p", { children: [
      n,
      " 道题中答对 ",
      t,
      " 道"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "查看解析" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "再练一次" })
    ] })
  ] });
}
function If({
  options: t,
  defaultValue: n,
  ...r
}) {
  const [a, i] = k(
    String(n ?? t[0]?.value ?? "")
  ), l = String(r.value ?? a), s = B(null), c = B(null), [u, d] = k("");
  return /* @__PURE__ */ o("span", { ref: c, className: r.className, children: [
    /* @__PURE__ */ e(
      "select",
      {
        ...r,
        hidden: !0,
        onInvalid: (p) => {
          p.preventDefault(), d(p.currentTarget.validationMessage), c.current?.querySelector("button")?.focus(), r.onInvalid?.(p);
        },
        "aria-hidden": "true",
        tabIndex: -1,
        ref: s,
        value: l,
        onChange: (p) => {
          i(p.target.value), r.onChange?.(p);
        },
        children: t.map((p) => /* @__PURE__ */ e("option", { value: p.value, children: p.label }, p.value))
      }
    ),
    /* @__PURE__ */ e(
      we,
      {
        label: r["aria-label"] || r.title || "选择选项",
        value: l,
        disabled: r.disabled,
        options: t,
        onChange: (p) => {
          i(p), d(""), s.current && (s.current.value = p, s.current.dispatchEvent(
            new Event("change", { bubbles: !0 })
          ));
        }
      }
    ),
    u && /* @__PURE__ */ e("span", { className: "fp-field-error", role: "alert", children: u })
  ] });
}
function Af({
  label: t,
  options: n,
  value: r,
  onChange: a
}) {
  const i = Ne(), [l, s] = k(!1), [c, u] = k(0), d = n.filter(
    (p) => p.toLowerCase().includes(r.toLowerCase())
  );
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: i, children: t }),
    /* @__PURE__ */ o("div", { className: "fp-combobox", children: [
      /* @__PURE__ */ e(
        "input",
        {
          id: i,
          className: "fp-input",
          role: "combobox",
          "aria-expanded": l,
          "aria-controls": i + "-options",
          "aria-autocomplete": "list",
          "aria-activedescendant": l && d.length ? i + "-" + c : void 0,
          value: r,
          onFocus: () => s(!0),
          onBlur: () => s(!1),
          onChange: (p) => {
            a(p.target.value), s(!0), u(0);
          },
          onKeyDown: (p) => {
            if (p.key === "Escape") {
              s(!1);
              return;
            }
            (p.key === "ArrowDown" || p.key === "ArrowUp") && (p.preventDefault(), s(!0), u(
              (h) => (h + (p.key === "ArrowDown" ? 1 : -1) + d.length) % Math.max(d.length, 1)
            )), p.key === "Enter" && l && d[c] && (p.preventDefault(), a(d[c]), s(!1));
          }
        }
      ),
      l && /* @__PURE__ */ o(
        "div",
        {
          id: i + "-options",
          className: "fp-combobox-options",
          role: "listbox",
          "aria-label": t,
          children: [
            d.map((p, h) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": h === c,
                id: i + "-" + h,
                tabIndex: -1,
                onMouseDown: (f) => f.preventDefault(),
                onClick: () => {
                  a(p), s(!1);
                },
                children: p
              },
              p
            )),
            !d.length && /* @__PURE__ */ e("p", { children: "没有匹配的选项" })
          ]
        }
      )
    ] })
  ] });
}
function Lf({
  renderRow: t,
  items: n,
  selectedId: r,
  onSelect: a,
  defaultExpanded: i = [],
  expandedIds: l,
  onExpandedChange: s,
  onToggle: c,
  onPrefetch: u,
  onOpen: d,
  onMiddleClick: p,
  onNodeDragStart: h,
  onNodeDragOver: f,
  onNodeDrop: m,
  namespace: b = "files",
  onRename: y,
  onRemove: w,
  onCreate: v,
  label: g = "文件目录"
}) {
  let [x, N] = k(new Set(i));
  const C = l === void 0 ? x : new Set(l);
  let A = B(null);
  const L = B(null);
  let [U, S] = k(null), I = [];
  function T(K) {
    K.forEach((j) => {
      I.push(j), C.has(j.id) && j.children && T(j.children);
    });
  }
  T(n);
  function H(K) {
    const j = new Set(C);
    j.has(K) ? j.delete(K) : j.add(K), l === void 0 && N(j), s?.([...j]), c?.(K, j.has(K));
  }
  function R(K) {
    S(K), requestAnimationFrame(
      () => A.current?.querySelector(`[data-node="${CSS.escape(K)}"]`)?.focus()
    );
  }
  function O(K, j) {
    let P = I.findIndex(($) => $.id === j.id);
    if ([
      "ArrowDown",
      "ArrowUp",
      "Home",
      "End",
      "ArrowRight",
      "ArrowLeft",
      "Enter",
      " "
    ].includes(K.key) && K.preventDefault(), K.key === "ArrowDown" && R(I[Math.min(I.length - 1, P + 1)].id), K.key === "ArrowUp" && R(I[Math.max(0, P - 1)].id), K.key === "Home" && R(I[0].id), K.key === "End" && R(I[I.length - 1].id), K.key === "ArrowRight" && j.kind === "folder" && (C.has(j.id) ? j.children?.[0] && R(j.children[0].id) : H(j.id)), K.key === "ArrowLeft")
      if (C.has(j.id)) H(j.id);
      else {
        let $ = function(E) {
          for (let D of E) {
            if (D.children?.some((ae) => ae.id === j.id)) return D;
            let ne = D.children && $(D.children);
            if (ne) return ne;
          }
        }, z = $(n);
        z && R(z.id);
      }
    (K.key === "Enter" || K.key === " ") && (j.kind === "folder" ? H(j.id) : (a(j), d?.(j, K)));
  }
  function M(K, j = 0) {
    return K.map((P) => /* @__PURE__ */ e(gt, { tabIndex: -1, label: `${P.name}的操作`, onOpen: ($) => {
      L.current = $;
    }, items: [
      { id: "open", label: P.kind === "folder" ? C.has(P.id) ? "收起文件夹" : "展开文件夹" : "打开", onSelect: () => {
        P.kind === "folder" ? H(P.id) : (a(P), L.current && d?.(P, L.current));
      } },
      ...P.kind === "folder" && v ? [{ id: "create", label: "新建文件", onSelect: () => v(P) }] : [],
      ...y ? [{ id: "rename", label: "重命名", onSelect: () => y(P) }] : [],
      ...w ? [{ id: "remove", label: "移除", danger: !0, separator: !0, onSelect: () => w(P) }] : []
    ], children: /* @__PURE__ */ o("div", { role: "none", children: [
      /* @__PURE__ */ e(Ru, { node: P, renderRow: t, children: /* @__PURE__ */ o(
        "div",
        {
          role: "treeitem",
          "aria-level": j + 1,
          "aria-expanded": P.kind === "folder" ? C.has(P.id) : void 0,
          "aria-selected": r === P.id,
          tabIndex: (I.find(($) => $.id === U)?.id || I.find(($) => $.id === r)?.id || I[0]?.id) === P.id ? 0 : -1,
          "data-node": P.id,
          className: "fp-file-tree-row",
          style: { paddingLeft: 12 + j * 18 },
          onFocus: ($) => {
            $.target === $.currentTarget && (S(P.id), u?.(P));
          },
          onMouseEnter: () => u?.(P),
          draggable: !!h,
          onDragStart: ($) => {
            h?.(P, $);
            const z = document.createElement("div");
            z.className = "fp-file-drag-preview", z.textContent = P.name, document.body.appendChild(z), $.dataTransfer.setDragImage?.(z, 12, 18), setTimeout(() => z.remove(), 0);
          },
          onDragOver: m ? ($) => {
            f?.(P, $), !(f && !$.defaultPrevented) && ($.preventDefault(), $.stopPropagation(), $.currentTarget.dataset.dropTarget = "true");
          } : void 0,
          onDragLeave: ($) => {
            $.currentTarget.contains($.relatedTarget) || delete $.currentTarget.dataset.dropTarget;
          },
          onDragEnd: () => A.current?.querySelectorAll("[data-drop-target]").forEach(($) => delete $.dataset.dropTarget),
          onDrop: m ? ($) => {
            $.preventDefault(), $.stopPropagation(), delete $.currentTarget.dataset.dropTarget, m(P, $);
          } : void 0,
          onAuxClick: ($) => {
            $.button === 1 && P.kind === "file" && p && ($.preventDefault(), p(P, $));
          },
          onKeyDown: ($) => O($, P),
          onClick: ($) => {
            S(P.id), P.kind === "folder" ? H(P.id) : (a(P), d?.(P, $));
          },
          children: [
            P.kind === "folder" ? /* @__PURE__ */ o(Z, { children: [
              /* @__PURE__ */ e(
                Ie,
                {
                  size: 13,
                  className: C.has(P.id) ? "is-expanded" : ""
                }
              ),
              C.has(P.id) ? /* @__PURE__ */ e(Ja, { size: 16 }) : /* @__PURE__ */ e(vn, { size: 16 })
            ] }) : /* @__PURE__ */ o(Z, { children: [
              /* @__PURE__ */ e("span", { style: { width: 13 } }),
              /* @__PURE__ */ e(Ye, { size: 16 })
            ] }),
            /* @__PURE__ */ e("span", { className: "fp-tree-name", title: P.name, children: P.name }),
            (y || w || P.kind === "folder" && v) && /* @__PURE__ */ e(
              "span",
              {
                onClick: ($) => $.stopPropagation(),
                onKeyDown: ($) => $.stopPropagation(),
                className: "fp-tree-actions",
                children: /* @__PURE__ */ e(
                  bi,
                  {
                    label: "操作",
                    icon: /* @__PURE__ */ e(Dt, { size: 16, "aria-hidden": "true" }),
                    items: [
                      ...P.kind === "folder" && v ? [{ label: "新建文件", onClick: () => v(P) }] : [],
                      ...y ? [{ label: "重命名", onClick: () => y(P) }] : [],
                      ...w ? [
                        {
                          label: "移除",
                          danger: !0,
                          onClick: () => w(P)
                        }
                      ] : []
                    ]
                  }
                )
              }
            )
          ]
        }
      ) }),
      P.kind === "folder" && /* @__PURE__ */ e(Oe, { isOpen: C.has(P.id), children: /* @__PURE__ */ e("div", { role: "group", children: M(P.children || [], j + 1) }) })
    ] }) }, `${b}/${P.id}`));
  }
  return /* @__PURE__ */ o("div", { ref: A, className: "fp-file-tree", role: "tree", "aria-label": g, children: [
    M(n),
    !n.length && /* @__PURE__ */ e("p", { children: "还没有文件，添加资料后会显示在这里。" })
  ] });
}
function Ru({ node: t, renderRow: n, children: r }) {
  return /* @__PURE__ */ e(Z, { children: n ? n(t, r) : r });
}
const Tf = El(function({ panels: n, direction: r = "horizontal", persistenceKey: a, onLayout: i, className: l = "" }, s) {
  const c = B(null), u = B(/* @__PURE__ */ new Map());
  return $l(s, () => ({
    getLayout: () => c.current?.getLayout() || [],
    setLayout: (d) => c.current?.setLayout(d),
    collapse: (d) => u.current.get(d)?.collapse(),
    expand: (d) => u.current.get(d)?.expand(),
    resize: (d, p) => u.current.get(d)?.resize(p),
    isCollapsed: (d) => u.current.get(d)?.isCollapsed() || !1
  }), []), /* @__PURE__ */ e(as, { ref: c, direction: r, autoSaveId: a, onLayout: i, className: `fp-workspace-layout ${l}`, children: n.map((d, p) => /* @__PURE__ */ o(Pa, { children: [
    p > 0 && /* @__PURE__ */ e(is, { className: "fp-workspace-divider", "aria-label": `调整${n[p - 1].label}与${d.label}` }),
    /* @__PURE__ */ e(
      ls,
      {
        ref: (h) => {
          h ? u.current.set(d.id, h) : u.current.delete(d.id);
        },
        id: d.id,
        order: p,
        defaultSize: d.defaultSize,
        minSize: d.minSize ?? 10,
        maxSize: d.maxSize,
        collapsible: d.collapsible,
        collapsedSize: d.collapsedSize ?? 0,
        onCollapse: d.onCollapse,
        onExpand: d.onExpand,
        children: /* @__PURE__ */ e("section", { className: "fp-workspace-pane", "aria-label": d.label, children: d.content })
      }
    )
  ] }, d.id)) });
});
function Df({
  url: t,
  room: n,
  token: r,
  user: a,
  enabled: i = !0
}) {
  let [l, s] = k(null), [c, u] = k("connecting");
  return Y(() => {
    if (!i) return;
    let d = new ss.Doc(), p = new os({
      url: t,
      name: n,
      document: d,
      token: r,
      onStatus: ({ status: h }) => u(h),
      onAuthenticationFailed: () => u("unauthorized")
    });
    return p.setAwarenessField("user", a), s({ document: d, provider: p }), () => {
      s(null), p.destroy(), d.destroy();
    };
  }, [t, n, r, i, a.id, a.name, a.color]), { session: l, status: c };
}
function Pf({ user: t, status: n = "local", onChange: r, onMarkdownChange: a, ...i }) {
  const l = n === "local" ? "本地编辑" : n === "connected" ? "已连接" : n === "unauthorized" ? "需要重新登录" : n === "disconnected" ? "等待重新连接" : "正在连接";
  return /* @__PURE__ */ o("section", { className: "fp-collab-editor", children: [
    /* @__PURE__ */ o("header", { className: "fp-collab-presence", children: [
      /* @__PURE__ */ e("span", { style: { color: t.color }, children: "●" }),
      /* @__PURE__ */ e("span", { children: t.name }),
      /* @__PURE__ */ e("span", { children: i.editable === !1 ? "只读" : "可以编辑" }),
      /* @__PURE__ */ e("span", { role: "status", children: l })
    ] }),
    /* @__PURE__ */ e(Xn, { ...i, user: t, onChange: (s, c) => {
      r?.(c), a?.(s);
    } })
  ] });
}
function Of({ messages: t, isLoading: n = !1, error: r, onClearError: a, onFollowUpClick: i, followUpQuestions: l = [], bottomInset: s = 0, renderMessage: c, emptyState: u, hydrated: d = !0, sessionId: p = "default", scrollContainerRef: h, hasOlder: f, loadingOlder: m, onLoadOlder: b, virtualize: y = t.length > 30, estimateSize: w = 100, footer: v, loadingIndicator: g, className: x = "", style: N }) {
  const C = B(null), A = h || C, L = B(null), U = B(!0), [S, I] = k(!1), T = B(/* @__PURE__ */ new Map()), H = B(p), R = B(null), O = B({ first: t[0]?.id, height: 0, top: 0 }), M = pi({ count: t.length, getScrollElement: () => A.current, estimateSize: () => w, getItemKey: (P) => t[P].id, overscan: 5, enabled: y }), K = () => {
    const P = A.current;
    P && (P.scrollTop = P.scrollHeight, U.current = !0, I(!1));
  };
  Ce(() => {
    const P = A.current;
    if (P) {
      if (H.current !== p) {
        const $ = O.current;
        T.current.set(H.current, { top: $.top, pinned: U.current }), H.current = p, R.current = null, O.current = { first: t[0]?.id, height: 0, top: 0 };
      }
      if (d) {
        if (R.current !== p) {
          const $ = T.current.get(p);
          U.current = $?.pinned ?? !0, P.scrollTop = U.current ? P.scrollHeight : $?.top || 0, R.current = p;
        } else O.current.first && t[0]?.id !== O.current.first && !U.current ? P.scrollTop = O.current.top + P.scrollHeight - O.current.height : U.current && (P.scrollTop = P.scrollHeight);
        O.current = { first: t[0]?.id, height: P.scrollHeight, top: P.scrollTop }, I(!U.current);
      }
    }
  }, [t, p, d, s, n]), Ce(() => {
    const P = A.current, $ = L.current;
    if (!P || !$ || typeof ResizeObserver > "u") return;
    let z = 0;
    const E = new ResizeObserver(() => {
      cancelAnimationFrame(z), z = requestAnimationFrame(() => {
        U.current && (P.scrollTop = P.scrollHeight), O.current.height = P.scrollHeight, O.current.top = P.scrollTop;
      });
    });
    return E.observe($), E.observe(P), () => {
      E.disconnect(), cancelAnimationFrame(z);
    };
  }, [A]);
  const j = (P) => c ? c(P) : /* @__PURE__ */ e(Bu, { message: P });
  return /* @__PURE__ */ o("div", { className: `fp-message-list-container ${x}`, style: N, children: [
    /* @__PURE__ */ e(
      "div",
      {
        ref: A,
        className: "fp-message-list",
        role: "region",
        "aria-label": "对话记录",
        tabIndex: 0,
        onScroll: () => {
          const P = A.current;
          U.current = P.scrollHeight - P.scrollTop - P.clientHeight < 48, I(!U.current), O.current.top = P.scrollTop, O.current.height = P.scrollHeight, T.current.set(p, { top: P.scrollTop, pinned: U.current });
        },
        children: /* @__PURE__ */ o("div", { ref: L, className: "fp-message-list-content", style: { paddingBottom: Math.max(0, Number.isFinite(s) ? s : 0), overflowAnchor: "none" }, children: [
          f && /* @__PURE__ */ e("button", { type: "button", className: "fp-history-load", disabled: m, onClick: b, children: m ? "正在加载…" : "加载更早的消息" }),
          d ? t.length === 0 ? u : y ? /* @__PURE__ */ e("div", { style: { height: M.getTotalSize(), position: "relative" }, children: M.getVirtualItems().map((P) => /* @__PURE__ */ e("div", { "data-index": P.index, ref: M.measureElement, style: { position: "absolute", top: 0, left: 0, width: "100%", transform: `translateY(${P.start}px)` }, children: /* @__PURE__ */ e("div", { className: "fp-message-row", children: j(t[P.index]) }) }, P.key)) }) : t.map((P) => /* @__PURE__ */ e("div", { className: "fp-message-row", children: j(P) }, P.id)) : /* @__PURE__ */ e("p", { role: "status", children: "正在打开对话…" }),
          n && (g === void 0 ? /* @__PURE__ */ e("div", { className: "fp-message-loading", role: "status", children: "正在回复…" }) : g),
          v,
          l.length > 0 && /* @__PURE__ */ e("div", { className: "fp-follow-ups", "aria-label": "继续提问", children: l.map((P) => /* @__PURE__ */ e("button", { type: "button", onClick: () => i?.(P), children: P }, P)) })
        ] })
      }
    ),
    S && /* @__PURE__ */ o("button", { type: "button", className: "fp-message-latest", onClick: K, children: [
      /* @__PURE__ */ e(Ua, { size: 14, "aria-hidden": "true" }),
      "回到最新"
    ] }),
    r && /* @__PURE__ */ o("div", { className: "fp-message-error", role: "alert", children: [
      /* @__PURE__ */ e("span", { children: r }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "关闭" })
    ] })
  ] });
}
function Bu({ message: t }) {
  return /* @__PURE__ */ o("div", { className: `fp-message-bubble fp-message-${t.role}`, "data-role": t.role, children: [
    /* @__PURE__ */ e("div", { className: "fp-message-content", children: t.content }),
    t.timestamp && /* @__PURE__ */ e("time", { className: "fp-message-time", dateTime: t.timestamp.toISOString(), children: t.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) })
  ] });
}
function Ff({
  inputProps: t,
  sendIcon: n,
  stopIcon: r,
  attachmentIcon: a,
  inputRef: i,
  value: l,
  onChange: s,
  onSend: c,
  onStop: u,
  isLoading: d,
  disabled: p,
  disabledReason: h,
  placeholder: f = "输入问题，或添加资料…",
  quotedText: m,
  onClearQuote: b,
  attachments: y = [],
  onRemoveAttachment: w,
  onFiles: v,
  accept: g,
  tools: x,
  footer: N,
  compact: C = !1,
  notice: A,
  onComposerInsetChange: L,
  sendOnEnter: U = !0
}) {
  const S = B(null), I = B(null), T = B(null), H = B(!1), R = B(!1), [O, M] = k(!1), [K, j] = k(""), $ = !p && !(d || O) && !y.some(
    (E) => E.status === "uploading" || E.status === "error"
  ) && (!!l.trim() || y.length > 0);
  Ce(() => {
    const E = I.current;
    if (!E) return;
    const D = E.cloneNode(!1);
    D.removeAttribute("id"), D.removeAttribute("aria-label"), D.setAttribute("aria-hidden", "true"), D.tabIndex = -1, D.value = l, Object.assign(D.style, {
      position: "absolute",
      visibility: "hidden",
      pointerEvents: "none",
      height: "0px",
      minHeight: "0px",
      width: `${E.getBoundingClientRect().width}px`,
      transition: "none"
    }), E.parentElement?.append(D);
    const ne = Math.min(200, Math.max(48, D.scrollHeight));
    D.remove(), E.style.height = `${ne}px`;
  }, [l]), Ce(() => {
    if (!S.current || !L) return;
    const E = () => L(S.current?.getBoundingClientRect().height || 0);
    E();
    const D = typeof ResizeObserver > "u" ? null : new ResizeObserver(E);
    return D?.observe(S.current), () => {
      D?.disconnect(), L(0);
    };
  }, [L]);
  async function z() {
    if (!(!$ || R.current)) {
      R.current = !0, M(!0), j("");
      try {
        await c(l.trim());
      } catch (E) {
        j(E instanceof Error ? E.message : "发送失败，请重试");
      } finally {
        R.current = !1, M(!1);
      }
    }
  }
  return /* @__PURE__ */ o("div", { ref: S, className: "fp-chat-composer-wrap", children: [
    A,
    /* @__PURE__ */ o(
      "div",
      {
        className: `fp-chat-composer${C ? " fp-composer-compact" : ""}`,
        "data-disabled": p || void 0,
        onDragOver: (E) => {
          v && !p && E.preventDefault();
        },
        onDrop: (E) => {
          v && !p && E.dataTransfer.files.length && (E.preventDefault(), v(Array.from(E.dataTransfer.files)));
        },
        children: [
          m && /* @__PURE__ */ o("div", { className: "fp-composer-quote", children: [
            /* @__PURE__ */ e(Ha, { size: 14, "aria-hidden": "true" }),
            /* @__PURE__ */ e("span", { children: m }),
            b && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "移除引用",
                onClick: b,
                children: /* @__PURE__ */ e(ge, { size: 14 })
              }
            )
          ] }),
          y.length > 0 && /* @__PURE__ */ e("ul", { className: "fp-composer-attachments", "aria-label": "已添加的附件", children: y.map((E) => /* @__PURE__ */ o("li", { "data-status": E.status, children: [
            E.previewUrl ? /* @__PURE__ */ e("img", { src: E.previewUrl, alt: "" }) : E.status === "uploading" ? /* @__PURE__ */ e(Pt, { size: 16, className: "fp-spin" }) : /* @__PURE__ */ e(Ye, { size: 16 }),
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e("span", { children: E.name }),
              E.status === "uploading" && /* @__PURE__ */ e("small", { children: "正在上传" }),
              E.status === "error" && /* @__PURE__ */ e("small", { role: "alert", children: E.error || "上传失败，请重新添加" })
            ] }),
            w && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": `移除${E.name}`,
                onClick: () => w(E.id),
                children: /* @__PURE__ */ e(ge, { size: 14 })
              }
            )
          ] }, E.id)) }),
          /* @__PURE__ */ e(
            "textarea",
            {
              ...t,
              ref: (E) => {
                I.current = E, typeof i == "function" ? i(E) : i && (i.current = E);
              },
              value: l,
              disabled: p,
              "aria-label": "消息",
              placeholder: h || f,
              rows: 2,
              onChange: (E) => s(E.target.value),
              onCompositionStart: () => {
                H.current = !0;
              },
              onCompositionEnd: () => {
                H.current = !1;
              },
              onPaste: (E) => {
                if (t?.onPaste?.(E), E.defaultPrevented) return;
                const D = Array.from(E.clipboardData?.files || []);
                D.length && v && !p && (E.preventDefault(), v(D));
              },
              onKeyDown: (E) => {
                E.key === "Enter" && !E.shiftKey && !H.current && !E.nativeEvent.isComposing && E.keyCode !== 229 && (U || E.ctrlKey || E.metaKey) && (E.preventDefault(), z());
              }
            }
          ),
          /* @__PURE__ */ o("div", { className: "fp-composer-actions", children: [
            /* @__PURE__ */ o("div", { className: "fp-composer-tools", children: [
              v && /* @__PURE__ */ o(Z, { children: [
                /* @__PURE__ */ e(
                  "input",
                  {
                    ref: T,
                    type: "file",
                    multiple: !0,
                    accept: g,
                    hidden: !0,
                    onChange: (E) => {
                      const D = Array.from(E.target.files || []);
                      D.length && v(D), E.target.value = "";
                    }
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-composer-icon",
                    "aria-label": "添加附件",
                    "data-fp-tooltip": "添加附件",
                    disabled: p,
                    onClick: () => T.current?.click(),
                    children: a || /* @__PURE__ */ e(cr, { size: 17 })
                  }
                )
              ] }),
              x
            ] }),
            C && N && /* @__PURE__ */ e("div", { className: "fp-composer-inline-footer", children: N }),
            d && u ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "停止回复",
                "data-fp-tooltip": "停止回复",
                onClick: u,
                children: r || /* @__PURE__ */ e(qn, { size: 14, fill: "currentColor" })
              }
            ) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "发送消息",
                "data-fp-tooltip": "发送消息 · Enter",
                disabled: !$,
                onClick: () => {
                  z();
                },
                children: O ? /* @__PURE__ */ e(Pt, { size: 16, className: "fp-spin" }) : n || /* @__PURE__ */ e($r, { size: 18 })
              }
            )
          ] }),
          !C && N && /* @__PURE__ */ e("div", { className: "fp-composer-footer", children: N })
        ]
      }
    ),
    (K || h) && /* @__PURE__ */ e(
      "p",
      {
        className: K ? "fp-error-text" : "fp-composer-hint",
        role: K ? "alert" : void 0,
        children: K || h
      }
    )
  ] });
}
function ju({ members: t, roles: n, canManage: r = !1, busyIds: a = [], onRoleChange: i, onRemove: l, onInvite: s, defaultInviteRole: c, error: u }) {
  const [d, p] = k(""), [h, f] = k(c || n[0]?.value || ""), [m, b] = k(!1), [y, w] = k(""), [v, g] = k(""), x = B(!1), N = Ne();
  return /* @__PURE__ */ o("section", { className: "fp-member-access", "aria-label": "成员与访问权限", children: [
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("ul", { className: "fp-access-members", children: t.map((C) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-access-avatar", "aria-hidden": "true", children: C.name.slice(0, 1) }),
      /* @__PURE__ */ o("span", { className: "fp-access-identity", children: [
        /* @__PURE__ */ e("strong", { children: C.name }),
        C.detail && /* @__PURE__ */ e("small", { children: C.detail })
      ] }),
      r && C.editable !== !1 && i ? /* @__PURE__ */ e(we, { label: `${C.name}的权限`, value: C.role, disabled: a.includes(C.id), onChange: (A) => i(C.id, A), options: n }) : /* @__PURE__ */ e("span", { className: "fp-access-role", children: n.find((A) => A.value === C.role)?.label || C.role }),
      r && C.editable !== !1 && l && /* @__PURE__ */ e("button", { type: "button", className: "fp-access-remove", "aria-label": `移除${C.name}`, disabled: a.includes(C.id), onClick: () => l(C.id), children: /* @__PURE__ */ e(ge, { size: 15 }) })
    ] }, C.id)) }) }),
    !t.length && /* @__PURE__ */ e("p", { className: "fp-access-help", children: "还没有其他成员。" }),
    r && s && /* @__PURE__ */ o("form", { className: "fp-access-invite", onSubmit: async (C) => {
      if (C.preventDefault(), !(x.current || !d.trim() || !h)) {
        x.current = !0, b(!0), w(""), g("");
        try {
          await s(d.trim(), h), p(""), w("邀请已发送");
        } catch (A) {
          g(A instanceof Error ? A.message : "邀请未能发送，请重试");
        } finally {
          x.current = !1, b(!1);
        }
      }
    }, children: [
      /* @__PURE__ */ e("label", { htmlFor: N, children: "邀请成员" }),
      /* @__PURE__ */ o("div", { className: "fp-access-invite-fields", children: [
        /* @__PURE__ */ e("input", { id: N, type: "email", required: !0, placeholder: "输入邮箱地址", value: d, disabled: m, onChange: (C) => p(C.target.value) }),
        /* @__PURE__ */ e(we, { label: "邀请权限", value: h, disabled: m, onChange: f, options: n }),
        /* @__PURE__ */ o("button", { type: "submit", disabled: m || !d.trim() || !h, children: [
          /* @__PURE__ */ e(ao, { size: 15, "aria-hidden": "true" }),
          m ? "正在邀请…" : "邀请"
        ] })
      ] }),
      n.find((C) => C.value === h)?.description && /* @__PURE__ */ e("p", { className: "fp-access-help", children: n.find((C) => C.value === h)?.description }),
      y && /* @__PURE__ */ e("p", { className: "fp-access-help", role: "status", children: y })
    ] }),
    (u || v) && /* @__PURE__ */ e("p", { className: "fp-error-text", role: "alert", children: u || v })
  ] });
}
function qu({ onSearch: t, onPick: n, disabled: r, excludedIds: a = [], debounceMs: i = 250, onQueryChange: l }) {
  const [s, c] = k("user"), [u, d] = k(""), [p, h] = k([]), [f, m] = k(!1), [b, y] = k(0), [w, v] = k("idle"), [g, x] = k(""), N = B(null), C = B(null), A = B(null), L = B(t);
  L.current = t;
  const U = Kn(), S = jt(C, f), I = Ne(), [T, H] = k({ left: 8, top: 8, width: 300, maxHeight: 280 }), R = p.filter((M) => !a.includes(M.id));
  Y(() => {
    f && A.current?.querySelector(`[id="${I}-${b}"]`)?.scrollIntoView?.({ block: "nearest" });
  }, [b, f, I]), Y(() => {
    const M = new AbortController();
    if (h([]), y(0), x(""), !u.trim() || r) {
      v("idle");
      return;
    }
    v("loading");
    const K = setTimeout(async () => {
      try {
        const j = await L.current(u.trim(), s, M.signal);
        M.signal.aborted || (h(j), v("ready"));
      } catch {
        M.signal.aborted || (x("暂时无法查找成员，请重试"), v("error"));
      }
    }, i);
    return () => {
      clearTimeout(K), M.abort();
    };
  }, [u, s, r, i]), Ce(() => {
    if (!f) return;
    const M = () => {
      const j = C.current?.getBoundingClientRect();
      if (!j) return;
      const P = window.innerHeight - j.bottom - 16, $ = Math.min(280, Math.max(100, P < 160 ? j.top - 16 : P));
      H({ left: Math.max(8, Math.min(j.left, window.innerWidth - j.width - 8)), top: P < 160 ? Math.max(8, j.top - $ - 6) : j.bottom + 6, width: Math.min(j.width, window.innerWidth - 16), maxHeight: $ });
    }, K = (j) => {
      const P = j.target;
      !N.current?.contains(P) && !A.current?.contains(P) && m(!1);
    };
    return M(), document.addEventListener("pointerdown", K, !0), document.addEventListener("focusin", K, !0), window.addEventListener("resize", M), window.addEventListener("scroll", M, !0), () => {
      document.removeEventListener("pointerdown", K, !0), document.removeEventListener("focusin", K, !0), window.removeEventListener("resize", M), window.removeEventListener("scroll", M, !0);
    };
  }, [f]);
  const O = (M) => {
    M.disabled || (n(M, s), d(""), m(!1), C.current?.focus());
  };
  return /* @__PURE__ */ o("div", { className: "fp-member-search", ref: N, children: [
    /* @__PURE__ */ e("div", { className: "fp-member-search-kind", "aria-label": "搜索范围", children: ["user", "group"].map((M) => /* @__PURE__ */ o("button", { type: "button", disabled: r, "aria-pressed": s === M, onClick: () => {
      l?.("", M), c(M), d(""), m(!1), C.current?.focus();
    }, children: [
      s === M && /* @__PURE__ */ e(Un.span, { className: "fp-choice-highlight", layoutId: `${I}-kind`, transition: { duration: U ? 0 : 0.18, ease: [0.2, 0, 0, 1] }, "aria-hidden": "true" }),
      M === "user" ? /* @__PURE__ */ e(io, { size: 14 }) : /* @__PURE__ */ e(dr, { size: 14 }),
      /* @__PURE__ */ e("span", { children: M === "user" ? "用户" : "用户组" })
    ] }, M)) }),
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(Je, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { ref: C, role: "combobox", "aria-label": "搜索成员", "aria-autocomplete": "list", "aria-expanded": f && !!u.trim(), "aria-controls": f && u.trim() ? I : void 0, "aria-activedescendant": f && R[b] ? `${I}-${b}` : void 0, disabled: r, placeholder: s === "user" ? "搜索姓名、账号或邮箱" : "搜索用户组名称", value: u, onFocus: () => m(!0), onChange: (M) => {
        l?.(M.target.value, s), d(M.target.value), m(!0);
      }, onKeyDown: (M) => {
        if (!M.nativeEvent.isComposing && (M.key === "Escape" && (M.preventDefault(), M.stopPropagation(), m(!1)), (M.key === "ArrowDown" || M.key === "ArrowUp") && (M.preventDefault(), m(!0), y((K) => {
          const j = M.key === "ArrowDown" ? 1 : -1;
          let P = K + j;
          for (; P >= 0 && P < R.length && R[P].disabled; ) P += j;
          return P >= 0 && P < R.length ? P : K;
        })), M.key === "Enter" && f)) {
          M.preventDefault();
          const K = R[b];
          K && O(K);
        }
      } }),
      w === "loading" && /* @__PURE__ */ e(Pt, { size: 15, className: "fp-spin", "aria-hidden": "true" })
    ] }),
    f && !r && u.trim() && Te(/* @__PURE__ */ o("div", { ref: A, "data-fp-overlay": "", className: "fp-member-results fp-popup-panel", id: I, role: "listbox", "aria-label": "匹配成员", style: { ...S, position: "fixed", ...T, overflowY: "auto" }, children: [
      w === "loading" && /* @__PURE__ */ e("p", { role: "status", children: "正在查找…" }),
      w === "error" && /* @__PURE__ */ e("p", { role: "alert", children: g }),
      w === "ready" && !R.length && /* @__PURE__ */ e("p", { role: "status", children: "没有可添加的匹配成员" }),
      R.map((M, K) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": K === b, id: `${I}-${K}`, disabled: M.disabled, onMouseEnter: () => y(K), onMouseDown: (j) => j.preventDefault(), onClick: () => O(M), children: [
        /* @__PURE__ */ e("span", { className: "fp-member-result-avatar", "aria-hidden": "true", children: M.avatarUrl ? /* @__PURE__ */ e("img", { src: M.avatarUrl, alt: "" }) : M.name.slice(0, 1) }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: M.name }),
          M.detail && /* @__PURE__ */ e("small", { children: M.detail })
        ] }),
        /* @__PURE__ */ e("span", { className: "fp-member-result-action", children: "添加" })
      ] }, M.id))
    ] }), C.current?.closest("[data-fp-overlay],[role=dialog],dialog") || document.body)
  ] });
}
function Ku({ url: t, enabled: n, onEnabledChange: r, access: a, onAccessChange: i, options: l = [{ value: "read", label: "可以阅读" }, { value: "edit", label: "可以编辑" }], disabled: s, onCopy: c }) {
  const [u, d] = k(!1), [p, h] = k(!1), [f, m] = k(""), b = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-link", "aria-label": "链接分享", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e(ft, { size: 17 }),
        /* @__PURE__ */ e("strong", { children: "链接分享" })
      ] }),
      /* @__PURE__ */ e("button", { type: "button", role: "switch", "aria-checked": n, "aria-label": "开启链接分享", disabled: s || u, onClick: async () => {
        if (!b.current) {
          b.current = !0, d(!0), m("");
          try {
            await r(!n);
          } catch {
            m("分享设置未能保存，请重试");
          } finally {
            b.current = !1, d(!1);
          }
        }
      }, children: /* @__PURE__ */ e("span", { className: `fp-switch ${n ? "is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) }) })
    ] }),
    /* @__PURE__ */ e("p", { children: n ? "拥有链接的人可以按以下权限访问。" : "开启后可通过链接邀请他人访问。" }),
    /* @__PURE__ */ e(Oe, { isOpen: n, children: /* @__PURE__ */ o("div", { className: "fp-share-link-controls", children: [
      /* @__PURE__ */ e(we, { label: "链接访问权限", value: a, onChange: i, options: l, disabled: s || u }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary fp-sm", disabled: s || !t, onClick: async () => {
        if (t)
          try {
            c ? await c(t) : await navigator.clipboard.writeText(t), h(!0), m("");
          } catch {
            m("未能复制链接，请重试");
          }
      }, children: [
        p ? /* @__PURE__ */ e(Re, { size: 14 }) : /* @__PURE__ */ e(jn, { size: 14 }),
        "复制链接"
      ] })
    ] }) }),
    p && /* @__PURE__ */ e("span", { role: "status", className: "fp-sr-only", children: "链接已复制" }),
    f && /* @__PURE__ */ e("p", { role: "alert", children: f })
  ] });
}
function Rf({ items: t, selectedIds: n, onChange: r, onConfirm: a, loading: i, error: l, onSearch: s, onLoadMore: c, hasMore: u }) {
  const [d, p] = k(""), [h, f] = k(!1), [m, b] = k(""), y = B(!1), w = s ? t : t.filter((v) => v.name.toLowerCase().includes(d.trim().toLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-attachment-picker", "aria-label": "选择资料", children: [
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(Je, { size: 16 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索资料", placeholder: "搜索资料名称", value: d, onChange: (v) => {
        p(v.target.value), s?.(v.target.value);
      } })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-attachment-picker-list", "aria-busy": i, children: [
      w.map((v) => /* @__PURE__ */ o("button", { type: "button", role: "checkbox", "aria-checked": n.includes(v.id), disabled: v.disabled || h, onClick: () => r(n.includes(v.id) ? n.filter((g) => g !== v.id) : [...n, v.id]), children: [
        /* @__PURE__ */ e("span", { className: "fp-picker-check", children: n.includes(v.id) && /* @__PURE__ */ e(Re, { size: 13 }) }),
        /* @__PURE__ */ e(Ye, { size: 18 }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: v.name }),
          v.detail && /* @__PURE__ */ e("small", { children: v.detail })
        ] })
      ] }, v.id)),
      i && /* @__PURE__ */ e("p", { role: "status", children: "正在查找资料…" }),
      !i && !w.length && /* @__PURE__ */ e("p", { children: "没有匹配的资料" }),
      u && c && /* @__PURE__ */ e("button", { type: "button", className: "fp-picker-load", disabled: i || h, onClick: c, children: "加载更多" })
    ] }),
    (l || m) && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: l || m }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ o("span", { children: [
        "已选择 ",
        n.length,
        " 项资料"
      ] }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-primary fp-sm", disabled: h || !n.length, onClick: async () => {
        if (!y.current) {
          y.current = !0, f(!0), b("");
          try {
            await a(n);
          } catch {
            b("未能添加资料，请重试");
          } finally {
            y.current = !1, f(!1);
          }
        }
      }, children: h ? "正在添加…" : "添加资料" })
    ] })
  ] });
}
function Bf({ tasks: t, onCancel: n, onRetry: r, onDismiss: a }) {
  return /* @__PURE__ */ e("section", { className: "fp-upload-queue", "aria-label": "上传资料", children: t.length ? /* @__PURE__ */ e("ul", { children: t.map((i) => /* @__PURE__ */ o("li", { "data-status": i.status, children: [
    /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: i.status === "done" ? /* @__PURE__ */ e(Re, { size: 17 }) : /* @__PURE__ */ e(Ye, { size: 17 }) }),
    /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
      /* @__PURE__ */ e("strong", { children: i.name }),
      /* @__PURE__ */ e("span", { children: i.status === "error" ? i.error || "上传失败，请重试" : i.status === "done" ? "已添加" : i.status === "processing" ? "正在整理资料" : i.status === "waiting" ? "等待上传" : `正在上传 ${Math.round(Math.max(0, Math.min(100, i.progress || 0)))}%` }),
      i.status === "uploading" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${i.name}上传进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(Math.max(0, Math.min(100, i.progress || 0))), className: "fp-upload-progress", children: /* @__PURE__ */ e("i", { style: { width: `${Math.max(0, Math.min(100, i.progress || 0))}%` } }) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
      i.status === "error" && r && /* @__PURE__ */ e("button", { type: "button", "aria-label": `重试${i.name}`, onClick: () => r(i.id), children: /* @__PURE__ */ e(Qa, { size: 15 }) }),
      ["waiting", "uploading", "processing"].includes(i.status) && n && /* @__PURE__ */ e("button", { type: "button", "aria-label": `取消上传${i.name}`, onClick: () => n(i.id), children: /* @__PURE__ */ e(ge, { size: 15 }) }),
      ["done", "error"].includes(i.status) && a && /* @__PURE__ */ e("button", { type: "button", "aria-label": `移除记录${i.name}`, onClick: () => a(i.id), children: /* @__PURE__ */ e(ge, { size: 15 }) })
    ] })
  ] }, i.id)) }) : /* @__PURE__ */ e("p", { className: "fp-muted", children: "还没有上传任务" }) });
}
function jf({ editor: t, toolbar: n, children: r, className: a = "", contextMenu: i = !0 }) {
  const l = /* @__PURE__ */ e(ii, { editor: t });
  return /* @__PURE__ */ o("section", { className: `fp-markdown-editor fp-markdown-editor-surface ${a}`, "data-readonly": t && !t.isEditable || void 0, children: [
    n,
    i ? /* @__PURE__ */ e(Hi, { editor: t, children: l }) : l,
    r
  ] });
}
function qf({ className: t = "", ...n }) {
  return /* @__PURE__ */ e("div", { ...n, className: `fp-conversation-viewport ${t}` });
}
const Uu = {
  pending: /* @__PURE__ */ e(Za, { size: 14 }),
  running: /* @__PURE__ */ e(oo, { size: 14, className: "fp-spin" }),
  done: /* @__PURE__ */ e(Re, { size: 14 }),
  error: /* @__PURE__ */ e(lo, { size: 14 })
};
function Kf({
  steps: t,
  streaming: n = !1,
  durationMs: r,
  defaultOpen: a = !0,
  title: i = "思考过程"
}) {
  const [l, s] = k(a || n), c = t.filter((d) => d.status === "done").length, u = t.some((d) => d.status === "error");
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-trace",
      "data-streaming": n || void 0,
      "aria-label": i,
      children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-trace-head",
            "aria-expanded": l,
            onClick: () => s((d) => !d),
            children: [
              /* @__PURE__ */ e(Ie, { size: 15, className: "fp-trace-chevron" }),
              /* @__PURE__ */ e("strong", { children: i }),
              /* @__PURE__ */ o("span", { className: "fp-trace-summary", children: [
                u ? "有步骤失败" : n ? "进行中" : `${c} / ${t.length} 步`,
                r ? ` · ${(r / 1e3).toFixed(1)}s` : ""
              ] })
            ]
          }
        ),
        /* @__PURE__ */ e("div", { className: "fp-trace-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("ol", { className: "fp-trace-steps", children: t.map((d) => /* @__PURE__ */ o("li", { "data-status": d.status, children: [
          /* @__PURE__ */ e("span", { className: "fp-trace-icon", "aria-hidden": "true", children: Uu[d.status] }),
          /* @__PURE__ */ o("div", { className: "fp-trace-content", children: [
            /* @__PURE__ */ o("div", { className: "fp-trace-title", children: [
              d.title,
              d.meta && /* @__PURE__ */ e("span", { className: "fp-trace-meta", children: d.meta })
            ] }),
            d.detail && /* @__PURE__ */ e("p", { className: "fp-trace-detail fp-trace-commentary", children: d.detail })
          ] })
        ] }, d.id)) }) })
      ]
    }
  );
}
const Hu = {
  excerpt: ["摘录 · 原文", "回顾 · 要点"],
  cloze: ["填空 · 回忆内容", "答案"],
  quiz: ["题目 · 先思考", "参考答案"],
  custom: ["正面", "背面"],
  qa: ["问题", "答案"]
};
function Uf({
  kind: t = "qa",
  front: n,
  back: r,
  flipped: a,
  onFlip: i,
  explanation: l,
  className: s
}) {
  const c = Ne(), [u, d] = Hu[t];
  return /* @__PURE__ */ o("div", { className: `fp-flip ${s || ""}`, "data-flipped": a || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-flip-stage",
        onClick: i,
        "aria-pressed": a,
        "aria-describedby": c,
        "aria-label": a ? "翻回正面" : "翻开背面",
        children: [
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-front", "aria-hidden": a, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: u }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: n }),
            /* @__PURE__ */ e("span", { className: "fp-flip-hint", children: "点击翻面" })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-back", "aria-hidden": !a, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: d }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: r }),
            l && /* @__PURE__ */ e("p", { className: "fp-flip-explanation", children: l })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ o("span", { id: c, className: "fp-sr-only", children: [
      "按下空格或回车翻面，当前显示",
      a ? d : u,
      "。"
    ] })
  ] });
}
function Hf({
  anchor: t,
  actions: n,
  onClose: r,
  preview: a
}) {
  const i = B(null), [l, s] = k(null);
  return Ce(() => {
    if (!t || !i.current) {
      s(null);
      return;
    }
    const c = i.current.getBoundingClientRect(), u = Math.max(
      8,
      Math.min(t.x - c.width / 2, window.innerWidth - c.width - 8)
    ), d = t.y - c.height - 8, p = d > 8 ? d : t.y + 12;
    s({ left: u, top: p });
  }, [t]), Y(() => {
    if (!t) return;
    const c = (d) => {
      d.key === "Escape" && r();
    }, u = (d) => {
      i.current?.contains(d.target) || r();
    };
    return document.addEventListener("keydown", c), document.addEventListener("pointerdown", u, !0), () => {
      document.removeEventListener("keydown", c), document.removeEventListener("pointerdown", u, !0);
    };
  }, [t, r]), !t || typeof window > "u" ? null : Te(
    /* @__PURE__ */ o(
      "div",
      {
        ref: i,
        className: "fp-selection-toolbar",
        role: "toolbar",
        "aria-label": "选区操作",
        style: {
          left: l?.left ?? t.x,
          top: l?.top ?? t.y - 44,
          visibility: l ? "visible" : "hidden"
        },
        children: [
          a && /* @__PURE__ */ o("span", { className: "fp-selection-preview", title: a, children: [
            a.slice(0, 24),
            a.length > 24 ? "…" : ""
          ] }),
          n.map((c) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "fp-selection-action",
              "data-danger": c.danger || void 0,
              onClick: () => {
                c.onClick(), r();
              },
              children: [
                c.icon,
                c.label
              ]
            },
            c.id
          ))
        ]
      }
    ),
    document.body
  );
}
function _f({
  list: t,
  sync: n,
  resolve: r,
  intervalMs: a = 3e4,
  eventName: i = "fp-sync-change"
}) {
  const [l, s] = k([]), [c, u] = k(""), [d, p] = k(!1), h = xe(() => {
    t().then((b) => {
      s(b), u("");
    }).catch(() => u("暂时无法同步，内容仍保存在此设备"));
  }, [t]), f = xe(() => {
    n().then(h).catch(() => u("暂时无法同步，稍后将重试"));
  }, [n, h]);
  if (Y(() => {
    h(), f();
    const b = () => h(), y = () => f();
    window.addEventListener(i, b), window.addEventListener("online", y);
    const w = a > 0 ? setInterval(f, a) : void 0;
    return () => {
      w && clearInterval(w), window.removeEventListener(i, b), window.removeEventListener("online", y);
    };
  }, [h, f, a, i]), Y(() => {
    p(!1);
  }, [l.length]), !l.length || d) return null;
  const m = l.some((b) => b.conflict);
  return /* @__PURE__ */ o(
    "aside",
    {
      className: "fp-sync-status",
      "data-conflict": m || void 0,
      role: "status",
      "aria-live": "polite",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-sync-icon", "aria-hidden": "true", children: m ? /* @__PURE__ */ e(so, { size: 16 }) : /* @__PURE__ */ e(co, { size: 16 }) }),
        /* @__PURE__ */ o("div", { className: "fp-sync-body", children: [
          /* @__PURE__ */ e("strong", { children: m ? "部分内容在其他设备上有更新" : "正在同步学习记录" }),
          /* @__PURE__ */ e("span", { children: m ? "选择要保留的版本，冲突解决后会继续同步。" : "未完成的内容已保存在本机。" }),
          l.filter((b) => b.conflict).map((b, y) => /* @__PURE__ */ o("div", { className: "fp-sync-actions", children: [
            /* @__PURE__ */ o("span", { className: "fp-sync-key", children: [
              "记录 ",
              y + 1
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !0).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "保留此设备版本"
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !1).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "采用云端版本"
              }
            )
          ] }, b.key)),
          c && /* @__PURE__ */ o("p", { className: "fp-sync-error", role: "alert", children: [
            /* @__PURE__ */ e(uo, { size: 13 }),
            " ",
            c
          ] })
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-sync-close",
            "aria-label": "收起同步提示",
            onClick: () => p(!0),
            children: /* @__PURE__ */ e(ge, { size: 14 })
          }
        )
      ]
    }
  );
}
function _u(t) {
  return !t || t <= 0 ? "" : t >= 1e6 ? `${+(t / 1e6).toFixed(1)}M` : t >= 1e3 ? `${+(t / 1e3).toFixed(1)}K` : `${t}`;
}
function Wu({
  value: t,
  onChange: n,
  groups: r,
  disabled: a,
  label: i = "选择模型"
}) {
  const l = r.flatMap((s) => s.models).find((s) => s.id === t);
  return /* @__PURE__ */ e("span", { className: "fp-model-selector", children: /* @__PURE__ */ e(
    Qe,
    {
      label: i,
      role: "listbox",
      disabled: a || !r.some((s) => s.models.length),
      className: "fp-model-selector-panel",
      trigger: /* @__PURE__ */ o(Z, { children: [
        l?.icon || /* @__PURE__ */ e(fo, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l?.label || t || "选择模型" }),
        /* @__PURE__ */ e(Ft, { size: 14, "aria-hidden": "true" })
      ] }),
      children: (s) => r.filter((c) => c.models.length).map((c) => /* @__PURE__ */ o(
        "div",
        {
          role: "group",
          "aria-label": c.name,
          className: "fp-model-group",
          children: [
            /* @__PURE__ */ e("div", { className: "fp-model-group-label", children: c.name }),
            c.models.map((u) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": u.id === t,
                disabled: u.disabled,
                tabIndex: -1,
                className: "fp-model-item",
                onClick: () => {
                  s(), n(u.id);
                },
                children: [
                  /* @__PURE__ */ o("span", { className: "fp-model-item-copy", children: [
                    /* @__PURE__ */ o("span", { className: "fp-model-item-main", children: [
                      /* @__PURE__ */ o("span", { className: "fp-model-item-label", children: [
                        u.icon,
                        u.label
                      ] }),
                      /* @__PURE__ */ e("span", { className: "fp-model-item-context", children: _u(u.contextWindow) })
                    ] }),
                    u.description && /* @__PURE__ */ e("span", { className: "fp-model-item-description", children: u.description }),
                    (u.supportsThinking || u.supportsVision || u.supportsTools) && /* @__PURE__ */ o("span", { className: "fp-model-capabilities", children: [
                      u.supportsThinking && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(po, { size: 12, "aria-hidden": "true" }),
                        "推理"
                      ] }),
                      u.supportsVision && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(Ga, { size: 12, "aria-hidden": "true" }),
                        "视觉"
                      ] }),
                      u.supportsTools && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(ho, { size: 12, "aria-hidden": "true" }),
                        "工具"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ e(
                    Re,
                    {
                      size: 16,
                      className: "fp-model-item-check",
                      "aria-hidden": "true",
                      style: {
                        visibility: u.id === t ? "visible" : "hidden"
                      }
                    }
                  )
                ]
              },
              u.id
            ))
          ]
        },
        c.name
      ))
    }
  ) });
}
function Vu({
  balance: t,
  enabled: n = !0,
  isLoading: r = !1,
  onClick: a,
  label: i
}) {
  const l = i || (n ? t !== void 0 ? `${(t / 1e3).toLocaleString(void 0, { maximumFractionDigits: 3 })} 积分` : "积分" : "免费体验");
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-token-dashboard",
      onClick: a,
      disabled: r,
      "aria-label": "查看积分与会员",
      children: [
        /* @__PURE__ */ e(mo, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l })
      ]
    }
  );
}
function Wf({
  apiEndpoint: t = "/api/me/credits",
  onClick: n
}) {
  const [r, a] = k(), [i, l] = k(!0), [s, c] = k(!0);
  return Y(() => {
    let u = !0;
    return fetch(t).then((d) => {
      if (!d.ok) throw new Error();
      return d.json();
    }).then((d) => {
      u && (a(d.wallet.balance), l(d.config.enabled), c(!1));
    }).catch(() => {
      u && c(!1);
    }), () => {
      u = !1;
    };
  }, [t]), /* @__PURE__ */ e(
    Vu,
    {
      balance: r,
      enabled: i,
      isLoading: s,
      onClick: n
    }
  );
}
function Vf({
  label: t,
  children: n,
  defaultOpen: r = !1,
  meta: a,
  className: i
}) {
  const [l, s] = k(r), c = Ne();
  return /* @__PURE__ */ o("div", { className: `fp-collapsible ${i || ""}`, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-collapsible-head",
        "aria-expanded": l,
        "aria-controls": c,
        onClick: () => s((u) => !u),
        children: [
          /* @__PURE__ */ e(Ie, { size: 14, className: "fp-collapsible-chevron" }),
          /* @__PURE__ */ e("span", { className: "fp-collapsible-label", children: t }),
          a != null && /* @__PURE__ */ e("span", { className: "fp-collapsible-meta", children: a })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: c, className: "fp-collapsible-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("div", { className: "fp-collapsible-inner", children: n }) })
  ] });
}
function Xf({
  items: t,
  onRemove: n,
  onOpen: r,
  size: a = 64
}) {
  return t.length ? /* @__PURE__ */ e("ul", { className: "fp-attachment-grid", "aria-label": "图片附件", children: t.map((i) => /* @__PURE__ */ o("li", { className: "fp-attachment", style: { width: a }, children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-thumb",
        style: { width: a, height: a },
        onClick: () => r?.(i),
        disabled: !r,
        "aria-label": i.name ? `查看 ${i.name}` : "查看附件",
        children: i.src ? /* @__PURE__ */ e("img", { src: i.src, alt: i.name || "" }) : /* @__PURE__ */ e("span", { className: "fp-attachment-placeholder", "aria-hidden": "true" })
      }
    ),
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-remove",
        "aria-label": `移除${i.name || "附件"}`,
        onClick: () => n(i.id),
        children: /* @__PURE__ */ e(ge, { size: 12 })
      }
    )
  ] }, i.id)) }) : null;
}
const Xu = {
  basic: "基础",
  medium: "中等",
  hard: "提高"
}, Yu = "ABCDEFGHIJ";
function Yf({
  index: t,
  total: n,
  kind: r = "单项选择",
  difficulty: a = "basic",
  prompt: i,
  options: l,
  selected: s,
  onSelect: c,
  mode: u = "answer",
  explanation: d,
  hint: p
}) {
  const h = Array.isArray(s) ? s : s ? [s] : [];
  return /* @__PURE__ */ o("article", { className: "fp-quiz", "data-mode": u, children: [
    /* @__PURE__ */ o("header", { className: "fp-quiz-meta", children: [
      /* @__PURE__ */ o("strong", { children: [
        "第 ",
        t + 1,
        " / ",
        n,
        " 题"
      ] }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: r }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: Xu[a] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-quiz-prompt", children: i }),
    /* @__PURE__ */ e("ol", { className: "fp-quiz-options", children: l.map((f, m) => {
      const b = h.includes(f.id), y = u === "review" && f.correct, w = u === "review" && b && !f.correct;
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-quiz-option",
          "data-selected": b || void 0,
          "data-correct": y || void 0,
          "data-wrong": w || void 0,
          "aria-pressed": b,
          disabled: u === "review" || !c,
          onClick: () => c?.(f.id),
          children: [
            /* @__PURE__ */ e("span", { className: "fp-quiz-letter", children: Yu[m] }),
            /* @__PURE__ */ e("span", { className: "fp-quiz-text", children: f.text }),
            y && /* @__PURE__ */ e(Re, { size: 16, "aria-label": "正确答案" }),
            w && /* @__PURE__ */ e(ge, { size: 16, "aria-label": "选择错误" })
          ]
        }
      ) }, f.id);
    }) }),
    u === "review" && d && /* @__PURE__ */ o("div", { className: "fp-quiz-explanation", children: [
      /* @__PURE__ */ e(Zr, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: d })
    ] }),
    p && /* @__PURE__ */ o("div", { className: "fp-quiz-hint", children: [
      /* @__PURE__ */ e(Zr, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: p })
    ] })
  ] });
}
function Gf({
  url: t,
  reason: n,
  onForce: r,
  title: a = "无法内嵌该页面",
  actionLabel: i = "打开原页面"
}) {
  let l = t;
  try {
    l = new URL(t).host;
  } catch {
  }
  return /* @__PURE__ */ o("div", { className: "fp-embed-fallback", children: [
    /* @__PURE__ */ e("span", { className: "fp-embed-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(bo, { size: 26 }) }),
    /* @__PURE__ */ e("strong", { children: a }),
    /* @__PURE__ */ o("p", { children: [
      /* @__PURE__ */ e("span", { className: "fp-embed-host", children: l }),
      " ",
      "拒绝在当前窗口中显示（安全策略或访问受限）。请到原网站查看，以保留完整功能。"
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-embed-reason", children: n }),
    /* @__PURE__ */ o(
      "a",
      {
        className: "fp-button fp-primary",
        href: t,
        target: "_blank",
        rel: "noopener noreferrer",
        children: [
          /* @__PURE__ */ e(Rt, { size: 15, "aria-hidden": "true" }),
          i
        ]
      }
    ),
    r && /* @__PURE__ */ e("button", { type: "button", className: "fp-embed-force", onClick: r, children: "仍要尝试内嵌（可能显示空白）" })
  ] });
}
function Gu({ src: t, alt: n = "", onClose: r }) {
  const [a, i] = k(1), [l, s] = k({ x: 0, y: 0 }), [c, u] = k(!1), d = B({ x: 0, y: 0 }), p = B({ x: 0, y: 0 });
  Y(() => {
    if (!t) return;
    i(1), s({ x: 0, y: 0 });
    const f = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const m = (b) => {
      b.key === "Escape" && r(), (b.key === "+" || b.key === "=") && i((y) => Math.min(5, y * 1.2)), b.key === "-" && i((y) => Math.max(0.25, y / 1.2)), b.key === "0" && (i(1), s({ x: 0, y: 0 }));
    };
    return document.addEventListener("keydown", m), () => {
      document.body.style.overflow = f, document.removeEventListener("keydown", m);
    };
  }, [t, r]);
  const h = xe(() => {
    i(1), s({ x: 0, y: 0 });
  }, []);
  return !t || typeof window > "u" ? null : Te(
    /* @__PURE__ */ o(
      "div",
      {
        className: "fp-lightbox",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": n || "图片预览",
        onWheel: (f) => {
          !f.ctrlKey && !f.metaKey || (f.preventDefault(), i((m) => Math.max(0.25, Math.min(5, m * (f.deltaY > 0 ? 0.9 : 1.1)))));
        },
        children: [
          /* @__PURE__ */ o("div", { className: "fp-lightbox-bar", children: [
            /* @__PURE__ */ o("span", { className: "fp-lightbox-zoom", children: [
              Math.round(a * 100),
              "%"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "缩小",
                onClick: () => i((f) => Math.max(0.25, f / 1.2)),
                children: /* @__PURE__ */ e(qa, { size: 17 })
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "放大",
                onClick: () => i((f) => Math.min(5, f * 1.2)),
                children: /* @__PURE__ */ e(ja, { size: 17 })
              }
            ),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "复位", onClick: h, children: /* @__PURE__ */ e(rt, { size: 17 }) }),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭", onClick: r, children: /* @__PURE__ */ e(ge, { size: 18 }) })
          ] }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "fp-lightbox-stage",
              "data-dragging": c || void 0,
              onDoubleClick: () => a > 1 ? h() : i(2),
              onPointerDown: (f) => {
                f.button !== 0 || a <= 1 || (u(!0), d.current = { x: f.clientX, y: f.clientY }, p.current = { ...l }, f.currentTarget.setPointerCapture(f.pointerId));
              },
              onPointerMove: (f) => {
                c && s({
                  x: p.current.x + f.clientX - d.current.x,
                  y: p.current.y + f.clientY - d.current.y
                });
              },
              onPointerUp: () => u(!1),
              onPointerCancel: () => u(!1),
              children: /* @__PURE__ */ e(
                "img",
                {
                  src: t,
                  alt: n,
                  draggable: !1,
                  style: {
                    transform: `translate(${l.x}px, ${l.y}px) scale(${a})`,
                    transition: c ? "none" : "transform 160ms var(--fp-ease)"
                  }
                }
              )
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-lightbox-scrim",
              "aria-label": "关闭预览",
              onClick: r
            }
          )
        ]
      }
    ),
    document.body
  );
}
function Jf({
  title: t,
  icon: n,
  summary: r,
  children: a,
  open: i,
  onToggle: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-settings-section", "data-open": i || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-settings-head",
        "aria-expanded": i,
        "aria-label": t,
        onClick: l,
        children: [
          /* @__PURE__ */ e("span", { className: "fp-settings-icon", "aria-hidden": "true", children: n }),
          /* @__PURE__ */ o("span", { className: "fp-settings-titles", children: [
            /* @__PURE__ */ e("strong", { children: t }),
            r && /* @__PURE__ */ e("small", { children: r })
          ] }),
          /* @__PURE__ */ e(Ft, { size: 16, className: "fp-settings-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-settings-body", inert: !i, "aria-hidden": !i, children: /* @__PURE__ */ e("div", { className: "fp-settings-inner", children: a }) })
  ] });
}
function Qf({
  subjectName: t = "学习",
  topic: n,
  prompts: r = [],
  onPrompt: a,
  icon: i,
  title: l,
  description: s
}) {
  return /* @__PURE__ */ o("div", { className: "fp-chat-empty", children: [
    /* @__PURE__ */ e("span", { className: "fp-chat-empty-icon", "aria-hidden": "true", children: i || /* @__PURE__ */ e(wn, { size: 22 }) }),
    /* @__PURE__ */ e("strong", { children: l || `我是你的${t}助教` }),
    /* @__PURE__ */ e("p", { children: s || "遇到不懂的概念随时问我，我可以解释公式、出题练习，或者帮你梳理知识点。" }),
    n && /* @__PURE__ */ o("span", { className: "fp-chat-empty-topic", children: [
      "当前学习 · ",
      n
    ] }),
    r.length > 0 && /* @__PURE__ */ o("div", { className: "fp-chat-prompts", children: [
      /* @__PURE__ */ e("span", { className: "fp-chat-prompts-label", children: "试试这样问我" }),
      r.map((c) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-chat-prompt",
          onClick: () => a?.(c),
          children: c
        },
        c
      ))
    ] })
  ] });
}
function Da(t) {
  try {
    return new URL(t).hostname.replace(/^www\./, "");
  } catch {
    return t;
  }
}
function Zf({
  sources: t,
  label: n = "联网来源",
  cached: r,
  onOpen: a
}) {
  const [i, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-source-fold", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-head",
        "aria-expanded": i,
        onClick: () => l((s) => !s),
        children: [
          /* @__PURE__ */ e(Ie, { size: 14, className: "fp-source-chevron" }),
          /* @__PURE__ */ e(go, { size: 15, "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { children: [
            n,
            " · ",
            t.length,
            " 条",
            r ? " · 缓存" : ""
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-source-body", inert: !i, "aria-hidden": !i, "data-open": i || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-source-list", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-item",
        onClick: () => a?.(s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-source-index", children: c + 1 }),
          /* @__PURE__ */ e("span", { className: "fp-source-title", children: s.title || Da(s.url) }),
          /* @__PURE__ */ o("span", { className: "fp-source-host", children: [
            /* @__PURE__ */ e(ft, { size: 12, "aria-hidden": "true" }),
            Da(s.url)
          ] })
        ]
      }
    ) }, `${s.url}:${c}`)) }) })
  ] }) : null;
}
function em({
  groups: t,
  activeId: n,
  onSelect: r,
  onCreate: a,
  onDelete: i,
  onClose: l
}) {
  const [s, c] = k(t[0]?.id), [u, d] = k(null), p = t.find((h) => h.id === s) || t[0];
  return /* @__PURE__ */ o("div", { className: "fp-session-history", children: [
    /* @__PURE__ */ o("header", { className: "fp-session-history-head", children: [
      /* @__PURE__ */ e(Rn, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: "历史记录" }),
      l && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-icon-button fp-sm",
          "aria-label": "关闭历史记录",
          onClick: l,
          children: /* @__PURE__ */ e(ge, { size: 16 })
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { className: "fp-session-tabs", role: "tablist", "aria-label": "记录类型", children: t.map((h) => /* @__PURE__ */ o(
      "button",
      {
        role: "tab",
        type: "button",
        "aria-selected": h.id === p?.id,
        onClick: () => c(h.id),
        children: [
          h.label,
          /* @__PURE__ */ e("span", { children: h.items.length })
        ]
      },
      h.id
    )) }),
    a && p && /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-session-create",
        onClick: () => a(p.id),
        children: [
          /* @__PURE__ */ e(gn, { size: 15, "aria-hidden": "true" }),
          "新建",
          p.label.replace(/记录$/, "")
        ]
      }
    ),
    /* @__PURE__ */ o("ul", { className: "fp-session-list", children: [
      (p?.items || []).map((h) => /* @__PURE__ */ o("li", { "data-active": h.id === n || void 0, children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-session-item",
            onClick: () => r(p.id, h.id),
            "aria-current": h.id === n || void 0,
            children: [
              /* @__PURE__ */ e(yo, { size: 15, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: h.title }),
                h.detail && /* @__PURE__ */ e("small", { children: h.detail })
              ] }),
              h.time && /* @__PURE__ */ e("time", { children: h.time })
            ]
          }
        ),
        i && (u === h.id ? /* @__PURE__ */ o("span", { className: "fp-session-confirm", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                i(p.id, h.id), d(null);
              },
              children: "删除"
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => d(null), children: "取消" })
        ] }) : /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-session-delete",
            "aria-label": `删除 ${h.title}`,
            onClick: () => d(h.id),
            children: /* @__PURE__ */ e(Bt, { size: 14 })
          }
        ))
      ] }, h.id)),
      !p?.items.length && /* @__PURE__ */ e("li", { className: "fp-session-empty", children: "还没有记录，开始第一次对话吧。" })
    ] })
  ] });
}
function tm({ mode: t = "login", title: n = "账号登录", icon: r = /* @__PURE__ */ e(ht, { size: 18 }), onClose: a, onBrowser: i, onReload: l, children: s, className: c, browserPending: u = !1 }) {
  return /* @__PURE__ */ e(hd, { children: /* @__PURE__ */ e(
    ol,
    {
      native: !0,
      title: n,
      icon: r,
      closeLabel: t === "task" ? "关闭授权窗口" : "取消登录",
      closeShortcut: "Esc",
      onClose: a,
      className: c,
      actions: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ o(le, { variant: "ghost", onClick: i, "aria-label": t === "task" ? "在浏览器中继续" : "在浏览器中继续登录", "data-fp-tooltip-side": "left", children: [
          /* @__PURE__ */ e(Rt, { size: 16 }),
          t === "task" ? "浏览器继续" : "浏览器登录"
        ] }),
        /* @__PURE__ */ e(le, { variant: "ghost", disabled: u, "aria-label": t === "task" ? "刷新授权信息" : "重新加载登录页", "data-fp-tooltip-side": "left", style: { width: 44, padding: 0 }, onClick: l, children: /* @__PURE__ */ e(Bn, { size: 16 }) })
      ] }),
      children: u ? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: "请在浏览器中完成登录，完成后会自动返回。" }) : s ?? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: t === "task" ? "正在读取授权信息…" : "正在打开登录页…" })
    }
  ) });
}
function nm({
  label: t = "筛选",
  value: n,
  onChange: r,
  options: a = [],
  groups: i = [],
  disabled: l,
  id: s
}) {
  const c = Ne();
  return /* @__PURE__ */ o("div", { className: "fp-filter", children: [
    t && /* @__PURE__ */ e("span", { id: s || c, className: "fp-filter-label", children: t }),
    /* @__PURE__ */ e(we, { label: t || "筛选", value: n, onChange: r, disabled: l, options: [...a, ...i.flatMap((d) => d.options.map((p) => ({ ...p, group: d.label })))] })
  ] });
}
function rm({
  years: t,
  value: n,
  onChange: r,
  compact: a = !1,
  termLabel: i = "学期"
}) {
  const l = t.find((u) => u.id === n), s = Array.from(new Set(t.map((u) => u.grade))), c = l ? t.filter((u) => u.grade === l.grade) : [];
  return /* @__PURE__ */ o("div", { className: "fp-academic", "data-compact": a || void 0, children: [
    /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": "年级", children: s.map((u) => {
      const d = t.find((h) => h.grade === u), p = l?.grade === u;
      return /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-academic-btn",
          "aria-pressed": p,
          onClick: () => r(d.id),
          children: u
        },
        u
      );
    }) }),
    c.length > 1 && /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": i, children: c.map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-academic-btn fp-academic-term",
        "aria-pressed": u.id === n,
        onClick: () => r(u.id),
        children: u.term
      },
      u.id
    )) })
  ] });
}
function am({
  hits: t,
  label: n = "引用笔记",
  onOpen: r,
  action: a
}) {
  const [i, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-citation-list", children: [
    /* @__PURE__ */ o("header", { className: "fp-citation-head", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-citation-toggle",
          "aria-expanded": i,
          onClick: () => l((s) => !s),
          children: [
            /* @__PURE__ */ e(Ie, { size: 14, className: "fp-citation-chevron" }),
            /* @__PURE__ */ e(Ye, { size: 15, "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { children: [
              n,
              " · ",
              t.length,
              " 条"
            ] })
          ]
        }
      ),
      a && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-citation-action",
          onClick: a.onClick,
          children: a.label
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-citation-body", "data-open": i || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-citation-hits", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-citation-hit",
        onClick: () => r?.(s),
        children: [
          /* @__PURE__ */ e("strong", { children: s.title }),
          /* @__PURE__ */ e("span", { children: s.path }),
          s.snippet && /* @__PURE__ */ e("small", { children: s.snippet })
        ]
      }
    ) }, `${s.path}:${c}`)) }) })
  ] }) : null;
}
const Ju = {
  idle: "等待确认",
  approved: "已批准",
  running: "生成中",
  done: "已完成",
  cancelled: "已取消",
  error: "失败"
};
function im({
  title: t = "AI 生图",
  prompt: n,
  details: r = [],
  cost: a,
  status: i = "idle",
  onApprove: l,
  onCancel: s,
  children: c
}) {
  const u = i === "idle";
  return /* @__PURE__ */ o("section", { className: "fp-approval", "data-status": i, children: [
    /* @__PURE__ */ o("header", { className: "fp-approval-head", children: [
      /* @__PURE__ */ e("span", { className: "fp-approval-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(wn, { size: 16 }) }),
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("span", { className: "fp-approval-status", children: Ju[i] })
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-approval-prompt", children: n }),
    r.length > 0 && /* @__PURE__ */ e("dl", { className: "fp-approval-details", children: r.map((d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: d.label }),
      /* @__PURE__ */ e("dd", { children: d.value })
    ] }, d.label)) }),
    a && /* @__PURE__ */ e("p", { className: "fp-approval-cost", children: a }),
    u ? /* @__PURE__ */ o("div", { className: "fp-approval-actions", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-primary", onClick: l, children: [
        /* @__PURE__ */ e(Re, { size: 15, "aria-hidden": "true" }),
        "批准并继续"
      ] }),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: s,
          children: [
            /* @__PURE__ */ e(ge, { size: 15, "aria-hidden": "true" }),
            "取消"
          ]
        }
      )
    ] }) : c
  ] });
}
function bl(t, n = 0) {
  return t.flatMap((r) => [
    { node: r, depth: n },
    ...bl(r.children || [], n + 1)
  ]);
}
function lm({
  items: t,
  activeId: n,
  onSelect: r,
  label: a = "目录",
  empty: i = "这篇内容还没有小节标题。"
}) {
  const l = bl(t);
  return l.length ? /* @__PURE__ */ e("nav", { className: "fp-toc", "aria-label": a, children: l.map(({ node: s, depth: c }) => {
    const u = s.level ?? 1;
    return /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-toc-row",
        "data-level": u,
        "data-active": s.id === n || void 0,
        style: { paddingLeft: 8 + c * 16 },
        title: s.text,
        "aria-current": s.id === n ? "location" : void 0,
        onClick: () => {
          r?.(s.id), document.getElementById(s.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
        },
        children: [
          u === 1 ? /* @__PURE__ */ e(Ye, { size: 14, "aria-hidden": "true" }) : /* @__PURE__ */ e("span", { className: "fp-toc-dot", "aria-hidden": "true" }),
          /* @__PURE__ */ e("span", { children: s.text })
        ]
      },
      s.id
    );
  }) }) : /* @__PURE__ */ e("p", { className: "fp-toc-empty", children: i });
}
const Qu = {
  done: mt,
  draft: vo,
  stub: Za
};
function om({
  items: t,
  activeId: n,
  onSelect: r,
  label: a = "同目录内容"
}) {
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-siblings", "aria-label": a, children: [
    /* @__PURE__ */ e("header", { className: "fp-siblings-label", children: a }),
    /* @__PURE__ */ e("ul", { className: "fp-siblings-list", children: t.map((i) => {
      const l = Qu[i.status ?? "stub"];
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-sibling",
          "data-status": i.status ?? "stub",
          "aria-current": i.id === n ? "page" : void 0,
          onClick: () => r(i),
          children: [
            /* @__PURE__ */ e(l, { size: 14, className: "fp-sibling-icon", "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { className: "fp-sibling-text", children: [
              i.title,
              i.detail && /* @__PURE__ */ e("small", { children: i.detail })
            ] })
          ]
        }
      ) }, i.id);
    }) })
  ] }) : null;
}
function sm({
  steps: t,
  interactive: n = !1,
  label: r = "推导步骤"
}) {
  const [a, i] = k(0);
  if (!t.length) return null;
  const l = n ? [t[a]] : t;
  return /* @__PURE__ */ o("section", { className: "fp-formula", "aria-label": r, children: [
    /* @__PURE__ */ o("header", { className: "fp-formula-head", children: [
      /* @__PURE__ */ e(zt, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("span", { children: r }),
      n && /* @__PURE__ */ o("span", { className: "fp-formula-count", children: [
        "第 ",
        a + 1,
        " / ",
        t.length,
        " 步"
      ] })
    ] }),
    /* @__PURE__ */ e("ol", { className: "fp-formula-list", children: l.map((s, c) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-formula-index", children: n ? a + 1 : c + 1 }),
      /* @__PURE__ */ e("div", { className: "fp-formula-body", children: s })
    ] }, n ? a : c)) }),
    n && /* @__PURE__ */ o("div", { className: "fp-formula-nav", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a === 0,
          onClick: () => i((s) => Math.max(0, s - 1)),
          children: [
            /* @__PURE__ */ e(Mr, { size: 14, "aria-hidden": "true" }),
            "上一步"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a === t.length - 1,
          onClick: () => i((s) => Math.min(t.length - 1, s + 1)),
          children: [
            "下一步",
            /* @__PURE__ */ e(Ie, { size: 14, "aria-hidden": "true" })
          ]
        }
      )
    ] })
  ] });
}
const gl = 320, Nr = 170, Pe = { l: 30, r: 12, t: 14, b: 26 }, sr = gl - Pe.l - Pe.r, $t = Nr - Pe.t - Pe.b;
function Zu(t, n, r) {
  const a = Math.max(1e-6, r);
  return 1 / (a * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * ((t - n) / a) ** 2);
}
function ep(t, n) {
  if (n < 0 || n > t) return 0;
  let r = 1;
  for (let a = 1; a <= n; a++) r = r * (t - n + a) / a;
  return r;
}
function tp(t, n, r) {
  return ep(n, t) * r ** t * (1 - r) ** (n - t);
}
function np(t, n) {
  let r = 1;
  for (let a = 2; a <= t; a++) r *= a;
  return n ** t * Math.exp(-n) / r;
}
function cm({
  type: t,
  params: n = {},
  interactive: r = !1,
  height: a = 180,
  label: i
}) {
  const l = Ne(), [s, c] = k(n.mu ?? 0), [u, d] = k(n.sigma ?? 1), [p, h] = k(n.n ?? 10), [f, m] = k(n.p ?? 0.5), [b, y] = k(n.lambda ?? 3), w = [];
  let v = [], g = 1;
  if (t === "normal") {
    const I = s - 4 * u, T = s + 4 * u, H = 120;
    for (let R = 0; R <= H; R++) {
      const O = I + (T - I) * R / H;
      w.push({ x: O, y: Zu(O, s, u) });
    }
    g = Math.max(...w.map((R) => R.y)), v = [I, s - u, s, s + u, T];
  } else {
    const I = t === "binomial" ? p : Math.max(1, Math.round(b * 4));
    for (let T = 0; T <= I; T++) {
      const H = t === "binomial" ? tp(T, p, f) : np(T, b);
      w.push({ x: T, y: H });
    }
    g = Math.max(...w.map((T) => T.y), 1e-9), v = [0, Math.round(I / 2), I];
  }
  const x = w[0].x, N = w[w.length - 1].x, C = (I) => Pe.l + (I - x) / (N - x || 1) * sr, A = (I) => Pe.t + $t - I / g * $t * 0.92, L = t === "normal" ? w.map((I, T) => `${T === 0 ? "M" : "L"}${C(I.x).toFixed(1)},${A(I.y).toFixed(1)}`).join(" ") : "", U = t === "normal" ? 0 : Math.max(4, sr / w.length - 4), S = /* @__PURE__ */ o(
    "svg",
    {
      viewBox: `0 0 ${gl} ${Nr}`,
      width: "100%",
      height: a,
      role: "img",
      "aria-labelledby": l,
      className: "fp-dist-chart",
      children: [
        /* @__PURE__ */ e("title", { id: l, children: i || (t === "normal" ? `正态分布 μ=${s} σ=${u}` : t === "binomial" ? `二项分布 n=${p} p=${f}` : `泊松分布 λ=${b}`) }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: Pe.l,
            y1: Pe.t + $t,
            x2: Pe.l + sr,
            y2: Pe.t + $t,
            className: "fp-dist-axis"
          }
        ),
        /* @__PURE__ */ e("line", { x1: Pe.l, y1: Pe.t, x2: Pe.l, y2: Pe.t + $t, className: "fp-dist-axis" }),
        t === "normal" ? /* @__PURE__ */ e("path", { d: L, className: "fp-dist-line" }) : w.map((I, T) => /* @__PURE__ */ e(
          "rect",
          {
            x: C(I.x) - U / 2,
            y: A(I.y),
            width: U,
            height: Pe.t + $t - A(I.y),
            rx: 2,
            className: "fp-dist-bar"
          },
          T
        )),
        v.map((I, T) => /* @__PURE__ */ e(
          "text",
          {
            x: C(I),
            y: Nr - 8,
            textAnchor: "middle",
            className: "fp-dist-tick",
            children: Number.isInteger(I) ? I : I.toFixed(1)
          },
          T
        ))
      ]
    }
  );
  return r ? /* @__PURE__ */ o("div", { className: "fp-dist", children: [
    S,
    /* @__PURE__ */ e("div", { className: "fp-dist-controls", children: t === "normal" ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "均值 μ · ",
          s.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: -3,
            max: 3,
            step: 0.1,
            value: s,
            onChange: (I) => c(Number(I.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "标准差 σ · ",
          u.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.3,
            max: 3,
            step: 0.1,
            value: u,
            onChange: (I) => d(Number(I.target.value))
          }
        )
      ] })
    ] }) : t === "binomial" ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "试验次数 n · ",
          p
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 1,
            max: 30,
            step: 1,
            value: p,
            onChange: (I) => h(Number(I.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "成功概率 p · ",
          f.toFixed(2)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.05,
            max: 0.95,
            step: 0.05,
            value: f,
            onChange: (I) => m(Number(I.target.value))
          }
        )
      ] })
    ] }) : /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ o("span", { children: [
        "λ · ",
        b.toFixed(1)
      ] }),
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0.5,
          max: 10,
          step: 0.5,
          value: b,
          onChange: (I) => y(Number(I.target.value))
        }
      )
    ] }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-dist", children: S });
}
function dm({
  open: t,
  onClose: n,
  categories: r,
  title: a = "快捷键参考",
  footnote: i
}) {
  return Y(() => {
    if (!t) return;
    const l = (c) => {
      c.key === "Escape" && (c.preventDefault(), n());
    };
    document.addEventListener("keydown", l);
    const s = document.body.style.overflow;
    return document.body.style.overflow = "hidden", () => {
      document.removeEventListener("keydown", l), document.body.style.overflow = s;
    };
  }, [t, n]), !t || typeof window > "u" ? null : Te(
    /* @__PURE__ */ e("div", { className: "fp-shortcut-scrim", onPointerDown: n, children: /* @__PURE__ */ o(
      "div",
      {
        className: "fp-shortcut",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": a,
        onPointerDown: (l) => l.stopPropagation(),
        children: [
          /* @__PURE__ */ o("header", { className: "fp-shortcut-head", children: [
            /* @__PURE__ */ e(Wa, { size: 18, "aria-hidden": "true" }),
            /* @__PURE__ */ e("strong", { children: a }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-icon-button fp-sm",
                "aria-label": "关闭快捷键参考",
                onClick: n,
                children: /* @__PURE__ */ e(ge, { size: 16 })
              }
            )
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-shortcut-body", children: r.map((l) => /* @__PURE__ */ o("section", { className: "fp-shortcut-group", children: [
            /* @__PURE__ */ e("h3", { children: l.label }),
            /* @__PURE__ */ e("dl", { children: l.items.map((s) => /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("dt", { children: s.keys.split(" ").map((c, u) => /* @__PURE__ */ e("span", { className: "fp-kbd", children: c }, u)) }),
              /* @__PURE__ */ e("dd", { children: s.description })
            ] }, s.keys + s.description)) })
          ] }, l.id)) }),
          i && /* @__PURE__ */ e("footer", { className: "fp-shortcut-foot", children: i })
        ]
      }
    ) }),
    document.body
  );
}
function um({
  items: t,
  value: n,
  onChange: r,
  label: a = "主导航",
  className: i = "",
  busy: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: `fp-bottom-nav ${i}`, "aria-label": a, "aria-busy": l, children: t.map((s) => {
    const c = s.id === n, u = s.href ? "a" : "button";
    return /* @__PURE__ */ o(
      u,
      {
        type: "button",
        href: s.href,
        "aria-disabled": s.disabled || void 0,
        className: "fp-bottom-nav-item",
        "aria-current": c ? "page" : void 0,
        onClick: (d) => {
          s.href && (d.metaKey || d.ctrlKey || d.shiftKey || d.altKey) || (d.preventDefault(), s.disabled || r(s.id));
        },
        children: [
          /* @__PURE__ */ e("span", { className: "fp-bottom-nav-indicator", "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { className: "fp-bottom-nav-icon", children: [
            s.icon,
            s.badge ? /* @__PURE__ */ e("span", { className: "fp-bottom-nav-badge", children: s.badge }) : null
          ] }),
          /* @__PURE__ */ e("span", { children: s.label })
        ]
      },
      s.id
    );
  }) });
}
const rp = 4;
function pm({
  images: t,
  label: n = "笔记图片",
  size: r = 132,
  meta: a
}) {
  const i = B(null), l = B(null), [s, c] = k(null);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-gallery", children: [
    /* @__PURE__ */ o("header", { className: "fp-gallery-head", children: [
      /* @__PURE__ */ e(wo, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        n,
        " · ",
        t.length,
        " 张"
      ] }),
      a && /* @__PURE__ */ e("small", { children: a })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        ref: i,
        className: "fp-gallery-strip",
        "data-dragging": l.current?.moved || void 0,
        onPointerDown: (u) => {
          const d = i.current;
          !d || u.button !== 0 || (l.current = { x: u.clientX, left: d.scrollLeft, moved: !1 });
        },
        onPointerMove: (u) => {
          const d = i.current, p = l.current;
          if (!d || !p) return;
          const h = u.clientX - p.x;
          !p.moved && Math.abs(h) >= rp && (p.moved = !0, d.setPointerCapture(u.pointerId)), p.moved && (d.scrollLeft = p.left - h);
        },
        onPointerUp: () => {
          l.current = null;
        },
        onPointerCancel: () => {
          l.current = null;
        },
        children: t.map((u, d) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-gallery-item",
            style: { width: r, height: r },
            onClick: () => {
              l.current?.moved || c(u);
            },
            children: [
              /* @__PURE__ */ e("img", { src: u.src, alt: u.alt || u.caption || `图片 ${d + 1}` }),
              u.caption && /* @__PURE__ */ e("span", { children: u.caption })
            ]
          },
          `${u.src}:${d}`
        ))
      }
    ),
    /* @__PURE__ */ e(
      Gu,
      {
        src: s?.src ?? null,
        alt: s?.alt || s?.caption,
        onClose: () => c(null)
      }
    )
  ] }) : null;
}
function hm({
  windows: t,
  onSelect: n,
  max: r = 5,
  label: a = "已打开的窗口"
}) {
  const i = B(null), [l, s] = k(r);
  if (Ce(() => {
    const p = i.current;
    if (!p) return;
    const h = () => {
      p.clientWidth && s(
        Math.max(
          1,
          Math.min(r, Math.floor((p.clientWidth - 46) / 132))
        )
      );
    };
    if (h(), typeof ResizeObserver > "u") return;
    const f = new ResizeObserver(h);
    return f.observe(p), () => f.disconnect();
  }, [r, t.length]), !t.length) return null;
  const c = Math.max(1, Math.min(r, l)), u = t.slice(0, c), d = t.slice(c);
  return /* @__PURE__ */ o("div", { ref: i, className: "fp-taskbar", role: "toolbar", "aria-label": a, children: [
    u.map((p) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-taskbar-item",
        "aria-pressed": p.active,
        title: p.title,
        onClick: () => n(p.id),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-taskbar-dot", "aria-hidden": "true" }),
          p.icon,
          /* @__PURE__ */ e("span", { className: "fp-taskbar-title", children: p.title })
        ]
      },
      p.id
    )),
    d.length > 0 && /* @__PURE__ */ e(
      Qe,
      {
        label: `还有 ${d.length} 个窗口`,
        menu: !0,
        trigger: /* @__PURE__ */ o("span", { children: [
          "+",
          d.length
        ] }),
        children: (p) => d.map((h) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            role: "menuitem",
            onClick: () => {
              p(), n(h.id);
            },
            children: [
              h.icon,
              h.title
            ]
          },
          h.id
        ))
      }
    )
  ] });
}
function fm({ title: t, description: n, icon: r, className: a = "", ...i }) {
  return /* @__PURE__ */ o("button", { ...i, type: i.type || "button", className: `fp-navigation-card ${a}`, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-navigation-card-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-navigation-card-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e(Ie, { size: 17, "aria-hidden": "true" })
  ] });
}
function mm({ title: t, description: n, eyebrow: r, art: a, footer: i, className: l = "", ...s }) {
  return /* @__PURE__ */ o("button", { ...s, type: s.type || "button", className: `fp-preview-card ${l}`, children: [
    /* @__PURE__ */ o("span", { className: "fp-preview-card-art", children: [
      /* @__PURE__ */ e("span", { className: "fp-preview-card-eyebrow", children: r }),
      a
    ] }),
    /* @__PURE__ */ o("span", { className: "fp-preview-card-copy", children: [
      /* @__PURE__ */ o("strong", { children: [
        t,
        /* @__PURE__ */ e(Ie, { size: 17 })
      ] }),
      n && /* @__PURE__ */ e("span", { children: n }),
      i && /* @__PURE__ */ e("span", { className: "fp-preview-card-footer", children: i })
    ] })
  ] });
}
const ap = (t) => t === void 0 ? "—" : t < 1024 ? `${t} B` : t < 1048576 ? `${(t / 1024).toFixed(1)} KB` : `${(t / 1048576).toFixed(1)} MB`;
function ip({
  media: t = !1,
  defaultView: n = "list",
  showSearch: r = !0,
  availableActions: a = ["download", "share", "rename", "delete"],
  query: i,
  onQueryChange: l,
  items: s,
  folderId: c = null,
  onFolderChange: u,
  selectedIds: d,
  onSelectionChange: p,
  onOpen: h,
  onAction: f,
  onCreateFolder: m,
  onUpload: b,
  onMove: y,
  loading: w,
  error: v
}) {
  const g = B(null), x = B(null), [N, C] = k(null), [A, L] = k(1), [U, S] = k(n), [I, T] = k(""), [H, R] = k("name"), O = i ?? I, M = (q) => {
    T(q), l?.(q);
  }, K = s.find((q) => q.id === c), j = s.filter((q) => d.includes(q.id)), P = [];
  let $ = K;
  const z = /* @__PURE__ */ new Set();
  for (; $ && !z.has($.id); )
    z.add($.id), P.unshift($), $ = s.find((q) => q.id === $?.parentId);
  const E = He(
    () => s.filter(
      (q) => (q.parentId || null) === c && q.name.toLowerCase().includes(O.toLowerCase())
    ).sort(
      (q, V) => q.kind !== V.kind ? q.kind === "folder" ? -1 : 1 : H === "name-desc" ? V.name.localeCompare(q.name, "zh-CN") : H === "modified-asc" ? (q.modifiedAt || "").localeCompare(V.modifiedAt || "") : H === "size-asc" ? (q.size || 0) - (V.size || 0) : H === "size" ? (V.size || 0) - (q.size || 0) : H === "modified" ? (V.modifiedAt || "").localeCompare(q.modifiedAt || "") : q.name.localeCompare(V.name, "zh-CN")
    ),
    [s, c, O, H]
  );
  Ce(() => {
    const q = x.current;
    if (!q) return;
    const V = () => L(Math.max(1, Math.floor((q.clientWidth - 8) / (t ? 228 : 148))));
    if (V(), typeof ResizeObserver > "u") return;
    const oe = new ResizeObserver(V);
    return oe.observe(q), () => oe.disconnect();
  }, [t]);
  const D = U === "list" ? 1 : A, ne = pi({
    count: Math.ceil(E.length / D),
    getScrollElement: () => x.current,
    estimateSize: () => U === "list" ? 52 : t ? 244 : 156,
    overscan: 8,
    initialRect: { width: 800, height: 480 }
  }), ae = E.length > 100, ye = ne.getVirtualItems(), he = ae ? ye.flatMap(
    (q) => E.slice(q.index * D, (q.index + 1) * D)
  ) : E;
  Y(() => {
    ne.scrollToOffset(0);
  }, [c, O, H, U]);
  const W = (q, V) => {
    const oe = /* @__PURE__ */ new Set();
    for (; V; ) {
      if (q.includes(V) || oe.has(V)) return !1;
      oe.add(V), V = s.find((_) => _.id === V)?.parentId || null;
    }
    return !0;
  }, G = (q, V = !1, oe = !1) => {
    if (V && g.current) {
      const _ = E.findIndex((Q) => Q.id === g.current), F = E.findIndex((Q) => Q.id === q);
      if (_ >= 0 && F >= 0) {
        p(
          E.slice(Math.min(_, F), Math.max(_, F) + 1).map((Q) => Q.id)
        );
        return;
      }
    }
    g.current = q, p(
      oe ? d.includes(q) ? d.filter((_) => _ !== q) : [...d, q] : [q]
    );
  }, ue = (q) => {
    q.kind === "folder" ? (u(q.id), p([]), M("")) : h(q);
  }, me = (q) => [
    {
      id: "open",
      label: "打开",
      icon: /* @__PURE__ */ e(Ye, { size: 15 }),
      disabled: q.length !== 1,
      onSelect: () => ue(q[0])
    },
    ...f ? [
      { id: "download", label: "下载", icon: /* @__PURE__ */ e(Ot, { size: 15 }), disabled: q.some((V) => V.kind === "folder") },
      { id: "restore", label: "恢复", icon: /* @__PURE__ */ e(rt, { size: 15 }) },
      { id: "move", label: "移动到…", icon: /* @__PURE__ */ e(xo, { size: 15 }) },
      { id: "share", label: "分享", icon: /* @__PURE__ */ e(Co, { size: 15 }) },
      {
        id: "rename",
        label: "重命名",
        icon: /* @__PURE__ */ e(Fn, { size: 15 }),
        disabled: q.length !== 1
      },
      {
        id: "delete",
        label: "移到回收站",
        icon: /* @__PURE__ */ e(Bt, { size: 15 }),
        danger: !0,
        separator: !0
      }
    ].filter((V) => a.includes(V.id)).map((V) => ({
      ...V,
      onSelect: () => f(
        V.id,
        q
      )
    })) : []
  ];
  return /* @__PURE__ */ o("section", { className: "fp-resource-explorer", "data-media": t || void 0, "aria-label": t ? "图片资源管理器" : "文件资源管理器", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("nav", { "aria-label": "文件路径", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              u(null), M("");
            },
            children: "全部文件"
          }
        ),
        P.map((q) => /* @__PURE__ */ o("span", { children: [
          " ",
          "/",
          " ",
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                u(q.id), M("");
              },
              children: q.name
            }
          )
        ] }, q.id))
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-explorer-tools", children: [
        (m || j.length > 0) && /* @__PURE__ */ e(ml, { label: "资源操作", actions: [...m ? [{ id: "create", label: "新建文件夹", icon: /* @__PURE__ */ e(ko, { size: 17 }), onSelect: m }] : [], ...me(j).filter((q) => q.id !== "open" && j.length > 0).map((q) => ({ id: q.id, label: q.label, icon: q.icon, onSelect: () => q.onSelect?.(), disabled: q.disabled }))] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "返回上级",
            disabled: !c,
            onClick: () => u(K?.parentId || null),
            children: /* @__PURE__ */ e($r, { size: 16 })
          }
        ),
        r && /* @__PURE__ */ o("label", { className: "fp-explorer-search", children: [
          /* @__PURE__ */ e(Je, { size: 15 }),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "搜索当前文件夹",
              placeholder: "搜索文件",
              value: O,
              onChange: (q) => M(q.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ e(
          we,
          {
            label: "文件排序",
            value: H,
            onChange: R,
            options: [
              { value: "name", label: "名称 A → Z" },
              { value: "name-desc", label: "名称 Z → A" },
              { value: "modified", label: "修改时间：新到旧" },
              { value: "modified-asc", label: "修改时间：旧到新" },
              { value: "size", label: "大小：大到小" },
              { value: "size-asc", label: "大小：小到大" }
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "列表视图",
            "aria-pressed": U === "list",
            onClick: () => S("list"),
            children: /* @__PURE__ */ e(yn, { size: 16 })
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "网格视图",
            "aria-pressed": U === "grid",
            onClick: () => S("grid"),
            children: /* @__PURE__ */ e(No, { size: 16 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(
      gt,
      {
        label: "文件夹操作",
        items: [
          ...m ? [{ id: "new", label: "新建文件夹", onSelect: m }] : [],
          {
            id: "select-all",
            label: "全选",
            onSelect: () => p(E.map((q) => q.id))
          },
          {
            id: "view",
            label: "视图",
            children: [
              {
                id: "list",
                label: "列表",
                checked: U === "list",
                onSelect: () => S("list")
              },
              {
                id: "grid",
                label: "网格",
                checked: U === "grid",
                onSelect: () => S("grid")
              }
            ]
          }
        ],
        children: /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o(
          "div",
          {
            ref: x,
            style: {
              position: "relative",
              maxHeight: 480,
              overflow: "auto",
              ...ae && U === "grid" ? {
                gridTemplateColumns: `repeat(${A},minmax(0,1fr))`,
                rowGap: 0
              } : {}
            },
            onPointerDown: (q) => {
              if (q.button !== 0 || q.pointerType === "touch" || q.target.closest(
                ".fp-explorer-item,button,input,label"
              ))
                return;
              const V = q.currentTarget.getBoundingClientRect(), oe = q.clientX - V.left + q.currentTarget.scrollLeft, _ = q.clientY - V.top + q.currentTarget.scrollTop;
              q.currentTarget.setPointerCapture(q.pointerId), C({ x: oe, y: _, left: oe, top: _, width: 0, height: 0 });
            },
            onPointerMove: (q) => {
              if (!N) return;
              const V = q.currentTarget.getBoundingClientRect(), oe = q.clientX - V.left + q.currentTarget.scrollLeft, _ = q.clientY - V.top + q.currentTarget.scrollTop, F = {
                ...N,
                left: Math.min(oe, N.x),
                top: Math.min(_, N.y),
                width: Math.abs(oe - N.x),
                height: Math.abs(_ - N.y)
              };
              C(F);
              const Q = Array.from(
                q.currentTarget.querySelectorAll(
                  "[data-resource-id]"
                )
              ).filter((ve) => {
                const Me = ve.getBoundingClientRect(), Ee = Me.left - V.left + q.currentTarget.scrollLeft, je = Me.top - V.top + q.currentTarget.scrollTop;
                return Ee < F.left + F.width && Ee + Me.width > F.left && je < F.top + F.height && je + Me.height > F.top;
              }).map((ve) => ve.dataset.resourceId);
              p(Q);
            },
            onPointerUp: () => C(null),
            onPointerCancel: () => C(null),
            className: `fp-explorer-content fp-explorer-${U}`,
            "aria-busy": w,
            tabIndex: 0,
            onKeyDown: (q) => {
              q.target.closest("input") || ((q.ctrlKey || q.metaKey) && q.key.toLowerCase() === "a" && (q.preventDefault(), p(E.map((V) => V.id))), q.key === "Escape" && p([]), q.key === "Delete" && j.length && f && a.includes("delete") && (q.preventDefault(), f("delete", j)));
            },
            onDragOver: (q) => {
              (b || y) && q.preventDefault();
            },
            onDrop: (q) => {
              if (q.preventDefault(), q.dataTransfer.files.length)
                b?.(Array.from(q.dataTransfer.files), c);
              else
                try {
                  const V = JSON.parse(
                    q.dataTransfer.getData(
                      "application/x-fiveplusone-resources"
                    )
                  );
                  Array.isArray(V) && V.every((oe) => typeof oe == "string") && W(V, c) && y?.(V, c);
                } catch {
                }
            },
            children: [
              v ? /* @__PURE__ */ e("p", { role: "alert", children: v }) : w ? /* @__PURE__ */ e(pl, { variant: "list", label: "正在加载文件" }) : E.length ? /* @__PURE__ */ o(Z, { children: [
                ae && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: ye[0]?.start || 0,
                      gridColumn: "1 / -1"
                    }
                  }
                ),
                he.map((q) => /* @__PURE__ */ e(
                  gt,
                  {
                    label: `${q.name}的操作`,
                    items: me(
                      d.includes(q.id) ? j : [q]
                    ),
                    children: /* @__PURE__ */ o(
                      "div",
                      {
                        className: "fp-explorer-item",
                        "data-resource-id": q.id,
                        style: ae ? {
                          height: U === "list" ? 52 : 148,
                          marginBottom: U === "grid" ? 8 : 0,
                          boxSizing: "border-box"
                        } : void 0,
                        "data-selected": d.includes(q.id) || void 0,
                        draggable: !!y,
                        onDragStart: (V) => {
                          V.dataTransfer.setData(
                            "application/x-fiveplusone-resources",
                            JSON.stringify(
                              d.includes(q.id) ? d : [q.id]
                            )
                          ), V.dataTransfer.effectAllowed = "move";
                        },
                        onDoubleClick: (V) => {
                          V.target.closest(
                            "button,input,label"
                          ) || ue(q);
                        },
                        onClick: (V) => {
                          V.target.closest(
                            "button,input,label"
                          ) || G(q.id, V.shiftKey, V.ctrlKey || V.metaKey);
                        },
                        onDragOver: (V) => {
                          q.kind === "folder" && y && (V.preventDefault(), V.stopPropagation());
                        },
                        onDrop: (V) => {
                          if (q.kind === "folder")
                            if (V.preventDefault(), V.stopPropagation(), V.dataTransfer.files.length)
                              b?.(Array.from(V.dataTransfer.files), q.id);
                            else
                              try {
                                const oe = JSON.parse(
                                  V.dataTransfer.getData(
                                    "application/x-fiveplusone-resources"
                                  )
                                );
                                Array.isArray(oe) && oe.every((_) => typeof _ == "string") && W(oe, q.id) && y?.(oe, q.id);
                              } catch {
                              }
                        },
                        children: [
                          /* @__PURE__ */ e(
                            Kr,
                            {
                              label: "",
                              "aria-label": `选择${q.name}`,
                              checked: d.includes(q.id),
                              onClick: (V) => {
                                V.shiftKey && (V.preventDefault(), G(q.id, !0));
                              },
                              onChange: () => G(q.id, !1, !0)
                            }
                          ),
                          /* @__PURE__ */ o(
                            "button",
                            {
                              type: "button",
                              className: "fp-explorer-name",
                              "aria-label": q.name,
                              onClick: (V) => {
                                V.shiftKey || V.ctrlKey || V.metaKey ? G(q.id, V.shiftKey, V.ctrlKey || V.metaKey) : ue(q);
                              },
                              children: [
                                q.thumbnailUrl ? /* @__PURE__ */ e("img", { src: q.thumbnailUrl, alt: "" }) : q.kind === "folder" ? /* @__PURE__ */ e(vn, { size: U === "grid" ? 36 : 19 }) : /* @__PURE__ */ e(Ye, { size: U === "grid" ? 32 : 19 }),
                                /* @__PURE__ */ e("span", { children: q.name })
                              ]
                            }
                          ),
                          /* @__PURE__ */ e("small", { children: q.kind === "folder" ? "文件夹" : ap(q.size) }),
                          /* @__PURE__ */ e("time", { children: q.modifiedAt ? new Date(q.modifiedAt).toLocaleDateString(
                            "zh-CN"
                          ) : "" }),
                          /* @__PURE__ */ e(
                            bi,
                            {
                              label: `${q.name}的更多操作`,
                              icon: /* @__PURE__ */ e(Dt, { size: 16 }),
                              items: me(
                                d.includes(q.id) ? j : [q]
                              ).filter((V) => !V.disabled).map((V) => ({
                                label: V.label,
                                danger: V.danger,
                                onClick: () => V.onSelect?.()
                              }))
                            }
                          )
                        ]
                      }
                    )
                  },
                  q.id
                )),
                ae && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: Math.max(
                        0,
                        ne.getTotalSize() - (ye.at(-1)?.end || 0)
                      ),
                      gridColumn: "1 / -1"
                    }
                  }
                )
              ] }) : /* @__PURE__ */ e("p", { className: "fp-explorer-empty", children: O ? "没有找到匹配的文件" : "文件夹还是空的" }),
              N && /* @__PURE__ */ e(
                "div",
                {
                  "aria-hidden": "true",
                  className: "fp-explorer-selection-box",
                  style: {
                    position: "absolute",
                    left: N.left,
                    top: N.top,
                    width: N.width,
                    height: N.height,
                    pointerEvents: "none"
                  }
                }
              )
            ]
          }
        ) })
      }
    ),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("span", { children: d.length ? `已选择 ${d.length} 项` : `${E.length} 项` }),
      d.length > 0 && /* @__PURE__ */ e("button", { type: "button", onClick: () => p([]), children: "取消选择" })
    ] })
  ] });
}
function bm({
  items: t,
  selectedIds: n,
  onSelectionChange: r,
  onRestore: a,
  onDelete: i,
  loading: l,
  error: s
}) {
  const [c, u] = k(!1), [d, p] = k(""), h = B(!1), f = async (m, b = !1) => {
    if (!h.current) {
      h.current = !0, u(!0), p("");
      try {
        await (b ? i(m) : a(m));
      } finally {
        h.current = !1, u(!1);
      }
    }
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "回收站" }),
        /* @__PURE__ */ e("small", { children: "还需要的资料可以恢复到原位置。" })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          be,
          {
            disabled: c || !n.length,
            onAction: () => f(n),
            children: "恢复所选"
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            disabled: c || !n.length,
            confirm: "永久删除所选资料后将无法恢复，确认继续？",
            onAction: () => f(n, !0),
            children: "永久删除"
          }
        )
      ] })
    ] }),
    (s || d) && /* @__PURE__ */ e("p", { role: "alert", children: s || d }),
    l ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取回收站…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((m) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ e(
      gt,
      {
        disabled: c,
        items: [
          {
            id: "restore",
            label: "恢复",
            onSelect: () => {
              f([m.id]).catch(
                (b) => p(
                  b instanceof Error ? b.message : "暂时无法恢复，请重试。"
                )
              );
            }
          },
          {
            id: "select",
            label: "选择",
            onSelect: () => r([m.id])
          }
        ],
        children: /* @__PURE__ */ o("div", { className: "fp-recycle-row", children: [
          /* @__PURE__ */ e(
            Kr,
            {
              label: "",
              "aria-label": `选择${m.name}`,
              checked: n.includes(m.id),
              disabled: c,
              onChange: () => r(
                n.includes(m.id) ? n.filter((b) => b !== m.id) : [...n, m.id]
              )
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: m.name }),
            /* @__PURE__ */ e("small", { children: m.originalPath })
          ] }),
          /* @__PURE__ */ e("time", { children: m.deletedAt }),
          m.size && /* @__PURE__ */ e("small", { children: m.size })
        ] })
      }
    ) }, m.id)) }) : /* @__PURE__ */ e("p", { children: "回收站是空的。" })
  ] });
}
function gm({
  items: t,
  onReview: n,
  onPreview: r,
  loading: a,
  error: i
}) {
  const [l, s] = k("all"), c = t.filter(
    (u) => l === "all" || u.status === l
  );
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "今日复习" }),
        /* @__PURE__ */ o("small", { children: [
          t.length,
          " 条学习记录"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: !c.length || a,
          onClick: () => n(c.map((u) => u.id)),
          children: "开始复习"
        }
      )
    ] }),
    /* @__PURE__ */ e(
      we,
      {
        label: "复习范围",
        value: l,
        onChange: s,
        options: [
          { value: "all", label: "全部记录" },
          { value: "new", label: "初次学习" },
          { value: "learning", label: "正在巩固" },
          { value: "review", label: "定期复习" }
        ]
      }
    ),
    i && /* @__PURE__ */ e("p", { role: "alert", children: i }),
    a ? /* @__PURE__ */ e("p", { role: "status", children: "正在整理复习记录…" }) : /* @__PURE__ */ e("ul", { children: c.map((u) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-review-record",
        onClick: () => r(u.id),
        children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: u.title }),
            /* @__PURE__ */ o("small", { children: [
              u.subject,
              u.detail && ` · ${u.detail}`
            ] })
          ] }),
          /* @__PURE__ */ e("time", { children: u.due })
        ]
      }
    ) }, u.id)) }),
    !a && !c.length && /* @__PURE__ */ e("p", { children: "当前范围没有待复习的记录。" })
  ] });
}
function ym({
  title: t,
  items: n,
  activeId: r,
  onNavigate: a,
  children: i,
  onSubmit: l,
  remainingLabel: s
}) {
  const c = n.filter((u) => u.answered).length;
  return /* @__PURE__ */ o("section", { className: "fp-quiz-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("span", { children: s || `已完成 ${c} / ${n.length} 题` })
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "题目导航", children: n.map((u) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": u.id === r ? "step" : void 0,
        "data-answered": u.answered || void 0,
        onClick: () => a(u.id),
        children: [
          u.label,
          u.flagged && /* @__PURE__ */ e("span", { "aria-label": "已标记", children: " ·" })
        ]
      },
      u.id
    )) }),
    /* @__PURE__ */ e(fe, { children: i }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        confirm: c < n.length ? `还有 ${n.length - c} 题未完成，仍要提交？` : "确认提交本次答题？",
        onAction: l,
        children: "提交答题"
      }
    ) })
  ] });
}
function vm({
  items: t
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-selection-actions",
      role: "toolbar",
      "aria-label": "所选内容操作",
      children: t.map((n) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n.disabled,
          onMouseDown: (r) => r.preventDefault(),
          onClick: n.onSelect,
          children: n.label
        },
        n.id
      ))
    }
  );
}
function wm({
  title: t,
  detail: n,
  value: r,
  onCancel: a,
  children: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-live": "polite", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "取消" })
    ] }),
    n && /* @__PURE__ */ e("p", { children: n }),
    /* @__PURE__ */ e(
      "progress",
      {
        "aria-label": t,
        max: 100,
        value: r === void 0 ? void 0 : Math.min(100, Math.max(0, r))
      }
    ),
    i
  ] });
}
function km({
  title: t = "打开一份资料，开始学习",
  description: n = "可以从左侧选择笔记，也可以添加新的资料。",
  actions: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-empty", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r })
  ] });
}
function Nm({
  title: t,
  status: n,
  actions: r,
  trace: a,
  children: i,
  attachments: l
}) {
  const [s, c] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-run-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] }),
      r
    ] }),
    i,
    l && /* @__PURE__ */ e("aside", { "aria-label": "相关资料", children: l }),
    a && /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": s,
          onClick: () => c((u) => !u),
          children: "工作记录"
        }
      ),
      /* @__PURE__ */ e(Oe, { isOpen: s, children: a })
    ] })
  ] });
}
function xm({
  title: t,
  frames: n,
  time: r,
  duration: a,
  playing: i,
  onTimeChange: l,
  onPlayingChange: s,
  children: c
}) {
  return /* @__PURE__ */ o("section", { className: "fp-recording-playback", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => s(!i), children: i ? "暂停回放" : "播放回放" })
    ] }),
    /* @__PURE__ */ e("div", { children: c }),
    /* @__PURE__ */ o("label", { children: [
      "回放进度",
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0,
          max: Math.max(0, a),
          step: "0.1",
          value: Math.min(a, Math.max(0, r)),
          onChange: (u) => l(Number(u.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "回放关键帧", children: n.map((u, d) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-current": n.filter((p) => p.time <= r).at(-1) === u ? "step" : void 0,
        onClick: () => l(u.time),
        children: u.label
      },
      d
    )) })
  ] });
}
function Cm({
  title: t = "分享与协作",
  access: n,
  search: r,
  onAddMember: a,
  link: i,
  permissionSummary: l
}) {
  const [s, c] = k(!1), [u, d] = k(""), p = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-access-panel", "aria-busy": s, children: [
    /* @__PURE__ */ e("h3", { children: t }),
    l,
    n.canManage && /* @__PURE__ */ e(
      qu,
      {
        ...r,
        disabled: s,
        excludedIds: n.members.map((h) => h.id),
        onPick: (h, f) => {
          p.current || (p.current = !0, c(!0), d(""), Promise.resolve().then(() => a(h, f)).catch(
            (m) => d(
              m instanceof Error ? m.message : "暂时无法添加成员，请重试。"
            )
          ).finally(() => {
            p.current = !1, c(!1);
          }));
        }
      }
    ),
    u && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: u }),
    /* @__PURE__ */ e(ju, { ...n }),
    /* @__PURE__ */ e(Ku, { ...i, disabled: i.disabled || !n.canManage })
  ] });
}
function Sm({
  models: t,
  modelId: n,
  onModelChange: r,
  thinking: a,
  thinkingOptions: i,
  onThinkingChange: l,
  webEnabled: s,
  onWebChange: c,
  disabled: u,
  quota: d,
  children: p
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "对话设置" }),
    /* @__PURE__ */ o("div", { className: "fp-chat-preferences", children: [
      /* @__PURE__ */ o("label", { children: [
        "使用模型",
        /* @__PURE__ */ e(
          Wu,
          {
            groups: t,
            value: n,
            onChange: r,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "思考方式",
        /* @__PURE__ */ e(
          we,
          {
            label: "思考方式",
            value: a,
            options: i,
            onChange: l,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ e(
        sp,
        {
          label: "联网查找资料",
          checked: s,
          onChange: c,
          disabled: u
        }
      ),
      d,
      p
    ] })
  ] });
}
function Mm({
  explorer: t,
  preview: n,
  previewTitle: r = "资料预览",
  actions: a
}) {
  const [i, l] = k("files");
  return /* @__PURE__ */ o("section", { className: "fp-resource-workspace", children: [
    /* @__PURE__ */ e("div", { className: "fp-resource-mobile-switch", children: /* @__PURE__ */ e(
      up,
      {
        value: i,
        onChange: l,
        items: [
          { value: "files", label: "文件" },
          { value: "preview", label: r }
        ]
      }
    ) }),
    /* @__PURE__ */ o("div", { className: "fp-resource-workspace-panes", "data-pane": i, children: [
      /* @__PURE__ */ e("aside", { children: /* @__PURE__ */ e(
        ip,
        {
          ...t,
          onOpen: (s) => {
            t.onOpen(s), l("preview");
          }
        }
      ) }),
      /* @__PURE__ */ o("section", { "aria-label": r, children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("h3", { children: r }),
          a
        ] }),
        /* @__PURE__ */ e(fe, { children: n })
      ] })
    ] })
  ] });
}
function Em(t, n) {
  const r = document.createElement("header");
  r.style.cssText = "position:fixed;inset:0 0 auto;height:36px;z-index:2147483647";
  const a = r.attachShadow({ mode: "open" });
  a.innerHTML = '<style>:host{color-scheme:inherit}nav{height:36px;display:flex;align-items:center;background:var(--window-bar-background,light-dark(#f5f3f8,#211f26));color:var(--window-bar-color,light-dark(#29252f,#e7e0ed));font:12px system-ui;user-select:none;-webkit-app-region:drag}span{flex:1;padding:0 12px;pointer-events:none}button{width:46px;height:36px;border:0;background:transparent;color:inherit;font:16px system-ui;-webkit-app-region:no-drag;cursor:default}button:hover{background:light-dark(#e2dfe7,#3c3844)}button:focus-visible{outline:2px solid #a78bfa;outline-offset:-3px}button:last-child:hover{background:#c42b1c;color:white}</style><nav aria-label="窗口"><button aria-label="课栈菜单">☰</button><span></span><button aria-label="最小化">−</button><button aria-label="最大化">□</button><button aria-label="关闭窗口">×</button></nav>', a.querySelector("span").textContent = n;
  const i = a.querySelectorAll("button");
  i[0].onclick = () => t.openMenu(), i[1].onclick = () => t.minimize(), i[2].onclick = () => t.toggleMaximize(), i[3].onclick = () => t.closeWindow();
  const l = (c) => {
    i[2].textContent = c.maximized ? "❐" : "□", i[2].setAttribute("aria-label", c.maximized ? "还原窗口" : "最大化"), r.hidden = c.fullscreen, document.documentElement.style.setProperty("--desktop-titlebar-height", c.fullscreen ? "0px" : "36px");
  };
  document.body.prepend(r);
  const s = t.onWindowState(l);
  return t.getWindowState().then(l), () => {
    s(), r.remove();
  };
}
function $m({ maximized: t, fullscreen: n, onMinimize: r, onMaximize: a, onClose: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-window-controls", role: "group", "aria-label": "窗口操作", children: [
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "最小化", onClick: r, children: /* @__PURE__ */ e(Tt, { size: 16 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": n ? "退出全屏" : t ? "还原窗口" : "最大化", onClick: a, children: t || n ? /* @__PURE__ */ e(jn, { size: 14 }) : /* @__PURE__ */ e(qn, { size: 14 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭窗口", onClick: i, children: /* @__PURE__ */ e(ge, { size: 18 }) })
  ] });
}
function zm({ enabled: t = !1, as: n = "header", children: r, className: a = "", ...i }) {
  return /* @__PURE__ */ e(n, { ...i, className: `${a}${t ? " fp-window-drag-region" : ""}`, children: r });
}
function Im({ name: t, description: n, items: r, onSelect: a, busy: i = !1 }) {
  return /* @__PURE__ */ e("span", { className: "fp-account-menu-anchor", children: /* @__PURE__ */ e(Qe, { label: "账号与设置", menu: !0, className: "fp-account-menu", disabled: i, trigger: /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: t.trim().slice(0, 1).toUpperCase() || "我" }), children: (l) => /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ o("div", { className: "fp-account-menu-identity", children: [
      /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: t.trim().slice(0, 1).toUpperCase() || "我" }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: t }),
        n && /* @__PURE__ */ e("small", { children: n })
      ] })
    ] }),
    r.map((s) => /* @__PURE__ */ e("div", { className: s.separator ? "fp-account-menu-group" : void 0, children: /* @__PURE__ */ o("button", { type: "button", role: "menuitem", disabled: s.disabled, className: s.danger ? "fp-error-text" : void 0, onClick: () => {
      l(), a(s.id);
    }, children: [
      s.icon,
      /* @__PURE__ */ e("span", { children: s.label }),
      (s.detail || s.shortcut) && /* @__PURE__ */ e("small", { children: s.detail || s.shortcut })
    ] }) }, s.id))
  ] }) }) });
}
function Am({ label: t, value: n, options: r, onChange: a }) {
  const i = Ne();
  return /* @__PURE__ */ o("fieldset", { className: "fp-choice-cards", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    r.map((l) => /* @__PURE__ */ o("label", { "data-selected": n === l.value, "data-disabled": l.disabled || void 0, children: [
      /* @__PURE__ */ e("input", { type: "radio", name: i, value: l.value, checked: n === l.value, disabled: l.disabled, onChange: () => a(l.value) }),
      l.icon && /* @__PURE__ */ e("span", { className: "fp-choice-card-icon", "aria-hidden": "true", children: l.icon }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: l.title }),
        /* @__PURE__ */ e("small", { children: l.description })
      ] })
    ] }, l.value))
  ] });
}
function Lm({ brand: t, headerActions: n, serviceName: r, request: a, completed: i, onDone: l, doneLabel: s = "返回应用", codeEntry: c, selectedIds: u = [], onSelectionChange: d, onApprove: p, onCancel: h, connections: f = [], onRevoke: m, loading: b, busy: y, error: w, onRetry: v }) {
  const [g, x] = k(""), N = He(() => a?.items.filter((T) => T.title.toLocaleLowerCase().includes(g.trim().toLocaleLowerCase())) || [], [g, a?.items]), C = new Set(u), A = N.length > 0 && N.every((T) => C.has(T.id)), L = a?.kind === "task", U = a?.kind === "change", S = L || U ? "内容" : "笔记本", I = () => d?.(A ? u.filter((T) => !N.some((H) => H.id === T)) : [.../* @__PURE__ */ new Set([...u, ...N.map((T) => T.id)])]);
  return /* @__PURE__ */ o("div", { className: "fp-application-access", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#access-main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-access-header", children: [
      /* @__PURE__ */ e("div", { children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "账号与外观", children: n })
    ] }),
    /* @__PURE__ */ e("main", { id: "access-main", className: a ? "fp-access-main" : "fp-access-main fp-access-management", children: b ? /* @__PURE__ */ o("section", { className: "fp-access-loading", role: "status", children: [
      /* @__PURE__ */ e(fi, { size: 28 }),
      /* @__PURE__ */ e("h1", { children: "正在读取连接信息" }),
      /* @__PURE__ */ e("p", { children: "请稍候，马上就好。" })
    ] }) : i ? /* @__PURE__ */ o("section", { className: "fp-access-card fp-access-completed", role: "status", children: [
      /* @__PURE__ */ e(mt, { size: 40, "aria-hidden": "true" }),
      /* @__PURE__ */ e("h1", { children: i.title }),
      /* @__PURE__ */ e("p", { children: i.description }),
      l && /* @__PURE__ */ e(le, { onClick: l, children: s })
    ] }) : a ? /* @__PURE__ */ o("section", { className: "fp-access-card", "aria-labelledby": "access-title", children: [
      /* @__PURE__ */ o("header", { className: "fp-access-intro", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-symbols", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(ht, { size: 28 }) }),
          /* @__PURE__ */ e(zr, { size: 20 }),
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(ft, { size: 26 }) })
        ] }),
        /* @__PURE__ */ o("p", { className: "fp-eyebrow", children: [
          r,
          " · 应用授权"
        ] }),
        /* @__PURE__ */ e("h1", { id: "access-title", children: U ? `确认 ${a.name} 的修改？` : L ? `允许 ${a.name} 完成这项任务？` : `允许 ${a.name} 连接${r}？` }),
        /* @__PURE__ */ e("p", { children: a.purpose || (U ? "查看具体变更，确认后助手将继续执行。" : L ? "助手申请以下内容和操作，确认后即可继续。" : "选择允许访问的笔记本，让它在你指定的范围内提供帮助。") }),
        a.returnLabel && /* @__PURE__ */ o("p", { className: "fp-access-return", children: [
          "完成后返回 ",
          a.returnLabel
        ] })
      ] }),
      a.permissions.length > 0 && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ e("h2", { children: "允许的操作" }),
        /* @__PURE__ */ e("ul", { className: "fp-access-permissions", children: a.permissions.map((T) => /* @__PURE__ */ o("li", { children: [
          /* @__PURE__ */ e(mt, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("strong", { children: T.label }),
            T.description && /* @__PURE__ */ e("p", { children: T.description })
          ] })
        ] }, T.label)) })
      ] }),
      (!a.allowEmptySelection || a.items.length > 0) && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-section-heading", children: [
          /* @__PURE__ */ e("h2", { children: L ? "申请访问的内容" : U ? "本次修改" : "选择笔记本" }),
          /* @__PURE__ */ o("span", { role: "status", children: [
            "已选 ",
            u.length,
            " 项"
          ] })
        ] }),
        /* @__PURE__ */ o("label", { className: "fp-access-search", children: [
          /* @__PURE__ */ e(Je, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ e("input", { className: "fp-input", "aria-label": `搜索${S}`, placeholder: `搜索${S}`, value: g, onChange: (T) => x(T.target.value) })
        ] }),
        a.items.length > 0 ? /* @__PURE__ */ o(Z, { children: [
          /* @__PURE__ */ o("div", { className: "fp-access-select", children: [
            /* @__PURE__ */ e("span", { children: g ? `找到 ${N.length} 项内容` : `只访问你选中的${S}` }),
            !U && /* @__PURE__ */ e(le, { variant: "ghost", disabled: y || !N.length, onClick: I, children: A ? "取消全选" : "全选" })
          ] }),
          /* @__PURE__ */ o("fieldset", { className: "fp-access-items", disabled: y, children: [
            /* @__PURE__ */ e("legend", { className: "fp-visually-hidden", children: "可访问的内容" }),
            N.map((T) => /* @__PURE__ */ o("label", { "data-selected": C.has(T.id), children: [
              /* @__PURE__ */ e("input", { type: "checkbox", disabled: U, checked: C.has(T.id), onChange: (H) => d?.(H.target.checked ? [...u, T.id] : u.filter((R) => R !== T.id)) }),
              /* @__PURE__ */ e(ht, { size: 19, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { className: "fp-access-item-copy", children: [
                /* @__PURE__ */ e("strong", { children: T.title }),
                T.detail && /* @__PURE__ */ e("small", { children: T.detail }),
                T.permissions && /* @__PURE__ */ e("small", { children: T.permissions.join("、") })
              ] }),
              C.has(T.id) && /* @__PURE__ */ e(mt, { size: 18, "aria-hidden": "true" })
            ] }, T.id)),
            N.length === 0 && /* @__PURE__ */ e("p", { className: "fp-access-empty", children: "没有找到匹配的内容，试试其他名称。" })
          ] })
        ] }) : /* @__PURE__ */ o("p", { className: "fp-access-empty", children: [
          "当前没有可授权的内容，请先在",
          r,
          "取得访问权限。"
        ] })
      ] }),
      a.changes && /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: "查看正文变化" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: a.changes.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: a.changes.after })
          ] })
        ] })
      ] }),
      a.changeSet?.map((T, H) => /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: T.title }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: T.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: T.after })
          ] })
        ] })
      ] }, H)),
      /* @__PURE__ */ o("aside", { className: "fp-access-notice", children: [
        /* @__PURE__ */ e(ei, { size: 21, "aria-hidden": "true" }),
        /* @__PURE__ */ e("p", { children: a.notice || "授权有效期为 30 天，包含所选笔记本中后续新增的内容。你可以随时在“外部连接”撤销访问。" })
      ] }),
      w && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: w }),
        v && /* @__PURE__ */ e(le, { variant: "secondary", disabled: y, onClick: v, children: "重试" })
      ] }),
      /* @__PURE__ */ o("footer", { className: "fp-access-actions", children: [
        /* @__PURE__ */ e(le, { variant: "secondary", disabled: y, onClick: h, children: "取消" }),
        /* @__PURE__ */ e(le, { "aria-label": U ? "确认修改" : L ? "同意并继续" : "允许连接", loading: y, disabled: b || !a.allowEmptySelection && !u.length, onClick: p, children: U ? "确认修改" : L ? "同意并继续" : "允许连接" })
      ] })
    ] }) : /* @__PURE__ */ o(Z, { children: [
      c && /* @__PURE__ */ o("form", { className: "fp-access-device-entry", onSubmit: (T) => {
        T.preventDefault(), c.onSubmit();
      }, children: [
        /* @__PURE__ */ e("label", { htmlFor: "access-device-code", children: "连接新设备" }),
        /* @__PURE__ */ e("p", { children: "输入终端中显示的设备代码。" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("input", { className: "fp-input", id: "access-device-code", value: c.value, onChange: (T) => c.onChange(T.target.value), placeholder: "ABCD-EFGH", autoComplete: "off", spellCheck: !1, maxLength: 9 }),
          /* @__PURE__ */ e(le, { type: "submit", disabled: c.value.replace(/-/g, "").trim().length !== 8, children: "继续" })
        ] })
      ] }),
      /* @__PURE__ */ o("header", { className: "fp-access-list-heading", children: [
        /* @__PURE__ */ e("span", { className: "fp-access-list-icon", children: /* @__PURE__ */ e(ft, { size: 28 }) }),
        /* @__PURE__ */ e("h1", { children: "已连接的应用" }),
        /* @__PURE__ */ o("p", { children: [
          "查看哪些应用可以访问你的",
          r,
          "内容，并随时管理连接。"
        ] })
      ] }),
      w && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        w,
        v && /* @__PURE__ */ e(le, { variant: "secondary", onClick: v, children: "重试" })
      ] }),
      f.length ? /* @__PURE__ */ e("div", { className: "fp-access-connections", children: f.map((T) => /* @__PURE__ */ o("section", { className: "fp-access-connection", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-connection-title", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(ft, { size: 22 }) }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("h2", { children: T.name }),
            /* @__PURE__ */ e("p", { "data-status": T.status, children: T.status === "active" ? "已连接" : T.status === "revoked" ? "已撤销" : "已过期" })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { children: T.permissions }),
        /* @__PURE__ */ e("p", { className: "fp-access-detail", children: T.detail }),
        T.status === "active" && /* @__PURE__ */ e(le, { variant: "secondary", disabled: y, onClick: () => m?.(T.id), children: "撤销连接" })
      ] }, T.id)) }) : !w && /* @__PURE__ */ o("section", { className: "fp-access-empty-state", children: [
        /* @__PURE__ */ e(ht, { size: 32 }),
        /* @__PURE__ */ e("h2", { children: "从第一个连接开始" }),
        /* @__PURE__ */ e("p", { children: "通过 CLI 或支持的 AI 助手发起连接，授权后会显示在这里。" })
      ] })
    ] }) })
  ] });
}
function Tm({ brand: t, showStatusIcon: n = !0, preview: r, productIcon: a, headerActions: i, onDrag: l, phase: s, transitionKey: c, title: u, description: d, version: p, progress: h, progressLabel: f, detail: m, children: b, actions: y, footer: w }) {
  const v = s + ":" + (c || ""), g = B(null), x = B(v);
  Y(() => {
    if (x.current === v) return;
    x.current = v;
    const U = g.current;
    if (!U || typeof U.animate != "function" || window.matchMedia?.("(prefers-reduced-motion:reduce)").matches) return;
    const S = U.animate([{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }], { duration: 320, easing: "cubic-bezier(.22,1,.36,1)" });
    return () => S.cancel();
  }, [v]);
  const N = ["checking", "verifying", "installing"].includes(s), C = s === "downloading" && Number.isFinite(h), A = Math.max(0, Math.min(100, C ? h : 0)), L = f || (s === "checking" ? "正在连接下载服务" : s === "verifying" ? "正在检查文件完整性" : s === "installing" ? "正在安装到此电脑" : "正在下载");
  return /* @__PURE__ */ o("div", { className: "fp-installer", "data-phase": s, "data-preview": !!r, children: [
    /* @__PURE__ */ o("header", { onMouseDown: (U) => {
      U.target.closest("button,a,input") || l?.();
    }, children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: i })
    ] }),
    /* @__PURE__ */ o("main", { children: [
      r && /* @__PURE__ */ e("aside", { className: "fp-installer-preview", children: r }),
      /* @__PURE__ */ o("section", { ref: g, className: "fp-installer-content", children: [
        /* @__PURE__ */ o("div", { className: "fp-installer-heading", children: [
          n && /* @__PURE__ */ e("div", { className: "fp-installer-art", "aria-hidden": "true", children: s === "ready" && a ? a : N ? /* @__PURE__ */ e(Pt, { size: 28 }) : s === "done" ? /* @__PURE__ */ e(mt, { size: 28 }) : s === "error" || s === "confirm" ? /* @__PURE__ */ e(Ir, { size: 28 }) : s === "downloading" ? /* @__PURE__ */ e(kn, { size: 28 }) : /* @__PURE__ */ e(So, { size: 28 }) }),
          /* @__PURE__ */ o("div", { children: [
            p && /* @__PURE__ */ o("p", { className: "fp-installer-version", children: [
              "版本 ",
              p
            ] }),
            /* @__PURE__ */ e("h1", { children: u })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { className: "fp-installer-description", role: s === "error" ? "alert" : "status", children: d }),
        (N || s === "downloading") && /* @__PURE__ */ o("div", { className: "fp-installer-progress", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("span", { children: L }),
            C && /* @__PURE__ */ o("strong", { children: [
              Math.round(A),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": s === "downloading" ? "安装文件下载进度" : L, "data-indeterminate": !C, "aria-valuenow": C ? A : void 0, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: C ? { width: `${A}%` } : void 0 }) })
        ] }),
        m && /* @__PURE__ */ e("p", { className: "fp-installer-detail", children: m }),
        b,
        /* @__PURE__ */ e("div", { className: "fp-installer-actions", children: y })
      ] })
    ] }),
    w && /* @__PURE__ */ e("footer", { children: w })
  ] });
}
function Dm({ cards: t, activeId: n, onSelect: r }) {
  const a = t.find((d) => d.id === n) || t[0], i = B(a?.id), [l, s] = k();
  if (Y(() => {
    if (!a || i.current === a.id) return;
    s(i.current), i.current = a.id;
    const d = setTimeout(() => s(void 0), 650);
    return () => clearTimeout(d);
  }, [a?.id]), !a) return null;
  const c = t.find((d) => d.id === l), u = (d) => /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-feature-card-copy", children: [
      /* @__PURE__ */ e("h2", { children: d.title }),
      /* @__PURE__ */ e("p", { children: d.description })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-preview", children: d.children })
  ] });
  return /* @__PURE__ */ o("section", { className: "fp-feature-stack", "aria-label": "产品功能预览", children: [
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back", "aria-hidden": "true" }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back fp-feature-card-back-second", "aria-hidden": "true" }),
    c && /* @__PURE__ */ e("article", { className: "fp-feature-card-out", "aria-hidden": "true", children: u(c) }, "out-" + c.id),
    /* @__PURE__ */ e("article", { className: "fp-feature-card-front", "data-motion": a.motion, "aria-label": a.title, children: u(a) }, a.id),
    /* @__PURE__ */ e("footer", { "aria-hidden": r ? void 0 : !0, role: r ? "group" : void 0, "aria-label": r ? "产品卡片切换" : void 0, children: t.map((d) => r ? /* @__PURE__ */ e("button", { type: "button", "aria-label": "查看" + d.label, "aria-pressed": d.id === a.id, onClick: () => r(d.id), children: /* @__PURE__ */ e("i", { "data-active": d.id === a.id, "aria-hidden": "true" }) }, d.id) : /* @__PURE__ */ e("i", { "data-active": d.id === a.id }, d.id)) })
  ] });
}
function Pm({ brand: t, navigation: n, actions: r, groups: a, currentPath: i, outline: l = [], children: s, footer: c, wide: u = !1 }) {
  const d = B(null), p = /* @__PURE__ */ e("nav", { "aria-label": "文档章节", children: a.map((h) => /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h2", { children: h.label }),
    h.links.map((f) => /* @__PURE__ */ e("a", { href: f.href, "aria-current": f.href === i ? "page" : void 0, children: f.label }, f.href))
  ] }, h.label)) });
  return /* @__PURE__ */ o("div", { className: "fp-docs", "data-wide": u || void 0, children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-docs-header", children: [
      /* @__PURE__ */ e("div", { className: "fp-docs-brand", children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "主导航", children: n }),
      /* @__PURE__ */ o("div", { className: "fp-docs-actions", children: [
        r,
        /* @__PURE__ */ e(le, { variant: "ghost", "aria-label": "打开文档目录", className: "fp-docs-menu", onClick: () => d.current?.showModal(), children: /* @__PURE__ */ e(Er, { size: 20 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("dialog", { ref: d, className: "fp-docs-drawer", onClick: (h) => {
      h.target === h.currentTarget && d.current?.close();
    }, children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: "文档目录" }),
        /* @__PURE__ */ e(le, { variant: "ghost", "aria-label": "关闭文档目录", onClick: () => d.current?.close(), children: /* @__PURE__ */ e(ge, { size: 20 }) })
      ] }),
      p
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-docs-grid", children: [
      !u && /* @__PURE__ */ e("aside", { className: "fp-docs-sidebar", children: p }),
      /* @__PURE__ */ e("main", { id: "main", className: "fp-docs-main", children: s }),
      !u && l.length > 0 && /* @__PURE__ */ e("aside", { className: "fp-docs-outline", children: /* @__PURE__ */ o("nav", { "aria-label": "本页目录", children: [
        /* @__PURE__ */ e("strong", { children: "本页目录" }),
        l.map((h) => /* @__PURE__ */ e("a", { href: h.href, children: h.label }, h.href))
      ] }) })
    ] }),
    c && /* @__PURE__ */ e("footer", { className: "fp-docs-footer", children: c })
  ] });
}
function Om({ items: t, label: n = "浏览文档" }) {
  const [r, a] = k(""), i = t.filter((l) => (l.label + " " + (l.description || "")).toLocaleLowerCase().includes(r.trim().toLocaleLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-docs-directory", "aria-label": n, children: [
    /* @__PURE__ */ o("label", { children: [
      n,
      /* @__PURE__ */ e("input", { type: "search", value: r, onChange: (l) => a(l.target.value), placeholder: "输入名称查找" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-docs-cards", children: i.map((l) => /* @__PURE__ */ o("a", { href: l.href, children: [
      /* @__PURE__ */ e("strong", { children: l.label }),
      l.description && /* @__PURE__ */ e("span", { children: l.description }),
      /* @__PURE__ */ e("span", { children: "阅读指南 →" })
    ] }, l.href)) }),
    !i.length && /* @__PURE__ */ e("p", { role: "status", children: "没有找到相关内容，请换个名称试试。" })
  ] });
}
function Fm({ variant: t = "primary", size: n = "md", className: r = "", ...a }) {
  return /* @__PURE__ */ e("a", { ...a, className: `fp-button fp-button-link fp-${t} fp-${n} ${r}` });
}
function Rm({ brand: t, eyebrow: n, title: r, description: a, benefits: i = [], children: l, actions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-app-entry", children: [
    /* @__PURE__ */ o("section", { className: "fp-app-entry-story", children: [
      /* @__PURE__ */ e("div", { className: "fp-app-entry-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-app-entry-copy", children: [
        n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
        /* @__PURE__ */ e("h1", { children: r }),
        /* @__PURE__ */ e("p", { children: a }),
        /* @__PURE__ */ e("ul", { children: i.map((u) => /* @__PURE__ */ o("li", { children: [
          u.icon,
          /* @__PURE__ */ e("span", { children: u.label })
        ] }, u.label)) })
      ] }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-app-entry-panel", children: [
      s && /* @__PURE__ */ e("div", { className: "fp-app-entry-window", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-app-entry-content", children: l })
    ] })
  ] });
}
function Bm({ brand: t, title: n, description: r, tone: a = "neutral", children: i, actions: l, headerActions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-status-page", children: [
    /* @__PURE__ */ o("header", { className: "fp-status-page-header", children: [
      t,
      /* @__PURE__ */ e("div", { children: s })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-status-card", "data-tone": a, "aria-labelledby": "status-heading", children: [
      /* @__PURE__ */ e("div", { className: "fp-status-symbol", "aria-hidden": "true", children: a === "success" ? /* @__PURE__ */ e(mt, { size: 32 }) : a === "loading" ? /* @__PURE__ */ e(Pt, { size: 32 }) : /* @__PURE__ */ e(Ir, { size: 32 }) }),
      /* @__PURE__ */ e("h1", { id: "status-heading", children: n }),
      /* @__PURE__ */ e("p", { className: "fp-status-description", role: a === "error" ? "alert" : "status", children: r }),
      i,
      l && /* @__PURE__ */ e("div", { className: "fp-status-actions", children: l }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] })
  ] });
}
function jm({ brand: t, navigation: n, headerActions: r, eyebrow: a, title: i, description: l, actions: s, meta: c, preview: u, children: d, footer: p }) {
  return /* @__PURE__ */ o("div", { className: "fp-product-landing", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ e("header", { className: "fp-product-header", children: /* @__PURE__ */ o("div", { className: "fp-product-header-inner", children: [
      t,
      /* @__PURE__ */ e("nav", { "aria-label": "页面导航", children: n }),
      /* @__PURE__ */ e("div", { className: "fp-product-header-actions", children: r })
    ] }) }),
    /* @__PURE__ */ o("main", { id: "main", children: [
      /* @__PURE__ */ o("section", { className: "fp-product-hero", children: [
        /* @__PURE__ */ o("div", { className: "fp-product-hero-copy", children: [
          a && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: a }),
          /* @__PURE__ */ e("h1", { children: i }),
          /* @__PURE__ */ e("p", { className: "fp-product-description", children: l }),
          /* @__PURE__ */ e("div", { className: "fp-product-actions", children: s }),
          c && /* @__PURE__ */ e("div", { className: "fp-product-meta", children: c })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-product-preview", children: u })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("footer", { className: "fp-product-footer", children: p })
  ] });
}
function qm({ id: t, eyebrow: n, title: r, description: a, children: i }) {
  return /* @__PURE__ */ o("section", { id: t, className: "fp-product-section", children: [
    /* @__PURE__ */ o("header", { children: [
      n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
      /* @__PURE__ */ e("h2", { children: r }),
      a && /* @__PURE__ */ e("p", { children: a })
    ] }),
    i
  ] });
}
function Km({ items: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-product-features", children: t.map((n) => /* @__PURE__ */ o("article", { children: [
    /* @__PURE__ */ e("div", { className: "fp-product-feature-icon", children: n.icon }),
    /* @__PURE__ */ e("h3", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function Um({ brand: t = "课栈笔记", label: n = "正在打开工作区", actions: r }) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton", role: "status", "aria-label": n, "aria-busy": "true", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: r })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton-body", children: [
      /* @__PURE__ */ o("aside", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] })
    ] })
  ] });
}
function Hm({ phase: t, title: n, description: r, currentVersion: a, version: i, notes: l, progress: s = 0, required: c = !1, compact: u = !1, actions: d }) {
  const p = Math.max(0, Math.min(100, Number.isFinite(s) ? s : 0));
  return /* @__PURE__ */ o("section", { className: "fp-update-panel", "data-phase": t, "data-compact": u || void 0, children: [
    /* @__PURE__ */ o("div", { className: "fp-update-art", "aria-hidden": "true", children: [
      /* @__PURE__ */ e("span", { children: ["checking", "preparing", "verifying", "installing"].includes(t) ? /* @__PURE__ */ e(Pt, { size: 34 }) : t === "error" ? /* @__PURE__ */ e(Ir, { size: 34 }) : t === "ready" || t === "current" ? /* @__PURE__ */ e(mt, { size: 34 }) : t === "downloading" ? /* @__PURE__ */ e(kn, { size: 34 }) : /* @__PURE__ */ e(Bn, { size: 34 }) }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-update-heading", children: [
      c && /* @__PURE__ */ e("span", { className: "fp-update-required", children: "需要更新" }),
      /* @__PURE__ */ e("h3", { children: n }),
      /* @__PURE__ */ e("p", { role: t === "error" ? "alert" : "status", children: r })
    ] }),
    (a || i) && /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: a || "—" })
      ] }),
      i && /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e(zr, { size: 18, "aria-hidden": "true" }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("small", { children: "最新版本" }),
          /* @__PURE__ */ e("strong", { children: i })
        ] })
      ] })
    ] }),
    l && /* @__PURE__ */ o("section", { className: "fp-update-notes", children: [
      /* @__PURE__ */ e("h4", { children: "本次更新" }),
      /* @__PURE__ */ e("p", { children: l })
    ] }),
    t === "downloading" && /* @__PURE__ */ o("div", { className: "fp-update-progress", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { children: "正在下载" }),
        /* @__PURE__ */ o("strong", { children: [
          Math.round(p),
          "%"
        ] })
      ] }),
      /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": "更新下载进度", "aria-valuenow": p, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: { width: `${p}%` } }) })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-update-actions", children: d })
  ] });
}
function _m({ tasks: t, title: n = "传输任务", variant: r = "panel", showHeader: a = !0, onCancel: i, onRetry: l, onDismiss: s, onOpen: c, onReveal: u, headerActions: d, collapsed: p = !1, onCollapsedChange: h }) {
  const f = t.filter((m) => m.status === "queued" || m.status === "active").length;
  return p ? /* @__PURE__ */ o(le, { className: "fp-transfer-summary", variant: "secondary", "aria-label": `展开${n}（${t.length}）`, "aria-expanded": !1, onClick: () => h?.(!1), children: [
    /* @__PURE__ */ e(kn, { size: 17 }),
    /* @__PURE__ */ e("span", { children: f ? `${f} 项传输中` : `${t.length} 项传输记录` })
  ] }) : /* @__PURE__ */ o("section", { className: "fp-upload-queue fp-transfer-queue", "aria-label": n, "data-variant": r, children: [
    a && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: n }),
        /* @__PURE__ */ e("span", { children: f ? `${f} 项进行中` : "传输记录" })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("ul", { children: t.map((m) => {
      const b = Math.max(0, Math.min(100, Number.isFinite(m.progress) ? m.progress : 0)), y = m.direction === "download" ? "下载" : "上传";
      return /* @__PURE__ */ o("li", { "data-status": m.status, children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", "aria-hidden": "true", children: m.status === "done" ? /* @__PURE__ */ e(Re, { size: 17 }) : m.direction === "download" ? /* @__PURE__ */ e(kn, { size: 17 }) : /* @__PURE__ */ e(Mo, { size: 17 }) }),
        /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
          /* @__PURE__ */ e("strong", { title: m.name, children: m.name }),
          /* @__PURE__ */ e("span", { children: m.detail || (m.status === "queued" ? `等待${y}` : m.status === "done" ? `${y}完成` : m.status === "cancelled" ? "已取消" : m.status === "error" ? `${y}未完成` : `正在${y}${m.indeterminate ? "" : ` ${Math.round(b)}%`}`) }),
          m.status === "active" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${m.name}${y}进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": m.indeterminate ? void 0 : b, className: "fp-upload-progress", "data-indeterminate": m.indeterminate, children: /* @__PURE__ */ e("i", { style: { width: m.indeterminate ? "40%" : `${b}%` } }) })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
          m.direction === "download" && m.status === "done" && /* @__PURE__ */ o(Z, { children: [
            c && /* @__PURE__ */ e(le, { variant: "ghost", size: "sm", "aria-label": `打开 ${m.name}`, onClick: () => c(m), children: "打开" }),
            u && /* @__PURE__ */ e(le, { variant: "ghost", size: "sm", "aria-label": `定位 ${m.name}`, onClick: () => u(m), children: /* @__PURE__ */ e(Ja, { size: 15 }) })
          ] }),
          ["queued", "active"].includes(m.status) && m.cancellable !== !1 && i && /* @__PURE__ */ e(le, { variant: "ghost", size: "sm", "aria-label": `取消${y} ${m.name}`, onClick: () => i(m), children: /* @__PURE__ */ e(ge, { size: 15 }) }),
          ["error", "cancelled"].includes(m.status) && m.retryable !== !1 && l && /* @__PURE__ */ e(le, { variant: "ghost", size: "sm", "aria-label": `重试${y} ${m.name}`, onClick: () => l(m), children: /* @__PURE__ */ e(Qa, { size: 15 }) }),
          ["done", "error", "cancelled"].includes(m.status) && s && /* @__PURE__ */ e(le, { variant: "ghost", size: "sm", "aria-label": `移除记录 ${m.name}`, onClick: () => s(m), children: /* @__PURE__ */ e(ge, { size: 15 }) })
        ] })
      ] }, m.id);
    }) })
  ] });
}
function Wm({ title: t, subtitle: n, leading: r, actions: a, onBack: i }) {
  return /* @__PURE__ */ o("header", { className: "fp-touch-header", children: [
    i ? /* @__PURE__ */ e("button", { type: "button", onClick: i, "aria-label": "返回", children: /* @__PURE__ */ e(Ar, { size: 22 }) }) : r,
    /* @__PURE__ */ o("div", { className: "fp-touch-heading", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    a && /* @__PURE__ */ e("div", { className: "fp-touch-header-actions", children: a })
  ] });
}
function Vm({ title: t, description: n, action: r, children: a }) {
  return /* @__PURE__ */ o("section", { className: "fp-touch-section", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h2", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r
    ] }),
    a
  ] });
}
function Xm({ items: t, label: n = "快捷操作" }) {
  return /* @__PURE__ */ e("div", { className: "fp-touch-actions", "aria-label": n, children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", disabled: r.disabled, onClick: r.onClick, children: [
    /* @__PURE__ */ e("span", { children: r.icon }),
    /* @__PURE__ */ e("strong", { children: r.label }),
    r.description && /* @__PURE__ */ e("small", { children: r.description })
  ] }, r.id)) });
}
function Ym({ title: t, description: n, icon: r, trailing: a, onClick: i }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-touch-row", onClick: i, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-touch-row-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-touch-row-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    a || /* @__PURE__ */ e(Ie, { size: 18, "aria-hidden": "true" })
  ] });
}
function Gm({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-mobile-notebook-grid", children: t });
}
function Jm({ title: t, description: n, icon: r, onClick: a }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-mobile-notebook", onClick: a, children: [
    /* @__PURE__ */ e("span", { className: "fp-mobile-notebook-mark", "aria-hidden": "true", children: r }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("small", { children: n })
  ] });
}
function Qm({ mark: t, title: n, description: r, children: a, footer: i }) {
  return /* @__PURE__ */ o("main", { className: "fp-mobile-welcome", children: [
    /* @__PURE__ */ o("div", { className: "fp-mobile-welcome-content", children: [
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-mark", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      /* @__PURE__ */ e("p", { children: r }),
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-actions", children: a })
    ] }),
    i && /* @__PURE__ */ e("footer", { children: i })
  ] });
}
function Zm({ state: t, time: n, busy: r, onStart: a, onPause: i, onFinish: l, onUpload: s, onAgain: c }) {
  const u = t === "recording" || t === "paused";
  return /* @__PURE__ */ o("section", { className: "fp-recorder", "aria-label": "课堂录音", "aria-busy": r, children: [
    /* @__PURE__ */ o("div", { className: "fp-recorder-status", role: "status", children: [
      t === "recording" && /* @__PURE__ */ e("i", {}),
      t === "idle" ? "准备记录课堂" : t === "paused" ? "已暂停" : t === "saved" ? "录音已保存" : "正在录音"
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-time", "aria-label": `录音时长 ${n}`, children: n }),
    /* @__PURE__ */ e("p", { children: t === "idle" ? "点击开始，记录课堂里的重点" : t === "saved" ? "已保存在手机，可以试听或上传到资源中心" : t === "paused" ? "继续录音，或结束并保存" : "锁屏或返回笔记后，录音仍会继续" }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-controls", children: u ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: i, className: "fp-recorder-secondary", children: [
        t === "paused" ? /* @__PURE__ */ e(Qt, { size: 24 }) : /* @__PURE__ */ e(Pn, { size: 24 }),
        /* @__PURE__ */ e("span", { children: t === "paused" ? "继续录音" : "暂停" })
      ] }),
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: l, className: "fp-recorder-finish", children: [
        /* @__PURE__ */ e(qn, { size: 22 }),
        /* @__PURE__ */ e("span", { children: "结束并保存" })
      ] })
    ] }) : t === "saved" ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ e("span", { className: "fp-recorder-saved", children: /* @__PURE__ */ e(Re, { size: 32 }) }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: s, className: "fp-recorder-primary", children: "上传录音" }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: c, children: "录制下一条" })
    ] }) : /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: a, className: "fp-recorder-start", children: [
      /* @__PURE__ */ e(Eo, { size: 30 }),
      /* @__PURE__ */ e("span", { children: "开始录音" })
    ] }) })
  ] });
}
function eb({ title: t, description: n, metrics: r, tables: a, loading: i, error: l, onRefresh: s, children: c, navigation: u, trend: d, personal: p = !1 }) {
  const h = Ne().replaceAll(":", ""), f = d || [], m = Math.max(1, ...f.map((g) => g.value)), b = (g) => 48 + g * 744 / Math.max(1, f.length - 1), y = (g) => 190 - g / m * 154, w = f.map((g, x) => `${b(x)},${y(g.value)}`).join(" "), v = [$o, Rn, dr, Xa, dr, Va];
  return /* @__PURE__ */ o("section", { className: "fp-analytics", "data-personal": p || void 0, children: [
    /* @__PURE__ */ o("header", { className: "fp-analytics-heading", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { className: "fp-analytics-eyebrow", children: p ? "我的学习" : "运营分析" }),
        /* @__PURE__ */ e("h1", { children: t }),
        /* @__PURE__ */ e("p", { children: n })
      ] }),
      /* @__PURE__ */ o(le, { variant: "secondary", loading: i, onClick: s, "aria-label": "刷新数据", children: [
        /* @__PURE__ */ e(Bn, { size: 16 }),
        "刷新数据"
      ] })
    ] }),
    u && /* @__PURE__ */ e("div", { className: "fp-analytics-navigation", children: u }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    r.length > 0 && /* @__PURE__ */ e("div", { className: "fp-analytics-metrics", children: r.map((g, x) => {
      const N = v[x % v.length];
      return /* @__PURE__ */ o(Gt, { children: [
        /* @__PURE__ */ o("div", { className: "fp-analytics-metric-label", children: [
          /* @__PURE__ */ e("span", { children: g.label }),
          /* @__PURE__ */ e(N, { size: 17, "aria-hidden": "true" })
        ] }),
        /* @__PURE__ */ e("strong", { children: typeof g.value == "number" ? g.value.toLocaleString("zh-CN") : g.value })
      ] }, g.label);
    }) }),
    d && /* @__PURE__ */ o(Gt, { className: "fp-analytics-trend", children: [
      /* @__PURE__ */ o("div", { className: "fp-analytics-panel-heading", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h2", { children: p ? "使用时长趋势" : "活跃趋势" }),
          /* @__PURE__ */ e("p", { children: "观察每天的使用变化" })
        ] }),
        /* @__PURE__ */ o("span", { className: "fp-analytics-period", children: [
          "最近 ",
          f.length,
          " 天"
        ] })
      ] }),
      f.length ? /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e("div", { className: "fp-analytics-chart", role: "img", "aria-label": f.map((g) => p ? `${g.label}，有效使用${g.minutes}分钟` : `${g.label}，活跃${g.value}人，有效使用${g.minutes}分钟`).join("；"), children: /* @__PURE__ */ o("svg", { viewBox: "0 0 840 230", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ o("linearGradient", { id: h, x1: "0", y1: "0", x2: "0", y2: "1", children: [
            /* @__PURE__ */ e("stop", { offset: "0%", stopColor: "currentColor", stopOpacity: ".18" }),
            /* @__PURE__ */ e("stop", { offset: "100%", stopColor: "currentColor", stopOpacity: "0" })
          ] }) }),
          [0, 0.5, 1].map((g) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("line", { x1: "48", x2: "792", y1: y(m * g), y2: y(m * g), className: "fp-analytics-gridline" }),
            /* @__PURE__ */ e("text", { x: "36", y: y(m * g) + 4, textAnchor: "end", children: Number((m * g).toFixed(1)) })
          ] }, g)),
          /* @__PURE__ */ e("polygon", { points: `48,190 ${w} ${b(f.length - 1)},190`, fill: `url(#${h})` }),
          /* @__PURE__ */ e("polyline", { points: w, fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinejoin: "round", strokeLinecap: "round" }),
          f.map((g, x) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("circle", { cx: b(x), cy: y(g.value), r: "4", fill: "var(--fp-surface)", stroke: "currentColor", strokeWidth: "2" }),
            (x === 0 || x === f.length - 1 || x % Math.ceil(f.length / 7) === 0 && x < f.length - 2) && /* @__PURE__ */ e("text", { x: b(x), y: "219", textAnchor: "middle", children: g.label.slice(5).replace("-", "/") })
          ] }, g.label))
        ] }) }),
        /* @__PURE__ */ o("div", { className: "fp-analytics-chart-footer", children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", {}),
            p ? "每日有效使用（分钟）" : "每日活跃用户"
          ] }),
          /* @__PURE__ */ o("span", { children: [
            "累计有效使用 ",
            /* @__PURE__ */ e("strong", { children: f.reduce((g, x) => g + x.minutes, 0).toLocaleString("zh-CN") }),
            " 分钟"
          ] })
        ] })
      ] }) : /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示活跃趋势。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-analytics-tables", children: a.map((g) => /* @__PURE__ */ o(Gt, { className: g.columns.length > 4 ? "fp-analytics-wide" : void 0, children: [
      /* @__PURE__ */ e("h2", { children: g.title }),
      /* @__PURE__ */ o("div", { className: "fp-analytics-table", tabIndex: 0, role: "region", "aria-label": g.title, children: [
        /* @__PURE__ */ o("table", { children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: g.columns.map((x) => /* @__PURE__ */ e("th", { children: x }, x)) }) }),
          /* @__PURE__ */ e("tbody", { children: g.rows.map((x, N) => /* @__PURE__ */ e("tr", { children: x.map((C, A) => /* @__PURE__ */ e("td", { children: C }, A)) }, N)) })
        ] }),
        !g.rows.length && /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示统计结果。" })
      ] })
    ] }, g.title)) }),
    c
  ] });
}
function tb({ entries: t, directoryId: n, onNavigate: r, selectedId: a, onSelect: i, rootLabel: l = "全部位置", searchLabel: s = "搜索名称、拼音或英文", emptyLabel: c = "此文件夹为空", disabled: u = !1, preview: d, loading: p = !1, variant: h = "content" }) {
  const [f, m] = k(""), b = B(null), y = He(() => new Map(t.map((L) => [L.id, L])), [t]), w = (L) => {
    const U = [], S = /* @__PURE__ */ new Set();
    let I = y.get(L);
    for (; I && !S.has(I.id); )
      S.add(I.id), U.unshift(I), I = I.parentId ? y.get(I.parentId) : void 0;
    return U;
  }, v = w(n), g = t.filter((L) => !L.parentId && L.kind === "folder"), x = He(() => new Map(t.map((L) => [L.id, nn(L.label, L.description || "", L.keywords || "", ...w(L.id).map((U) => U.label))])), [t, y]), N = f.trim().toLowerCase(), C = t.filter((L) => N ? x.get(L.id)?.includes(N) : (L.parentId || "") === n), A = (L) => {
    m(""), r(L);
  };
  return /* @__PURE__ */ o("div", { className: "fp-resource-browser", "data-variant": h, "aria-busy": p, children: [
    h === "destination" && /* @__PURE__ */ o("div", { className: "fp-browser-destination-heading", children: [
      /* @__PURE__ */ e("span", { children: "选择保存位置" }),
      /* @__PURE__ */ e("small", { children: "打开文件夹，选择当前位置" })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-search", children: [
      /* @__PURE__ */ e(Je, { size: 17, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { type: "search", "aria-label": s, placeholder: s, value: f, disabled: u, onChange: (L) => m(L.target.value) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-body", children: [
      h === "content" && /* @__PURE__ */ o("nav", { className: "fp-browser-locations", "aria-label": "浏览位置", children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": n ? void 0 : "location", onClick: () => A(""), children: l }),
        g.map((L) => /* @__PURE__ */ o("button", { type: "button", disabled: u || L.disabled, "aria-current": v[0]?.id === L.id ? "location" : void 0, onClick: () => A(L.id), children: [
          L.icon || /* @__PURE__ */ e(vn, { size: 17 }),
          /* @__PURE__ */ e("span", { children: L.label })
        ] }, L.id))
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-browser-main", "aria-label": "文件夹内容", children: [
        h === "destination" && g.length > 1 && /* @__PURE__ */ e("div", { className: "fp-browser-root-choice", children: /* @__PURE__ */ e(we, { label: "切换位置", value: v[0]?.id || "", onChange: A, options: [{ value: "", label: l }, ...g.map((L) => ({ value: L.id, label: L.label, disabled: L.disabled }))] }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-path", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回上一级", disabled: u || !n, onClick: () => A(y.get(n)?.parentId || ""), children: /* @__PURE__ */ e($r, { size: 17 }) }),
          /* @__PURE__ */ o("nav", { "aria-label": "当前位置", children: [
            /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: () => A(""), children: l }),
            v.map((L) => /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(Ie, { size: 13 }),
              /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": L.id === n ? "location" : void 0, onClick: () => A(L.id), children: L.label })
            ] }, L.id))
          ] })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-browser-list", ref: b, role: "group", "aria-label": N ? "搜索结果" : "可选内容", onKeyDown: (L) => {
          if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(L.key)) return;
          const U = Array.from(b.current?.querySelectorAll("button:not(:disabled)") || []), S = U.indexOf(document.activeElement);
          S < 0 || (L.preventDefault(), U[L.key === "Home" ? 0 : L.key === "End" ? U.length - 1 : Math.max(0, Math.min(U.length - 1, S + (L.key === "ArrowDown" ? 1 : -1)))]?.focus());
        }, children: p ? /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }) : C.length ? C.map((L) => /* @__PURE__ */ o("button", { className: "fp-browser-entry", type: "button", disabled: u || L.disabled, "aria-pressed": L.kind === "file" ? a === L.id : void 0, onClick: () => L.kind === "folder" ? A(L.id) : i(L.id), children: [
          /* @__PURE__ */ e("span", { className: "fp-browser-entry-icon", children: L.icon || (L.kind === "folder" ? /* @__PURE__ */ e(vn, { size: 22 }) : /* @__PURE__ */ e(zo, { size: 22 })) }),
          /* @__PURE__ */ o("span", { className: "fp-browser-entry-text", children: [
            /* @__PURE__ */ e("strong", { children: L.label }),
            (N || L.description || h === "destination") && /* @__PURE__ */ e("small", { children: N ? w(L.id).slice(0, -1).map((U) => U.label).join(" / ") : L.description || (L.kind === "folder" ? `${t.filter((U) => U.parentId === L.id && U.kind === "folder").length} 个文件夹` : "") })
          ] }),
          L.kind === "folder" && /* @__PURE__ */ e(Ie, { size: 16 })
        ] }, L.id)) : /* @__PURE__ */ e("p", { role: "status", children: N ? "没有匹配的内容" : c }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-count", "aria-live": "polite", children: [
          C.length,
          " 项",
          N ? " · 搜索全部位置" : ""
        ] })
      ] }),
      d && /* @__PURE__ */ e("aside", { className: "fp-browser-preview", "aria-label": "所选内容", children: d })
    ] })
  ] });
}
function nb({ brand: t, headerActions: n, items: r, value: a, onChange: i, onReturn: l, identity: s, children: c }) {
  const [u, d] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-console", children: [
    /* @__PURE__ */ o("header", { className: "fp-console-topbar", children: [
      /* @__PURE__ */ e("div", { className: "fp-console-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-console-top-actions", children: [
        /* @__PURE__ */ o(le, { variant: "ghost", onClick: l, children: [
          /* @__PURE__ */ e(Ar, { size: 17 }),
          "返回工作区"
        ] }),
        n
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-console-body", children: [
      /* @__PURE__ */ o("div", { className: "fp-console-mobile-bar", children: [
        /* @__PURE__ */ o(le, { variant: "secondary", "aria-expanded": u, "aria-controls": "management-navigation", onClick: () => d(!u), children: [
          u ? /* @__PURE__ */ e(ge, { size: 18 }) : /* @__PURE__ */ e(Er, { size: 18 }),
          "管理导航"
        ] }),
        /* @__PURE__ */ e("span", { children: r.find((p) => p.id === a)?.label })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-console-sidebar", "data-open": u, children: [
        /* @__PURE__ */ e("div", { className: "fp-console-sidebar-heading", children: "管理中心" }),
        /* @__PURE__ */ e("nav", { id: "management-navigation", "aria-label": "管理导航", children: r.map((p) => /* @__PURE__ */ o("button", { type: "button", "aria-current": a === p.id ? "page" : void 0, onClick: () => {
          i(p.id), d(!1);
        }, children: [
          p.icon,
          /* @__PURE__ */ e("span", { children: p.label })
        ] }, p.id)) }),
        s && /* @__PURE__ */ e("footer", { children: s })
      ] }),
      /* @__PURE__ */ e("main", { className: "fp-console-content", tabIndex: -1, children: c })
    ] })
  ] });
}
function rb({ title: t, description: n, items: r, value: a, onChange: i, actions: l, status: s, children: c }) {
  return /* @__PURE__ */ o("section", { className: "fp-console-form", children: [
    /* @__PURE__ */ e("header", { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h1", { children: t }),
      n && /* @__PURE__ */ e("p", { children: n })
    ] }) }),
    /* @__PURE__ */ e(mi, { items: r, value: a, onChange: i }),
    /* @__PURE__ */ e("div", { className: "fp-console-form-body", children: c }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("div", { role: "status", "aria-live": "polite", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-console-form-actions", children: l })
    ] })
  ] });
}
function ab({ open: t, version: n, minimum: r, children: a, actions: i, updateContent: l }) {
  return /* @__PURE__ */ e(on, { open: t, dismissible: !1, className: "fp-upgrade-dialog", title: "更新课栈，继续学习", onClose: () => {
  }, footer: i, children: l || /* @__PURE__ */ o("div", { className: "fp-upgrade-required", children: [
    /* @__PURE__ */ e("div", { className: "fp-upgrade-symbol", "aria-hidden": "true", children: /* @__PURE__ */ e(Ya, { size: 28 }) }),
    /* @__PURE__ */ e("p", { children: "当前版本需要升级，完成后即可继续使用。" }),
    /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: n || "—" })
      ] }),
      /* @__PURE__ */ e(zr, { size: 18, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "最低支持版本" }),
        /* @__PURE__ */ e("strong", { children: r || "—" })
      ] })
    ] }),
    /* @__PURE__ */ e("p", { className: "fp-upgrade-hint", children: "升级前请保留正在编辑的内容。" }),
    a
  ] }) });
}
function ib({ value: t, onChange: n, models: r, tools: a, syncStatus: i, providers: l, initialTab: s = "preferences", children: c }) {
  const [u, d] = k(s);
  Y(() => d(s), [s]);
  const p = r.filter((f) => f.type !== "image").map((f) => ({ value: f.id, label: f.label })), h = r.filter((f) => f.type === "image").map((f) => ({ value: f.id, label: f.label }));
  return /* @__PURE__ */ o("div", { className: "fp-assistant-preferences", children: [
    /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: i }),
    /* @__PURE__ */ e(_e, { label: "AI 设置分类", value: u, onChange: d, density: "compact", items: [{ id: "preferences", label: "常用偏好" }, { id: "models", label: "模型与供应商" }, { id: "capabilities", label: "能力与备份" }] }),
    u === "preferences" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "常用偏好", children: [
      /* @__PURE__ */ o(ee, { title: "对话偏好", children: [
        /* @__PURE__ */ e(X, { label: "默认对话模型", value: t.selectedModelId, options: p, onChange: (f) => n("selectedModelId", f) }),
        /* @__PURE__ */ e(ze, { label: "深度思考", description: "新对话默认开启深度思考。", checked: t.defaultThinking, onChange: (f) => n("defaultThinking", f) }),
        /* @__PURE__ */ e(X, { label: "默认思考力度", value: t.defaultThinkingEffort, options: [{ value: "low", label: "轻量" }, { value: "medium", label: "标准" }, { value: "high", label: "深入" }, { value: "max", label: "充分" }], onChange: (f) => n("defaultThinkingEffort", f) }),
        /* @__PURE__ */ e(ze, { label: "联网搜索", description: "新对话默认启用联网搜索。", checked: t.defaultSearch, onChange: (f) => n("defaultSearch", f) })
      ] }),
      /* @__PURE__ */ e(ee, { title: "回答偏好", description: "告诉 AI 你的学习背景、称呼和回答习惯。", children: /* @__PURE__ */ e(X, { label: "希望 AI 记住的偏好", value: t.globalContext, multiline: !0, onChange: (f) => n("globalContext", f) }) })
    ] }),
    u === "models" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "模型与供应商", children: [
      l,
      /* @__PURE__ */ o(ee, { title: "摘录与划词助手", children: [
        /* @__PURE__ */ e(X, { label: "摘录模型", value: t.recordModelId, options: p, onChange: (f) => n("recordModelId", f) }),
        /* @__PURE__ */ e(X, { label: "划词助手模型", value: t.floatingChatModelId, options: [{ value: "", label: "跟随主对话" }, ...p], onChange: (f) => n("floatingChatModelId", f) })
      ] }),
      h.length > 0 && /* @__PURE__ */ o(ee, { title: "图片生成", children: [
        /* @__PURE__ */ e(X, { label: "默认生图模型", value: t.defaultImageModelId || "", options: [{ value: "", label: "自动选择" }, ...h], onChange: (f) => n("defaultImageModelId", f || null) }),
        /* @__PURE__ */ e(X, { label: "图片描述模型", value: t.imageModeTextModel, options: p, onChange: (f) => n("imageModeTextModel", f) }),
        /* @__PURE__ */ e(X, { label: "备用描述模型", value: t.imageModeTextModelFallback, options: p, onChange: (f) => n("imageModeTextModelFallback", f) })
      ] })
    ] }),
    u === "capabilities" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "能力与备份", children: [
      /* @__PURE__ */ e(ee, { title: "助手能力", children: a.map((f) => /* @__PURE__ */ e(ze, { label: f.label, description: f.desc, checked: !t.disabledTools.includes(f.name), onChange: (m) => n("disabledTools", m ? t.disabledTools.filter((b) => b !== f.name) : [...t.disabledTools, f.name]) }, f.name)) }),
      c
    ] })
  ] });
}
const lp = { name: "", baseUrl: "", protocol: "openai", apiKey: "", models: [] };
function lb({ items: t, loading: n, error: r, credentialNotice: a, imports: i = [], onImportSaved: l, onDiscover: s, onTest: c, onSave: u, onDelete: d }) {
  const [p, h] = k(), [f, m] = k(null), [b, y] = k(""), [w, v] = k(""), [g, x] = k(""), [N, C] = k(""), [A, L] = k([]), [U, S] = k(), I = !f || f.models.every((O) => Number.isInteger(O.contextK ?? 32) && (O.contextK ?? 32) >= 4 && (O.contextK ?? 32) <= 2048), T = (O) => {
    m((M) => M ? { ...M, ...O } : null), x(""), v("");
  }, H = (O) => {
    m(O ? { ...O, apiKey: "" } : { ...lp, models: [] }), L(O?.models || []), C(""), x(""), v(""), S(void 0), h(void 0);
  }, R = async (O, M) => {
    y(O), v("");
    try {
      await M();
    } catch (K) {
      v(K instanceof Error ? K.message : "操作未完成，请重试");
    } finally {
      y("");
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-provider-manager", children: [
    /* @__PURE__ */ e("p", { children: "连接你自己的 AI 服务。供应商和模型会同步到账号，在其他设备也可使用。" }),
    a && /* @__PURE__ */ o("aside", { className: "fp-provider-privacy", role: "note", "aria-label": "API Key 使用说明", children: [
      /* @__PURE__ */ e(ei, { size: 20, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: a })
    ] }),
    n && /* @__PURE__ */ e("p", { role: "status", children: "正在读取供应商…" }),
    r && /* @__PURE__ */ e("p", { role: "alert", children: r }),
    i.length > 0 && !f && /* @__PURE__ */ o("section", { className: "fp-provider-imports", "aria-label": "此设备的旧配置", children: [
      /* @__PURE__ */ e("strong", { children: "此设备的旧配置" }),
      /* @__PURE__ */ e("p", { children: "检查并测试后保存到账号，即可在其他设备使用。" }),
      i.map((O) => /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: O.label }),
        /* @__PURE__ */ o(le, { variant: "secondary", disabled: !!b, onClick: () => {
          H(), m({ ...O.draft }), L(O.draft.models), h(O.id);
        }, children: [
          "检查并迁移 ",
          O.label
        ] })
      ] }, O.id))
    ] }),
    t.map((O) => /* @__PURE__ */ o("div", { className: "fp-provider-summary", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: O.name }),
        /* @__PURE__ */ o("small", { children: [
          O.models.length,
          " 个模型 · ",
          O.protocol === "anthropic" ? "Anthropic Messages" : O.protocol === "siliconflow" ? "SiliconFlow" : "OpenAI 兼容"
        ] })
      ] }),
      /* @__PURE__ */ e(le, { variant: "ghost", disabled: !!b, onClick: () => H(O), children: "编辑" }),
      /* @__PURE__ */ e(le, { variant: "ghost", disabled: !!b, onClick: () => S(O.id), children: "删除" }),
      U === O.id && /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: "删除此供应商？" }),
        /* @__PURE__ */ e(le, { variant: "secondary", onClick: () => S(void 0), children: "取消" }),
        /* @__PURE__ */ e(le, { disabled: !!b, onClick: () => {
          R("delete", async () => {
            await d(O), S(void 0), f?.id === O.id && m(null);
          });
        }, children: "确认删除" })
      ] })
    ] }, O.id)),
    !f && /* @__PURE__ */ e(le, { variant: "secondary", onClick: () => H(), children: "添加供应商" }),
    f && /* @__PURE__ */ o("div", { className: "fp-provider-form", "aria-label": f.id ? "编辑供应商" : "添加供应商", children: [
      /* @__PURE__ */ e(X, { label: "供应商名称", value: f.name, disabled: !!b, onChange: (O) => T({ name: O }) }),
      /* @__PURE__ */ e(X, { label: "API 端点", hint: "填写 HTTPS 地址，例如 https://api.example.com/v1", value: f.baseUrl, disabled: !!b, onChange: (O) => {
        T({ baseUrl: O, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "协议", value: f.protocol, disabled: !!b, options: [{ value: "openai", label: "OpenAI 兼容" }, { value: "anthropic", label: "Anthropic Messages" }, { value: "siliconflow", label: "SiliconFlow" }], onChange: (O) => {
        T({ protocol: O, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "API Key", hint: f.id ? "留空沿用已保存的 Key。" : "Key 仅用于连接你的供应商，保存后不会再显示。", value: f.apiKey, secret: !0, disabled: !!b, onChange: (O) => T({ apiKey: O }) }),
      /* @__PURE__ */ e("div", { className: "fp-provider-actions", children: /* @__PURE__ */ e(le, { variant: "secondary", disabled: !!b || !f.baseUrl || !f.apiKey && !f.id, onClick: () => {
        R("discover", async () => {
          const O = await s(f);
          L(O), T({ models: [] }), v("已获取模型，请选择要添加的模型。");
        });
      }, children: b === "discover" ? "正在获取…" : "获取模型" }) }),
      A.length > 0 && /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ o("p", { "aria-live": "polite", children: [
          "已选择 ",
          f.models.length,
          " / 50 个模型"
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-provider-models", role: "group", "aria-label": "选择模型", children: A.map((O) => /* @__PURE__ */ o("label", { children: [
          /* @__PURE__ */ e("input", { type: "checkbox", disabled: !!b || f.models.length >= 50 && !f.models.some((M) => M.id === O.id), checked: f.models.some((M) => M.id === O.id), onChange: (M) => T({ models: M.target.checked ? [...f.models, O] : f.models.filter((K) => K.id !== O.id) }) }),
          O.label || O.id
        ] }, O.id)) })
      ] }),
      f.models.length > 0 && /* @__PURE__ */ o("section", { className: "fp-provider-contexts", "aria-label": "模型能力设置", children: [
        /* @__PURE__ */ e("h3", { children: "模型能力与容量" }),
        /* @__PURE__ */ e("p", { children: "按供应商实际支持的能力分别设置每个模型。图片输入用于识别图片；工具调用用于读取资料、操作笔记等。1K 为 1000 tokens。" }),
        f.models.map((O) => /* @__PURE__ */ o("fieldset", { className: "fp-provider-context", children: [
          /* @__PURE__ */ e("legend", { children: O.label || O.id }),
          /* @__PURE__ */ e(ze, { label: "支持图片输入", description: "允许在对话中上传图片供此模型识别。", checked: O.vision === !0, disabled: !!b, onChange: (M) => T({ models: f.models.map((K) => K.id === O.id ? { ...K, vision: M } : K) }) }),
          /* @__PURE__ */ e(ze, { label: "启用工具调用", description: "允许此模型读取资料及执行你授权的笔记操作。", checked: O.tools === !0, disabled: !!b, onChange: (M) => T({ models: f.models.map((K) => K.id === O.id ? { ...K, tools: M } : K) }) }),
          /* @__PURE__ */ e(X, { label: "上下文容量（K）", numeric: !0, value: O.contextK ?? 32, disabled: !!b, hint: O.contextSource === "provider" ? "供应商提供的容量，可按实际限制调整。" : O.contextSource === "user" ? "手动设置的容量。" : O.contextSource === "default" || O.contextK === void 0 ? "供应商未提供容量，暂用保守默认值 32K，请按实际限制确认。" : "已保存的容量，请按供应商实际限制确认。", onChange: (M) => T({ models: f.models.map((K) => K.id === O.id ? { ...K, contextK: Number(M), contextSource: "user" } : K) }) }),
          (!Number.isInteger(O.contextK ?? 32) || (O.contextK ?? 32) < 4 || (O.contextK ?? 32) > 2048) && /* @__PURE__ */ e("p", { role: "alert", children: "请填写 4–2048 之间的整数。" })
        ] }, O.id))
      ] }),
      /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ e("summary", { children: "手动添加模型" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e(X, { label: "模型 ID", value: N, hint: "供应商无法列出模型时，可填写模型 ID，多个模型用逗号或换行分隔。", multiline: !0, disabled: !!b, onChange: C }),
          /* @__PURE__ */ e(le, { variant: "secondary", disabled: !!b || !N.trim(), onClick: () => {
            const O = [...new Set(N.split(/[\n,，]/).map((K) => K.trim()).filter(Boolean))].map((K) => ({ id: K, label: K })), M = [...f.models, ...O.filter((K) => !f.models.some((j) => j.id === K.id))];
            L((K) => [...K, ...O.filter((j) => !K.some((P) => P.id === j.id))]), T({ models: M }), C("");
          }, children: "加入模型列表" })
        ] })
      ] }),
      /* @__PURE__ */ e("p", { children: "连接测试只检查所选第一个模型是否可访问，图片和工具能力请按供应商说明设置。测试及对话的费用由你的供应商收取。" }),
      /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e(le, { variant: "secondary", disabled: !!b || !I || !f.name.trim() || !f.models.length || f.models.length > 50, onClick: () => {
          R("test", async () => {
            x(await c(f)), v("连接成功，可以保存供应商。");
          });
        }, children: b === "test" ? "正在测试…" : "测试连接" }),
        /* @__PURE__ */ e(le, { disabled: !!b || !g || !I, onClick: () => {
          R("save", async () => {
            await u(f, g), p && l?.(p), h(void 0), m(null), x(""), v("供应商已保存，可在模型菜单中选择。");
          });
        }, children: b === "save" ? "正在保存…" : f.id ? "保存供应商" : "添加供应商" }),
        /* @__PURE__ */ e(le, { variant: "ghost", disabled: !!b, onClick: () => {
          m(null), h(void 0), x(""), v("");
        }, children: "取消" })
      ] })
    ] }),
    w && /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: w })
  ] });
}
function ob({ items: t, onSelect: n, label: r = "相关设置" }) {
  return /* @__PURE__ */ e("nav", { className: "fp-settings-links", "aria-label": r, children: t.map((a) => /* @__PURE__ */ o("button", { type: "button", disabled: a.disabled, onClick: () => n(a.id), children: [
    a.icon && /* @__PURE__ */ e("span", { className: "fp-settings-link-icon", "aria-hidden": "true", children: a.icon }),
    /* @__PURE__ */ o("span", { className: "fp-settings-link-copy", children: [
      /* @__PURE__ */ e("strong", { children: a.label }),
      a.description && /* @__PURE__ */ e("small", { children: a.description })
    ] }),
    /* @__PURE__ */ e(Ie, { size: 18, "aria-hidden": "true" })
  ] }, a.id)) });
}
function sb({ metrics: t, description: n = "最近 30 天", loading: r, error: a, onRetry: i }) {
  return /* @__PURE__ */ o(ee, { title: "使用统计", description: n, children: [
    /* @__PURE__ */ e(Se, { error: a }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取使用统计…" }) : /* @__PURE__ */ e("dl", { className: "fp-admin-metrics", children: t.map((l) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, l.label)) }),
    a && i && /* @__PURE__ */ e(le, { onClick: i, children: "重新读取" })
  ] });
}
function cb({ items: t, loading: n, error: r, hasMore: a, onMore: i }) {
  return /* @__PURE__ */ o(ee, { title: "拥有的笔记本", children: [
    /* @__PURE__ */ e(Se, { error: r }),
    /* @__PURE__ */ e("ul", { className: "fp-admin-notebooks", children: t.map((l) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("div", { children: [
      l.href ? /* @__PURE__ */ e("a", { href: l.href, children: l.title }) : /* @__PURE__ */ e("strong", { children: l.title }),
      /* @__PURE__ */ o("small", { children: [
        l.noteCount,
        " 篇笔记 · 更新于 ",
        l.updatedAt
      ] })
    ] }) }, l.id)) }),
    n ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : !t.length && !r ? /* @__PURE__ */ e("p", { children: "该用户尚未拥有笔记本。" }) : null,
    a && i && /* @__PURE__ */ e(le, { disabled: n, onClick: i, children: "加载更多笔记本" })
  ] });
}
function db({ entries: t, filters: n, onFiltersChange: r, actions: a, onSearch: i, onReset: l, onNext: s, onPrevious: c, canNext: u, canPrevious: d, loading: p, error: h }) {
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-admin-audit", children: /* @__PURE__ */ o(ee, { title: "审计日志", description: "查看平台操作的时间、操作者、对象与变更说明。", children: [
    /* @__PURE__ */ o("form", { className: "fp-admin-audit-filters", onSubmit: (f) => {
      f.preventDefault(), i();
    }, children: [
      /* @__PURE__ */ e(X, { label: "操作者", value: n.actor, onChange: (f) => r({ ...n, actor: f }) }),
      /* @__PURE__ */ e(X, { label: "操作", value: n.action, options: [{ value: "", label: "全部操作" }, ...a], onChange: (f) => r({ ...n, action: f }) }),
      /* @__PURE__ */ e(X, { label: "操作对象", value: n.target, onChange: (f) => r({ ...n, target: f }) }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "开始日期" }),
        /* @__PURE__ */ e(Aa, { className: "fp-input", "aria-label": "开始日期", value: n.from, onChange: (f) => r({ ...n, from: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "结束日期" }),
        /* @__PURE__ */ e(Aa, { className: "fp-input", "aria-label": "结束日期", value: n.to, onChange: (f) => r({ ...n, to: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-actions", children: [
        /* @__PURE__ */ e(le, { type: "submit", disabled: p, children: "查询" }),
        /* @__PURE__ */ e(le, { type: "button", disabled: p, onClick: l, children: "重置筛选" })
      ] })
    ] }),
    /* @__PURE__ */ e(Se, { error: h }),
    p ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取操作记录…" }) : /* @__PURE__ */ e("ol", { className: "fp-admin-audit-list", children: t.map((f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-heading", children: [
        /* @__PURE__ */ e("strong", { children: f.action }),
        /* @__PURE__ */ e("time", { children: f.time })
      ] }),
      /* @__PURE__ */ o("p", { children: [
        /* @__PURE__ */ e("span", { children: f.actor }),
        /* @__PURE__ */ e("span", { "aria-hidden": "true", children: " → " }),
        /* @__PURE__ */ e("span", { children: f.target })
      ] }),
      f.summary && /* @__PURE__ */ e("p", { children: f.summary })
    ] }, f.id)) }),
    !p && !h && !t.length && /* @__PURE__ */ e("p", { children: "没有符合条件的操作记录。" }),
    /* @__PURE__ */ o("nav", { className: "fp-admin-audit-actions", "aria-label": "审计记录分页", children: [
      /* @__PURE__ */ e(le, { disabled: p || !d, onClick: c, children: "上一页" }),
      /* @__PURE__ */ e(le, { disabled: p || !u, onClick: s, children: "下一页" })
    ] })
  ] }) });
}
function ub({ index: t, children: n, className: r = "", duration: a = 0.26, label: i }) {
  const [l, s] = k({ index: t, direction: 1, prior: null }), c = B(n), u = Kn();
  l.index !== t && s({ index: t, direction: t > l.index ? 1 : -1, prior: { index: l.index, children: c.current } }), c.current = n, Y(() => {
    const p = setTimeout(() => s((h) => h.index === t && h.prior ? { ...h, prior: null } : h), u ? 0 : a * 1e3 + 30);
    return () => clearTimeout(p);
  }, [t, a, u]);
  const d = [...l.prior ? [{ ...l.prior, active: !1 }] : [], { index: t, children: n, active: !0 }];
  return /* @__PURE__ */ e("div", { className: `fp-slide-transition ${r}`, "data-direction": l.direction, "data-index": t, "aria-label": i, style: { position: "relative", height: "100%", width: "100%", minHeight: 0, minWidth: 0, overflow: "hidden" }, children: d.map((p) => /* @__PURE__ */ e(
    Un.div,
    {
      "data-fp-slide-page": "",
      "data-active": p.active,
      inert: !p.active,
      "aria-hidden": !p.active || void 0,
      initial: p.active && l.prior && !u ? { x: `${l.direction * 100}%`, opacity: 0.35 } : !1,
      animate: { x: p.active || u ? 0 : `${-l.direction * 100}%`, opacity: p.active || u ? 1 : 0.35 },
      transition: { duration: u ? 0 : a, ease: [0.2, 0, 0, 1] },
      style: { position: "absolute", inset: 0, minWidth: 0, minHeight: 0, overflow: "hidden", pointerEvents: p.active ? "auto" : "none" },
      children: p.children
    },
    p.index
  )) });
}
function pb(t, n = !1) {
  if (t.isComposing || t.repeat || !(t.ctrlKey || t.metaKey)) return null;
  const r = t.key.toLowerCase();
  return !n && !t.altKey || n && t.altKey ? null : r === "n" && !t.shiftKey ? "new-note" : r === "w" && !t.shiftKey ? "close-tab" : r === "t" && t.shiftKey ? "reopen-tab" : !n && r === "arrowright" && !t.shiftKey ? "next-tab" : !n && r === "arrowleft" && !t.shiftKey ? "previous-tab" : n && r === "tab" ? t.shiftKey ? "previous-tab" : "next-tab" : !t.shiftKey && /^[1-9]$/.test(r) ? `tab-${Number(r)}` : null;
}
function hb(t) {
  const n = Ne(), [r, a] = k("edit"), [i, l] = k("");
  Y(() => {
    a("edit"), l("");
  }, [t.sessionKey]);
  const s = t.mode === "create";
  return /* @__PURE__ */ o("section", { className: "fp-experiment", "aria-label": "实验编辑工作台", onKeyDown: (c) => {
    (c.ctrlKey || c.metaKey) && c.key.toLowerCase() === "s" && (c.preventDefault(), t.onSave());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-experiment-header", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-experiment-back", onClick: t.onBack, children: [
        /* @__PURE__ */ e(Ar, { size: 17 }),
        "我的实验"
      ] }),
      /* @__PURE__ */ e("span", { role: "status", className: "fp-experiment-save", children: t.saveStatus }),
      /* @__PURE__ */ e(ml, { label: "实验操作", actions: [
        { id: "save", label: "保存实验（Ctrl+S）", icon: /* @__PURE__ */ e(_a, { size: 18 }), onSelect: t.onSave },
        { id: "insert", label: "加入笔记", icon: /* @__PURE__ */ e(Io, { size: 18 }), onSelect: t.onInsert, disabled: t.busy || !t.source.trim() },
        { id: "copy", label: "另存为新实验", icon: /* @__PURE__ */ e(jn, { size: 18 }), onSelect: t.onDuplicate, disabled: t.busy || !t.source.trim() },
        { id: "download", label: "下载实验", icon: /* @__PURE__ */ e(Ot, { size: 18 }), onSelect: t.onExport, disabled: !t.source.trim() }
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-experiment-layout", children: [
      /* @__PURE__ */ o("aside", { className: "fp-experiment-editor", children: [
        /* @__PURE__ */ e("label", { htmlFor: `${n}-title`, children: "实验名称" }),
        /* @__PURE__ */ e("input", { id: `${n}-title`, value: t.title, placeholder: "给实验起个名字", onChange: (c) => t.onTitleChange(c.target.value), maxLength: 100, disabled: t.busy }),
        /* @__PURE__ */ o("div", { className: "fp-experiment-tabs", role: "tablist", "aria-label": "实验编辑", onKeyDown: (c) => {
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(c.key)) return;
          c.preventDefault();
          const u = c.key === "Home" ? "edit" : c.key === "End" || r === "edit" ? "history" : "edit";
          a(u), c.currentTarget.querySelectorAll("[role=tab]")[u === "edit" ? 0 : 1]?.focus();
        }, children: [
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-edit-tab`, role: "tab", tabIndex: r === "edit" ? 0 : -1, "aria-selected": r === "edit", "aria-controls": `${n}-edit`, onClick: () => a("edit"), children: [
            /* @__PURE__ */ e(wn, { size: 16 }),
            s ? "创建实验" : "继续修改"
          ] }),
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-history-tab`, role: "tab", tabIndex: r === "history" ? 0 : -1, "aria-selected": r === "history", "aria-controls": `${n}-history`, onClick: () => a("history"), children: [
            /* @__PURE__ */ e(Ao, { size: 16 }),
            "版本记录"
          ] })
        ] }),
        r === "edit" ? /* @__PURE__ */ o("div", { id: `${n}-edit`, role: "tabpanel", "aria-labelledby": `${n}-edit-tab`, className: "fp-experiment-form", children: [
          t.modelSelector && /* @__PURE__ */ e("div", { className: "fp-experiment-model", children: t.modelSelector }),
          /* @__PURE__ */ e("label", { htmlFor: `${n}-prompt`, children: "描述你的想法" }),
          /* @__PURE__ */ e("textarea", { id: `${n}-prompt`, value: t.prompt, onChange: (c) => t.onPromptChange(c.target.value), disabled: t.busy, rows: 5, placeholder: s ? "例如：用滑块调整电荷大小，观察电场如何变化。" : "例如：保留现有图形，增加一个能调节距离的滑块。" }),
          /* @__PURE__ */ e("button", { type: "button", className: "fp-experiment-primary", onClick: t.busy ? t.onStop : t.onGenerate, disabled: !t.busy && (!t.prompt.trim() || t.canGenerate === !1), children: t.busy ? /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e(qn, { size: 16 }),
            "停止生成"
          ] }) : /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e(wn, { size: 17 }),
            "生成实验"
          ] }) }),
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: s ? "描述想探索的概念和操作，AI 会为你创建实验。" : "描述要增加或调整的内容，AI 会基于当前实验修改。" }),
          /* @__PURE__ */ o("details", { children: [
            /* @__PURE__ */ e("summary", { children: "编辑实验源代码" }),
            /* @__PURE__ */ e("label", { htmlFor: `${n}-source`, children: "实验内容" }),
            /* @__PURE__ */ e("textarea", { id: `${n}-source`, "aria-label": "交互内容", value: t.source, onChange: (c) => t.onSourceChange(c.target.value), disabled: t.busy, rows: 14, spellCheck: !1 })
          ] })
        ] }) : /* @__PURE__ */ o("div", { id: `${n}-history`, role: "tabpanel", "aria-labelledby": `${n}-history-tab`, className: "fp-experiment-form", children: [
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: "恢复后会保留当前内容，方便再次找回。" }),
          t.versions?.length ? /* @__PURE__ */ o(Z, { children: [
            /* @__PURE__ */ e(we, { label: "选择实验版本", value: i, onChange: l, options: t.versions.map((c) => ({ value: c.id, label: c.label })) }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              t.onRestore?.(i), l("");
            }, disabled: !i || t.busy, children: "恢复此版本" })
          ] }) : /* @__PURE__ */ e("p", { children: "保存或完成一次修改后，可以在这里找回之前的内容。" })
        ] }),
        t.message && /* @__PURE__ */ e("p", { role: "status", className: "fp-experiment-message", children: t.message }),
        t.generationSummary && /* @__PURE__ */ e("div", { role: "status", className: "fp-experiment-hint", children: t.generationSummary })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-experiment-preview", "aria-label": "实验预览", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: t.title || "未命名实验" }),
          /* @__PURE__ */ e("span", { children: "动手探索" })
        ] }),
        t.busy && /* @__PURE__ */ e("div", { className: "fp-experiment-progress", "aria-live": "polite", children: t.progress }),
        /* @__PURE__ */ e("div", { className: "fp-experiment-canvas", children: t.preview })
      ] })
    ] })
  ] });
}
function at({
  label: t,
  children: n,
  ...r
}) {
  return /* @__PURE__ */ e(
    le,
    {
      variant: "ghost",
      ...r,
      className: Ue("fp-icon-button", r.className),
      "aria-label": t,
      title: t,
      children: n
    }
  );
}
function qr({
  className: t,
  ...n
}) {
  return /* @__PURE__ */ e("input", { ...n, className: Ue("fp-input", t) });
}
function op(t) {
  return /* @__PURE__ */ e("textarea", { ...t, className: Ue("fp-input", t.className) });
}
function fb({
  label: t,
  hint: n,
  error: r,
  children: a
}) {
  let i = Ne();
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: i, children: t }),
    Lt.cloneElement(a, {
      id: i,
      "aria-describedby": `${i}-help`,
      "aria-invalid": !!r
    }),
    (r || n) && /* @__PURE__ */ e("small", { id: `${i}-help`, className: r ? "fp-error-text" : "", children: r || n })
  ] });
}
function Kr({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "checkbox" }),
    t
  ] });
}
function mb({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "radio" }),
    t
  ] });
}
function sp({
  label: t,
  checked: n,
  onChange: r,
  disabled: a
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-switch-label",
      role: "switch",
      "aria-checked": n,
      disabled: a,
      onClick: () => r(!n),
      children: [
        /* @__PURE__ */ e("span", { children: t }),
        /* @__PURE__ */ e("span", { className: Ue("fp-switch", n && "is-on"), children: /* @__PURE__ */ e("i", {}) })
      ]
    }
  );
}
function bb({
  label: t,
  min: n = 0,
  max: r = 100,
  step: a = 1,
  value: i,
  defaultValue: l,
  className: s,
  ...c
}) {
  let [u, d] = k(
    () => l === void 0 ? void 0 : Number(l)
  ), p = i !== void 0 ? Number(i) : u, h = Number(n), f = Number(r), m = p === void 0 || f === h ? 0 : (p - h) / (f - h) * 100;
  return /* @__PURE__ */ o("label", { className: Ue("fp-slider", s), children: [
    t,
    /* @__PURE__ */ e(
      "input",
      {
        ...c,
        type: "range",
        min: n,
        max: r,
        step: a,
        value: i,
        defaultValue: l,
        onChange: (b) => {
          d(Number(b.target.value)), c.onChange?.(b);
        },
        style: {
          ...c.style,
          "--fp-slider-fill": `${Math.min(100, Math.max(0, m))}%`
        }
      }
    )
  ] });
}
function cp({
  children: t,
  selected: n,
  onClick: r,
  onRemove: a
}) {
  return /* @__PURE__ */ o("span", { className: Ue("fp-chip", n && "is-selected"), children: [
    /* @__PURE__ */ e("button", { type: "button", onClick: r, "aria-pressed": n, children: t }),
    a && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-label": `移除 ${typeof t == "string" ? t : "项目"}`,
        onClick: a,
        children: "×"
      }
    )
  ] });
}
function dp({
  name: t,
  src: n,
  size: r = 36
}) {
  return /* @__PURE__ */ e("span", { className: "fp-avatar", style: { width: r, height: r }, children: n ? /* @__PURE__ */ e("img", { src: n, alt: t }) : t.slice(0, 1) });
}
function gb({ names: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-avatar-group", children: t.map((n) => /* @__PURE__ */ e(dp, { name: n }, n)) });
}
function yb() {
  return /* @__PURE__ */ e("hr", { className: "fp-divider" });
}
function vb({
  title: t,
  children: n,
  tone: r = "accent"
}) {
  return /* @__PURE__ */ o(
    "div",
    {
      className: `fp-alert fp-tone-${r}`,
      role: r === "error" ? "alert" : "status",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-alert-dot" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: t }),
          n && /* @__PURE__ */ e("p", { children: n })
        ] })
      ]
    }
  );
}
function wb({
  width: t = "100%",
  height: n = 16
}) {
  return /* @__PURE__ */ e("div", { className: "fp-skeleton", style: { width: t, height: n }, "aria-hidden": "true" });
}
function kb({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-progress-wrap", children: [
    n && /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ o("span", { children: [
        Math.round(t),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "fp-progress",
        role: "progressbar",
        "aria-label": n || "完成进度",
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": Math.min(100, Math.max(0, t)),
        children: /* @__PURE__ */ e("i", { style: { width: `${Math.min(100, Math.max(0, t))}%` } })
      }
    )
  ] });
}
function up(t) {
  return /* @__PURE__ */ e("div", { className: "fp-segmented", children: /* @__PURE__ */ e(mi, { ...t }) });
}
function Nb({
  items: t
}) {
  return /* @__PURE__ */ e("nav", { "aria-label": "当前位置", className: "fp-breadcrumbs", children: t.map((n, r) => /* @__PURE__ */ o(Lt.Fragment, { children: [
    r > 0 && /* @__PURE__ */ e("span", { children: "/" }),
    n.href ? /* @__PURE__ */ e("a", { href: n.href, children: n.label }) : /* @__PURE__ */ e("span", { "aria-current": "page", children: n.label })
  ] }, n.label)) });
}
function xb({
  page: t,
  total: n,
  onChange: r
}) {
  return /* @__PURE__ */ o("nav", { className: "fp-row", "aria-label": "分页", children: [
    /* @__PURE__ */ e(
      le,
      {
        variant: "secondary",
        size: "sm",
        disabled: t <= 1,
        onClick: () => r(t - 1),
        children: "上一页"
      }
    ),
    /* @__PURE__ */ o("span", { className: "fp-muted", children: [
      t,
      " / ",
      n
    ] }),
    /* @__PURE__ */ e(
      le,
      {
        variant: "secondary",
        size: "sm",
        disabled: t >= n,
        onClick: () => r(t + 1),
        children: "下一页"
      }
    )
  ] });
}
function Cb({
  items: t,
  current: n
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-steps", children: t.map((r, a) => /* @__PURE__ */ o(
    "li",
    {
      "aria-current": a === n ? "step" : void 0,
      className: a <= n ? "is-active" : "",
      children: [
        /* @__PURE__ */ e("span", { children: a < n ? "✓" : a + 1 }),
        r
      ]
    },
    r
  )) });
}
const pp = "https://go.r-l.ink/ico";
function Sb({
  size: t = 32,
  decorative: n = !1
}) {
  return /* @__PURE__ */ e(
    "img",
    {
      src: pp,
      alt: n ? "" : "五加一",
      width: t,
      height: t,
      className: "fp-brand-logo"
    }
  );
}
function on({
  open: t,
  onClose: n,
  title: r,
  children: a,
  footer: i,
  drawer: l = !1,
  className: s,
  dismissible: c = !0
}) {
  let u = B(null), d = Ne();
  return Y(() => {
    let p = u.current;
    t && !p?.open && p?.showModal(), !t && p?.open && p.close();
  }, [t]), typeof window > "u" ? null : Te(
    /* @__PURE__ */ o(
      "dialog",
      {
        ref: u,
        className: Ue("fp-dialog", l && "fp-drawer", s),
        "aria-labelledby": d,
        onCancel: (p) => {
          p.preventDefault(), c && n();
        },
        onClick: (p) => {
          if (p.target === p.currentTarget) {
            let h = p.currentTarget.getBoundingClientRect();
            (p.clientX < h.left || p.clientX > h.right || p.clientY < h.top || p.clientY > h.bottom) && c && n();
          }
        },
        children: [
          /* @__PURE__ */ o("header", { children: [
            /* @__PURE__ */ e("h2", { id: d, children: r }),
            c && /* @__PURE__ */ e(at, { label: "关闭", onClick: n, children: "×" })
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-dialog-body", children: a }),
          i && /* @__PURE__ */ e("footer", { children: i })
        ]
      }
    ),
    document.body
  );
}
function Mb(t) {
  return /* @__PURE__ */ e(on, { ...t, drawer: !0 });
}
function hp({
  title: t,
  description: n,
  action: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-empty", children: [
    /* @__PURE__ */ e("div", { className: "fp-empty-symbol", children: "＋" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r
  ] });
}
function Eb({
  message: t,
  onClose: n
}) {
  return Y(() => {
    let r = setTimeout(n, 4e3);
    return () => clearTimeout(r);
  }, [t, n]), /* @__PURE__ */ o("div", { className: "fp-toast", role: "status", children: [
    /* @__PURE__ */ e("span", { children: "✓" }),
    t,
    /* @__PURE__ */ e(at, { label: "关闭提示", onClick: n, children: "×" })
  ] });
}
function $b({
  columns: t,
  rows: n,
  caption: r
}) {
  return /* @__PURE__ */ e("div", { className: "fp-table-scroll", children: /* @__PURE__ */ o("table", { className: "fp-table", children: [
    r && /* @__PURE__ */ e("caption", { children: r }),
    /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: t.map((a) => /* @__PURE__ */ e("th", { children: a }, a)) }) }),
    /* @__PURE__ */ e("tbody", { children: n.map((a, i) => /* @__PURE__ */ e("tr", { children: a.map((l, s) => /* @__PURE__ */ e("td", { children: l }, s)) }, i)) })
  ] }) });
}
function zb({
  items: t
}) {
  return /* @__PURE__ */ e("dl", { className: "fp-descriptions", children: t.map((n) => /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ e("dt", { children: n.label }),
    /* @__PURE__ */ e("dd", { children: n.value })
  ] }, n.label)) });
}
function fp({
  items: t
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-timeline", children: t.map((n) => /* @__PURE__ */ o("li", { children: [
    /* @__PURE__ */ e("strong", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function Ib({
  label: t,
  value: n,
  detail: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-stat", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e("strong", { children: n }),
    r && /* @__PURE__ */ e("small", { children: r })
  ] });
}
function Ab({
  onFiles: t,
  accept: n,
  multiple: r = !0
}) {
  let [a, i] = k([]);
  function l(s) {
    let c = Array.from(s || []);
    i(c.map((u) => u.name)), t(c);
  }
  return /* @__PURE__ */ o(
    "label",
    {
      className: "fp-upload",
      onDragOver: (s) => s.preventDefault(),
      onDrop: (s) => {
        s.preventDefault(), l(s.dataTransfer.files);
      },
      children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: "↥" }),
        /* @__PURE__ */ e("strong", { children: "选择文件，或拖放到这里" }),
        /* @__PURE__ */ e("small", { children: a.length ? a.join("、") : "资料会保留在你的设备上" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "file",
            accept: n,
            multiple: r,
            onChange: (s) => l(s.target.files)
          }
        )
      ]
    }
  );
}
function mp({
  value: t,
  onChange: n,
  placeholder: r = "搜索内容"
}) {
  return /* @__PURE__ */ o("div", { className: "fp-search-input", children: [
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌕" }),
    /* @__PURE__ */ e(
      qr,
      {
        "aria-label": r,
        placeholder: r,
        value: t,
        onChange: (a) => n(a.target.value)
      }
    ),
    t && /* @__PURE__ */ e(at, { label: "清除搜索", onClick: () => n(""), children: "×" })
  ] });
}
function Lb({
  value: t,
  onChange: n,
  min: r = 0,
  max: a = 100,
  label: i
}) {
  return /* @__PURE__ */ o("div", { className: "fp-number", children: [
    /* @__PURE__ */ e(
      at,
      {
        label: `减少${i}`,
        disabled: t <= r,
        onClick: () => n(t - 1),
        children: "−"
      }
    ),
    /* @__PURE__ */ e(
      qr,
      {
        "aria-label": i,
        type: "number",
        min: r,
        max: a,
        value: t,
        onChange: (l) => n(Math.min(a, Math.max(r, Number(l.target.value))))
      }
    ),
    /* @__PURE__ */ e(
      at,
      {
        label: `增加${i}`,
        disabled: t >= a,
        onClick: () => n(t + 1),
        children: "＋"
      }
    )
  ] });
}
function Tb({
  value: t,
  onChange: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-rating", role: "group", "aria-label": "评价", children: [1, 2, 3, 4, 5].map((r) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      "aria-label": `${r} 星`,
      "aria-pressed": r === t,
      onClick: () => n(r),
      className: r <= t ? "is-active" : "",
      children: "★"
    },
    r
  )) });
}
function Db({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-meter", children: [
    /* @__PURE__ */ e("meter", { min: 0, max: 100, value: t, "aria-label": n }),
    /* @__PURE__ */ o("span", { children: [
      n,
      " · ",
      t,
      "%"
    ] })
  ] });
}
function Pb({
  code: t,
  language: n = "tsx"
}) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-code", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ e(
        le,
        {
          size: "sm",
          variant: "ghost",
          onClick: async () => {
            try {
              await navigator.clipboard.writeText(t), a(!0), setTimeout(() => a(!1), 1800);
            } catch {
              a(!1);
            }
          },
          children: r ? "已复制" : "复制"
        }
      )
    ] }),
    /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: t }) })
  ] });
}
function Ob({ children: t }) {
  return /* @__PURE__ */ e("kbd", { className: "fp-kbd", children: t });
}
function Fb({
  children: t,
  ...n
}) {
  return /* @__PURE__ */ e("a", { ...n, className: Ue("fp-link", n.className), children: t });
}
function Rb({
  items: t
}) {
  return /* @__PURE__ */ e("div", { className: "fp-tree", children: t.map((n) => /* @__PURE__ */ e(bp, { item: n }, n.label)) });
}
function bp({
  item: t
}) {
  const [n, r] = Lt.useState(!0), a = Lt.useId();
  return t.children ? /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-tree-branch",
        "aria-expanded": n,
        "aria-controls": a,
        onClick: () => r((i) => !i),
        children: [
          /* @__PURE__ */ e(
            Ft,
            {
              size: 14,
              style: { transform: n ? "rotate(0)" : "rotate(-90deg)" }
            }
          ),
          t.label
        ]
      }
    ),
    /* @__PURE__ */ e(Oe, { isOpen: n, children: /* @__PURE__ */ e("div", { id: a, children: t.children.map((i) => /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: i }, i)) }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: t.label });
}
function Bb({
  items: t,
  value: n,
  onChange: r
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-navigation", children: t.map((a) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-current": n === a.value ? "page" : void 0,
      onClick: () => r(a.value),
      children: [
        a.icon,
        a.label
      ]
    },
    a.value
  )) });
}
function jb({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-toolbar", role: "group", "aria-label": "内容操作", children: t });
}
function qb({
  title: t,
  children: n
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-callout", children: [
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function Kb({
  title: t,
  detail: n,
  onClick: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-citation", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "↗" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] })
  ] });
}
function Ub({
  role: t,
  children: n
}) {
  return /* @__PURE__ */ o("article", { className: `fp-message fp-message-${t}`, children: [
    /* @__PURE__ */ e("strong", { children: t === "user" ? "你" : "五加一 AI" }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function Hb({
  onSend: t,
  disabled: n = !1
}) {
  let [r, a] = k("");
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-composer",
      onSubmit: (i) => {
        i.preventDefault(), r.trim() && (t(r.trim()), a(""));
      },
      children: [
        /* @__PURE__ */ e(
          op,
          {
            "aria-label": "向 AI 提问",
            placeholder: "从一个想法开始…",
            value: r,
            onChange: (i) => a(i.target.value),
            disabled: n
          }
        ),
        /* @__PURE__ */ o("footer", { children: [
          /* @__PURE__ */ e("span", { children: "让想法继续生长" }),
          /* @__PURE__ */ e(le, { size: "sm", disabled: n || !r.trim(), type: "submit", children: "发送 ↑" })
        ] })
      ]
    }
  );
}
function _b({
  title: t,
  steps: n,
  running: r,
  onToggle: a
}) {
  return /* @__PURE__ */ o(Gt, { children: [
    /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(hi, { tone: r ? "accent" : "neutral", children: r ? "进行中" : "已暂停" })
    ] }),
    /* @__PURE__ */ e(
      fp,
      {
        items: n.map((i, l) => ({
          title: i,
          description: l === n.length - 1 ? r ? "正在进行" : "等待继续" : "已完成"
        }))
      }
    ),
    /* @__PURE__ */ e(le, { variant: "secondary", size: "sm", onClick: a, children: r ? "暂停整理" : "继续整理" })
  ] });
}
function Wb({
  title: t,
  description: n,
  onApply: r
}) {
  return /* @__PURE__ */ o(Gt, { children: [
    /* @__PURE__ */ e(hi, { tone: "success", children: "已完成" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { className: "fp-muted", children: n }),
    /* @__PURE__ */ e(le, { onClick: r, children: "应用到笔记 ↗" })
  ] });
}
function Vb({
  name: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-file-card", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "▤" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { children: "↗" })
  ] });
}
function Xb({
  eyebrow: t,
  title: n,
  description: r,
  action: a
}) {
  return /* @__PURE__ */ o("header", { className: "fp-page-header", children: [
    /* @__PURE__ */ o("div", { children: [
      t && /* @__PURE__ */ e("span", { className: "fp-eyebrow", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      r && /* @__PURE__ */ e("p", { children: r })
    ] }),
    a
  ] });
}
function Yb({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: Ue("fp-container", n), children: t });
}
function Gb({
  children: t,
  gap: n,
  direction: r = "column"
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "flex",
        flexDirection: r,
        gap: n ?? (r === "row" ? 12 : 24),
        flexWrap: r === "row" ? "wrap" : void 0
      },
      children: t
    }
  );
}
function Jb({
  children: t,
  minWidth: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "grid",
        gridTemplateColumns: `repeat(auto-fit,minmax(min(${n}px,100%),1fr))`,
        gap: 20
      },
      children: t
    }
  );
}
function Qb({
  children: t,
  height: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-scroll-area",
      tabIndex: 0,
      style: { maxHeight: n, overflow: "auto" },
      children: t
    }
  );
}
function Zb({
  children: t,
  ratio: n = 16 / 9
}) {
  return /* @__PURE__ */ e("div", { style: { aspectRatio: n, overflow: "hidden" }, children: t });
}
function eg({
  label: t,
  options: n,
  value: r,
  onChange: a
}) {
  return /* @__PURE__ */ o("fieldset", { className: "fp-multiselect", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    n.map((i) => /* @__PURE__ */ e(
      cp,
      {
        selected: r.includes(i),
        onClick: () => a(
          r.includes(i) ? r.filter((l) => l !== i) : [...r, i]
        ),
        children: i
      },
      i
    ))
  ] });
}
function tg({
  label: t = "密码",
  ...n
}) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-password", children: [
    /* @__PURE__ */ e(qr, { ...n, "aria-label": t, type: r ? "text" : "password" }),
    /* @__PURE__ */ e(
      at,
      {
        label: r ? "隐藏密码" : "显示密码",
        onClick: () => a(!r),
        type: "button",
        children: r ? "隐藏" : "显示"
      }
    )
  ] });
}
function ng({
  children: t,
  onClose: n
}) {
  return /* @__PURE__ */ o("div", { className: "fp-banner", role: "status", children: [
    /* @__PURE__ */ e("span", { children: t }),
    n && /* @__PURE__ */ e(at, { label: "关闭通知", onClick: n, children: "×" })
  ] });
}
function rg({
  value: t,
  onChange: n
}) {
  let r = t ? /* @__PURE__ */ new Date(t + "T12:00:00") : /* @__PURE__ */ new Date(), [a, i] = k(
    new Date(r.getFullYear(), r.getMonth(), 1)
  ), l = a.getFullYear(), s = a.getMonth(), c = new Date(l, s, 1).getDay(), u = new Date(l, s + 1, 0).getDate();
  return /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e(
        at,
        {
          label: "上个月",
          onClick: () => i(new Date(l, s - 1, 1)),
          children: "‹"
        }
      ),
      /* @__PURE__ */ o("strong", { children: [
        l,
        " 年 ",
        s + 1,
        " 月"
      ] }),
      /* @__PURE__ */ e(
        at,
        {
          label: "下个月",
          onClick: () => i(new Date(l, s + 1, 1)),
          children: "›"
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-calendar-grid", children: [
      "日一二三四五六".split("").map((d) => /* @__PURE__ */ e("span", { children: d }, d)),
      Array.from({ length: c }, (d, p) => /* @__PURE__ */ e("span", {}, "s" + p)),
      Array.from({ length: u }, (d, p) => {
        let h = `${l}-${String(s + 1).padStart(2, "0")}-${String(p + 1).padStart(2, "0")}`;
        return /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": h,
            "aria-pressed": t === h,
            onClick: () => n(h),
            children: p + 1
          },
          h
        );
      })
    ] })
  ] });
}
function ag({
  first: t,
  second: n
}) {
  let [r, a] = k(50), i = B(null);
  return /* @__PURE__ */ o(
    "div",
    {
      ref: i,
      className: "fp-resizable",
      style: {
        gridTemplateColumns: `minmax(0,${r}fr) 10px minmax(0,${100 - r}fr)`
      },
      children: [
        /* @__PURE__ */ e("div", { children: t }),
        /* @__PURE__ */ e(
          "div",
          {
            role: "separator",
            "aria-label": "调整面板宽度",
            "aria-orientation": "vertical",
            "aria-valuenow": Math.round(r),
            "aria-valuemin": 25,
            "aria-valuemax": 75,
            tabIndex: 0,
            onKeyDown: (l) => {
              ["ArrowLeft", "ArrowRight", "Home", "End"].includes(l.key) && (l.preventDefault(), a(
                l.key === "Home" ? 25 : l.key === "End" ? 75 : Math.max(
                  25,
                  Math.min(75, r + (l.key === "ArrowRight" ? 5 : -5))
                )
              ));
            },
            onPointerDown: (l) => {
              l.currentTarget.setPointerCapture(l.pointerId);
            },
            onPointerMove: (l) => {
              if (l.currentTarget.hasPointerCapture(l.pointerId)) {
                let s = i.current.getBoundingClientRect();
                a(
                  Math.max(
                    25,
                    Math.min(75, (l.clientX - s.left) / s.width * 100)
                  )
                );
              }
            }
          }
        ),
        /* @__PURE__ */ e("div", { children: n })
      ]
    }
  );
}
function ig({
  open: t,
  onClose: n,
  onConfirm: r,
  title: a,
  description: i
}) {
  return /* @__PURE__ */ e(
    on,
    {
      open: t,
      onClose: n,
      title: a,
      footer: /* @__PURE__ */ o(Z, { children: [
        /* @__PURE__ */ e(le, { variant: "secondary", onClick: n, children: "取消" }),
        /* @__PURE__ */ e(le, { variant: "danger", onClick: r, children: "确认移除" })
      ] }),
      children: /* @__PURE__ */ e("p", { children: i })
    }
  );
}
function lg({
  open: t,
  onClose: n,
  items: r
}) {
  let [a, i] = k(""), [l, s] = k(0), c = r.filter(
    (u) => u.label.toLowerCase().includes(a.toLowerCase())
  );
  return Y(() => {
    t && (i(""), s(0));
  }, [t]), /* @__PURE__ */ e(on, { open: t, onClose: n, title: "快速前往", children: /* @__PURE__ */ o(
    "div",
    {
      onKeyDown: (u) => {
        u.key === "ArrowDown" && (u.preventDefault(), s((l + 1) % Math.max(1, c.length))), u.key === "ArrowUp" && (u.preventDefault(), s(
          (l - 1 + c.length) % Math.max(1, c.length)
        )), u.key === "Enter" && c[l] && (u.preventDefault(), c[l].onSelect(), n());
      },
      children: [
        /* @__PURE__ */ e(
          mp,
          {
            value: a,
            onChange: (u) => {
              i(u), s(0);
            },
            placeholder: "搜索页面与组件"
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-command-results", children: [
          c.map((u, d) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: d === l ? "is-active" : "",
              onClick: () => {
                u.onSelect(), n();
              },
              children: [
                u.label,
                /* @__PURE__ */ e("span", { children: "↵" })
              ]
            },
            u.label
          )),
          !c.length && /* @__PURE__ */ e("p", { children: "没有匹配的结果，试试其他关键词。" })
        ] })
      ]
    }
  ) });
}
function og({
  items: t,
  onRead: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-notifications", children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
    /* @__PURE__ */ e("span", { className: Ue("fp-notification-dot", !r.read && "is-unread") }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: r.title }),
      /* @__PURE__ */ e("small", { children: r.detail })
    ] }),
    /* @__PURE__ */ e("span", { children: r.read ? "已读" : "查看" })
  ] }, r.id)) });
}
function sg({
  items: t,
  label: n
}) {
  let r = Math.max(1, ...t.map((a) => a.value));
  return /* @__PURE__ */ o("figure", { className: "fp-chart", "aria-label": n, children: [
    /* @__PURE__ */ e("figcaption", { children: n }),
    t.map((a) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("span", { children: a.label }),
      /* @__PURE__ */ e("i", { style: { width: `${a.value / r * 70}%` } }),
      /* @__PURE__ */ e("strong", { children: a.value })
    ] }, a.label))
  ] });
}
function cg({ src: t, alt: n }) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o(Z, { children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-image-button",
        onClick: () => a(!0),
        "aria-label": `放大${n}`,
        children: /* @__PURE__ */ e("img", { src: t, alt: n })
      }
    ),
    /* @__PURE__ */ e(on, { open: r, onClose: () => a(!1), title: n, children: /* @__PURE__ */ e("img", { style: { width: "100%" }, src: t, alt: n }) })
  ] });
}
function dg({
  title: t = "暂时无法显示内容",
  description: n,
  onRetry: r
}) {
  return /* @__PURE__ */ e(
    hp,
    {
      title: t,
      description: n,
      action: /* @__PURE__ */ e(le, { onClick: r, children: "重新加载" })
    }
  );
}
function ug({ children: t }) {
  return /* @__PURE__ */ e("footer", { className: "fp-footer", children: t });
}
function pg({ children: t }) {
  return /* @__PURE__ */ e("span", { className: "fp-sr-only", children: t });
}
export {
  Hb as AIComposer,
  Ub as AIMessage,
  sf as AISettingsWorkspace,
  rm as AcademicYearSwitcher,
  ih as Accordion,
  Uh as AccountLayout,
  Im as AccountMenu,
  ml as ActionToolbar,
  ul as AdministratorAccess,
  Jh as AdministratorDirectory,
  Kf as AgentTrace,
  vb as Alert,
  eb as AnalyticsWorkspace,
  pf as AnchoredPanel,
  fe as AnimatedSize,
  Rm as AppEntryLayout,
  df as AppearanceWorkspace,
  Lm as ApplicationAccess,
  im as ApprovalCard,
  kf as ArtifactCard,
  Nf as ArtifactPreview,
  Zb as AspectRatio,
  ib as AssistantPreferences,
  be as AsyncAction,
  Gi as Attachment,
  Xf as AttachmentGrid,
  Rf as AttachmentPicker,
  xn as AudioPlayer,
  db as AuditLogWorkspace,
  tm as AuthenticationWindow,
  dp as Avatar,
  gb as AvatarGroup,
  zh as BacklinksPanel,
  hi as Badge,
  ng as Banner,
  sg as BarChart,
  qh as Bookshelf,
  um as BottomNav,
  Sb as BrandLogo,
  Nb as Breadcrumbs,
  vu as BrowserPreferences,
  ku as BrowserSurface,
  Bh as BrowserWorkspace,
  le as Button,
  Fm as ButtonLink,
  rg as Calendar,
  qb as Callout,
  br as CanvasBlockRenderer,
  lc as CanvasDiagnosticPanel,
  oc as CanvasRevisionPanel,
  Sf as CanvasWorkbench,
  af as CanvasWorkspace,
  Qh as CapacityDirectory,
  dl as CapacityEditor,
  xh as CapacityOverview,
  Gt as Card,
  ys as CardBodyBoundary,
  gf as CardEditorFrame,
  Gc as CauseEffect,
  Ff as ChatComposer,
  Qf as ChatEmptyState,
  Sm as ChatPreferencesPanel,
  Kr as Checkbox,
  cp as Chip,
  Am as ChoiceCards,
  Kb as Citation,
  am as CitationList,
  Mf as ClassroomTimeline,
  Pb as CodeBlock,
  Pf as CollaborativeEditor,
  Oe as CollapseTransition,
  Vf as CollapsibleSection,
  fl as ColorPicker,
  Af as Combobox,
  lg as CommandMenu,
  lf as CommerceWorkspace,
  Vc as CompareTable,
  Wc as ConceptCard,
  ig as ConfirmDialog,
  Yb as Container,
  gr as ContentImage,
  pl as ContentSkeleton,
  gt as ContextMenu,
  qf as ConversationViewport,
  Lh as CourseContentWorkspace,
  Cu as CreditAdjustment,
  Nh as CreditsOverview,
  Aa as DatePicker,
  Jc as Derivation,
  zb as DescriptionList,
  on as Dialog,
  Xi as DirectiveBlock,
  Ns as DirectiveFields,
  Vh as DirectoryPicker,
  jh as DirectoryWorkspace,
  bf as DiscardChangesPrompt,
  cm as DistributionChart,
  yb as Divider,
  Om as DocumentationCards,
  Pm as DocumentationLayout,
  Mb as Drawer,
  bi as Dropdown,
  Hi as EditorContextMenu,
  Dd as EditorUniqueID,
  Gf as EmbedFallback,
  hp as EmptyState,
  dg as ErrorState,
  va as EventCard,
  uh as ExperimentLibrary,
  hb as ExperimentWorkbench,
  Dm as FeatureCardStack,
  fb as Field,
  Qc as Figure,
  Vb as FileCard,
  Lf as FileTree,
  Ab as FileUpload,
  nm as FilterSelect,
  Uf as FlipCard,
  Oh as FloatingWindow,
  ef as FollowUpQuestions,
  ug as Footer,
  sm as FormulaSteps,
  zi as FunctionPlot,
  Cf as GraphView,
  Jb as Grid,
  Nu as GroupEditor,
  td as HistoryLocationMap,
  hh as HistoryMap,
  cs as HorizontalScrollbar,
  at as IconButton,
  Wi as ImageConversion,
  pm as ImageGallery,
  Ih as ImagePasteOptions,
  cg as ImagePreview,
  Fh as ImportPanel,
  qr as Input,
  Tm as InstallerPanel,
  Wh as InvitationList,
  Ob as Kbd,
  _c as KeyPoint,
  Rh as LazyVisible,
  Zc as LearningAnimation,
  Ci as LearningExperiment,
  uf as LearningRecords,
  uu as LearningSourceView,
  Ef as LectureDock,
  du as LectureWorkspace,
  kh as LedgerView,
  Fb as Link,
  Hh as LoginForm,
  rb as ManagementForm,
  pu as ManagementTable,
  nb as ManagementWorkspace,
  bt as MarkdownContent,
  Xn as MarkdownEditor,
  jf as MarkdownEditorSurface,
  ps as MediaControls,
  Gu as MediaLightbox,
  pr as MediaSlider,
  ju as MemberAccess,
  qu as MemberSearch,
  ph as MemoryCard,
  ji as MermaidPreview,
  Bu as MessageBubble,
  wf as MessageContentView,
  Of as MessageList,
  Db as Meter,
  Xm as MobileActionGrid,
  Ym as MobileCollectionRow,
  Wm as MobileHeader,
  Jm as MobileNotebookCard,
  Gm as MobileNotebookGrid,
  Zm as MobileRecorder,
  Vm as MobileSection,
  Kh as MobileTopBar,
  Qm as MobileWelcome,
  Wu as ModelSelector,
  eg as MultiSelect,
  gh as NOTE_SCHEMA_VERSION,
  Bb as Navigation,
  fm as NavigationCard,
  bu as NoteEditorWorkspace,
  fh as NoteLink,
  zd as NoteToolbar,
  Eh as NotebookManagerWorkspace,
  hu as NotebookPublishing,
  og as NotificationList,
  Lb as NumberInput,
  Xb as PageHeader,
  xb as Pagination,
  tg as PasswordInput,
  us as PdfPreview,
  Ch as PermissionSummary,
  Xh as PlanPicker,
  Zh as PlatformReset,
  Gh as PlatformWorkspace,
  oh as Popover,
  Qe as Popup,
  mm as PreviewCard,
  Km as ProductFeatures,
  jm as ProductLanding,
  xu as ProductNavigation,
  qm as ProductSection,
  kb as Progress,
  lb as ProviderManager,
  Yf as QuizQuestion,
  $f as QuizScoring,
  zf as QuizSummary,
  ym as QuizWorkspace,
  La as READING_FONTS,
  mb as Radio,
  Tb as Rating,
  nd as ReadingTimeline,
  ed as RecallContent,
  xm as RecordingPlayback,
  bm as RecycleBin,
  nf as ReleaseNotice,
  ag as ResizablePanel,
  tb as ResourceBrowser,
  ip as ResourceExplorer,
  fs as ResourcePreview,
  Mm as ResourceWorkspace,
  Wb as ResultCard,
  gm as ReviewDashboard,
  Nm as RunWorkspace,
  $h as SaveConflict,
  Qb as ScrollArea,
  mp as SearchInput,
  yf as SearchResults,
  up as SegmentedControl,
  If as Select,
  we as SelectField,
  vm as SelectionActions,
  Hf as SelectionToolbar,
  em as SessionHistory,
  Sh as SettingsForm,
  mf as SettingsLayout,
  ob as SettingsLinks,
  Jf as SettingsSection,
  _e as SettingsTabs,
  Mh as SetupWizard,
  Cm as ShareAccessPanel,
  Ku as ShareLink,
  ff as ShareMemberRow,
  tf as SharedReadingPage,
  dm as ShortcutHelp,
  Th as ShortcutProvider,
  Ph as ShortcutSettings,
  om as SiblingFiles,
  wb as Skeleton,
  xf as SkillsPanel,
  of as SkillsWorkspace,
  ub as SlideTransition,
  bb as Slider,
  Zf as SourceFold,
  fi as Spinner,
  Gb as Stack,
  Ib as Stat,
  Bm as StatusPage,
  Cb as Steps,
  ru as SuggestionList,
  Js as SurfaceBoundary,
  $i as SvgCanvas,
  sp as Switch,
  _f as SyncStatus,
  $b as Table,
  mi as Tabs,
  wm as TaskProgress,
  _b as TaskStatus,
  op as Textarea,
  hf as ThemeToggle,
  cf as TimePicker,
  fp as Timeline,
  Eb as Toast,
  lm as TocTree,
  Vu as TokenDashboard,
  Wf as TokenDashboardAuto,
  jb as Toolbar,
  fd as Tooltip,
  hd as TooltipProvider,
  _m as TransferQueue,
  Rb as Tree,
  Hm as UpdatePanel,
  ab as UpgradeRequiredDialog,
  Vi as UploadPlaceholder,
  Bf as UploadQueue,
  Yh as UserDetailsWorkspace,
  cb as UserNotebookList,
  _h as UserProfile,
  cl as UserProfileEditor,
  sb as UserUsageOverview,
  mh as VennDiagram,
  Ah as VersionDiff,
  mu as VersionHistory,
  Jt as VideoPlayer,
  Rc as VisualCodeBlock,
  pg as VisuallyHidden,
  ol as WindowChrome,
  $m as WindowControls,
  zm as WindowDragRegion,
  hm as WindowTaskbar,
  km as WorkspaceEmpty,
  Se as WorkspaceFeedback,
  X as WorkspaceField,
  Tf as WorkspaceLayout,
  it as WorkspaceSave,
  ee as WorkspaceSection,
  Um as WorkspaceSkeleton,
  vf as WorkspaceTabs,
  ze as WorkspaceToggle,
  ss as Y,
  bs as acknowledgeCardEdit,
  Tu as appearanceStyles,
  bh as appendUploadPlaceholder,
  Br as baseEditorExtensions,
  vh as bindNestedMathEditor,
  Au as brandColor,
  pp as brandLogoUrl,
  fa as calculateTicks,
  gi as cardEditRequested,
  pn as cardTypeForCommand,
  wa as codeLanguageForCommand,
  Rr as compileMathExpr,
  ch as configureEditorCommandUsage,
  yh as configureMathPreferences,
  ir as constrainWindowGeometry,
  gs as continueAfterCard,
  Iu as createEditableAIModel,
  Hd as createLazyMathExtensions,
  Ue as cx,
  Ta as defaultGraphSettings,
  ld as deleteEditorBlock,
  Ca as documentToMarkdown,
  ki as editorCommandFrequencies,
  dh as editorCommandFrequency,
  fr as editorCommandUsageChanged,
  hr as editorCommandUsageKey,
  Ui as editorInsertCommands,
  nn as editorSearchText,
  js as getLearningExperiment,
  Qn as insertDirectiveCard,
  qi as insertMermaidCard,
  lh as learningAlpha,
  Dr as learningExperiments,
  Ji as markdownToDocument,
  sh as mergeEditorCommandUsage,
  Em as mountWindowTitleBar,
  yr as moveEditorBlock,
  Oi as nestedEditorNodeViewEvents,
  Tn as normalizeBrowserUrl,
  wi as notifyEditorCommandUsage,
  wh as openActiveMathEditor,
  ms as openEditorLink,
  Ni as parseDirectiveAttributes,
  Sn as parseEditorCommandUsage,
  zu as parseSkillFile,
  Lu as productThemes,
  ws as recordEditorCommandUse,
  lr as replaceAIModelReferences,
  Du as resolveContentTypography,
  tc as sanitizeSvg,
  ud as searchEditorCommands,
  aa as setDirectiveAttribute,
  vr as tableSizeForCommand,
  Df as useCollaboration,
  ou as useMathEditor,
  rf as useReleaseUpdate,
  Dh as useShortcut,
  Le as useWorkspaceAction,
  et as useWorkspaceDraft,
  za as validateAISettings,
  Eu as validateCommerceSettings,
  Pu as visibleActionCount,
  pb as workspaceTabShortcut
};
