import { type ReactNode, type InputHTMLAttributes } from 'react';
import './account-task.css';
/** Progress belongs to a task, while verification and persistence remain host responsibilities. */
export declare function AccountTaskProgress({ steps, current }: {
    steps: string[];
    current: number;
}): import("react").JSX.Element;
export declare function AccountField({ label, hint, error, ...input }: InputHTMLAttributes<HTMLInputElement> & {
    label: string;
    hint?: ReactNode;
    error?: string;
}): import("react").JSX.Element;
export declare function AccountFeedback({ tone, title, children, action }: {
    tone?: 'info' | 'success' | 'error';
    title?: string;
    children?: ReactNode;
    action?: ReactNode;
}): import("react").JSX.Element;
export declare function AccountVerificationIntro({ description }: {
    description?: string;
}): import("react").JSX.Element;
export declare function AccountCodeField({ value, onChange, onSend, busy, sent, remaining, error, label, destination }: {
    value: string;
    onChange: (value: string) => void;
    onSend: () => void;
    busy?: boolean;
    sent?: boolean;
    remaining?: number;
    error?: string;
    label?: string;
    destination?: string;
}): import("react").JSX.Element;
export declare function useAccountTaskBusy(busy: boolean): void;
export declare function AccountTaskDialog({ title, onClose, children }: {
    title: string;
    onClose: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
