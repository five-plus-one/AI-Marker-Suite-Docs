type IndicatorOptions = {
    active: string;
    surface?: boolean;
    inset?: number;
    indicator?: HTMLElement;
};
/** Follow the committed selection, including interrupted switches and container resizing. */
export declare function mountSelectionIndicator(host: HTMLElement, { active, surface, inset, indicator: provided }: IndicatorOptions): {
    update: (animate?: boolean) => void;
    destroy(): void;
};
export {};
