export interface ReleaseNoteGroup {
    title: string;
    items: {
        text: string;
        id?: string;
        aliases?: string[];
    }[];
}
export interface ReleaseHistoryEntry {
    version: string;
    date?: string;
    id?: string;
    aliases?: string[];
    items: string[];
}
export interface ReleaseNotesProps {
    version: string;
    versionId?: string;
    date?: string;
    badge: string;
    description: string;
    groups: ReleaseNoteGroup[];
    emptyMessage?: string;
    history?: ReleaseHistoryEntry[];
    historyLabel?: string;
    anchors?: string[];
}
/** Static markup keeps release contents readable in server-rendered documentation. */
export declare function renderReleaseNotes({ version, versionId, date, badge, description, groups, emptyMessage, history, historyLabel, anchors: compatibility }: ReleaseNotesProps): string;
export declare function ReleaseNotes(props: ReleaseNotesProps): import("react").JSX.Element;
