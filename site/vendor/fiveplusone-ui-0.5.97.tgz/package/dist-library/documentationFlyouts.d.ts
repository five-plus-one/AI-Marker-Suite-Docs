/** Keep the host's flyout state while supplying consistent dismissal behavior. */
export declare function mountDocumentationFlyouts(): () => void;
