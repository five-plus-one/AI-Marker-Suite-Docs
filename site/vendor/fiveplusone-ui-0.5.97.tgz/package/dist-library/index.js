import { jsx as e, jsxs as o, Fragment as Q } from "react/jsx-runtime";
import Pt, { useRef as B, useEffect as Y, useId as ve, useState as k, useLayoutEffect as Ce, useCallback as xe, Fragment as Wa, lazy as zl, Suspense as Al, createContext as cn, useContext as Bt, Component as Il, useMemo as Ue, Children as Ll, isValidElement as Va, cloneElement as Ya, forwardRef as Tl, useImperativeHandle as Dl } from "react";
import { createPortal as De } from "react-dom";
import { Minus as Ft, Plus as kn, Minimize2 as $r, Maximize2 as zr, Download as jt, RotateCcw as Je, ChevronDown as qt, Check as Pe, Play as tn, Pause as On, VolumeX as Xa, Volume2 as Ga, PictureInPicture as Pl, Maximize as Rn, ZoomIn as Ar, ZoomOut as Ir, ExternalLink as Kt, Pencil as Bn, Code2 as Lr, Trash2 as Ht, IndentIncrease as Fl, IndentDecrease as Ol, CornerDownLeft as Ja, ArrowDown as Qa, BookOpen as bt, ChevronRight as ze, ImageOff as Rl, Undo2 as Bl, Redo2 as jl, Paintbrush as ql, Bold as Kl, Italic as Hl, Baseline as Ul, Highlighter as _l, List as nn, Link2 as gt, Paperclip as fr, Sigma as It, Table2 as er, Strikethrough as Wl, Underline as Vl, Eraser as Yl, Quote as Za, Braces as Xl, Layers3 as la, Video as oa, Workflow as Gl, FlaskConical as Jl, Save as ei, MoreHorizontal as Ot, ListOrdered as Ql, Search as We, Star as sa, ChevronLeft as Tr, Keyboard as ti, Settings2 as Zl, Grid2X2 as eo, FileText as Qe, Clock as jn, Minimize as to, X as ge, Home as no, RefreshCw as qn, Monitor as ni, Smartphone as ro, Settings as ao, Menu as rn, Copy as Kn, CalendarDays as ri, Sun as io, Moon as lo, Columns2 as oo, Network as ca, SlidersHorizontal as so, ArrowUpRight as Dr, Eye as ai, Code as co, ImagePlus as uo, Upload as po, Images as ho, FolderOpen as ii, Folder as Nn, LoaderCircle as Rt, Square as Hn, ArrowUp as Pr, UserPlus as fo, UserRound as mo, Users as mr, RotateCw as li, AlertCircle as Fr, Loader as bo, Circle as oi, AlertTriangle as go, Cloud as vo, CloudOff as yo, Brain as wo, Wrench as ko, Cpu as No, Coins as xo, Lightbulb as da, ShieldAlert as Co, Sparkles as xn, Globe as So, MessageSquare as Mo, CircleDashed as Eo, CheckCircle2 as ct, ImageIcon as $o, FolderPlus as zo, LayoutGrid as Ao, FolderInput as Io, Share2 as Lo, FileCheck2 as To, ArrowRight as Un, ShieldCheck as Or, CircleAlert as Rr, ArrowDownToLine as Cn, PackageOpen as Do, ArrowUpFromLine as Po, ArrowLeft as Br, Mic as Fo, Activity as Oo, File as Ro, BookPlus as Bo, History as jo, Info as qo } from "lucide-react";
import { useReducedMotion as _n, motion as Wn } from "framer-motion";
import { Extension as jr, InputRule as Ko, Node as Vn, mergeAttributes as qr } from "@tiptap/core";
import { Plugin as dn, TextSelection as Ze, NodeSelection as Zt, PluginKey as si, Selection as Sn } from "@tiptap/pm/state";
import ci from "react-markdown";
import Ho from "remark-gfm";
import di from "remark-math";
import Uo from "remark-directive";
import ui from "rehype-katex";
import _o from "rehype-raw";
import Wo, { defaultSchema as Mt } from "rehype-sanitize";
import { visit as an } from "unist-util-visit";
import Vo from "dompurify";
import { ReactNodeViewRenderer as Xt, NodeViewWrapper as Lt, NodeViewContent as ua, useEditor as Yo, EditorContent as pi } from "@tiptap/react";
import { CodeBlockLowlight as hi } from "@tiptap/extension-code-block-lowlight";
import { createLowlight as Xo, common as Go } from "lowlight";
import { closeHistory as fi } from "@tiptap/pm/history";
import { yUndoPluginKey as mi } from "@tiptap/y-tiptap";
import "katex/contrib/mhchem";
import { DecorationSet as br, Decoration as bi } from "@tiptap/pm/view";
import { DOMSerializer as Jo } from "@tiptap/pm/model";
import Qo from "@tiptap/extension-collaboration";
import Zo from "@tiptap/extension-collaboration-caret";
import es from "@tiptap/extension-placeholder";
import { pinyin as ts } from "pinyin-pro";
import ns from "@tiptap/starter-kit";
import rs from "@tiptap/extension-link";
import { Mathematics as as, InlineMath as is, BlockMath as ls } from "@tiptap/extension-mathematics";
import { TableKit as os } from "@tiptap/extension-table";
import { Markdown as ss, MarkdownManager as gi } from "@tiptap/markdown";
import cs from "@tiptap/extension-image";
import ds from "@tiptap/extension-unique-id";
import { TextStyle as us } from "@tiptap/extension-text-style";
import { Color as ps } from "@tiptap/extension-color";
import hs from "@tiptap/extension-highlight";
import vi from "katex";
import { PanelGroup as fs, PanelResizeHandle as ms, Panel as bs } from "react-resizable-panels";
import { HocuspocusProvider as gs } from "@hocuspocus/provider";
import * as vs from "yjs";
import { useVirtualizer as yi } from "@tanstack/react-virtual";
function Re({ isOpen: t, children: n, duration: r = 240, easing: a = "cubic-bezier(0.2, 0, 0, 1)" }) {
  return /* @__PURE__ */ e("div", { className: "fp-collapse-transition", "data-open": t || void 0, "aria-hidden": !t, inert: !t, style: { display: "grid", gridTemplateRows: t ? "1fr" : "0fr", transition: `grid-template-rows ${r}ms ${a}, opacity ${r}ms ${a}`, opacity: t ? 1 : 0 }, children: /* @__PURE__ */ e("div", { style: { minHeight: 0, overflow: "hidden" }, children: n }) });
}
function wi(t, { active: n, surface: r = !1, inset: a = 0, indicator: i }) {
  const l = i || document.createElement("span");
  l.classList.add("fp-selection-indicator"), l.setAttribute("aria-hidden", "true"), i || t.append(l), t.dataset.fpSelection = r ? "surface" : "underline";
  const s = window.matchMedia?.("(prefers-reduced-motion: reduce)");
  let c, u = !1, d = 0, p = !1, h;
  const f = (w = !0) => {
    const v = t.querySelector(n), N = t.getBoundingClientRect();
    if (!v || !N.width || !N.height) {
      c?.cancel(), l.style.opacity = "0", u = !1, h = void 0;
      return;
    }
    const x = v.getBoundingClientRect(), C = { left: x.left - N.left + t.scrollLeft + a, top: r ? x.top - N.top + t.scrollTop : t.clientHeight - 3, width: Math.max(0, x.width - a * 2), height: r ? x.height : 3 };
    if (h && Object.entries(C).every(([K, S]) => Math.abs(S - h[K]) < 0.5)) return;
    const I = l.getBoundingClientRect(), L = { left: I.left - N.left + t.scrollLeft, top: I.top - N.top + t.scrollTop, width: I.width, height: I.height };
    if (c?.cancel(), h = C, Object.assign(l.style, { left: C.left + "px", top: C.top + "px", width: C.width + "px", height: C.height + "px", opacity: "1" }), w && !s?.matches && typeof l.animate == "function") {
      const K = (S) => Object.fromEntries(Object.entries(S).map(([A, D]) => [A, D + "px"]));
      if (u) {
        const S = r ? C.top - L.top : C.left - L.left, A = r ? { ...C, top: L.top + S * 0.58, height: C.height + Math.min(Math.abs(S) * 0.18, 20) } : { ...C, left: L.left + S * 0.58, width: Math.max(L.width, C.width) + Math.min(Math.abs(S) * 0.2, 28) };
        c = l.animate([{ ...K(L), offset: 0 }, { ...K(A), offset: 0.48 }, { ...K(C), offset: 1 }], { duration: 400, easing: "cubic-bezier(.2,.7,.2,1)" });
      } else c = l.animate([{ opacity: 0, transform: r ? "scale(.98)" : "scaleX(.55)" }, { opacity: 1, transform: "scale(1)" }], { duration: 280, easing: "cubic-bezier(.16,1,.3,1)" });
    }
    u = !0;
  }, m = (w = !0) => {
    p ||= w, d || (d = requestAnimationFrame(() => {
      d = 0;
      const v = p;
      p = !1, f(v);
    }));
  }, b = new MutationObserver(() => m());
  b.observe(t, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["class", "aria-selected", "aria-current"] });
  const g = typeof ResizeObserver > "u" ? void 0 : new ResizeObserver(() => m(!1));
  g?.observe(t), t.querySelectorAll("a,button").forEach((w) => g?.observe(w));
  const y = () => {
    c?.cancel(), f(!1);
  };
  return s?.addEventListener("change", y), f(!1), { update: f, destroy() {
    cancelAnimationFrame(d), c?.cancel(), b.disconnect(), g?.disconnect(), s?.removeEventListener("change", y), delete t.dataset.fpSelection, i || l.remove();
  } };
}
const _e = (...t) => t.filter(Boolean).join(" ");
function te({
  variant: t = "primary",
  size: n = "md",
  loading: r,
  multiline: a = !1,
  children: i,
  className: l,
  title: s,
  type: c = "button",
  ...u
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      ...u,
      "data-multiline": a || void 0,
      "data-fp-tooltip": s || u["data-fp-tooltip"] || u["aria-label"],
      type: c,
      disabled: u.disabled || r,
      className: _e("fp-button", `fp-${t}`, `fp-${n}`, l),
      "aria-busy": r,
      children: [
        r && /* @__PURE__ */ e(Hr, { size: 16 }),
        i
      ]
    }
  );
}
function Kr({
  children: t,
  tone: n = "neutral"
}) {
  return /* @__PURE__ */ e("span", { className: `fp-badge fp-tone-${n}`, children: t });
}
function Dt({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: _e("fp-card", n), children: t });
}
function Hr({ size: t = 22 }) {
  return /* @__PURE__ */ e(
    "span",
    {
      role: "status",
      "aria-label": "正在处理",
      className: "fp-spinner",
      style: { width: t, height: t }
    }
  );
}
function Ur({
  items: t,
  value: n,
  onChange: r,
  id: a,
  label: i
}) {
  let l = B(null);
  const s = t.map((c) => c.label).join("\0");
  return Y(() => {
    const c = l.current;
    if (!c) return;
    const u = c.querySelector(".fp-tab-indicator");
    if (!u) return;
    const d = wi(c, { active: 'button[aria-selected="true"]', indicator: u });
    return () => d.destroy();
  }, [s]), /* @__PURE__ */ o(
    "div",
    {
      ref: l,
      className: "fp-tabs",
      role: "tablist",
      "aria-label": i,
      onKeyDown: (c) => {
        if (!t.length || c.altKey || c.ctrlKey || c.metaKey) return;
        let u = t.findIndex((p) => p.value === n), d = c.key === "ArrowRight" ? (u + 1) % t.length : c.key === "ArrowLeft" ? (u - 1 + t.length) % t.length : c.key === "Home" ? 0 : c.key === "End" ? t.length - 1 : -1;
        d >= 0 && (c.preventDefault(), r(t[d].value), l.current?.children[d]?.focus());
      },
      children: [
        t.map((c) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            role: "tab",
            id: a ? `${a}-tab-${c.value}` : void 0,
            "aria-controls": a ? `${a}-panel-${c.value}` : void 0,
            "aria-selected": c.value === n,
            tabIndex: c.value === n ? 0 : -1,
            onClick: () => r(c.value),
            children: c.label
          },
          c.value
        )),
        /* @__PURE__ */ e(
          "span",
          {
            className: "fp-tab-indicator",
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function yh({
  items: t
}) {
  const [n, r] = Pt.useState(/* @__PURE__ */ new Set()), a = Pt.useId();
  return /* @__PURE__ */ e("div", { className: "fp-accordion", children: t.map((i, l) => /* @__PURE__ */ o("div", { className: "fp-accordion-item", children: [
    /* @__PURE__ */ o(
      "button",
      {
        className: "fp-accordion-trigger",
        type: "button",
        "aria-expanded": n.has(l),
        "aria-controls": `${a}-${l}`,
        onClick: () => r((s) => {
          const c = new Set(s);
          return c.has(l) ? c.delete(l) : c.add(l), c;
        }),
        children: [
          i.title,
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "＋" })
        ]
      }
    ),
    /* @__PURE__ */ e(Re, { isOpen: n.has(l), children: /* @__PURE__ */ e("div", { id: `${a}-${l}`, className: "fp-accordion-content", children: i.content }) })
  ] }, i.title)) });
}
function ut({
  open: t,
  onClose: n,
  title: r,
  children: a,
  footer: i,
  drawer: l = !1,
  className: s,
  dismissible: c = !0
}) {
  let u = B(null), d = ve();
  return Y(() => {
    let p = u.current;
    t && !p?.open && p?.showModal(), !t && p?.open && p.close();
  }, [t]), typeof window > "u" ? null : De(
    /* @__PURE__ */ o(
      "dialog",
      {
        ref: u,
        className: _e("fp-dialog", l && "fp-drawer", s),
        "aria-labelledby": d,
        onCancel: (p) => {
          p.preventDefault(), c && n();
        },
        onClick: (p) => {
          if (p.target === p.currentTarget) {
            let h = p.currentTarget.getBoundingClientRect();
            (p.clientX < h.left || p.clientX > h.right || p.clientY < h.top || p.clientY > h.bottom) && c && n();
          }
        },
        children: [
          /* @__PURE__ */ o("header", { children: [
            /* @__PURE__ */ e("h2", { id: d, children: r }),
            c && /* @__PURE__ */ e(te, { variant: "ghost", className: "fp-icon-button", "aria-label": "关闭", title: "关闭", onClick: n, children: "×" })
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-dialog-body", children: a }),
          i && /* @__PURE__ */ e("footer", { children: i })
        ]
      }
    ),
    document.body
  );
}
function wh(t) {
  return /* @__PURE__ */ e(ut, { ...t, drawer: !0 });
}
function kh(t, n) {
  const r = Math.max(0, Math.min(255, parseInt(n, 16) || 0));
  return `color-mix(in srgb, ${t} ${Math.round(r / 255 * 1e4) / 100}%, transparent)`;
}
function ys({
  value: t,
  max: n,
  viewport: r,
  controls: a,
  onChange: i
}) {
  const l = B(null), s = B(
    null
  ), [c, u] = k(!1), d = Math.max(0, n), p = d <= 0 ? 1 : Math.max(0.08, Math.min(1, r / Math.max(1, r + d))), f = (d > 0 ? Math.min(1, Math.max(0, t / d)) : 0) * (1 - p), m = (g) => Math.max(0, Math.min(d, g)), b = (g) => i(m(g));
  return /* @__PURE__ */ o(
    "div",
    {
      ref: l,
      className: "horizontal-scrollbar",
      role: "scrollbar",
      "aria-label": "横向滚动预览",
      "aria-orientation": "horizontal",
      "aria-controls": a,
      "aria-valuemin": 0,
      "aria-valuemax": Math.round(d),
      "aria-valuenow": Math.round(t),
      "data-dragging": c || void 0,
      tabIndex: 0,
      onPointerDown: (g) => {
        if (g.button !== 0 || !l.current) return;
        const y = l.current.getBoundingClientRect(), w = y.width * (1 - p), v = g.target === g.currentTarget ? (g.clientX - y.left - y.width * p / 2) / Math.max(1, w) * d : t;
        b(v), s.current = {
          x: g.clientX,
          value: m(v),
          travel: w
        }, u(!0), g.currentTarget.setPointerCapture(g.pointerId);
      },
      onPointerMove: (g) => {
        s.current && b(
          s.current.value + (g.clientX - s.current.x) / Math.max(1, s.current.travel) * d
        );
      },
      onPointerUp: (g) => {
        s.current = null, u(!1), g.currentTarget.hasPointerCapture(g.pointerId) && g.currentTarget.releasePointerCapture(g.pointerId);
      },
      onPointerCancel: () => {
        s.current = null, u(!1);
      },
      onKeyDown: (g) => {
        const y = g.key === "ArrowLeft" ? -48 : g.key === "ArrowRight" ? 48 : g.key === "PageUp" ? -r : g.key === "PageDown" ? r : 0;
        (y || g.key === "Home" || g.key === "End") && (g.preventDefault(), b(
          g.key === "Home" ? 0 : g.key === "End" ? d : t + y
        ));
      },
      children: [
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-fill",
            style: { width: `${(f + p) * 100}%` },
            "aria-hidden": "true"
          }
        ),
        /* @__PURE__ */ e(
          "span",
          {
            className: "horizontal-scrollbar-thumb",
            style: { width: `${p * 100}%`, left: `${f * 100}%` },
            "aria-hidden": "true"
          }
        )
      ]
    }
  );
}
function fe({ children: t, initialHeight: n, className: r }) {
  const a = B(null), [i, l] = k(n), s = _n();
  return Ce(() => {
    const c = a.current;
    if (!c) return;
    const u = () => l(c.getBoundingClientRect().height);
    if (u(), typeof ResizeObserver > "u") return;
    const d = new ResizeObserver(u);
    return d.observe(c), () => d.disconnect();
  }, []), /* @__PURE__ */ e(
    Wn.div,
    {
      className: r,
      "data-animated-size": "",
      initial: n === void 0 ? !1 : { height: n, opacity: 0 },
      animate: { height: i ?? "auto", opacity: 1 },
      exit: { height: n ?? 0, opacity: 0 },
      transition: { duration: s ? 0 : 0.24, ease: [0.2, 0, 0, 1] },
      style: { overflow: "clip", minWidth: 0 },
      children: /* @__PURE__ */ e("div", { ref: a, style: { display: "flow-root", minWidth: 0 }, children: t })
    }
  );
}
function ws({
  page: t,
  zoom: n,
  aspect: r,
  onAspect: a,
  expanded: i
}) {
  const l = B(null), [s, c] = k(t.n <= 2), [u, d] = k(!1), [p, h] = k(0), [f, m] = k(!1);
  Y(() => {
    if (s || !l.current) return;
    const g = i ? l.current.closest(".resource-detail") : l.current.closest(".pdf-preview-pages"), y = new IntersectionObserver(
      (w) => {
        w.some((v) => v.isIntersecting) && (c(!0), y.disconnect());
      },
      { root: g, rootMargin: "700px 0px" }
    );
    return y.observe(l.current), () => y.disconnect();
  }, [s, i]), Y(() => {
    d(!1), h(0);
  }, [t.url]);
  const b = `${Math.round(n * 100)}%`;
  return /* @__PURE__ */ e(
    "div",
    {
      ref: l,
      "data-pdf-sheet": t.n,
      style: {
        width: b,
        aspectRatio: f ? void 0 : String(r),
        margin: n <= 1 ? "0 auto 12px" : "0 0 12px",
        background: "#fff",
        boxShadow: "0 1px 4px rgba(0,0,0,.12)"
      },
      children: s && (u ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
        "第 ",
        t.n,
        " 页加载失败。",
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              d(!1), h((g) => g + 1);
            },
            children: "重试"
          }
        )
      ] }) : /* @__PURE__ */ e(
        "img",
        {
          src: p ? `${t.url}${t.url.includes("?") ? "&" : "?"}retry=${p}` : t.url,
          alt: `第 ${t.n} 页`,
          draggable: !1,
          onLoad: (g) => {
            const y = g.currentTarget;
            t.n === 1 && y.naturalWidth > 0 && y.naturalHeight > 0 && a(y.naturalWidth / y.naturalHeight), m(!0);
          },
          onError: () => {
            m(!1), d(!0);
          },
          style: { display: "block", width: "100%", height: "auto" }
        }
      ))
    }
  );
}
function ks({
  url: t,
  name: n,
  downloadUrl: r
}) {
  const a = B(null), i = B(null), l = ve(), s = B(null), [c, u] = k(!1), [d, p] = k(null), [h, f] = k("loading"), [m, b] = k(1), [g, y] = k(""), [w, v] = k(!1), [N, x] = k(1), [C, I] = k(0.707), [L, K] = k(0), [S, A] = k({ left: 0, max: 0 });
  Y(() => {
    b(1), y(""), I(0.707), i.current && (i.current.scrollTop = 0);
  }, [t]), Y(() => {
    if (!a.current) return;
    const j = new IntersectionObserver(
      (T) => {
        T.some((M) => M.isIntersecting) && (u(!0), j.disconnect());
      },
      { rootMargin: "200px" }
    );
    return j.observe(a.current), () => j.disconnect();
  }, []), Y(() => {
    if (!c) return;
    const j = new AbortController();
    let T, M = 0, R = "";
    p(null), f("loading");
    const q = async () => {
      try {
        const F = new URL(t, window.location.href);
        F.searchParams.set("view", "pages"), F.searchParams.delete("download"), R && F.searchParams.set("hash", R);
        const E = await fetch(F.href, {
          credentials: "include",
          signal: j.signal,
          cache: "no-store"
        });
        if (!E.ok) throw new Error("preview unavailable");
        const z = await E.json();
        if (j.signal.aborted) return;
        typeof z.contentHash == "string" && (R = z.contentHash), z.status === "ready" && z.manifest?.pages?.length ? (p({
          pages: z.manifest.pages,
          pageCount: z.manifest.pageCount || z.manifest.pages.length
        }), f("ready"), M = 0, T = setTimeout(() => {
          q();
        }, 1800 * 1e3)) : z.status === "failed" ? f("error") : (M++, f("rendering"), T = setTimeout(
          () => {
            q();
          },
          M < 15 ? 2e3 : M < 60 ? 5e3 : 1e4
        ));
      } catch {
        j.signal.aborted || f("error");
      }
    };
    return q(), () => {
      j.abort(), clearTimeout(T);
    };
  }, [t, c, L]);
  const D = xe(
    (j) => {
      const T = Math.max(1, Math.min(d?.pageCount || 1, j)), M = i.current, R = M?.querySelector(
        `[data-pdf-sheet="${T}"]`
      );
      M && R && (w ? R.scrollIntoView({ block: "start", behavior: "smooth" }) : M.scrollTo({
        top: M.scrollTop + R.getBoundingClientRect().top - M.getBoundingClientRect().top,
        behavior: "smooth"
      })), b(T);
    },
    [d?.pageCount, w]
  );
  Y(() => {
    const j = i.current;
    j && (j.scrollLeft = Math.max(
      0,
      (j.scrollWidth - j.clientWidth) / 2
    ));
  }, [N, h]), Y(() => {
    const j = i.current;
    if (!j) return;
    const T = () => A({
      left: j.scrollLeft,
      max: Math.max(0, j.scrollWidth - j.clientWidth)
    }), M = typeof ResizeObserver > "u" ? null : new ResizeObserver(T);
    M?.observe(j);
    const R = requestAnimationFrame(T);
    return () => {
      cancelAnimationFrame(R), M?.disconnect();
    };
  }, [N, h, d]);
  const U = (j) => {
    i.current && (i.current.scrollLeft = j), A((T) => ({ ...T, left: j }));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: a,
      className: `pdf-preview pdf-preview-scroll${w ? " pdf-preview-expanded" : " pdf-preview-windowed"}`,
      "aria-label": `${n} 预览`,
      children: [
        /* @__PURE__ */ o("div", { className: "pdf-preview-controls", children: [
          /* @__PURE__ */ o("div", { className: "pdf-page-navigation", children: [
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(
                "input",
                {
                  type: "number",
                  min: 1,
                  max: d?.pageCount || 1,
                  value: g || m,
                  onChange: (j) => y(j.target.value),
                  onKeyDown: (j) => {
                    j.key === "Enter" && (D(Number(g || m)), y(""));
                  },
                  "aria-label": "跳转到页码"
                }
              ),
              " ",
              "/ ",
              d?.pageCount || "…",
              " 页"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h !== "ready",
                onClick: () => {
                  D(Number(g || m)), y("");
                },
                children: "跳转"
              }
            )
          ] }),
          /* @__PURE__ */ o("div", { className: "pdf-zoom-controls", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: N <= 0.5 || h !== "ready",
                onClick: () => x((j) => Math.max(0.5, j - 0.25)),
                "aria-label": "缩小",
                children: /* @__PURE__ */ e(Ft, {})
              }
            ),
            /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                className: "pdf-zoom-value",
                title: "恢复适合宽度",
                onClick: () => x(1),
                children: [
                  Math.round(N * 100),
                  "%"
                ]
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: N >= 3 || h !== "ready",
                onClick: () => x((j) => Math.min(3, j + 0.25)),
                "aria-label": "放大",
                children: /* @__PURE__ */ e(kn, {})
              }
            )
          ] }),
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "pdf-expand-toggle",
              "aria-label": w ? "固定窗口" : "完整展开",
              title: w ? "固定窗口" : "完整展开",
              "aria-pressed": w,
              "aria-controls": l,
              onClick: () => v((j) => !j),
              children: [
                w ? /* @__PURE__ */ e($r, { "aria-hidden": "true" }) : /* @__PURE__ */ e(zr, { "aria-hidden": "true" }),
                /* @__PURE__ */ e("span", { children: w ? "固定窗口" : "完整展开" })
              ]
            }
          ),
          /* @__PURE__ */ e(
            "a",
            {
              className: "pdf-download",
              "aria-label": "下载原文件",
              title: "下载原文件",
              href: r || `${t}${t.includes("?") ? "&" : "?"}download=1`,
              download: !0,
              children: /* @__PURE__ */ e(jt, {})
            }
          ),
          S.max > 1 && /* @__PURE__ */ e("div", { className: "pdf-preview-horizontal", children: /* @__PURE__ */ e(
            ys,
            {
              value: S.left,
              max: S.max,
              viewport: i.current?.clientWidth || 1,
              controls: l,
              onChange: U
            }
          ) })
        ] }),
        /* @__PURE__ */ e(fe, { children: h === "error" ? /* @__PURE__ */ o("div", { role: "alert", className: "pdf-preview-message", children: [
          "暂时无法预览此文件。",
          /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => K((j) => j + 1),
              children: [
                /* @__PURE__ */ e(Je, {}),
                "重试"
              ]
            }
          )
        ] }) : h !== "ready" ? /* @__PURE__ */ e("div", { role: "status", className: "pdf-preview-message", children: "正在准备预览…" }) : /* @__PURE__ */ e(
          "div",
          {
            ref: i,
            id: l,
            className: "pdf-preview-pages",
            style: { cursor: N > 1 ? "grab" : void 0 },
            onScroll: (j) => {
              const T = j.currentTarget.scrollLeft;
              A(
                (M) => M.left === T ? M : { ...M, left: T }
              );
            },
            onPointerDown: (j) => {
              N <= 1 || j.pointerType !== "mouse" || j.button !== 0 || (s.current = {
                x: j.clientX,
                left: j.currentTarget.scrollLeft
              }, j.currentTarget.setPointerCapture(j.pointerId), j.currentTarget.style.cursor = "grabbing");
            },
            onPointerMove: (j) => {
              s.current && (j.currentTarget.scrollLeft = s.current.left - (j.clientX - s.current.x));
            },
            onPointerUp: (j) => {
              s.current = null, j.currentTarget.style.cursor = "grab";
            },
            onPointerCancel: () => {
              s.current = null;
            },
            children: d?.pages.map((j) => /* @__PURE__ */ e(
              ws,
              {
                page: j,
                zoom: N,
                aspect: C,
                onAspect: I,
                expanded: w
              },
              j.n
            ))
          }
        ) })
      ]
    }
  );
}
function Ns({ progress: t, children: n, className: r = "", ...a }) {
  return /* @__PURE__ */ o("div", { ...a, "data-theme": "dark", className: `fp-media-controls ${r}`, children: [
    t && /* @__PURE__ */ e("div", { className: "fp-media-progress", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-media-toolbar", children: n })
  ] });
}
function gr({ className: t = "", style: n, min: r = 0, max: a = 100, value: i, ...l }) {
  const s = Math.max(0, Math.min(100, (Number(i ?? r) - Number(r)) / (Number(a) - Number(r) || 1) * 100));
  return /* @__PURE__ */ e("input", { ...l, type: "range", min: r, max: a, value: i, className: `fp-media-slider ${t}`, style: { ...n, "--fp-media-fill": `${s}%` } });
}
function Ut(t, n, r) {
  const [a, i] = k({});
  return Ce(() => {
    if (!n || !t.current) return;
    const l = () => {
      if (!t.current) return;
      const u = getComputedStyle(t.current), d = {
        color: u.color,
        colorScheme: u.colorScheme,
        fontFamily: u.fontFamily
      };
      for (let p = 0; p < u.length; p++) {
        const h = u.item(p);
        h.startsWith("--fp-") && (d[h] = u.getPropertyValue(h));
      }
      i((p) => {
        const h = d;
        return JSON.stringify(p) === JSON.stringify(h) ? p : h;
      });
    };
    l();
    const s = new MutationObserver(l);
    for (let u = t.current; u; u = u.parentElement)
      s.observe(u, { attributes: !0, attributeFilter: ["class", "style", "data-theme", "data-product"] });
    const c = window.matchMedia?.("(prefers-color-scheme: dark)");
    return c?.addEventListener("change", l), () => {
      s.disconnect(), c?.removeEventListener("change", l);
    };
  }, [t, n, r]), a;
}
function et({
  label: t,
  triggerRole: n,
  triggerId: r,
  children: a,
  menu: i = !1,
  icon: l,
  trigger: s,
  disabled: c,
  className: u = "",
  role: d,
  onOpenChange: p,
  density: h = "comfortable"
}) {
  const [f, m] = k(!1), [b, g] = k(!1), y = () => {
    g(!0), m(!1);
  };
  Y(() => {
    if (!b) return;
    const U = setTimeout(() => g(!1), 120);
    return () => clearTimeout(U);
  }, [b]);
  const w = B(null), v = B(null), N = Ut(w, f), x = ve(), C = B(p);
  C.current = p, Y(() => {
    C.current?.(f);
  }, [f]);
  const I = d || (i ? "menu" : "dialog"), [L, K] = k({ left: 8, top: 8, maxHeight: 400 }), S = () => {
    y(), w.current?.focus();
  }, A = I === "listbox" ? '[role="option"]:not(:disabled)' : '[role="menuitem"]:not(:disabled)', D = (U = !1) => requestAnimationFrame(() => {
    const j = v.current?.querySelectorAll(A), T = v.current?.querySelector(
      '[aria-selected="true"]:not(:disabled)'
    );
    (U ? j?.[j.length - 1] : T || j?.[0])?.focus();
  });
  return Ce(() => {
    if (!f) return;
    const U = () => {
      const T = w.current?.getBoundingClientRect(), M = v.current?.getBoundingClientRect();
      if (!T || !M) return;
      const R = window.innerHeight - T.bottom - 16, q = T.top - 16, F = R < Math.min(M.height, 240) && q > R, E = Math.max(80, F ? q : R), z = {
        left: Math.max(
          8,
          Math.min(T.left, window.innerWidth - M.width - 8)
        ),
        top: F ? Math.max(8, T.top - Math.min(M.height, E) - 8) : T.bottom + 8,
        maxHeight: E
      };
      K(
        ($) => $.left === z.left && $.top === z.top && $.maxHeight === z.maxHeight ? $ : z
      );
    };
    U(), window.addEventListener("resize", U), window.addEventListener("scroll", U, !0);
    const j = typeof ResizeObserver > "u" ? null : new ResizeObserver(U);
    return v.current && j?.observe(v.current), () => {
      j?.disconnect(), window.removeEventListener("resize", U), window.removeEventListener("scroll", U, !0);
    };
  }, [f]), Y(() => {
    c && f && y();
  }, [c]), Y(() => {
    if (!f) return;
    const U = (T) => {
      const M = T.target;
      !w.current?.contains(M) && !v.current?.contains(M) && y();
    }, j = (T) => {
      T.key === "Escape" && (!T.target.closest?.("[data-fp-overlay]") || T.target.closest?.("[data-fp-overlay]") === v.current) && (T.preventDefault(), T.stopPropagation(), S());
    };
    return document.addEventListener("pointerdown", U, !0), document.addEventListener("focusin", U, !0), document.addEventListener("keydown", j, !0), I === "listbox" && v.current?.querySelector(".fp-select-search input") ? requestAnimationFrame(
      () => v.current?.querySelector(".fp-select-search input")?.focus({ preventScroll: !0 })
    ) : I !== "dialog" ? D() : requestAnimationFrame(
      () => (v.current?.querySelector(
        '[aria-pressed="true"]:not(:disabled)'
      ) || v.current?.querySelector(
        'input:not(:disabled), button:not(:disabled), [tabindex="0"]'
      ))?.focus({ preventScroll: !0 })
    ), () => {
      document.removeEventListener("pointerdown", U, !0), document.removeEventListener("focusin", U, !0), document.removeEventListener("keydown", j, !0);
    };
  }, [f]), /* @__PURE__ */ o("span", { className: "fp-dropdown", children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        ref: w,
        role: n,
        id: r,
        disabled: c,
        "aria-label": t,
        "aria-expanded": f,
        "aria-controls": f ? x : void 0,
        "aria-haspopup": I,
        className: `fp-popup-trigger${l ? " fp-popup-icon" : ""}`,
        onClick: () => {
          f ? y() : (g(!1), m(!0));
        },
        onKeyDown: (U) => {
          I !== "dialog" && (U.key === "ArrowDown" || U.key === "ArrowUp") && (U.preventDefault(), m(!0), D(U.key === "ArrowUp"));
        },
        children: s || l || /* @__PURE__ */ o(Q, { children: [
          /* @__PURE__ */ e("span", { children: t }),
          /* @__PURE__ */ e(qt, { size: 15, "aria-hidden": "true" })
        ] })
      }
    ),
    (f || b) && De(
      /* @__PURE__ */ e(
        "div",
        {
          ref: v,
          "data-fp-overlay": "",
          id: x,
          role: I,
          "aria-label": t,
          "aria-hidden": b || void 0,
          inert: b,
          "data-exiting": b || void 0,
          className: `fp-popup-panel ${I === "menu" ? "fp-popup-menu" : I === "listbox" ? "fp-popup-listbox" : "fp-popover-content"} ${h === "compact" ? "fp-popup-compact" : ""} ${u}`,
          style: {
            ...N,
            position: "fixed",
            ...L,
            overflowY: "auto",
            maxWidth: "calc(100vw - 16px)"
          },
          onKeyDown: (U) => {
            if (I === "dialog") return;
            if (U.key === "Tab") {
              y(), w.current?.focus();
              return;
            }
            const j = Array.from(
              v.current?.querySelectorAll(A) || []
            ), T = j.indexOf(
              document.activeElement
            ), M = U.key === "ArrowDown" ? (T + 1) % j.length : U.key === "ArrowUp" ? (T - 1 + j.length) % j.length : U.key === "Home" ? 0 : U.key === "End" ? j.length - 1 : -1;
            M >= 0 && (U.preventDefault(), U.stopPropagation(), j[M]?.focus());
          },
          children: a(S)
        }
      ),
      w.current?.closest("[data-fp-overlay],dialog") || document.body
    )
  ] });
}
function ki({
  label: t,
  items: n,
  icon: r
}) {
  return /* @__PURE__ */ e(et, { label: t, icon: r, menu: !0, children: (a) => n.map((i) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      role: "menuitem",
      className: i.danger ? "fp-error-text" : "",
      onClick: () => {
        a(), i.onClick();
      },
      children: i.label
    },
    i.label
  )) });
}
function Nh({
  label: t,
  children: n
}) {
  return /* @__PURE__ */ e(et, { label: t, children: () => n });
}
function ke({ value: t, onChange: n, options: r, label: a, id: i, disabled: l, placeholder: s = "请选择", className: c = "", searchable: u = r.length > 8 }) {
  return /* @__PURE__ */ e("span", { className: `fp-select-field ${c}`, children: /* @__PURE__ */ e(et, { label: a, triggerRole: "combobox", triggerId: i, role: "listbox", disabled: l, className: "fp-select-options", trigger: /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: r.find((d) => d.value === t)?.fontFamily }, children: [
      r.find((d) => d.value === t)?.color && /* @__PURE__ */ e("i", { style: { background: r.find((d) => d.value === t)?.color } }),
      r.find((d) => d.value === t)?.label || s
    ] }),
    /* @__PURE__ */ e(qt, { size: 14, "aria-hidden": "true" })
  ] }), children: (d) => /* @__PURE__ */ e(xs, { options: r, value: t, searchable: u, onSelect: (p) => {
    n(p), d();
  } }) }) });
}
function xs({ options: t, value: n, searchable: r, onSelect: a }) {
  const [i, l] = k(""), s = t.filter((c) => `${c.label} ${c.value} ${c.description || ""}`.toLowerCase().includes(i.trim().toLowerCase()));
  return /* @__PURE__ */ o(Q, { children: [
    r && /* @__PURE__ */ e("div", { className: "fp-select-search", children: /* @__PURE__ */ e("input", { "aria-label": "搜索选项", placeholder: "搜索…", value: i, onChange: (c) => l(c.target.value), onKeyDown: (c) => {
      if (!c.nativeEvent.isComposing) {
        if (c.key === "ArrowDown" && (c.preventDefault(), c.currentTarget.parentElement?.nextElementSibling?.querySelector('[role="option"]:not(:disabled)')?.focus()), c.key === "Enter") {
          c.preventDefault();
          const u = s.find((d) => !d.disabled);
          u && a(u.value);
        }
        c.key !== "Escape" && c.stopPropagation();
      }
    } }) }),
    /* @__PURE__ */ o("div", { className: "fp-select-scroll", children: [
      s.map((c, u) => /* @__PURE__ */ o("div", { role: "none", children: [
        c.group && s[u - 1]?.group !== c.group && /* @__PURE__ */ e("div", { className: "fp-select-group", children: c.group }),
        /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": n === c.value, disabled: c.disabled, tabIndex: -1, onClick: () => a(c.value), children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ o("span", { className: "fp-select-value", style: { fontFamily: c.fontFamily }, children: [
              c.color && /* @__PURE__ */ e("i", { style: { background: c.color } }),
              c.label
            ] }),
            c.description && /* @__PURE__ */ e("small", { children: c.description })
          ] }),
          n === c.value && /* @__PURE__ */ e(Pe, { size: 14, "aria-hidden": "true" })
        ] })
      ] }, c.value)),
      !s.length && /* @__PURE__ */ e("p", { className: "fp-select-empty", children: "没有匹配的选项" })
    ] })
  ] });
}
function pa(t) {
  if (!Number.isFinite(t)) return "0:00";
  const n = Math.floor(t / 60), r = Math.floor(t % 60);
  return `${n}:${String(r).padStart(2, "0")}`;
}
function en({
  src: t,
  poster: n,
  title: r,
  startAt: a = 0,
  autoPlay: i = !1,
  onReady: l,
  onWindowPlayback: s,
  onTimeUpdate: c,
  onEnded: u,
  resolveSource: d,
  videoRef: p,
  onSeek: h,
  onPlaybackRateChange: f,
  onPlaybackError: m,
  tracks: b = [],
  onPictureInPictureChange: g,
  keyboardShortcuts: y = !0
}) {
  const w = B(null), v = B(null), N = B(a), x = B(t), C = B(null), [I, L] = k(b.findIndex((_) => _.default)), [K, S] = k(!1), [A, D] = k(a), [U, j] = k(0), [T, M] = k(1), [R, q] = k(!1), [F, E] = k(d ? "" : t), [z, $] = k(""), [P, re] = k(""), [ie, ye] = k(0), [he, W] = k(1), G = B({ onPlaybackError: m });
  G.current = { onPlaybackError: m };
  const ue = (_) => {
    $(_), G.current.onPlaybackError?.(_);
  };
  Y(() => {
    const _ = new AbortController();
    if (x.current !== t && (x.current = t, N.current = a), $(""), re(""), S(!1), D(N.current), j(0), !d) {
      E(t);
      return;
    }
    return E(""), d(t, _.signal).then((O) => {
      _.signal.aborted || E(O);
    }).catch((O) => {
      _.signal.aborted || ue(O instanceof Error ? O.message : "视频暂时无法播放");
    }), () => _.abort();
  }, [t, d, ie]), Y(() => {
    const _ = v.current;
    _ && (N.current = a, _.currentTime = a);
  }, [t, a]), Y(() => {
    const _ = v.current;
    if (!_) return;
    const O = () => g?.(!0), Z = () => g?.(!1);
    return _.addEventListener("enterpictureinpicture", O), _.addEventListener("leavepictureinpicture", Z), () => {
      _.removeEventListener("enterpictureinpicture", O), _.removeEventListener("leavepictureinpicture", Z);
    };
  }, [g]);
  const me = () => {
    const _ = v.current;
    _ && (_.paused ? _.play().catch(() => ue("暂时无法播放，请重试")) : _.pause());
  }, H = async () => {
    const _ = v.current;
    if (_)
      try {
        document.pictureInPictureElement ? await document.exitPictureInPicture() : document.pictureInPictureEnabled && await _.requestPictureInPicture();
      } catch {
        re("暂时无法打开画中画，请重试。");
      }
  }, V = async () => {
    try {
      re(""), document.fullscreenElement === w.current ? await document.exitFullscreen() : await w.current?.requestFullscreen?.();
    } catch {
      re("暂时无法进入全屏，请重试");
    }
  }, oe = (_) => {
    const O = v.current;
    !O || !Number.isFinite(O.duration) || O.duration <= 0 || (O.currentTime = Math.max(0, Math.min(O.duration, _)), D(O.currentTime));
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-video",
      ref: w,
      tabIndex: 0,
      role: "region",
      "aria-label": r ? `${r}视频播放器` : "视频播放器",
      "aria-keyshortcuts": y ? "Space k j l ArrowLeft ArrowRight ArrowUp ArrowDown m f Home End" : void 0,
      onKeyDown: (_) => {
        if (!y || _.defaultPrevented || _.nativeEvent.isComposing || _.ctrlKey || _.altKey || _.metaKey || _.target.closest('input,textarea,select,button,[contenteditable="true"],[role="combobox"],[role="menu"]')) return;
        const O = v.current;
        if (!O) return;
        const Z = _.key.toLowerCase();
        ![" ", "k", "j", "l", "arrowleft", "arrowright", "arrowup", "arrowdown", "m", "f", "home", "end", ",", "."].includes(Z) && !/^[0-9]$/.test(Z) || (_.preventDefault(), _.stopPropagation(), !(_.repeat && [" ", "k", "m", "f"].includes(Z)) && (Z === " " || Z === "k" ? me() : Z === "j" || Z === "arrowleft" ? oe(O.currentTime - (Z === "j" ? 10 : 5)) : Z === "l" || Z === "arrowright" ? oe(O.currentTime + (Z === "l" ? 10 : 5)) : Z === "home" ? oe(0) : Z === "end" ? oe(O.duration) : /^[0-9]$/.test(Z) ? oe(O.duration * Number(Z) / 10) : Z === "arrowup" || Z === "arrowdown" ? (O.volume = Math.max(0, Math.min(1, O.volume + (Z === "arrowup" ? 0.05 : -0.05))), Z === "arrowup" && (O.muted = !1), M(O.volume), q(O.muted)) : Z === "m" ? (O.muted = !O.muted, q(O.muted)) : Z === "f" ? V() : O.paused && oe(O.currentTime + (Z === "." ? 1 / 30 : -1 / 30))));
      },
      children: [
        /* @__PURE__ */ o("div", { className: "fp-video-stage", children: [
          /* @__PURE__ */ e(
            "video",
            {
              ref: (_) => {
                v.current = _, typeof p == "function" ? p(_) : p && (p.current = _);
              },
              src: F || void 0,
              poster: n,
              playsInline: !0,
              preload: "metadata",
              onCanPlay: (_) => {
                const O = _.currentTarget;
                l?.(O), i && C.current !== t && (C.current = t, O.play().catch(() => {
                }));
              },
              onClick: () => {
                w.current?.focus({ preventScroll: !0 }), me();
              },
              onPlay: () => S(!0),
              onPause: () => S(!1),
              onLoadedMetadata: (_) => {
                _.currentTarget.playbackRate = he, _.currentTarget.volume = T, _.currentTarget.muted = R, Array.from(_.currentTarget.textTracks).forEach((O, Z) => {
                  O.mode = Z === I ? "showing" : "disabled";
                }), j(_.currentTarget.duration), _.currentTarget.currentTime = Math.max(0, Math.min(N.current, _.currentTarget.duration || N.current));
              },
              onError: () => {
                F && ue("视频暂时无法播放，请重试");
              },
              onSeeked: (_) => h?.(_.currentTarget.currentTime),
              onRateChange: (_) => {
                W(_.currentTarget.playbackRate), f?.(_.currentTarget.playbackRate);
              },
              onVolumeChange: (_) => {
                M(_.currentTarget.volume), q(_.currentTarget.muted);
              },
              onTimeUpdate: (_) => {
                N.current = _.currentTarget.currentTime, D(_.currentTarget.currentTime), c?.(_.currentTarget.currentTime);
              },
              onEnded: () => {
                S(!1), u?.();
              },
              "aria-label": r || "视频",
              children: b.map((_) => /* @__PURE__ */ e("track", { kind: "subtitles", src: _.src, srcLang: _.language, label: _.label, default: _.default }, _.src))
            }
          ),
          z && /* @__PURE__ */ o("div", { className: "fp-video-error", role: "alert", children: [
            /* @__PURE__ */ e("span", { children: z }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              d || v.current?.load(), ye((_) => _ + 1);
            }, children: "重新加载" })
          ] }),
          !z && !F && /* @__PURE__ */ e("div", { className: "fp-video-error", role: "status", children: "正在准备视频…" }),
          !K && !z && F && /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-video-bigplay",
              "aria-label": "播放",
              onClick: () => {
                w.current?.focus({ preventScroll: !0 }), me();
              },
              children: /* @__PURE__ */ e(tn, { size: 26, fill: "currentColor" })
            }
          )
        ] }),
        /* @__PURE__ */ o(Ns, { progress: /* @__PURE__ */ e(
          gr,
          {
            type: "range",
            min: 0,
            max: U || 0,
            step: 0.1,
            value: A,
            "aria-label": "播放进度",
            onChange: (_) => {
              const O = Number(_.target.value);
              D(O), v.current && (v.current.currentTime = O);
            }
          }
        ), children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": K ? "暂停" : "播放",
              title: "播放／暂停（空格或 K）",
              onClick: me,
              children: K ? /* @__PURE__ */ e(On, { size: 16 }) : /* @__PURE__ */ e(tn, { size: 16 })
            }
          ),
          /* @__PURE__ */ o("span", { className: "fp-media-time", children: [
            pa(A),
            " / ",
            pa(U)
          ] }),
          b.length > 0 && /* @__PURE__ */ e(ke, { label: "字幕", value: String(I), options: [{ value: "-1", label: "关闭字幕" }, ...b.map((_, O) => ({ value: String(O), label: _.label }))], onChange: (_) => {
            const O = Number(_);
            L(O), v.current && Array.from(v.current.textTracks).forEach((Z, we) => {
              Z.mode = we === O ? "showing" : "disabled";
            });
          } }),
          /* @__PURE__ */ e(ke, { label: "播放速度", value: String(he), onChange: (_) => {
            v.current && (v.current.playbackRate = Number(_));
          }, options: [0.5, 0.75, 1, 1.25, 1.5, 2].map((_) => ({ value: String(_), label: `${_}×` })) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": R ? "取消静音" : "静音",
              title: "静音（M）",
              onClick: () => {
                const _ = v.current;
                _ && (_.muted = !_.muted, q(_.muted));
              },
              children: R ? /* @__PURE__ */ e(Xa, { size: 16 }) : /* @__PURE__ */ e(Ga, { size: 16 })
            }
          ),
          /* @__PURE__ */ e(
            gr,
            {
              className: "fp-media-volume",
              min: 0,
              max: 1,
              step: 0.05,
              value: T,
              "aria-label": "音量",
              onChange: (_) => {
                const O = Number(_.target.value);
                M(O), v.current && (v.current.volume = O);
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": s ? "小窗播放" : "画中画", disabled: !s && typeof document < "u" && !document.pictureInPictureEnabled, onClick: s ? () => s(v.current?.currentTime || 0) : H, children: /* @__PURE__ */ e(Pl, { size: 16 }) }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "全屏",
              title: "全屏（F）",
              onClick: () => {
                V();
              },
              children: /* @__PURE__ */ e(Rn, { size: 16 })
            }
          )
        ] }),
        P && /* @__PURE__ */ e("div", { className: "fp-video-notice", role: "status", children: P })
      ]
    }
  );
}
const ha = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function Mn({
  src: t,
  title: n = "音频",
  startAt: r = 0,
  onTimeUpdate: a,
  onEnded: i,
  resolveSource: l,
  audioRef: s,
  onSeek: c,
  onPlaybackRateChange: u
}) {
  const d = B(null), p = B(0), h = B(r), f = B(t), [m, b] = k(1), [g, y] = k(l ? "" : t), [w, v] = k(!1), [N, x] = k(0), [C, I] = k(0), [L, K] = k(1), [S, A] = k(""), [D, U] = k(0);
  Y(() => {
    const M = new AbortController(), R = ++p.current;
    return f.current !== t && (f.current = t, h.current = r), A(""), v(!1), x(h.current), I(0), y(""), Promise.resolve(l ? l(t, M.signal) : t).then((q) => {
      !M.signal.aborted && R === p.current && y(q);
    }).catch(() => {
      M.signal.aborted || A("音频暂时无法加载，请重试。");
    }), () => M.abort();
  }, [t, l, D]);
  const j = (M) => {
    if (d.current) {
      const R = Math.max(0, Math.min(C || 0, M));
      d.current.currentTime = R, x(R), h.current = R;
    }
  }, T = () => {
    const M = d.current;
    M && (M.paused ? M.play().catch(() => A("暂时无法播放，请重试。")) : M.pause());
  };
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-audio-player",
      "aria-label": n,
      tabIndex: 0,
      onKeyDown: (M) => {
        if (!M.target.closest("button,input") && [" ", "k", "ArrowLeft", "ArrowRight", "m"].includes(M.key))
          if (M.preventDefault(), M.key === " " || M.key === "k") T();
          else if (M.key === "m") {
            const R = L ? 0 : 1;
            K(R), d.current && (d.current.volume = R);
          } else j(N + (M.key === "ArrowLeft" ? -5 : 5));
      },
      children: [
        /* @__PURE__ */ e(
          "audio",
          {
            ref: (M) => {
              d.current = M, typeof s == "function" ? s(M) : s && (s.current = M);
            },
            src: g || void 0,
            preload: "metadata",
            onLoadedMetadata: () => {
              const M = d.current;
              I(Number.isFinite(M.duration) ? M.duration : 0), M.currentTime = Math.max(0, Math.min(h.current, M.duration || 0)), M.playbackRate = m, M.volume = L;
            },
            onSeeked: () => c?.(d.current.currentTime),
            onRateChange: () => {
              const M = d.current.playbackRate;
              b(M), u?.(M);
            },
            onTimeUpdate: () => {
              h.current = d.current.currentTime, x(h.current), a?.(d.current.currentTime);
            },
            onPlay: () => v(!0),
            onPause: () => v(!1),
            onEnded: () => {
              v(!1), i?.();
            },
            onError: () => {
              g && A("音频暂时无法加载，请重试。");
            }
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-audio-heading", children: [
          /* @__PURE__ */ e("strong", { children: n }),
          /* @__PURE__ */ o("span", { children: [
            ha(N),
            " / ",
            ha(C)
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-audio-controls", children: [
          /* @__PURE__ */ e(ke, { label: "播放速度", value: String(m), options: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((M) => ({ value: String(M), label: `${M}×` })), onChange: (M) => {
            b(Number(M)), d.current && (d.current.playbackRate = Number(M));
          } }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": w ? "暂停" : "播放",
              disabled: !g || !!S,
              onClick: T,
              children: w ? /* @__PURE__ */ e(On, { size: 18 }) : /* @__PURE__ */ e(tn, { size: 18 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "播放进度",
              type: "range",
              min: 0,
              max: C || 0,
              step: 0.1,
              value: Math.min(N, C),
              disabled: !C,
              onChange: (M) => j(Number(M.target.value))
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": L ? "静音" : "恢复音量",
              onClick: () => {
                const M = L ? 0 : 1;
                K(M), d.current && (d.current.volume = M);
              },
              children: L ? /* @__PURE__ */ e(Ga, { size: 17 }) : /* @__PURE__ */ e(Xa, { size: 17 })
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "音量",
              type: "range",
              min: 0,
              max: 1,
              step: 0.05,
              value: L,
              onChange: (M) => {
                const R = Number(M.target.value);
                K(R), d.current && (d.current.volume = R);
              }
            }
          )
        ] }),
        S && /* @__PURE__ */ o("p", { role: "alert", children: [
          S,
          /* @__PURE__ */ e("button", { type: "button", onClick: () => U((M) => M + 1), children: "重试" })
        ] })
      ]
    }
  );
}
function Cs({
  resource: t,
  renderVideoExtra: n,
  videoProps: r,
  audioProps: a
}) {
  let { name: i, url: l, mediaType: s = "", previewUrl: c, bytes: u = 0 } = t, [d, p] = k(""), [h, f] = k(!1), m = /^(text\/(plain|markdown|csv)|application\/json)$/.test(s) || /\.(txt|md|csv|json)$/i.test(i), b = /\.(pdf|pptx?|docx?|xlsx?|odt|odp|ods)$/i.test(i) || s === "application/pdf";
  const g = b ? Wa : fe;
  return Y(() => {
    if (p(""), f(!1), !m || u > 2e6) return;
    let y = new AbortController();
    return fetch(l, { signal: y.signal, credentials: "include" }).then((w) => {
      if (!w.ok) throw Error();
      return w.text();
    }).then((w) => {
      y.signal.aborted || p(w);
    }).catch(() => {
      y.signal.aborted || f(!0);
    }), () => y.abort();
  }, [l, m, u]), /* @__PURE__ */ o("section", { className: "fp-resource-preview", children: [
    /* @__PURE__ */ o("header", { className: "fp-resource-header", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: i }),
        /* @__PURE__ */ e("small", { children: b ? "文档预览" : s.startsWith("image/") ? "图片预览" : "文件预览" })
      ] }),
      !b && /* @__PURE__ */ o("a", { href: t.downloadUrl || l, download: i, children: [
        /* @__PURE__ */ e(jt, { size: 16, "aria-hidden": "true" }),
        "下载原文件"
      ] })
    ] }),
    /* @__PURE__ */ e(g, { children: b ? /* @__PURE__ */ e(
      ks,
      {
        url: c || l,
        name: i,
        downloadUrl: t.downloadUrl || l
      }
    ) : s.startsWith("image/") ? /* @__PURE__ */ e("img", { className: "fp-preview-image", src: l, alt: i }) : s.startsWith("video/") ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e(en, { ...r, src: l, title: i }),
      n
    ] }) : s.startsWith("audio/") ? /* @__PURE__ */ e(Mn, { ...a, src: l, title: i }) : m && u <= 2e6 ? /* @__PURE__ */ e("pre", { className: "fp-preview-text", children: h ? "暂时无法读取，请下载查看。" : d || "正在阅读文件…" }) : /* @__PURE__ */ e("div", { className: "pdf-preview-message", children: "此文件可以下载后查看。" }) })
  ] });
}
function Ss(t, n) {
  const a = (t.target instanceof Element ? t.target : t.target instanceof Node ? t.target.parentElement : null)?.closest("a[href]");
  if (!a) return !1;
  let i;
  try {
    i = new URL(a.href, window.location.href);
  } catch {
    return !1;
  }
  return ["http:", "https:", "mailto:", "tel:"].includes(i.protocol) ? (t.preventDefault(), t.stopPropagation(), n(i.href, a.textContent || ""), !0) : !1;
}
const En = /* @__PURE__ */ new WeakMap();
function Ni(t, n) {
  return typeof n == "string" && En.get(t) === n;
}
function Ms(t, n) {
  Ni(t, n) && En.delete(t);
}
function tr(t, n = "note") {
  if (!t.isEditable) return !1;
  const r = crypto.randomUUID();
  En.set(t, r);
  const a = t.chain().focus().insertContent({ type: "directiveBlock", attrs: { name: n, attributes: "", body: "", id: r } }).command(({ tr: i }) => {
    let l;
    return i.doc.descendants((s, c) => {
      if (s.type.name === "directiveBlock" && s.attrs.id === r)
        return l = c, !1;
    }), l === void 0 ? !1 : (i.setSelection(Zt.create(i.doc, l)), !0);
  }).run();
  return a || En.delete(t), a;
}
function Es(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const r = n();
  if (r === void 0) return !1;
  const a = t.state.doc.nodeAt(r);
  if (a?.type.name !== "directiveBlock") return !1;
  const i = r + a.nodeSize, l = t.chain().command(({ tr: s }) => (s.doc.nodeAt(i)?.type.name !== "paragraph" && s.insert(i, t.schema.nodes.paragraph.create()), s.setSelection(Ze.create(s.doc, i + 1)).setStoredMarks(null).scrollIntoView(), !0)).run();
  return l && t.view.focus(), l;
}
function fa(t) {
  let n = 0;
  return t.descendants((r) => {
    if (r.type.name === "directiveBlock")
      return n++, !1;
  }), n;
}
const $s = jr.create({ name: "cardBodyBoundary", addProseMirrorPlugins() {
  return [new dn({ filterTransaction: (t, n) => !t.docChanged || fa(t.doc) <= fa(n.doc) })];
} }), vr = "fp.editor.commands.v1", yr = "fp:editor-command-usage";
let xi, Et;
const wr = (t) => /^[a-zA-Z0-9:_-]{1,80}$/.test(t) && !["__proto__", "constructor", "prototype"].includes(t);
function $n(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    const r = JSON.parse(t || "null");
    if (r?.version !== 1 || !r.counts || typeof r.counts != "object") return n;
    for (const [a, i] of Object.entries(r.counts).slice(0, 128)) {
      if (!wr(a) || !i || typeof i != "object") continue;
      const l = /* @__PURE__ */ Object.create(null);
      for (const [s, c] of Object.entries(i).slice(0, 256)) wr(s) && typeof c == "number" && Number.isSafeInteger(c) && c > 0 && c <= 1e9 && (l[s] = c);
      n[a] = l;
    }
  } catch {
  }
  return n;
}
function xh(t, n) {
  const r = $n(t);
  for (const [a, i] of Object.entries($n(n))) {
    const l = r[a] ??= /* @__PURE__ */ Object.create(null);
    for (const [s, c] of Object.entries(i)) l[s] = Math.max(l[s] || 0, c);
  }
  return JSON.stringify({ version: 1, counts: r });
}
const Ci = () => xi ?? (typeof window < "u" ? window.localStorage : void 0);
function Ch(t) {
  xi = t, Si();
}
function Si() {
  typeof window < "u" && window.dispatchEvent(new Event(yr));
}
function Mi(t) {
  const n = /* @__PURE__ */ Object.create(null);
  try {
    for (const [r, a] of Object.entries($n(t === void 0 ? Ci()?.getItem(vr) ?? null : t))) n[r] = Object.values(a).reduce((i, l) => i + l, 0);
  } catch {
  }
  return n;
}
function Sh(t, n) {
  return Mi(n)[t] || 0;
}
function zs() {
  if (Et) return Et;
  const t = "fp.editor.command-device";
  try {
    Et = window.localStorage.getItem(t) || crypto.randomUUID(), window.localStorage.setItem(t, Et);
  } catch {
    Et = crypto.randomUUID();
  }
  return Et;
}
function As(t) {
  if (!wr(t) || typeof window > "u") return;
  const n = () => {
    try {
      const r = Ci();
      if (!r) return;
      const a = $n(r.getItem(vr)), i = zs(), l = a[t] ??= /* @__PURE__ */ Object.create(null);
      l[i] = Math.min(1e9, (l[i] || 0) + 1), r.setItem(vr, JSON.stringify({ version: 1, counts: a })), Si();
    } catch {
    }
  };
  navigator.locks ? navigator.locks.request("fp-editor-command-usage", n).catch(() => {
  }) : n();
}
function Ei(t) {
  const n = {}, r = /([\w-]+)=(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^\s}]+))/g;
  for (const a of t.matchAll(r))
    n[a[1]] = (a[2] ?? a[3] ?? a[4] ?? "").replace(
      /\\([\\"'])/g,
      "$1"
    );
  return n;
}
function ma(t, n, r) {
  const a = Ei(t);
  return r ? a[n] = r : delete a[n], Object.entries(a).map(
    ([i, l]) => `${i}="${l.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`
  ).join(" ");
}
const Is = {
  video: [
    ["src", "视频地址"],
    ["poster", "封面地址"]
  ],
  audio: [["src", "音频地址"]],
  figure: [
    ["src", "图片地址"],
    ["alt", "图片说明"],
    ["caption", "图片标题"],
    ["credit", "图片来源"]
  ],
  interactive: [["src", "内容地址"]],
  plot: [
    ["fn", "函数表达式"],
    ["xmin", "横轴最小值"],
    ["xmax", "横轴最大值"],
    ["ymin", "纵轴最小值"],
    ["ymax", "纵轴最大值"]
  ],
  historymap: [
    ["points", "地点与坐标"],
    ["caption", "地图说明"]
  ],
  learninganimation: [
    ["src", "演示地址"],
    ["source", "源文件地址"],
    ["caption", "演示说明"]
  ],
  event: [
    ["year", "事件时间"],
    ["location", "地点"],
    ["people", "人物"],
    ["result", "结果"],
    ["impact", "影响"]
  ],
  attachment: [
    ["src", "附件地址"],
    ["name", "附件名称"]
  ]
};
function Ls({
  name: t,
  value: n,
  onChange: r,
  disabled: a
}) {
  const i = Ei(n), s = {
    "learning-animation": "learninganimation",
    figuremedia: "figure",
    functionplot: "plot",
    eventcard: "event",
    noteattachment: "attachment",
    memorycard: "memory"
  }[t] || t, c = Is[s] || [];
  return !c.length && s !== "memory" ? null : /* @__PURE__ */ o("div", { className: "fp-directive-fields", children: [
    s === "memory" && /* @__PURE__ */ o("label", { children: [
      "回忆方式",
      /* @__PURE__ */ e(
        ke,
        {
          label: "回忆方式",
          value: i.mode || "checklist",
          onChange: (u) => r(ma(n, "mode", u)),
          disabled: a,
          options: [
            { value: "checklist", label: "逐项回忆" },
            { value: "cloze", label: "重点挖空" }
          ]
        }
      )
    ] }),
    c.map(([u, d]) => /* @__PURE__ */ o("label", { children: [
      d,
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": d,
          value: i[u] || "",
          disabled: a,
          onChange: (p) => r(ma(n, u, p.target.value))
        }
      )
    ] }, u))
  ] });
}
function Ts() {
  return (t) => {
    function n(r, a = !1) {
      if (r.type === "element" && ["code", "pre", "script", "style", "math"].includes(r.tagName)) return;
      const i = a || r.type === "element" && ["td", "th"].includes(r.tagName);
      for (let l = 0; l < r.children.length; l++) {
        const s = r.children[l];
        if (s.type === "element") {
          n(s, i);
          continue;
        }
        if (!i || s.type !== "text" || !s.value.includes("$")) continue;
        const c = [], u = new RegExp("(?<!\\\\)\\$(?!\\$)([^$\\n]+?)(?<!\\\\)\\$(?!\\$)", "g");
        let d = 0, p;
        for (; p = u.exec(s.value); )
          p.index > d && c.push({ type: "text", value: s.value.slice(d, p.index) }), c.push({ type: "element", tagName: "span", properties: { className: ["math-inline", "language-math"] }, children: [{ type: "text", value: p[1] }] }), d = p.index + p[0].length;
        c.length && (d < s.value.length && c.push({ type: "text", value: s.value.slice(d) }), r.children.splice(l, 1, ...c), l += c.length - 1);
      }
    }
    n(t);
  };
}
function Ds() {
  return (t) => {
    an(t, "containerDirective", (n) => {
      n.name === "callout" && an(
        n,
        "text",
        (r, a, i) => {
          if (a == null || i == null || i.children == null) return;
          const l = r.value;
          if (typeof l != "string" || !l.includes(`
`)) return;
          const s = l.split(`
`), c = [];
          return s.forEach((u, d) => {
            d > 0 && c.push({ type: "break" }), u && c.push({ type: "text", value: u });
          }), i.children.splice(a, 1, ...c), [void 0, a + c.length];
        }
      );
    });
  };
}
const Ps = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
];
new Set(Ps);
const zn = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function Fs(t) {
  const n = t.toLowerCase();
  return n in zn ? zn[n] ?? "note" : "note";
}
function Os(t) {
  const n = t.toLowerCase();
  return n in zn && zn[n] === null;
}
const Rs = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, Bs = /^(\s*)>( ?)(.*)$/;
function js(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (a) => {
    if (a === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const i = r ? "‘" : "’";
    return r = !r, i;
  });
}
function qs(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const y = c[1][0];
      a ? y === i && (a = !1, i = "") : (a = !0, i = y), r.push(s), l++;
      continue;
    }
    if (a) {
      r.push(s), l++;
      continue;
    }
    const u = s.match(Rs);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (Os(p)) {
      r.push(s), l++;
      continue;
    }
    const m = Fs(p), b = f.trim(), g = [`kind=${m}`];
    for (b && g.push(`label="${js(b)}"`), h === "-" && g.push("collapsed=true"), r.push(`${d}:::callout{${g.join(" ")}}`), l++; l < n.length; ) {
      const y = n[l];
      if (!/^\s*>/.test(y) || y.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const v = y.match(Bs);
      v ? r.push(v[3]) : r.push(y.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function Ks(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      a ? u === i && (a = !1, i = "") : (a = !0, i = u), r.push(l);
      continue;
    }
    if (a) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const Hs = /^(\s*:{1,4}[A-Za-z][\w-]*)(\{[^}\n]*\})([^\n]*)$/, Us = /^\{(label|title)=([\s\S]*)\}$/;
function _s(t) {
  return /^\{(?:label|title)=(?:"[^"]*"|'[^']*')(?:\s+[\s\S]*)?\}$/.test(t) ? t : t.replace(Us, (n, r, a) => {
    let i = a.trim();
    return i.length >= 2 && i.startsWith('"') && i.endsWith('"') && (i = i.slice(1, -1)), i = i.replace(/"([^"]*)"/g, "“$1”").replace(/"/g, "“"), i = i.replace(/'([^']*)'/g, "‘$1’").replace(/'/g, "‘"), `{${r}="${i}"}`;
  });
}
function Ws(t) {
  if (!t || (t = Ks(t), t = qs(t), t.indexOf("::") === -1)) return t;
  const n = t.split(`
`);
  let r = !1, a = "";
  for (let i = 0; i < n.length; i++) {
    const l = n[i], s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const f = s[1][0];
      r ? f === a && (r = !1, a = "") : (r = !0, a = f);
      continue;
    }
    if (r) continue;
    const c = l.match(Hs);
    if (!c) continue;
    const [, u, d, p] = c, h = _s(d);
    h !== d && (n[i] = u + h + p);
  }
  return n.join(`
`);
}
const Vs = { ...Mt, clobberPrefix: "fp-content-", tagNames: [...Mt.tagNames || [], "fp-directive", "mark"], attributes: { ...Mt.attributes, "fp-directive": ["dataName", "dataAttributes", "data-name", "data-attributes"], span: [...Mt.attributes?.span || [], "style", ["className", "math-inline", "language-math"]], mark: ["dataColor", "style"], td: [...Mt.attributes?.td || [], "rowSpan", "colSpan"], th: [...Mt.attributes?.th || [], "rowSpan", "colSpan"] } }, ba = /^(?:#[\da-f]{3,8}|[a-z]{1,24}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\))$/i;
function Ys() {
  return (t) => {
    an(t, "element", (n) => {
      if (n.tagName !== "span" && n.tagName !== "mark") return;
      const r = n.properties, i = String(r.style || "").split(";").map((s) => s.split(":")).filter(([s, c]) => /^(?:color|background-color|background)$/.test(s?.trim()) && ba.test(c?.trim())).map(([s, c]) => `${s.trim()}:${c.trim()}`), l = String(r.dataColor || "");
      n.tagName === "mark" && ba.test(l) && i.push(`background-color:${l}`), i.length ? r.style = i.join(";") : delete r.style;
    });
  };
}
function Xs() {
  return (t) => {
    const n = /* @__PURE__ */ new Map();
    an(t, "element", (r) => {
      if (!/^h[1-6]$/.test(r.tagName)) return;
      const a = (s) => s.children.map((c) => c.type === "text" ? c.value : c.type === "element" ? a(c) : "").join(""), i = a(r).toLowerCase().trim().replace(/[^\p{L}\p{N}\s_-]/gu, "").replace(/\s+/g, "-") || "section", l = (n.get(i) || 0) + 1;
      n.set(i, l), r.properties.id = l === 1 ? i : `${i}-${l}`;
    });
  };
}
const $i = {
  "\\placeholder": "\\mathord{\\square}\\phantom{#1}",
  "\\displaylines": "\\begin{gathered}#1\\end{gathered}"
};
function J(t, n) {
  const r = zl(async () => {
    const a = await t();
    return typeof a == "function" ? { default: a } : a;
  });
  return () => /* @__PURE__ */ e(Al, { fallback: /* @__PURE__ */ e("p", { role: "status", children: "正在打开实验…" }), children: /* @__PURE__ */ e(r, {}) });
}
const _r = [
  {
    id: "probability-disk-conditional-lab",
    subjectId: "probability",
    chapterId: "ch03",
    sectionId: "conditional-density",
    title: "圆盘条件密度切片",
    description: "拖动横坐标，比较弦长与归一后的条件密度。",
    Component: J(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.DiskConditionalLab)
    )
  },
  {
    id: "probability-occupancy-lab",
    subjectId: "probability",
    chapterId: "ch01",
    sectionId: "finite-occupancy",
    title: "每个窗口非空的分配",
    description: "调整人数和窗口数，观察条件计数与指定窗口人数分布。",
    Component: J(
      () => import("./ReviewLabs-B25nuJFs.js").then((t) => t.OccupancyLab)
    )
  },
  {
    id: "physics-electrostatics-lab",
    subjectId: "physics",
    chapterId: "learning",
    sectionId: "physics-electrostatics-lab",
    title: "静电场与叠加",
    Component: J(() => import("./ElectrostaticsLab-M7oVnK6H.js"))
  },
  {
    id: "discrete-set-counting",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-set-counting",
    title: "集合运算与计数",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.SetCountingLab)
    )
  },
  {
    id: "discrete-order-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-order-lab",
    title: "整除偏序与上下界",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.OrderLab)
    )
  },
  {
    id: "discrete-graph-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-graph-lab",
    title: "图的度数与二染色",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then(
        (t) => t.GraphStructureLab
      )
    )
  },
  {
    id: "discrete-matching-lab",
    subjectId: "discrete-math",
    chapterId: "learning",
    sectionId: "discrete-matching-lab",
    title: "图的最大匹配",
    Component: J(
      () => import("./StructureLabs-DM9gD4l8.js").then((t) => t.MatchingLab)
    )
  },
  {
    id: "numerical-lu-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-lu-lab",
    title: "保存消元乘子的LU分解",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then((t) => t.LULab)
    )
  },
  {
    id: "numerical-cholesky-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-cholesky-lab",
    title: "平方根分解与正定条件",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.CholeskyLab
      )
    )
  },
  {
    id: "numerical-thomas-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-thomas-lab",
    title: "追赶法的递推与回代",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ThomasLab
      )
    )
  },
  {
    id: "numerical-condition-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-condition-lab",
    title: "条件数与扰动放大",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.ConditionLab
      )
    )
  },
  {
    id: "numerical-divided-difference-lab",
    subjectId: "numerical-methods",
    chapterId: "learning",
    sectionId: "numerical-divided-difference-lab",
    title: "差商与插值曲线",
    Component: J(
      () => import("./FactorizationLabs-CV0_wH89.js").then(
        (t) => t.DividedDifferenceLab
      )
    )
  },
  {
    id: "discrete-prop-truth-table",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "propositional-logic",
    title: "真值表实验台",
    description: "切换公式与赋值，观察蕴含、双条件和德摩根律。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.TruthTableLab
      )
    )
  },
  {
    id: "discrete-predicate-quantifier",
    subjectId: "discrete-math",
    chapterId: "logic",
    sectionId: "predicate-logic",
    title: "量词作用域实验台",
    description: "调整有限论域和谓词条件，对比全称量词与存在量词。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.QuantifierScopeLab
      )
    )
  },
  {
    id: "discrete-relation-properties",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "binary-relations",
    title: "关系性质实验台",
    description: "编辑三阶关系矩阵，实时判断自反、对称、反对称和传递性。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.RelationPropertyLab
      )
    )
  },
  {
    id: "discrete-function-mapping",
    subjectId: "discrete-math",
    chapterId: "sets-relations",
    sectionId: "orders-functions",
    title: "函数映射实验台",
    description: "改变有限函数的映射，实时判断单射、满射与双射。",
    Component: J(
      () => import("./LogicRelationsLabs-CAFcjaGz.js").then(
        (t) => t.FunctionMappingLab
      )
    )
  },
  {
    id: "numerical-linear-lab",
    subjectId: "numerical-methods",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "两种线性迭代的计算过程",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.LinearLab)
    )
  },
  {
    id: "numerical-interpolation-lab",
    subjectId: "numerical-methods",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "等距高次插值的变化",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.InterpolationLab
      )
    )
  },
  {
    id: "numerical-fitting-lab",
    subjectId: "numerical-methods",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "观测点与最小二乘拟合",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.FittingLab)
    )
  },
  {
    id: "numerical-quadrature-lab",
    subjectId: "numerical-methods",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "加密网格与积分精度",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then(
        (t) => t.QuadratureLab
      )
    )
  },
  {
    id: "numerical-ode-lab",
    subjectId: "numerical-methods",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "常微分方程的逐步求解",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.OdeLab)
    )
  },
  {
    id: "numerical-power-lab",
    subjectId: "numerical-methods",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "幂法收敛过程",
    Component: J(
      () => import("./ExtensionLabs-ChlSIvev.js").then((t) => t.PowerLab)
    )
  },
  {
    id: "numerical-source-rec-01",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01",
    title: "第一课 · 原始录音",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.RecordingOne)
    )
  },
  {
    id: "numerical-source-rec-02",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02",
    title: "第二课 · 原始录音",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.RecordingTwo)
    )
  },
  {
    id: "numerical-source-slides-03-04",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-03-04",
    title: "课件 · 第三、四章",
    Component: J(
      () => Promise.resolve().then(() => Ge).then(
        (t) => t.SlidesThreeFour
      )
    )
  },
  {
    id: "numerical-source-slides-05-06",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-05-06",
    title: "课件 · 第五、六章",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.SlidesFiveSix)
    )
  },
  {
    id: "numerical-source-slides-07-08",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides-07-08",
    title: "课件 · 第七、八章",
    Component: J(
      () => Promise.resolve().then(() => Ge).then(
        (t) => t.SlidesSevenEight
      )
    )
  },
  {
    id: "numerical-source-slides",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "slides",
    title: "课件 · 第一、二章",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.Slides)
    )
  },
  {
    id: "numerical-source-textbook-6",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-6",
    title: "教材 · 第六版完整 PDF",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.Textbook)
    )
  },
  {
    id: "numerical-source-textbook-reference",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "textbook-reference",
    title: "补充教材 · 完整 PDF",
    Component: J(
      () => Promise.resolve().then(() => Ge).then(
        (t) => t.ReferenceTextbook
      )
    )
  },
  {
    id: "numerical-source-rec-01-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-01-transcript",
    title: "第一课 · 原始转录稿",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.TranscriptOne)
    )
  },
  {
    id: "numerical-source-rec-02-transcript",
    subjectId: "numerical-methods",
    chapterId: "sources",
    sectionId: "rec-02-transcript",
    title: "第二课 · 原始转录稿",
    Component: J(
      () => Promise.resolve().then(() => Ge).then((t) => t.TranscriptTwo)
    )
  },
  {
    id: "numerical-error-lab",
    subjectId: "numerical-methods",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "面积误差实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.ErrorLab)
    )
  },
  {
    id: "numerical-bisection-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二分法实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.BisectionLab)
    )
  },
  {
    id: "numerical-iteration-lab",
    subjectId: "numerical-methods",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "不动点迭代实验",
    Component: J(
      () => import("./Labs-Co6UmxG2.js").then((t) => t.IterationLab)
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.1-events",
    chapterId: "ch01",
    sectionId: "1.1",
    title: "样本空间构造器",
    description: "点击骰子结果归入事件 A / B，实时显示集合表示与并交差补，直观体会「事件=子集」。",
    Component: J(() => import("./SampleSpaceBuilder-DKDCubKb.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.2-venn",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "事件运算 · 维恩图实验台",
    description: "选择并、交、差、补、对称差与德摩根律，实时高亮对应区域。",
    Component: J(() => import("./VennPlayground-yDIe19eQ.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.3-frequency",
    chapterId: "ch01",
    sectionId: "1.3",
    title: "频率趋于概率 · 抛硬币模拟",
    description: "批量抛硬币，观察正面频率随试验次数增大向 0.5 收敛。",
    Component: J(
      () => import("./FrequencyConvergence-D_R7GMec.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch01-1.4-coins",
    chapterId: "ch01",
    sectionId: "1.4",
    title: "古典概型实验室",
    description: "切换掷两骰子之和 / 摸球场景，蒙特卡洛模拟对比理论概率与频率收敛。",
    Component: J(() => import("./ClassicalProbLab-CsFOyWKB.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.5-bayes-lab",
    chapterId: "ch01",
    sectionId: "1.5",
    title: "贝叶斯推断可视化",
    description: "调患病率 / 灵敏度 / 特异度，用方块图直观显示后验 P(病|阳性) 与基率谬误。",
    Component: J(() => import("./BayesExplorer-BRx_irdu.js"))
  },
  {
    subjectId: "probability",
    id: "ch01-1.6-reliability",
    chapterId: "ch01",
    sectionId: "1.6",
    title: "串/并联系统可靠度探索器",
    description: "拖动各元件可靠度，实时计算系统可靠度并高亮工作/失效路径。",
    Component: J(() => import("./ReliabilityExplorer-BZLcH3fY.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.1-rv-mapper",
    chapterId: "ch02",
    sectionId: "2.1",
    title: "随机变量映射器",
    description: "点击样本点为其指定一个实数值，构造自定义随机变量 X，实时展示 X 的分布律。",
    Component: J(() => import("./RVMapper-65hp8cRq.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.2-binomial-explorer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "二项/泊松分布探索器",
    description: "滑块调 n、p（或 λ），实时绘制分布律柱状图，切换二项/泊松，直观体会参数变化对形状的影响。",
    Component: J(() => import("./BinomialExplorer-BUimg2bl.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.3-cdf-visualizer",
    chapterId: "ch02",
    sectionId: "2.3",
    title: "分布函数可视化",
    description: "切换离散/连续分布，拖动 x 轴上的竖线，左侧阴影面积实时显示 F(x)=P(X≤x) 的数值。",
    Component: J(() => import("./CDFVisualizer-1I8Pictu.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.4-pdf-explorer",
    chapterId: "ch02",
    sectionId: "2.4",
    title: "连续分布密度函数探索器",
    description: "切换均匀/指数/正态分布，调参数，拖动区间端点，实时计算 P(a≤X≤b)（面积）。",
    Component: J(() => import("./PDFExplorer-82a47XZM.js"))
  },
  {
    subjectId: "probability",
    id: "ch02-2.5-func-dist-demo",
    chapterId: "ch02",
    sectionId: "2.5",
    title: "随机变量函数分布演示",
    description: "选 X 的分布，选变换 Y=g(X)，并排展示 X 和 Y 的 PDF/PMF，直观看到「折叠/拉伸」效果。",
    Component: J(() => import("./FuncDistDemo-CVrNS8dD.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.1-joint-dist-explorer",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "联合分布律探索器",
    description: "3×3 表格可编辑 p(xi,yj)，自动归一化，热力图实时展示联合分布，底部/右侧显示边缘分布。",
    Component: J(() => import("./JointDistExplorer-DhO5cBsX.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.2-marginal-explorer",
    chapterId: "ch03",
    sectionId: "3.2",
    title: "边缘分布提取演示",
    description: "从联合分布热力图中，点击某行/列即「投影」出该边缘分布，直观体会「对另一变量求和」的含义。",
    Component: J(() => import("./MarginalExplorer-CV5J9xv-.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.3-conditional-explorer",
    chapterId: "ch03",
    sectionId: "3.3",
    title: "条件分布可视化",
    description: "点击选定 Y=yj 的行，右侧自动计算并展示归一化后的 P(X|Y=yj)，与边缘 P(X) 并排对比。",
    Component: J(() => import("./ConditionalExplorer-14dDs9eY.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.4-independence-checker",
    chapterId: "ch03",
    sectionId: "3.4",
    title: "独立性检验器",
    description: "编辑联合分布表，实时检验 p(xi,yj)=pi·qj 是否成立，用颜色高亮违反独立性的格子。",
    Component: J(() => import("./IndependenceChecker-BDQA5czh.js"))
  },
  {
    subjectId: "probability",
    id: "ch03-3.5-convolution-demo",
    chapterId: "ch03",
    sectionId: "3.5",
    title: "卷积：两独立随机变量之和",
    description: "选 X 和 Y 各自的分布类型和参数，用蒙特卡洛模拟 Z=X+Y，展示 Z 的经验分布与理论 PDF。",
    Component: J(() => import("./ConvolutionDemo-BfkHEOoN.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.1-expectation-explorer",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "期望：加权重心探索器",
    description: "可拖动数轴上的概率质量块，实时看到期望「重心」移动，直观体会期望=加权平均。",
    Component: J(() => import("./ExpectationExplorer-C-WMDKGL.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.2-variance-explorer",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "方差与分布扩散度可视化",
    description: "并排两个正态分布，独立调 μ 和 σ，实时看到曲线形状变化，量化均值/方差/标准差。",
    Component: J(() => import("./VarianceExplorer-Bv_PRTxx.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.3-correlation-explorer",
    chapterId: "ch04",
    sectionId: "4.3",
    title: "相关系数可视化实验室",
    description: "拖动 ρ 滑块实时生成对应散点云，展示相关系数的几何意义；额外演示不相关但不独立的案例。",
    Component: J(() => import("./CorrelationExplorer-Ch9T7o1B.js"))
  },
  {
    subjectId: "probability",
    id: "ch04-4.4-cov-matrix-demo",
    chapterId: "ch04",
    sectionId: "4.4",
    title: "协方差矩阵与等高线椭圆",
    description: "调整 2×2 协方差矩阵的四个元素，实时看到二维正态分布等高线椭圆的形状和方向变化。",
    Component: J(() => import("./CovMatrixDemo-B-1WZEsk.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.1-chebyshev-demo",
    chapterId: "ch05",
    sectionId: "5.1",
    title: "切比雪夫不等式演示",
    description: "调 ε 和 σ，实时看到概率尾部与切比雪夫上界的数值对比，直观体会不等式的松紧程度。",
    Component: J(() => import("./ChebyshevDemo-CZm0Kt2n.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.2-lln-simulator",
    chapterId: "ch05",
    sectionId: "5.2",
    title: "大数定律模拟器",
    description: "选分布、调 ε，批量模拟样本均值折线，可视化展示「n 越大，超出 ε 带的折线比例越小」。",
    Component: J(() => import("./LLNSimulator-pLGn9nLM.js"))
  },
  {
    subjectId: "probability",
    id: "ch05-5.3-clt-simulator",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "中心极限定理模拟实验室",
    description: "任选底层分布（均匀/指数/泊松/二项），拖动 n，实时看样本均值的标准化直方图收敛到 N(0,1)。",
    Component: J(() => import("./CLTSimulator-BZqx08Ja.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.1-statistic-calculator",
    chapterId: "ch06",
    sectionId: "6.1",
    title: "统计量计算器",
    description: "输入或随机生成一组样本数据，实时计算 X̄、S²（n-1）、S、顺序统计量，并展示每步计算过程。",
    Component: J(() => import("./StatisticCalculator-qUSdZTwp.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.2-sampling-dist-explorer",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "三大抽样分布探索器",
    description: "切换 χ²/t/F 分布，调自由度参数，实时展示 PDF 曲线与临界值（α=0.05/0.01）。",
    Component: J(
      () => import("./SamplingDistExplorer-UxlLcTBn.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch06-6.3-normal-sampling-demo",
    chapterId: "ch06",
    sectionId: "6.3",
    title: "正态总体抽样分布仿真",
    description: "设定正态总体参数和样本量 n，大量重复抽样，实证验证四大定理（X̄、S²、t统计量的分布）。",
    Component: J(() => import("./NormalSamplingDemo-CwxsNJo3.js"))
  },
  {
    subjectId: "probability",
    id: "ch06-6.4-quantile-explorer",
    chapterId: "ch06",
    sectionId: "6.4",
    title: "样本分位数与 Q-Q 图",
    description: "生成样本，展示各顺序统计量，绘制 Q-Q 图（与正态理论分位数对比），判断是否来自正态总体。",
    Component: J(() => import("./QuantileExplorer-DGChs3kW.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.1-moment-estimator",
    chapterId: "ch07",
    sectionId: "7.1",
    title: "矩估计量计算器",
    description: "选分布（指数/正态/均匀），输入样本，自动推导矩估计量公式并代入样本矩给出数值估计。",
    Component: J(() => import("./MomentEstimator-KE5isNUD.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.2-mle-explorer",
    chapterId: "ch07",
    sectionId: "7.2",
    title: "极大似然估计可视化",
    description: "输入样本数据，展示对数似然函数曲线，标注 MLE 峰值，并允许用户拖动参数感受似然如何随 θ 变化。",
    Component: J(() => import("./MLEExplorer-Dq7T8fU7.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.3-estimator-comparator",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "估计量性质比较器",
    description: "大量重复抽样，可视化比较 X̄（均值估计）、S²（无偏方差）和 Sn²（有偏方差）的分布，验证无偏性和相合性。",
    Component: J(() => import("./EstimatorComparator-Dk3lkNZs.js"))
  },
  {
    subjectId: "probability",
    id: "ch07-7.4-conf-interval-explorer",
    chapterId: "ch07",
    sectionId: "7.4",
    title: "置信区间捕获率可视化",
    description: "设定置信水平、样本量，批量模拟抽样，可视化每次的置信区间，统计实际覆盖率是否接近声称的 1-α。",
    Component: J(
      () => import("./ConfidenceIntervalExplorer-BxRdZEkH.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.1-hyp-test-demo",
    chapterId: "ch08",
    sectionId: "8.1",
    title: "假设检验直觉演示",
    description: "调显著性水平 α 和观测到的检验统计量 z，实时看到拒绝域变化和决策结果（拒绝/不拒绝 H0）。",
    Component: J(() => import("./HypTestDemo-rrTfTpPc.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.2-mean-test-explorer",
    chapterId: "ch08",
    sectionId: "8.2",
    title: "均值假设检验计算器",
    description: "输入样本统计量，选 Z/t 检验和检验方向，自动计算检验统计量和 p 值，判断在给定 α 下是否拒绝 H0。",
    Component: J(() => import("./MeanTestExplorer-CusKecP0.js"))
  },
  {
    subjectId: "probability",
    id: "ch08-8.3-variance-test-explorer",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "方差假设检验计算器",
    description: "输入样本方差 S²、样本量 n、假设方差 σ₀²，计算 χ² 统计量，在分布图上标注位置，给出检验结论。",
    Component: J(
      () => import("./VarianceTestExplorer-DMdp9C2G.js")
    )
  },
  {
    subjectId: "probability",
    id: "ch08-8.4-error-type-demo",
    chapterId: "ch08",
    sectionId: "8.4",
    title: "两类错误权衡可视化",
    description: "调整显著性水平 α（或等价地移动拒绝域边界），实时看到 α（第一类）和 β（第二类）错误概率的此消彼长。",
    Component: J(() => import("./ErrorTypeDemo-Ci-t9P-0.js"))
  },
  // ─── 有机化学交互组件 ───────────────────────────────────────────────────────
  {
    subjectId: "chemistry",
    id: "ch01-1.2-bond-polarity",
    chapterId: "ch01",
    sectionId: "1.2",
    title: "电负性与键极性探索器",
    description: "选择两个成键原子，按电负性差 Δχ 判定非极性/极性共价键/离子键，并画出偶极箭头。",
    Component: J(() => import("./BondPolarityExplorer-CoRShQhQ.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch02-2.2-iupac-namer",
    chapterId: "ch02",
    sectionId: "2.2",
    title: "IUPAC 命名练习器",
    description: "选择支链烷烃结构，逐步演示选主链、编号、列取代基、组合系统名的命名过程。",
    Component: J(() => import("./IUPACNamingPractice-Ba2XNKYT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch03-3.1-boiling-point",
    chapterId: "ch03",
    sectionId: "3.1",
    title: "分子间作用力与沸点比较",
    description: "对烷烃同系列/同分异构体/氢键组排序沸点，验证分子间作用力对物理性质的影响。",
    Component: J(
      () => import("./BoilingPointComparator-sWZRZAmF.js")
    )
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.1-newman",
    chapterId: "ch04",
    sectionId: "4.1",
    title: "纽曼投影构象能量",
    description: "拖动二面角观察纽曼投影旋转与势能曲线，对比乙烷/丁烷的交叉式与重叠式。",
    Component: J(() => import("./NewmanProjection-C1EvLXJm.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch04-4.2-chair-flip",
    chapterId: "ch04",
    sectionId: "4.2",
    title: "环己烷椅式翻转",
    description: "演示椅式翻转时直立键 a 与平伏键 e 的互换，体会大取代基偏好赤道键。",
    Component: J(() => import("./ChairFlip-Md0U2D_M.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch05-5.3-carbocation",
    chapterId: "ch05",
    sectionId: "5.3",
    title: "碳正离子稳定性",
    description: "比较甲基/伯/仲/叔碳正离子的超共轭数目与稳定性排序，理解电荷分散。",
    Component: J(() => import("./CarbocationStability-qUHSlIsS.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch06-6.2-markovnikov",
    chapterId: "ch06",
    sectionId: "6.2",
    title: "马氏规则加成预测",
    description: "选不对称烯烃与 HX，对比两条路径碳正离子稳定性预测主产物；过氧化物切换反马氏。",
    Component: J(() => import("./MarkovnikovPredictor-DwurHVMV.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch07-7.3-diene",
    chapterId: "ch07",
    sectionId: "7.3",
    title: "共轭二烯 1,2 vs 1,4 加成",
    description: "用温度滑块切换动力学（1,2，低温）与热力学（1,4，高温）产物比例。",
    Component: J(() => import("./DieneAddition-BoBJrygY.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch08-8.3-directing",
    chapterId: "ch08",
    sectionId: "8.3",
    title: "芳环定位效应预测",
    description: "选苯环上已有取代基，判定致活/致钝与邻对位/间位定向，高亮下一取代位置。",
    Component: J(() => import("./DirectingEffect-C6D3YGBy.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.1-chirality",
    chapterId: "ch09",
    sectionId: "9.1",
    title: "手性与镜像",
    description: "尝试旋转手性分子的镜像使其重叠，体会对映异构体不可重叠即手性。",
    Component: J(() => import("./ChiralityMirror-CEewePpu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch09-9.3-rs-config",
    chapterId: "ch09",
    sectionId: "9.3",
    title: "R/S 构型判定",
    description: "分步引导：顺序规则排优先级、最小基朝后、看大中小转向判定 R/S。",
    Component: J(() => import("./RSConfigPractice-BBihDfok.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.1-sn1-sn2",
    chapterId: "ch10",
    sectionId: "10.1",
    title: "SN1/SN2 机理对比",
    description: "选底物/亲核试剂/溶剂，判定倾向 SN1 还是 SN2，演示背面进攻翻转与碳正离子外消旋。",
    Component: J(() => import("./SN1SN2Compare-De50UNKU.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch10-10.2-elimination",
    chapterId: "ch10",
    sectionId: "10.2",
    title: "E1/E2 与扎伊采夫规则",
    description: "选卤代烷展示不同 β-氢消除得到的烯烃，按扎伊采夫规则标出主产物。",
    Component: J(() => import("./EliminationZaitsev-BuPuwKj3.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch11-11.3-epoxide",
    chapterId: "ch11",
    sectionId: "11.3",
    title: "环氧乙烷开环区域选择",
    description: "切换酸/碱催化，对比亲核试剂进攻位阻大碳（酸）或位阻小碳（碱）。",
    Component: J(() => import("./EpoxideOpening-MXwtj4vu.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch12-12.1-carbonyl",
    chapterId: "ch12",
    sectionId: "12.1",
    title: "羰基亲核加成",
    description: "选不同亲核试剂进攻羰基碳，演示电子流向与对应产物（α-羟基腈/醇/缩醛/亚胺等）。",
    Component: J(() => import("./CarbonylAddition-DVZgPquT.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch13-13.2-acyl-reactivity",
    chapterId: "ch13",
    sectionId: "13.2",
    title: "羧酸衍生物活性序列",
    description: "酰氯>酸酐>酯>酰胺活性排序，点击查看离去能力与电子效应的原因。",
    Component: J(() => import("./AcylReactivity-wN8j1BXK.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.1-diazonium",
    chapterId: "ch14",
    sectionId: "14.1",
    title: "重氮盐转化网络",
    description: "点击不同试剂展示重氮盐的桑德迈尔/席曼/还原/水解/偶联等转化产物。",
    Component: J(() => import("./DiazoniumNetwork-Cd5Wc6HL.js"))
  },
  {
    subjectId: "chemistry",
    id: "ch14-14.2-amine-basicity",
    chapterId: "ch14",
    sectionId: "14.2",
    title: "胺碱性比较",
    description: "对脂肪胺/氨/芳胺/吡啶/吡咯排序碱性，解释电子效应与芳香共轭的影响。",
    Component: J(() => import("./AmineBasicity-C1sxuYtu.js"))
  }
];
(() => {
  const t = /* @__PURE__ */ new Set();
  for (const n of _r) {
    if (t.has(n.id))
      throw new Error(
        `[registry] 重复的交互 id: "${n.id}"（交互 id 必须全局唯一）`
      );
    t.add(n.id);
  }
})();
function Gs(t) {
  if (t)
    return _r.find((n) => n.id === t);
}
const Wr = cn(null);
function tt({
  id: t,
  kind: n = "document"
}) {
  const r = Bt(Wr);
  return /* @__PURE__ */ e("section", { className: "fp-learning-source", children: r ? r(t, n) : /* @__PURE__ */ e("p", { children: "请从课程资料中打开此内容。" }) });
}
const Js = () => /* @__PURE__ */ e(tt, { id: "rec-01", kind: "audio" }), Qs = () => /* @__PURE__ */ e(tt, { id: "rec-02", kind: "audio" }), Zs = () => /* @__PURE__ */ e(tt, { id: "slides" }), ec = () => /* @__PURE__ */ e(tt, { id: "textbook-6" }), tc = () => /* @__PURE__ */ e(tt, { id: "textbook-reference" }), nc = () => /* @__PURE__ */ e(tt, { id: "rec-01", kind: "transcript" }), rc = () => /* @__PURE__ */ e(tt, { id: "rec-02", kind: "transcript" }), ac = () => /* @__PURE__ */ e(tt, { id: "slides-03-04" }), ic = () => /* @__PURE__ */ e(tt, { id: "slides-05-06" }), lc = () => /* @__PURE__ */ e(tt, { id: "slides-07-08" }), Ge = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LearningSourceContext: Wr,
  RecordingOne: Js,
  RecordingTwo: Qs,
  ReferenceTextbook: tc,
  Slides: Zs,
  SlidesFiveSix: ic,
  SlidesSevenEight: lc,
  SlidesThreeFour: ac,
  Textbook: ec,
  TranscriptOne: nc,
  TranscriptTwo: rc
}, Symbol.toStringTag, { value: "Module" }));
class oc extends Il {
  state = { failed: !1, attempt: 0 };
  static getDerivedStateFromError() {
    return { failed: !0 };
  }
  componentDidCatch(n, r) {
    this.props.onError?.(n, r);
  }
  componentDidUpdate(n) {
    n.resetKey !== this.props.resetKey && this.state.failed && this.retry();
  }
  retry = () => this.setState(({ attempt: n }) => ({ failed: !1, attempt: n + 1 }));
  render() {
    return this.state.failed ? /* @__PURE__ */ o("section", { className: "fp-surface-recovery", role: "alert", children: [
      /* @__PURE__ */ e(Je, { size: 24, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: this.props.title || "内容暂时无法显示" }),
      /* @__PURE__ */ e("p", { children: this.props.description || "请重新打开，继续查看内容。" }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary", onClick: this.retry, children: [
        /* @__PURE__ */ e(Je, { size: 15, "aria-hidden": "true" }),
        "重新打开"
      ] })
    ] }) : /* @__PURE__ */ e("div", { className: "fp-surface-boundary", children: this.props.children }, this.state.attempt);
  }
}
function ee({
  title: t,
  description: n,
  actions: r,
  children: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-section", children: [
    (t || n || r) && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        t && /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r && /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: r })
    ] }),
    a
  ] });
}
function sc({
  label: t,
  value: n,
  onChange: r,
  disabled: a,
  required: i
}) {
  const [l, s] = k(String(n)), c = B(!1), u = B(l);
  return u.current = l, Y(() => {
    (!c.current || !(typeof n == "number" && Object.is(Number(u.current), n)) && u.current !== String(n)) && s(String(n));
  }, [n]), /* @__PURE__ */ e(
    "input",
    {
      "aria-label": t,
      className: "fp-input",
      type: "text",
      inputMode: "decimal",
      value: l,
      onFocus: () => {
        c.current = !0;
      },
      onBlur: () => {
        c.current = !1, (typeof n == "string" || Number.isFinite(n)) && s(String(n));
      },
      onChange: (d) => {
        const p = d.target.value;
        u.current = p, s(p), r(p);
      },
      disabled: a,
      required: i
    }
  );
}
function X({
  label: t,
  value: n,
  onChange: r,
  hint: a,
  options: i,
  multiline: l,
  secret: s,
  numeric: c,
  disabled: u,
  required: d
}) {
  return /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    i ? /* @__PURE__ */ e(
      ke,
      {
        label: t,
        value: String(n),
        options: i,
        onChange: r,
        disabled: u
      }
    ) : l ? /* @__PURE__ */ e(
      "textarea",
      {
        "aria-label": t,
        className: "fp-input",
        value: n,
        onChange: (p) => r(p.target.value),
        rows: 5,
        disabled: u,
        required: d
      }
    ) : c ? /* @__PURE__ */ e(
      sc,
      {
        label: t,
        value: n,
        onChange: r,
        disabled: u,
        required: d
      }
    ) : /* @__PURE__ */ e(
      "input",
      {
        "aria-label": t,
        className: "fp-input",
        type: s ? "password" : "text",
        value: n,
        onChange: (p) => r(p.target.value),
        disabled: u,
        required: d,
        autoComplete: s ? "new-password" : void 0
      }
    ),
    a && /* @__PURE__ */ e("small", { children: a })
  ] });
}
function Ae({
  label: t,
  checked: n,
  onChange: r,
  description: a,
  disabled: i
}) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-toggle", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      a && /* @__PURE__ */ e("p", { children: a })
    ] }),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        role: "switch",
        "aria-label": t,
        "aria-checked": n,
        disabled: i,
        className: "fp-switch-label",
        onClick: () => r(!n),
        children: /* @__PURE__ */ e("span", { "aria-hidden": "true", className: `fp-switch${n ? " is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) })
      }
    )
  ] });
}
function Ve({
  label: t,
  value: n,
  onChange: r,
  items: a,
  density: i = "comfortable"
}) {
  const l = ve(), s = _n();
  return /* @__PURE__ */ e("div", { className: "fp-settings-tabs", "data-density": i, role: "tablist", "aria-label": t, children: a.map((c) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      role: "tab",
      "aria-selected": n === c.id,
      tabIndex: n === c.id ? 0 : -1,
      onClick: () => r(c.id),
      onKeyDown: (u) => {
        const d = a.findIndex((h) => h.id === c.id), p = u.key === "ArrowRight" ? (d + 1) % a.length : u.key === "ArrowLeft" ? (d - 1 + a.length) % a.length : u.key === "Home" ? 0 : u.key === "End" ? a.length - 1 : -1;
        p >= 0 && (u.preventDefault(), r(a[p].id), u.currentTarget.parentElement?.children[p]?.focus());
      },
      children: [
        n === c.id && /* @__PURE__ */ e(
          Wn.span,
          {
            className: "fp-settings-tab-indicator",
            layoutId: `settings-tab-${l}`,
            transition: {
              duration: s ? 0 : 0.18,
              ease: [0.2, 0.8, 0.2, 1]
            }
          }
        ),
        /* @__PURE__ */ e("span", { children: c.label })
      ]
    },
    c.id
  )) });
}
function Le() {
  const [t, n] = k(!1), [r, a] = k(""), [i, l] = k(""), s = B(!1), c = B(!0);
  return Y(() => (c.current = !0, () => {
    c.current = !1;
  }), []), { busy: t, error: r, message: i, run: async (d, p = "") => {
    if (s.current) return !1;
    s.current = !0, n(!0), a(""), l("");
    try {
      return await d(), c.current && p && l(p), !0;
    } catch (h) {
      return c.current && a(
        h instanceof Error ? h.message : "操作暂未完成，请重试。"
      ), !1;
    } finally {
      s.current = !1, c.current && n(!1);
    }
  }, setError: a, setMessage: l };
}
function Se({
  error: t,
  message: n
}) {
  return /* @__PURE__ */ e(
    fe,
    {
      className: `fp-feedback-size${t || n ? " fp-feedback-visible" : ""}`,
      children: /* @__PURE__ */ o("div", { className: "fp-workspace-feedback", children: [
        t && /* @__PURE__ */ e("p", { role: "alert", children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] })
    }
  );
}
function it({
  busy: t,
  dirty: n = !0,
  onClick: r,
  label: a = "保存更改"
}) {
  return /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-primary",
      disabled: t || !n,
      onClick: r,
      children: t ? "正在保存…" : a
    }
  );
}
function nt(t) {
  const [n, r] = k(t), [a, i] = k(() => JSON.stringify(t)), l = JSON.stringify(t), s = JSON.stringify(n) !== a, c = B(l);
  return Y(() => {
    l !== c.current && (c.current = l, s || (r(t), i(l)));
  }, [l, a, s]), { draft: n, setDraft: r, dirty: s, accept: (d) => {
    r(d), i(JSON.stringify(d));
  } };
}
function zi({
  id: t,
  renderSource: n,
  sources: r
}) {
  const a = Gs(t);
  if (!a) return /* @__PURE__ */ e("p", { children: "暂时无法打开此实验，请重新选择。" });
  const i = a.Component;
  return /* @__PURE__ */ e(
    Wr.Provider,
    {
      value: n || (r ? (l, s) => r[`${l}:${s}`] || r[l] ? /* @__PURE__ */ e(
        ku,
        {
          source: r[`${l}:${s}`] || r[l]
        },
        `${l}:${s}`
      ) : /* @__PURE__ */ e("p", { children: "此资料暂不可用。" }) : null),
      children: /* @__PURE__ */ e(oc, { resetKey: t, children: /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { className: "fp-lab-content", "aria-label": a.title, children: /* @__PURE__ */ e(i, {}) }) }) })
    }
  );
}
function Mh({
  value: t,
  onSelect: n,
  onSave: r,
  renderSource: a,
  sources: i
}) {
  const [l, s] = k(""), [c, u] = k("all"), [d, p] = k(""), h = Le(), f = t ?? d, m = {
    probability: "概率论",
    chemistry: "有机化学",
    physics: "大学物理",
    "discrete-math": "离散数学",
    "numerical-methods": "数值计算"
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "交互实验",
      description: "改变条件，观察结果，检验自己的理解。",
      children: [
        /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
          /* @__PURE__ */ e(X, { label: "搜索实验", value: l, onChange: s }),
          /* @__PURE__ */ e(
            X,
            {
              label: "实验学科",
              value: c,
              onChange: u,
              options: [
                { value: "all", label: "全部学科" },
                ...Object.entries(m).map(([b, g]) => ({
                  value: b,
                  label: g
                }))
              ]
            }
          )
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ e(
            "nav",
            {
              className: "fp-workspace-item-list fp-experiment-list",
              "aria-label": "交互实验列表",
              children: _r.filter(
                (b) => (c === "all" || c === b.subjectId) && `${b.title} ${b.description || ""}`.includes(l)
              ).map((b) => /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-pressed": f === b.id,
                  onClick: () => {
                    p(b.id), n?.(b.id);
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: b.title }),
                    /* @__PURE__ */ e("small", { children: m[b.subjectId] || b.subjectId })
                  ]
                },
                b.id
              ))
            }
          ),
          /* @__PURE__ */ e("div", { children: f ? /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e(
              zi,
              {
                id: f,
                renderSource: a,
                sources: i
              }
            ),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                disabled: h.busy,
                className: "fp-button fp-secondary",
                onClick: () => {
                  h.run(() => r(f), "实验已保存到笔记。");
                },
                children: "保存到笔记"
              }
            )
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个实验开始探索。" }) })
        ] }),
        /* @__PURE__ */ e(Se, { ...h })
      ]
    }
  ) });
}
const cc = [
  "svg",
  "g",
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "textPath",
  "defs",
  "marker",
  "use",
  "symbol",
  "clipPath",
  "mask",
  "pattern",
  "linearGradient",
  "radialGradient",
  "stop",
  "title",
  "desc",
  "image"
], dc = [
  "viewBox",
  "xmlns",
  "width",
  "height",
  "x",
  "y",
  "cx",
  "cy",
  "r",
  "rx",
  "ry",
  "x1",
  "y1",
  "x2",
  "y2",
  "d",
  "points",
  "fill",
  "stroke",
  "stroke-width",
  "stroke-dasharray",
  "stroke-linecap",
  "stroke-linejoin",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "transform",
  "font-size",
  "font-family",
  "font-weight",
  "text-anchor",
  "dominant-baseline",
  "dx",
  "dy",
  "markerWidth",
  "markerHeight",
  "refX",
  "refY",
  "orient",
  "id",
  "class",
  "clip-path",
  "mask",
  "filter",
  "gradientUnits",
  "offset",
  "stop-color",
  "stop-opacity",
  "patternUnits",
  "preserveAspectRatio",
  "role",
  "aria-label",
  "startOffset",
  "textLength",
  "lengthAdjust",
  "marker-end",
  "marker-start",
  "marker-mid",
  "fill-rule",
  "clip-rule",
  "letter-spacing",
  "word-spacing",
  "writing-mode",
  "alignment-baseline",
  "baseline-shift"
];
function uc(t, n = !0) {
  if (typeof window > "u") return t;
  let r;
  try {
    r = Vo.sanitize(t, {
      USE_PROFILES: { svg: !0, svgFilters: !0 },
      ADD_TAGS: cc,
      ADD_ATTR: dc,
      FORBID_TAGS: ["script", "foreignObject", "iframe", "object", "embed"],
      FORBID_ATTR: ["onclick", "onload", "onerror", "onmouseover", "onmouseout", "onfocus", "onblur"]
    });
  } catch {
    return "";
  }
  return n && (r = r.replace(/(fill|stroke)="(?:black|#000(?:000)?|rgb\(0,\s*0,\s*0\))"/g, '$1="currentColor"').replace(/fill="(?:white|#fff(?:fff)?|rgb\(255,\s*255,\s*255\))"/g, 'fill="var(--diagram-surface)"')), r;
}
const pc = /* @__PURE__ */ new Set([
  "circle",
  "ellipse",
  "rect",
  "line",
  "polyline",
  "polygon",
  "path",
  "text",
  "tspan",
  "use",
  "image"
]);
function hc(t) {
  const n = t.getAttribute("viewBox") ?? t.getAttribute("viewbox");
  if (!n) return null;
  const r = n.trim().split(/[\s,]+/).map(Number).filter(Number.isFinite);
  return r.length !== 4 || r[2] <= 0 || r[3] <= 0 ? null : { minX: r[0], minY: r[1], width: r[2], height: r[3] };
}
function ot(t, n) {
  const r = t.getAttribute(n);
  if (!r) return null;
  const a = Number.parseFloat(r);
  return Number.isFinite(a) ? a : null;
}
function fc(t, n) {
  const r = n.minX + n.width, a = n.minY + n.height, i = t.tagName.toLowerCase(), l = [];
  if (i === "circle" || i === "ellipse") {
    const s = ot(t, "cx"), c = ot(t, "cy");
    s !== null && c !== null && l.push({ x: s, y: c });
  } else if (i === "rect" || i === "image" || i === "text" || i === "use") {
    const s = ot(t, "x") ?? 0, c = ot(t, "y") ?? 0;
    l.push({ x: s, y: c });
  } else if (i === "line") {
    const s = ot(t, "x1"), c = ot(t, "y1"), u = ot(t, "x2"), d = ot(t, "y2");
    s !== null && c !== null && l.push({ x: s, y: c }), u !== null && d !== null && l.push({ x: u, y: d });
  } else
    return !0;
  return l.length === 0 ? !0 : l.some(
    (s) => s.x >= n.minX && s.x <= r && s.y >= n.minY && s.y <= a
  );
}
function mc(t) {
  const n = t.trim();
  if (!n) return { ok: !1, reason: "empty", visibleElementCount: 0 };
  if (typeof DOMParser > "u") {
    const s = (n.match(/<(?:circle|ellipse|rect|line|polyline|polygon|path|text|tspan|use|image)\b/gi) ?? []).length;
    return s > 0 ? { ok: !0, reason: "ok", visibleElementCount: s } : { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  }
  const a = new DOMParser().parseFromString(n, "image/svg+xml").querySelector("svg");
  if (!a) return { ok: !1, reason: "no-svg-root", visibleElementCount: 0 };
  const i = Array.from(a.querySelectorAll("*")).filter((s) => pc.has(s.tagName.toLowerCase()));
  if (i.length === 0) return { ok: !1, reason: "no-visible-elements", visibleElementCount: 0 };
  const l = hc(a);
  return l && !i.some((s) => fc(s, l)) ? { ok: !1, reason: "out-of-viewbox", visibleElementCount: i.length } : { ok: !0, reason: "ok", visibleElementCount: i.length };
}
function Vr() {
  const [t, n] = k(!1), r = xe(() => n((i) => !i), []), a = xe(() => n(!1), []);
  return Y(() => {
    if (!t) return;
    const i = document.activeElement, l = (s) => {
      s.key === "Escape" && (s.preventDefault(), s.stopPropagation(), a());
    };
    return document.addEventListener("keydown", l, !0), () => {
      document.removeEventListener("keydown", l, !0), i?.focus({ preventScroll: !0 });
    };
  }, [t, a]), { fullscreen: t, toggle: r, exit: a };
}
function Yr({
  onReset: t,
  onZoomIn: n,
  onZoomOut: r,
  onDownload: a,
  onOpenExternal: i,
  onMaximize: l,
  fullscreen: s = !1
}) {
  return /* @__PURE__ */ o("div", { className: "svg-canvas-controls", children: [
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: n,
        title: "放大",
        "aria-label": "放大",
        children: /* @__PURE__ */ e(Ar, { size: 11 })
      }
    ),
    r && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: r,
        title: "缩小",
        "aria-label": "缩小",
        children: /* @__PURE__ */ e(Ir, { size: 11 })
      }
    ),
    t && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: t,
        title: "重置视图",
        "aria-label": "重置视图",
        children: /* @__PURE__ */ e(Je, { size: 11 })
      }
    ),
    a && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: a,
        title: "下载 HTML",
        "aria-label": "下载 HTML",
        children: /* @__PURE__ */ e(jt, { size: 11 })
      }
    ),
    i && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: i,
        title: "新页面展开",
        "aria-label": "新页面展开",
        children: /* @__PURE__ */ e(Kt, { size: 11 })
      }
    ),
    l && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "press",
        onClick: l,
        title: s ? "退出全屏" : "放大查看",
        "aria-label": s ? "退出全屏" : "放大查看",
        children: s ? /* @__PURE__ */ e($r, { size: 11 }) : /* @__PURE__ */ e(zr, { size: 11 })
      }
    )
  ] });
}
function bc({
  diagnostic: t
}) {
  return !t || t.ok ? null : /* @__PURE__ */ o("div", { className: "fp-canvas-status", role: "status", children: [
    /* @__PURE__ */ e("strong", { children: "画布暂时无法显示" }),
    /* @__PURE__ */ e("p", { children: "请检查内容，或通过“修改画布”调整后再试。" })
  ] });
}
function gc({
  busy: t,
  error: n,
  onCancel: r,
  onSubmit: a
}) {
  const [i, l] = k(""), s = Le(), c = t || s.busy;
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-canvas-revision",
      onSubmit: (u) => {
        u.preventDefault(), !(!i.trim() || c || !a) && s.run(async () => {
          await a(i.trim()), l(""), r();
        });
      },
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "希望如何调整画布",
            value: i,
            multiline: !0,
            disabled: c,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(Se, { error: n || s.error }),
        /* @__PURE__ */ o("footer", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-secondary",
              type: "button",
              disabled: c,
              onClick: r,
              children: "取消"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              className: "fp-button fp-primary",
              type: "submit",
              disabled: c || !i.trim() || !a,
              children: c ? "正在调整…" : "生成修改"
            }
          )
        ] })
      ]
    }
  );
}
function un({
  title: t,
  source: n,
  diagnostic: r,
  controls: a,
  children: i,
  className: l,
  style: s,
  onPointerDown: c,
  onPointerMove: u,
  onPointerUp: d,
  onPointerCancel: p,
  onWheel: h,
  revisionBlock: f,
  revisionTopic: m,
  revisionBusy: b = !1,
  revisionError: g,
  onRevisionSubmit: y,
  onRevisionAccepted: w
}) {
  const [v, N] = k(!1), [x, C] = k(!1), I = !!n?.trim();
  return /* @__PURE__ */ o(
    "div",
    {
      className: `svg-canvas-wrapper canvas-frame ${l ?? ""}`,
      style: s,
      onPointerDown: c,
      onPointerMove: u,
      onPointerUp: d,
      onPointerCancel: p,
      onWheel: h,
      children: [
        /* @__PURE__ */ e("div", { className: "svg-canvas-controls svg-canvas-controls-left", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "press",
            disabled: !y,
            onClick: () => N((L) => !L),
            title: "修改画布",
            "aria-label": "修改画布",
            children: /* @__PURE__ */ e(Bn, { size: 11 })
          }
        ) }),
        a,
        t ? /* @__PURE__ */ e("div", { className: "canvas-frame-title", children: t }) : null,
        /* @__PURE__ */ e("div", { className: "canvas-frame-body", children: i }),
        /* @__PURE__ */ e(bc, { diagnostic: r }),
        /* @__PURE__ */ e(fe, { children: v ? /* @__PURE__ */ e(
          gc,
          {
            block: f,
            topic: m,
            busy: b,
            error: g,
            onCancel: () => N(!1),
            onSubmit: y,
            onRevisionAccepted: w
          }
        ) : null }),
        I ? /* @__PURE__ */ o("div", { className: "canvas-source-panel", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "viz-error-toggle press",
              onClick: () => C((L) => !L),
              children: x ? "收起内容" : "查看内容"
            }
          ),
          /* @__PURE__ */ e(fe, { children: x ? /* @__PURE__ */ e("pre", { className: "viz-error-source", children: n }) : null })
        ] }) : null
      ]
    }
  );
}
function Yn({
  open: t,
  onExit: n,
  children: r,
  label: a = "学习画布"
}) {
  const i = B(null), l = B(null), s = B(null), [c, u] = k(null);
  return Ce(() => {
    const d = document.createElement("div");
    return d.className = "fp-canvas-portal-content", u(d), () => d.remove();
  }, []), Ce(() => {
    c && (t ? l.current : i.current)?.append(c);
  }, [c, t]), Y(() => {
    if (!t) return;
    s.current = document.activeElement;
    const d = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const p = requestAnimationFrame(
      () => l.current?.querySelector('button:not(:disabled),[tabindex="0"]')?.focus({ preventScroll: !0 })
    );
    return () => {
      cancelAnimationFrame(p), document.body.style.overflow = d, s.current?.focus({ preventScroll: !0 });
    };
  }, [t]), /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ e("div", { ref: i }),
    c && De(r, c),
    t && De(
      /* @__PURE__ */ e("div", { className: "canvas-fullscreen-backdrop", onClick: n, children: /* @__PURE__ */ e(
        "div",
        {
          ref: l,
          className: "canvas-fullscreen-stage",
          role: "dialog",
          "aria-modal": "true",
          "aria-label": a,
          onClick: (d) => d.stopPropagation(),
          onKeyDown: (d) => {
            if (d.key === "Escape" && d.target.closest("[data-fp-overlay]") || (d.key === "Escape" && (d.preventDefault(), d.stopPropagation(), n()), d.key !== "Tab")) return;
            const p = [
              ...d.currentTarget.querySelectorAll(
                'button:not(:disabled),input:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]'
              )
            ].filter((m) => m.getClientRects().length), h = p[0], f = p.at(-1);
            d.shiftKey && document.activeElement === h ? (d.preventDefault(), f?.focus()) : !d.shiftKey && document.activeElement === f && (d.preventDefault(), h?.focus());
          }
        }
      ) }),
      document.body
    )
  ] });
}
const ga = 0.25, va = 4;
function vc(t, n, r) {
  const a = t.match(/<svg\b[^>]*>/i);
  if (!a) return t;
  const i = a[0];
  if (/\bviewbox\s*=/i.test(i)) return t;
  const l = i.match(/\bwidth\s*=\s*["']?\s*(\d+(?:\.\d+)?)/i), s = i.match(/\bheight\s*=\s*["']?\s*(\d+(?:\.\d+)?)/i), c = l ? parseFloat(l[1]) : n, u = s ? parseFloat(s[1]) : r;
  return t.replace(
    i,
    i.replace(/<svg\b/i, `<svg viewBox="0 0 ${c} ${u}"`)
  );
}
function Ai({
  block: t,
  revisionBlock: n = t,
  revisionTopic: r,
  onRevisionSubmit: a,
  onRevisionAccepted: i
}) {
  const l = t.width ?? 400, s = t.height ?? 300, [c, u] = k({ x: 0, y: 0 }), [d, p] = k(1), h = B(null), { fullscreen: f, toggle: m, exit: b } = Vr(), g = Ue(() => uc(t.source), [t.source]), y = g.trimStart().startsWith("<svg"), w = Ue(() => {
    const A = y ? g : `<svg viewBox="0 0 ${l} ${s}" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">${g}</svg>`;
    return vc(A, l, s);
  }, [g, y, s, l]), v = Ue(() => mc(w), [w]), N = v.ok ? null : {
    ok: !1,
    reason: v.reason,
    message: "Canvas has no visible SVG content.",
    details: { visibleElementCount: v.visibleElementCount }
  }, x = xe(
    (A) => {
      A.target.closest(
        ".svg-canvas-controls, .canvas-revision-panel, .canvas-source-panel"
      ) || (A.currentTarget.setPointerCapture(A.pointerId), h.current = {
        startX: A.clientX,
        startY: A.clientY,
        panX: c.x,
        panY: c.y
      });
    },
    [c]
  ), C = xe(
    (A) => {
      h.current && u({
        x: h.current.panX + A.clientX - h.current.startX,
        y: h.current.panY + A.clientY - h.current.startY
      });
    },
    []
  ), I = xe(() => {
    h.current = null;
  }, []), L = xe((A) => {
    if (!A.ctrlKey && !A.metaKey) return;
    A.preventDefault();
    const D = A.deltaY > 0 ? 0.9 : 1.1;
    p((U) => Math.max(ga, Math.min(va, U * D)));
  }, []), K = xe(() => {
    u({ x: 0, y: 0 }), p(1);
  }, []), S = /* @__PURE__ */ e(
    Yr,
    {
      onReset: K,
      onZoomIn: () => p((A) => Math.min(va, A * 1.2)),
      onZoomOut: () => p((A) => Math.max(ga, A / 1.2)),
      onMaximize: m,
      fullscreen: f
    }
  );
  return /* @__PURE__ */ e(Yn, { open: f, onExit: b, children: /* @__PURE__ */ e(
    un,
    {
      title: t.title,
      source: t.source,
      diagnostic: N,
      controls: S,
      className: "svg-raw-content",
      style: { touchAction: "none" },
      onPointerDown: x,
      onPointerMove: C,
      onPointerUp: I,
      onPointerCancel: I,
      onWheel: L,
      revisionBlock: n,
      revisionTopic: r,
      onRevisionSubmit: a,
      onRevisionAccepted: i,
      children: /* @__PURE__ */ e(
        "div",
        {
          className: "svg-raw-inner",
          style: {
            transform: `translate(${c.x}px, ${c.y}px) scale(${d})`,
            transformOrigin: "center center",
            width: "100%",
            height: "auto",
            minHeight: s
          },
          dangerouslySetInnerHTML: { __html: w }
        }
      )
    }
  ) });
}
const ya = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, wa = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
}, yc = /\\[A-Za-z]+/;
function ka(t) {
  const n = [];
  let r = 0, a = 0;
  for (let i = 0; i < t.length; i += 1) {
    const l = t[i];
    l === "(" && (r += 1), l === ")" && (r -= 1), l === "," && r === 0 && (n.push(t.slice(a, i).trim()), a = i + 1);
  }
  return n.push(t.slice(a).trim()), n;
}
function Na(t, n, r) {
  return `(1/((${r})*sqrt(2*pi)))*exp(-(((${t})-(${n}))^2)/(2*(${r})^2))`;
}
function Ii(t, n = {}) {
  const r = String(n.mu ?? 0), a = String(n.sigma ?? 1);
  let i = (t ?? "").trim().replace(/\u2212/g, "-").replace(/\bMath\./g, "").replace(/μ/g, r).replace(/σ/g, a);
  return i = i.replace(/\b(?:normal_pdf|gaussian)\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x", u = "0", d = "1"] = ka(s);
    return Na(c, u, d);
  }), i = i.replace(/\bphi\s*\(([^()]*(?:\([^)]*\)[^()]*)*)\)/gi, (l, s) => {
    const [c = "x"] = ka(s);
    return Na(c, "0", "1");
  }), i;
}
function wc(t) {
  const n = Object.keys(ya), r = Object.values(ya), a = Object.keys(wa), i = Object.values(wa), l = t.replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), s = new Function(
    "x",
    ...n,
    ...a,
    `"use strict"; return (${l});`
  );
  return (c) => {
    const u = s(c, ...r, ...i);
    return typeof u == "number" ? u : NaN;
  };
}
function kc(t, n = {}) {
  const r = Ii(t, n);
  if (!r)
    return {
      ok: !1,
      reason: "empty-fn",
      normalizedFn: r,
      message: "Function expression is empty."
    };
  if (yc.test(r))
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function plots do not accept LaTeX syntax. Use plain expressions such as normal_pdf(x,0,1)."
    };
  let a;
  try {
    a = wc(r);
  } catch {
    return {
      ok: !1,
      reason: "unsupported-syntax",
      normalizedFn: r,
      message: "Function expression could not be parsed."
    };
  }
  const i = n.xmin ?? -10, l = n.xmax ?? 10, s = Math.max(2, Math.floor(n.samples ?? 200)), c = (l - i) / (s - 1);
  let u = 0;
  for (let d = 0; d < s; d += 1)
    try {
      const p = a(i + d * c);
      Number.isFinite(p) && (u += 1);
    } catch {
      return {
        ok: !1,
        reason: "unsupported-syntax",
        normalizedFn: r,
        message: "Function expression failed while sampling."
      };
    }
  return u === 0 ? {
    ok: !1,
    reason: "no-finite-samples",
    normalizedFn: r,
    message: "Function expression produced no finite sample points."
  } : {
    ok: !0,
    normalizedFn: r,
    sampledPoints: u
  };
}
const xa = {
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  exp: Math.exp,
  log: Math.log,
  ln: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sqrt: Math.sqrt,
  abs: Math.abs,
  ceil: Math.ceil,
  floor: Math.floor,
  round: Math.round,
  sign: Math.sign,
  pow: Math.pow,
  min: Math.min,
  max: Math.max
}, Ca = {
  pi: Math.PI,
  PI: Math.PI,
  e: Math.E,
  E: Math.E
};
function Xr(t) {
  const n = Ii(t).replace(/\^/g, "**").replace(/(\d)([a-zA-Z(])/g, "$1*$2").replace(/\)(\d)/g, ")*$1").replace(/\)([a-zA-Z(])/g, ")*$1"), r = Object.keys(xa), a = Object.values(xa), i = Object.keys(Ca), l = Object.values(Ca);
  try {
    const s = new Function(
      "x",
      ...r,
      ...i,
      `"use strict"; return (${n});`
    );
    return (c) => {
      try {
        const u = s(c, ...a, ...l);
        return typeof u == "number" ? u : NaN;
      } catch {
        return NaN;
      }
    };
  } catch {
    return () => NaN;
  }
}
function Sa(t, n, r = 8) {
  const a = n - t;
  if (a <= 0 || !isFinite(a)) return [];
  const i = a / r, l = Math.pow(10, Math.floor(Math.log10(i))), s = i / l;
  let c;
  s <= 1.5 ? c = 1 * l : s <= 3.5 ? c = 2 * l : s <= 7.5 ? c = 5 * l : c = 10 * l;
  const u = Math.ceil(t / c) * c, d = [];
  for (let p = u; p <= n + c * 0.01; p += c) {
    const h = Math.round(p * 1e12) / 1e12;
    h >= t && h <= n && d.push({ value: h, label: Nc(h, c) });
  }
  return d;
}
function Nc(t, n) {
  if (t === 0) return "0";
  const r = Math.max(0, -Math.floor(Math.log10(n)));
  return t.toFixed(r).replace(/\.?0+$/, "");
}
function xc(t, n, r, a, i, l, s, c) {
  const u = (r - n) / (a - 1), p = (c - s) * 2;
  let h = "", f = null, m = !1;
  for (let b = 0; b < a; b++) {
    const g = n + b * u, y = t(g);
    if (!isFinite(y) || isNaN(y)) {
      m = !1, f = null;
      continue;
    }
    const w = i(g), v = l(y);
    f !== null && Math.abs(y - f) > p && (m = !1), m ? h += `L${w.toFixed(2)},${v.toFixed(2)}` : (h += `M${w.toFixed(2)},${v.toFixed(2)}`, m = !0), f = y;
  }
  return h;
}
function Li(t, n, r, a = 200) {
  let i = 1 / 0, l = -1 / 0;
  const s = (r - n) / (a - 1);
  for (let u = 0; u < a; u++) {
    const d = n + u * s, p = t(d);
    isFinite(p) && (p < i && (i = p), p > l && (l = p));
  }
  if (!isFinite(i) || !isFinite(l)) return { yMin: -1, yMax: 1 };
  const c = (l - i) * 0.1 || 1;
  return { yMin: i - c, yMax: l + c };
}
const nr = [
  "var(--md-sys-color-primary)",
  "var(--md-sys-color-tertiary)",
  "var(--md-sys-color-error)",
  "var(--color-formula, #1976d2)",
  "var(--color-success, #2e7d32)",
  "var(--color-warning, #f57c00)"
];
function Cc(t, n) {
  return n ? nr.some((r) => r.includes(n)) ? `var(--md-sys-color-${n})` : n : nr[t % nr.length];
}
const ce = { top: 20, right: 20, bottom: 36, left: 48 }, Ma = 0.25, Ea = 4;
function Ti({
  width: t = 600,
  height: n = 400,
  xMin: r = -10,
  xMax: a = 10,
  yMin: i = -5,
  yMax: l = 5,
  showGrid: s = !0,
  showAxes: c = !0,
  axisLabels: u,
  pannable: d = !0,
  zoomable: p = !0,
  className: h,
  children: f
}) {
  const m = B(null), [b, g] = k({ x: 0, y: 0 }), [y, w] = k(1), { fullscreen: v, toggle: N, exit: x } = Vr(), C = B(null), I = t - ce.left - ce.right, L = n - ce.top - ce.bottom, K = a - r || 1e-6, S = l - i || 1e-6, A = xe(
    (P) => {
      d && (P.target.closest?.(".svg-canvas-controls") || (P.currentTarget.setPointerCapture(P.pointerId), C.current = {
        startX: P.clientX,
        startY: P.clientY,
        panX: b.x,
        panY: b.y
      }));
    },
    [d, b]
  ), D = xe((P) => {
    if (!C.current) return;
    const re = P.clientX - C.current.startX, ie = P.clientY - C.current.startY;
    g({ x: C.current.panX + re, y: C.current.panY + ie });
  }, []), U = xe(() => {
    C.current = null;
  }, []), j = xe(
    (P) => {
      if (!p || !P.ctrlKey && !P.metaKey) return;
      P.preventDefault();
      const re = P.deltaY > 0 ? 0.9 : 1.1;
      w((ie) => Math.max(Ma, Math.min(Ea, ie * re)));
    },
    [p]
  ), T = xe(() => {
    g({ x: 0, y: 0 }), w(1);
  }, []), M = Sa(r, a), R = Sa(i, l), q = (P) => ce.left + (P - r) / K * I, F = (P) => ce.top + (l - P) / S * L, E = q(0), z = F(0), $ = 0 >= r && 0 <= a && 0 >= i && 0 <= l;
  return /* @__PURE__ */ e(Yn, { open: v, onExit: x, children: /* @__PURE__ */ o("div", { className: `svg-canvas-wrapper ${h ?? ""}`, children: [
    /* @__PURE__ */ o(
      "svg",
      {
        ref: m,
        viewBox: `0 0 ${t} ${n}`,
        width: t,
        height: n,
        onPointerDown: A,
        onPointerMove: D,
        onPointerUp: U,
        onPointerCancel: U,
        onWheel: j,
        style: { touchAction: "none" },
        children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e("clipPath", { id: "plot-area", children: /* @__PURE__ */ e(
            "rect",
            {
              x: ce.left,
              y: ce.top,
              width: I,
              height: L
            }
          ) }) }),
          /* @__PURE__ */ o(
            "g",
            {
              transform: `translate(${b.x + t / 2}, ${b.y + n / 2}) scale(${y}) translate(${-t / 2}, ${-n / 2})`,
              children: [
                s && /* @__PURE__ */ o("g", { className: "svg-canvas-grid", clipPath: "url(#plot-area)", children: [
                  M.map((P) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: q(P.value),
                      y1: ce.top,
                      x2: q(P.value),
                      y2: ce.top + L
                    },
                    `gx-${P.value}`
                  )),
                  R.map((P) => /* @__PURE__ */ e(
                    "line",
                    {
                      x1: ce.left,
                      y1: F(P.value),
                      x2: ce.left + I,
                      y2: F(P.value)
                    },
                    `gy-${P.value}`
                  ))
                ] }),
                c && /* @__PURE__ */ o("g", { className: "svg-canvas-axis", children: [
                  $ || i <= 0 ? /* @__PURE__ */ o(Q, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: ce.left,
                        y1: $ ? z : ce.top + L,
                        x2: ce.left + I,
                        y2: $ ? z : ce.top + L
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${ce.left + I},${$ ? z : ce.top + L} ${ce.left + I - 6},${($ ? z : ce.top + L) - 3} ${ce.left + I - 6},${($ ? z : ce.top + L) + 3}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  $ || r <= 0 ? /* @__PURE__ */ o(Q, { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: $ ? E : ce.left,
                        y1: ce.top,
                        x2: $ ? E : ce.left,
                        y2: ce.top + L
                      }
                    ),
                    /* @__PURE__ */ e(
                      "polygon",
                      {
                        points: `${$ ? E : ce.left},${ce.top} ${($ ? E : ce.left) - 3},${ce.top + 6} ${($ ? E : ce.left) + 3},${ce.top + 6}`,
                        fill: "var(--md-sys-color-on-surface)"
                      }
                    )
                  ] }) : null,
                  M.map(
                    (P) => P.value === 0 && $ ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: q(P.value),
                          y1: ($ ? z : ce.top + L) - 3,
                          x2: q(P.value),
                          y2: ($ ? z : ce.top + L) + 3
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: q(P.value),
                          y: ($ ? z : ce.top + L) + 16,
                          textAnchor: "middle",
                          children: P.label
                        }
                      )
                    ] }, `xt-${P.value}`)
                  ),
                  R.map(
                    (P) => P.value === 0 && $ ? null : /* @__PURE__ */ o("g", { className: "svg-canvas-tick", children: [
                      /* @__PURE__ */ e(
                        "line",
                        {
                          x1: ($ ? E : ce.left) - 3,
                          y1: F(P.value),
                          x2: ($ ? E : ce.left) + 3,
                          y2: F(P.value)
                        }
                      ),
                      /* @__PURE__ */ e(
                        "text",
                        {
                          x: ($ ? E : ce.left) - 8,
                          y: F(P.value) + 4,
                          textAnchor: "end",
                          children: P.label
                        }
                      )
                    ] }, `yt-${P.value}`)
                  ),
                  u?.x && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: ce.left + I - 4,
                      y: ($ ? z : ce.top + L) + 32,
                      textAnchor: "end",
                      children: u.x
                    }
                  ),
                  u?.y && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-axis-label",
                      x: ($ ? E : ce.left) + 12,
                      y: ce.top + 4,
                      textAnchor: "start",
                      children: u.y
                    }
                  ),
                  $ && /* @__PURE__ */ e(
                    "text",
                    {
                      className: "svg-canvas-tick",
                      x: E - 8,
                      y: z + 16,
                      textAnchor: "end",
                      fill: "var(--md-sys-color-on-surface-variant)",
                      fontSize: "10",
                      fontFamily: "var(--font-mono)",
                      children: "O"
                    }
                  )
                ] }),
                /* @__PURE__ */ e("g", { clipPath: "url(#plot-area)", children: f })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e(
      Yr,
      {
        onReset: d || p ? T : void 0,
        onZoomIn: p ? () => w((P) => Math.min(Ea, P * 1.2)) : void 0,
        onZoomOut: p ? () => w((P) => Math.max(Ma, P / 1.2)) : void 0,
        onMaximize: N,
        fullscreen: v
      }
    )
  ] }) });
}
function Di({
  fn: t,
  xMin: n,
  xMax: r,
  yMin: a,
  yMax: i,
  plotLeft: l,
  plotTop: s,
  plotWidth: c,
  plotHeight: u,
  color: d,
  colorIndex: p = 0,
  label: h,
  strokeWidth: f = 2,
  samples: m = 500
}) {
  const b = Ue(
    () => kc(t, { xmin: n, xmax: r, samples: m }),
    [t, m, r, n]
  ), g = b.normalizedFn, y = Ue(
    () => Xr(g),
    [g]
  ), w = (C) => l + (C - n) / (r - n) * c, v = (C) => s + (i - C) / (i - a) * u, N = Ue(
    () => b.ok ? xc(
      y,
      n,
      r,
      m,
      w,
      v,
      a,
      i
    ) : "",
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      b.ok,
      g,
      n,
      r,
      a,
      i,
      l,
      s,
      c,
      u,
      m
    ]
  ), x = Cc(p, d);
  return !b.ok || !N.trim() ? /* @__PURE__ */ e(
    "g",
    {
      "data-testid": "plot-diagnostic",
      "aria-label": b.ok ? "empty plot path" : b.message,
      children: /* @__PURE__ */ e(
        "text",
        {
          x: l + 8,
          y: s + 20,
          fontSize: 12,
          fill: "var(--md-sys-color-error)",
          children: b.ok ? "No drawable curve points." : b.message
        }
      )
    }
  ) : /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ e(
      "path",
      {
        d: N,
        className: "svg-canvas-curve",
        stroke: x,
        strokeWidth: f
      }
    ),
    h && /* @__PURE__ */ e("title", { children: h })
  ] });
}
const $t = { top: 20, right: 20, bottom: 36, left: 48 };
function Sc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = t.width ?? 600, l = t.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = Li(Xr(t.fn), s, c), d = t.attrs.ymin ?? u.yMin, p = t.attrs.ymax ?? u.yMax, h = i - $t.left - $t.right, f = l - $t.top - $t.bottom;
  return /* @__PURE__ */ e(
    un,
    {
      title: t.title,
      source: t.fn,
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        Ti,
        {
          width: i,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: /* @__PURE__ */ e(
            Di,
            {
              fn: t.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: $t.left,
              plotTop: $t.top,
              plotWidth: h,
              plotHeight: f,
              color: t.attrs.color,
              label: t.attrs.label,
              samples: t.attrs.samples
            }
          )
        }
      )
    }
  );
}
const zt = { top: 20, right: 20, bottom: 36, left: 48 };
function Mc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = t.width ?? t.attrs.width ?? 600, l = t.height ?? t.attrs.height ?? 400, s = t.attrs.xmin ?? -10, c = t.attrs.xmax ?? 10, u = t.plots.reduce(
    (m, b) => {
      const g = Li(Xr(b.fn), s, c);
      return {
        yMin: Math.min(m.yMin, g.yMin),
        yMax: Math.max(m.yMax, g.yMax)
      };
    },
    { yMin: 1 / 0, yMax: -1 / 0 }
  ), d = t.attrs.ymin ?? (Number.isFinite(u.yMin) ? u.yMin : -5), p = t.attrs.ymax ?? (Number.isFinite(u.yMax) ? u.yMax : 5), h = i - zt.left - zt.right, f = l - zt.top - zt.bottom;
  return /* @__PURE__ */ e(
    un,
    {
      title: t.title,
      source: JSON.stringify(t.plots, null, 2),
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        Ti,
        {
          width: i,
          height: l,
          xMin: s,
          xMax: c,
          yMin: d,
          yMax: p,
          axisLabels: {
            x: t.attrs.xlabel ?? "x",
            y: t.attrs.ylabel ?? "y"
          },
          children: t.plots.map((m, b) => /* @__PURE__ */ e(
            Di,
            {
              fn: m.fn,
              xMin: s,
              xMax: c,
              yMin: d,
              yMax: p,
              plotLeft: zt.left,
              plotTop: zt.top,
              plotWidth: h,
              plotHeight: f,
              color: m.color,
              colorIndex: b,
              label: m.label,
              samples: m.samples
            },
            `${m.fn}-${b}`
          ))
        }
      )
    }
  );
}
const Pi = cn(null);
function Ec({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const i = Bt(Pi), [l, s] = k({ key: "", svg: "", error: "" });
  Y(() => {
    if (!i) return;
    const u = new AbortController();
    return s({ key: t.source, svg: "", error: "" }), i(t.source, {
      width: t.width || 380,
      height: t.height || 300,
      signal: u.signal
    }).then((d) => {
      u.signal.aborted || s({ key: t.source, svg: d, error: "" });
    }).catch(() => {
      u.signal.aborted || s({
        key: t.source,
        svg: "",
        error: "分子结构暂时无法显示，请检查后重试。"
      });
    }), () => u.abort();
  }, [i, t.source, t.width, t.height]);
  const c = { revisionTopic: n, onRevisionSubmit: r, onRevisionAccepted: a };
  return l.key === t.source && l.svg ? /* @__PURE__ */ e(
    Ai,
    {
      ...c,
      block: { ...t, kind: "raw-svg", source: l.svg }
    }
  ) : /* @__PURE__ */ e(
    un,
    {
      ...c,
      title: t.title || "分子结构",
      source: t.source,
      revisionBlock: t,
      children: /* @__PURE__ */ e("p", { role: "status", children: l.error || (i ? "正在绘制分子结构…" : "选择分子结构，查看对应内容。") })
    }
  );
}
function $c(t, n) {
  const r = n.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 60) || "demo", a = new Blob([t], { type: "text/html;charset=utf-8" }), i = URL.createObjectURL(a), l = document.createElement("a");
  l.href = i, l.download = `${r}.html`, document.body.appendChild(l), l.click(), l.remove(), setTimeout(() => URL.revokeObjectURL(i), 1e3);
}
function zc({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  const { fullscreen: i, toggle: l, exit: s } = Vr(), c = t.title || "互动内容", u = t.height ?? 360, d = xe(() => {
    const f = URL.createObjectURL(
      new Blob([t.source], { type: "text/html" })
    );
    window.open(f, "_blank", "noopener"), setTimeout(() => URL.revokeObjectURL(f), 6e4);
  }, [t.source]), p = xe(
    () => $c(t.source, c),
    [t.source, c]
  ), h = /* @__PURE__ */ e(
    Yr,
    {
      onDownload: p,
      onOpenExternal: d,
      onMaximize: l,
      fullscreen: i
    }
  );
  return /* @__PURE__ */ e(Yn, { open: i, onExit: s, children: /* @__PURE__ */ e(
    un,
    {
      title: t.title,
      source: t.source,
      controls: h,
      className: "html-canvas-layer",
      revisionBlock: t,
      revisionTopic: n,
      onRevisionSubmit: r,
      onRevisionAccepted: a,
      children: /* @__PURE__ */ e(
        "iframe",
        {
          title: c,
          srcDoc: `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none';">${t.source}`,
          sandbox: "allow-scripts",
          referrerPolicy: "no-referrer",
          className: "html-canvas-frame",
          style: { height: i ? "100%" : u }
        }
      )
    }
  ) });
}
function kr({
  block: t,
  revisionTopic: n,
  onRevisionSubmit: r,
  onRevisionAccepted: a
}) {
  switch (t.kind) {
    case "raw-svg":
      return /* @__PURE__ */ e(
        Ai,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "plot":
      return /* @__PURE__ */ e(
        Sc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "multi-plot":
      return /* @__PURE__ */ e(
        Mc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "molecule":
      return /* @__PURE__ */ e(
        Ec,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
    case "html":
      return /* @__PURE__ */ e(
        zc,
        {
          block: t,
          revisionTopic: n,
          onRevisionSubmit: r,
          onRevisionAccepted: a
        }
      );
  }
}
const Ac = /^<svg\b[\s\S]*<\/svg>$/i, Ic = /<(?:g|path|rect|circle|ellipse|line|polyline|polygon|text|tspan|textPath|defs|marker|stop|linearGradient|radialGradient|clipPath|mask|pattern|image|use|symbol)\b[\s\S]*>/i;
function at(t) {
  return typeof t == "string" && t.trim() ? t.trim() : void 0;
}
function je(t) {
  if (t === "" || t === null || t === void 0) return;
  const n = Number(t);
  return Number.isFinite(n) ? n : void 0;
}
function An(t) {
  if (t === !0 || t === "true") return !0;
  if (t === !1 || t === "false") return !1;
}
function Lc(t) {
  return {
    title: at(t.title),
    width: je(t.width),
    height: je(t.height)
  };
}
function Tc(t, n, r) {
  const a = String(t ?? "").trim();
  if (!a) return "";
  if (Ac.test(a) || !Ic.test(a)) return a;
  const i = Number.isFinite(n) && n && n > 0 ? Math.round(n) : 600, l = Number.isFinite(r) && r && r > 0 ? Math.round(r) : 360;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${i} ${l}" width="${i}" height="${l}">${a}</svg>`;
}
function Fi(t) {
  return {
    xmin: je(t.xmin),
    xmax: je(t.xmax),
    ymin: je(t.ymin),
    ymax: je(t.ymax),
    label: at(t.label),
    xlabel: at(t.xlabel),
    ylabel: at(t.ylabel),
    color: at(t.color),
    samples: je(t.samples),
    grid: An(t.grid),
    axes: An(t.axes)
  };
}
function Dc(t) {
  return {
    xmin: je(t.xmin),
    xmax: je(t.xmax),
    ymin: je(t.ymin),
    ymax: je(t.ymax),
    xlabel: at(t.xlabel),
    ylabel: at(t.ylabel),
    width: je(t.width),
    height: je(t.height),
    grid: An(t.grid),
    axes: An(t.axes)
  };
}
function Pc(t, n) {
  const r = at(t.mode)?.toLowerCase() ?? "raw", a = (n ?? "").trim(), i = Lc(t);
  return r === "molecule" ? {
    ...i,
    kind: "molecule",
    source: a
  } : r === "math" ? {
    ...i,
    kind: "plot",
    fn: at(t.fn) ?? a,
    attrs: Fi(t)
  } : r === "html" ? {
    ...i,
    kind: "html",
    source: a
  } : {
    ...i,
    kind: "raw-svg",
    source: Tc(a, i.width, i.height)
  };
}
const Oi = Xo(Go), Xn = [
  { value: "javascript", label: "JavaScript" },
  { value: "typescript", label: "TypeScript" },
  { value: "python", label: "Python" },
  { value: "bash", label: "Bash" },
  { value: "json", label: "JSON" },
  { value: "html", label: "HTML" },
  { value: "css", label: "CSS" },
  { value: "markdown", label: "Markdown" },
  { value: "xml", label: "XML" },
  { value: "yaml", label: "YAML" },
  { value: "mermaid", label: "Mermaid" },
  { value: "cpp", label: "C++" },
  { value: "java", label: "Java" },
  { value: "c", label: "C" },
  { value: "csharp", label: "C#" },
  { value: "go", label: "Go" },
  { value: "rust", label: "Rust" },
  { value: "sql", label: "SQL" }
];
function rr() {
  return null;
}
function Fc(t) {
  if (!t || typeof t != "object") return rr();
  const r = t.attrs?.language;
  if (typeof r != "string") return rr();
  const a = r.trim();
  return a || rr();
}
const Ri = 4;
function Bi(t, n, r, a = !1, i = Ri) {
  const l = " ".repeat(i);
  if (n === r && !a) return [{ from: n, to: r, text: l }];
  const s = t.slice(0, n).lastIndexOf(`
`) + 1, c = r > n && t[r - 1] === `
` ? r - 1 : r, u = [];
  for (let d = s; d <= c; ) {
    const p = t[d] === "	" ? 1 : t.slice(d).match(/^ */)?.[0].length || 0;
    a ? p && u.push({ from: d, to: d + Math.min(p, i), text: "" }) : u.push({ from: d, to: d, text: l });
    const h = t.indexOf(`
`, d);
    if (h < 0) break;
    d = h + 1;
  }
  return u;
}
function In(t, n) {
  let r = 0;
  for (const a of n) {
    if (t < a.from) break;
    if (t <= a.to) return a.from + r + a.text.length;
    r += a.text.length - (a.to - a.from);
  }
  return t + r;
}
function Ln(t, n = !1) {
  if (!t.isEditable || t.isDestroyed || t.view.composing) return !1;
  const { selection: r } = t.state;
  if (!(r instanceof Ze) || !r.$from.sameParent(r.$to) || r.$from.parent.type.name !== "codeBlock") return !1;
  const a = r.$from.start(), i = Bi(r.$from.parent.textContent, r.from - a, r.to - a, n);
  return t.commands.command(({ tr: l }) => {
    for (const s of [...i].reverse()) l.insertText(s.text, a + s.from, a + s.to);
    return l.setSelection(Ze.create(
      l.doc,
      a + In(r.anchor - a, i),
      a + In(r.head - a, i)
    )), i.length && l.scrollIntoView(), !0;
  });
}
function ji(t, n, r) {
  const a = t.slice(0, n).lastIndexOf(`
`) + 1, i = t.slice(a, n), l = i.match(/^[\t ]*/)?.[0] || "";
  return n === r && r === t.length && i && i === l ? { from: a, to: r, text: `
` } : { from: n, to: r, text: `
${l}` };
}
function Oc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!(n instanceof Ze) || !n.$from.sameParent(n.$to) || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.start(), a = ji(n.$from.parent.textContent, n.from - r, n.to - r);
  return t.commands.command(({ tr: i }) => (i.insertText(a.text, r + a.from, r + a.to), i.setSelection(Ze.create(i.doc, r + a.from + a.text.length)).scrollIntoView(), !0));
}
function Rc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parentOffset, a = n.$from.parent.textContent.slice(0, r), i = a.slice(a.lastIndexOf(`
`) + 1);
  if (!i || !/^[\t ]+$/.test(i)) return !1;
  const l = i.endsWith("	") ? 1 : Math.min(i.match(/ +$/)?.[0].length || 0, (i.length - 1) % Ri + 1);
  return t.commands.deleteRange({ from: n.from - l, to: n.from });
}
function Bc(t, n) {
  const r = t.currentTarget;
  if (r.readOnly || r.disabled || t.nativeEvent.isComposing || t.ctrlKey || t.metaKey || t.altKey) return !1;
  const { value: a, selectionStart: i, selectionEnd: l, selectionDirection: s } = r, c = t.key === "Tab" ? Bi(a, i, l, t.shiftKey) : t.key === "Enter" && !t.shiftKey ? [ji(a, i, l)] : null;
  if (!c) return !1;
  if (t.preventDefault(), !c.length) return !0;
  let u = a;
  for (const b of [...c].reverse()) u = u.slice(0, b.from) + b.text + u.slice(b.to);
  const d = c[0].from, p = c.at(-1).to, h = u.slice(d, u.length - (a.length - p)), f = t.key === "Enter" ? d + c[0].text.length : In(i, c), m = t.key === "Enter" ? f : In(l, c);
  return r.setSelectionRange(d, p), document.execCommand?.("insertText", !1, h) || n(u), r.setSelectionRange(f, m, s), requestAnimationFrame(() => {
    document.activeElement === r && r.value === u && r.setSelectionRange(f, m, s);
  }), !0;
}
const qi = {
  stopEvent: ({ event: t }) => !!(t.target instanceof Element ? t.target : t.target instanceof globalThis.Node ? t.target.parentElement : null)?.closest("[data-nested-editor-boundary]")
}, ln = { "(": ")", "[": "]", "{": "}", "<": ">", '"': '"', "'": "'", "`": "`" }, jc = new Set(Object.values(ln));
function Ki(t, n, r) {
  let a = "", i = !1, l = !1;
  const s = /^(python|py|bash|sh|shell|ruby|rb|yaml|yml|r)$/i.test(r);
  for (let c = 0; c < n; c++) {
    const u = t[c], d = t[c + 1];
    if (i) {
      u === `
` && (i = !1);
      continue;
    }
    if (l) {
      u === "*" && d === "/" && (l = !1, c++);
      continue;
    }
    if (a) {
      u === "\\" ? c++ : u === a && (a = "");
      continue;
    }
    u === "/" && d === "/" ? (i = !0, c++) : u === "/" && d === "*" ? (l = !0, c++) : s && u === "#" ? i = !0 : "\"'`".includes(u) && (a = u);
  }
  return { quote: a, comment: i || l };
}
function qc(t, n, r) {
  const a = t.slice(0, n), i = a.slice(a.lastIndexOf(`
`) + 1);
  return /^(html|xml|vue|svelte|jsx|tsx)$/i.test(r) || /^\s*$/.test(i) || /^\s*#\s*include\s*$/.test(i) ? !0 : /^(c|cpp|c\+\+|java|rust|rs|csharp|cs|typescript|ts)$/i.test(r) && /[\w>:]$/.test(a);
}
function Hi(t, n, r, a, i = "") {
  if (a.length !== 1) return null;
  const l = Math.min(n, r), s = Math.max(n, r), c = Ki(t, l, i);
  if (c.comment) return null;
  const u = a === '"' || a === "'" || a === "`";
  if ((t.slice(0, l).match(/\\+$/)?.[0].length ?? 0) % 2 === 1) return null;
  if (l === s && t[l] === a && jc.has(a) && (u ? c.quote === a : !c.quote))
    return { from: l, to: s, text: "", anchor: l + 1, head: l + 1 };
  const p = ln[a];
  return !p || c.quote || a === "<" && !qc(t, l, i) || u && a === "'" && /[\p{L}\p{N}_]/u.test(t[l - 1] ?? "") || l === s && t[s] && !/[\s)\]}>;,.:]/.test(t[s]) ? null : { from: l, to: s, text: a + t.slice(l, s) + p, anchor: n + 1, head: r + 1 };
}
function Kc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, a = n.$from.parentOffset, i = r[a - 1];
  return !ln[i] || ln[i] !== r[a] || !Hi(r.slice(0, a - 1) + r.slice(a + 1), a - 1, a - 1, i, String(n.$from.parent.attrs.language || "")) ? !1 : t.commands.deleteRange({ from: n.from - 1, to: n.from + 1 });
}
function Hc(t) {
  if (!t.isEditable || t.view.composing) return !1;
  const { selection: n } = t.state;
  if (!n.empty || n.$from.parent.type.name !== "codeBlock") return !1;
  const r = n.$from.parent.textContent, a = n.$from.parentOffset;
  if (!"([{".includes(r[a - 1] || " ") || ln[r[a - 1]] !== r[a]) return !1;
  const i = Ki(r, a, String(n.$from.parent.attrs.language || ""));
  if (i.quote || i.comment) return !1;
  const l = r.slice(0, a), s = l.slice(l.lastIndexOf(`
`) + 1).match(/^[\t ]*/)?.[0] || "";
  return t.commands.command(({ tr: c }) => (c.insertText(`
` + s + `    
` + s, n.from), c.setSelection(Ze.create(c.doc, n.from + s.length + 5)).scrollIntoView(), !0));
}
function Uc(t) {
  return new dn({ props: { handleTextInput(n, r, a, i) {
    if (!t.isEditable || n.composing) return !1;
    const l = n.state.selection;
    if (!(l instanceof Ze) || !l.$from.sameParent(l.$to) || l.$from.parent.type.name !== "codeBlock" || r !== l.from || a !== l.to) return !1;
    const s = l.$from.start(), c = Hi(l.$from.parent.textContent, l.anchor - s, l.head - s, i, String(l.$from.parent.attrs.language || ""));
    if (!c) return !1;
    const u = n.state.tr;
    return c.text && u.insertText(c.text, s + c.from, s + c.to), u.setSelection(Ze.create(u.doc, s + c.anchor, s + c.head)).scrollIntoView(), n.dispatch(u), !0;
  } } });
}
const on = new si("codeFence"), Ui = /^[a-zA-Z][a-zA-Z0-9_+#.-]*$/;
function _c(t) {
  return new Ko({
    find: /^```$/,
    handler: ({ state: n, range: r }) => {
      const a = n.doc.resolve(r.from);
      if (!a.node(-1).canReplaceWith(a.index(-1), a.indexAfter(-1), t)) return null;
      const i = n.tr.delete(r.from, r.to).setBlockType(r.from, r.from, t);
      i.setMeta(on, i.selection.$from.before());
    }
  });
}
function Wc() {
  return new dn({
    key: on,
    state: {
      init: () => null,
      apply(t, n) {
        const r = t.getMeta(on);
        if (r !== void 0) return r;
        if (n === null || t.selectionSet && !t.docChanged) return null;
        const a = t.mapping.map(n, -1), i = t.doc.nodeAt(a), { selection: l } = t;
        return i?.type.name !== "codeBlock" || i.attrs.language || !l.empty || l.$from.start() !== a + 1 || l.$from.parentOffset !== i.content.size || i.textContent && !Ui.test(i.textContent) ? null : a;
      }
    }
  });
}
function $a(t) {
  const n = on.getState(t.state);
  if (n == null || !t.isEditable || t.view.composing) return !1;
  const r = t.state.doc.nodeAt(n);
  return r?.type.name !== "codeBlock" || r.textContent && !Ui.test(r.textContent) ? !1 : t.commands.command(({ tr: a }) => {
    const i = r.textContent || null;
    return a.delete(n + 1, n + r.nodeSize - 1), a.setNodeMarkup(n, void 0, { ...r.attrs, language: i }), a.setSelection(Ze.create(a.doc, n + 1)).setMeta(on, null), !0;
  });
}
const za = [
  { value: "flow", label: "流程图", code: `flowchart LR
  A[开始] --> B{理解}
  B --> C[应用]` },
  { value: "sequence", label: "时序图", code: `sequenceDiagram
  participant U as 用户
  participant S as 服务
  U->>S: 请求
  S-->>U: 响应` },
  { value: "state", label: "状态图", code: `stateDiagram-v2
  [*] --> 待办
  待办 --> 进行中
  进行中 --> 完成` }
];
function _i({ code: t }) {
  const n = ve().replace(/[^a-zA-Z0-9]/g, ""), r = B(0), [a, i] = k(""), [l, s] = k(""), [c, u] = k("");
  return Y(() => {
    const d = () => u(`${document.documentElement.dataset.theme}/${document.documentElement.dataset.product}`);
    d();
    const p = new MutationObserver(d);
    return p.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product"] }), () => p.disconnect();
  }, []), Y(() => {
    const d = ++r.current, p = setTimeout(async () => {
      try {
        const { default: h } = await import("mermaid"), f = getComputedStyle(document.documentElement);
        h.initialize({ startOnLoad: !1, securityLevel: "strict", suppressErrorRendering: !0, theme: "base", themeVariables: { fontFamily: "system-ui, sans-serif", primaryColor: f.getPropertyValue("--fp-primary-soft").trim() || "#fff2e2", primaryTextColor: f.getPropertyValue("--fp-ink").trim() || "#202124", primaryBorderColor: f.getPropertyValue("--fp-line-strong").trim() || "#b9a68e", lineColor: f.getPropertyValue("--fp-muted").trim() || "#757575" } });
        const m = await h.render(`fp-mermaid-${n}-${d}`, t);
        r.current === d && (i(m.svg), s(""));
      } catch {
        r.current === d && s("图表语法有误，请检查连线、括号和节点名称。");
      }
    }, 250);
    return () => {
      clearTimeout(p), r.current++;
    };
  }, [t, n, c]), /* @__PURE__ */ e("div", { className: "fp-mermaid-preview", "aria-label": "图表预览", children: /* @__PURE__ */ e(fe, { children: l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : a ? /* @__PURE__ */ e("div", { dangerouslySetInnerHTML: { __html: a } }) : /* @__PURE__ */ e("p", { role: "status", children: "正在绘制图表…" }) }) });
}
function Vc({ node: t, editor: n, getPos: r, deleteNode: a, selected: i }) {
  const l = String(t.attrs.language).toLowerCase() === "mermaid", [s, c] = k(!1), [u, d] = k(!1), p = B(null), h = B(null), f = B(!1);
  Y(() => {
    s ? p.current?.focus({ preventScroll: !0 }) : f.current && h.current?.focus({ preventScroll: !0 }), f.current = s;
  }, [s]);
  const m = t.textContent, [b, g] = k(m);
  Y(() => {
    g(m);
  }, [m]);
  const y = () => {
    mi.getState(n.state)?.undoManager.stopCapturing(), n.view.dispatch(fi(n.state.tr));
  }, w = (N) => {
    const x = r();
    x === void 0 || n.isDestroyed || !n.isEditable || (g(N), n.commands.command(({ tr: C }) => {
      const I = C.doc.nodeAt(x);
      return I ? (C.replaceWith(x + 1, x + I.nodeSize - 1, N ? n.schema.text(N) : []), !0) : !1;
    }));
  }, v = () => {
    const N = r();
    if (N === void 0 || !n.isEditable) return !1;
    const x = n.state.doc.nodeAt(N);
    if (x?.type.name !== "codeBlock") return !1;
    const { $from: C, $to: I } = n.state.selection;
    return (!C.sameParent(I) || C.start() !== N + 1) && n.commands.setTextSelection({ from: N + 1, to: N + x.nodeSize - 1 }), n.commands.focus(void 0, { scrollIntoView: !1 }), !0;
  };
  return /* @__PURE__ */ o(Lt, { className: l ? "fp-mermaid-node" : "fp-code-node", "data-selected": i || void 0, "data-note-object": l ? "diagram" : void 0, children: [
    l && /* @__PURE__ */ e("pre", { hidden: !0, "aria-hidden": "true", children: /* @__PURE__ */ e(ua, {}) }),
    l ? /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", children: [
      /* @__PURE__ */ o("header", { className: "fp-code-header", children: [
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e(Lr, { size: 14 }),
          "Mermaid 图表"
        ] }),
        /* @__PURE__ */ o("div", { children: [
          n.isEditable && /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ o("button", { ref: h, type: "button", "aria-label": s ? "完成图表编辑" : "编辑图表", "aria-expanded": s, onClick: () => {
              y(), c((N) => !N);
            }, children: [
              s ? /* @__PURE__ */ e(Pe, { size: 14 }) : /* @__PURE__ */ e(Bn, { size: 14 }),
              s ? "完成" : "编辑"
            ] }),
            /* @__PURE__ */ o("button", { type: "button", "aria-label": "删除图表", onClick: () => {
              y(), a(), n.commands.focus();
            }, children: [
              /* @__PURE__ */ e(Ht, { size: 14 }),
              "删除"
            ] })
          ] }),
          /* @__PURE__ */ e("button", { type: "button", "aria-pressed": u, onClick: () => d((N) => !N), children: "源码" })
        ] })
      ] }),
      /* @__PURE__ */ e(Re, { isOpen: s, children: /* @__PURE__ */ o("div", { className: "fp-mermaid-source", children: [
        /* @__PURE__ */ e(ke, { label: "图表模板", value: "", placeholder: "插入模板", options: za, onChange: (N) => {
          const x = za.find((C) => C.value === N);
          x && w(x.code);
        } }),
        /* @__PURE__ */ e("textarea", { ref: p, readOnly: !n.isEditable, "aria-label": "Mermaid 源码", value: b, spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", onChange: (N) => w(N.target.value), onKeyDown: (N) => {
          N.stopPropagation(), !N.nativeEvent.isComposing && (Bc(N, w) || (N.key === "Escape" || N.key === "Enter" && (N.ctrlKey || N.metaKey)) && (N.preventDefault(), c(!1)));
        } })
      ] }) }),
      /* @__PURE__ */ e(Re, { isOpen: !s && u, children: /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: m }) }) }),
      /* @__PURE__ */ e(_i, { code: m })
    ] }) : /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ o("div", { contentEditable: !1, "data-nested-editor-boundary": "", className: "fp-code-header", children: [
        /* @__PURE__ */ e(ke, { label: "代码块语言", value: t.attrs.language || "", disabled: !n.isEditable, options: [{ value: "", label: "纯文本" }, ...Xn], onChange: (N) => {
          const x = r();
          x !== void 0 && n.commands.command(({ tr: C }) => (C.setNodeMarkup(x, void 0, { ...t.attrs, language: N || null }), !0));
        } }),
        n.isEditable && /* @__PURE__ */ o("div", { className: "fp-code-actions", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩进", "data-fp-tooltip": "缩进 · Tab", "aria-keyshortcuts": "Tab", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            v() && Ln(n);
          }, children: /* @__PURE__ */ e(Fl, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "减少缩进", "data-fp-tooltip": "减少缩进 · Shift+Tab", "aria-keyshortcuts": "Shift+Tab", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            v() && Ln(n, !0);
          }, children: /* @__PURE__ */ e(Ol, { size: 16 }) }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "在代码块下方继续", "data-fp-tooltip": "在代码块下方继续 · Ctrl/⌘+Enter", "aria-keyshortcuts": "Control+Enter Meta+Enter", onMouseDown: (N) => N.preventDefault(), onClick: () => {
            v() && n.commands.exitCode();
          }, children: /* @__PURE__ */ e(Ja, { size: 16 }) })
        ] })
      ] }),
      /* @__PURE__ */ e("pre", { spellCheck: !1, autoCorrect: "off", autoCapitalize: "off", children: /* @__PURE__ */ e("code", { children: /* @__PURE__ */ e(ua, { style: { whiteSpace: "pre" } }) }) })
    ] })
  ] });
}
const Yc = hi.extend({
  priority: 110,
  addNodeView() {
    return Xt(Vc, qi);
  },
  addInputRules() {
    return [_c(this.type), ...this.parent?.() || []];
  },
  addProseMirrorPlugins() {
    return [...this.parent?.() || [], Wc(), Uc(this.editor)];
  },
  addKeyboardShortcuts() {
    const t = this.parent?.() || {};
    return {
      ...t,
      Tab: () => Ln(this.editor),
      "Shift-Tab": () => Ln(this.editor, !0),
      Space: () => $a(this.editor),
      Enter: (n) => this.editor.isEditable && !this.editor.view.composing && ($a(this.editor) || Hc(this.editor) || t.Enter?.(n) || Oc(this.editor)),
      Backspace: (n) => this.editor.isEditable && !this.editor.view.composing && (Kc(this.editor) || Rc(this.editor) || t.Backspace?.(n) || !1),
      "Mod-Enter": () => this.editor.isEditable && this.editor.isActive(this.name) && this.editor.commands.exitCode(),
      Escape: () => {
        const { editor: n } = this;
        if (!n.isEditable || n.state.selection.$from.parent.type.name !== this.name) return !1;
        const r = n.view.nodeDOM(n.state.selection.$from.before()), a = r instanceof Element ? r.querySelector(".fp-code-header button:not(:disabled)") : null;
        return a ? (a.focus({ preventScroll: !0 }), !0) : !1;
      }
    };
  }
}).configure({ lowlight: Oi }), Xc = [
  "definition",
  "theorem",
  "example",
  "insight",
  "pitfall",
  "note",
  "tip",
  "memory"
];
new Set(Xc);
const Gc = {
  animation: "learninganimation",
  map: "historymap",
  "cause-effect": "causeeffect",
  "learning-animation": "learninganimation",
  intuition: "insight",
  technique: "tip",
  comparison: "compare",
  summary: "keypoint",
  question: "note",
  task: "note"
};
function Jc(t) {
  return Gc[t] ?? t;
}
const Qc = {
  definition: { label: "定义", cls: "callout-definition" },
  theorem: { label: "定理", cls: "callout-theorem" },
  example: { label: "例", cls: "callout-example" },
  insight: { label: "直觉", cls: "callout-insight" },
  pitfall: { label: "易错点", cls: "callout-pitfall" },
  note: { label: "注", cls: "callout-note" },
  tip: { label: "提示", cls: "callout-tip" },
  memory: { label: "记忆卡", cls: "callout-memory" }
}, Tn = {
  note: "note",
  info: "note",
  todo: "note",
  question: "note",
  help: "note",
  faq: "note",
  tip: "tip",
  hint: "tip",
  important: "tip",
  success: "tip",
  check: "tip",
  done: "tip",
  warning: "pitfall",
  caution: "pitfall",
  attention: "pitfall",
  danger: "pitfall",
  error: "pitfall",
  failure: "pitfall",
  fail: "pitfall",
  bug: "pitfall",
  example: "example",
  abstract: "insight",
  summary: "insight",
  tldr: "insight",
  definition: "definition",
  theorem: "theorem",
  quote: null,
  cite: null
};
function Zc(t) {
  const n = t.toLowerCase();
  return n in Tn ? Tn[n] ?? "note" : "note";
}
function ed(t) {
  const n = t.toLowerCase();
  return n in Tn && Tn[n] === null;
}
function td({ label: t = "核心要点", children: n }) {
  return /* @__PURE__ */ o("aside", { className: "fp-keypoint", children: [
    /* @__PURE__ */ e("span", { className: "fp-keypoint-label", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-keypoint-body", children: n })
  ] });
}
function nd({
  term: t,
  children: n,
  defaultOpen: r = !1
}) {
  const [a, i] = k(r), l = ve();
  return /* @__PURE__ */ o("section", { className: "fp-concept", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-concept-head",
        "aria-expanded": a,
        "aria-controls": l,
        onClick: () => i((s) => !s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-concept-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(bt, { size: 16 }) }),
          /* @__PURE__ */ e("span", { className: "fp-concept-term", children: t }),
          /* @__PURE__ */ e("span", { className: "fp-concept-hint", children: a ? "点击收起" : "点击展开" }),
          /* @__PURE__ */ e(ze, { size: 16, className: "fp-concept-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: l, className: "fp-concept-body", inert: !a, "aria-hidden": !a, "data-open": a || void 0, children: /* @__PURE__ */ e("div", { className: "fp-concept-clip", children: /* @__PURE__ */ e("div", { className: "fp-concept-inner", children: n }) }) })
  ] });
}
function rd({ title: t, children: n }) {
  return /* @__PURE__ */ o("section", { className: "fp-compare", children: [
    t && /* @__PURE__ */ e("header", { className: "fp-compare-title", children: t }),
    /* @__PURE__ */ e("div", { className: "fp-compare-body", children: n })
  ] });
}
const ad = {
  cause: "因",
  effect: "影响",
  result: "结果"
};
function id(t) {
  return t.split(`
`).map((n) => n.trim().replace(/^[-*]\s*/, "")).filter(Boolean).map((n) => /^(因|原因)[：:]/.test(n) ? { kind: "cause", text: n.replace(/^(因|原因)[：:]/, "").trim() } : /^(果|结果)[：:]/.test(n) ? { kind: "result", text: n.replace(/^(果|结果)[：:]/, "").trim() } : /^(影响|后果)[：:]/.test(n) ? { kind: "effect", text: n.replace(/^(影响|后果)[：:]/, "").trim() } : { kind: void 0, text: n });
}
function ld({ items: t, text: n, children: r }) {
  const a = t ?? (n ? id(n) : []);
  return /* @__PURE__ */ o("div", { className: "fp-cause-effect", children: [
    a.map((i, l) => {
      const s = i.kind ?? (l === 0 ? "cause" : "effect");
      return /* @__PURE__ */ o("div", { className: "fp-cause-node", "data-kind": s, children: [
        /* @__PURE__ */ e("span", { className: "fp-cause-label", children: ad[s] }),
        /* @__PURE__ */ e("div", { className: "fp-cause-text", children: i.text }),
        l < a.length - 1 && /* @__PURE__ */ e(Qa, { size: 16, className: "fp-cause-arrow", "aria-hidden": "true" })
      ] }, l);
    }),
    r
  ] });
}
function od({
  label: t = "推导过程",
  children: n,
  defaultOpen: r = !1
}) {
  const [a, i] = k(r), l = ve();
  return /* @__PURE__ */ o("section", { className: "fp-derivation", "data-open": a || void 0, children: [
    /* @__PURE__ */ o("button", { type: "button", className: "fp-derivation-trigger", "aria-expanded": a, "aria-controls": l, onClick: () => i((s) => !s), children: [
      /* @__PURE__ */ e(ze, { size: 15, className: "fp-derivation-chevron" }),
      t
    ] }),
    /* @__PURE__ */ e(Re, { isOpen: a, children: /* @__PURE__ */ e("div", { id: l, className: "fp-derivation-body", children: n }) })
  ] });
}
function Nr({ src: t, alt: n, title: r, onError: a, ...i }) {
  const [l, s] = k(void 0), c = l === t || !t ? /* @__PURE__ */ o("span", { className: "fp-content-image-error", role: "img", "aria-label": n || "图片", children: [
    /* @__PURE__ */ e(Rl, { size: 22, "aria-hidden": "true" }),
    /* @__PURE__ */ e("span", { children: n || "图片加载失败" })
  ] }) : /* @__PURE__ */ e(
    "img",
    {
      src: t,
      alt: n || "",
      title: r,
      loading: "lazy",
      decoding: "async",
      ...i,
      onError: (u) => {
        s(t), a?.(u);
      }
    }
  );
  return r ? /* @__PURE__ */ o("figure", { className: "fp-content-image", children: [
    c,
    /* @__PURE__ */ e("figcaption", { children: r })
  ] }) : /* @__PURE__ */ e("span", { className: "fp-content-image-plain", children: c });
}
function Aa({
  title: t,
  date: n,
  children: r,
  defaultOpen: a = !1,
  fields: i = []
}) {
  const [l, s] = k(a);
  return /* @__PURE__ */ o("article", { className: "fp-event-card", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": l,
        onClick: () => s((c) => !c),
        children: [
          /* @__PURE__ */ e(
            ze,
            {
              size: 16,
              style: { transform: l ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: t }),
            n && /* @__PURE__ */ e("time", { children: n })
          ] })
        ]
      }
    ),
    !!i.length && /* @__PURE__ */ e("dl", { className: "fp-event-fields", children: i.map((c) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: c.label }),
      /* @__PURE__ */ e("dd", { children: c.value })
    ] }, c.label)) }),
    /* @__PURE__ */ e(Re, { isOpen: l, children: /* @__PURE__ */ e("div", { className: "fp-reading-body", children: r }) })
  ] });
}
function sd({
  src: t,
  alt: n,
  caption: r,
  credit: a,
  onOpen: i
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-reading-figure", children: [
    i ? /* @__PURE__ */ e("button", { type: "button", "aria-label": `查看${n}`, onClick: i, children: /* @__PURE__ */ e(Nr, { src: t, alt: n }) }) : /* @__PURE__ */ e(Nr, { src: t, alt: n }),
    (r || a) && /* @__PURE__ */ o("figcaption", { children: [
      r,
      a && /* @__PURE__ */ e("small", { children: a })
    ] })
  ] });
}
function Eh({
  question: t,
  answer: n,
  revealed: r,
  onReveal: a,
  onGrade: i
}) {
  return /* @__PURE__ */ o("article", { className: "fp-memory-card", children: [
    /* @__PURE__ */ e("div", { children: t }),
    /* @__PURE__ */ e(Re, { isOpen: r, children: /* @__PURE__ */ e("div", { className: "fp-memory-answer", children: n }) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r ? i && ["again", "hard", "good", "easy"].map((l, s) => /* @__PURE__ */ e("button", { type: "button", onClick: () => i(l), children: ["再学一次", "有些困难", "已经掌握", "很轻松"][s] }, l)) : /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "查看答案" }) })
  ] });
}
function $h({
  events: t,
  selectedId: n,
  onSelect: r
}) {
  return /* @__PURE__ */ e("section", { className: "fp-history-map", "aria-label": "历史脉络", children: /* @__PURE__ */ e("ol", { children: t.map((a) => /* @__PURE__ */ o("li", { "data-active": n === a.id || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": n === a.id,
        onClick: () => r(a.id),
        children: [
          /* @__PURE__ */ e("time", { children: a.date }),
          /* @__PURE__ */ e("strong", { children: a.title })
        ]
      }
    ),
    /* @__PURE__ */ e(Re, { isOpen: n === a.id, children: /* @__PURE__ */ o("div", { className: "fp-reading-body", children: [
      a.description,
      a.relatedIds?.map((i) => {
        const l = t.find((s) => s.id === i);
        return l ? /* @__PURE__ */ o("button", { type: "button", onClick: () => r(i), children: [
          "关联：",
          l.title
        ] }, i) : null;
      })
    ] }) })
  ] }, a.id)) }) });
}
function cd({
  title: t,
  children: n,
  sourceUrl: r,
  caption: a
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-learning-animation", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      r && /* @__PURE__ */ o("a", { href: r, download: !0, children: [
        "下载源文件",
        /* @__PURE__ */ e(Kt, { size: 13 })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { children: n }),
    a && /* @__PURE__ */ e("figcaption", { children: a })
  ] });
}
function zh({
  title: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-note-link", onClick: r, children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e(Kt, { size: 15 })
  ] });
}
function Ah({
  leftLabel: t,
  rightLabel: n,
  leftCount: r,
  rightCount: a,
  intersection: i,
  total: l
}) {
  return /* @__PURE__ */ e(
    "figure",
    {
      className: "fp-venn",
      "aria-label": `${t} ${r}，${n} ${a}，交集 ${i}${l === void 0 ? "" : `，总数 ${l}`}`,
      children: /* @__PURE__ */ o("svg", { viewBox: "0 0 360 210", role: "img", children: [
        /* @__PURE__ */ e("title", { children: "集合关系" }),
        /* @__PURE__ */ e(
          "rect",
          {
            x: "8",
            y: "8",
            width: "344",
            height: "194",
            rx: "8",
            fill: "none",
            stroke: "var(--fp-line)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "139",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: "221",
            cy: "106",
            r: "73",
            fill: "var(--fp-primary-soft)",
            fillOpacity: ".65",
            stroke: "var(--fp-action)"
          }
        ),
        /* @__PURE__ */ e("text", { x: "112", y: "70", textAnchor: "middle", children: t }),
        /* @__PURE__ */ e("text", { x: "249", y: "70", textAnchor: "middle", children: n }),
        /* @__PURE__ */ e("text", { x: "112", y: "120", textAnchor: "middle", children: Math.max(0, r - i) }),
        /* @__PURE__ */ e("text", { x: "180", y: "120", textAnchor: "middle", children: i }),
        /* @__PURE__ */ e("text", { x: "249", y: "120", textAnchor: "middle", children: Math.max(0, a - i) }),
        l !== void 0 && /* @__PURE__ */ e("text", { x: "325", y: "184", textAnchor: "end", children: Math.max(0, l - r - a + i) })
      ] })
    }
  );
}
function dd({
  children: t,
  mode: n = "cloze"
}) {
  const [r, a] = k([]), i = (l, s = "root") => Ll.map(l, (c, u) => {
    const d = `${s}.${u}`;
    if (!Va(c)) return c;
    const p = c;
    return n === "cloze" && p.type === "strong" || n !== "cloze" && p.type === "li" ? /* @__PURE__ */ e("span", { className: "fp-recall-item", children: /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-expanded": r.includes(d),
        onClick: () => a(
          (f) => f.includes(d) ? f.filter((m) => m !== d) : [...f, d]
        ),
        children: r.includes(d) ? p.props.children : "点击回忆"
      }
    ) }) : Ya(p, {}, i(p.props.children, d));
  });
  return /* @__PURE__ */ e("div", { className: "fp-recall-content", children: i(t) });
}
function ud({
  title: t = "历史地图",
  points: n,
  caption: r,
  onSelect: a
}) {
  return /* @__PURE__ */ o("figure", { className: "fp-location-map", children: [
    /* @__PURE__ */ e("figcaption", { children: t }),
    /* @__PURE__ */ e("div", { children: n.map((i, l) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        style: {
          left: `${Math.max(0, Math.min(100, i.x))}%`,
          top: `${Math.max(0, Math.min(100, i.y))}%`
        },
        onClick: () => a?.(i),
        children: [
          /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "●" }),
          i.name
        ]
      },
      l
    )) }),
    r && /* @__PURE__ */ e("p", { children: r })
  ] });
}
function pd({
  title: t = "时间轴",
  children: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-reading-timeline", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    n
  ] });
}
function hd({
  title: t,
  kind: n,
  collapsed: r,
  children: a
}) {
  const [i, l] = k(!r);
  return /* @__PURE__ */ o("aside", { className: "fp-reader-callout", "data-kind": n, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-reader-callout-toggle",
        "aria-expanded": i,
        onClick: () => l(!i),
        children: [
          /* @__PURE__ */ e(
            qt,
            {
              size: 16,
              style: { transform: i ? void 0 : "rotate(-90deg)" }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t })
        ]
      }
    ),
    /* @__PURE__ */ e(Re, { isOpen: i, children: a })
  ] });
}
function fd() {
  return (t) => {
    an(t, (n) => {
      const r = n;
      if (!["containerDirective", "leafDirective", "textDirective"].includes(
        r.type
      ))
        return;
      const a = { ...r.attributes }, i = (l) => (l || []).map(
        (s) => s.value || i(s.children)
      ).join(`
`);
      r.name === "canvas" && r.children && (a.plots = JSON.stringify(
        r.children.filter((l) => l.name === "plot").map((l) => l.attributes || {})
      )), r.data = {
        ...r.data,
        hName: "fp-directive",
        hProperties: {
          "data-name": r.name,
          "data-attributes": JSON.stringify({
            ...a,
            __source: i(r.children)
          })
        }
      };
    });
  };
}
const md = (t) => /^\s*(?:javascript|vbscript|data):/i.test(t) ? "" : t;
function vt({
  markdown: t,
  resolveResourceUrl: n,
  renderDirective: r,
  onOpenResource: a,
  onOpenLink: i,
  components: l,
  remarkPlugins: s,
  rehypePlugins: c
}) {
  const u = (h) => md(n?.(h) ?? h), d = ({
    name: h,
    attributes: f,
    children: m,
    source: b
  }) => {
    const g = Jc(h), y = f.title || f.label || Qc[g]?.label || "学习内容";
    if (r) {
      const w = r({
        name: g,
        attributes: f,
        children: m,
        source: b
      });
      if (w !== void 0) return w;
    }
    if (g === "interactive" && f.id)
      return /* @__PURE__ */ e(zi, { id: f.id });
    if (["plot", "functionplot"].includes(g))
      return /* @__PURE__ */ e(
        kr,
        {
          block: {
            kind: "plot",
            title: f.title || f.label,
            fn: f.fn || b || "x",
            attrs: Fi(f)
          }
        }
      );
    if (["canvas", "svgcanvas", "svg"].includes(g)) {
      let w = [];
      try {
        w = JSON.parse(f.plots || "[]");
      } catch {
      }
      return /* @__PURE__ */ e(
        kr,
        {
          block: w.length ? {
            kind: "multi-plot",
            title: f.title,
            attrs: Dc(f),
            plots: w
          } : Pc(f, b || "")
        }
      );
    }
    return ["concept", "conceptcard"].includes(g) ? /* @__PURE__ */ e(nd, { term: f.term || y, children: m }) : g === "derivation" ? /* @__PURE__ */ e(od, { label: y, children: m }) : g === "keypoint" ? /* @__PURE__ */ e(td, { label: y, children: m }) : ["compare", "comparetable"].includes(g) ? /* @__PURE__ */ e(rd, { title: y, children: m }) : g === "causeeffect" ? /* @__PURE__ */ e(ld, { children: m }) : ["event", "eventcard"].includes(g) ? /* @__PURE__ */ e(
      Aa,
      {
        title: y,
        date: f.date || f.year,
        fields: [
          ["location", "地点"],
          ["people", "人物"],
          ["result", "结果"],
          ["impact", "影响"]
        ].filter(([w]) => !!f[w]).map(([w, v]) => ({ label: v, value: f[w] })),
        children: m
      }
    ) : ["figure", "figuremedia"].includes(g) && f.src ? /* @__PURE__ */ e(
      sd,
      {
        src: u(f.src),
        alt: f.alt || y,
        caption: f.caption,
        credit: f.credit
      }
    ) : ["memory", "memorycard"].includes(g) ? /* @__PURE__ */ e(Aa, { title: y, children: /* @__PURE__ */ e(dd, { mode: f.mode || "checklist", children: m }) }) : g === "timeline" ? /* @__PURE__ */ e(
      pd,
      {
        title: f.period ? `时间轴 · ${f.period}` : y,
        children: m
      }
    ) : g === "historymap" ? /* @__PURE__ */ e(
      ud,
      {
        title: y,
        caption: f.caption,
        points: (f.points || "").split(",").filter(Boolean).map((w) => {
          const [v, N, x] = w.split(":");
          return {
            name: v,
            x: Number.isFinite(Number(N)) ? Number(N) : 50,
            y: Number.isFinite(Number(x)) ? Number(x) : 50
          };
        })
      }
    ) : ["learninganimation", "learning-animation"].includes(g) ? /* @__PURE__ */ e(
      cd,
      {
        title: y,
        sourceUrl: f.source ? u(f.source) : void 0,
        caption: f.caption,
        children: f.src ? /* @__PURE__ */ e(en, { src: u(f.src), title: y }) : m
      }
    ) : g === "mediaembed" && f.src ? /audio/i.test(f.type || "") ? /* @__PURE__ */ e(Mn, { src: u(f.src), title: y }) : /* @__PURE__ */ e(en, { src: u(f.src), title: y }) : g === "video" && f.src ? /* @__PURE__ */ e(en, { src: u(f.src), title: y }) : g === "audio" && f.src ? /* @__PURE__ */ e(Mn, { src: u(f.src), title: y }) : [
      "interactive",
      "plot",
      "functionplot",
      "canvas",
      "svgcanvas",
      "svg",
      "attachment",
      "noteattachment",
      "learning-animation"
    ].includes(g) && a ? /* @__PURE__ */ o("section", { className: "fp-reader-resource", children: [
      /* @__PURE__ */ e("strong", { children: y }),
      m,
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => a(f, g),
          children: "打开内容"
        }
      )
    ] }) : /* @__PURE__ */ e(
      hd,
      {
        title: y,
        kind: g === "callout" ? f.kind || "note" : g,
        collapsed: f.collapsed === "true",
        children: m
      }
    );
  };
  return /* @__PURE__ */ e("article", { className: "fp-markdown-content", children: /* @__PURE__ */ e(
    ci,
    {
      remarkPlugins: s || [
        Ho,
        di,
        Uo,
        Ds,
        fd
      ],
      rehypePlugins: c || [
        _o,
        Ys,
        [Wo, Vs],
        Ts,
        [
          ui,
          { throwOnError: !1, strict: !1, macros: $i }
        ],
        Xs
      ],
      components: { ...{
        "fp-directive": ({
          node: h,
          children: f
        }) => {
          const m = h?.properties || {};
          let b = {};
          try {
            b = JSON.parse(
              String(
                m["data-attributes"] || m.dataAttributes || "{}"
              )
            );
          } catch {
          }
          const g = b.__source;
          return delete b.__source, d({
            name: String(m["data-name"] || m.dataName || "note"),
            attributes: b,
            children: f,
            source: g
          });
        },
        img: ({ src: h, alt: f }) => u(h || "") ? /* @__PURE__ */ e(Nr, { src: u(h || ""), alt: f || "" }) : /* @__PURE__ */ e("span", { children: f || "图片暂时无法显示。" }),
        a: ({ href: h, children: f }) => /* @__PURE__ */ e(
          "a",
          {
            href: h,
            onClick: (m) => {
              h && i && !m.ctrlKey && !m.metaKey && !m.shiftKey && (m.preventDefault(), i(h));
            },
            children: f
          }
        ),
        pre: ({ children: h }) => /* @__PURE__ */ e("div", { className: "fp-reader-code", children: h }),
        code: ({
          className: h,
          children: f
        }) => h?.includes("language-mermaid") ? /* @__PURE__ */ e(_i, { code: String(f).trimEnd() }) : /* @__PURE__ */ e("code", { className: h, children: f })
      }, ...l },
      children: Ws(t)
    }
  ) });
}
function xr(t, n) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const { state: r } = t, a = r.selection.$from.index(0), i = [];
  r.doc.forEach((p, h) => i.push(h));
  const l = a + (n === "up" ? -1 : 1);
  if (l < 0 || l >= r.doc.childCount) return !1;
  const s = r.doc.child(a), c = i[a], u = r.doc.child(l), d = n === "up" ? i[l] : i[l] + u.nodeSize - s.nodeSize;
  return t.commands.command(({ tr: p }) => (p.delete(c, c + s.nodeSize), p.insert(d, s), p.setSelection(
    Sn.near(
      p.doc.resolve(Math.min(p.doc.content.size, d + 1))
    )
  ), !0));
}
function bd(t) {
  if (!t.isEditable || t.isDestroyed) return !1;
  const n = t.state.selection.$from.index(0);
  let r = 0;
  for (let a = 0; a < n; a++)
    r += t.state.doc.child(a).nodeSize;
  return t.commands.deleteRange({
    from: r,
    to: r + t.state.doc.child(n).nodeSize
  });
}
const gd = jr.create({
  name: "blockDragHandles",
  addProseMirrorPlugins() {
    const t = this.editor;
    return [
      new dn({
        props: {
          decorations(n) {
            if (!t.isEditable) return br.empty;
            const r = [];
            return n.doc.forEach((a, i) => {
              Zt.isSelectable(a) && r.push(
                bi.widget(
                  i,
                  (l, s) => {
                    const c = document.createElement("span");
                    c.className = "fp-block-handle", c.contentEditable = "false";
                    const u = document.createElement("button");
                    return u.type = "button", u.draggable = !0, u.tabIndex = 0, u.title = "拖动段落", u.setAttribute("aria-label", "拖动段落"), u.textContent = "⠿", u.addEventListener("dragstart", (d) => {
                      const p = s();
                      if (p === void 0 || !d.dataTransfer) return;
                      d.stopPropagation();
                      const h = Zt.create(
                        l.state.doc,
                        p
                      );
                      l.dispatch(l.state.tr.setSelection(h));
                      const f = h.content(), m = document.createElement("div");
                      m.append(
                        Jo.fromSchema(
                          l.state.schema
                        ).serializeFragment(f.content)
                      ), d.dataTransfer.clearData(), d.dataTransfer.setData(
                        "text/html",
                        m.innerHTML
                      ), d.dataTransfer.setData(
                        "text/plain",
                        h.node.textContent
                      ), d.dataTransfer.effectAllowed = "copyMove", l.dragging = {
                        slice: f,
                        move: !d.ctrlKey && !d.altKey
                      };
                    }), u.addEventListener("keydown", (d) => {
                      if (!d.altKey || !["ArrowUp", "ArrowDown"].includes(d.key))
                        return;
                      const p = s();
                      p !== void 0 && (d.preventDefault(), d.stopPropagation(), t.commands.setTextSelection(
                        Math.min(p + 1, l.state.doc.content.size)
                      ), xr(
                        t,
                        d.key === "ArrowUp" ? "up" : "down"
                      ));
                    }), u.addEventListener("mousedown", (d) => {
                      const p = s();
                      p === void 0 || d.button !== 0 || (d.stopPropagation(), l.dispatch(
                        l.state.tr.setSelection(
                          Zt.create(l.state.doc, p)
                        )
                      ), l.focus());
                    }), c.append(u), c;
                  },
                  { side: -1, key: `block-${i}` }
                )
              );
            }), br.create(n.doc, r);
          }
        }
      })
    ];
  }
});
function Wi(t) {
  return t.chain().focus().insertContent({ type: "codeBlock", attrs: { language: "mermaid" }, content: [{ type: "text", text: `flowchart LR
  A[开始] --> B[理解] --> C[应用]` }] }).run();
}
function sn(...t) {
  const n = t.join(" "), r = ts(n, { toneType: "none", type: "array" });
  return `${n} ${r.join("")} ${r.map((a) => a[0]).join("")}`.toLowerCase();
}
const vd = [
  ["text", "文本", "普通段落", "paragraph wenben wb"],
  ["h1", "一级标题", "大标题", "heading title yijibiaoti yjbt"],
  ["h2", "二级标题", "章节标题", "heading erjibiaoti ejbt"],
  ["h3", "三级标题", "小节标题", "heading sanjibiaoti sjbt"],
  ["h4", "四级标题", "细分内容", "heading sijibiaoti sjbt"],
  ["h5", "五级标题", "细分内容", "heading wujibiaoti wjbt"],
  ["h6", "六级标题", "细分内容", "heading liujibiaoti ljbt"],
  ["bullet", "无序列表", "项目列表", "list unordered wuxuliebiao wxlb"],
  ["ordered", "有序列表", "编号列表", "list numbered youxuliebiao yxlb"],
  ["quote", "引用", "引用段落", "blockquote yinyong yy"],
  ["code", "代码块", "代码内容", "codeblock daima dm dmk"],
  ["divider", "分隔线", "划分内容", "horizontal rule fengexian fgx"],
  ["table", "表格", "3 × 3", "biaoge bg"],
  ["inlineMath", "行内公式", "在段落中输入公式", "formula equation gongshi gs latex hangneigongshi hngs"],
  ["math", "独立公式", "独立成行的公式", "blockmath equation duligongshi dlgs"],
  ["card", "卡片", "说明与重点", "callout kapian kp"],
  ["mermaid", "Mermaid 图表", "流程图与时序图", "diagram flowchart liuchengtu lct tuxing tx"],
  ["interactive", "交互实验", "插入可探索的实验", "experiment lab jiaohushiyan jhsy hudong hd"],
  ["attachment", "附件", "图片、视频或 PDF", "file image pdf audio upload 图片 音频 文件 上传 fujian fj tupian tp"],
  ["video", "视频", "边看边记", "movie shipin sp"]
], yd = { javascript: "js node nodejs", typescript: "ts", python: "py", bash: "sh shell terminal 终端", cpp: "c++ cc cxx", csharp: "c# cs", rust: "rs", yaml: "yml", markdown: "md" }, Vi = [
  ["definition", "定义", "明确概念", "概念定义 dy"],
  ["theorem", "定理", "记录条件与结论", "定律 dl"],
  ["example", "例题", "题目与解答", "例子 示例 lt"],
  ["tip", "技巧", "记录解题方法", "提示 jq"],
  ["pitfall", "易错点", "记录常见错误", "warning 注意 ycd"],
  ["memory", "记忆卡", "整理记忆要点", "记忆 flashcard jyk"],
  ["derivation", "推导", "分步说明推导", "推导过程 td"],
  ["compare", "对比", "比较概念与方法", "比较 comparison db"],
  ["keypoint", "核心要点", "突出重要内容", "重点 key hxyd"],
  ["concept", "概念", "整理概念边界", "术语 gn"],
  ["insight", "直觉", "解释直观理解", "理解 intuition zj"],
  ["note", "说明", "补充说明", "备注 callout sm"],
  ["cause-effect", "因果", "梳理原因与结果", "因果关系 cause effect yg"]
].map(([t, n, r, a]) => ["card:" + t, n + "卡片", r, t + " " + a]), Yi = [
  ...vd,
  ...Xn.filter((t) => t.value !== "mermaid").map((t) => [
    "code:" + t.value,
    t.label + " 代码块",
    "输入 " + t.label + " 代码",
    t.value + " " + (yd[t.value] || "") + " code 代码"
  ]),
  ["code:plaintext", "纯文本代码块", "按原样记录文本", "text txt plaintext 纯文本"],
  ...Vi
], wd = new Map(Yi.map((t) => [t[0], sn(...t)]));
function kd(t) {
  const n = t.trim().replace(/^\//, "").toLowerCase(), r = Cr(n);
  if (r) return [[`table:${r.rows}x${r.cols}`, `${r.rows} × ${r.cols} 表格`, `${r.rows} 行 × ${r.cols} 列`, n]];
  const a = n.split(/\s+/), i = Yi.filter((d) => a.every((p) => wd.get(d[0]).includes(p))), l = (d) => [d[0], d[0].split(":").at(-1), ...d[3].toLowerCase().split(/\s+/)].includes(n), s = n ? i.filter(l) : [], c = s.length ? s : i, u = Mi();
  return c.sort((d, p) => Number(l(p)) - Number(l(d)) || (u[p[0]] || 0) - (u[d[0]] || 0));
}
function Ia(t) {
  return t === "code:plaintext" ? null : Xn.find((n) => t === "code:" + n.value)?.value;
}
function bn(t) {
  return Vi.find((n) => n[0] === t)?.[0].slice(5);
}
function Cr(t) {
  const n = t.trim().toLowerCase().replace(/^\//, "").match(/^(?:bg|table:?)([1-9]\d?)[x*×]([1-9]\d?)$/);
  if (!n) return;
  const r = Number(n[1]), a = Number(n[2]);
  return r <= 20 && a <= 20 ? { rows: r, cols: a } : void 0;
}
function yt({
  children: t,
  items: n,
  label: r = "快捷操作",
  disabled: a,
  tabIndex: i = 0,
  onOpen: l
}) {
  const s = B(null), c = B(null), u = B(null), [d, p] = k(null), [h, f] = k([]), m = ve(), b = Ut(s, !!d), g = (v = !0) => {
    p(null), f([]), v && u.current?.focus({ preventScroll: !0 });
  }, y = (v, N) => {
    u.current = document.activeElement, f([]), p({ x: v, y: N });
  };
  Ce(() => {
    if (!d || !c.current) return;
    const v = c.current.getBoundingClientRect();
    c.current.style.left = `${Math.max(8, Math.min(d.x, window.innerWidth - v.width - 8))}px`, c.current.style.top = `${Math.max(8, Math.min(d.y, window.innerHeight - v.height - 8))}px`, c.current.querySelector('[role="menuitem"]:not(:disabled)')?.focus({ preventScroll: !0 });
  }, [d, h]), Y(() => {
    if (!d) return;
    const v = (C) => {
      c.current?.contains(C.target) || g(!1);
    }, N = (C) => {
      C.key === "Escape" && (C.preventDefault(), g());
    }, x = () => g(!1);
    return document.addEventListener("pointerdown", v, !0), document.addEventListener("keydown", N, !0), window.addEventListener("resize", x), window.addEventListener("blur", x), window.addEventListener("scroll", v, !0), () => {
      document.removeEventListener("pointerdown", v, !0), document.removeEventListener("keydown", N, !0), window.removeEventListener("resize", x), window.removeEventListener("blur", x), window.removeEventListener("scroll", v, !0);
    };
  }, [d]);
  let w = typeof n == "function" ? n() : n;
  for (const v of h)
    w = w.find((N) => N.id === v)?.children || [];
  return /* @__PURE__ */ o(
    "div",
    {
      ref: s,
      className: "fp-context-host",
      tabIndex: i,
      onContextMenu: (v) => {
        a || l?.(v) === !1 || (v.preventDefault(), v.stopPropagation(), y(v.clientX, v.clientY));
      },
      onKeyDown: (v) => {
        if (!a && (v.key === "ContextMenu" || v.shiftKey && v.key === "F10")) {
          if (l?.(v) === !1) return;
          v.preventDefault(), v.stopPropagation();
          const N = s.current.getBoundingClientRect();
          y(N.left + 16, N.top + 16);
        }
      },
      children: [
        t,
        d && De(
          /* @__PURE__ */ o(
            "div",
            {
              ref: c,
              "data-fp-overlay": "",
              id: m,
              role: "menu",
              "aria-label": r,
              className: "fp-popup-panel fp-popup-menu fp-context-menu",
              style: {
                ...b,
                position: "fixed",
                left: d.x,
                top: d.y,
                maxHeight: "calc(100vh - 16px)",
                overflowY: "auto"
              },
              onContextMenu: (v) => v.preventDefault(),
              onKeyDown: (v) => {
                const N = Array.from(
                  c.current?.querySelectorAll(
                    '[role="menuitem"]:not(:disabled)'
                  ) || []
                ), x = N.indexOf(
                  document.activeElement
                ), C = v.key === "ArrowDown" ? (x + 1) % N.length : v.key === "ArrowUp" ? (x - 1 + N.length) % N.length : v.key === "Home" ? 0 : v.key === "End" ? N.length - 1 : -1;
                if (C >= 0 && (v.preventDefault(), N[C]?.focus()), v.key === "ArrowLeft" && h.length && (v.preventDefault(), f(h.slice(0, -1))), v.key === "ArrowRight") {
                  const I = document.activeElement?.dataset.item, L = w.find((K) => K.id === I);
                  L?.children && (v.preventDefault(), f([...h, L.id]));
                }
                v.key === "Tab" && g(!1);
              },
              children: [
                h.length > 0 && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    onClick: () => f(h.slice(0, -1)),
                    children: "‹ 返回"
                  }
                ),
                w.map((v) => /* @__PURE__ */ o("div", { children: [
                  v.separator && /* @__PURE__ */ e("div", { role: "separator", className: "fp-context-separator" }),
                  /* @__PURE__ */ o(
                    "button",
                    {
                      type: "button",
                      role: "menuitem",
                      "data-item": v.id,
                      disabled: v.disabled,
                      "aria-haspopup": v.children ? "menu" : void 0,
                      className: v.danger ? "fp-error-text" : "",
                      onClick: () => {
                        v.children ? f([...h, v.id]) : (g(), v.onSelect?.());
                      },
                      children: [
                        /* @__PURE__ */ e("span", { className: "fp-context-icon", children: v.checked ? /* @__PURE__ */ e(Pe, { size: 15 }) : v.icon }),
                        /* @__PURE__ */ e("span", { children: v.label }),
                        v.children ? /* @__PURE__ */ e(ze, { size: 14 }) : v.shortcut ? /* @__PURE__ */ e("kbd", { children: v.shortcut }) : null
                      ]
                    }
                  )
                ] }, v.id))
              ]
            }
          ),
          s.current?.closest("dialog") || document.body
        )
      ]
    }
  );
}
function Xi({
  editor: t,
  children: n,
  getExtraItems: r
}) {
  const [a, i] = k(""), l = B(""), s = B(null), c = async (d) => {
    if (!t) return;
    const { from: p, to: h } = t.state.selection, f = t.state.doc;
    try {
      if (d === "paste") {
        const m = await navigator.clipboard.readText();
        if (!m) return;
        !t.isDestroyed && t.state.doc === f && t.chain().focus().insertContentAt({ from: p, to: h }, { type: "text", text: m }).run();
      } else {
        const { dom: m, text: b } = t.view.serializeForClipboard(t.state.selection.content());
        navigator.clipboard.write && typeof ClipboardItem < "u" ? await navigator.clipboard.write([new ClipboardItem({
          "text/html": new Blob([m.innerHTML], { type: "text/html" }),
          "text/plain": new Blob([b], { type: "text/plain" })
        })]) : await navigator.clipboard.writeText(b), d === "cut" && !t.isDestroyed && t.state.doc === f && t.chain().focus().deleteRange({ from: p, to: h }).run();
      }
      i(
        d === "paste" ? "已粘贴" : d === "cut" ? "已剪切" : "已复制"
      );
    } catch {
      i("暂时无法访问剪贴板，请使用键盘快捷键。");
    }
  };
  return /* @__PURE__ */ o(
    yt,
    {
      label: "笔记快捷操作",
      tabIndex: -1,
      disabled: !t,
      items: () => {
        if (!t) return [];
        const d = !t.isEditable, p = t.state.selection.empty;
        return [
          ...s.current ? r?.(s.current) ?? [] : [],
          {
            id: "cut",
            label: "剪切",
            shortcut: "Ctrl+X",
            disabled: d || p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("cut");
            }
          },
          {
            id: "copy",
            label: "复制",
            shortcut: "Ctrl+C",
            disabled: p || !navigator.clipboard?.writeText,
            onSelect: () => {
              c("copy");
            }
          },
          {
            id: "paste",
            label: "粘贴为纯文本",
            shortcut: "Ctrl+Shift+V",
            disabled: d || !navigator.clipboard?.readText,
            onSelect: () => {
              c("paste");
            }
          },
          {
            id: "all",
            label: "全选",
            shortcut: "Ctrl+A",
            onSelect: () => t.chain().focus().selectAll().run()
          },
          ...l.current ? [
            {
              id: "copy-link",
              label: "复制链接地址",
              disabled: !navigator.clipboard?.writeText,
              onSelect: () => {
                navigator.clipboard.writeText(l.current).then(
                  () => i("链接已复制"),
                  () => i("请使用键盘快捷键复制链接。")
                );
              }
            },
            {
              id: "unlink",
              label: "取消链接",
              disabled: d,
              onSelect: () => t.chain().focus().extendMarkRange("link").unsetLink().run()
            }
          ] : [],
          {
            id: "format",
            label: "文字格式",
            separator: !0,
            disabled: d,
            children: [
              {
                id: "bold",
                label: "粗体",
                checked: t.isActive("bold"),
                onSelect: () => t.chain().focus().toggleBold().run()
              },
              {
                id: "italic",
                label: "斜体",
                checked: t.isActive("italic"),
                onSelect: () => t.chain().focus().toggleItalic().run()
              },
              {
                id: "clear",
                label: "清除格式",
                onSelect: () => t.chain().focus().unsetAllMarks().run()
              }
            ]
          },
          {
            id: "block",
            label: "段落操作",
            disabled: d,
            children: [
              {
                id: "move-up",
                label: "向上移动",
                disabled: t.state.selection.$from.index(0) === 0,
                onSelect: () => xr(t, "up")
              },
              {
                id: "move-down",
                label: "向下移动",
                disabled: t.state.selection.$from.index(0) >= t.state.doc.childCount - 1,
                onSelect: () => xr(t, "down")
              },
              {
                id: "delete-block",
                label: "删除这一块",
                danger: !0,
                onSelect: () => bd(t)
              }
            ]
          },
          ...t.isActive("table") ? [
            {
              id: "table",
              label: "表格操作",
              disabled: d,
              children: [
                {
                  id: "row-before",
                  label: "向上插入行",
                  onSelect: () => t.chain().focus().addRowBefore().run()
                },
                {
                  id: "row-after",
                  label: "向下插入行",
                  onSelect: () => t.chain().focus().addRowAfter().run()
                },
                {
                  id: "column-before",
                  label: "向左插入列",
                  onSelect: () => t.chain().focus().addColumnBefore().run()
                },
                {
                  id: "column-after",
                  label: "向右插入列",
                  onSelect: () => t.chain().focus().addColumnAfter().run()
                },
                {
                  id: "merge",
                  label: "合并单元格",
                  disabled: !t.can().mergeCells(),
                  onSelect: () => t.chain().focus().mergeCells().run()
                },
                {
                  id: "split",
                  label: "拆分单元格",
                  disabled: !t.can().splitCell(),
                  onSelect: () => t.chain().focus().splitCell().run()
                },
                {
                  id: "delete-row",
                  label: "删除当前行",
                  danger: !0,
                  separator: !0,
                  onSelect: () => t.chain().focus().deleteRow().run()
                },
                {
                  id: "delete-column",
                  label: "删除当前列",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteColumn().run()
                },
                {
                  id: "delete-table",
                  label: "删除表格",
                  danger: !0,
                  onSelect: () => t.chain().focus().deleteTable().run()
                }
              ]
            }
          ] : [],
          {
            id: "undo",
            label: "撤销",
            separator: !0,
            shortcut: "Ctrl+Z",
            disabled: d || !t.can().undo(),
            onSelect: () => t.chain().focus().undo().run()
          },
          {
            id: "redo",
            label: "重做",
            shortcut: "Ctrl+Shift+Z",
            disabled: d || !t.can().redo(),
            onSelect: () => t.chain().focus().redo().run()
          }
        ];
      },
      onOpen: (d) => {
        if (!t) return !1;
        const p = d.target;
        if (p.closest("input,textarea,math-field,button")) return !1;
        if (s.current = p, l.current = p.closest("a")?.getAttribute("href") || "", "clientX" in d) {
          const h = t.view.posAtCoords({
            left: d.clientX,
            top: d.clientY
          }), f = p.closest("[data-note-object], .fp-mermaid-node");
          if (f && t.view.dom.contains(f) && t.isEditable) {
            const m = t.view.posAtDOM(f, 0), b = t.state.doc.nodeAt(m), g = b && (b.isAtom || b.type.name === "codeBlock") ? m : Math.max(0, m - 1);
            t.state.doc.nodeAt(g) && t.commands.setNodeSelection(g);
          } else h && (t.state.selection.empty || h.pos < t.state.selection.from || h.pos > t.state.selection.to) && t.commands.setTextSelection(h.pos);
        }
        i("");
      },
      children: [
        n,
        a && /* @__PURE__ */ e("span", { className: "fp-visually-hidden", role: "status", children: a })
      ]
    }
  );
}
const Dn = cn(!1), Nd = '[data-fp-tooltip],button,[role="button"],a[title],a[aria-label],[tabindex][title]';
function xd({ children: t }) {
  return Bt(Dn) ? /* @__PURE__ */ e(Q, { children: t }) : /* @__PURE__ */ o(Dn.Provider, { value: !0, children: [
    /* @__PURE__ */ e(Gi, {}),
    t
  ] });
}
function Gi({ owner: t }) {
  const [n, r] = k(null), a = B(null), i = B(null), l = ve(), s = Ut(a, !!n, n?.node), [c, u] = k({ left: 8, top: 8 });
  return Y(() => {
    let d = !1, p = !1;
    const h = () => r(null), f = (y) => {
      if ("pointerType" in y && (d = y.pointerType === "touch"), y.type === "focusin" && p || d) return;
      const w = y.target instanceof Element ? y.target : null, v = w?.closest(Nd);
      if (t && v?.dataset.fpTooltipOwner !== t) {
        h();
        return;
      }
      if (!v || v.closest('[inert],[aria-hidden="true"]') || v.dataset.fpTooltip === "off" || v.matches('[role="menuitem"],[role="option"],[aria-expanded="true"]')) {
        h();
        return;
      }
      for (let C = w; C; C = C.parentElement) {
        const I = C.getAttribute("title");
        I && (C.dataset.fpTooltip ||= I, C.removeAttribute("title"));
      }
      const N = v.dataset.fpTooltip || v.getAttribute("aria-label") || v.textContent?.trim();
      if (!N) {
        h();
        return;
      }
      a.current = v;
      const x = v.dataset.fpTooltipSide || (v.closest('[data-variant="rail"]') ? "right" : "bottom");
      r((C) => C?.node === v && C.text === N ? C : { node: v, text: N, side: x });
    }, m = (y) => {
      const w = y.relatedTarget;
      (!(w instanceof Node) || !a.current?.contains(w)) && h();
    }, b = (y) => {
      d = !1, p = !1, y.key === "Escape" && h();
    }, g = (y) => {
      d = y.pointerType === "touch", p = !0, h();
    };
    return document.addEventListener("pointerover", f, !0), document.addEventListener("pointerout", m, !0), document.addEventListener("focusin", f, !0), document.addEventListener("focusout", h, !0), document.addEventListener("pointerdown", g, !0), document.addEventListener("keydown", b, !0), window.addEventListener("blur", h), window.addEventListener("scroll", h, !0), window.addEventListener("resize", h), () => {
      document.removeEventListener("pointerover", f, !0), document.removeEventListener("pointerout", m, !0), document.removeEventListener("focusin", f, !0), document.removeEventListener("focusout", h, !0), document.removeEventListener("pointerdown", g, !0), document.removeEventListener("keydown", b, !0), window.removeEventListener("blur", h), window.removeEventListener("scroll", h, !0), window.removeEventListener("resize", h);
    };
  }, [t]), Ce(() => {
    if (!n || !i.current) return;
    const d = n.node, p = d.getAttribute("aria-describedby");
    d.setAttribute("aria-describedby", [p, l].filter(Boolean).join(" "));
    const h = d.getBoundingClientRect(), f = i.current.getBoundingClientRect(), m = 8, b = 8;
    let g = n.side;
    g === "bottom" && h.bottom + m + f.height > innerHeight - b && (g = "top"), g === "top" && h.top - m - f.height < b && (g = "bottom"), g === "right" && h.right + m + f.width > innerWidth - b && (g = "left"), g === "left" && h.left - m - f.width < b && (g = "right");
    const y = g === "left" ? h.left - m - f.width : g === "right" ? h.right + m : h.left + (h.width - f.width) / 2, w = g === "top" ? h.top - m - f.height : g === "bottom" ? h.bottom + m : h.top + (h.height - f.height) / 2;
    u({ left: Math.max(b, Math.min(y, innerWidth - f.width - b)), top: Math.max(b, Math.min(w, innerHeight - f.height - b)) });
    const v = new MutationObserver(() => {
      (!d.isConnected || d.closest('[inert],[aria-hidden="true"]') || d.getAttribute("aria-expanded") === "true") && r(null);
    });
    return v.observe(document.body, { childList: !0, subtree: !0, attributes: !0, attributeFilter: ["aria-expanded", "inert", "aria-hidden"] }), () => {
      v.disconnect(), p ? d.setAttribute("aria-describedby", p) : d.removeAttribute("aria-describedby");
    };
  }, [n, l]), n && typeof document < "u" ? De(/* @__PURE__ */ e("div", { ref: i, id: l, role: "tooltip", className: "fp-tooltip-bubble", style: { ...s, color: "var(--fp-surface)", ...c }, children: n.text }), document.body) : null;
}
function Cd({ text: t, children: n, side: r = "bottom" }) {
  const a = Bt(Dn), i = ve(), l = { "data-fp-tooltip": t, "data-fp-tooltip-side": r, "data-fp-tooltip-owner": a ? void 0 : i, title: void 0 }, s = Va(n) ? Ya(n, l) : /* @__PURE__ */ e("span", { ...l, children: n });
  return a ? s : /* @__PURE__ */ o(Dn.Provider, { value: !0, children: [
    /* @__PURE__ */ e(Gi, { owner: i }),
    s
  ] });
}
function Sd({ tip: t, children: n }) {
  return /* @__PURE__ */ e(Cd, { text: t, children: n });
}
const yn = ["bold", "italic", "strike", "code", "underline"];
function Md(t) {
  const { from: n, to: r, empty: a } = t.state.selection;
  if (a || n >= r)
    return yn.filter((l) => t.isActive(l));
  const i = /* @__PURE__ */ new Set();
  return t.state.doc.nodesBetween(n, r, (l) => {
    if (l.isText)
      for (const s of l.marks)
        yn.includes(s.type.name) && i.add(s.type.name);
  }), yn.filter((l) => i.has(l));
}
function Ed(t, n, r, a) {
  if (r >= a) return !1;
  const i = t.chain().focus().setTextSelection({ from: r, to: a });
  for (const l of yn)
    n.includes(l) ? i.setMark(l) : i.unsetMark(l);
  return i.run();
}
function $d(t) {
  return t === null ? "once" : t === "once" ? "locked" : null;
}
function zd({ language: t, onChange: n, className: r }) {
  return /* @__PURE__ */ e(ke, { label: "代码块语言", className: r, value: t ?? "", onChange: (i) => n(i || null), options: [{ value: "", label: "无语言" }, ...Xn] });
}
const Ad = [
  { label: "墨色", value: "#1f2937" },
  { label: "白", value: "#ffffff" },
  { label: "红", value: "#dc2626" },
  { label: "橙", value: "#ea580c" },
  { label: "黄", value: "#ca8a04" },
  { label: "绿", value: "#16a34a" },
  { label: "青", value: "#0891b2" },
  { label: "蓝", value: "#2563eb" },
  { label: "紫", value: "#7c3aed" },
  { label: "粉", value: "#db2777" }
], Id = [
  "#000000",
  "#7f1d1d",
  "#9a3412",
  "#854d0e",
  "#166534",
  "#0e7490",
  "#1d4ed8",
  "#6d28d9",
  "#9d174d",
  "#525252"
], Ld = [
  "#fef08a",
  "#bbf7d0",
  "#a5f3fc",
  "#ddd6fe",
  "#fecdd3",
  "#fde68a",
  "#86efac",
  "#67e8f9",
  "#c4b5fd",
  "#fda4af"
], Td = [
  "rgba(17,24,39,0.55)",
  "rgba(220,38,38,0.45)",
  "rgba(234,88,12,0.45)",
  "rgba(22,163,74,0.45)",
  "rgba(37,99,235,0.45)",
  "rgba(124,58,237,0.45)"
];
function Sr() {
  try {
    const t = localStorage.getItem("fp-toolbar-recent-colors"), n = t ? JSON.parse(t) : null;
    return Array.isArray(n) ? n.filter((r) => typeof r == "string").slice(0, 8) : [];
  } catch {
    return [];
  }
}
function Dd(t) {
  const n = [t, ...Sr().filter((r) => r !== t)].slice(0, 8);
  try {
    localStorage.setItem("fp-toolbar-recent-colors", JSON.stringify(n));
  } catch {
  }
}
function Pd({
  mode: t,
  current: n,
  onApply: r,
  onClose: a
}) {
  const [i, l] = k([]), [s, c] = k(n?.startsWith("#") ? n : "#FD8B07"), u = B(null);
  Y(() => l(Sr()), []), Y(() => {
    const h = (m) => {
      u.current?.contains(m.target) || a();
    }, f = (m) => m.key === "Escape" && a();
    return window.addEventListener("pointerdown", h), window.addEventListener("keydown", f), () => {
      window.removeEventListener("pointerdown", h), window.removeEventListener("keydown", f);
    };
  }, [a]);
  const d = (h) => {
    h && Dd(h), l(Sr()), r(h), a();
  }, p = (h) => h.map((f) => {
    const m = typeof f == "string" ? f : f.value, b = typeof f == "string" ? m : f.label;
    return /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        title: b,
        "aria-label": b,
        className: "toolbar-color-swatch",
        style: { background: m },
        "data-active": n === m || void 0,
        onClick: () => d(m)
      },
      m
    );
  });
  return /* @__PURE__ */ o("div", { ref: u, className: "toolbar-color-picker", role: "listbox", "aria-label": t === "text" ? "字体颜色" : "荧光笔颜色", children: [
    i.length > 0 && /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "最近使用" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(i) })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: t === "text" ? "主题色" : "荧光笔" }),
      /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(t === "text" ? Ad : Ld) })
    ] }),
    t === "text" && /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "标准色" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(Id) })
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("h4", { children: "半透明" }),
        /* @__PURE__ */ e("div", { className: "toolbar-color-grid", children: p(Td) })
      ] })
    ] }),
    /* @__PURE__ */ o("section", { children: [
      /* @__PURE__ */ e("h4", { children: "自定义" }),
      /* @__PURE__ */ o("div", { className: "toolbar-color-custom", children: [
        /* @__PURE__ */ e(
          "input",
          {
            type: "text",
            "aria-label": "自定义颜色",
            value: s,
            placeholder: "#FD8B07",
            onChange: (h) => c(h.target.value)
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: !/^#[0-9a-f]{6}$/i.test(s), onClick: () => d(s), children: "应用" }),
        /* @__PURE__ */ e("button", { type: "button", onClick: () => d(t === "text" ? null : "#fef08a"), children: t === "text" ? "默认颜色" : "默认高亮" })
      ] })
    ] })
  ] });
}
function Fd(t, n, r = (i) => i.width ?? 0, a = 4) {
  const i = new Set(t.map((s) => s.id)), l = () => t.reduce((s, c) => s + (i.has(c.id) ? r(c) : 0), 0) + Math.max(0, i.size - 1) * a;
  for (const s of [...t].sort((c, u) => c.priority - u.priority || t.indexOf(u) - t.indexOf(c))) {
    if (l() <= Math.max(0, n)) break;
    i.delete(s.id);
  }
  return { visible: t.filter((s) => i.has(s.id)), overflow: t.filter((s) => !i.has(s.id)) };
}
function Od(t, n, r, a = 40, i = 4) {
  let l = null;
  const s = (p, h, f, m) => {
    if (h > n) return;
    if (p === t.length) {
      (!l || f > l.score) && (l = { modes: { ...m }, score: f });
      return;
    }
    const b = t[p], g = b.actions?.length ?? 1;
    for (const y of ["full", "icons", "group"]) {
      const w = y === "group" ? 0 : g, v = w * 1e5 + w * b.priority * 100 + (y === "full" ? g * b.priority : 0);
      m[b.id] = y, s(p + 1, h + r(b, y) + (p ? i : 0), f + v, m);
    }
  };
  if (s(0, 0, 0, {}), l) return { modes: l.modes, visible: [...t], overflow: [] };
  const c = Object.fromEntries(t.map((p) => [p.id, "full"])), u = [...t].sort((p, h) => p.priority - h.priority), d = () => t.reduce((p, h) => p + r(h, c[h.id]), 0) + Math.max(0, t.length - 1) * i;
  for (const p of ["icons", "group"])
    for (const h of u) {
      if (d() <= n) return { modes: c, visible: [...t], overflow: [] };
      r(h, p) < r(h, c[h.id]) && (c[h.id] = p);
    }
  return d() <= n ? { modes: c, visible: [...t], overflow: [] } : { modes: c, ...Fd(t, n - a, (p) => r(p, c[p.id]), i) };
}
function Rd(t) {
  const n = B(null), r = B(null), [a, i] = k({ modes: {}, ids: [] });
  return Ce(() => {
    const l = n.current, s = r.current;
    if (!l || !s || !l.parentElement) return;
    const c = l.parentElement;
    let u = 0, d = !0;
    const p = () => {
      if (!d) return;
      const m = new Map(Array.from(s.querySelectorAll("[data-measure-mode] [data-group]")).map((I) => [`${I.parentElement.dataset.measureMode}:${I.dataset.group}`, I.getBoundingClientRect().width])), b = getComputedStyle(c), g = parseFloat(getComputedStyle(l).columnGap) || 0, y = c.clientWidth - parseFloat(b.paddingLeft || "0") - parseFloat(b.paddingRight || "0"), w = c.querySelector(".note-toolbar-hint"), v = w && getComputedStyle(w).position !== "absolute" ? w.getBoundingClientRect().width + g : 0, N = (s.querySelector("[data-measure-overflow]")?.getBoundingClientRect().width ?? 40) + g, x = Od(t, Math.max(0, Math.floor(y - v)), (I, L) => m.get(`${L}:${I.id}`) ?? 1 / 0, N, g), C = { modes: x.modes, ids: x.visible.map((I) => I.id) };
      i((I) => JSON.stringify(I) === JSON.stringify(C) ? I : C);
    }, h = () => {
      cancelAnimationFrame(u), u = requestAnimationFrame(p);
    };
    p();
    const f = typeof ResizeObserver > "u" ? null : new ResizeObserver(h);
    return f?.observe(c), f?.observe(s), window.addEventListener("resize", h), document.fonts?.addEventListener("loadingdone", h), document.fonts?.ready.then(() => {
      d && h();
    }), () => {
      d = !1, cancelAnimationFrame(u), f?.disconnect(), window.removeEventListener("resize", h), document.fonts?.removeEventListener("loadingdone", h);
    };
  }), { hostRef: n, measureRef: r, modes: a.modes, visible: t.filter((l) => a.ids.includes(l.id)), overflow: t.filter((l) => !a.ids.includes(l.id)) };
}
function Bd({ editor: t, onHistory: n, onAttachment: r, onVideo: a, onInteractive: i, onInsertCard: l, onMath: s, onSnapshot: c, onExport: u, formatPainterMode: d, onFormatPainterMode: p, formatPainterMarks: h, onFormatPainterMarks: f, hiddenActions: m = [] }) {
  const [b, g] = k(null), [y, w] = k(null), [v, N] = k({ rows: 3, cols: 3 }), [x, C] = k(""), [, I] = k(0), L = B(null), K = B(null), S = B(null), A = B(null), D = B([]);
  Y(() => {
    const O = ({ transaction: Z }) => {
      A.current && Z.docChanged && (A.current = {
        from: Z.mapping.map(A.current.from),
        to: Z.mapping.map(A.current.to)
      }), I((we) => we + 1);
    };
    return t.on("transaction", O), () => {
      t.off("transaction", O);
    };
  }, [t]), Y(() => {
    if (!b) return;
    const O = (qe) => {
      const Be = qe.target;
      !L.current?.contains(Be) && !K.current?.contains(Be) && !Be.closest?.(".fp-popup-panel") && g(null);
    }, Z = (qe) => {
      qe.key === "Escape" && (g(null), S.current?.focus());
    }, we = () => g(null), Me = L.current?.clientWidth, Ee = typeof ResizeObserver > "u" ? null : new ResizeObserver(() => {
      L.current?.clientWidth !== Me && we();
    });
    return L.current && Ee?.observe(L.current), window.addEventListener("pointerdown", O), window.addEventListener("keydown", Z), window.addEventListener("resize", we), () => {
      Ee?.disconnect(), window.removeEventListener("pointerdown", O), window.removeEventListener("keydown", Z), window.removeEventListener("resize", we);
    };
  }, [b]);
  const U = () => {
    const { from: O, to: Z } = t.state.selection;
    A.current = { from: O, to: Z };
  }, j = () => {
    const O = A.current;
    O && O.to <= t.state.doc.content.size ? t.chain().focus().setTextSelection(O).run() : t.commands.focus();
  }, T = () => {
    g(null), A.current = null;
  }, M = (O) => {
    O(), T();
  }, R = [1, 2, 3, 4, 5, 6].find((O) => t.isActive("heading", { level: O })), q = t.getAttributes("textStyle").color || null, F = t.getAttributes("highlight").color || "#fde047", E = () => {
    const O = $d(d);
    p(O), f(O ? D.current : []);
  }, z = [
    { id: "history", priority: 100, actions: [
      { id: "undo", label: "撤销", icon: /* @__PURE__ */ e(Bl, { size: 16 }), disabled: !t.can().undo(), run: () => {
        t.chain().focus().undo().run();
      } },
      { id: "redo", label: "重做", icon: /* @__PURE__ */ e(jl, { size: 16 }), disabled: !t.can().redo(), run: () => {
        t.chain().focus().redo().run();
      } }
    ] },
    { id: "painter", priority: 40, actions: [{ id: "painter", label: "格式刷", icon: /* @__PURE__ */ e(ql, { size: 16 }), active: !!d, before: () => {
      D.current = Md(t);
    }, run: E }] },
    { id: "heading", priority: 95, actions: [{ id: "heading", label: "标题级别", icon: /* @__PURE__ */ e("b", { children: R ? `H${R}` : "Hn" }), menu: "heading" }] },
    { id: "bold", priority: 90, actions: [{ id: "bold", label: "粗体", icon: /* @__PURE__ */ e(Kl, { size: 16 }), active: t.isActive("bold"), run: () => {
      t.chain().focus().toggleBold().run();
    } }] },
    { id: "italic", priority: 65, actions: [{ id: "italic", label: "斜体", icon: /* @__PURE__ */ e(Hl, { size: 16 }), active: t.isActive("italic"), run: () => {
      t.chain().focus().toggleItalic().run();
    } }] },
    { id: "colors", priority: 60, actions: [
      { id: "color", label: "字体颜色", icon: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e(Ul, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: q || "var(--fp-ink)" } })
      ] }), menu: "color", before: U },
      { id: "highlight", label: "荧光笔", icon: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e(_l, { size: 16 }),
        /* @__PURE__ */ e("i", { className: "toolbar-color-bar", style: { background: F } })
      ] }), menu: "highlight", before: U }
    ] },
    { id: "list", priority: 70, actions: [{ id: "list", label: "列表", icon: /* @__PURE__ */ e(nn, { size: 16 }), menu: "list" }] },
    { id: "link", priority: 45, actions: [{ id: "link", label: "链接", icon: /* @__PURE__ */ e(gt, { size: 16 }), active: t.isActive("link"), menu: "link", before: U }] },
    { id: "attachment", priority: 42, actions: [{ id: "attachment", label: "附件", icon: /* @__PURE__ */ e(fr, { size: 16 }), run: r }] },
    { id: "math", priority: 99, actions: [{ id: "math", label: "公式", icon: /* @__PURE__ */ e(It, { size: 16 }), menu: "math" }] },
    { id: "insert", priority: 98, actions: [{ id: "insert", label: "插入", icon: /* @__PURE__ */ e(er, { size: 16 }), menu: "insert" }] },
    { id: "decoration", priority: 35, actions: [
      { id: "strike", label: "删除线", icon: /* @__PURE__ */ e(Wl, { size: 16 }), active: t.isActive("strike"), run: () => {
        t.chain().focus().toggleStrike().run();
      } },
      { id: "underline", label: "下划线", icon: /* @__PURE__ */ e(Vl, { size: 16 }), active: t.isActive("underline"), run: () => {
        t.chain().focus().toggleUnderline().run();
      } }
    ] },
    { id: "clear", priority: 20, actions: [{ id: "clear", label: "清除格式", icon: /* @__PURE__ */ e(Yl, { size: 16 }), run: () => {
      t.chain().focus().unsetAllMarks().clearNodes().run();
    } }] },
    { id: "quote", priority: 30, actions: [{ id: "quote", label: "引用", icon: /* @__PURE__ */ e(Za, { size: 16 }), active: t.isActive("blockquote"), run: () => {
      t.chain().focus().toggleBlockquote().run();
    } }] },
    { id: "code", priority: 25, actions: [
      { id: "code", label: "行内代码", icon: /* @__PURE__ */ e(Lr, { size: 16 }), active: t.isActive("code"), run: () => {
        t.chain().focus().toggleCode().run();
      } },
      { id: "codeBlock", label: "代码块", icon: /* @__PURE__ */ e(Xl, { size: 16 }), active: t.isActive("codeBlock"), run: () => {
        t.chain().focus().toggleCodeBlock().run();
      } }
    ] },
    { id: "versions", priority: 15, actions: [{ id: "versions", label: "历史", icon: /* @__PURE__ */ e("span", { children: "历史" }), run: n }] }
  ];
  t.isActive("codeBlock") && z.push({ id: "language", priority: 85, actions: [], custom: /* @__PURE__ */ e(zd, { language: Fc(t.state.selection.$head.parent), onChange: (O) => t.chain().focus().updateAttributes("codeBlock", { language: O }).run() }) }), t.isActive("table") && z.push({ id: "tableActions", priority: 80, actions: [
    { id: "addRow", label: "添加行", icon: /* @__PURE__ */ e("span", { children: "+行" }), run: () => {
      t.chain().focus().addRowAfter().run();
    } },
    { id: "deleteRow", label: "删除行", icon: /* @__PURE__ */ e("span", { children: "−行" }), run: () => {
      t.chain().focus().deleteRow().run();
    } },
    { id: "addColumn", label: "添加列", icon: /* @__PURE__ */ e("span", { children: "+列" }), run: () => {
      t.chain().focus().addColumnAfter().run();
    } },
    { id: "deleteColumn", label: "删除列", icon: /* @__PURE__ */ e("span", { children: "−列" }), run: () => {
      t.chain().focus().deleteColumn().run();
    } },
    { id: "deleteTable", label: "删除表格", icon: /* @__PURE__ */ e("span", { children: "删表" }), run: () => {
      t.chain().focus().deleteTable().run();
    } }
  ] });
  const $ = z.flatMap((O) => O.actions), P = (...O) => $.filter((Z) => O.includes(Z.id)), ie = [
    { id: "history", label: "撤销重做", priority: 100, actions: P("undo", "redo") },
    { id: "text", label: "文字格式", priority: 80, actions: P("heading", "bold", "italic", "underline", "strike", "color", "highlight", "painter", "clear") },
    { id: "paragraph", label: "段落", priority: 60, actions: P("list", "quote", "code", "codeBlock") },
    { id: "insertions", label: "插入", priority: 90, actions: [
      ...P("math"),
      { id: "table", label: "表格", icon: /* @__PURE__ */ e(er, { size: 16 }), menu: "table" },
      { id: "card", label: "卡片", icon: /* @__PURE__ */ e(la, { size: 16 }), run: l },
      ...P("link", "attachment"),
      { id: "video", label: "视频 · 边看边记", icon: /* @__PURE__ */ e(oa, { size: 16 }), run: a || r },
      { id: "mermaid", label: "Mermaid 图", icon: /* @__PURE__ */ e(Gl, { size: 16 }), run: () => {
        Wi(t);
      } },
      ...i ? [{ id: "interactive", label: "交互实验", icon: /* @__PURE__ */ e(Jl, { size: 16 }), run: i }] : [],
      { id: "divider", label: "分隔线", icon: /* @__PURE__ */ e(Ft, { size: 16 }), run: () => {
        t.chain().focus().setHorizontalRule().run();
      } }
    ] },
    { id: "versions", label: "历史与导出", priority: 40, actions: [
      ...P("versions"),
      { id: "snapshot", label: "建立版本", icon: /* @__PURE__ */ e(ei, { size: 16 }), run: c },
      { id: "export", label: "导出", icon: /* @__PURE__ */ e(jt, { size: 16 }), run: u }
    ] },
    ...z.filter((O) => ["language", "tableActions"].includes(O.id)).map((O) => ({ ...O, label: O.id === "language" ? "代码语言" : "表格操作" }))
  ].map((O) => ({ ...O, actions: O.actions.filter((Z) => !m.includes(Z.id)) })).filter((O) => O.actions.length || O.custom), { hostRef: ye, measureRef: he, modes: W, visible: G, overflow: ue } = Rd(ie), me = (O, Z = !1, we = !1, Me = !1) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "data-fp-tooltip": Z ? "off" : O.label,
      "aria-label": O.label,
      "aria-pressed": O.active || void 0,
      "aria-expanded": O.menu ? b === O.menu : void 0,
      disabled: O.disabled,
      className: Z ? "toolbar-menu-item" : void 0,
      onMouseDown: (Ee) => {
        we || (Ee.preventDefault(), O.before?.());
      },
      onClick: (Ee) => {
        we || (O.before?.(), O.menu ? (w(Z ? y ?? Ee.currentTarget.getBoundingClientRect() : Ee.currentTarget.getBoundingClientRect()), g((qe) => qe === O.menu ? null : O.menu), O.menu === "link" && C(t.getAttributes("link").href || "")) : O.run && M(O.run));
      },
      children: [
        O.icon,
        (Z || Me) && O.id !== "versions" && /* @__PURE__ */ e("span", { children: O.label })
      ]
    },
    O.id
  ), H = (O, Z = !1, we = !1, Me = W[O.id] ?? "full") => /* @__PURE__ */ e("div", { "data-group": O.id, className: Z ? "toolbar-overflow-group" : "toolbar-group", children: Me === "group" && !Z && O.id !== "history" ? /* @__PURE__ */ o("button", { type: "button", "aria-label": O.label, "aria-expanded": b === `group:${O.id}`, onMouseDown: (Ee) => Ee.preventDefault(), onClick: (Ee) => {
    w(Ee.currentTarget.getBoundingClientRect()), g(`group:${O.id}`);
  }, children: [
    O.label,
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌄" })
  ] }) : /* @__PURE__ */ o(Q, { children: [
    O.actions.map((Ee) => me(Ee, Z, we, Me === "full" && O.id !== "history")),
    O.custom
  ] }) }, O.id), V = (O, Z, we) => /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onMouseDown: (Me) => Me.preventDefault(), onClick: () => M(we), children: [
    Z,
    /* @__PURE__ */ e("span", { children: O })
  ] }), oe = y ? Math.max(8, Math.min(y.left, window.innerWidth - 256)) : 8, _ = y ? Math.min(y.bottom + 6, window.innerHeight - 160) : 8;
  return /* @__PURE__ */ o("div", { className: "fp-note-toolbar note-editor-topbar", ref: L, role: "toolbar", "aria-label": "笔记编辑工具", children: [
    /* @__PURE__ */ e("div", { ref: ye, className: "visual-note-editor-toolbar", children: G.map((O) => H(O)) }),
    ue.length > 0 && /* @__PURE__ */ e(Sd, { tip: "更多", children: /* @__PURE__ */ e("button", { ref: S, type: "button", "aria-label": "更多", title: "更多", "aria-expanded": b === "more", onMouseDown: (O) => O.preventDefault(), onClick: () => {
      w(S.current?.getBoundingClientRect() ?? null), g(b === "more" ? null : "more");
    }, children: /* @__PURE__ */ e(Ot, { size: 17 }) }) }),
    /* @__PURE__ */ o("div", { ref: he, className: "visual-note-editor-toolbar toolbar-measure", "aria-hidden": "true", inert: !0, children: [
      ["full", "icons", "group"].map((O) => /* @__PURE__ */ e("div", { "data-measure-mode": O, className: "toolbar-measure-row", children: ie.map((Z) => H(Z, !1, !0, O)) }, O)),
      /* @__PURE__ */ e("button", { type: "button", "data-measure-overflow": !0, "aria-label": "更多", children: /* @__PURE__ */ e(Ot, { size: 17 }) })
    ] }),
    d && t.state.selection.empty && !h.length && /* @__PURE__ */ e("span", { className: "note-toolbar-hint", role: "status", children: "请先选中带格式的文字，再点格式刷" }),
    b && y && De(/* @__PURE__ */ o("div", { ref: K, className: "fp-editor-menu note-toolbar-portal-menu", role: "dialog", "aria-label": "编辑工具选项", style: { left: oe, top: _, maxHeight: Math.max(100, window.innerHeight - _ - 12) }, children: [
      b === "more" && /* @__PURE__ */ e(Q, { children: ue.map((O) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: O.label }),
        H(O, !0)
      ] }, O.id)) }),
      b.startsWith("group:") && ie.filter((O) => `group:${O.id}` === b).map((O) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: O.label }),
        H(O, !0)
      ] }, O.id)),
      b === "heading" && /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e("strong", { className: "toolbar-menu-label", children: "标题级别" }),
        /* @__PURE__ */ e("div", { className: "toolbar-menu-grid", children: [1, 2, 3, 4, 5, 6].map((O) => /* @__PURE__ */ o("button", { type: "button", className: R === O ? "is-active" : "", onClick: () => M(() => {
          t.chain().focus().toggleHeading({ level: O }).run();
        }), children: [
          "H",
          O
        ] }, O)) }),
        V("正文", null, () => {
          t.chain().focus().setParagraph().run();
        })
      ] }),
      (b === "color" || b === "highlight") && /* @__PURE__ */ e(Pd, { mode: b === "color" ? "text" : "highlight", current: b === "color" ? q : F, onApply: (O) => {
        j(), b === "color" ? O === null ? t.chain().unsetMark("textStyle").removeEmptyTextStyle().run() : t.chain().setColor(O).run() : O === null ? t.chain().unsetHighlight().run() : t.chain().setHighlight({ color: O }).run();
      }, onClose: T }),
      b === "list" && /* @__PURE__ */ o(Q, { children: [
        V("无序列表", /* @__PURE__ */ e(nn, { size: 15 }), () => {
          t.chain().focus().toggleBulletList().run();
        }),
        V("有序列表", /* @__PURE__ */ e(Ql, { size: 15 }), () => {
          t.chain().focus().toggleOrderedList().run();
        })
      ] }),
      b === "link" && /* @__PURE__ */ o("form", { className: "toolbar-link-form", onSubmit: (O) => {
        O.preventDefault(), j(), x.trim() ? t.chain().extendMarkRange("link").setLink({ href: x.trim() }).run() : t.chain().extendMarkRange("link").unsetLink().run(), T();
      }, children: [
        /* @__PURE__ */ o("label", { children: [
          "链接地址",
          /* @__PURE__ */ e("input", { "aria-label": "链接地址", value: x, onChange: (O) => C(O.target.value), placeholder: "https://" })
        ] }),
        /* @__PURE__ */ e("button", { type: "submit", children: "应用" }),
        V("移除链接", null, () => {
          j(), t.chain().extendMarkRange("link").unsetLink().run();
        })
      ] }),
      b === "math" && /* @__PURE__ */ o(Q, { children: [
        V("行内公式", /* @__PURE__ */ e(It, { size: 15 }), () => s(!1)),
        V("独立公式", /* @__PURE__ */ e(It, { size: 15 }), () => s(!0))
      ] }),
      b === "insert" && /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ o("button", { type: "button", className: "toolbar-menu-item", onClick: () => g("table"), children: [
          /* @__PURE__ */ e(er, { size: 15 }),
          "表格…"
        ] }),
        V("行内公式", /* @__PURE__ */ e(It, { size: 15 }), () => s(!1)),
        V("独立公式", /* @__PURE__ */ e(It, { size: 15 }), () => s(!0)),
        !m.includes("card") && V("说明卡片", /* @__PURE__ */ e(la, { size: 15 }), l),
        !m.includes("video") && V("视频 · 边看边记", /* @__PURE__ */ e(oa, { size: 15 }), a || r),
        !m.includes("attachment") && V("附件", /* @__PURE__ */ e(fr, { size: 15 }), r),
        V("分隔线", /* @__PURE__ */ e(Ft, { size: 15 }), () => {
          t.chain().focus().setHorizontalRule().run();
        })
      ] }),
      b === "table" && /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ o("strong", { className: "toolbar-menu-label", children: [
          v.rows,
          " × ",
          v.cols,
          " 表格"
        ] }),
        /* @__PURE__ */ e("div", { className: "toolbar-table-grid", children: Array.from({ length: 64 }, (O, Z) => {
          const we = Math.floor(Z / 8) + 1, Me = Z % 8 + 1;
          return /* @__PURE__ */ e("button", { type: "button", "aria-label": `${we} 行 ${Me} 列`, className: we <= v.rows && Me <= v.cols ? "is-active" : "", onFocus: () => N({ rows: we, cols: Me }), onMouseEnter: () => N({ rows: we, cols: Me }), onClick: () => M(() => {
            t.chain().focus().insertTable({ rows: we, cols: Me, withHeaderRow: !0 }).run();
          }) }, Z);
        }) })
      ] })
    ] }), document.body)
  ] });
}
const Ji = Vn.create({
  name: "imageConversion",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return Object.fromEntries(["src", "alt", "jobId", "markdown", "error"].map((t) => [t, { default: "" }]));
  },
  parseHTML() {
    return [{ tag: "figure[data-image-conversion]" }];
  },
  renderHTML({ node: t }) {
    return ["figure", { "data-image-conversion": "" }, ["img", { src: t.attrs.src, alt: t.attrs.alt }]];
  },
  renderMarkdown(t) {
    return `![${String(t.attrs?.alt || "图片").replace(/[\[\]]/g, "")}](${t.attrs?.src || ""})`;
  }
});
function Ih(t, n) {
  const r = t.state.selection.to;
  return t.chain().focus().insertContentAt(r, [n, { type: "paragraph" }]).run();
}
const Vt = (t) => String(t ?? "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), Qi = Vn.create({
  name: "uploadPlaceholder",
  group: "block",
  atom: !0,
  selectable: !0,
  addAttributes() {
    return {
      uploadId: { default: "" },
      name: { default: "附件" },
      mediaType: { default: "application/octet-stream" },
      error: { default: "" },
      convert: { default: !1, parseHTML: (t) => t.getAttribute("convert") === "true" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-upload-placeholder]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["div", qr(t, { "data-upload-placeholder": "" }), `正在上传 ${t.name || "附件"}`];
  },
  renderMarkdown(t) {
    const n = t.attrs || {};
    return `<div data-upload-placeholder="" uploadid="${Vt(n.uploadId)}" name="${Vt(n.name)}" mediatype="${Vt(n.mediaType)}" error="${Vt(n.error)}" convert="${n.convert === !0 ? "true" : "false"}">正在上传 ${Vt(n.name || "附件")}</div>

`;
  }
});
function jd(t) {
  const n = (r) => {
    if (!r.content) return [r];
    const a = r.content.flatMap(n);
    if (!["paragraph", "heading"].includes(r.type || "") || !a.some((u) => u.type === "image")) return [{ ...r, content: a }];
    const i = [];
    let l = [], s = !1;
    const c = () => {
      if (!l.length) return;
      const u = { ...r.attrs };
      s && delete u.id, i.push({ ...r, attrs: u, content: l }), s = !0, l = [];
    };
    for (const u of a)
      u.type === "image" ? (c(), i.push(u)) : l.push(u);
    return c(), i;
  };
  return n(t)[0];
}
function qd(t) {
  const n = t.match(
    /^::(video|audio|interactive|figure|plot)\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/
  );
  if (n)
    return {
      type: "directiveBlock",
      raw: n[0],
      name: n[1],
      attributes: n[2] || "",
      body: ""
    };
  const r = t.match(/^:::([a-zA-Z][\w-]*)(?:\{([^\n}]*)\})?[ \t]*\r?\n/);
  if (!r) return;
  let a = 1, i = r[0].length;
  for (; i <= t.length; ) {
    const l = t.indexOf(`
`, i), s = l < 0 ? t.length : l + 1, c = t.slice(i, s).replace(/\r?\n$/, "");
    if (/^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/.test(c) && (a += 1), /^:::[ \t]*$/.test(c) && (a -= 1, a === 0)) {
      const u = t.slice(r[0].length, i).replace(/\r?\n$/, "");
      return {
        type: "directiveBlock",
        raw: t.slice(0, s),
        name: r[1],
        attributes: r[2] || "",
        body: u
      };
    }
    if (l < 0) break;
    i = s;
  }
}
const Zi = Vn.create({
  name: "directiveBlock",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "note" },
      attributes: { default: "" },
      body: { default: "" }
    };
  },
  parseHTML() {
    return [{ tag: "div[data-directive-block]" }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return [
      "div",
      qr(t, { "data-directive-block": "" })
    ];
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("directiveBlock", {
      name: r.name,
      attributes: r.attributes,
      body: r.body
    });
  },
  renderMarkdown(t) {
    const n = String(t.attrs?.attributes || "").trim(), r = String(t.attrs?.body || ""), a = t.attrs?.name || "note";
    return ["video", "audio", "interactive", "figure", "plot"].includes(a) ? `::${a}${n ? `{${n}}` : ""}` : `:::${a}${n ? `{${n}}` : ""}
${r}${r.endsWith(`
`) ? "" : `
`}:::`;
  },
  markdownTokenizer: {
    name: "directiveBlock",
    level: "block",
    start: (t) => t.search(
      /^::(?:interactive|video|audio|figure|plot)\{[^\n}]*\}[ \t]*$|^:::[a-zA-Z][\w-]*(?:\{[^\n}]*\})?[ \t]*$/m
    ),
    tokenize: (t) => qd(t)
  }
}), Kd = [
  ["definition", "定义"],
  ["theorem", "定理"],
  ["example", "例题"],
  ["insight", "直觉"],
  ["pitfall", "易错点"],
  ["note", "说明"],
  ["tip", "技巧"],
  ["memory", "记忆卡"],
  ["derivation", "推导"],
  ["timeline", "时间线"],
  ["event", "事件"],
  ["concept", "概念"],
  ["compare", "对比"],
  ["cause-effect", "因果"],
  ["keypoint", "核心要点"],
  ["interactive", "互动内容"],
  ["video", "视频"],
  ["figure", "图片"],
  ["plot", "函数图"],
  ["audio", "音频"],
  ["historymap", "历史地图"],
  ["learninganimation", "学习动画"],
  ["attachment", "附件"]
];
function el(t) {
  return t === "timeline" ? "period" : t === "concept" ? "term" : ["event", "compare", "cause-effect"].includes(t) ? "title" : "label";
}
function La(t, n) {
  const r = el(n);
  for (const a of [r, "label", "title", "term", "period"]) {
    const i = t.match(
      new RegExp(`(?:^|\\s)${a}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)
    );
    if (i) return i[1] ?? i[2] ?? i[3] ?? "";
  }
  return "";
}
function Ta(t, n, r) {
  const a = el(n), i = t.replace(
    /(?:^|\s)(?:label|title|period|term)=(?:"[^"]*"|'[^']*'|[^\s}]+)/g,
    ""
  ).trim(), l = r.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  return [`${a}="${l}"`, i].filter(Boolean).join(" ");
}
const Hd = cs.extend({
  addOptions() {
    return { ...this.parent?.(), resolveUrl: (t) => t };
  },
  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: null,
        parseHTML: (t) => t.getAttribute("data-width") || t.style.width || null,
        renderHTML: (t) => t.width ? { "data-width": t.width, style: `width:${t.width};max-width:100%` } : {}
      }
    };
  },
  addNodeView() {
    return ({ node: t, getPos: n, editor: r }) => {
      let a = t;
      const i = document.createElement("span");
      i.className = "visual-image-node", i.contentEditable = "false", i.dataset.noteObject = "image";
      const l = document.createElement("img"), s = document.createElement("input");
      s.type = "text", s.className = "visual-image-caption", s.setAttribute("aria-label", "图片名称"), s.placeholder = "添加图片名称", s.addEventListener("keydown", (d) => {
        d.stopPropagation(), d.key === "Enter" && !d.isComposing && (d.preventDefault(), s.blur());
      }), s.addEventListener("blur", () => {
        const d = n();
        typeof d == "number" && s.value !== String(a.attrs.title || a.attrs.alt || "") && r.view.dispatch(r.state.tr.setNodeMarkup(d, void 0, { ...a.attrs, alt: s.value, title: s.value }));
      });
      const c = document.createElement("button");
      c.type = "button", c.className = "visual-image-resize", c.setAttribute("aria-label", "调整图片大小");
      const u = () => {
        l.src = this.options.resolveUrl(String(a.attrs.src || "")), l.alt = String(a.attrs.alt || ""), l.title = String(a.attrs.title || ""), document.activeElement !== s && (s.value = String(a.attrs.title || a.attrs.alt || "")), l.style.width = a.attrs.width ? String(a.attrs.width) : "";
      };
      return c.addEventListener("pointerdown", (d) => {
        d.preventDefault(), d.stopPropagation();
        const p = d.clientX, h = l.getBoundingClientRect().width;
        c.setPointerCapture(d.pointerId);
        const f = (b) => {
          const g = Math.max(180, i.parentElement?.clientWidth || 900);
          l.style.width = `${Math.round(Math.min(g, Math.max(120, h + b.clientX - p)))}px`;
        }, m = (b) => {
          c.releasePointerCapture(b.pointerId), c.removeEventListener("pointermove", f), c.removeEventListener("pointerup", m);
          const g = n();
          typeof g == "number" && r.view.dispatch(r.state.tr.setNodeMarkup(g, void 0, { ...a.attrs, width: l.style.width }));
        };
        c.addEventListener("pointermove", f), c.addEventListener("pointerup", m);
      }), i.append(l, c, s), u(), {
        dom: i,
        stopEvent(d) {
          return d.target === s;
        },
        update(d) {
          return d.type !== a.type ? !1 : (a = d, u(), !0);
        },
        selectNode() {
          i.classList.add("is-selected");
        },
        deselectNode() {
          i.classList.remove("is-selected");
        }
      };
    };
  }
}), Ud = ds.extend({
  onCreate(t) {
    if (this.parent?.(t), !this.options.updateDocument || !this.editor.extensionManager.extensions.find((u) => ["collaboration", "collaborationCaret"].includes(u.name) && u.options.provider)?.options.provider?.synced) return;
    const { state: r, view: a } = this.editor, { attributeName: i, generateID: l, types: s } = this.options, c = r.tr;
    r.doc.descendants((u, d) => {
      (s === "all" ? !["doc", "text"].includes(u.type.name) : s.includes(u.type.name)) && u.attrs[i] === null && c.setNodeMarkup(d, void 0, { ...u.attrs, [i]: l({ node: u, pos: d }) });
    }), c.steps.length && a.dispatch(c.setStoredMarks(r.storedMarks).setMeta("addToHistory", !1).setMeta("__uniqueIDTransaction", !0));
  }
});
function ar(t, n) {
  const r = t.match(new RegExp(`(?:^|\\s)${n}=(?:"([^"]*)"|'([^']*)'|([^\\s}]+))`)), a = r?.[1] ?? r?.[2] ?? r?.[3] ?? "";
  try {
    return decodeURIComponent(a);
  } catch {
    return a;
  }
}
function ir(t) {
  return encodeURIComponent(t);
}
function _d(t) {
  const n = t.match(/^::attachment\{([^\n}]*)\}[ \t]*(?:\r?\n|$)/);
  if (n)
    return {
      type: "attachment",
      raw: n[0],
      name: ar(n[1], "name") || "附件",
      url: ar(n[1], "url"),
      mediaType: ar(n[1], "mediaType") || "application/octet-stream"
    };
}
const tl = Vn.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addAttributes() {
    return {
      name: { default: "附件" },
      url: { default: "" },
      mediaType: { default: "application/octet-stream" }
    };
  },
  parseHTML() {
    return [{
      tag: "figure[data-note-attachment]",
      getAttrs: (t) => {
        const n = t;
        return {
          name: n.dataset.name || "附件",
          url: n.dataset.url || "",
          mediaType: n.dataset.mediaType || "application/octet-stream"
        };
      }
    }];
  },
  renderHTML({ HTMLAttributes: t }) {
    return ["figure", qr(t, {
      "data-note-attachment": "",
      "data-name": t.name,
      "data-url": t.url,
      "data-media-type": t.mediaType
    }), ["a", { href: t.url, target: "_blank", rel: "noreferrer" }, t.name || "附件"]];
  },
  renderMarkdown(t) {
    const n = ir(String(t.attrs?.name || "附件")), r = ir(String(t.attrs?.url || "")), a = ir(String(t.attrs?.mediaType || "application/octet-stream"));
    return `::attachment{name="${n}" url="${r}" mediaType="${a}"}

`;
  },
  parseMarkdown(t, n) {
    const r = t;
    return n.createNode("attachment", { name: r.name, url: r.url, mediaType: r.mediaType });
  },
  markdownTokenizer: {
    name: "attachment",
    level: "block",
    start: (t) => t.search(/^::attachment\{[^\n}]*\}[ \t]*$/m),
    tokenize: (t) => _d(t)
  }
}), Wd = /^(\s*)>\s*\[!([A-Za-z]+)\]([+-])?\s*(.*)$/, Vd = /^(\s*)>( ?)(.*)$/;
function Yd(t) {
  let n = !0, r = !0;
  return t.replace(/["']/g, (a) => {
    if (a === '"') {
      const l = n ? "“" : "”";
      return n = !n, l;
    }
    const i = r ? "‘" : "’";
    return r = !r, i;
  });
}
function Xd(t) {
  if (!t || t.indexOf("[!") === -1) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "", l = 0;
  for (; l < n.length; ) {
    const s = n[l], c = s.match(/^\s*(`{3,}|~{3,})/);
    if (c) {
      const y = c[1][0];
      a ? y === i && (a = !1, i = "") : (a = !0, i = y), r.push(s), l++;
      continue;
    }
    if (a) {
      r.push(s), l++;
      continue;
    }
    const u = s.match(Wd);
    if (!u) {
      r.push(s), l++;
      continue;
    }
    const [, d, p, h, f] = u;
    if (ed(p)) {
      r.push(s), l++;
      continue;
    }
    const m = Zc(p), b = f.trim(), g = [`kind=${m}`];
    for (b && g.push(`label="${Yd(b)}"`), h === "-" && g.push("collapsed=true"), r.push(`${d}:::callout{${g.join(" ")}}`), l++; l < n.length; ) {
      const y = n[l];
      if (!/^\s*>/.test(y) || y.match(/^\s*>\s*(`{3,}|~{3,})/)) break;
      const v = y.match(Vd);
      v ? r.push(v[3]) : r.push(y.replace(/^\s*>\s?/, "")), l++;
    }
    r.push(`${d}:::`);
  }
  return r.join(`
`);
}
function Gd(t) {
  if (!t || !/(==[^=\n]+==)|<font\s|<span\s[^>]*background/i.test(t)) return t;
  const n = t.split(`
`), r = [];
  let a = !1, i = "";
  for (const l of n) {
    const s = l.match(/^\s*(`{3,}|~{3,})/);
    if (s) {
      const u = s[1][0];
      a ? u === i && (a = !1, i = "") : (a = !0, i = u), r.push(l);
      continue;
    }
    if (a) {
      r.push(l);
      continue;
    }
    let c = l;
    c = c.replace(/==([^\n=]+)==/g, "<mark>$1</mark>"), c = c.replace(
      /<font\s+color=["']([^"']+)["']\s*>([\s\S]*?)<\/font>/gi,
      (u, d, p) => `<span style="color:${d}">${p}</span>`
    ), c = c.replace(
      /<span\s+[^>]*style=["'][^"']*background(?:-color)?:\s*([^;"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,
      (u, d, p) => `<mark data-color="${d.trim()}">${p}</mark>`
    ), r.push(c);
  }
  return r.join(`
`);
}
const Da = /#[\p{L}\p{N}_][\p{L}\p{N}_-]{0,48}/gu, Jd = jr.create({
  name: "hashtagHighlight",
  addProseMirrorPlugins() {
    return [
      new dn({
        key: new si("hashtagHighlight"),
        props: {
          decorations(t) {
            const { doc: n, selection: r } = t, a = [];
            return n.descendants((i, l) => {
              if (i.type.spec.code) return !1;
              if (!i.isText || !i.text || i.marks.some((d) => d.type.spec.code) || r.empty && r.from >= l && r.from <= l + i.nodeSize) return;
              const c = i.text;
              Da.lastIndex = 0;
              let u;
              for (; (u = Da.exec(c)) !== null; ) {
                const d = l + u.index, p = d + u[0].length;
                a.push(
                  bi.inline(d, p, { class: "note-inline-tag" })
                );
              }
            }), br.create(n, a);
          }
        }
      })
    ];
  }
}), Qd = [
  "paragraph",
  "heading",
  "blockquote",
  "codeBlock",
  "bulletList",
  "orderedList",
  "table",
  "horizontalRule",
  "image",
  "attachment",
  "blockMath",
  "directiveBlock"
], Lh = 2;
function Gr(t = !0, n, r = Zi, a, i = tl, l = hi.configure({ lowlight: Oi })) {
  return [
    ns.configure({
      undoRedo: t ? void 0 : !1,
      link: !1,
      codeBlock: !1
    }),
    rs.configure({ openOnClick: !1, autolink: !0, defaultProtocol: "https" }),
    us,
    ps,
    hs.configure({ multicolor: !0 }),
    l,
    Hd.configure({ allowBase64: !1, inline: !1 }),
    i,
    Ji,
    Qi,
    os.configure({ table: { resizable: !0 } }),
    Ud.configure({ types: Qd }),
    r,
    ...a || [as.configure({
      katexOptions: { throwOnError: !1 },
      inlineOptions: { onClick: (s, c) => n?.onInlineClick?.(String(s.attrs.latex || ""), c) },
      blockOptions: { onClick: (s, c) => n?.onBlockClick?.(String(s.attrs.latex || ""), c) }
    })],
    ss.configure({ markedOptions: { gfm: !0, breaks: !1 } }),
    Jd
  ];
}
function nl(t) {
  return jd(new gi({ extensions: Gr(!1) }).parse(
    Xd(Gd(t))
  ));
}
function Pa(t) {
  return new gi({ extensions: Gr(!1) }).serialize(t);
}
const Pn = /* @__PURE__ */ new WeakMap();
let Gt = null;
function Zd() {
  return typeof IntersectionObserver > "u" ? null : (Gt || (Gt = new IntersectionObserver((t) => {
    for (const n of t) {
      if (!n.isIntersecting) continue;
      const r = Pn.get(n.target);
      r && (Pn.delete(n.target), Gt?.unobserve(n.target), r());
    }
  }, { rootMargin: "600px 0px" })), Gt);
}
function Fa({ node: t, getPos: n, editor: r }, a, i) {
  let l = t, s = !1, c = !1;
  const u = document.createElement(a ? "div" : "span");
  u.mathPosition = () => c ? void 0 : n();
  const d = document.createElement(a ? "div" : "span");
  u.className = "tiptap-mathematics-render is-deferred", u.dataset.type = a ? "block-math" : "inline-math", u.contentEditable = "false", u.draggable = !1, d.className = "math-node-content", u.append(d);
  const p = document.createElement(a ? "div" : "span");
  p.className = "math-node-editor-slot", u.append(p);
  const h = (N) => {
    N.preventDefault(), N.stopPropagation();
  };
  u.addEventListener("dragstart", h);
  const f = document.createElement("button");
  f.type = "button", f.className = "math-node-edit", f.textContent = "编辑公式", f.setAttribute("aria-label", "编辑公式"), i && u.append(f);
  const m = () => {
    const N = String(l.attrs.latex || "");
    u.dataset.latex = N, u.setAttribute("aria-label", `公式：${N}`), d.textContent = N;
  }, b = () => {
    if (c) return;
    const N = String(l.attrs.latex || "");
    try {
      vi.render(N || "\\;", d, { throwOnError: !0, displayMode: a, macros: $i }), u.classList.remove(a ? "block-math-error" : "inline-math-error"), u.removeAttribute("title");
    } catch {
      d.textContent = N, u.classList.add(a ? "block-math-error" : "inline-math-error"), u.title = "公式暂时无法显示，点击编辑后可检查写法";
    }
    N || (d.textContent = "点击输入公式"), u.classList.toggle("is-empty-math", !N), u.classList.remove("is-deferred"), s = !0;
  }, g = () => {
    const N = Zd();
    if (!N) {
      b();
      return;
    }
    Pn.set(u, b), N.observe(u);
  }, y = () => {
    Pn.delete(u), Gt?.unobserve(u);
  }, w = (N) => {
    if (p.contains(N.target) || !r.isEditable) return;
    N.preventDefault(), N.stopPropagation();
    const x = n();
    typeof x == "number" && i?.(String(l.attrs.latex || ""), x);
  }, v = (N) => {
    if (p.contains(N.target)) return;
    N.preventDefault(), N.stopPropagation();
    const x = n();
    typeof x == "number" && r.isEditable && (r.commands.setNodeSelection(x), i?.(String(l.attrs.latex || ""), x));
  };
  return f.addEventListener("click", w), u.addEventListener("dblclick", w), m(), g(), i && u.addEventListener("click", v), {
    dom: u,
    selectNode() {
      u.classList.add("ProseMirror-selectednode"), u.draggable = !1;
    },
    deselectNode() {
      u.classList.remove("ProseMirror-selectednode"), u.draggable = !1;
    },
    stopEvent: (N) => p.contains(N.target) || f.contains(N.target),
    ignoreMutation: () => !0,
    update(N) {
      return N.type !== l.type ? !1 : (l = N, u.dataset.latex = String(l.attrs.latex || ""), u.setAttribute("aria-label", `公式：${l.attrs.latex || ""}`), s ? b() : m(), !0);
    },
    destroy() {
      c = !0, u.removeEventListener("dragstart", h), y(), u.removeEventListener("click", v), u.removeEventListener("dblclick", w), f.removeEventListener("click", w);
    }
  };
}
function eu(t) {
  const n = (i, l, s) => ({
    Enter: () => {
      const c = i.state.selection;
      return !(c instanceof Zt) || c.node.type.name !== l || !s ? !1 : (s(String(c.node.attrs.latex || ""), c.from), !0);
    }
  }), r = is.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "inlineMath", t.onInlineClick);
    },
    addNodeView() {
      return (i) => Fa(i, !1, t.onInlineClick);
    }
  });
  return [ls.extend({
    addKeyboardShortcuts() {
      return n(this.editor, "blockMath", t.onBlockClick);
    },
    addNodeView() {
      return (i) => Fa(i, !0, t.onBlockClick);
    }
  }), r];
}
const rl = {
  sin: "正弦",
  cos: "余弦",
  tan: "正切",
  cot: "余切",
  sec: "正割",
  csc: "余割",
  arcsin: "反正弦",
  arccos: "反余弦",
  arctan: "反正切",
  sinh: "双曲正弦",
  cosh: "双曲余弦",
  tanh: "双曲正切",
  coth: "双曲余切",
  exp: "指数函数",
  ln: "自然对数",
  log: "对数",
  lg: "常用对数",
  min: "最小值",
  max: "最大值",
  inf: "下确界",
  sup: "上确界",
  liminf: "下极限",
  limsup: "上极限",
  gcd: "最大公约数",
  arg: "辐角"
}, tu = { "e^x": "自然指数", "\\log_a": "任意底对数", "\\sqrt[n]{x}": "高次根号", "f'(x)": "一阶导数", "\\frac{d^2}{dx^2}": "二阶导数", "|x|": "绝对值", "\\{x\\}": "集合", "\\operatorname{span}": "线性张成", "\\ker": "核空间", "\\operatorname{Im}": "像空间", "\\operatorname{diag}": "对角矩阵", "\\frac{1}{n}": "倒数", "x^2": "平方" }, ne = (t, n = t, r) => ({ latex: `\\textstyle ${t}`, insert: n, tooltip: r ?? tu[t] ?? rl[t.replace(/^\\/, "")], class: "small" }), nu = ["[undo]", "[redo]", "[left]", "[right]", { label: "下一格", tooltip: "移到下一个占位框", command: ["performWithFeedback", "moveToNextPlaceholder"], width: 2 }, { label: "[backspace]", width: 2 }], Yt = (t, n) => ({ id: t, label: "", displayEditToolbar: !1, rows: [...n, nu] }), ru = [
  { id: "basic", label: "常用", layout: Yt("note-basic", [
    ["7", "8", "9", "+", "-", ne("\\frac{a}{b}", "\\frac{#0}{#?}", "分数"), ne("\\sqrt{x}", "\\sqrt{#0}", "根号"), ne("x^n", "#0^{#?}", "上标")],
    ["4", "5", "6", "\\times", "\\div", "(", ")", ne("x_n", "#0_{#?}", "下标")],
    ["1", "2", "3", "=", "\\ne", "<", ">", "\\pi"],
    ["0", ".", "x", "y", "\\le", "\\ge", "\\pm", "\\infty"]
  ]) },
  { id: "calculus", label: "高等数学", layout: Yt("note-calculus", [
    [ne("\\lim", "\\lim_{x\\to #?} #?", "极限"), ne("\\frac{d}{dx}", "\\frac{d #?}{d x}", "导数"), ne("\\frac{\\partial}{\\partial x}", "\\frac{\\partial #?}{\\partial x}", "偏导数"), ne("\\int", "\\int #?\\,d x", "不定积分"), ne("\\int_a^b", "\\int_{#?}^{#?} #?\\,d x", "定积分"), ne("\\iint", "\\iint_{#?} #?\\,d x\\,d y", "二重积分"), ne("\\iiint", "\\iiint_{#?} #?\\,d V", "三重积分"), ne("\\oint", "\\oint_{#?} #?\\,d s", "曲线积分")],
    [ne("\\sum", "\\sum_{n=#?}^{#?} #?", "求和"), ne("\\prod", "\\prod_{n=#?}^{#?} #?", "连乘"), ne("e^x", "e^{#?}"), ne("\\ln", "\\ln\\left(#?\\right)"), ne("\\log_a", "\\log_{#?}\\left(#?\\right)"), ne("\\sqrt[n]{x}", "\\sqrt[#?]{#0}"), "\\infty", "\\to"],
    [ne("\\sin", "\\sin\\left(#?\\right)"), ne("\\cos", "\\cos\\left(#?\\right)"), ne("\\tan", "\\tan\\left(#?\\right)"), ne("\\arcsin", "\\arcsin\\left(#?\\right)"), "\\pi", "\\theta", "\\Delta", "\\nabla"],
    [ne("f'(x)", "f^{\\prime}(#?)"), ne("\\frac{d^2}{dx^2}", "\\frac{d^2 #?}{d x^2}"), ne("|x|", "\\left|#0\\right|"), ne("\\{\\cdots", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}", "分段函数"), "x", "n", "=", "\\approx"]
  ]) },
  { id: "discrete", label: "离散数学", layout: Yt("note-discrete", [
    ["\\neg", "\\land", "\\lor", "\\oplus", "\\implies", "\\iff", "\\forall", "\\exists"],
    ["\\in", "\\notin", "\\subset", "\\subseteq", "\\cup", "\\cap", "\\setminus", "\\varnothing"],
    [ne("\\{x\\}", "\\left\\{#0\\right\\}"), ne("|A|", "\\left|#0\\right|", "集合基数"), "\\mathbb{N}", "\\mathbb{Z}", "\\mathbb{Q}", "\\mathbb{R}", "\\times", "\\mathcal{P}"],
    [ne("\\binom{n}{k}", "\\binom{#?}{#?}", "组合数"), ne("n!", "#0!", "阶乘"), ne("\\sum", "\\sum_{#?}^{#?}#?"), "\\equiv", ne("\\pmod{n}", "\\pmod{#?}", "模运算"), "\\mapsto", "\\vdash", "\\models"]
  ]) },
  { id: "linear", label: "线性代数", layout: Yt("note-linear", [
    [ne("\\vec{a}", "\\vec{#0}", "向量"), ne("\\mathbf{A}", "\\mathbf{#0}", "粗体矩阵"), ne("A^{\\mathsf T}", "#0^{\\mathsf T}", "转置"), ne("A^{-1}", "#0^{-1}", "逆矩阵"), ne("\\det A", "\\det\\left(#?\\right)", "行列式"), ne("\\operatorname{rank}", "\\operatorname{rank}\\left(#?\\right)", "秩"), ne("\\operatorname{tr}", "\\operatorname{tr}\\left(#?\\right)", "迹"), "\\lambda"],
    [ne("\\lVert x\\rVert", "\\left\\lVert #0\\right\\rVert", "范数"), ne("\\langle u,v\\rangle", "\\left\\langle #?,#?\\right\\rangle", "内积"), "\\cdot", "\\times", "\\otimes", "\\perp", "\\mathbb{R}", "\\mathbb{C}"],
    [ne("\\operatorname{span}", "\\operatorname{span}\\left(#?\\right)"), ne("\\ker", "\\ker\\left(#?\\right)"), ne("\\operatorname{Im}", "\\operatorname{Im}\\left(#?\\right)"), ne("\\operatorname{diag}", "\\operatorname{diag}\\left(#?\\right)"), "\\alpha", "\\beta", "\\mu", "\\sigma"],
    ["a", "b", "x", "=", "\\sim", "\\cdots", "\\vdots", "\\ddots"]
  ]) },
  { id: "probability", label: "概率统计", layout: Yt("note-probability", [
    [ne("P(A)", "P\\left(#?\\right)", "概率"), ne("P(A\\mid B)", "P\\left(#?\\mid #?\\right)", "条件概率"), ne("E(X)", "E\\left(#?\\right)", "期望"), ne("\\operatorname{Var}", "\\operatorname{Var}\\left(#?\\right)", "方差"), ne("\\operatorname{Cov}", "\\operatorname{Cov}\\left(#?,#?\\right)", "协方差"), "\\mu", "\\sigma", "\\rho"],
    [ne("\\bar{x}", "\\bar{#0}", "均值"), ne("\\hat{\\theta}", "\\hat{#0}", "估计量"), ne("\\binom{n}{k}", "\\binom{#?}{#?}"), ne("n!", "#0!"), ne("\\sum", "\\sum_{i=1}^{#?}#?"), ne("\\prod", "\\prod_{i=1}^{#?}#?"), ne("\\frac{1}{n}", "\\frac{1}{#?}"), ne("x^2", "#0^2")],
    [ne("\\mathcal{N}", "\\mathcal{N}\\left(#?,#?\\right)", "正态分布"), ne("\\operatorname{Bin}", "\\operatorname{Bin}\\left(#?,#?\\right)", "二项分布"), ne("\\operatorname{Pois}", "\\operatorname{Pois}\\left(#?\\right)", "泊松分布"), "\\sim", "\\Phi", "\\phi", "\\chi^2", "\\alpha"],
    ["X", "Y", "n", "p", "\\cap", "\\cup", "\\le", "\\ge"]
  ]) },
  { id: "letters", label: "abc", layout: "alphabetic" },
  { id: "greek", label: "αβγ", layout: "greek" }
], al = [
  ["pmatrix", "圆括号 ( )"],
  ["bmatrix", "方括号 [ ]"],
  ["vmatrix", "行列式 | |"],
  ["Vmatrix", "双竖线 ‖ ‖"],
  ["Bmatrix", "花括号 { }"],
  ["matrix", "无括号"]
];
function il(t, n, r) {
  if (!Number.isInteger(t) || !Number.isInteger(n) || t < 1 || n < 1 || t > 10 || n > 10) throw new RangeError("Matrix dimensions must be between 1 and 10");
  if (!al.some(([a]) => a === r)) throw new RangeError("Unsupported matrix style");
  return `\\begin{${r}}${Array.from({ length: t }, () => Array(n).fill("#?").join(" & ")).join(" \\\\ ")}\\end{${r}}`;
}
const au = [
  ["basic", "常用"],
  ["letters", "字母"],
  ["calculus", "微积分"],
  ["discrete", "集合与逻辑"],
  ["linear", "线性代数"],
  ["probability", "概率统计"],
  ["relations", "关系与运算"],
  ["arrows", "箭头"],
  ["greek", "希腊字母"],
  ["accents", "修饰与括号"],
  ["fonts", "数学字体"]
], ll = [], Mr = /* @__PURE__ */ new Map();
function pt(t, n, r, a = n) {
  const i = Mr.get(a);
  if (i) {
    i.categories.includes(t) || i.categories.push(t), i.aliases += ` ${sn(r)}`, !/[\u3400-\u9fff]/.test(i.label) && /[\u3400-\u9fff]/.test(r) && (i.label = r);
    return;
  }
  const l = { id: encodeURIComponent(a), category: t, categories: [t], latex: n, label: r, insert: a, aliases: sn(r, n, a) };
  Mr.set(a, l), ll.push(l);
}
for (const t of ru)
  if (!(typeof t.layout == "string" || !("rows" in t.layout)))
    for (const n of t.layout.rows.slice(0, -1)) for (const r of n) {
      const a = typeof r == "string" ? r : r.latex;
      !a || a.startsWith("[") || pt(t.id, a, typeof r == "string" ? r.replaceAll("\\", "") : r.tooltip ?? a.replace(/\\textstyle\s*/g, "").replaceAll("\\", ""), typeof r == "string" ? r : r.insert ?? a);
    }
function kt(t, n) {
  for (const r of n.split("|")) {
    const [a, i] = r.split(":");
    pt(t, `\\${a}`, i?.split(" ")[0] ?? a), i && (Mr.get(`\\${a}`).aliases += ` ${sn(i)}`);
  }
}
kt("relations", "sim:相似 服从分布 波浪号 similar distributed|approx:约等于 近似等于 approximately|times:乘 叉乘 multiplication|cdot:点乘 点积|otimes:张量积 克罗内克积|perp:垂直 正交|pm:正负|ne:不等于|le:小于等于|ge:大于等于|equiv:恒等 等价|cdots:横向省略号|vdots:竖向省略号|ddots:对角省略号");
kt("discrete", "neg:逻辑非|land:逻辑与 合取|lor:逻辑或 析取|oplus:异或 直和|implies:蕴含 推出|iff:当且仅当 等价|forall:任意 全称量词|exists:存在 存在量词|in:属于|notin:不属于|subset:真子集|subseteq:子集 包含于|cup:并集|cap:交集|setminus:差集|varnothing:空集|mapsto:映射到|vdash:推导|models:满足 模型");
kt("relations", "leq:小于等于|geq:大于等于|neq:不等于|ll:远小于|gg:远大于|lesssim:小于或近似|gtrsim:大于或近似|lessapprox:小于或约等于|gtrapprox:大于或约等于|prec:先于|succ:后于|preceq:先于或等于|succeq:后于或等于|simeq:渐近相等|simcolon:相似冒号|simcoloncolon:相似双冒号|cong:全等|asymp:渐近等价|propto:成比例|doteq:定义等于|triangleq:定义等于三角|leqq:小于双等号|geqq:大于双等号|lneq:小于且不等于|gneq:大于且不等于|nless:不小于|ngtr:不大于|nleq:不小于等于|ngeq:不大于等于|ncong:不全等|nsim:不相似|parallel:平行|nparallel:不平行|mid:整除|nmid:不整除|mp:减加|div:除法|ast:星号乘法|star:星形运算|circ:复合运算|bullet:点积实心点|diamond:菱形运算|odot:圈点积|ominus:圈减|oslash:圈除|bigcirc:圆运算|amalg:并合|wr:环绕积|dagger:匕首伴随|ddagger:双匕首|angle:角|measuredangle:有向角|sphericalangle:球面角|degree:度");
kt("discrete", "ni:包含元素|subsetneq:真子集|supset:超集|supseteq:超集或相等|supsetneq:真超集|nsubseteq:不是子集|nsupseteq:不是超集|emptyset:空集|uplus:不交并|sqcup:方并|sqcap:方交|sqsubseteq:方子集|sqsupseteq:方超集|bigcup:大并集|bigcap:大交集|biguplus:大不交并|bigsqcup:大方并|bigvee:大析取|bigwedge:大合取|wedge:合取|vee:析取|lnot:逻辑非|nexists:不存在|top:真|bot:假|vDash:语义蕴涵|Vdash:强制|dashv:逆推出|nvdash:不可推导|nvDash:不语义蕴涵|therefore:所以|because:因为|aleph:阿列夫基数|beth:贝斯基数|complement:补集|triangleleft:左三角关系|triangleright:右三角关系");
kt("arrows", "leftarrow:左箭头|rightarrow:右箭头|leftrightarrow:双向箭头|Leftarrow:左双箭头|Rightarrow:右双箭头|Leftrightarrow:左右双箭头|longleftarrow:长左箭头|longrightarrow:长右箭头|longleftrightarrow:长双向箭头|Longleftarrow:长左双箭头|Longrightarrow:长右双箭头|Longleftrightarrow:长左右双箭头|longmapsto:长映射箭头|hookleftarrow:左钩箭头|hookrightarrow:右钩箭头|uparrow:上箭头|downarrow:下箭头|updownarrow:上下箭头|Uparrow:上双箭头|Downarrow:下双箭头|Updownarrow:上下双箭头|nearrow:右上箭头|searrow:右下箭头|swarrow:左下箭头|nwarrow:左上箭头|leftharpoonup:左上鱼叉|leftharpoondown:左下鱼叉|rightharpoonup:右上鱼叉|rightharpoondown:右下鱼叉|rightleftharpoons:可逆反应|leftrightharpoons:左右鱼叉|twoheadrightarrow:满射|twoheadleftarrow:左双头箭头|rightarrowtail:单射尾箭头|leftarrowtail:左尾箭头|rightsquigarrow:波浪箭头|leadsto:导向|curvearrowleft:左弯箭头|curvearrowright:右弯箭头|circlearrowleft:逆时针箭头|circlearrowright:顺时针箭头|nrightarrow:非右箭头|nleftarrow:非左箭头|nRightarrow:不蕴涵|nLeftrightarrow:不等价");
kt("greek", "alpha:阿尔法 alpha|beta:贝塔 beta|gamma:伽马 gamma|delta:德尔塔 delta|epsilon:艾普西隆 epsilon|zeta:泽塔 zeta|eta:伊塔 eta|theta:西塔 theta|iota:约塔 iota|kappa:卡帕 kappa|lambda:兰姆达 lambda|mu:缪 mu|nu:纽 nu|xi:克西 xi|omicron:奥米克戎 omicron|pi:派 pi|rho:柔 rho|sigma:西格玛 sigma|tau:陶 tau|upsilon:宇普西隆 upsilon|phi:斐 phi|chi:卡 chi|psi:普西 psi|omega:欧米伽 omega|Gamma:大写伽马|Delta:大写德尔塔|Theta:大写西塔|Lambda:大写兰姆达|Xi:大写克西|Pi:大写派|Sigma:大写西格玛|Upsilon:大写宇普西隆|Phi:大写斐|Psi:大写普西|Omega:大写欧米伽|varepsilon:变体艾普西隆|vartheta:变体西塔|varpi:变体派|varrho:变体柔|varsigma:末尾西格玛|varphi:变体斐|varkappa:变体卡帕");
kt("calculus", "partial:偏导 partial|infty:无穷 infinity|nabla:梯度 nabla|hbar:约化普朗克常量|ell:花体长度|Re:实部|Im:虚部|prime:一阶导撇号");
for (const [t, n] of Object.entries(rl)) pt("calculus", `\\${t}`, `${n} ${t}`, `\\${t}\\left(#?\\right)`);
for (const [t, n] of [["hat", "帽"], ["widehat", "宽帽"], ["bar", "横线"], ["overline", "上划线"], ["underline", "下划线"], ["vec", "向量"], ["overrightarrow", "右向量"], ["overleftarrow", "左向量"], ["overleftrightarrow", "双向量"], ["dot", "一阶点导数"], ["ddot", "二阶点导数"], ["tilde", "波浪修饰"], ["widetilde", "宽波浪"], ["check", "抑扬符"], ["breve", "短音符"], ["acute", "尖音符"], ["grave", "重音符"]]) pt("accents", `\\${t}{x}`, n, `\\${t}{#0}`);
for (const [t, n, r] of [["(", ")", "圆括号"], ["[", "]", "方括号"], ["\\{", "\\}", "集合花括号"], ["|", "|", "绝对值"], ["\\lVert", "\\rVert", "范数"], ["\\langle", "\\rangle", "内积括号"], ["\\lfloor", "\\rfloor", "向下取整"], ["\\lceil", "\\rceil", "向上取整"]]) pt("accents", `\\left${t} x\\right${n}`, r, `\\left${t} #0\\right${n}`);
for (const [t, n, r] of [["mathbb", "NZQRCFHP", "黑板粗体"], ["mathcal", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "花体"], ["mathfrak", "gabh", "哥特体"], ["mathbf", "ABuvx", "粗体"]]) for (const a of n) pt("fonts", `\\${t}{${a}}`, `${r} ${a}`);
for (const [t, n, r] of [
  ["\\underbrace{x+y}_{n}", "下括注", "\\underbrace{#0}_{#?}"],
  ["\\overbrace{x+y}^{n}", "上括注", "\\overbrace{#0}^{#?}"],
  ["\\overset{a}{=}", "上方标注", "\\overset{#?}{#0}"],
  ["\\underset{a}{=}", "下方标注", "\\underset{#?}{#0}"],
  ["\\xrightarrow{f}", "带标注箭头", "\\xrightarrow{#?}"],
  ["\\begin{aligned}a&=b\\\\c&=d\\end{aligned}", "多行对齐方程", "\\begin{aligned}#? &= #? \\\\ #? &= #?\\end{aligned}"]
]) pt("accents", t, n, r);
for (const t of "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") pt("letters", t, `字母 ${t}`);
const st = ll;
function iu(t) {
  const n = t.trim().toLowerCase().split(/\s+/);
  return st.filter((r) => n.every((a) => r.aliases.includes(a)));
}
const wt = "fp:math-preferences-changed";
let Tt;
function Th(t) {
  Tt = t, typeof window < "u" && window.dispatchEvent(new Event(wt));
}
const Gn = {
  getItem(t) {
    if (Tt) return Tt.getItem(t);
    try {
      return globalThis.localStorage?.getItem(t) ?? null;
    } catch {
      return null;
    }
  },
  setItem(t, n) {
    Tt ? Tt.setItem(t, n) : globalThis.localStorage?.setItem(t, n), typeof window < "u" && window.dispatchEvent(new Event(wt));
  }
};
async function lu() {
  await Tt?.refresh?.(), typeof window < "u" && window.dispatchEvent(new Event(wt));
}
const ol = "fp.math.symbols.v1";
function Oa() {
  try {
    const t = JSON.parse(Gn.getItem(ol) ?? "{}");
    return { favorites: Array.isArray(t.favorites) ? t.favorites.filter((n) => typeof n == "string") : [], recent: Array.isArray(t.recent) ? t.recent.filter((n) => typeof n == "string") : [] };
  } catch {
    return { favorites: [], recent: [] };
  }
}
const ou = new Map(st.map((t) => [t.id, vi.renderToString(t.latex, { throwOnError: !1, trust: !1, strict: !1 })]));
function su({ onInsert: t, shortcuts: n, onCommand: r }) {
  const [a, i] = k("basic"), [l, s] = k(""), [c, u] = k({}), [d, p] = k(8), [h, f] = k(Oa), [m, b] = k(null), g = B(null);
  Y(() => {
    const S = () => f(Oa());
    return window.addEventListener(wt, S), window.addEventListener("storage", S), () => {
      window.removeEventListener(wt, S), window.removeEventListener("storage", S);
    };
  }, []), Y(() => {
    if (!g.current) return;
    const S = () => {
      const D = g.current?.clientWidth ?? 0;
      p(Math.max(4, Math.min(20, Math.floor(D / 56))));
    };
    S();
    const A = new ResizeObserver(S);
    return A.observe(g.current), () => A.disconnect();
  }, []);
  const y = Ue(() => {
    if (l.trim()) {
      const S = new Set(n.filter((D) => D.trigger.toLowerCase().includes(l.toLowerCase())).map((D) => D.replacement)), A = new Set(iu(l));
      return st.filter((D) => A.has(D) || S.has(D.insert));
    }
    return a === "recent" ? h.recent.map((S) => st.find((A) => A.id === S)).filter((S) => !!S) : a === "favorites" ? st.filter((S) => h.favorites.includes(S.id)) : st.filter((S) => S.categories.includes(a));
  }, [a, l, h, n]), w = d * (d <= 7 ? 3 : 4), v = l ? `search:${l}` : a, N = Math.max(1, Math.ceil(y.length / w)), x = Math.min(c[v] ?? 0, N - 1), C = y.slice(x * w, (x + 1) * w), I = st.find((S) => S.id === m), L = I && n.find((S) => S.enabled && S.replacement === I.insert), K = (S) => {
    f(S);
    try {
      Gn.setItem(ol, JSON.stringify(S));
    } catch {
    }
  };
  return /* @__PURE__ */ o("div", { className: "math-symbol-palette", ref: g, children: [
    /* @__PURE__ */ e("div", { className: "math-keyboard-navigation", "aria-label": "键盘操作", children: [["undo", "撤销"], ["redo", "重做"], ["moveToPreviousChar", "←"], ["moveToNextChar", "→"], ["moveToPreviousPlaceholder", "上一空位"], ["moveToNextPlaceholder", "下一空位"], ["deleteBackward", "退格"]].map(([S, A]) => /* @__PURE__ */ e("button", { type: "button", onMouseDown: (D) => D.preventDefault(), onClick: () => r?.(S), children: A }, S)) }),
    /* @__PURE__ */ e("div", { className: "math-symbol-categories", role: "tablist", "aria-label": "符号分类", children: [["recent", "最近"], ["favorites", "收藏"], ...au].map(([S, A]) => /* @__PURE__ */ e("button", { type: "button", role: "tab", "aria-selected": !l && a === S, onMouseDown: (D) => D.preventDefault(), onClick: () => {
      i(S), s("");
    }, children: A }, S)) }),
    /* @__PURE__ */ o("div", { className: "math-symbol-search", children: [
      /* @__PURE__ */ e(We, { size: 15 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索数学符号", placeholder: "搜索名称、LaTeX 或快捷词", value: l, onChange: (S) => s(S.target.value) }),
      /* @__PURE__ */ o("span", { children: [
        y.length,
        " 项"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "math-symbol-grid", style: { gridTemplateColumns: `repeat(${d}, minmax(0, 1fr))` }, children: C.map((S) => /* @__PURE__ */ o("div", { className: "math-symbol-cell", children: [
      /* @__PURE__ */ e("button", { type: "button", className: "math-symbol-insert", "aria-label": `插入${S.label}`, title: `${S.label} · ${S.insert}`, onMouseDown: (A) => A.preventDefault(), onFocus: () => b(S.id), onMouseEnter: () => b(S.id), onClick: () => {
        t(S.insert), b(S.id), K({ ...h, recent: [S.id, ...h.recent.filter((A) => A !== S.id)].slice(0, 40) });
      }, children: /* @__PURE__ */ e("span", { "aria-hidden": "true", dangerouslySetInnerHTML: { __html: ou.get(S.id) ?? "" } }) }),
      /* @__PURE__ */ e("button", { type: "button", className: `math-symbol-star${h.favorites.includes(S.id) ? " is-favorite" : ""}`, "aria-label": `${h.favorites.includes(S.id) ? "取消收藏" : "收藏"}${S.label}`, "aria-pressed": h.favorites.includes(S.id), onMouseDown: (A) => A.preventDefault(), onClick: () => K({ ...h, favorites: h.favorites.includes(S.id) ? h.favorites.filter((A) => A !== S.id) : [...h.favorites, S.id] }), children: /* @__PURE__ */ e(sa, { size: 10 }) })
    ] }, S.id)) }),
    !y.length && /* @__PURE__ */ e("p", { className: "note-math-status", children: l ? "没有找到匹配符号，请尝试名称或 LaTeX 命令。" : a === "favorites" ? "选择符号后点按星标，将常用符号放在这里。" : "使用过的符号会显示在这里。" }),
    /* @__PURE__ */ o("div", { className: "math-symbol-footer", children: [
      I && /* @__PURE__ */ e("button", { type: "button", className: "math-mobile-favorite", "aria-label": `${h.favorites.includes(I.id) ? "取消收藏" : "收藏"}${I.label}`, onClick: () => K({ ...h, favorites: h.favorites.includes(I.id) ? h.favorites.filter((S) => S !== I.id) : [...h.favorites, I.id] }), children: /* @__PURE__ */ e(sa, { size: 18 }) }),
      /* @__PURE__ */ e("span", { className: "math-symbol-detail", children: I ? /* @__PURE__ */ o(Q, { children: [
        I.label,
        " ",
        /* @__PURE__ */ e("code", { children: I.insert }),
        L && /* @__PURE__ */ o("kbd", { children: [
          L.trigger,
          L.mode === "tab" ? " ⇥" : ""
        ] })
      ] }) : "选中公式片段后，点击符号可替换选区" }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上一页符号", disabled: x === 0, onMouseDown: (S) => S.preventDefault(), onClick: () => u((S) => ({ ...S, [v]: x - 1 })), children: /* @__PURE__ */ e(Tr, { size: 14 }) }),
        /* @__PURE__ */ o("span", { "aria-live": "polite", children: [
          x + 1,
          " / ",
          N
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下一页符号", disabled: x + 1 >= N, onMouseDown: (S) => S.preventDefault(), onClick: () => u((S) => ({ ...S, [v]: x + 1 })), children: /* @__PURE__ */ e(ze, { size: 14 }) })
      ] })
    ] })
  ] });
}
const sl = "fp.math.shortcuts.v1", cu = { a: "alpha", b: "beta", g: "gamma", d: "delta", e: "epsilon", z: "zeta", h: "eta", t: "theta", i: "iota", k: "kappa", l: "lambda", m: "mu", n: "nu", x: "xi", p: "pi", r: "rho", s: "sigma", u: "upsilon", f: "phi", c: "chi", j: "psi", o: "omega", G: "Gamma", D: "Delta", T: "Theta", L: "Lambda", X: "Xi", P: "Pi", S: "Sigma", U: "Upsilon", F: "Phi", J: "Psi", O: "Omega" }, cl = [
  { trigger: "mat", replacement: "\\begin{pmatrix}#?\\end{pmatrix}", mode: "tab", enabled: !0, kind: "matrix" },
  ...Object.entries(cu).map(([t, n]) => ({ trigger: `@${t}`, replacement: `\\${n}`, mode: "auto", enabled: !0 })),
  { trigger: "//", replacement: "\\frac{#?}{#?}", mode: "auto", enabled: !0 },
  ...[["sum", "\\sum_{#?}^{#?}#?"], ["lim", "\\lim_{#?\\to #?}#?"], ["sqrt", "\\sqrt{#?}"], ["int", "\\int_{#?}^{#?}#?\\,d x"], ["cases", "\\begin{cases}#? & #? \\\\ #? & #?\\end{cases}"], ["vec", "\\vec{#?}"], ["frac", "\\frac{#?}{#?}"]].map(([t, n]) => ({ trigger: t, replacement: n, mode: "tab", enabled: !0 }))
];
function du(t, n) {
  const r = t.match(/(10|[1-9])x(10|[1-9])$/);
  if (!r) return null;
  const a = n.find((i) => i.kind === "matrix" && i.enabled && t.endsWith(i.trigger + r[0]));
  return a ? { length: a.trigger.length + r[0].length, replacement: il(Number(r[1]), Number(r[2]), "pmatrix") } : null;
}
function dl(t) {
  const n = /* @__PURE__ */ new Set();
  for (const a of t) {
    if (!a.trigger.trim() || /\s/.test(a.trigger) || a.trigger.length > 40 || !a.replacement.trim()) return "请填写有效的触发词和公式，触发词不能含空格。";
    if (n.has(a.trigger)) return `触发词 ${a.trigger} 重复，请修改。`;
    n.add(a.trigger);
  }
  const r = t.filter((a) => a.enabled && a.mode === "auto");
  for (const a of r) for (const i of r) if (a !== i && i.trigger.startsWith(a.trigger)) return `${a.trigger} 与 ${i.trigger} 会提前触发，请改用 Tab 展开。`;
  return null;
}
function Ra() {
  try {
    const t = JSON.parse(Gn.getItem(sl) ?? "null");
    if (Array.isArray(t) && t.every((n) => n && typeof n.trigger == "string" && typeof n.replacement == "string" && ["auto", "tab"].includes(n.mode) && typeof n.enabled == "boolean") && !dl(t)) return t;
  } catch {
  }
  return cl.map((t) => ({ ...t }));
}
function uu(t, n, r) {
  const a = t.inlineShortcuts, i = { ...a };
  for (const u of Object.keys(i))
    (u === "@" || n.some((d) => d.enabled && d.trigger.startsWith(u) && d.trigger !== u)) && delete i[u];
  for (const u of n)
    delete i[u.trigger], u.enabled && u.mode === "auto" && (i[u.trigger] = u.replacement);
  i["*"] = "\\ast", t.inlineShortcuts = i, t.inlineShortcutTimeout = 0;
  let l = [];
  const s = () => {
    l = [];
  }, c = (u) => {
    if (u.isComposing || u.keyCode === 229 || u.ctrlKey || u.metaKey || u.altKey) {
      s();
      return;
    }
    if (u.key === "Tab" && !u.shiftKey) {
      const d = l.map((g) => g.key).join(""), p = [...n].filter((g) => g.enabled && g.mode === "tab" && d.endsWith(g.trigger)).sort((g, y) => y.trigger.length - g.trigger.length)[0], h = du(d, n), f = p?.replacement ?? h?.replacement, m = p?.trigger.length ?? h?.length ?? 0, b = l[l.length - m]?.position;
      if (f && b !== void 0 && t.position >= b) {
        u.preventDefault(), u.stopImmediatePropagation(), t.selection = { ranges: [[b, t.position]] }, t.insert(f, { selectionMode: "placeholder" }), r(), s();
        return;
      }
    }
    u.key.length === 1 ? (l.push({ key: u.key, position: t.position }), l = l.slice(-64)) : s();
  };
  return t.addEventListener("keydown", c, !0), t.addEventListener("pointerdown", s), t.addEventListener("blur", s), () => {
    t.removeEventListener("keydown", c, !0), t.removeEventListener("pointerdown", s), t.removeEventListener("blur", s), t.isConnected && (t.inlineShortcuts = a);
  };
}
function pu({ rules: t, onSave: n, onClose: r }) {
  const [a, i] = k(t.map((p) => ({ ...p }))), [l, s] = k(""), [c, u] = k(""), d = (p, h) => {
    i((f) => f.map((m, b) => b === p ? { ...m, ...h } : m)), u("");
  };
  return /* @__PURE__ */ o("section", { className: "math-shortcut-settings", "aria-label": "公式快捷输入设置", children: [
    /* @__PURE__ */ o("div", { className: "math-shortcut-heading", children: [
      /* @__PURE__ */ e("strong", { children: "快捷输入" }),
      /* @__PURE__ */ e("input", { "aria-label": "查找快捷规则", placeholder: "查找触发词或命令", value: l, onChange: (p) => s(p.target.value) }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        i(cl.map((p) => ({ ...p }))), u("");
      }, children: "恢复默认" })
    ] }),
    /* @__PURE__ */ e("p", { children: "触屏可使用数学键盘；使用实体键盘时，在公式中输入 @a 得到 α；sum 后按 Tab 展开求和。mat3x4 后按 Tab 插入矩阵。Tab / Shift+Tab 切换占位框。" }),
    /* @__PURE__ */ e("div", { className: "math-shortcut-list", children: a.map((p, h) => `${p.trigger} ${p.replacement}`.toLowerCase().includes(l.toLowerCase()) ? /* @__PURE__ */ o("div", { className: "math-shortcut-row", children: [
      /* @__PURE__ */ e("input", { type: "checkbox", "aria-label": `启用规则 ${h + 1}`, checked: p.enabled, onChange: (f) => d(h, { enabled: f.target.checked }) }),
      /* @__PURE__ */ e("input", { "aria-label": `触发词 ${h + 1}`, value: p.trigger, onChange: (f) => d(h, { trigger: f.target.value }) }),
      /* @__PURE__ */ e("input", { "aria-label": `替换公式 ${h + 1}`, readOnly: p.kind === "matrix", value: p.kind === "matrix" ? "接行数 x 列数，例如 3x4（1–10）" : p.replacement, onChange: (f) => d(h, { replacement: f.target.value }) }),
      /* @__PURE__ */ e(ke, { label: `触发方式 ${h + 1}`, disabled: p.kind === "matrix", value: p.mode, onChange: (f) => d(h, { mode: f }), options: [{ value: "auto", label: "自动" }, { value: "tab", label: "Tab" }] }),
      /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除规则 ${h + 1}`, onClick: () => i((f) => f.filter((m, b) => b !== h)), children: "×" })
    ] }, h) : null) }),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    /* @__PURE__ */ o("div", { className: "math-shortcut-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        s(""), i((p) => [...p, { trigger: "", replacement: "", mode: "tab", enabled: !0 }]);
      }, children: "添加规则" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => i((p) => p.map((h) => ({ ...h, enabled: !1 }))), children: "全部停用" }),
      /* @__PURE__ */ e("span", {}),
      /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "取消" }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => {
        const p = dl(a);
        if (p) {
          u(p);
          return;
        }
        try {
          Gn.setItem(sl, JSON.stringify(a));
        } catch {
          u("浏览器无法保存设置，请检查存储权限。");
          return;
        }
        n(a), r();
      }, children: "保存规则" })
    ] })
  ] });
}
function hu({ anchor: t, items: n, activeId: r, onSelect: a, label: i = "输入建议" }) {
  const l = B(null), s = Ut(t, n.length > 0), [c, u] = k({ left: 8, top: 8, maxHeight: 280 });
  return Ce(() => {
    if (!n.length) return;
    const d = () => {
      if (!t.current || !l.current) return;
      const p = t.current.getBoundingClientRect(), h = l.current.getBoundingClientRect(), f = innerHeight - p.bottom - 16, m = p.top - 16, b = f < Math.min(h.height, 180) && m > f, g = Math.max(80, Math.min(280, b ? m : f));
      u({ left: Math.max(8, Math.min(p.left, innerWidth - h.width - 8)), top: b ? Math.max(8, p.top - Math.min(h.height, g) - 6) : p.bottom + 6, maxHeight: g });
    };
    return d(), window.addEventListener("resize", d), document.addEventListener("scroll", d, !0), () => {
      window.removeEventListener("resize", d), document.removeEventListener("scroll", d, !0);
    };
  }, [t, n]), Ce(() => {
    l.current?.querySelector('[aria-selected="true"]')?.scrollIntoView?.({ block: "nearest" });
  }, [r]), n.length ? De(/* @__PURE__ */ e("div", { ref: l, role: "listbox", "aria-label": i, className: "fp-popup-panel fp-suggestion-list", style: { ...s, ...c }, onPointerDown: (d) => d.preventDefault(), children: n.map((d) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": d.id === r, onClick: () => a(d.id), children: [
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: d.label }),
      d.detail && /* @__PURE__ */ e("small", { children: d.detail })
    ] }),
    d.preview && /* @__PURE__ */ e("span", { className: "fp-suggestion-preview", children: d.preview })
  ] }, d.id)) }), document.body) : null;
}
let Ba = 0;
function fu({ anchor: t }) {
  const n = B(null), [r, a] = k([]);
  return Y(() => {
    let i;
    const l = () => {
      const u = n.current, d = t.current?.contains(document.activeElement) && u?.classList.contains("is-visible") ? [...u.querySelectorAll("li[data-command]")].map((p) => {
        const h = p.dataset.command;
        return { id: h, label: st.find((f) => f.latex === h)?.label || h, markup: p.querySelector(".ML__popover__command")?.innerHTML || "", active: p.classList.contains("ML__popover__current") };
      }) : [];
      a((p) => JSON.stringify(p) === JSON.stringify(d) ? p : d);
    }, s = () => {
      const u = document.getElementById("mathlive-suggestion-popover");
      u !== n.current && (i?.disconnect(), n.current = u, u && (u.setAttribute("aria-hidden", "true"), i = new MutationObserver(l), i.observe(u, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["class", "style"] })), l());
    };
    Ba++, document.documentElement.dataset.fpMathCandidates = "true", document.addEventListener("focusin", l), document.addEventListener("focusout", l);
    const c = new MutationObserver(s);
    return c.observe(document.body, { childList: !0 }), s(), () => {
      c.disconnect(), i?.disconnect(), document.removeEventListener("focusin", l), document.removeEventListener("focusout", l), --Ba === 0 && (n.current?.removeAttribute("aria-hidden"), delete document.documentElement.dataset.fpMathCandidates);
    };
  }, []), /* @__PURE__ */ e(hu, { anchor: t, label: "公式输入建议", activeId: r.find((i) => i.active)?.id, items: r.map((i) => ({ id: i.id, label: i.label, detail: i.id, preview: /* @__PURE__ */ e("span", { dangerouslySetInnerHTML: { __html: i.markup } }) })), onSelect: (i) => {
    [...n.current?.querySelectorAll("li[data-command]") || []].find((s) => s.dataset.command === i)?.dispatchEvent(new MouseEvent("click", { bubbles: !0 }));
  } });
}
const wn = /* @__PURE__ */ new WeakMap();
function ul(t) {
  wn.get(t)?.();
}
function mu(t, n, r, a) {
  ul(t);
  const i = { duration: 220, easing: "cubic-bezier(.2,0,0,1)" }, l = t.animate([{ height: `${r}px`, overflow: "clip" }, { height: `${a}px`, overflow: "clip" }], i), s = t.animate([{ opacity: 0 }, { opacity: 0, offset: 0.35 }, { opacity: 1 }], i), c = n.animate([{ height: `${r}px`, opacity: 1 }, { height: `${a}px`, opacity: 0 }], i), u = () => {
    wn.get(t) === u && (wn.delete(t), n.remove(), l.cancel(), s.cancel(), c.cancel());
  };
  wn.set(t, u), c.onfinish = u, c.oncancel = u;
}
const bu = [
  ["分数", "\\frac{#0}{#?}"],
  ["根号", "\\sqrt{#0}"],
  ["上标", "#0^{#?}"],
  ["下标", "#0_{#?}"],
  ["积分", "\\int_{#?}^{#?} #? \\,d#?"],
  ["求和", "\\sum_{#?}^{#?} #?"]
], Jt = /* @__PURE__ */ new WeakMap();
function Dh(t, n, r) {
  const a = () => Jt.set(t, { editor: n, open: r }), i = (l) => {
    (!(l.target instanceof Element) || !l.target.closest(".visual-directive-editor,.fp-card-editor-frame")) && Jt.delete(t);
  };
  return n.on("focus", a), t.view.dom.addEventListener("pointerdown", i, !0), a(), () => {
    n.off("focus", a), t.view.dom.removeEventListener("pointerdown", i, !0), Jt.get(t)?.editor === n && Jt.delete(t);
  };
}
function Ph(t, n, r) {
  const a = Jt.get(t);
  a && !a.editor.isDestroyed && a.editor.view.dom.isConnected ? a.open(a.editor, n) : r(t, n);
}
function lr(t) {
  mi.getState(t.state)?.undoManager.stopCapturing(), t.view.dispatch(fi(t.state.tr));
}
function gu() {
  const [t, n] = k(null), r = B(null), a = xe((l) => {
    if (l && r.current?.id !== l) return;
    const s = r.current;
    r.current = null, n(null), s && !s.editor.isDestroyed && lr(s.editor);
  }, []);
  return {
    open: xe(
      (l, s, c, u) => {
        if (!l.isEditable) return;
        if (c === void 0) {
          lr(l);
          const f = u ?? l.state.selection;
          l.chain().insertContentAt(
            { from: f.from, to: f.to },
            {
              type: s ? "blockMath" : "inlineMath",
              attrs: { latex: "" }
            }
          ).command(({ tr: m }) => (m.mapping.maps.at(-1)?.forEach((b, g, y, w) => {
            m.doc.nodesBetween(y, w, (v, N) => {
              if (v.type.name === (s ? "blockMath" : "inlineMath"))
                return c = N, !1;
            });
          }), !0)).run();
        }
        if (c === void 0) return;
        const d = l.view.nodeDOM(c), p = d?.querySelector(".math-node-editor-slot");
        if (!d?.mathPosition || !p || r.current?.host === d)
          return;
        a(), lr(l);
        const h = {
          id: crypto.randomUUID(),
          editor: l,
          display: s,
          host: d,
          slot: p,
          collapsedHeight: d.getBoundingClientRect().height,
          original: String(l.state.doc.nodeAt(c)?.attrs.latex ?? "")
        };
        r.current = h, n(h);
      },
      [a]
    ),
    card: t ? /* @__PURE__ */ e(vu, { session: t, onClose: a }, t.id) : null
  };
}
function vu({
  session: t,
  onClose: n
}) {
  const r = xe(
    () => n(t.id),
    [n, t.id]
  ), [a, i] = k(t.original), l = B(t.original), [s, c] = k(!1), [u, d] = k(
    "loading"
  ), [p, h] = k(
    () => typeof window < "u" && !!window.matchMedia?.("(pointer: coarse)").matches
  ), [f, m] = k(!1), [b, g] = k(Ra), y = B(!1), [w, v] = k(!1), [N, x] = k(3), [C, I] = k(3), [L, K] = k("pmatrix"), [S, A] = k(""), D = B(null), U = B(null), j = B(null), T = B(null), M = xe(
    (E) => {
      const z = t.host.mathPosition();
      if (z === void 0 || t.editor.isDestroyed) return;
      const $ = t.editor.state.doc.nodeAt(z);
      !$ || !["inlineMath", "blockMath"].includes($.type.name) || (l.current = E, i(E), $.attrs.latex !== E && t.editor.view.dispatch(
        t.editor.state.tr.setNodeMarkup(z, void 0, {
          ...$.attrs,
          latex: E
        })
      ));
    },
    [t]
  );
  Ce(() => {
    ul(
      t.display ? t.host : t.host.closest("p, li, td") || t.host
    ), t.host.classList.add("is-math-editing"), t.host.setAttribute("draggable", "false");
    const E = t.display ? null : t.host.closest("p"), z = t.editor.view.dom, $ = z.style.getPropertyValue(
      "--fp-inline-math-space"
    ), P = () => {
      E && z.style.setProperty(
        "--fp-inline-math-space",
        `${t.slot.getBoundingClientRect().height + 12}px`
      );
    };
    P();
    const re = E && typeof ResizeObserver < "u" ? new ResizeObserver(P) : null;
    re?.observe(t.slot);
    const ie = () => {
      const he = t.host.mathPosition();
      if (he === void 0 || !t.host.isConnected) {
        r();
        return;
      }
      const W = t.editor.state.doc.nodeAt(he);
      if (!W || !["inlineMath", "blockMath"].includes(W.type.name)) {
        r();
        return;
      }
      const G = String(W.attrs.latex ?? "");
      G !== l.current && (l.current = G, i(G), j.current?.setValue(G, { silenceNotifications: !0 }));
    }, ye = (he) => {
      !t.host.contains(he.target) && !he.target.closest?.(".fp-popup-panel, #mathlive-suggestion-popover") && r();
    };
    return t.editor.on("transaction", ie), t.editor.on("destroy", r), document.addEventListener("pointerdown", ye), () => {
      const he = t.host, W = t.display ? he : he.closest("p, li, td") || he, G = W.getBoundingClientRect(), ue = W.cloneNode(!0);
      ue.querySelectorAll("math-field").forEach((V) => {
        const oe = he.querySelector(".math-node-content")?.cloneNode(!0);
        oe ? (oe.style.display = "block", V.replaceWith(oe)) : V.remove();
      }), re?.disconnect(), t.slot.style.display = "none";
      const me = z.style.getPropertyValue(
        "--fp-inline-math-space"
      );
      $ ? z.style.setProperty("--fp-inline-math-space", $) : z.style.removeProperty("--fp-inline-math-space"), he.classList.remove("is-math-editing");
      const H = W.getBoundingClientRect();
      if (t.slot.style.removeProperty("display"), W.isConnected && typeof W.animate == "function" && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
        const V = document.createElement("div");
        V.className = "fp-markdown-editor fp-formula-closing", V.style.setProperty("--fp-inline-math-space", me), V.inert = !0, V.setAttribute("aria-hidden", "true"), Object.assign(V.style, {
          position: "absolute",
          left: `${G.left + window.scrollX}px`,
          top: `${G.top + window.scrollY}px`,
          width: `${G.width}px`,
          height: `${G.height}px`,
          overflow: "clip",
          pointerEvents: "none",
          zIndex: "20"
        }), ue.style.margin = "0", ue.querySelectorAll("[id]").forEach((_) => _.removeAttribute("id"));
        const oe = document.createElement("div");
        oe.className = "fp-editor-prose", Object.assign(oe.style, { padding: "0", minHeight: "0" }), oe.append(ue), V.append(oe), document.body.append(V), mu(W, V, G.height, H.height);
      }
      t.editor.off("transaction", ie), t.editor.off("destroy", r), document.removeEventListener("pointerdown", ye);
    };
  }, [t, r]), Y(() => {
    let E = !0, z = () => {
    };
    return document.documentElement.dataset.mathEditing = "true", document.dispatchEvent(new Event("fp:math-open")), D.current?.focus(), (async () => {
      try {
        const { MathfieldElement: $ } = await import("mathlive");
        if (await Promise.resolve({                   }), !E || !U.current) return;
        const P = new $();
        P.className = "note-math-live", P.mathVirtualKeyboardPolicy = "manual", P.smartFence = !0, P.smartMode = !1, P.environmentPopoverPolicy = "off", P.maxMatrixCols = 10, P.setAttribute("aria-label", "公式内容");
        const re = new Promise(
          (W) => P.addEventListener("mount", () => W(), { once: !0 })
        );
        if (U.current.append(P), z = () => {
          P.remove(), j.current = null;
        }, await re, !E) return;
        P.menuItems = [], P.setValue(l.current, { silenceNotifications: !0 }), j.current = P;
        const ie = window.mathVirtualKeyboard;
        ie.hide();
        const ye = () => M(P.getValue("latex-unstyled"));
        P.addEventListener("input", ye);
        const he = () => {
          y.current = !1;
        };
        P.addEventListener("focus", he), z = () => {
          ie.hide(), P.removeEventListener("input", ye), P.removeEventListener("focus", he), P.remove(), j.current = null;
        }, d("ready"), document.activeElement !== T.current && P.focus();
      } catch ($) {
        z(), console.warn("Formula input initialization failed", $), E && (d("fallback"), c(!0));
      }
    })(), () => {
      E = !1, z(), delete document.documentElement.dataset.mathEditing;
    };
  }, [M]), Y(() => {
    const E = () => g(Ra()), z = () => {
      lu();
    };
    return window.addEventListener(wt, E), window.addEventListener("storage", E), window.addEventListener("focus", z), z(), () => {
      window.removeEventListener(wt, E), window.removeEventListener("storage", E), window.removeEventListener("focus", z);
    };
  }, []), Y(() => {
    if (u !== "ready" || !j.current) return;
    const E = j.current;
    return uu(
      E,
      b,
      () => M(E.getValue("latex-unstyled"))
    );
  }, [u, b, M]);
  const R = (E) => {
    const z = j.current;
    if (!z) return;
    z.focus();
    const $ = z.executeCommand(E);
    A($ ? "" : "请将光标放在矩阵内；每行最多 10 列。"), $ && M(z.getValue("latex-unstyled"));
  }, q = (E = !1) => {
    const z = t.editor, $ = t.host.mathPosition();
    if ($ === void 0 || z.isDestroyed) {
      r();
      return;
    }
    const P = z.state.doc.nodeAt($);
    if (E && P && z.commands.deleteRange({ from: $, to: $ + P.nodeSize }), r(), !z.isDestroyed) {
      const re = Math.min(
        $ + (E ? 0 : P?.nodeSize ?? 0),
        z.state.doc.content.size
      );
      z.view.dispatch(
        z.state.tr.setSelection(
          Sn.near(z.state.doc.resolve(re), 1)
        )
      ), z.commands.focus(void 0, { scrollIntoView: !1 });
    }
  }, F = (E) => {
    const z = j.current;
    if (z && !y.current)
      z.focus(), z.insert(E, { selectionMode: "placeholder" }), M(z.getValue("latex-unstyled"));
    else {
      const $ = T.current, P = $?.selectionStart ?? l.current.length, re = $?.selectionEnd ?? P, ie = E.replaceAll("#0", l.current.slice(P, re)).replaceAll("#?", ""), ye = l.current.slice(0, P) + ie + l.current.slice(re);
      M(ye), z?.setValue(ye, { silenceNotifications: !0 }), $?.focus(), requestAnimationFrame(
        () => $?.setSelectionRange(P + ie.length, P + ie.length)
      );
    }
  };
  return De(
    /* @__PURE__ */ o(fe, { initialHeight: t.collapsedHeight, children: [
      /* @__PURE__ */ e(fu, { anchor: U }),
      /* @__PURE__ */ o(
        "div",
        {
          className: "note-math-card inline-card-expansion",
          ref: D,
          role: "group",
          "aria-label": t.display ? "编辑独立公式" : "编辑行内公式",
          tabIndex: -1,
          onPointerDown: (E) => E.stopPropagation(),
          onClick: (E) => E.stopPropagation(),
          onDoubleClick: (E) => E.stopPropagation(),
          onContextMenu: (E) => E.stopPropagation(),
          onKeyDownCapture: (E) => {
            if (!(E.nativeEvent.isComposing || E.nativeEvent.keyCode === 229) && !(E.target === j.current && j.current?.mode === "latex")) {
              if (!t.display && E.key === "Enter" && !E.shiftKey && !(E.target instanceof HTMLButtonElement)) {
                E.preventDefault(), E.stopPropagation(), q();
                return;
              }
              if (t.display && E.key === "Enter" && !E.ctrlKey && !E.metaKey && E.target === j.current) {
                E.preventDefault(), E.stopPropagation(), j.current?.executeCommand("addRowAfter"), j.current && M(j.current.getValue("latex-unstyled"));
                return;
              }
              (E.key === "Escape" || E.key === "Enter" && (E.ctrlKey || E.metaKey)) && (E.preventDefault(), E.stopPropagation(), q());
            }
          },
          onKeyDown: (E) => E.stopPropagation(),
          children: [
            /* @__PURE__ */ o("div", { className: "note-math-topline", children: [
              /* @__PURE__ */ o("span", { className: "note-math-title", children: [
                "∑ ",
                /* @__PURE__ */ e("span", { children: t.display ? "独立公式" : "行内公式" })
              ] }),
              /* @__PURE__ */ o("div", { className: "note-math-controls", children: [
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    title: "LaTeX 源码",
                    "aria-label": "LaTeX 源码",
                    "aria-expanded": s,
                    disabled: u === "fallback",
                    onClick: () => c((E) => !E),
                    children: [
                      /* @__PURE__ */ e(Lr, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "源码" })
                    ]
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    "aria-label": "数学键盘",
                    "aria-expanded": p,
                    onClick: () => {
                      h((E) => !E), window.mathVirtualKeyboard?.hide();
                    },
                    children: [
                      /* @__PURE__ */ e(ti, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "键盘" })
                    ]
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "快捷输入设置",
                    "aria-expanded": f,
                    onClick: () => m((E) => !E),
                    children: /* @__PURE__ */ e(Zl, { size: 15 })
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "note-math-delete",
                    title: "删除公式",
                    "aria-label": "删除公式",
                    onClick: () => q(!0),
                    children: /* @__PURE__ */ e(Ht, { size: 15 })
                  }
                ),
                /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    className: "note-math-done",
                    "aria-label": "收起",
                    title: "收起 · Ctrl/⌘+Enter",
                    onClick: () => q(),
                    children: [
                      /* @__PURE__ */ e(Pe, { size: 15 }),
                      /* @__PURE__ */ e("span", { children: "完成" })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-writing", children: [
              u === "loading" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "正在准备公式输入…" }),
              /* @__PURE__ */ e(
                "div",
                {
                  ref: U,
                  className: "note-math-live-host",
                  hidden: u === "fallback"
                }
              ),
              s && /* @__PURE__ */ o("label", { className: "note-math-source-label", children: [
                "LaTeX",
                /* @__PURE__ */ e(
                  "textarea",
                  {
                    ref: T,
                    "aria-label": "LaTeX 源码",
                    className: "note-math-source",
                    rows: 2,
                    value: a,
                    spellCheck: !1,
                    onFocus: () => {
                      y.current = !0;
                    },
                    onChange: (E) => {
                      M(E.target.value), j.current?.setValue(E.target.value, {
                        silenceNotifications: !0
                      });
                    }
                  }
                )
              ] }),
              u === "fallback" && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: "可直接输入 LaTeX 公式。" })
            ] }),
            /* @__PURE__ */ o("div", { className: "note-math-tools", role: "toolbar", "aria-label": "公式结构", children: [
              bu.map(([E, z]) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  disabled: u === "loading" && !s,
                  onMouseDown: ($) => $.preventDefault(),
                  onClick: () => F(z),
                  children: E
                },
                E
              )),
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  "aria-expanded": w,
                  onMouseDown: (E) => E.preventDefault(),
                  onClick: () => {
                    v((E) => !E), A("");
                  },
                  children: [
                    /* @__PURE__ */ e(eo, { size: 14 }),
                    "矩阵"
                  ]
                }
              )
            ] }),
            w && /* @__PURE__ */ o(
              "div",
              {
                className: "note-matrix-builder",
                role: "group",
                "aria-label": "矩阵设置",
                children: [
                  /* @__PURE__ */ o("div", { className: "note-matrix-settings", children: [
                    /* @__PURE__ */ o("label", { children: [
                      "行",
                      /* @__PURE__ */ e(
                        ke,
                        {
                          label: "矩阵行数",
                          value: String(N),
                          onChange: (E) => x(Number(E)),
                          options: Array.from({ length: 10 }, (E, z) => ({
                            value: String(z + 1),
                            label: String(z + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "×" }),
                    /* @__PURE__ */ o("label", { children: [
                      "列",
                      /* @__PURE__ */ e(
                        ke,
                        {
                          label: "矩阵列数",
                          value: String(C),
                          onChange: (E) => I(Number(E)),
                          options: Array.from({ length: 10 }, (E, z) => ({
                            value: String(z + 1),
                            label: String(z + 1)
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o("label", { children: [
                      "括号",
                      /* @__PURE__ */ e(
                        ke,
                        {
                          label: "矩阵括号",
                          value: L,
                          onChange: (E) => K(E),
                          options: al.map(([E, z]) => ({
                            value: E,
                            label: z
                          }))
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        className: "note-matrix-insert",
                        disabled: u === "loading" && !s,
                        onMouseDown: (E) => E.preventDefault(),
                        onClick: () => {
                          F(
                            il(N, C, L)
                          ), v(!1);
                        },
                        children: [
                          "插入 ",
                          N,
                          " × ",
                          C
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-presets", children: [
                    /* @__PURE__ */ e("span", { children: "常用" }),
                    [
                      [1, 3],
                      [3, 1],
                      [2, 2],
                      [3, 3],
                      [4, 4],
                      [3, 4]
                    ].map(([E, z]) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": N === E && C === z,
                        onClick: () => {
                          x(E), I(z);
                        },
                        children: [
                          E,
                          " × ",
                          z
                        ]
                      },
                      `${E}-${z}`
                    ))
                  ] }),
                  /* @__PURE__ */ o("div", { className: "note-matrix-actions", children: [
                    /* @__PURE__ */ e("span", { children: "光标所在矩阵" }),
                    [
                      ["增行", "addRowAfter"],
                      ["增列", "addColumnAfter"],
                      ["删行", "removeRow"],
                      ["删列", "removeColumn"]
                    ].map(([E, z]) => /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        disabled: u !== "ready" || s,
                        onMouseDown: ($) => $.preventDefault(),
                        onClick: () => R(z),
                        children: E
                      },
                      z
                    ))
                  ] }),
                  S && /* @__PURE__ */ e("span", { className: "note-math-status", role: "status", children: S })
                ]
              }
            ),
            t.display && /* @__PURE__ */ o("div", { className: "note-math-line-actions", children: [
              /* @__PURE__ */ o(
                "button",
                {
                  type: "button",
                  onMouseDown: (E) => E.preventDefault(),
                  onClick: () => {
                    const E = j.current;
                    E && (E.focus(), E.executeCommand("addRowAfter"), M(E.getValue("latex-unstyled")));
                  },
                  children: [
                    /* @__PURE__ */ e(Ja, { size: 14 }),
                    "换行"
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  onMouseDown: (E) => E.preventDefault(),
                  onClick: () => F("\\begin{aligned}#0 &= #? \\\\ #? &= #?\\end{aligned}"),
                  children: "对齐多行"
                }
              ),
              /* @__PURE__ */ e("span", { children: "Enter 换行 · Ctrl/⌘+Enter 完成" })
            ] }),
            f && /* @__PURE__ */ e(
              pu,
              {
                rules: b,
                onSave: g,
                onClose: () => m(!1)
              }
            ),
            p && /* @__PURE__ */ e(
              su,
              {
                onInsert: F,
                shortcuts: b,
                onCommand: (E) => {
                  const z = j.current;
                  z && (z.focus(), z.executeCommand(E), M(z.getValue("latex-unstyled")));
                }
              }
            )
          ]
        }
      )
    ] }),
    t.slot
  );
}
function yu(t) {
  const { node: n, updateAttributes: r, editor: a, deleteNode: i, getPos: l } = t, [s, c] = k(() => Ni(a, n.attrs.id)), u = B(null), d = B(!1), p = () => {
    c(!1), Es(a, l);
  }, h = B(null), f = B(String(n.attrs.body || ""));
  Y(() => {
    s && (Ms(a, n.attrs.id), requestAnimationFrame(() => u.current?.focus()));
  }, [s]), Y(() => {
    const b = String(n.attrs.body || "");
    h.current && !h.current.isDestroyed && b !== f.current && (h.current.commands.setContent(nl(b), {
      emitUpdate: !1
    }), f.current = b);
  }, [n.attrs.body]);
  const m = String(n.attrs.name);
  return /* @__PURE__ */ o(
    Lt,
    {
      onKeyDownCapture: (b) => {
        s && !b.nativeEvent.isComposing && b.key === "Enter" && (b.ctrlKey || b.metaKey) && (b.preventDefault(), b.stopPropagation(), p());
      },
      className: "fp-directive-node",
      contentEditable: !1,
      "data-selected": t.selected || void 0,
      "data-card-type": m,
      "data-nested-editor-boundary": s ? "" : void 0,
      children: [
        /* @__PURE__ */ o("div", { className: "fp-directive-heading", contentEditable: !1, "data-nested-editor-boundary": "", children: [
          /* @__PURE__ */ e(
            ke,
            {
              label: "卡片类型",
              value: m,
              disabled: !a.isEditable,
              onChange: (b) => {
                const g = La(n.attrs.attributes, m);
                r({
                  name: b,
                  attributes: Ta(
                    n.attrs.attributes,
                    b,
                    g
                  )
                });
              },
              options: Kd.map(([b, g]) => ({
                value: b,
                label: g
              }))
            }
          ),
          a.isEditable && /* @__PURE__ */ o("span", { className: "fp-directive-actions", children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": s ? "完成卡片编辑" : "编辑卡片内容",
                onClick: () => s ? p() : c(!0),
                children: s ? /* @__PURE__ */ e(Pe, { size: 14 }) : /* @__PURE__ */ e(Bn, { size: 14 })
              }
            ),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "删除卡片", onClick: i, children: /* @__PURE__ */ e(Ht, { size: 14 }) })
          ] })
        ] }),
        s && /* @__PURE__ */ e(
          "input",
          {
            ref: u,
            onKeyDown: (b) => {
              b.key === "Enter" && !b.nativeEvent.isComposing && !b.ctrlKey && !b.metaKey && (b.preventDefault(), b.stopPropagation(), h.current ? h.current.commands.focus("start") : d.current = !0);
            },
            "aria-label": "卡片标题",
            value: La(n.attrs.attributes, m),
            disabled: !a.isEditable,
            placeholder: "添加标题",
            onChange: (b) => r({
              attributes: Ta(
                n.attrs.attributes,
                m,
                b.target.value
              )
            })
          }
        ),
        /* @__PURE__ */ o(fe, { children: [
          s && /* @__PURE__ */ e(
            Ls,
            {
              name: m,
              value: String(n.attrs.attributes || ""),
              onChange: (b) => r({ attributes: b }),
              disabled: !a.isEditable
            }
          ),
          " ",
          s ? /* @__PURE__ */ e(
            Jn,
            {
              allowCards: !1,
              markdown: String(n.attrs.body || ""),
              editable: a.isEditable,
              onOpenLink: t.onOpenLink,
              resolveResourceUrl: t.resolveResourceUrl,
              toolbar: !0,
              onReady: (b) => {
                h.current = b, d.current && (d.current = !1, b.commands.focus("start"));
              },
              onChange: (b) => {
                f.current = b, r({ body: b });
              }
            }
          ) : /* @__PURE__ */ e(
            vt,
            {
              resolveResourceUrl: t.resolveResourceUrl,
              markdown: ":::" + m + (n.attrs.attributes ? "{" + n.attrs.attributes + "}" : "") + `
` + String(n.attrs.body || "") + `
:::`
            }
          )
        ] })
      ]
    }
  );
}
function Jn(t) {
  const {
    markdown: n = "",
    documentKey: r = "default",
    document: a,
    provider: i,
    user: l,
    editable: s = !0,
    placeholder: c = "写下你的理解…",
    extensions: u = [],
    status: d
  } = t, p = B(t);
  p.current = t;
  const h = gu(), f = B(null), m = B(h);
  m.current = h;
  const [b, g] = k(null), [y, w] = k(null), [v, N] = k([]), [x, C] = k(0), [I, L] = k(""), K = B({ suggestion: y, suggestions: v, suggestionActive: x });
  K.current = { suggestion: y, suggestions: v, suggestionActive: x }, Y(() => {
    const z = new AbortController();
    if (N([]), C(0), L(""), !y || !t.getSuggestions) return () => z.abort();
    const $ = setTimeout(() => {
      t.getSuggestions(
        y.query,
        y.kind,
        z.signal
      ).then((P) => {
        z.signal.aborted || N(P);
      }).catch(() => {
        z.signal.aborted || L("暂时无法查找，请继续输入或重试。");
      });
    }, 180);
    return () => {
      clearTimeout($), z.abort();
    };
  }, [y?.query, y?.kind, t.getSuggestions]), Y(() => {
    const z = () => g(($) => $ && { ...$ });
    return window.addEventListener(yr, z), () => window.removeEventListener(yr, z);
  }, []);
  const S = B(b);
  S.current = b;
  const A = (z) => kd(z).filter(($) => !(["attachment", "video"].includes($[0]) && !t.onAttachment) && !($[0] === "interactive" && !t.onInteractive) && !(t.allowCards === !1 && ($[0] === "card" || bn($[0]))));
  function D(z) {
    const { $from: $, from: P, empty: re } = z.state.selection, ie = re && z.isEditable && !$.parent.type.spec.code ? $.parent.textBetween(0, $.parentOffset).match(/(?:^|\s)\/([^\s/]*)$/u) : null, ye = $.parent.textBetween(0, $.parentOffset), he = t.getSuggestions && re && z.isEditable && !$.parent.type.spec.code ? ye.match(/(?:^|\s)(#([^\s#]*)|\[\[([^\]\n]*))$/u) : null;
    if (he) {
      const G = z.view.coordsAtPos(P), ue = he[2] !== void 0 ? "tag" : "link", me = he[2] ?? he[3];
      w({
        from: P - me.length - (ue === "tag" ? 1 : 2),
        to: P,
        kind: ue,
        query: me,
        top: Math.max(8, Math.min(G.bottom + 6, window.innerHeight - 290)),
        left: Math.max(8, Math.min(G.left, window.innerWidth - 280))
      });
    } else w(null);
    if (!ie) {
      g(null);
      return;
    }
    const W = z.view.coordsAtPos(P);
    g((G) => ({
      from: P - ie[1].length - 1,
      to: P,
      query: ie[1],
      top: Math.max(8, Math.min(W.bottom + 6, window.innerHeight - 300)),
      left: Math.max(8, Math.min(W.left, window.innerWidth - 272)),
      active: G?.query === ie[1] ? G.active : 0
    }));
  }
  function U(z) {
    const $ = f.current, P = S.current;
    !$ || !P || p.current.allowCards === !1 && (z === "card" || bn(z)) || (g(null), As(z), $.chain().focus().deleteRange(P).run(), z === "text" ? $.commands.setParagraph() : /^h[1-6]$/.test(z) ? $.commands.setHeading({ level: Number(z[1]) }) : z === "bullet" ? $.commands.toggleBulletList() : z === "ordered" ? $.commands.toggleOrderedList() : z === "quote" ? $.commands.toggleBlockquote() : z === "code" ? $.commands.toggleCodeBlock() : Ia(z) !== void 0 ? $.commands.setCodeBlock({ language: Ia(z) || "" }) : bn(z) ? tr($, bn(z)) : z === "divider" ? $.commands.setHorizontalRule() : Cr(z) ? $.commands.insertTable({ ...Cr(z), withHeaderRow: !0 }) : z === "table" ? $.commands.insertTable({ rows: 3, cols: 3, withHeaderRow: !0 }) : z === "inlineMath" || z === "math" ? m.current.open($, z === "math") : z === "card" ? tr($) : z === "mermaid" ? Wi($) : z === "interactive" ? p.current.onInteractive?.($) : (z === "attachment" || z === "video") && p.current.onAttachment?.(
      $,
      z === "video" ? "video" : "file"
    ));
  }
  function j(z) {
    const $ = f.current, P = K.current.suggestion;
    !$ || !P || ($.chain().focus().deleteRange({ from: P.from, to: P.to }).run(), P.kind === "link" && z.href ? $.chain().insertContent({
      type: "text",
      text: z.label,
      marks: [{ type: "link", attrs: { href: z.href } }]
    }).run() : $.commands.insertContent({
      type: "text",
      text: z.insertText ?? (P.kind === "tag" ? `#${z.label} ` : z.label)
    }), w(null));
  }
  const [T, M] = k(null), [R, q] = k([]), F = B({ mode: T, marks: R });
  F.current = { mode: T, marks: R };
  const E = Yo(
    {
      immediatelyRender: !1,
      editable: s,
      extensions: [
        gd,
        ...(t.baseExtensions || Gr(
          !a,
          void 0,
          Zi.extend({
            addNodeView: () => Xt(
              (z) => p.current.renderDirective ? /* @__PURE__ */ e(Lt, { children: p.current.renderDirective(z) }) : /* @__PURE__ */ e(
                yu,
                {
                  ...z,
                  onOpenLink: p.current.onOpenLink,
                  resolveResourceUrl: p.current.resolveResourceUrl
                }
              ),
              qi
            )
          }),
          eu({
            onInlineClick: (z, $) => f.current && m.current.open(f.current, !1, $),
            onBlockClick: (z, $) => f.current && m.current.open(f.current, !0, $)
          }),
          tl.extend({
            addNodeView: () => Xt(
              ({ node: z, editor: $, deleteNode: P }) => /* @__PURE__ */ o(Lt, { className: "fp-attachment-node", children: [
                /* @__PURE__ */ e(Qe, { size: 20 }),
                /* @__PURE__ */ e("span", { children: String(z.attrs.name) }),
                p.current.onOpenAttachment && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    onClick: () => p.current.onOpenAttachment?.({
                      name: z.attrs.name,
                      url: z.attrs.url,
                      mediaType: z.attrs.mediaType
                    }),
                    children: "查看附件"
                  }
                ),
                $.isEditable && /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    "aria-label": "删除附件",
                    onClick: P,
                    children: /* @__PURE__ */ e(Ht, { size: 14 })
                  }
                )
              ] })
            )
          }),
          Yc
        )).map(
          (z) => z.name === "image" ? z.configure({
            resolveUrl: ($) => p.current.resolveResourceUrl?.($) || $
          }) : z.name === "uploadPlaceholder" ? Qi.extend({
            addNodeView: () => Xt(({ node: $, deleteNode: P }) => /* @__PURE__ */ o(
              Lt,
              {
                className: "fp-editor-upload",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e("strong", { children: String($.attrs.name) }),
                  /* @__PURE__ */ e("p", { role: $.attrs.error ? "alert" : "status", children: $.attrs.error || "正在上传…" }),
                  f.current?.isEditable && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    $.attrs.error && p.current.onUploadAction && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onUploadAction?.(
                          String($.attrs.uploadId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          p.current.onUploadAction?.(
                            String($.attrs.uploadId),
                            "cancel"
                          ), P();
                        },
                        children: "取消上传"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : z.name === "imageConversion" ? Ji.extend({
            addNodeView: () => Xt(({ node: $ }) => /* @__PURE__ */ o(
              Lt,
              {
                className: "fp-editor-conversion",
                contentEditable: !1,
                children: [
                  /* @__PURE__ */ e(
                    "img",
                    {
                      src: p.current.resolveResourceUrl?.(
                        $.attrs.src
                      ) || $.attrs.src,
                      alt: $.attrs.alt || "识别中的图片"
                    }
                  ),
                  /* @__PURE__ */ e("p", { role: $.attrs.error ? "alert" : "status", children: $.attrs.error || ($.attrs.markdown ? "内容已识别" : "正在识别图片…") }),
                  f.current?.isEditable && p.current.onConversionAction && /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
                    $.attrs.markdown && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "insert"
                        ),
                        children: "插入识别内容"
                      }
                    ),
                    $.attrs.error && /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "retry"
                        ),
                        children: "重试"
                      }
                    ),
                    /* @__PURE__ */ e(
                      "button",
                      {
                        type: "button",
                        onClick: () => p.current.onConversionAction?.(
                          String($.attrs.jobId),
                          "keep-image"
                        ),
                        children: "保留图片"
                      }
                    )
                  ] })
                ]
              }
            ))
          }) : z
        ),
        es.configure({ placeholder: c }),
        ...t.allowCards === !1 ? [$s] : [],
        ...a ? [Qo.configure({ document: a })] : [],
        ...i && l ? [Zo.configure({ provider: i, user: l })] : [],
        ...u
      ],
      content: a ? void 0 : t.content ?? nl(n),
      onCreate: ({ editor: z }) => p.current.onReady?.(z),
      onUpdate: ({ editor: z }) => {
        p.current.onChange?.(
          Pa(z.getJSON()),
          z.getJSON()
        ), D(z);
      },
      onSelectionUpdate: ({ editor: z }) => D(z),
      onBlur: () => {
        g(null), w(null);
      },
      editorProps: {
        handleDoubleClick: (z, $, P) => Ss(P, (re, ie) => {
          p.current.onOpenLink ? p.current.onOpenLink(re, ie) : window.open(re, "_blank", "noopener,noreferrer");
        }),
        attributes: { "aria-label": "笔记正文", class: "fp-editor-prose" },
        handleKeyDown(z, $) {
          if (!$.isComposing && ($.ctrlKey || $.metaKey) && ($.key === "Home" || $.key === "End")) {
            const ye = $.key === "Home" ? Sn.atStart(z.state.doc) : Sn.atEnd(z.state.doc), he = $.shiftKey ? Ze.create(z.state.doc, z.state.selection.anchor, ye.head) : ye;
            return z.dispatch(z.state.tr.setSelection(he).scrollIntoView()), !0;
          }
          const P = K.current;
          if (P.suggestion && !$.isComposing) {
            if ($.key === "Escape")
              return w(null), !0;
            if (P.suggestions.length) {
              if ($.key === "ArrowDown" || $.key === "ArrowUp")
                return C(
                  (P.suggestionActive + ($.key === "ArrowDown" ? 1 : -1) + P.suggestions.length) % P.suggestions.length
                ), !0;
              if ($.key === "Enter")
                return j(
                  P.suggestions[P.suggestionActive] || P.suggestions[0]
                ), !0;
            }
          }
          const re = S.current;
          if (!re || $.isComposing) return !1;
          const ie = A(re.query);
          return $.key === "Escape" ? (g(null), !0) : ie.length ? $.key === "ArrowDown" || $.key === "ArrowUp" ? (g({
            ...re,
            active: (re.active + ($.key === "ArrowDown" ? 1 : -1) + ie.length) % ie.length
          }), !0) : $.key === "Enter" ? (U(ie[Math.min(re.active, ie.length - 1)][0]), !0) : !1 : !1;
        },
        handlePaste(z, $) {
          const P = Array.from($.clipboardData?.files || []), re = f.current;
          return P.length && p.current.onFiles && re ? (p.current.onFiles(P, re), !0) : !1;
        },
        handleDrop(z, $, P, re) {
          const ie = Array.from($.dataTransfer?.files || []), ye = f.current;
          if (!re && ie.length && p.current.onFiles && ye) {
            const he = z.posAtCoords({
              left: $.clientX,
              top: $.clientY
            });
            return he && ye.commands.setTextSelection(he.pos), p.current.onFiles(ie, ye), !0;
          }
          return !1;
        },
        handleDOMEvents: {
          mouseup: () => {
            const z = f.current;
            if (z && F.current.mode && !z.state.selection.empty) {
              const { from: $, to: P } = z.state.selection;
              Ed(z, F.current.marks, $, P), F.current.mode === "once" && M(null);
            }
            return !1;
          }
        }
      }
    },
    [r, a, i]
  );
  return f.current = E, Y(() => {
    E?.setEditable(s);
  }, [E, s]), /* @__PURE__ */ o(
    "section",
    {
      className: "fp-markdown-editor",
      "data-readonly": !s || void 0,
      children: [
        E && s && t.toolbar !== !1 && /* @__PURE__ */ e(
          Bd,
          {
            editor: E,
            onHistory: () => p.current.onHistory?.(),
            onSnapshot: () => p.current.onSnapshot?.(),
            hiddenActions: [
              ...t.allowCards === !1 ? ["card"] : [],
              ...t.onHistory ? [] : ["versions"],
              ...t.onSnapshot ? [] : ["snapshot"],
              ...t.onExport ? [] : ["export"],
              ...t.onAttachment ? [] : ["attachment", "video"]
            ],
            onExport: () => p.current.onExport?.(Pa(E.getJSON())),
            onAttachment: () => p.current.onAttachment?.(E, "file"),
            onInteractive: t.onInteractive ? () => p.current.onInteractive?.(E) : void 0,
            onVideo: () => p.current.onAttachment?.(E, "video"),
            onInsertCard: () => {
              p.current.allowCards !== !1 && tr(E);
            },
            onMath: (z) => h.open(E, z),
            formatPainterMode: T,
            onFormatPainterMode: M,
            formatPainterMarks: R,
            onFormatPainterMarks: q
          }
        ),
        /* @__PURE__ */ e(Xi, { editor: E, children: /* @__PURE__ */ e(pi, { editor: E }) }),
        h.card,
        b && E && De(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": "插入内容",
              style: { left: b.left, top: b.top, maxHeight: 280 },
              children: [
                A(b.query).map(([z, $, P], re) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": re === b.active,
                    tabIndex: -1,
                    onMouseDown: (ie) => ie.preventDefault(),
                    onClick: () => U(z),
                    children: [
                      /* @__PURE__ */ e("strong", { children: $ }),
                      /* @__PURE__ */ e("small", { children: P })
                    ]
                  },
                  z
                )),
                !A(b.query).length && /* @__PURE__ */ e("p", { className: "fp-muted", children: "没有匹配的内容" })
              ]
            }
          ),
          E.view.dom.closest("dialog") || window.document.body
        ),
        d && /* @__PURE__ */ e("footer", { className: "fp-markdown-status", children: d }),
        y && E && De(
          /* @__PURE__ */ o(
            "div",
            {
              className: "fp-editor-menu fp-editor-quick",
              role: "listbox",
              "aria-label": y.kind === "tag" ? "标签建议" : "笔记链接建议",
              style: {
                left: y.left,
                top: y.top,
                maxHeight: 260
              },
              children: [
                v.map((z, $) => /* @__PURE__ */ o(
                  "button",
                  {
                    type: "button",
                    role: "option",
                    "aria-selected": $ === x,
                    onMouseDown: (P) => P.preventDefault(),
                    onClick: () => j(z),
                    children: [
                      /* @__PURE__ */ e("strong", { children: z.label }),
                      z.detail && /* @__PURE__ */ e("small", { children: z.detail })
                    ]
                  },
                  z.id
                )),
                !v.length && /* @__PURE__ */ e("p", { role: I ? "alert" : "status", children: I || "输入关键词查找…" })
              ]
            }
          ),
          E.view.dom.closest("dialog") || window.document.body
        )
      ]
    }
  );
}
const or = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
function wu({
  title: t,
  media: n,
  transcript: r,
  chapters: a = [],
  notes: i,
  onNotesChange: l,
  onPositionChange: s,
  onCite: c
}) {
  const [u, d] = k(n.startAt || 0), [p, h] = k("transcript"), [f, m] = k(!0), b = B(null), g = B(null), y = r.findIndex(
    (x) => u >= x.start && u < x.end
  ), w = [...a].reverse().find((x) => x.start <= u);
  Y(() => {
    if (!f || p !== "transcript" || !g.current) return;
    const x = g.current, C = x.parentElement;
    if (!C) return;
    const I = x.getBoundingClientRect(), L = C.getBoundingClientRect();
    (I.top < L.top || I.bottom > L.bottom) && C.scrollTo?.({
      top: C.scrollTop + I.top - L.top - 16,
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
    });
  }, [y, f, p]), Y(() => {
    d(n.startAt || 0);
  }, [n.src, n.startAt]), Y(() => {
    p === "chapter" && !w?.markdown && h("transcript");
  }, [p, w?.markdown]);
  const v = (x) => {
    d(x), s?.(x), n.onTimeUpdate?.(x);
  }, N = (x) => {
    b.current && (b.current.currentTime = Math.max(0, x), v(x));
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-lecture-workspace", children: /* @__PURE__ */ o(ee, { title: t, children: [
    n.kind === "audio" ? /* @__PURE__ */ e(
      Mn,
      {
        ...n,
        audioRef: (x) => {
          b.current = x;
          const C = n.audioRef;
          typeof C == "function" ? C(x) : C && (C.current = x);
        },
        onTimeUpdate: v
      }
    ) : /* @__PURE__ */ e(
      en,
      {
        ...n,
        videoRef: (x) => {
          b.current = x;
          const C = n.videoRef;
          typeof C == "function" ? C(x) : C && (C.current = x);
        },
        onTimeUpdate: v
      }
    ),
    a.length > 0 && /* @__PURE__ */ e("nav", { className: "fp-lecture-chapters", "aria-label": "课堂章节", children: a.map((x) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        "aria-current": w?.id === x.id ? "step" : void 0,
        onClick: () => N(x.start),
        children: [
          /* @__PURE__ */ e("span", { children: or(x.start) }),
          x.title
        ]
      },
      x.id
    )) }),
    /* @__PURE__ */ e(
      Ve,
      {
        label: "课堂内容",
        value: p,
        onChange: h,
        items: [
          { id: "transcript", label: "讲稿" },
          { id: "notes", label: "课堂笔记" },
          ...w?.markdown ? [{ id: "chapter", label: "章节内容" }] : []
        ]
      }
    ),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { className: "fp-lecture-content", children: p === "notes" ? /* @__PURE__ */ e(
      Jn,
      {
        markdown: i,
        onChange: l,
        placeholder: "记录课堂中的想法…"
      }
    ) : p === "chapter" ? /* @__PURE__ */ e(vt, { markdown: w?.markdown || "" }) : /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e("div", { className: "fp-workspace-actions", children: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          "aria-pressed": f,
          onClick: () => m(!f),
          children: "跟随播放"
        }
      ) }),
      /* @__PURE__ */ e("div", { className: "fp-lecture-transcript", "aria-label": "课堂讲稿", children: r.length ? r.map((x, C) => /* @__PURE__ */ o(
        "div",
        {
          ref: C === y ? g : void 0,
          className: "fp-lecture-line",
          "data-active": C === y || void 0,
          children: [
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-timestamp",
                onClick: () => N(x.start),
                "aria-label": `跳转至 ${or(x.start)}`,
                children: or(x.start)
              }
            ),
            /* @__PURE__ */ e("p", { children: x.words?.length ? x.words.map((I, L) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                "data-active": u >= I.start && u < I.end || void 0,
                onClick: () => N(I.start),
                children: I.text
              },
              L
            )) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-lecture-word",
                onClick: () => N(x.start),
                children: x.text
              }
            ) }),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => c({
                  title: t,
                  time: x.start,
                  text: x.text
                }),
                children: "引用"
              }
            )
          ]
        },
        x.id || `${x.start}-${C}`
      )) : /* @__PURE__ */ e("p", { className: "fp-workspace-empty", children: "还没有可用的课堂讲稿。" }) })
    ] }) }) })
  ] }) });
}
function ku({
  source: t
}) {
  const [n, r] = k("");
  return t.audio ? /* @__PURE__ */ e(
    wu,
    {
      title: t.title,
      media: { kind: "audio", ...t.audio },
      transcript: t.transcript || [],
      chapters: t.chapters,
      notes: n,
      onNotesChange: r
    }
  ) : t.resource ? /* @__PURE__ */ e(Cs, { resource: t.resource }) : /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h3", { children: t.title }),
    /* @__PURE__ */ e(
      vt,
      {
        markdown: t.markdown || "此资料还没有可阅读的正文。"
      }
    )
  ] });
}
function be({
  children: t,
  onAction: n,
  disabled: r = !1,
  confirm: a
}) {
  const [i, l] = k(!1), [s, c] = k(""), [u, d] = k(!1), p = B(!1), h = async () => {
    if (!p.current) {
      p.current = !0, l(!0), c("");
      try {
        await n(), d(!1);
      } catch (f) {
        c(
          f instanceof Error ? f.message : "操作未能完成，请重试。"
        );
      } finally {
        p.current = !1, l(!1);
      }
    }
  };
  return /* @__PURE__ */ o("span", { className: "fp-async-action", children: [
    u ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e("span", { children: a }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i || r,
          onClick: () => {
            h();
          },
          children: i ? "正在处理…" : "确认"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: i,
          onClick: () => d(!1),
          children: "取消"
        }
      )
    ] }) : /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary fp-sm",
        disabled: i || r,
        onClick: () => a ? d(!0) : void h(),
        children: i ? "正在处理…" : t
      }
    ),
    s && /* @__PURE__ */ e("span", { role: "alert", children: s })
  ] });
}
function Nu({
  title: t,
  items: n,
  columns: r,
  actions: a = [],
  loading: i,
  error: l,
  toolbar: s,
  onLoadMore: c,
  hasMore: u
}) {
  return /* @__PURE__ */ o("section", { className: "fp-management", "aria-label": t, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      s
    ] }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    /* @__PURE__ */ e("div", { className: "fp-management-scroll", children: /* @__PURE__ */ o("table", { children: [
      /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ o("tr", { children: [
        r.map((d) => /* @__PURE__ */ e("th", { scope: "col", children: d.label }, d.id)),
        !!a.length && /* @__PURE__ */ e("th", { scope: "col", children: "操作" })
      ] }) }),
      /* @__PURE__ */ e("tbody", { children: n.map((d) => /* @__PURE__ */ o("tr", { children: [
        r.map((p) => /* @__PURE__ */ e("td", { "data-label": p.label, children: p.render(d) }, p.id)),
        !!a.length && /* @__PURE__ */ e("td", { "data-label": "操作", children: /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: a.map((p) => /* @__PURE__ */ e(
          be,
          {
            disabled: p.disabled?.(d) || i,
            confirm: p.confirm?.(d),
            onAction: () => p.run(d),
            children: p.label
          },
          p.id
        )) }) })
      ] }, d.id)) })
    ] }) }),
    i && /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }),
    !n.length && !i && /* @__PURE__ */ e("p", { children: "这里还没有内容。" }),
    u && c && /* @__PURE__ */ e("button", { type: "button", disabled: i, onClick: c, children: "加载更多" })
  ] });
}
function Fh({
  entries: t,
  loading: n,
  error: r
}) {
  return /* @__PURE__ */ e(
    Nu,
    {
      title: "收支明细",
      items: t,
      loading: n,
      error: r,
      columns: [
        { id: "title", label: "事项", render: (a) => a.title },
        { id: "date", label: "时间", render: (a) => a.date },
        {
          id: "amount",
          label: "变动",
          render: (a) => /* @__PURE__ */ o("span", { "data-positive": a.amount > 0 || void 0, children: [
            a.amount > 0 ? "+" : "",
            a.amount.toLocaleString()
          ] })
        },
        {
          id: "balance",
          label: "余额",
          render: (a) => a.balance?.toLocaleString() ?? "—"
        },
        { id: "status", label: "状态", render: (a) => a.status || "已完成" }
      ]
    }
  );
}
function Oh({
  balance: t,
  reserved: n = 0,
  children: r,
  onTopUp: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的积分" }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "补充积分" })
    ] }),
    /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: t.toLocaleString() }),
    /* @__PURE__ */ o("p", { children: [
      "可用积分",
      n > 0 && ` · 使用中 ${n.toLocaleString()}`
    ] }),
    r
  ] });
}
function Rh({
  items: t,
  onManage: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "使用情况" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-capacity-row", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: r.label }),
        /* @__PURE__ */ o("span", { children: [
          r.used.toLocaleString(),
          " / ",
          r.limit.toLocaleString(),
          " ",
          r.unit
        ] })
      ] }),
      /* @__PURE__ */ e(
        "progress",
        {
          "aria-label": r.label,
          value: Math.min(r.limit, Math.max(0, r.used)),
          max: Math.max(1, r.limit)
        }
      ),
      n && /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
        "管理",
        r.label
      ] })
    ] }, r.id))
  ] });
}
function Bh({
  items: t,
  canManage: n,
  onManage: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-label": "访问权限来源", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "访问权限" }),
      n && r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "管理权限" })
    ] }),
    t.length ? /* @__PURE__ */ e("ul", { children: t.map((a, i) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("strong", { children: a.source }),
      /* @__PURE__ */ e("span", { children: a.role }),
      /* @__PURE__ */ e("small", { children: a.inherited ? "来自上级目录" : "单独设置" })
    ] }, `${a.source}-${i}`)) }) : /* @__PURE__ */ e("p", { children: "仅自己可以访问。" })
  ] });
}
function jh({
  title: t,
  fields: n,
  onChange: r,
  onSave: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-settings-fields", children: n.map((i) => /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ e("span", { children: i.label }),
      i.options ? /* @__PURE__ */ e(
        ke,
        {
          label: i.label,
          value: i.value,
          options: i.options,
          disabled: i.disabled,
          onChange: (l) => r(i.id, l)
        }
      ) : /* @__PURE__ */ e(
        "input",
        {
          "aria-label": i.label,
          type: i.secret ? "password" : "text",
          value: i.value,
          disabled: i.disabled,
          onChange: (l) => r(i.id, l.target.value)
        }
      ),
      " ",
      i.description && /* @__PURE__ */ e("small", { children: i.description })
    ] }, i.id)) }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(be, { onAction: a, children: "保存设置" }) })
  ] });
}
function qh({
  steps: t,
  step: n,
  onStepChange: r,
  onComplete: a
}) {
  const i = t[n];
  return i ? /* @__PURE__ */ o("section", { className: "fp-onboarding", children: [
    /* @__PURE__ */ e("ol", { "aria-label": "设置进度", children: t.map((l, s) => /* @__PURE__ */ o("li", { "aria-current": s === n ? "step" : void 0, children: [
      /* @__PURE__ */ e("span", { children: s + 1 }),
      l.title
    ] }, l.id)) }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: i.title }),
      i.description && /* @__PURE__ */ e("p", { children: i.description }),
      i.content
    ] }) }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      n < t.length - 1 ? /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: i.canContinue === !1,
          onClick: () => r(n + 1),
          children: "继续"
        }
      ) : /* @__PURE__ */ e(
        be,
        {
          disabled: i.canContinue === !1,
          onAction: a,
          children: "完成设置"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n === 0,
          onClick: () => r(n - 1),
          children: "上一步"
        }
      )
    ] })
  ] }) : /* @__PURE__ */ e("section", { className: "fp-onboarding", children: /* @__PURE__ */ e("p", { children: "暂时没有可用的设置步骤。" }) });
}
function xu(t) {
  return /* @__PURE__ */ e(Cu, { ...t }, t.notebook?.id || "new");
}
function Cu({
  notebook: t,
  drafts: n = [],
  versions: r = [],
  onPrepare: a,
  onPublish: i,
  onSetSource: l,
  onRestore: s,
  onLoadVersions: c,
  onRefresh: u,
  resolveResourceUrl: d
}) {
  const [p, h] = k("update"), {
    draft: f,
    setDraft: m,
    dirty: b,
    accept: g
  } = nt({
    sourcePrefix: t?.sourcePrefix || "",
    syncMode: t?.syncMode || "review"
  }), y = f.sourcePrefix, w = f.syncMode, v = (M) => m({ ...f, sourcePrefix: M }), N = (M) => m({ ...f, syncMode: M }), [x, C] = k(), [I, L] = k(""), [K, S] = k(null), [A, D] = k(""), U = Le(), j = K?.items.find((M) => M.id === A) || K?.items[0], T = () => {
    U.run(async () => {
      if (!y.trim()) throw new Error("请填写资料来源目录。");
      const M = await a({
        notebookId: t?.id,
        sourcePrefix: y.trim(),
        manifest: x
      });
      S(M), D(M.items[0]?.id || "");
    }, "内容已准备好，请检查后发布。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "笔记本发布", children: /* @__PURE__ */ o(
    ee,
    {
      title: t?.title || "新建笔记本",
      description: "预览课程内容，为读者发布新的阅读版本。",
      actions: u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          disabled: U.busy,
          onClick: () => {
            U.run(u);
          },
          children: "刷新"
        }
      ),
      children: [
        /* @__PURE__ */ e(
          Ve,
          {
            label: "笔记本管理",
            value: p,
            onChange: (M) => {
              h(M), M === "history" && c && U.run(c);
            },
            items: [
              { id: "update", label: "预览与发布" },
              { id: "source", label: "来源与更新" },
              { id: "history", label: "发布历史" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...U }),
        /* @__PURE__ */ e("fieldset", { disabled: U.busy, children: /* @__PURE__ */ o(fe, { children: [
          p === "update" && /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ o(ee, { title: "准备课程资料", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "资料来源目录",
                  value: y,
                  onChange: (M) => {
                    v(M), S(null);
                  },
                  hint: "选择已经上传的课程资料目录。"
                }
              ),
              /* @__PURE__ */ o(
                "label",
                {
                  className: "fp-workspace-upload",
                  role: "button",
                  tabIndex: 0,
                  onKeyDown: (M) => {
                    (M.key === "Enter" || M.key === " ") && (M.preventDefault(), M.currentTarget.querySelector("input")?.click());
                  },
                  children: [
                    /* @__PURE__ */ e("strong", { children: I || "选择目录清单" }),
                    /* @__PURE__ */ e("span", { children: "JSON 文件，最大 2 MB" }),
                    /* @__PURE__ */ e(
                      "input",
                      {
                        hidden: !0,
                        type: "file",
                        "aria-label": "选择目录清单",
                        accept: ".json,application/json",
                        onChange: (M) => {
                          const R = M.target.files?.[0];
                          M.target.value = "", R && (C(void 0), L(""), S(null), U.run(async () => {
                            if (R.size > 2e6)
                              throw new Error("清单文件不能超过 2 MB。");
                            let q;
                            try {
                              q = JSON.parse(await R.text());
                            } catch {
                              throw new Error(
                                "无法读取清单，请选择有效的 JSON 文件。"
                              );
                            }
                            C(q), L(R.name), S(null);
                          }));
                        }
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: T,
                  children: U.busy ? "正在检查…" : "检查并预览"
                }
              )
            ] }),
            n.length > 0 && /* @__PURE__ */ e(ee, { title: "待发布内容", children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: n.map((M) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                onClick: () => {
                  S(M), D(M.items[0]?.id || "");
                },
                children: [
                  /* @__PURE__ */ e("strong", { children: M.title }),
                  /* @__PURE__ */ o("small", { children: [
                    M.sections,
                    " 个章节 · ",
                    M.resources,
                    " 份资料"
                  ] })
                ]
              },
              M.id
            )) }) }),
            K && /* @__PURE__ */ o(
              ee,
              {
                title: K.title,
                description: `${K.sections} 个章节 · ${K.resources} 份资料${K.structureChanged ? " · 目录有调整" : ""}`,
                children: [
                  /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
                    /* @__PURE__ */ e(
                      "nav",
                      {
                        className: "fp-workspace-item-list",
                        "aria-label": "草稿章节",
                        children: K.items.map((M) => /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            "aria-pressed": M.id === j?.id,
                            onClick: () => D(M.id),
                            children: M.title
                          },
                          M.id
                        ))
                      }
                    ),
                    /* @__PURE__ */ e("article", { children: j ? /* @__PURE__ */ e(
                      vt,
                      {
                        markdown: j.content,
                        resolveResourceUrl: d
                      }
                    ) : /* @__PURE__ */ e("p", { children: "此草稿还没有可预览的章节。" }) })
                  ] }),
                  /* @__PURE__ */ e(
                    be,
                    {
                      disabled: !K.items.length,
                      confirm: `将“${K.title}”发布给读者？`,
                      onAction: async () => {
                        await i(K.id, t?.currentRelease), S(null), U.setMessage("发布完成，读者可以看到新内容。");
                      },
                      children: "确认发布"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-ghost",
                      onClick: () => S(null),
                      children: "返回修改"
                    }
                  )
                ]
              }
            )
          ] }),
          p === "source" && /* @__PURE__ */ o(ee, { title: "资料来源与更新方式", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "来源目录",
                value: y,
                onChange: (M) => {
                  v(M), S(null);
                }
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "发布方式",
                value: w,
                options: [
                  {
                    value: "review",
                    label: "确认后发布",
                    description: "先预览内容，再决定发布时间。"
                  },
                  {
                    value: "auto",
                    label: "自动发布",
                    description: "正文变化自动更新，目录调整仍需确认。"
                  }
                ],
                onChange: (M) => N(M)
              }
            ),
            l && /* @__PURE__ */ e(
              it,
              {
                busy: U.busy,
                dirty: b,
                onClick: () => {
                  U.run(async () => {
                    if (!y.trim()) throw new Error("请填写来源目录。");
                    const M = {
                      sourcePrefix: y.trim(),
                      syncMode: w
                    };
                    await l(M), g(M);
                  }, "来源与更新方式已保存。");
                }
              }
            )
          ] }),
          p === "history" && /* @__PURE__ */ o(ee, { title: "发布历史", children: [
            r.map((M) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
              /* @__PURE__ */ o("div", { children: [
                /* @__PURE__ */ e("strong", { children: M.label || new Date(M.createdAt).toLocaleString("zh-CN") }),
                /* @__PURE__ */ e("p", { children: M.id === t?.currentRelease ? "当前阅读版本" : "历史阅读版本" })
              ] }),
              s && t && M.id !== t.currentRelease && /* @__PURE__ */ e(
                be,
                {
                  confirm: "恢复此版本？后续更新将等待你确认。",
                  onAction: async () => {
                    await s(
                      M.id,
                      t.currentRelease
                    ), U.setMessage("阅读版本已恢复。");
                  },
                  children: "恢复版本"
                }
              )
            ] }, M.id)),
            !r.length && /* @__PURE__ */ e("p", { children: "暂无发布历史。" })
          ] })
        ] }) })
      ]
    }
  ) });
}
function Kh({
  notebooks: t,
  drafts: n,
  versions: r = {},
  loading: a,
  error: i,
  onPrepare: l,
  onPublish: s,
  onSetSource: c,
  onRestore: u,
  onLoadVersions: d,
  onRefresh: p,
  resolveResourceUrl: h
}) {
  const [f, m] = k(""), [b, g] = k("all"), [y, w] = k(null), v = t.find((I) => I.id === y), N = n.filter(
    (I) => y === "new" ? !I.notebookId : I.notebookId === y
  ), x = t.filter(
    (I) => I.title.toLowerCase().includes(f.trim().toLowerCase()) && (b === "all" || n.some((L) => L.notebookId === I.id))
  ), C = n.filter(
    (I) => !I.notebookId || !t.some((L) => L.id === I.notebookId)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "笔记本",
      description: "整理课程资料，检查更新并发布阅读版本。",
      actions: /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          onClick: () => w("new"),
          children: "新建笔记本"
        }
      ),
      children: [
        /* @__PURE__ */ e(X, { label: "搜索笔记本", value: f, onChange: m }),
        /* @__PURE__ */ e(
          Ve,
          {
            label: "笔记本筛选",
            value: b,
            onChange: g,
            items: [
              { id: "all", label: "全部笔记本" },
              { id: "pending", label: "有待发布内容" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { error: i }),
        a ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ o("div", { className: "fp-workspace-item-list", children: [
          x.map((I) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              "aria-pressed": y === I.id,
              onClick: () => w(I.id),
              children: [
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: I.title }),
                  /* @__PURE__ */ e("small", { children: n.some((L) => L.notebookId === I.id) ? "有内容等待发布" : "课程内容已发布" })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            I.id
          )),
          !x.length && /* @__PURE__ */ e("p", { children: f ? "没有找到匹配的笔记本。" : "选择新建笔记本，开始整理课程。" }),
          C.filter(
            (I) => I.title.toLowerCase().includes(f.toLowerCase())
          ).map((I) => /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => w("new"),
              children: /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: I.title }),
                /* @__PURE__ */ e("small", { children: "首次发布待确认" })
              ] })
            },
            I.id
          ))
        ] }),
        /* @__PURE__ */ e(fe, { children: y && /* @__PURE__ */ e(
          ee,
          {
            title: v?.title || "准备新的笔记本",
            actions: /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                onClick: () => w(null),
                children: "返回笔记本列表"
              }
            ),
            children: /* @__PURE__ */ e(
              xu,
              {
                notebook: v,
                drafts: N,
                versions: r[y],
                onPrepare: l,
                onPublish: s,
                onSetSource: v && c ? (I) => c(v.id, I) : void 0,
                onRestore: v && u ? (I, L) => u(v.id, I, L) : void 0,
                onLoadVersions: v && d ? () => d(v.id) : void 0,
                onRefresh: p,
                resolveResourceUrl: h
              },
              y
            )
          }
        ) })
      ]
    }
  ) });
}
function Su({
  versions: t,
  selectedId: n,
  onSelect: r,
  onRestore: a,
  loading: i,
  error: l
}) {
  const [s, c] = k(null), [u, d] = k(!1), [p, h] = k(""), f = B(!1), m = t.find((b) => b.id === n);
  return /* @__PURE__ */ o("section", { className: "fp-version-history", "aria-label": "笔记历史", children: [
    /* @__PURE__ */ e("div", { className: "fp-version-list", "aria-busy": i, children: i ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取历史…" }) : t.length ? t.map((b) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-pressed": b.id === n,
        onClick: () => {
          c(null), h(""), r(b.id);
        },
        children: [
          /* @__PURE__ */ e(jn, { size: 15 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: b.label }),
            /* @__PURE__ */ o("small", { children: [
              b.date,
              b.author && ` · ${b.author}`
            ] })
          ] })
        ]
      },
      b.id
    )) : /* @__PURE__ */ e("p", { children: "还没有保存的历史版本。" }) }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o("div", { className: "fp-version-preview", children: [
      m ? /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e("h3", { children: m.label }),
        m.preview,
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: s === m.id ? /* @__PURE__ */ o(Q, { children: [
          /* @__PURE__ */ e("span", { children: "将当前笔记恢复到此版本？" }),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: async () => {
                if (!f.current) {
                  f.current = !0, d(!0), h("");
                  try {
                    await a(m.id), c(null);
                  } catch {
                    h("恢复未能完成，当前内容已保留。");
                  } finally {
                    f.current = !1, d(!1);
                  }
                }
              },
              children: u ? "正在恢复…" : "确认恢复"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              disabled: u,
              onClick: () => c(null),
              children: "取消"
            }
          )
        ] }) : /* @__PURE__ */ o("button", { type: "button", onClick: () => c(m.id), children: [
          /* @__PURE__ */ e(Je, { size: 15 }),
          "恢复此版本"
        ] }) })
      ] }) : /* @__PURE__ */ e("p", { children: "选择一个版本查看内容。" }),
      (l || p) && /* @__PURE__ */ e("p", { role: "alert", children: l || p })
    ] }) })
  ] });
}
function Hh({
  local: t,
  remote: n,
  onResolve: r
}) {
  const [a, i] = k(!1), [l, s] = k(""), c = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-save-conflict", "aria-label": "处理笔记冲突", children: [
    /* @__PURE__ */ e("h3", { children: "笔记有新的修改" }),
    /* @__PURE__ */ e("p", { children: "比较两个版本，选择要继续使用的内容。" }),
    /* @__PURE__ */ o("div", { className: "fp-compare-panes", children: [
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "我的修改" }),
        t
      ] }),
      /* @__PURE__ */ o("article", { children: [
        /* @__PURE__ */ e("h4", { children: "最新版本" }),
        n
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: ["local", "remote"].map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        disabled: a,
        onClick: async () => {
          if (!c.current) {
            c.current = !0, i(!0), s("");
            try {
              await r(u);
            } catch {
              s("暂时无法应用，请重试。");
            } finally {
              c.current = !1, i(!1);
            }
          }
        },
        children: u === "local" ? "使用我的修改" : "使用最新版本"
      },
      u
    )) }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l })
  ] });
}
function Uh({
  items: t,
  onOpen: n,
  loading: r = !1
}) {
  return /* @__PURE__ */ o("section", { className: "fp-backlinks", "aria-label": "关联笔记", children: [
    /* @__PURE__ */ e("h3", { children: "引用这篇笔记" }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在查找关联…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((a) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("button", { type: "button", onClick: () => n(a.id), children: [
      /* @__PURE__ */ e(gt, { size: 15 }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: a.title }),
        a.excerpt && /* @__PURE__ */ e("small", { children: a.excerpt })
      ] })
    ] }) }, a.id)) }) : /* @__PURE__ */ e("p", { children: "还没有其他笔记引用这里。" })
  ] });
}
function _h({
  previewUrl: t,
  onChoose: n,
  onCancel: r,
  busy: a = !1,
  error: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-image-paste", "aria-label": "添加图片", children: [
    /* @__PURE__ */ e("img", { src: t, alt: "待添加的图片" }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: "如何添加这张图片？" }),
      /* @__PURE__ */ e("p", { children: "保留图片，或识别其中的文字与公式。" }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: a,
            onClick: () => n("image"),
            children: "插入图片"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: a,
            onClick: () => n("recognize"),
            children: "识别内容"
          }
        ),
        /* @__PURE__ */ e("button", { type: "button", disabled: a, onClick: r, children: "取消" })
      ] }),
      a && /* @__PURE__ */ e("p", { role: "status", children: "正在处理图片…" }),
      i && /* @__PURE__ */ e("p", { role: "alert", children: i })
    ] })
  ] });
}
function Wh({ lines: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-version-diff", "aria-label": "版本变化", children: t.map((n, r) => /* @__PURE__ */ o("div", { "data-kind": n.kind, children: [
    /* @__PURE__ */ e(
      "span",
      {
        "aria-label": n.kind === "added" ? "新增" : n.kind === "removed" ? "删除" : "保留",
        children: n.kind === "added" ? "+" : n.kind === "removed" ? "−" : " "
      }
    ),
    /* @__PURE__ */ e("code", { children: n.text || " " })
  ] }, r)) });
}
function Mu(t) {
  return /* @__PURE__ */ e(Eu, { ...t }, t.document.id);
}
function Eu({
  document: t,
  onSave: n,
  autosaveDelay: r = 1600,
  readOnly: a,
  editorProps: i,
  versions: l = [],
  onRestore: s,
  onExportDraft: c,
  registerNavigationGuard: u,
  onDirtyChange: d
}) {
  const [p, h] = k(t), [f, m] = k(t.markdown), [b, g] = k(
    "clean"
  ), [y, w] = k(""), [v, N] = k(null), [x, C] = k(!1), [I, L] = k(l[0]?.id), [K, S] = k(!1), A = B(!1), D = p.markdown !== f, U = B(p), j = B(n), T = B(null), M = B(null), R = B(!0), q = B(t.revision);
  U.current = p, j.current = n, Y(() => (R.current = !0, () => {
    R.current = !1, T.current?.abort();
  }), []), Y(() => {
    d?.(D);
  }, [D, d]), Y(() => {
    t.revision !== q.current && (D || M.current ? N(t) : (q.current = t.revision, h(t), m(t.markdown)));
  }, [t, D]);
  const F = xe(() => {
    if (M.current) return M.current;
    if (a || v) return Promise.resolve(!D);
    const E = U.current, z = new AbortController();
    T.current = z, g("saving"), w("");
    const $ = (async () => {
      try {
        const P = await j.current(E, z.signal);
        if (z.signal.aborted || !R.current) return !1;
        if (P.id !== E.id)
          throw new Error("保存的笔记不匹配，请重试。");
        return q.current = P.revision, m(P.markdown), h(
          (re) => re.markdown === E.markdown ? P : { ...re, revision: P.revision }
        ), g("saved"), !0;
      } catch (P) {
        return R.current && !z.signal.aborted && (g("error"), w(
          P instanceof Error ? P.message : "保存未完成，当前内容已保留。"
        )), !1;
      } finally {
        M.current = null;
      }
    })();
    return M.current = $, $;
  }, [a, v, D]);
  return Y(() => {
    if (!D || a || v || b === "error" || b === "saving" || r <= 0)
      return;
    const E = setTimeout(() => {
      F();
    }, r);
    return () => clearTimeout(E);
  }, [D, p.markdown, a, v, b, r, F]), Y(
    () => u?.(async () => D ? await F() ? U.current.markdown === p.markdown : !1 : !0),
    [u, D, F, p.markdown]
  ), Y(() => {
    const E = (z) => {
      D && (z.preventDefault(), z.returnValue = "");
    };
    return window.addEventListener("beforeunload", E), () => window.removeEventListener("beforeunload", E);
  }, [D]), /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form",
      onKeyDown: (E) => {
        (E.ctrlKey || E.metaKey) && E.key.toLowerCase() === "s" && (E.preventDefault(), D && F());
      },
      children: /* @__PURE__ */ o(
        ee,
        {
          title: p.title,
          actions: /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e("span", { role: "status", children: a ? "只读" : b === "saving" ? "正在保存…" : D ? "有待保存的更改" : "已保存" }),
            l.length > 0 && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                "aria-expanded": x,
                onClick: () => C(!x),
                children: "版本历史"
              }
            ),
            c && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: () => c(p),
                children: "导出笔记"
              }
            ),
            !a && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-primary",
                disabled: !D || b === "saving" || !!v || K,
                onClick: () => {
                  F();
                },
                children: "保存"
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(Se, { error: y }),
            /* @__PURE__ */ e(fe, { children: v && /* @__PURE__ */ o("div", { className: "fp-workspace-subsection", role: "alert", children: [
              /* @__PURE__ */ e("strong", { children: "这篇笔记有新的版本" }),
              /* @__PURE__ */ e("p", { children: "当前编辑内容已保留，请先导出需要保留的内容，再选择继续使用的版本。" }),
              /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      q.current = v.revision, h(v), m(v.markdown), N(null), w(""), g("clean");
                    },
                    children: "读取最新版本"
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      q.current = v.revision, h((E) => ({
                        ...E,
                        revision: v.revision
                      })), N(null), g("clean");
                    },
                    children: "继续编辑当前内容"
                  }
                )
              ] })
            ] }) }),
            /* @__PURE__ */ e(
              Jn,
              {
                ...i,
                documentKey: t.id,
                markdown: p.markdown,
                editable: !a && !K,
                onChange: (E) => {
                  h((z) => ({ ...z, markdown: E })), b !== "saving" && g("clean");
                }
              }
            ),
            /* @__PURE__ */ e(fe, { children: x && /* @__PURE__ */ e(
              Su,
              {
                versions: l,
                selectedId: I,
                onSelect: L,
                onRestore: async (E) => {
                  if (!s) throw new Error("暂时无法恢复此版本。");
                  if (!A.current) {
                    A.current = !0, S(!0);
                    try {
                      const z = U.current;
                      if (D && !await F())
                        throw new Error("请先保存当前更改。");
                      if (U.current.markdown !== z.markdown)
                        throw new Error("请先保存当前更改。");
                      const $ = new AbortController();
                      T.current = $;
                      const P = await s(
                        E,
                        U.current.revision,
                        $.signal
                      );
                      if (!R.current || $.signal.aborted) return;
                      if (P.id !== t.id)
                        throw new Error("恢复的笔记不匹配，请重试。");
                      q.current = P.revision, h(P), m(P.markdown), g("saved");
                    } finally {
                      A.current = !1, R.current && S(!1);
                    }
                  }
                }
              }
            ) })
          ]
        }
      )
    }
  );
}
function Vh(t) {
  return /* @__PURE__ */ e($u, { ...t }, t.document.id);
}
function $u({
  document: t,
  onSave: n,
  autosaveDelay: r,
  versions: a,
  onRestore: i,
  editorProps: l,
  onExportDraft: s,
  subject: c,
  summary: u,
  examples: d = [],
  quiz: p,
  readOnly: h,
  loading: f,
  error: m,
  onRetry: b,
  actions: g,
  contentProps: y,
  renderedContent: w
}) {
  const [v, N] = k("content"), [x, C] = k(!1), [I, L] = k(!1), [K, S] = k(d[0]?.id || ""), A = B(null), D = Le(), U = (T) => {
    D.run(async () => {
      if (x && A.current && !await A.current())
        throw new Error("当前修改已保留，请保存后继续。");
      C(!1), N(T);
    });
  }, j = d.find((T) => T.id === K) || d[0];
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ e(
    Yn,
    {
      open: I,
      onExit: () => L(!1),
      label: t.title,
      children: /* @__PURE__ */ e("div", { className: "fp-course-content", children: /* @__PURE__ */ o(
        ee,
        {
          title: t.title,
          description: [c, u].filter(Boolean).join(" · "),
          actions: /* @__PURE__ */ o(Q, { children: [
            g,
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": I ? "退出全屏" : "全屏阅读",
                onClick: () => L(!I),
                children: I ? /* @__PURE__ */ e(to, { size: 17 }) : /* @__PURE__ */ e(Rn, { size: 17 })
              }
            ),
            I && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                "aria-label": "关闭全屏阅读",
                onClick: () => L(!1),
                children: /* @__PURE__ */ e(ge, { size: 17 })
              }
            )
          ] }),
          children: [
            /* @__PURE__ */ e(
              Ve,
              {
                label: "课程内容",
                value: v,
                onChange: U,
                items: [
                  { id: "content", label: "正文" },
                  ...d.length ? [{ id: "examples", label: `例题 ${d.length}` }] : [],
                  ...p ? [{ id: "quiz", label: "练习" }] : []
                ]
              }
            ),
            /* @__PURE__ */ e(Se, { error: m || D.error }),
            /* @__PURE__ */ e(fe, { children: f ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开课程内容…" }) : m ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: b,
                children: "重新打开"
              }
            ) : v === "quiz" ? p : v === "examples" ? /* @__PURE__ */ o(Q, { children: [
              /* @__PURE__ */ e("nav", { className: "fp-workspace-actions", "aria-label": "例题列表", children: d.map((T) => /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  "aria-pressed": j?.id === T.id,
                  onClick: () => S(T.id),
                  children: T.title
                },
                T.id
              )) }),
              j && /* @__PURE__ */ e(
                vt,
                {
                  ...y,
                  markdown: j.markdown
                }
              )
            ] }) : x ? /* @__PURE__ */ e(
              Mu,
              {
                document: t,
                onSave: n,
                autosaveDelay: r,
                versions: a,
                onRestore: i,
                editorProps: l,
                onExportDraft: s,
                registerNavigationGuard: (T) => (A.current = T, () => {
                  A.current = null;
                })
              }
            ) : w ?? /* @__PURE__ */ e(
              vt,
              {
                ...y,
                markdown: t.markdown
              }
            ) }),
            v === "content" && !h && !f && !m && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                disabled: D.busy,
                onClick: () => {
                  D.run(async () => {
                    if (x && A.current && !await A.current())
                      throw new Error("当前修改已保留，请保存后继续。");
                    C(!x);
                  });
                },
                children: x ? "完成编辑" : "编辑笔记"
              }
            )
          ]
        }
      ) })
    }
  ) });
}
function Fn(t) {
  try {
    const n = new URL(
      /^[a-z][a-z\d+.-]*:/i.test(t.trim()) ? t.trim() : `https://${t.trim()}`
    );
    return ["http:", "https:"].includes(n.protocol) && n.hostname ? n.href : "";
  } catch {
    return "";
  }
}
function zu({
  bookmarks: t,
  homeUrl: n,
  onAdd: r,
  onRemove: a,
  onOpen: i,
  onHomeChange: l
}) {
  const [s, c] = k(""), [u, d] = k(""), p = Le(), {
    draft: h,
    setDraft: f,
    dirty: m,
    accept: b
  } = nt(n);
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "浏览与收藏", children: [
    /* @__PURE__ */ e(Se, { ...p }),
    /* @__PURE__ */ o(ee, { title: "添加收藏", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "收藏名称",
          value: s,
          onChange: c,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        X,
        {
          label: "网页地址",
          value: u,
          onChange: d,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: p.busy || !u.trim(),
          onClick: () => {
            p.run(async () => {
              const g = Fn(u);
              if (!g) throw new Error("请填写有效的网页地址。");
              await r({
                name: s.trim() || new URL(g).hostname,
                url: g
              }), c(""), d("");
            }, "收藏已添加。");
          },
          children: "添加收藏"
        }
      )
    ] }),
    /* @__PURE__ */ o(ee, { title: "我的收藏", children: [
      t.map((g) => /* @__PURE__ */ o("div", { className: "fp-workspace-row", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-ghost",
            onClick: () => i(g.id),
            children: g.name
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            confirm: `移除“${g.name}”收藏？`,
            onAction: () => a(g.id),
            children: "移除"
          }
        )
      ] }, g.id)),
      !t.length && /* @__PURE__ */ e("p", { children: "添加常用网页，下次可以快速打开。" })
    ] }),
    /* @__PURE__ */ o(ee, { title: "浏览器主页", children: [
      /* @__PURE__ */ e(
        X,
        {
          label: "主页地址",
          value: h,
          onChange: f,
          disabled: p.busy
        }
      ),
      /* @__PURE__ */ e(
        it,
        {
          busy: p.busy,
          dirty: m,
          label: "保存主页",
          onClick: () => {
            p.run(async () => {
              const g = Fn(h);
              if (!g) throw new Error("请填写有效的主页地址。");
              await l(g), b(g);
            }, "主页已更新。");
          }
        }
      )
    ] })
  ] }) });
}
function pl({
  title: t,
  icon: n,
  onClose: r,
  onMinimize: a,
  onFullscreen: i,
  isFullscreen: l = !1,
  children: s,
  onDragStart: c,
  actions: u,
  className: d,
  native: p = !1,
  closeLabel: h = "关闭窗口",
  closeShortcut: f
}) {
  return /* @__PURE__ */ o("div", { className: `fp-window${p ? " fp-window-native" : ""} ${d || ""}`, children: [
    /* @__PURE__ */ o(
      "header",
      {
        className: "fp-window-bar",
        onPointerDown: (m) => {
          m.button === 0 && !m.target.closest(
            "button,a,input,textarea,select,[data-no-drag]"
          ) && c?.(m);
        },
        "data-draggable": c ? !0 : void 0,
        children: [
          /* @__PURE__ */ o("div", { className: "fp-window-title", children: [
            n,
            /* @__PURE__ */ e("span", { "data-fp-tooltip": t, "data-fp-tooltip-side": "left", children: t })
          ] }),
          u && /* @__PURE__ */ e("div", { className: "fp-window-actions", "data-no-drag": !0, children: u }),
          /* @__PURE__ */ o("div", { className: "fp-window-controls", "data-no-drag": !0, children: [
            a && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": "最小化窗口",
                "data-fp-tooltip": "最小化",
                "data-fp-tooltip-side": "left",
                onClick: a,
                children: /* @__PURE__ */ e(Ft, { size: 16 })
              }
            ),
            i && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control",
                "aria-label": l ? "退出全屏" : "全屏",
                "data-fp-tooltip": l ? "退出全屏" : "全屏",
                "data-fp-tooltip-side": "left",
                onClick: i,
                children: l ? /* @__PURE__ */ e($r, { size: 16 }) : /* @__PURE__ */ e(zr, { size: 16 })
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-window-control fp-window-control-close",
                "aria-label": h,
                "data-fp-tooltip": f ? `${h}（${f}）` : h,
                "data-fp-tooltip-side": "left",
                onClick: r,
                children: /* @__PURE__ */ e(ge, { size: 16 })
              }
            )
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-window-body", children: s })
  ] });
}
const hl = cn(
  () => () => {
  }
);
function Au(t, n) {
  const r = n.toLowerCase().split("+").map((l) => l.trim()), a = r.at(-1), i = (l) => r.includes(l);
  return t.key.toLowerCase() === a && (i("mod") ? t.ctrlKey || t.metaKey : t.ctrlKey === i("ctrl") && t.metaKey === i("meta")) && t.altKey === i("alt") && t.shiftKey === i("shift");
}
function Yh({
  children: t,
  paused: n = !1
}) {
  const r = B(/* @__PURE__ */ new Map());
  Y(() => {
    const i = (l) => {
      if (n || l.defaultPrevented || l.isComposing || l.key === "Process")
        return;
      const s = l.target instanceof Element && !!l.target.closest(
        "input,textarea,[contenteditable=true],math-field,[role=dialog],[role=menu]"
      ), c = [...r.current.values()].sort(
        (u, d) => (d.priority || 0) - (u.priority || 0)
      );
      for (const u of c)
        if (!(u.enabled === !1 || s && !u.allowInInput || !Au(l, u.keys))) {
          l.preventDefault(), u.run();
          break;
        }
    };
    return window.addEventListener("keydown", i), () => window.removeEventListener("keydown", i);
  }, [n]);
  const a = B((i) => {
    const l = Symbol(i.id);
    return r.current.set(l, i), () => {
      r.current.delete(l);
    };
  });
  return /* @__PURE__ */ e(hl.Provider, { value: a.current, children: t });
}
function Xh(t) {
  const n = Bt(hl);
  Y(
    () => n(t),
    [
      n,
      t.id,
      t.keys,
      t.enabled,
      t.allowInInput,
      t.priority,
      t.run
    ]
  );
}
function Gh({
  items: t,
  onChange: n,
  onReset: r
}) {
  const [a, i] = k(""), [l, s] = k(null), [c, u] = k("");
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "快捷键" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-pattern-input",
        "aria-label": "搜索快捷键",
        placeholder: "查找操作",
        value: a,
        onChange: (d) => i(d.target.value)
      }
    ),
    t.filter((d) => d.label.includes(a)).map((d) => /* @__PURE__ */ o("div", { className: "fp-shortcut-setting", children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `设置${d.label}快捷键`,
          onClick: () => {
            u(""), s(d.id);
          },
          onKeyDown: (p) => {
            if (l !== d.id) return;
            if (p.preventDefault(), p.stopPropagation(), p.key === "Escape") {
              s(null);
              return;
            }
            if (["Control", "Shift", "Alt", "Meta"].includes(p.key)) return;
            const h = [
              p.ctrlKey ? "Ctrl" : "",
              p.metaKey ? "Meta" : "",
              p.altKey ? "Alt" : "",
              p.shiftKey ? "Shift" : "",
              p.key
            ].filter(Boolean).join("+");
            if (t.some(
              (f) => f.id !== d.id && f.enabled && f.keys.toLowerCase() === h.toLowerCase()
            )) {
              u("这个快捷键已被其他操作使用。");
              return;
            }
            n(d.id, h, d.enabled), s(null);
          },
          children: l === d.id ? "按下新的快捷键…" : d.keys
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-pressed": d.enabled,
          onClick: () => n(d.id, d.keys, !d.enabled),
          children: d.enabled ? "已启用" : "已停用"
        }
      )
    ] }, d.id)),
    c && /* @__PURE__ */ e("p", { role: "alert", children: c }),
    r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "恢复默认" })
  ] });
}
function sr(t, n, r = { width: 300, height: 200 }) {
  const a = Math.min(n.width, Math.max(r.width, t.width)), i = Math.min(
    n.height,
    Math.max(r.height, t.height)
  );
  return {
    width: a,
    height: i,
    x: Math.max(0, Math.min(n.width - a, t.x)),
    y: Math.max(0, Math.min(n.height - i, t.y))
  };
}
function Jh({
  title: t,
  geometry: n,
  onGeometryChange: r,
  onClose: a,
  onMinimize: i,
  onFocus: l,
  children: s,
  zIndex: c = 40,
  minWidth: u = 300,
  minHeight: d = 200,
  contained: p = !1
}) {
  const [h, f] = k(!1), m = B(null), b = B(null), [g, y] = k(null);
  Ce(() => {
    const x = () => {
      const I = p ? b.current?.parentElement : null, L = {
        width: I?.clientWidth || window.innerWidth,
        height: I?.clientHeight || window.innerHeight
      };
      y(
        (K) => K?.width === L.width && K.height === L.height ? K : L
      );
    };
    x();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(x);
    return p && b.current?.parentElement && C?.observe(b.current.parentElement), window.addEventListener("resize", x), () => {
      C?.disconnect(), window.removeEventListener("resize", x);
    };
  }, [p]);
  const w = g ? sr(n, g, {
    width: u,
    height: d
  }) : n, v = B(n);
  v.current = w;
  const N = (x, C) => {
    x.button !== 0 || h || x.target.closest(
      "button,input,textarea,a,[data-no-drag]"
    ) || (x.preventDefault(), x.currentTarget.setPointerCapture(x.pointerId), m.current = {
      mode: C,
      x: x.clientX,
      y: x.clientY,
      value: v.current
    }, l?.());
  };
  return /* @__PURE__ */ o(
    "div",
    {
      ref: b,
      className: "fp-floating-window",
      role: "region",
      "aria-label": t,
      style: h ? { position: p ? "absolute" : "fixed", inset: 8, zIndex: c } : {
        position: p ? "absolute" : "fixed",
        left: w.x,
        top: w.y,
        width: w.width,
        height: w.height,
        zIndex: c
      },
      onPointerDown: l,
      onPointerMove: (x) => {
        const C = m.current;
        if (!C) return;
        const I = g || {
          width: window.innerWidth,
          height: window.innerHeight
        }, L = x.clientX - C.x, K = x.clientY - C.y;
        r(
          sr(
            C.mode === "move" ? {
              ...C.value,
              x: C.value.x + L,
              y: C.value.y + K
            } : {
              ...C.value,
              width: Math.max(
                u,
                Math.min(
                  I.width - C.value.x,
                  C.value.width + L
                )
              ),
              height: Math.max(
                d,
                Math.min(
                  I.height - C.value.y,
                  C.value.height + K
                )
              )
            },
            I,
            { width: u, height: d }
          )
        );
      },
      onPointerUp: () => {
        m.current = null;
      },
      onPointerCancel: () => {
        m.current = null;
      },
      children: [
        /* @__PURE__ */ e(
          pl,
          {
            title: t,
            onClose: a,
            onMinimize: i,
            onFullscreen: () => f((x) => !x),
            isFullscreen: h,
            onDragStart: (x) => N(x, "move"),
            children: s
          }
        ),
        !h && /* @__PURE__ */ e(
          "div",
          {
            className: "fp-window-resize",
            role: "separator",
            "aria-label": "调整窗口大小",
            "aria-orientation": "horizontal",
            tabIndex: 0,
            onPointerDown: (x) => N(x, "resize"),
            onKeyDown: (x) => {
              ["ArrowRight", "ArrowLeft", "ArrowUp", "ArrowDown"].includes(
                x.key
              ) && (x.preventDefault(), r(
                sr(
                  {
                    ...w,
                    width: Math.max(
                      u,
                      w.width + (x.key === "ArrowRight" ? 16 : x.key === "ArrowLeft" ? -16 : 0)
                    ),
                    height: Math.max(
                      d,
                      w.height + (x.key === "ArrowDown" ? 16 : x.key === "ArrowUp" ? -16 : 0)
                    )
                  },
                  g || {
                    width: window.innerWidth,
                    height: window.innerHeight
                  },
                  { width: u, height: d }
                )
              ));
            }
          }
        )
      ]
    }
  );
}
function Iu({
  url: t,
  onNavigate: n,
  onBack: r,
  onForward: a,
  canBack: i,
  canForward: l,
  loading: s,
  error: c,
  children: u
}) {
  const [d, p] = k(t), [h, f] = k("");
  return Y(() => p(t), [t]), /* @__PURE__ */ o("section", { className: "fp-browser-surface", children: [
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: (m) => {
          m.preventDefault();
          try {
            const b = Fn(d);
            if (!b) throw Error();
            f(""), n(b);
          } catch {
            f("请输入有效的网址。");
          }
        },
        children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "后退",
              disabled: !i,
              onClick: r,
              children: "←"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              "aria-label": "前进",
              disabled: !l,
              onClick: a,
              children: "→"
            }
          ),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "网页地址",
              value: d,
              onChange: (m) => p(m.target.value)
            }
          ),
          /* @__PURE__ */ e("button", { type: "submit", children: "前往" })
        ]
      }
    ),
    (c || h) && /* @__PURE__ */ e("p", { role: "alert", children: c || h }),
    s && /* @__PURE__ */ e("p", { role: "status", children: "正在打开网页…" }),
    /* @__PURE__ */ e("div", { children: u })
  ] });
}
function Qh({
  title: t = "导入学习资料",
  accept: n,
  multiple: r = !0,
  onImport: a,
  children: i
}) {
  const l = B(null), [s, c] = k([]), [u, d] = k(""), p = (h) => {
    d(""), c(r ? h : h.slice(0, 1));
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "fp-import-drop",
        onDragOver: (h) => h.preventDefault(),
        onDrop: (h) => {
          h.preventDefault(), p(Array.from(h.dataTransfer.files));
        },
        children: [
          /* @__PURE__ */ e("p", { children: "将文件拖到这里，或选择文件。" }),
          /* @__PURE__ */ e(
            "input",
            {
              ref: l,
              type: "file",
              accept: n,
              multiple: r,
              hidden: !0,
              onChange: (h) => {
                p(Array.from(h.target.files || [])), h.target.value = "";
              }
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => l.current?.click(), children: "选择文件" })
        ]
      }
    ),
    s.length > 0 && /* @__PURE__ */ e("ul", { children: s.map((h, f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { children: h.name }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-label": `移除${h.name}`,
          onClick: () => c((m) => m.filter((b, g) => g !== f)),
          children: "移除"
        }
      )
    ] }, `${h.name}-${f}`)) }),
    i,
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !s.length,
        onAction: async () => {
          const h = s;
          try {
            await a(h), c((f) => f === h ? [] : f);
          } catch (f) {
            throw d("资料已保留，可以重试。"), f;
          }
        },
        children: "开始导入"
      }
    ) }),
    u && /* @__PURE__ */ e("p", { role: "status", children: u })
  ] });
}
function Zh({
  children: t,
  fallback: n = null,
  margin: r = "240px"
}) {
  const a = B(null), [i, l] = k(!1);
  return Y(() => {
    if (!a.current) return;
    if (typeof IntersectionObserver > "u") {
      l(!0);
      return;
    }
    const s = new IntersectionObserver(
      (c) => {
        c.some((u) => u.isIntersecting) && (l(!0), s.disconnect());
      },
      { rootMargin: r }
    );
    return s.observe(a.current), () => s.disconnect();
  }, [r]), /* @__PURE__ */ e("div", { ref: a, children: i ? t : n });
}
function ef({
  url: t,
  onNavigate: n,
  children: r,
  homeUrl: a,
  canBack: i,
  canForward: l,
  onBack: s,
  onForward: c,
  onRefresh: u,
  onOpenExternal: d,
  loading: p,
  error: h,
  viewport: f = "desktop",
  onViewportChange: m,
  bookmarks: b = [],
  onAddBookmark: g,
  onRemoveBookmark: y,
  onHomeChange: w
}) {
  const [v, N] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form fp-browser-workspace", children: [
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", "aria-label": "浏览器操作", children: [
      a && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "打开主页",
          onClick: () => {
            const x = Fn(a);
            x && n(x);
          },
          children: /* @__PURE__ */ e(no, { size: 17 })
        }
      ),
      u && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "刷新网页",
          onClick: u,
          children: /* @__PURE__ */ e(qn, { size: 17 })
        }
      ),
      m && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: () => m(f === "desktop" ? "mobile" : "desktop"),
          children: [
            f === "desktop" ? /* @__PURE__ */ e(ni, { size: 17 }) : /* @__PURE__ */ e(ro, { size: 17 }),
            /* @__PURE__ */ e("span", { children: f === "desktop" ? "桌面视图" : "手机视图" })
          ]
        }
      ),
      d && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "在浏览器中打开",
          onClick: () => d(t),
          children: /* @__PURE__ */ e(Kt, { size: 17 })
        }
      ),
      g && y && w && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          "aria-label": "浏览与收藏设置",
          "aria-expanded": v,
          onClick: () => N(!v),
          children: /* @__PURE__ */ e(ao, { size: 17 })
        }
      )
    ] }),
    /* @__PURE__ */ e(fe, { children: v && g && y && w && /* @__PURE__ */ e(
      zu,
      {
        bookmarks: b,
        homeUrl: a || "",
        onAdd: g,
        onRemove: y,
        onHomeChange: w,
        onOpen: (x) => {
          const C = b.find((I) => I.id === x);
          C && (n(C.url), N(!1));
        }
      }
    ) }),
    /* @__PURE__ */ e(
      Iu,
      {
        url: t,
        onNavigate: n,
        canBack: i,
        canForward: l,
        onBack: s,
        onForward: c,
        loading: p,
        error: h,
        children: /* @__PURE__ */ e("div", { className: "fp-browser-viewport", "data-viewport": f, children: r })
      }
    )
  ] });
}
function tf({
  users: t,
  groups: n,
  protectedUserIds: r = [],
  onSaveUser: a,
  onSaveGroup: i,
  onDeleteGroup: l,
  renderUserDetails: s,
  onRefresh: c,
  loading: u,
  error: d
}) {
  const [p, h] = k("users"), [f, m] = k(""), [b, g] = k(0), [y, w] = k(
    null
  ), v = Le(), N = (p === "users" ? t.map((C) => ({
    id: C.sub,
    label: C.name,
    description: C.email || C.sub,
    value: C
  })) : n.map((C) => ({
    id: C.id,
    label: C.name,
    description: `${C.members.length} 位成员 · ${C.description}`,
    value: C
  }))).filter(
    (C) => `${C.label} ${C.description}`.toLowerCase().includes(f.toLowerCase())
  ), x = Math.min(
    b,
    Math.max(0, Math.ceil(N.length / 20) - 1)
  );
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "用户与用户组", children: /* @__PURE__ */ o(
    ee,
    {
      title: "用户与授权",
      description: "管理成员资料、用户组和访问权限。",
      actions: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            disabled: u,
            onClick: () => w(
              p === "users" ? { sub: "", name: "", email: "", disabled: !1 } : {
                id: crypto.randomUUID(),
                name: "",
                description: "",
                members: []
              }
            ),
            children: p === "users" ? "添加用户" : "新建用户组"
          }
        ),
        c && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: v.busy,
            onClick: () => {
              v.run(c);
            },
            children: "刷新"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(
          Ve,
          {
            label: "成员类型",
            value: p,
            onChange: (C) => {
              h(C), g(0), m("");
            },
            items: [
              { id: "users", label: `用户 ${t.length}` },
              { id: "groups", label: `用户组 ${n.length}` }
            ]
          }
        ),
        /* @__PURE__ */ e(
          X,
          {
            label: "搜索成员",
            value: f,
            onChange: (C) => {
              m(C), g(0);
            }
          }
        ),
        /* @__PURE__ */ e(Se, { error: d || v.error, message: v.message }),
        u ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取成员…" }) : /* @__PURE__ */ o(Q, { children: [
          /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: N.slice(x * 20, x * 20 + 20).map((C) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              onClick: () => w(C.value),
              children: [
                /* @__PURE__ */ e("span", { className: "fp-workspace-avatar", children: C.label.slice(0, 1) }),
                /* @__PURE__ */ o("span", { children: [
                  /* @__PURE__ */ e("strong", { children: C.label }),
                  /* @__PURE__ */ e("small", { children: C.description })
                ] }),
                /* @__PURE__ */ e("span", { children: "管理" })
              ]
            },
            C.id
          )) }),
          !N.length && /* @__PURE__ */ e("p", { children: "没有匹配的成员，试试其他关键词。" }),
          /* @__PURE__ */ o("footer", { className: "fp-workspace-pagination", children: [
            /* @__PURE__ */ o("span", { children: [
              N.length,
              " 项"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: !x,
                onClick: () => g(x - 1),
                children: "上一页"
              }
            ),
            /* @__PURE__ */ o("span", { children: [
              x + 1,
              " /",
              " ",
              Math.max(1, Math.ceil(N.length / 20))
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-ghost",
                disabled: (x + 1) * 20 >= N.length,
                onClick: () => g(x + 1),
                children: "下一页"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(fe, { children: y && ("members" in y ? /* @__PURE__ */ e(
          Lu,
          {
            group: y,
            users: t,
            onSave: i,
            onDelete: n.some((C) => C.id === y.id) ? l : void 0,
            onClose: () => w(null)
          },
          y.id
        ) : s?.(y, () => w(null)) || /* @__PURE__ */ e(
          fl,
          {
            protectedUser: r.includes(y.sub),
            user: y,
            existing: t.some((C) => C.sub === y.sub),
            onSave: a,
            onClose: () => w(null)
          },
          y.sub || "new"
        )) })
      ]
    }
  ) });
}
function Lu({
  group: t,
  users: n,
  onSave: r,
  onDelete: a,
  onClose: i
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = nt(t), d = Le(), [p, h] = k("");
  return /* @__PURE__ */ o(
    ee,
    {
      title: l.name || "新建用户组",
      actions: /* @__PURE__ */ e(
        be,
        {
          confirm: c ? "放弃尚未保存的更改？" : void 0,
          disabled: d.busy,
          onAction: i,
          children: "关闭用户组"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组名称",
              value: l.name,
              onChange: (f) => s({ ...l, name: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "用户组说明",
              value: l.description,
              onChange: (f) => s({ ...l, description: f })
            }
          ),
          /* @__PURE__ */ e(
            X,
            {
              label: "搜索候选成员",
              value: p,
              onChange: h
            }
          ),
          /* @__PURE__ */ e("div", { className: "fp-workspace-picker", children: n.filter(
            (f) => `${f.name} ${f.email || ""} ${f.sub}`.toLowerCase().includes(p.toLowerCase())
          ).map((f) => /* @__PURE__ */ e(
            Ae,
            {
              label: f.name,
              description: f.email,
              checked: l.members.includes(f.sub),
              onChange: (m) => s({
                ...l,
                members: m ? [...l.members, f.sub] : l.members.filter((b) => b !== f.sub)
              })
            },
            f.sub
          )) }),
          /* @__PURE__ */ o("p", { children: [
            "已选 ",
            l.members.length,
            " 位成员"
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
            /* @__PURE__ */ e(
              it,
              {
                busy: d.busy,
                dirty: c,
                label: "保存用户组",
                onClick: () => {
                  if (!l.name.trim()) {
                    d.setError("请填写用户组名称。");
                    return;
                  }
                  d.run(async () => {
                    await r(l), u(l);
                  }, "用户组已保存。");
                }
              }
            ),
            a && /* @__PURE__ */ e(
              be,
              {
                confirm: "删除此用户组？通过该组获得的访问权限将失效。",
                onAction: async () => {
                  await a(l.id), i();
                },
                children: "删除用户组"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e(Se, { ...d })
      ]
    }
  );
}
function fl({
  user: t,
  existing: n = !0,
  protectedUser: r,
  onSave: a,
  emailEditable: i = !0,
  onClose: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = nt(t), p = Le();
  return /* @__PURE__ */ o(
    ee,
    {
      title: t.name || "添加用户",
      actions: l && /* @__PURE__ */ e(
        be,
        {
          confirm: u ? "放弃尚未保存的更改？" : void 0,
          disabled: p.busy,
          onAction: l,
          children: "关闭用户"
        }
      ),
      children: [
        /* @__PURE__ */ o("fieldset", { disabled: p.busy, children: [
          /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "账号",
                value: s.sub,
                disabled: n,
                onChange: (h) => c({ ...s, sub: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "显示名称",
                value: s.name,
                onChange: (h) => c({ ...s, name: h })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "邮箱",
                disabled: !i,
                hint: i ? void 0 : "邮箱由账号中心同步。",
                value: s.email || "",
                onChange: (h) => c({ ...s, email: h })
              }
            )
          ] }),
          /* @__PURE__ */ e(
            Ae,
            {
              label: "停用此用户",
              checked: !!s.disabled,
              disabled: r,
              description: r ? "此账号受到保护。" : "保存后生效。",
              onChange: (h) => c({ ...s, disabled: h })
            }
          ),
          /* @__PURE__ */ e(
            it,
            {
              busy: p.busy,
              dirty: u,
              label: "保存资料",
              onClick: () => {
                if (!/^[\w-]{1,128}$/.test(s.sub) || !s.name.trim()) {
                  p.setError("请填写有效的账号和显示名称。");
                  return;
                }
                p.run(async () => {
                  await a(s), d(s);
                }, "用户资料已保存。");
              }
            }
          )
        ] }),
        /* @__PURE__ */ e(Se, { ...p })
      ]
    }
  );
}
function ml({
  usedBytes: t,
  capacityBytes: n,
  onSave: r
}) {
  const {
    draft: a,
    setDraft: i,
    dirty: l,
    accept: s
  } = nt(
    String(Math.round(n / 1073741824 * 100) / 100)
  ), c = Le();
  return /* @__PURE__ */ o(
    ee,
    {
      title: "存储额度",
      description: `已使用 ${(t / 1024 ** 3).toFixed(2)} GB`,
      children: [
        /* @__PURE__ */ e(
          X,
          {
            label: "总存储额度（GB）",
            numeric: !0,
            value: a,
            onChange: i,
            hint: "调整额度会保留已上传的资料。"
          }
        ),
        /* @__PURE__ */ e(
          it,
          {
            busy: c.busy,
            dirty: l,
            onClick: () => {
              const u = Number(a);
              if (!Number.isFinite(u) || u < 1 || u > 102400) {
                c.setError("请输入 1 至 102400 GB 的有效额度。");
                return;
              }
              c.run(async () => {
                await r(u, n), s(a);
              }, "存储额度已保存。");
            }
          }
        ),
        /* @__PURE__ */ e(Se, { ...c })
      ]
    }
  );
}
function bl({
  name: t,
  enabled: n,
  protectedUser: r,
  onSave: a
}) {
  const {
    draft: i,
    setDraft: l,
    dirty: s,
    accept: c
  } = nt(n);
  return /* @__PURE__ */ o(
    ee,
    {
      title: "平台管理权限",
      description: "平台管理员可以管理课程、用户和计费配置。",
      children: [
        /* @__PURE__ */ e(
          Ae,
          {
            label: "允许进入管理中心",
            checked: i,
            disabled: r,
            description: r ? "当前账号或平台负责人的权限受到保护。" : void 0,
            onChange: l
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            disabled: r || !s,
            confirm: `确认${i ? "授予" : "收回"} ${t} 的平台管理权限？`,
            onAction: async () => {
              await a(i), c(i);
            },
            children: "保存权限"
          }
        )
      ]
    }
  );
}
function Tu({
  items: t,
  value: n,
  onChange: r,
  label: a = "产品导航",
  variant: i = "tabs",
  compact: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-product-navigation", "data-variant": i, "data-compact": l || void 0, "aria-label": a, children: t.map((s) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-label": l ? s.label : void 0,
      "data-fp-tooltip": s.label,
      "data-fp-tooltip-side": i === "rail" ? "right" : "bottom",
      "aria-current": s.id === n ? "page" : void 0,
      disabled: s.disabled,
      onClick: () => r(s.id),
      children: [
        s.icon,
        /* @__PURE__ */ e("span", { children: s.label }),
        s.detail && /* @__PURE__ */ e("small", { children: s.detail })
      ]
    },
    s.id
  )) });
}
function nf({
  items: t,
  onOpen: n,
  actions: r,
  loading: a,
  error: i,
  onCreate: l
}) {
  const [s, c] = k(""), u = t.filter(
    (d) => `${d.title} ${d.subtitle || ""} ${d.group || ""}`.toLowerCase().includes(s.toLowerCase())
  );
  return /* @__PURE__ */ o("section", { className: "fp-bookshelf", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "我的笔记本" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "新建笔记本" })
    ] }),
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(We, { size: 16 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索笔记本",
          value: s,
          placeholder: "搜索笔记本",
          onChange: (d) => c(d.target.value)
        }
      )
    ] }),
    i && /* @__PURE__ */ e("p", { role: "alert", children: i }),
    a ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : /* @__PURE__ */ e("div", { className: "fp-bookshelf-grid", children: u.map((d) => /* @__PURE__ */ e(
      yt,
      {
        disabled: !r,
        items: () => r?.(d) || [],
        label: `${d.title}的操作`,
        children: /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-book",
            onClick: () => n(d.id),
            children: [
              d.coverUrl ? /* @__PURE__ */ e("img", { src: d.coverUrl, alt: "" }) : /* @__PURE__ */ e("span", { className: "fp-book-cover", children: /* @__PURE__ */ e(bt, { size: 25 }) }),
              /* @__PURE__ */ e("strong", { children: d.title }),
              d.subtitle && /* @__PURE__ */ e("small", { children: d.subtitle }),
              d.detail && /* @__PURE__ */ e("small", { children: d.detail }),
              d.progress !== void 0 && /* @__PURE__ */ e(
                "progress",
                {
                  "aria-label": `${d.title}的学习进度`,
                  value: Math.min(100, Math.max(0, d.progress)),
                  max: 100
                }
              )
            ]
          }
        )
      },
      d.id
    )) }),
    !u.length && !a && /* @__PURE__ */ e("p", { children: s ? "没有找到匹配的笔记本。" : "创建一本笔记本，开始整理学习内容。" })
  ] });
}
function rf({
  title: t,
  onBack: n,
  actions: r
}) {
  return /* @__PURE__ */ o("header", { className: "fp-mobile-topbar", children: [
    n && /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回", onClick: n, children: "‹" }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: r })
  ] });
}
function af({
  title: t,
  navigation: n,
  activeId: r,
  onNavigate: a,
  profile: i,
  children: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-account-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: t }),
      i,
      /* @__PURE__ */ e(
        Tu,
        {
          items: n,
          value: r,
          onChange: a,
          label: "账户功能"
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-account-content", children: l })
  ] });
}
function lf({
  onLogin: t,
  heading: n = "登录课栈",
  description: r = "继续整理笔记，与同学一起学习。",
  alternate: a
}) {
  const [i, l] = k(""), [s, c] = k(""), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(!1), b = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel fp-login-form", children: [
    /* @__PURE__ */ e("h2", { children: n }),
    /* @__PURE__ */ e("p", { children: r }),
    /* @__PURE__ */ o(
      "form",
      {
        onSubmit: async (g) => {
          if (g.preventDefault(), !(b.current || !i.trim() || !s)) {
            b.current = !0, d(!0), h("");
            try {
              await t(i.trim(), s);
            } catch (y) {
              h(
                y instanceof Error ? y.message : "登录未能完成，请检查账号和密码。"
              );
            } finally {
              b.current = !1, d(!1);
            }
          }
        },
        children: [
          /* @__PURE__ */ o("label", { children: [
            "账号",
            /* @__PURE__ */ e(
              "input",
              {
                "aria-label": "账号",
                autoComplete: "username",
                required: !0,
                value: i,
                disabled: u,
                onChange: (g) => l(g.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ o("label", { children: [
            "密码",
            /* @__PURE__ */ o("div", { className: "fp-password-entry", children: [
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "密码",
                  autoComplete: "current-password",
                  required: !0,
                  type: f ? "text" : "password",
                  value: s,
                  disabled: u,
                  onChange: (g) => c(g.target.value)
                }
              ),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  "aria-label": f ? "隐藏密码" : "显示密码",
                  onClick: () => m((g) => !g),
                  children: f ? "隐藏" : "显示"
                }
              )
            ] })
          ] }),
          p && /* @__PURE__ */ e("p", { role: "alert", children: p }),
          /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e("button", { type: "submit", disabled: u || !i.trim() || !s, children: u ? "正在登录…" : "登录" }) })
        ]
      }
    ),
    a
  ] });
}
function of({
  name: t,
  avatarUrl: n,
  description: r,
  details: a,
  actions: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { className: "fp-profile-heading", children: [
        n ? /* @__PURE__ */ e("img", { src: n, alt: "" }) : /* @__PURE__ */ e("span", { "aria-hidden": "true", children: t.slice(0, 1) }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: t }),
          r && /* @__PURE__ */ e("small", { children: r })
        ] })
      ] }),
      i
    ] }),
    /* @__PURE__ */ e("dl", { className: "fp-detail-list", children: a.map((l, s) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, s)) })
  ] });
}
function Du({
  name: t,
  balance: n,
  onSubmit: r
}) {
  const [a, i] = k(""), [l, s] = k(""), c = Number(a);
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("h3", { children: [
      "调整",
      t,
      "的积分"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "当前可用 ",
      n.toLocaleString(),
      " 积分"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-settings-fields", children: [
      /* @__PURE__ */ o("label", { children: [
        "调整数量",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整数量",
            inputMode: "numeric",
            value: a,
            onChange: (u) => i(u.target.value)
          }
        ),
        /* @__PURE__ */ e("small", { children: "正数增加，负数扣减。" })
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "调整原因",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": "调整原因",
            value: l,
            onChange: (u) => s(u.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !a.trim() || !Number.isSafeInteger(c) || c === 0 || !l.trim() || n + c < 0,
        confirm: `将${c >= 0 ? "增加" : "扣减"} ${Math.abs(c) || 0} 积分，确认继续？`,
        onAction: () => r(c, l.trim()),
        children: "确认调整"
      }
    ) })
  ] });
}
function Pu({
  item: t,
  onRespond: n
}) {
  const [r, a] = k(!1), i = B(!1), l = async (s) => {
    if (!i.current) {
      i.current = !0, a(!0);
      try {
        await n(t.id, s);
      } finally {
        i.current = !1, a(!1);
      }
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
    /* @__PURE__ */ e(be, { disabled: r, onAction: () => l(!0), children: "接受" }),
    /* @__PURE__ */ e(be, { disabled: r, onAction: () => l(!1), children: "婉拒" })
  ] });
}
function sf({
  items: t,
  onRespond: n,
  loading: r,
  error: a
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "协作邀请" }),
    a && /* @__PURE__ */ e("p", { role: "alert", children: a }),
    /* @__PURE__ */ e(fe, { children: r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取邀请…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((i) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: i.name }),
        /* @__PURE__ */ o("small", { children: [
          i.from,
          " 邀请你",
          i.role,
          i.date && ` · ${i.date}`
        ] })
      ] }),
      /* @__PURE__ */ e(Pu, { item: i, onRespond: n })
    ] }, i.id)) }) : /* @__PURE__ */ e("p", { children: "暂时没有待处理的邀请。" }) })
  ] });
}
function cf({
  items: t,
  value: n,
  onChange: r,
  label: a = "选择目录",
  onConfirm: i
}) {
  const l = (s) => {
    const c = [s.name], u = /* @__PURE__ */ new Set([s.id]);
    let d = s;
    for (; d.parentId; ) {
      const p = t.find((h) => h.id === d.parentId);
      if (!p || u.has(p.id)) break;
      c.unshift(p.name), u.add(p.id), d = p;
    }
    return c.join(" / ");
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: a }),
    /* @__PURE__ */ e(
      ke,
      {
        label: a,
        value: n,
        onChange: r,
        searchable: !0,
        options: t.map((s) => ({
          value: s.id,
          label: s.name,
          description: l(s),
          disabled: s.disabled
        }))
      }
    ),
    i && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        disabled: !t.some((s) => s.id === n && !s.disabled),
        onAction: i,
        children: "选择此目录"
      }
    ) })
  ] });
}
function df({
  plans: t,
  onSelect: n
}) {
  return /* @__PURE__ */ e("section", { className: "fp-plan-picker", "aria-label": "选择方案", children: t.map((r) => /* @__PURE__ */ o(
    "article",
    {
      className: "fp-pattern-panel",
      "data-current": r.current || void 0,
      children: [
        /* @__PURE__ */ e("h3", { children: r.name }),
        /* @__PURE__ */ e("strong", { className: "fp-summary-value", children: r.price }),
        /* @__PURE__ */ e("p", { children: r.description }),
        /* @__PURE__ */ e("ul", { children: r.features.map((a) => /* @__PURE__ */ e("li", { children: a }, a)) }),
        /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            disabled: r.current || r.disabled,
            onClick: () => n(r.id),
            children: r.current ? "当前方案" : "查看方案"
          }
        ) })
      ]
    },
    r.id
  )) });
}
function uf(t) {
  return /* @__PURE__ */ e(Fu, { ...t }, t.user.sub || "new");
}
function Fu({
  user: t,
  groups: n,
  existing: r = !0,
  protectedUser: a,
  storage: i,
  credits: l,
  administrator: s,
  loading: c,
  error: u,
  onSaveProfile: d,
  onSaveCapacity: p,
  onAdjustCredits: h,
  onSaveAdministrator: f,
  onRetry: m,
  canManageAdministrator: b = !0,
  emailEditable: g = !0,
  usage: y,
  notebooks: w
}) {
  const [v, N] = k("profile");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: v === "profile" ? void 0 : t.name || "添加用户", children: [
    /* @__PURE__ */ e(
      Ve,
      {
        label: "用户详情",
        value: v,
        onChange: N,
        items: [
          { id: "profile", label: "资料" },
          ...r ? [
            ...y ? [{ id: "usage", label: "使用统计" }] : [],
            ...w ? [{ id: "notebooks", label: "笔记本" }] : [],
            { id: "storage", label: "存储" },
            { id: "credits", label: "积分" },
            { id: "access", label: "平台权限" }
          ] : []
        ]
      }
    ),
    /* @__PURE__ */ e(Se, { error: u }),
    u && m && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: m,
        children: "重试"
      }
    ),
    /* @__PURE__ */ o(fe, { children: [
      /* @__PURE__ */ e("div", { hidden: v !== "usage", children: y }),
      /* @__PURE__ */ e("div", { hidden: v !== "notebooks", children: w }),
      /* @__PURE__ */ o("div", { hidden: v !== "profile", children: [
        /* @__PURE__ */ e(
          fl,
          {
            user: t,
            emailEditable: g,
            existing: r,
            protectedUser: a,
            onSave: d
          }
        ),
        /* @__PURE__ */ e(ee, { title: "所在用户组", children: /* @__PURE__ */ e("p", { children: n.filter((x) => x.members.includes(t.sub)).map((x) => x.name).join("、") || "尚未加入用户组" }) })
      ] }),
      /* @__PURE__ */ e("div", { hidden: v !== "storage", children: i && p ? /* @__PURE__ */ e(
        ml,
        {
          usedBytes: i.used,
          capacityBytes: i.capacity,
          onSave: p
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取存储信息…" : "存储信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: v !== "credits", children: l !== void 0 && h ? /* @__PURE__ */ e(
        Du,
        {
          name: t.name,
          balance: l,
          onSubmit: h
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取积分…" : "积分信息暂不可用。" }) }),
      /* @__PURE__ */ e("div", { hidden: v !== "access", children: b ? s !== void 0 && f ? /* @__PURE__ */ e(
        bl,
        {
          name: t.name,
          enabled: s,
          protectedUser: a,
          onSave: f
        }
      ) : /* @__PURE__ */ e("p", { role: "status", children: c ? "正在读取管理权限…" : "管理权限暂不可用。" }) : /* @__PURE__ */ o(ee, { title: "平台管理权限", children: [
        /* @__PURE__ */ e("p", { children: s ? "平台管理员" : "普通用户" }),
        /* @__PURE__ */ e("p", { children: "仅超级管理员可以调整平台管理权限。" })
      ] }) })
    ] })
  ] }) });
}
function pf({
  value: t,
  onSave: n,
  onConfigureStorage: r
}) {
  const { draft: a, setDraft: i, dirty: l, accept: s } = nt(t), c = Le(), u = a.documentProcessing.quark, d = (h, f) => i({
    ...a,
    providers: a.providers.map(
      (m, b) => b === h ? { ...m, ...f } : m
    )
  }), p = (h) => i({
    ...a,
    documentProcessing: {
      ...a.documentProcessing,
      quark: { ...u, ...h }
    }
  });
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "站点与学习服务",
      description: "管理站点信息、模型连接和资料识别。",
      actions: /* @__PURE__ */ e(
        it,
        {
          busy: c.busy,
          dirty: l,
          onClick: () => {
            if (!a.siteName.trim() || !a.accountName.trim() || a.supportUrl && !/^https?:\/\//.test(a.supportUrl) || !Number.isInteger(u.pagesPerRequest) || u.pagesPerRequest < 1 || u.pagesPerRequest > 4 || new Set(a.providers.map((h) => h.id)).size !== a.providers.length || a.providers.some(
              (h) => !/^[a-z0-9-]+$/.test(h.id) || !h.name.trim() || h.enabled && !/^https?:\/\//.test(h.baseUrl)
            )) {
              c.setError("请检查站点名称、服务地址和识别页数。");
              return;
            }
            c.run(
              async () => s(await n(a) || a),
              "平台设置已保存。"
            );
          }
        }
      ),
      children: [
        /* @__PURE__ */ e(Se, { ...c }),
        /* @__PURE__ */ o("fieldset", { disabled: c.busy, children: [
          /* @__PURE__ */ o(ee, { title: "站点信息", children: [
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "站点名称",
                  value: a.siteName,
                  onChange: (h) => i({ ...a, siteName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "账号品牌",
                  value: a.accountName,
                  onChange: (h) => i({ ...a, accountName: h })
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "帮助中心地址",
                  value: a.supportUrl,
                  onChange: (h) => i({ ...a, supportUrl: h })
                }
              )
            ] }),
            r && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-button fp-secondary",
                onClick: r,
                children: "配置资料存储"
              }
            )
          ] }),
          /* @__PURE__ */ e(
            ee,
            {
              title: "模型供应商",
              description: "保存密钥后，仅显示配置状态。",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => i({
                    ...a,
                    providers: [
                      ...a.providers,
                      {
                        id: `service-${crypto.randomUUID().slice(0, 8)}`,
                        name: "模型服务",
                        baseUrl: "",
                        apiKey: "",
                        enabled: !1,
                        models: []
                      }
                    ]
                  }),
                  children: "添加供应商"
                }
              ),
              children: a.providers.map((h, f) => /* @__PURE__ */ o(ee, { title: h.name || "模型服务", children: [
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "连接标识",
                      value: h.id,
                      onChange: (m) => d(f, { id: m }),
                      hint: "使用小写字母、数字和连字符。"
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务名称",
                      value: h.name,
                      onChange: (m) => d(f, { name: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务地址",
                      value: h.baseUrl,
                      onChange: (m) => d(f, { baseUrl: m })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "服务密钥",
                      secret: !0,
                      value: h.apiKey,
                      hint: h.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (m) => d(f, { apiKey: m })
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "可用模型",
                    multiline: !0,
                    value: h.models.join(`
`),
                    hint: "每行填写一个模型名称。",
                    onChange: (m) => d(f, {
                      models: m.split(`
`).map((b) => b.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  Ae,
                  {
                    label: `启用 ${h.name}`,
                    checked: h.enabled,
                    onChange: (m) => d(f, { enabled: m })
                  }
                ),
                /* @__PURE__ */ e(
                  be,
                  {
                    confirm: "移除此供应商？保存后生效。",
                    onAction: () => i({
                      ...a,
                      providers: a.providers.filter((m, b) => b !== f)
                    }),
                    children: "移除供应商"
                  }
                )
              ] }, f))
            }
          ),
          /* @__PURE__ */ o(
            ee,
            {
              title: "扫描识别",
              description: "将扫描资料中的文字、表格与公式转为可阅读内容。",
              children: [
                /* @__PURE__ */ e(
                  Ae,
                  {
                    label: "启用扫描识别",
                    checked: u.enabled,
                    onChange: (h) => p({ enabled: h })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "识别服务密钥",
                      secret: !0,
                      value: u.apiKey,
                      hint: u.keyConfigured ? "已配置；留空保留当前密钥。" : void 0,
                      onChange: (h) => p({ apiKey: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "默认识别方式",
                      value: u.scene,
                      options: [
                        { value: "general-ocr", label: "通用识别" },
                        { value: "formula-recognition", label: "公式识别" },
                        { value: "table-recognition", label: "表格识别" }
                      ],
                      onChange: (h) => p({ scene: h })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "每批处理页数",
                      numeric: !0,
                      value: u.pagesPerRequest,
                      onChange: (h) => p({ pagesPerRequest: Number(h) })
                    }
                  )
                ] })
              ]
            }
          )
        ] })
      ]
    }
  ) });
}
function hf({
  users: t,
  enabledIds: n,
  protectedIds: r,
  onSave: a
}) {
  const [i, l] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "平台管理员", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索管理员账户",
        value: i,
        onChange: l
      }
    ),
    t.filter(
      (s) => `${s.name} ${s.email || ""} ${s.sub}`.toLowerCase().includes(i.toLowerCase())
    ).map((s) => /* @__PURE__ */ e(
      bl,
      {
        name: s.name,
        enabled: n.includes(s.sub),
        protectedUser: r.includes(s.sub),
        onSave: (c) => a(s.sub, c)
      },
      `${s.sub}-${n.includes(s.sub)}`
    ))
  ] }) });
}
function ff({
  entries: t,
  onSave: n
}) {
  const [r, a] = k("");
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(ee, { title: "用户存储", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: "搜索存储账户",
        value: r,
        onChange: a
      }
    ),
    t.filter(
      (i) => i.name.toLowerCase().includes(r.toLowerCase())
    ).map((i) => /* @__PURE__ */ e(ee, { title: i.name, children: /* @__PURE__ */ e(
      ml,
      {
        usedBytes: i.used,
        capacityBytes: i.capacity,
        onSave: (l, s) => n(i.id, l, s)
      }
    ) }, i.id))
  ] }) });
}
function mf({
  canReset: t,
  confirmation: n = "重置课栈平台",
  onReset: r
}) {
  const [a, i] = k(""), l = Le();
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", children: /* @__PURE__ */ o(
    ee,
    {
      title: "重新配置平台",
      description: "重新设置平台服务，已保存的课程、笔记和资料会保留。",
      children: [
        t ? /* @__PURE__ */ o(Q, { children: [
          /* @__PURE__ */ e(
            X,
            {
              label: `输入“${n}”确认`,
              value: a,
              onChange: i,
              disabled: l.busy
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              disabled: l.busy || a !== n,
              onClick: () => {
                l.run(r, "平台配置已重置。");
              },
              children: l.busy ? "正在重新配置…" : "重置并重新配置"
            }
          )
        ] }) : /* @__PURE__ */ e("p", { children: "请联系平台负责人进行此项操作。" }),
        /* @__PURE__ */ e(Se, { ...l })
      ]
    }
  ) });
}
function bf({
  questions: t,
  onSelect: n,
  sourceCount: r = 0,
  onOpenSources: a,
  title: i = "你可能还想问"
}) {
  return /* @__PURE__ */ e(fe, { children: (t.length > 0 || r > 0) && /* @__PURE__ */ o("section", { className: "fp-followup-questions", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t.length ? i : "参考资料" }),
      r > 0 && a && /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-ghost",
          onClick: a,
          children: [
            "来源 · ",
            r
          ]
        }
      )
    ] }),
    t.map((l, s) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-followup-question",
        onClick: () => n(l),
        children: /* @__PURE__ */ e(
          ci,
          {
            remarkPlugins: [di],
            rehypePlugins: [ui],
            components: {
              a: ({ children: c }) => /* @__PURE__ */ e("span", { children: c }),
              img: ({ alt: c }) => /* @__PURE__ */ e("span", { children: c })
            },
            children: l
          }
        )
      },
      s
    ))
  ] }) });
}
function gl({ label: t = "正在打开内容", variant: n = "document" }) {
  return /* @__PURE__ */ o("div", { className: `fp-content-skeleton fp-content-skeleton-${n}`, role: "status", "aria-label": t, "aria-busy": "true", children: [
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-title" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" }),
    /* @__PURE__ */ e("div", { className: "fp-content-skeleton-block" }),
    /* @__PURE__ */ e("span", {}),
    /* @__PURE__ */ e("span", { className: "fp-content-skeleton-short" })
  ] });
}
function gf({
  title: t,
  markdown: n,
  entries: r = [],
  selectedId: a,
  onNavigate: i,
  headings: l = [],
  loading: s,
  error: c,
  onRetry: u,
  access: d = "granted",
  onSignIn: p,
  toolbar: h,
  footer: f,
  onCopyReference: m,
  contentProps: b,
  content: g,
  navigation: y,
  brand: w,
  account: v,
  collection: N
}) {
  const [x, C] = k(null), [I, L] = k(""), K = Le(), S = ve().replace(/:/g, ""), [A, D] = k(""), U = B(null);
  Y(() => {
    if (!x) return;
    const q = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const F = (E) => {
      E.key === "Escape" && C(null);
    };
    return window.addEventListener("keydown", F), () => {
      window.removeEventListener("keydown", F), document.body.style.overflow = q, U.current?.focus({ preventScroll: !0 });
    };
  }, [x]), Y(() => {
    if (!l.length || typeof IntersectionObserver > "u") return;
    const q = document.getElementById(S);
    if (!q) return;
    const F = /* @__PURE__ */ new Map(), E = new IntersectionObserver(
      (z) => {
        for (const P of z)
          P.isIntersecting ? F.set(P.target.id, P.boundingClientRect.top) : F.delete(P.target.id);
        const $ = [...F].sort((P, re) => P[1] - re[1])[0];
        $ && L($[0]);
      },
      { rootMargin: "-10% 0px -65% 0px" }
    );
    for (const z of q.querySelectorAll("h2[id],h3[id],h4[id]"))
      E.observe(z);
    return () => E.disconnect();
  }, [S, n, l.length, s, d]), Y(() => {
    C(null), L("");
  }, [a]);
  const T = n.trimStart().match(/^#\s+(.+?)(?:\s+#+)?\s*(?:\r?\n|$)/)?.[1].trim() !== t.trim(), M = y ?? /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ e("h2", { children: "笔记目录" }),
    /* @__PURE__ */ e(
      "input",
      {
        className: "fp-input",
        "aria-label": "搜索分享笔记",
        value: A,
        placeholder: "搜索笔记",
        onChange: (q) => D(q.target.value)
      }
    ),
    /* @__PURE__ */ e("nav", { "aria-label": "分享笔记", children: r.filter(
      (q) => `${q.title} ${q.group || ""}`.toLowerCase().includes(A.toLowerCase())
    ).map((q, F, E) => /* @__PURE__ */ o("div", { children: [
      q.group && (F === 0 || E[F - 1].group !== q.group) && /* @__PURE__ */ e("h3", { children: q.group }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-note",
          "aria-current": a === q.id ? "page" : void 0,
          onClick: () => {
            i?.(q.id), C(null);
          },
          children: q.title
        }
      )
    ] }, q.id)) })
  ] }), R = /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ e("h2", { children: "本页目录" }),
    /* @__PURE__ */ e("nav", { "aria-label": "本页目录", children: l.map((q) => /* @__PURE__ */ e(
      "a",
      {
        href: `#${q.id}`,
        "aria-current": I === q.id ? "location" : void 0,
        style: {
          paddingInlineStart: Math.max(0, q.level - 1) * 12 + 12
        },
        onClick: (F) => {
          F.preventDefault(), document.getElementById(S)?.querySelector(`[id="${CSS.escape(q.id)}"]`)?.scrollIntoView({
            behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
            block: "start"
          }), L(q.id), C(null);
        },
        children: q.title
      },
      q.id
    )) })
  ] });
  return /* @__PURE__ */ o("div", { className: "fp-shared-reading", children: [
    /* @__PURE__ */ o("header", { className: "fp-shared-header", children: [
      w ?? /* @__PURE__ */ e("a", { href: "https://fiveplus.one/", "aria-label": "五加一主页", children: /* @__PURE__ */ e(
        "img",
        {
          src: "https://go.r-l.ink/ico",
          alt: "五加一",
          width: 28,
          height: 28
        }
      ) }),
      /* @__PURE__ */ e("strong", { children: N?.title || t }),
      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
        h,
        v,
        p && d !== "granted" && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-shared-mobile-bar", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (q) => {
            U.current = q.currentTarget, C("notes");
          },
          children: [
            /* @__PURE__ */ e(rn, { size: 16 }),
            "笔记"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: (q) => {
            U.current = q.currentTarget, C("contents");
          },
          children: [
            /* @__PURE__ */ e(nn, { size: 16 }),
            "目录"
          ]
        }
      )
    ] }),
    x && /* @__PURE__ */ e(
      "div",
      {
        className: "fp-shared-drawer-backdrop",
        onClick: () => C(null),
        children: /* @__PURE__ */ o(
          "aside",
          {
            className: "fp-shared-drawer",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": x === "notes" ? "笔记目录" : "本页目录",
            onClick: (q) => q.stopPropagation(),
            onKeyDown: (q) => {
              if (q.key !== "Tab") return;
              const F = [
                ...q.currentTarget.querySelectorAll(
                  "button,a,input"
                )
              ], E = F[0], z = F.at(-1);
              q.shiftKey && document.activeElement === E ? (q.preventDefault(), z?.focus()) : !q.shiftKey && document.activeElement === z && (q.preventDefault(), E?.focus());
            },
            children: [
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  autoFocus: !0,
                  className: "fp-shared-close",
                  "aria-label": "关闭目录",
                  onClick: () => C(null),
                  children: /* @__PURE__ */ e(ge, { size: 18 })
                }
              ),
              x === "notes" ? M : R
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ o("div", { className: "fp-shared-layout", children: [
      /* @__PURE__ */ e("aside", { className: "fp-shared-navigation", children: M }),
      /* @__PURE__ */ e("main", { id: S, children: /* @__PURE__ */ e(fe, { children: s ? /* @__PURE__ */ e(gl, { label: "正在打开笔记" }) : c ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: c }),
        u && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            onClick: u,
            children: "重试"
          }
        )
      ] }) : d !== "granted" ? /* @__PURE__ */ o("div", { className: "fp-workspace-empty", children: [
        /* @__PURE__ */ e("h1", { children: d === "sign-in" ? "登录后阅读" : "这篇笔记尚未向你分享" }),
        /* @__PURE__ */ e("p", { children: d === "sign-in" ? "登录账户，继续查看分享内容。" : "请联系分享者获取访问权限。" }),
        d === "sign-in" && p && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-primary",
            onClick: p,
            children: "登录并继续"
          }
        )
      ] }) : /* @__PURE__ */ o(Q, { children: [
        N && /* @__PURE__ */ o("section", { className: "fp-shared-collection", "aria-label": "分享笔记本", children: [
          /* @__PURE__ */ o("div", { className: "fp-shared-collection-title", children: [
            /* @__PURE__ */ e(bt, { size: 23, "aria-hidden": "true" }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("strong", { children: N.title }),
              N.byline && /* @__PURE__ */ e("span", { children: N.byline })
            ] })
          ] }),
          N.description && /* @__PURE__ */ e("p", { children: N.description }),
          N.actions && /* @__PURE__ */ e("div", { className: "fp-shared-collection-actions", children: N.actions })
        ] }),
        T && /* @__PURE__ */ e("h1", { children: t }),
        m && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: K.busy,
            onClick: () => {
              K.run(
                () => m({
                  title: t,
                  text: (() => {
                    const q = window.getSelection();
                    return q?.anchorNode && document.getElementById(S)?.contains(q.anchorNode) && q.toString() || t;
                  })(),
                  heading: I || void 0
                }),
                "引用已复制"
              );
            },
            children: [
              /* @__PURE__ */ e(Kn, { size: 15 }),
              "复制引用"
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...K }),
        g ?? /* @__PURE__ */ e(vt, { ...b, markdown: n }),
        f
      ] }) }) }),
      /* @__PURE__ */ e("aside", { className: "fp-shared-contents", children: R })
    ] })
  ] });
}
function vf({
  available: t,
  onRefresh: n,
  onDismiss: r,
  beforeRefresh: a
}) {
  const i = Le();
  return /* @__PURE__ */ e(fe, { children: t && /* @__PURE__ */ o("aside", { className: "fp-release-notice", "aria-label": "应用更新", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("strong", { children: "新版本已就绪" }),
      /* @__PURE__ */ e("p", { children: "更新后继续使用最新功能。" }),
      /* @__PURE__ */ e(Se, { ...i })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-button fp-primary",
          disabled: i.busy,
          onClick: () => {
            i.run(async () => {
              if (a && !await a()) {
                i.setMessage("请先保存当前内容。");
                return;
              }
              await n();
            });
          },
          children: i.busy ? "正在更新…" : "立即更新"
        }
      ),
      r && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-shared-close",
          "aria-label": "稍后更新",
          onClick: r,
          children: /* @__PURE__ */ e(ge, { size: 17 })
        }
      )
    ] })
  ] }) });
}
function yf({
  currentVersion: t,
  checkVersion: n,
  interval: r = 6e4,
  enabled: a = !0,
  onError: i
}) {
  const [l, s] = k(t), [c, u] = k(""), d = B({ checkVersion: n, onError: i });
  return d.current = { checkVersion: n, onError: i }, Y(() => {
    if (!a) return;
    let p = null, h = !0;
    const f = async () => {
      if (p || document.visibilityState === "hidden") return;
      const g = new AbortController();
      p = g;
      try {
        const y = await d.current.checkVersion(g.signal);
        h && !g.signal.aborted && y && s(y);
      } catch (y) {
        g.signal.aborted || d.current.onError?.(y);
      } finally {
        p === g && (p = null);
      }
    }, m = () => {
      f();
    }, b = setInterval(m, Math.max(1e3, r));
    return window.addEventListener("focus", m), document.addEventListener("visibilitychange", m), m(), () => {
      h = !1, p?.abort(), clearInterval(b), window.removeEventListener("focus", m), document.removeEventListener("visibilitychange", m);
    };
  }, [t, r, a]), {
    available: l !== t && l !== c,
    version: l,
    dismiss: () => u(l)
  };
}
function wf({
  value: t,
  onChange: n,
  onRevise: r,
  renderMolecule: a,
  recorder: i,
  onDiagnostic: l
}) {
  const [s, c] = k(null), [u, d] = k("current"), p = Le(), h = B(null), f = B(t);
  return f.current = t, Y(() => () => h.current?.abort(), []), Y(() => {
    c(null), d("current"), h.current?.abort();
  }, [t]), /* @__PURE__ */ e(Pi.Provider, { value: a || null, children: /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-canvas-workspace", children: /* @__PURE__ */ o(
    ee,
    {
      title: t.title || "学习画布",
      description: "探索图形，提出修改，再确认需要保留的版本。",
      children: [
        /* @__PURE__ */ e(
          Ve,
          {
            label: "画布版本",
            value: u,
            onChange: d,
            items: [
              { id: "current", label: "当前版本" },
              ...s ? [{ id: "candidate", label: "修改预览" }] : [],
              ...i ? [{ id: "recording", label: "操作回放" }] : []
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...p }),
        /* @__PURE__ */ e(fe, { children: u === "recording" ? i : /* @__PURE__ */ e(
          kr,
          {
            block: u === "candidate" && s ? s : t,
            onRevisionSubmit: r ? async (m) => {
              h.current?.abort();
              const b = new AbortController();
              h.current = b;
              let g;
              const y = t;
              if (!await p.run(async () => {
                try {
                  const v = await r(
                    y,
                    m,
                    b.signal
                  );
                  if (b.signal.aborted || f.current !== y)
                    return;
                  c(v), d("candidate");
                } catch (v) {
                  throw g = v, v;
                }
              }))
                throw l?.(g), new Error("画布修改未完成，请保留输入后重试。");
            } : void 0
          }
        ) }),
        s && /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-primary",
              onClick: () => {
                n(s), c(null), d("current");
              },
              children: "采用此版本"
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-button fp-secondary",
              onClick: () => {
                c(null), d("current");
              },
              children: "保留当前版本"
            }
          )
        ] })
      ]
    }
  ) }) });
}
const gn = (t) => Number.isFinite(t) && t >= 0;
function Ou(t) {
  if (!(t.creditsPerYuan > 0 && t.creditsPerYuan <= 1e4) || !((t.costMultiplier ?? 1) > 0 && (t.costMultiplier ?? 1) <= 100))
    return "请填写有效的积分比例和成本倍率。";
  if (Object.values(t.serviceRates).some((n) => !gn(n) || n > 1e4))
    return "请填写有效的资料处理价格。";
  if (Object.entries(t.modelRates || {}).some(
    ([n, r]) => !n.trim() || Object.values(r).some((a) => !gn(a) || a > 1e5)
  ))
    return "请检查模型名称和价格。";
  if (new Set(t.plans.map((n) => n.id)).size !== t.plans.length || t.plans.length > 30 || t.plans.some(
    (n) => !n.name.trim() || !Number.isInteger(n.days) || n.days < 1 || n.days > 3660 || !gn(n.priceYuan) || n.priceYuan <= 0 || n.priceYuan > 1e4 || !gn(n.credits) || n.credits > 1e6 || !(n.discount >= 0 && n.discount <= 1)
  ))
    return "请检查会员名称、天数、价格及折扣。";
  if (t.enabled && (!/^https?:\/\//.test(t.gateway) || !t.pid.trim()))
    return "启用支付前，请填写支付网关和商户号。";
}
function kf({
  value: t,
  onSave: n,
  onSyncPrices: r,
  readOnly: a
}) {
  const { draft: i, setDraft: l, dirty: s, accept: c } = nt(t), u = Le(), [d, p] = k("credits"), [h, f] = k(""), [m, b] = k(""), g = (v, N) => l({ ...i, [v]: N }), y = (v = []) => {
    if (r) {
      if (s) {
        u.setError("请先保存当前更改，再同步价格。");
        return;
      }
      u.run(
        async () => c(await r(v)),
        "模型价格已同步。"
      );
    }
  }, w = () => {
    const v = Ou(i);
    if (v) {
      u.setError(v);
      return;
    }
    u.run(
      async () => c(await n(i) || i),
      "积分与会员设置已保存。"
    );
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "积分与会员设置", children: /* @__PURE__ */ o(
    ee,
    {
      title: "积分与会员",
      description: "管理充值、会员权益和服务价格。",
      actions: /* @__PURE__ */ e(
        it,
        {
          busy: u.busy,
          dirty: s && !a,
          onClick: w
        }
      ),
      children: [
        /* @__PURE__ */ e(
          Ve,
          {
            label: "计费设置",
            value: d,
            onChange: p,
            items: [
              { id: "credits", label: "充值与积分" },
              { id: "plans", label: "会员计划" },
              { id: "payment", label: "支付接入" },
              { id: "models", label: "模型价格" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...u }),
        /* @__PURE__ */ e("fieldset", { disabled: u.busy || a, children: /* @__PURE__ */ o(fe, { children: [
          d === "credits" && /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e(ee, { title: "积分规则", children: /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "每元兑换积分",
                  numeric: !0,
                  value: i.creditsPerYuan,
                  onChange: (v) => g("creditsPerYuan", Number(v))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "成本倍率",
                  numeric: !0,
                  value: i.costMultiplier ?? 1,
                  onChange: (v) => g("costMultiplier", Number(v))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "单次回复积分",
                  numeric: !0,
                  value: i.replyCredits ?? 0,
                  onChange: (v) => g("replyCredits", Number(v))
                }
              )
            ] }) }),
            /* @__PURE__ */ e(
              ee,
              {
                title: "资料处理价格",
                description: "按实际处理次数计费。",
                children: /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                  ["quarkOcrRequest", "扫描识别（每次）"],
                  ["documentOrganization", "资料整理（每次）"],
                  ["webSearch", "联网搜索（每次）"]
                ].map(([v, N]) => /* @__PURE__ */ e(
                  X,
                  {
                    label: N,
                    numeric: !0,
                    value: i.serviceRates[v],
                    onChange: (x) => g("serviceRates", {
                      ...i.serviceRates,
                      [v]: Number(x)
                    })
                  },
                  v
                )) })
              }
            )
          ] }),
          d === "plans" && /* @__PURE__ */ o(
            ee,
            {
              title: "会员计划",
              actions: /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  disabled: i.plans.length >= 30,
                  onClick: () => g("plans", [
                    ...i.plans,
                    {
                      id: crypto.randomUUID(),
                      name: "学习会员",
                      days: 30,
                      priceYuan: 10,
                      credits: 100,
                      discount: 0.9,
                      enabled: !1
                    }
                  ]),
                  children: "添加会员计划"
                }
              ),
              children: [
                i.plans.map((v, N) => /* @__PURE__ */ o(
                  ee,
                  {
                    title: v.name || "新会员计划",
                    children: [
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["name", "计划名称"],
                        ["days", "有效天数"],
                        ["priceYuan", "价格（元）"],
                        ["credits", "附赠积分"],
                        ["discount", "对话价格系数"]
                      ].map(([x, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: C,
                          numeric: x !== "name",
                          value: v[x],
                          onChange: (I) => g(
                            "plans",
                            i.plans.map(
                              (L, K) => K === N ? {
                                ...L,
                                [x]: x === "name" ? I : Number(I)
                              } : L
                            )
                          )
                        },
                        x
                      )) }),
                      /* @__PURE__ */ e(
                        Ae,
                        {
                          label: `上架 ${v.name}`,
                          checked: v.enabled,
                          onChange: (x) => g(
                            "plans",
                            i.plans.map(
                              (C, I) => I === N ? { ...C, enabled: x } : C
                            )
                          )
                        }
                      ),
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-ghost",
                          onClick: () => g(
                            "plans",
                            i.plans.filter((x) => x.id !== v.id)
                          ),
                          children: "移除计划"
                        }
                      )
                    ]
                  },
                  v.id
                )),
                !i.plans.length && /* @__PURE__ */ e("p", { children: "添加会员计划，设置学习权益。" })
              ]
            }
          ),
          d === "payment" && /* @__PURE__ */ o(ee, { title: "支付接入", children: [
            /* @__PURE__ */ e(
              Ae,
              {
                label: "启用充值",
                checked: i.enabled,
                onChange: (v) => g("enabled", v)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "支付网关",
                value: i.gateway,
                onChange: (v) => g("gateway", v)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户号",
                  value: i.pid,
                  onChange: (v) => g("pid", v)
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "商户密钥",
                  secret: !0,
                  value: i.secret,
                  hint: "留空时保留已保存的密钥。",
                  onChange: (v) => g("secret", v)
                }
              )
            ] })
          ] }),
          d === "models" && /* @__PURE__ */ o(
            ee,
            {
              title: "模型价格",
              description: "价格单位：元 / 百万 Token。",
              actions: r && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => y(),
                  children: "同步上游价格"
                }
              ),
              children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "搜索模型价格",
                    value: h,
                    onChange: f
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "新模型名称",
                      value: m,
                      onChange: b
                    }
                  ),
                  /* @__PURE__ */ e(
                    "button",
                    {
                      type: "button",
                      className: "fp-button fp-secondary",
                      disabled: !m.trim(),
                      onClick: () => {
                        const v = m.trim();
                        if (i.modelRates?.[v]) {
                          u.setError("模型名称已存在。");
                          return;
                        }
                        g("modelRates", {
                          ...i.modelRates,
                          [v]: { input: 0, cachedInput: 0, output: 0 }
                        }), b("");
                      },
                      children: "添加模型"
                    }
                  )
                ] }),
                Object.entries(i.modelRates || {}).filter(
                  ([v]) => v.toLowerCase().includes(h.toLowerCase())
                ).map(([v, N]) => /* @__PURE__ */ o(
                  ee,
                  {
                    title: v,
                    description: i.rateOverrides?.includes(v) ? "使用手动价格" : "使用上游价格",
                    children: [
                      /* @__PURE__ */ e(
                        Ru,
                        {
                          name: v,
                          onRename: (x) => {
                            const C = x.trim();
                            if (!C || C !== v && i.modelRates?.[C])
                              return u.setError("请填写尚未使用的模型名称。"), !1;
                            const I = { ...i.modelRates, [C]: N };
                            return C !== v && delete I[v], l({
                              ...i,
                              modelRates: I,
                              rateOverrides: i.rateOverrides?.map(
                                (L) => L === v ? C : L
                              )
                            }), !0;
                          }
                        }
                      ),
                      /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: [
                        ["input", "输入价格"],
                        ["cachedInput", "缓存命中价格"],
                        ["output", "输出价格"]
                      ].map(([x, C]) => /* @__PURE__ */ e(
                        X,
                        {
                          label: `${v} · ${C}`,
                          numeric: !0,
                          value: N[x],
                          onChange: (I) => l({
                            ...i,
                            modelRates: {
                              ...i.modelRates,
                              [v]: { ...N, [x]: Number(I) }
                            },
                            rateOverrides: [
                              .../* @__PURE__ */ new Set([
                                ...i.rateOverrides || [],
                                v
                              ])
                            ]
                          })
                        },
                        x
                      )) }),
                      /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                        r && /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-secondary",
                            onClick: () => y([v]),
                            children: "恢复上游价格"
                          }
                        ),
                        /* @__PURE__ */ e(
                          "button",
                          {
                            type: "button",
                            className: "fp-button fp-ghost",
                            onClick: () => {
                              const x = { ...i.modelRates };
                              delete x[v], l({
                                ...i,
                                modelRates: x,
                                rateOverrides: i.rateOverrides?.filter(
                                  (C) => C !== v
                                )
                              });
                            },
                            children: "移除模型"
                          }
                        )
                      ] })
                    ]
                  },
                  v
                ))
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
function Ru({
  name: t,
  onRename: n
}) {
  const [r, a] = k(!1), [i, l] = k(t);
  return r ? /* @__PURE__ */ o("div", { className: "fp-workspace-inline", children: [
    /* @__PURE__ */ e(
      X,
      {
        label: `${t} · 模型名称`,
        value: i,
        onChange: l
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-secondary",
        onClick: () => {
          n(i) && a(!1);
        },
        children: "确认名称"
      }
    ),
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-button fp-ghost",
        onClick: () => {
          l(t), a(!1);
        },
        children: "取消"
      }
    )
  ] }) : /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      className: "fp-button fp-ghost",
      onClick: () => a(!0),
      children: "修改模型名称"
    }
  );
}
function Bu(t, n) {
  const r = t.replace(/^\uFEFF/, "").replace(/\r\n/g, `
`), a = r.match(/^---\n([\s\S]*?)\n---(?:\n|$)/), i = Object.fromEntries(
    (a?.[1] || "").split(`
`).flatMap((l) => {
      const s = l.match(/^(name|description):\s*(.*?)\s*$/);
      return s ? [[s[1], s[2].replace(/^(['"])(.*)\1$/, "$2")]] : [];
    })
  );
  return {
    name: i.name || n.replace(/\.(md|markdown)$/i, ""),
    description: i.description || "",
    content: a ? r.slice(a[0].length) : r
  };
}
function Nf({
  skills: t,
  maxSkills: n = 100,
  maxFileBytes: r = 2e6,
  onSave: a,
  onExport: i
}) {
  const { draft: l, setDraft: s, dirty: c, accept: u } = nt(t), d = Le(), [p, h] = k(""), [f, m] = k(null), b = l.find((w) => w.id === f), g = (w) => s(l.map((v) => v.id === f ? { ...v, ...w } : v)), y = async (w) => {
    await d.run(async () => {
      const v = [];
      if (l.length + w.length > n)
        throw new Error(`最多可保留 ${n} 个技能，请先整理后再导入。`);
      for (const N of w) {
        if (!/\.(md|markdown)$/i.test(N.name))
          throw new Error("请选择 Markdown 技能文件。");
        if (N.size > r)
          throw new Error(`${N.name} 超出文件大小限制。`);
        v.push({
          ...Bu(await N.text(), N.name),
          id: crypto.randomUUID(),
          pinned: !1
        });
      }
      s([...l, ...v]), v[0] && m(v[0].id);
    }, "文件已读入，保存后即可使用。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "技能管理", children: /* @__PURE__ */ o(
    ee,
    {
      title: "技能库",
      description: `${l.length} / ${n} 个技能`,
      actions: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ o(
          "label",
          {
            className: "fp-button fp-secondary",
            role: "button",
            tabIndex: 0,
            onKeyDown: (w) => {
              !d.busy && (w.key === "Enter" || w.key === " ") && (w.preventDefault(), w.currentTarget.querySelector("input")?.click());
            },
            children: [
              "导入文件",
              /* @__PURE__ */ e(
                "input",
                {
                  "aria-label": "导入技能文件",
                  hidden: !0,
                  type: "file",
                  accept: ".md,.markdown,text/markdown",
                  multiple: !0,
                  disabled: d.busy,
                  onChange: (w) => {
                    const v = Array.from(w.target.files || []);
                    w.target.value = "", v.length && y(v);
                  }
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-button fp-secondary",
            disabled: d.busy || l.length >= n,
            onClick: () => {
              const w = {
                id: crypto.randomUUID(),
                name: "新技能",
                description: "",
                content: "",
                pinned: !1
              };
              s([...l, w]), m(w.id);
            },
            children: "新建技能"
          }
        ),
        /* @__PURE__ */ e(
          it,
          {
            busy: d.busy,
            dirty: c,
            onClick: () => {
              if (l.some((w) => !w.name.trim())) {
                d.setError("请填写技能名称。");
                return;
              }
              d.run(async () => {
                await a(l), u(l);
              }, "技能库已保存。");
            }
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ e(Se, { ...d }),
        /* @__PURE__ */ o("div", { className: "fp-workspace-split", children: [
          /* @__PURE__ */ o("aside", { children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "搜索技能",
                value: p,
                onChange: h
              }
            ),
            /* @__PURE__ */ e("nav", { "aria-label": "技能列表", className: "fp-workspace-item-list", children: l.filter(
              (w) => `${w.name} ${w.description}`.toLowerCase().includes(p.toLowerCase())
            ).map((w) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                "aria-pressed": f === w.id,
                onClick: () => m(w.id),
                children: [
                  /* @__PURE__ */ e("strong", { children: w.name }),
                  /* @__PURE__ */ o("small", { children: [
                    w.pinned ? "始终使用" : "按需使用",
                    " ·",
                    " ",
                    new Blob([w.content]).size.toLocaleString(),
                    " B"
                  ] })
                ]
              },
              w.id
            )) }),
            !l.length && /* @__PURE__ */ e("p", { children: "添加技能，为学习助手补充工作方法。" })
          ] }),
          /* @__PURE__ */ e("div", { children: b ? /* @__PURE__ */ o("fieldset", { disabled: d.busy, children: [
            /* @__PURE__ */ e(
              X,
              {
                label: "技能名称",
                value: b.name,
                onChange: (w) => g({ name: w })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能说明",
                value: b.description,
                onChange: (w) => g({ description: w })
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "技能正文",
                multiline: !0,
                value: b.content,
                onChange: (w) => g({ content: w })
              }
            ),
            /* @__PURE__ */ e(
              Ae,
              {
                label: "始终使用此技能",
                description: "关闭后，助手会按任务需要使用。",
                checked: b.pinned,
                onChange: (w) => g({ pinned: w })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
              i && /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  className: "fp-button fp-secondary",
                  onClick: () => i(b),
                  children: "导出技能"
                }
              ),
              /* @__PURE__ */ e(
                be,
                {
                  confirm: `删除“${b.name}”？保存后生效。`,
                  onAction: () => {
                    s(l.filter((w) => w.id !== f)), m(null);
                  },
                  children: "删除技能"
                }
              )
            ] })
          ] }) : /* @__PURE__ */ e("div", { className: "fp-workspace-empty", children: "选择一个技能，查看和编辑内容。" }) })
        ] })
      ]
    }
  ) });
}
const ju = () => ({
  id: "",
  label: "",
  modelType: "text",
  contextK: 128,
  cacheTtlSec: 3600,
  inputPrice: 0,
  outputPrice: 0,
  vision: !1,
  tools: !0,
  thinking: !1,
  thinkingRequired: !1,
  thinkingLevels: ["low", "medium", "high", "max"],
  apiProtocol: "openai",
  thinkingRequestStyle: "none",
  imageApiStyle: "auto",
  sizes: ["1024x1024"],
  maxCount: 1
});
function ja(t) {
  if (!t || typeof t != "object") return !1;
  const n = t, r = (i) => Array.isArray(i) && i.length <= 1e3 && i.every((l) => typeof l == "string" && l.length <= 2e3), a = (i, l = !1) => l && i === void 0 || typeof i == "number" && Number.isFinite(i) && i >= 0 && i <= 1e5;
  return Array.isArray(n.groups) && n.groups.length <= 100 && new Set(n.groups.map((i) => i?.id)).size === n.groups.length && n.groups.every(
    (i) => i && typeof i == "object" && typeof i.id == "string" && i.id.length <= 128 && typeof i.name == "string" && typeof i.baseUrl == "string" && typeof i.apiKey == "string" && Array.isArray(i.models) && i.models.length <= 1e3 && i.models.every(
      (l) => l && typeof l == "object" && typeof l.id == "string" && typeof l.label == "string" && ["text", "image"].includes(l.modelType) && Number.isFinite(l.contextK) && l.contextK > 0 && l.contextK <= 1e5 && Number.isFinite(l.cacheTtlSec) && l.cacheTtlSec >= 0 && a(l.inputPrice) && a(l.outputPrice) && a(l.cachedInputPrice, !0) && a(l.cacheWritePrice, !0) && ["vision", "tools", "thinking", "thinkingRequired"].every(
        (s) => typeof l[s] == "boolean"
      ) && r(l.thinkingLevels) && r(l.sizes) && typeof l.thinkingRequestStyle == "string" && ["openai", "anthropic", "siliconflow"].includes(l.apiProtocol) && ["auto", "openai", "siliconflow"].includes(l.imageApiStyle) && Number.isInteger(l.maxCount) && l.maxCount > 0 && l.maxCount <= 100
    )
  ) && [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel",
    "thinkingEffort",
    "globalContext"
  ].every((i) => typeof n[i] == "string") && ["defaultThinking", "defaultSearch", "imageEnabled"].every(
    (i) => typeof n[i] == "boolean"
  ) && r(n.disabledTools) && (n.fontSize === void 0 || Number.isFinite(n.fontSize) && n.fontSize >= 10 && n.fontSize <= 32) && (n.fontFamily === void 0 || typeof n.fontFamily == "string");
}
function cr(t, n) {
  const r = { ...t };
  for (const a of [
    "defaultModel",
    "excerptModel",
    "selectionModel",
    "imageTextModel",
    "fallbackModel"
  ])
    Object.hasOwn(n, r[a]) && (r[a] = n[r[a]]);
  return r;
}
function xf({
  value: t,
  builtInModels: n = [],
  tools: r = [],
  onSave: a,
  onExportChats: i,
  onExportSettings: l
}) {
  const { draft: s, setDraft: c, dirty: u, accept: d } = nt(t), p = Le(), [h, f] = k("models"), [m, b] = k(s.groups[0]?.id || ""), [g, y] = k(null), w = s.groups.find((S) => S.id === m), v = g === null ? void 0 : w?.models[g], N = (S, A) => c({ ...s, [S]: A }), x = (S) => {
    const A = {};
    if (S.models && w)
      for (const D of w.models)
        S.models.some((U) => U.id === D.id) || (A[`${m}:${D.id}`] = "");
    c(
      cr(
        {
          ...s,
          groups: s.groups.map(
            (D) => D.id === m ? { ...D, ...S } : D
          )
        },
        A
      )
    );
  }, C = (S) => {
    if (!w || !v) return;
    const A = S.id !== void 0 && S.id !== v.id ? {
      [`${m}:${v.id}`]: S.id ? `${m}:${S.id}` : ""
    } : {};
    c(
      cr(
        {
          ...s,
          groups: s.groups.map(
            (D) => D.id === m ? {
              ...D,
              models: D.models.map(
                (U, j) => j === g ? { ...U, ...S } : U
              )
            } : D
          )
        },
        A
      )
    );
  }, I = [
    ...n,
    ...s.groups.flatMap(
      (S) => S.models.filter((A) => A.id).map((A) => ({
        id: `${S.id}:${A.id}`,
        label: `${S.name} · ${A.label || A.id}`
      }))
    )
  ], L = [
    { value: "", label: "跟随主对话" },
    ...I.map((S) => ({ value: S.id, label: S.label }))
  ], K = () => {
    if (!ja(s) || s.groups.some(
      (S) => !S.name.trim() || !/^https?:\/\//.test(S.baseUrl) || S.models.some((A) => !A.id.trim()) || new Set(S.models.map((A) => A.id)).size !== S.models.length
    )) {
      p.setError("请检查分组地址、模型名称和数值设置。");
      return;
    }
    p.run(async () => {
      await a(s), d(s);
    }, "助手设置已保存。");
  };
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form", "aria-label": "助手完整设置", children: /* @__PURE__ */ o(
    ee,
    {
      title: "学习助手设置",
      description: "管理模型、学习偏好和技能使用方式。",
      actions: /* @__PURE__ */ e(it, { busy: p.busy, dirty: u, onClick: K }),
      children: [
        /* @__PURE__ */ e(
          Ve,
          {
            label: "助手设置分区",
            value: h,
            onChange: f,
            items: [
              { id: "models", label: "模型与连接" },
              { id: "defaults", label: "学习偏好" },
              { id: "images", label: "图片创作" },
              { id: "tools", label: "工具" },
              { id: "data", label: "导入与导出" }
            ]
          }
        ),
        /* @__PURE__ */ e(Se, { ...p }),
        /* @__PURE__ */ e("fieldset", { disabled: p.busy, children: /* @__PURE__ */ o(fe, { children: [
          h === "models" && /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ o(ee, { title: "对话模型", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "默认对话模型",
                  value: s.defaultModel,
                  options: [
                    { value: "", label: "自动选择" },
                    ...L.slice(1)
                  ],
                  onChange: (S) => N("defaultModel", S)
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "摘录模型",
                    value: s.excerptModel,
                    options: L,
                    onChange: (S) => N("excerptModel", S)
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "划词助手模型",
                    value: s.selectionModel,
                    options: L,
                    onChange: (S) => N("selectionModel", S)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ o(
              ee,
              {
                title: "自定义连接",
                actions: /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-button fp-secondary",
                    onClick: () => {
                      const S = {
                        id: crypto.randomUUID(),
                        name: "新连接",
                        baseUrl: "",
                        apiKey: "",
                        models: []
                      };
                      N("groups", [...s.groups, S]), b(S.id), y(null);
                    },
                    children: "添加连接"
                  }
                ),
                children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: "当前连接",
                      value: m,
                      options: s.groups.map((S) => ({
                        value: S.id,
                        label: S.name
                      })),
                      onChange: (S) => {
                        b(S), y(null);
                      }
                    }
                  ),
                  w && /* @__PURE__ */ o(Q, { children: [
                    /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "连接名称",
                          value: w.name,
                          onChange: (S) => x({ name: S })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "服务地址",
                          value: w.baseUrl,
                          onChange: (S) => x({ baseUrl: S })
                        }
                      ),
                      /* @__PURE__ */ e(
                        X,
                        {
                          label: "API 密钥",
                          secret: !0,
                          value: w.apiKey,
                          onChange: (S) => x({ apiKey: S })
                        }
                      )
                    ] }),
                    /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: w.models.map((S, A) => /* @__PURE__ */ o(
                      "button",
                      {
                        type: "button",
                        "aria-pressed": A === g,
                        onClick: () => y(A),
                        children: [
                          /* @__PURE__ */ e("strong", { children: S.label || S.id || "新模型" }),
                          /* @__PURE__ */ o("small", { children: [
                            S.modelType === "image" ? "图片模型" : "文本模型",
                            " ",
                            "· ",
                            S.contextK,
                            " K"
                          ] })
                        ]
                      },
                      A
                    )) }),
                    /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                      /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          className: "fp-button fp-secondary",
                          onClick: () => {
                            y(w.models.length), x({
                              models: [
                                ...w.models,
                                ju()
                              ]
                            });
                          },
                          children: "添加模型"
                        }
                      ),
                      /* @__PURE__ */ e(
                        be,
                        {
                          confirm: `删除“${w.name}”及其模型？保存后生效。`,
                          onAction: () => {
                            c(
                              cr(
                                {
                                  ...s,
                                  groups: s.groups.filter(
                                    (S) => S.id !== m
                                  )
                                },
                                Object.fromEntries(
                                  w.models.map((S) => [
                                    `${m}:${S.id}`,
                                    ""
                                  ])
                                )
                              )
                            ), b(""), y(null);
                          },
                          children: "删除连接"
                        }
                      )
                    ] })
                  ] })
                ]
              }
            ),
            v && /* @__PURE__ */ o(ee, { title: v.label || "编辑模型", children: [
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型名称",
                    value: v.id,
                    onChange: (S) => C({ id: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "显示名称",
                    value: v.label,
                    onChange: (S) => C({ label: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "模型类型",
                    value: v.modelType,
                    options: [
                      { value: "text", label: "文本" },
                      { value: "image", label: "图片" }
                    ],
                    onChange: (S) => C({
                      modelType: S
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "上下文长度（K）",
                    value: v.contextK,
                    numeric: !0,
                    onChange: (S) => C({ contextK: Number(S) })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "缓存有效期（秒）",
                    value: v.cacheTtlSec,
                    numeric: !0,
                    onChange: (S) => C({ cacheTtlSec: Number(S) })
                  }
                ),
                [
                  "inputPrice",
                  "cachedInputPrice",
                  "cacheWritePrice",
                  "outputPrice"
                ].map((S, A) => /* @__PURE__ */ e(
                  X,
                  {
                    label: [
                      "输入价格",
                      "缓存读取价格",
                      "缓存写入价格",
                      "输出价格"
                    ][A],
                    value: v[S] ?? 0,
                    numeric: !0,
                    onChange: (D) => C({ [S]: Number(D) })
                  },
                  S
                )),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "服务协议",
                    value: v.apiProtocol,
                    options: ["openai", "anthropic", "siliconflow"].map(
                      (S) => ({ value: S, label: S })
                    ),
                    onChange: (S) => C({
                      apiProtocol: S
                    })
                  }
                )
              ] }),
              [
                "vision",
                "tools",
                "thinking",
                "thinkingRequired"
              ].map((S, A) => /* @__PURE__ */ e(
                Ae,
                {
                  label: ["理解图片", "使用工具", "支持思考", "始终启用思考"][A],
                  checked: v[S],
                  onChange: (D) => C({ [S]: D })
                },
                S
              )),
              /* @__PURE__ */ e(
                X,
                {
                  label: "可用思考力度",
                  value: v.thinkingLevels.join(", "),
                  hint: "以逗号分隔。",
                  onChange: (S) => C({
                    thinkingLevels: S.split(",").map((A) => A.trim()).filter(Boolean)
                  })
                }
              ),
              /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "思考参数格式",
                    value: v.thinkingRequestStyle,
                    options: [
                      "none",
                      "siliconflow",
                      "mimo-thinking",
                      "openai-reasoning-effort",
                      "openrouter-reasoning",
                      "anthropic-thinking"
                    ].map((S) => ({
                      value: S,
                      label: S === "none" ? "自动使用默认格式" : S
                    })),
                    onChange: (S) => C({ thinkingRequestStyle: S })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "推理内容字段",
                    value: v.reasoningField || "",
                    onChange: (S) => C({ reasoningField: S })
                  }
                )
              ] }),
              v.modelType === "image" && /* @__PURE__ */ o(Q, { children: [
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片接口",
                    value: v.imageApiStyle,
                    options: ["auto", "openai", "siliconflow"].map(
                      (S) => ({
                        value: S,
                        label: S === "auto" ? "自动识别" : S
                      })
                    ),
                    onChange: (S) => C({
                      imageApiStyle: S
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "图片尺寸",
                    value: v.sizes.join(", "),
                    hint: "例如 1024x1024，以逗号分隔。",
                    onChange: (S) => C({
                      sizes: S.split(",").map((A) => A.trim()).filter(Boolean)
                    })
                  }
                ),
                /* @__PURE__ */ e(
                  X,
                  {
                    label: "最多生成张数",
                    numeric: !0,
                    value: v.maxCount,
                    onChange: (S) => C({ maxCount: Number(S) })
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                be,
                {
                  confirm: "移除此模型？保存后生效。",
                  onAction: () => {
                    x({
                      models: w.models.filter(
                        (S, A) => A !== g
                      )
                    }), y(null);
                  },
                  children: "移除模型"
                }
              )
            ] })
          ] }),
          h === "defaults" && /* @__PURE__ */ o(ee, { title: "新对话偏好", children: [
            /* @__PURE__ */ e(
              Ae,
              {
                label: "深度思考",
                checked: s.defaultThinking,
                onChange: (S) => N("defaultThinking", S)
              }
            ),
            /* @__PURE__ */ e(
              Ae,
              {
                label: "联网搜索",
                checked: s.defaultSearch,
                onChange: (S) => N("defaultSearch", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "默认思考力度",
                value: s.thinkingEffort,
                options: ["low", "medium", "high", "max"].map((S, A) => ({
                  value: S,
                  label: ["轻度", "适中", "深入", "充分"][A]
                })),
                onChange: (S) => N("thinkingEffort", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "补充学习背景",
                multiline: !0,
                value: s.globalContext,
                hint: "介绍你的课程、称呼和回答偏好。",
                onChange: (S) => N("globalContext", S)
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字号",
                  numeric: !0,
                  value: s.fontSize || 15,
                  onChange: (S) => N("fontSize", Number(S))
                }
              ),
              /* @__PURE__ */ e(
                X,
                {
                  label: "对话字体",
                  value: s.fontFamily || "inherit",
                  options: [
                    { value: "inherit", label: "跟随全局" },
                    { value: "sans-serif", label: "清晰黑体" },
                    { value: "serif", label: "阅读衬线" },
                    { value: "monospace", label: "等宽" }
                  ],
                  onChange: (S) => N("fontFamily", S)
                }
              )
            ] })
          ] }),
          h === "images" && /* @__PURE__ */ o(ee, { title: "图片创作", children: [
            /* @__PURE__ */ e(
              Ae,
              {
                label: "开启图片创作",
                checked: s.imageEnabled,
                onChange: (S) => N("imageEnabled", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "图片创作理解模型",
                value: s.imageTextModel,
                options: L,
                onChange: (S) => N("imageTextModel", S)
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "备用模型",
                value: s.fallbackModel,
                options: L,
                onChange: (S) => N("fallbackModel", S)
              }
            )
          ] }),
          h === "tools" && /* @__PURE__ */ o(ee, { title: "可用工具", children: [
            r.map((S) => /* @__PURE__ */ e(
              Ae,
              {
                label: S.label,
                description: S.description,
                checked: !s.disabledTools.includes(S.id),
                onChange: (A) => N(
                  "disabledTools",
                  A ? s.disabledTools.filter((D) => D !== S.id) : [...s.disabledTools, S.id]
                )
              },
              S.id
            )),
            !r.length && /* @__PURE__ */ e("p", { children: "当前没有可配置的工具。" })
          ] }),
          h === "data" && /* @__PURE__ */ o(
            ee,
            {
              title: "导入与导出",
              description: "配置文件可能包含连接密钥，请妥善保管。",
              children: [
                /* @__PURE__ */ o(
                  "label",
                  {
                    className: "fp-workspace-upload",
                    role: "button",
                    tabIndex: 0,
                    onKeyDown: (S) => {
                      (S.key === "Enter" || S.key === " ") && (S.preventDefault(), S.currentTarget.querySelector("input")?.click());
                    },
                    children: [
                      "导入助手设置",
                      /* @__PURE__ */ e(
                        "input",
                        {
                          type: "file",
                          hidden: !0,
                          "aria-label": "导入助手设置",
                          accept: ".json,application/json",
                          onChange: (S) => {
                            const A = S.target.files?.[0];
                            S.target.value = "", A && p.run(async () => {
                              if (A.size > 2e6)
                                throw new Error("设置文件不能超过 2 MB。");
                              let D;
                              try {
                                D = JSON.parse(await A.text());
                              } catch {
                                throw new Error(
                                  "无法读取设置文件，请选择有效的 JSON 文件。"
                                );
                              }
                              if (!ja(D))
                                throw new Error("文件内容与助手设置不匹配。");
                              c(D), b(D.groups[0]?.id || ""), y(null);
                            }, "设置已读入，请检查后保存。");
                          }
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-actions", children: [
                  l && /* @__PURE__ */ e(be, { onAction: () => l(s), children: "导出助手设置" }),
                  i && /* @__PURE__ */ e(be, { onAction: i, children: "导出对话记录" })
                ] })
              ]
            }
          )
        ] }) })
      ]
    }
  ) });
}
const qu = "#FD8B07", Ku = {
  brand: { name: "五加一", primary: qu, onPrimary: "#542D0C", action: "#B85E00", onAction: "#FFFFFF", darkAction: "#FFB65C", darkOnAction: "#492600", soft: "#FFF2E2", ink: "#914600", darkSoft: "#422D18", darkInk: "#FFC98F" },
  kezhan: { name: "课栈笔记", primary: "#1A73E8", onPrimary: "#FFFFFF", soft: "#E8F0FE", ink: "#185ABC", darkPrimary: "#A8C7FA", darkSoft: "#263751", darkInk: "#C2D7FA", darkOnPrimary: "#142D50" },
  marker: { name: "AI 批改助手", primary: "#13795B", onPrimary: "#FFFFFF", soft: "#E6F4ED", ink: "#0C6248", darkPrimary: "#8DD8B6", darkSoft: "#193C30", darkInk: "#B1E8CE", darkOnPrimary: "#103C2B" },
  onepass: { name: "OnePass", primary: "#7252C7", onPrimary: "#FFFFFF", soft: "#F0EAFC", ink: "#5D3DA8", darkPrimary: "#CDB8FF", darkSoft: "#35294B", darkInk: "#DFD0FF", darkOnPrimary: "#342052" }
}, Qt = (t) => `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
function qa(t) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const n = /* @__PURE__ */ new Date(t + "T12:00:00");
  return Number.isFinite(n.getTime()) && Qt(n) === t ? n : null;
}
function vl(t) {
  const [n, r] = k(String(t.defaultValue ?? "")), a = B(null), i = String(t.value ?? n), l = (c) => {
    if (r(c), a.current) {
      a.current.value = c;
      const u = new Event("change", { bubbles: !0 });
      t.onChange?.({ target: a.current, currentTarget: a.current, nativeEvent: u, type: "change", bubbles: !0, cancelable: !1, defaultPrevented: !1, eventPhase: 3, isTrusted: !1, timeStamp: u.timeStamp, preventDefault: () => u.preventDefault(), stopPropagation: () => u.stopPropagation(), isDefaultPrevented: () => u.defaultPrevented, isPropagationStopped: () => !1, persist: () => {
      } });
    }
  }, s = (c) => {
    a.current = c, typeof t.ref == "function" ? t.ref(c) : t.ref && (t.ref.current = c);
  };
  return Y(() => {
    const c = a.current?.form, u = () => r(String(t.defaultValue ?? ""));
    return c?.addEventListener("reset", u), () => c?.removeEventListener("reset", u);
  }, [t.defaultValue]), { input: a, bind: s, value: i, change: l };
}
function Ka({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: a, bind: i, value: l, change: s } = vl(r), c = qa(l) || /* @__PURE__ */ new Date(), [u, d] = k(new Date(c.getFullYear(), c.getMonth(), 1)), p = u.getFullYear(), h = u.getMonth(), f = r.disabled || r.readOnly, m = (b) => (!r.min || b >= String(r.min)) && (!r.max || b <= String(r.max));
  return Y(() => {
    a.current?.setCustomValidity(l && (!qa(l) || !m(l)) ? "请填写有效范围内的日期" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: i, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "YYYY-MM-DD", onChange: (b) => s(b.target.value) }),
    /* @__PURE__ */ e(et, { label: "选择日期", disabled: f, trigger: /* @__PURE__ */ e(ri, { size: 17 }), className: "fp-date-popup", onOpenChange: (b) => {
      b && d(new Date(c.getFullYear(), c.getMonth(), 1));
    }, children: (b) => /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "上个月", onClick: () => d(new Date(p, h - 1, 1)), children: /* @__PURE__ */ e(Tr, { size: 17 }) }),
        /* @__PURE__ */ o("strong", { children: [
          p,
          " 年 ",
          h + 1,
          " 月"
        ] }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "下个月", onClick: () => d(new Date(p, h + 1, 1)), children: /* @__PURE__ */ e(ze, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-calendar-grid", role: "group", "aria-label": "日期", children: [
        "日一二三四五六".split("").map((g) => /* @__PURE__ */ e("span", { children: g }, g)),
        Array.from({ length: new Date(p, h, 1).getDay() }, (g, y) => /* @__PURE__ */ e("span", {}, "blank" + y)),
        Array.from({ length: new Date(p, h + 1, 0).getDate() }, (g, y) => {
          const w = Qt(new Date(p, h, y + 1));
          return /* @__PURE__ */ e("button", { type: "button", "data-date": w, "aria-label": w, "aria-pressed": l === w, disabled: !m(w), onClick: () => {
            s(w), b();
          }, onKeyDown: (v) => {
            const N = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[v.key];
            if (!N) return;
            v.preventDefault();
            const x = new Date(p, h, y + 1 + N), C = Qt(x), I = v.currentTarget.closest(".fp-calendar");
            d(new Date(x.getFullYear(), x.getMonth(), 1)), requestAnimationFrame(() => I?.querySelector(`[data-date="${C}"]`)?.focus());
          }, children: y + 1 }, w);
        })
      ] }),
      /* @__PURE__ */ o("footer", { children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: r.required, onClick: () => {
          s(""), b();
        }, children: "清除" }),
        /* @__PURE__ */ e("button", { type: "button", disabled: !m(Qt(/* @__PURE__ */ new Date())), onClick: () => {
          s(Qt(/* @__PURE__ */ new Date())), b();
        }, children: "今天" })
      ] })
    ] }) })
  ] });
}
function Cf({ className: t = "", wrapperClassName: n = "", ...r }) {
  const { input: a, bind: i, value: l, change: s } = vl(r), [c, u] = l.split(":");
  return Y(() => {
    a.current?.setCustomValidity(l && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(l) || r.min && l < String(r.min) || r.max && l > String(r.max)) ? "请填写有效范围内的时间" : "");
  }, [l, r.min, r.max]), /* @__PURE__ */ o("span", { className: `fp-date-field ${n}`, children: [
    /* @__PURE__ */ e("input", { ...r, ref: i, className: `fp-input ${t}`, type: "text", value: l, defaultValue: void 0, placeholder: r.placeholder || "HH:mm", onChange: (d) => s(d.target.value) }),
    /* @__PURE__ */ e(et, { label: "选择时间", disabled: r.disabled || r.readOnly, trigger: /* @__PURE__ */ e(jn, { size: 17 }), className: "fp-time-popup", children: (d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-time-columns", children: [["小时", 24, c], ["分钟", 60, u]].map(([p, h, f], m) => /* @__PURE__ */ e("div", { role: "group", "aria-label": String(p), children: Array.from({ length: Number(h) }, (b, g) => {
        const y = String(g).padStart(2, "0"), w = m === 0 ? `${y}:${u || "00"}` : `${c || "00"}:${y}`, v = m === 0 ? r.min && w < String(r.min) ? String(r.min) : r.max && w > String(r.max) ? String(r.max) : w : w, N = m === 0 ? (!r.min || `${y}:59` >= String(r.min)) && (!r.max || `${y}:00` <= String(r.max)) : (!r.min || v >= String(r.min)) && (!r.max || v <= String(r.max));
        return /* @__PURE__ */ e("button", { type: "button", "aria-pressed": f === y, disabled: !N, onClick: () => s(v), children: y }, y);
      }) }, p)) }),
      /* @__PURE__ */ e("footer", { children: /* @__PURE__ */ e("button", { type: "button", onClick: d, children: "完成" }) })
    ] }) })
  ] });
}
function yl({ label: t, value: n, onChange: r, disabled: a = !1 }) {
  const [i, l] = k(n), s = ["#FD8B07", "#B85E00", "#1A73E8", "#13795B", "#7252C7", "#D44A61", "#202124", "#FFFFFF"];
  Y(() => l(n), [n]);
  const c = /^#[0-9a-f]{6}$/i.test(n) ? n : "#FD8B07", u = (p) => parseInt(c.slice(p * 2 + 1, p * 2 + 3), 16), d = ve();
  return /* @__PURE__ */ o("div", { className: "fp-color-field", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e(et, { disabled: a, label: t, trigger: /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e("i", { className: "fp-color-swatch", style: { background: c } }),
      /* @__PURE__ */ e("code", { children: n })
    ] }), className: "fp-color-popup", children: () => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("div", { className: "fp-color-swatches", children: s.map((p) => /* @__PURE__ */ e("button", { type: "button", "aria-label": p, "aria-pressed": n.toLowerCase() === p.toLowerCase(), style: { background: p }, onClick: () => {
        l(p), r(p);
      } }, p)) }),
      ["红", "绿", "蓝"].map((p, h) => /* @__PURE__ */ o("label", { className: "fp-color-channel", children: [
        p,
        /* @__PURE__ */ e("input", { type: "range", "aria-label": p, min: 0, max: 255, value: u(h), onChange: (f) => {
          const m = [u(0), u(1), u(2)];
          m[h] = Number(f.target.value);
          const b = "#" + m.map((g) => g.toString(16).padStart(2, "0")).join("");
          l(b), r(b);
        } }),
        /* @__PURE__ */ e("output", { children: u(h) })
      ] }, p)),
      /* @__PURE__ */ e("label", { htmlFor: d, children: "HEX" }),
      /* @__PURE__ */ e("input", { id: d, className: "fp-input", "aria-label": "十六进制颜色", value: i, onFocus: () => l(n), onChange: (p) => {
        l(p.target.value), /^#[0-9a-f]{6}$/i.test(p.target.value) && r(p.target.value);
      } })
    ] }) })
  ] });
}
const Jr = {
  system: "system-ui, sans-serif",
  songti: '"Noto Serif SC", SimSun, serif',
  kaiti: "KaiTi, STKaiti, serif",
  hei: '"Microsoft YaHei", sans-serif',
  serif: "Georgia, serif",
  mono: "Consolas, monospace"
}, Ha = [
  { value: "system", label: "系统默认" },
  { value: "songti", label: "宋体阅读" },
  { value: "kaiti", label: "楷体手写" },
  { value: "hei", label: "黑体清晰" },
  { value: "serif", label: "英文衬线" },
  { value: "mono", label: "等宽" }
].map((t) => ({ ...t, fontFamily: Jr[t.value] }));
function Hu(t, n = !1, r = "brand") {
  const a = t.theme === "dark" || t.theme === "system" && n, i = a ? "#1d1f22" : "#ffffff", l = {
    colorScheme: a ? "dark" : "light",
    fontFamily: Jr[t.font] || t.font,
    "--fp-bg": a ? "#141517" : "#fbfaf8",
    "--fp-surface": i,
    "--fp-surface-muted": a ? "#26282c" : "#f4f2ef",
    "--fp-surface-sunken": a ? "#101113" : "#eeebe7",
    "--fp-ink": a ? "#e8eaed" : "#202124",
    "--fp-muted": a ? "#a9adb4" : "#6b7075",
    "--fp-faint": a ? "#7c828a" : "#9aa0a6",
    "--fp-line": a ? "#34373c" : "#e6e3df",
    "--fp-line-strong": a ? "#464a50" : "#d3cfca"
  }, s = Ku[r];
  Object.assign(l, {
    "--fp-primary": a && s.darkPrimary || s.primary,
    "--fp-on-primary": a && s.darkOnPrimary || s.onPrimary,
    "--fp-primary-soft": a ? s.darkSoft : s.soft,
    "--fp-primary-ink": a ? s.darkInk : s.ink,
    "--fp-action": a ? s.darkAction || s.darkPrimary || s.primary : s.action || s.primary,
    "--fp-on-action": a ? s.darkOnAction || s.darkOnPrimary || s.onPrimary : s.onAction || s.onPrimary
  });
  const c = a ? t.darkAccent : t.lightAccent;
  if (t.mode === "custom" && /^#[\da-f]{6}$/i.test(c)) {
    const u = [1, 3, 5].map((f) => parseInt(c.slice(f, f + 2), 16)), d = (f, m) => "#" + u.map(
      (b) => Math.round(b + (m - b) * f).toString(16).padStart(2, "0")
    ).join(""), p = (f) => {
      const m = [1, 3, 5].map((b) => parseInt(f.slice(b, b + 2), 16) / 255).map((b) => b <= 0.04045 ? b / 12.92 : ((b + 0.055) / 1.055) ** 2.4);
      return m[0] * 0.2126 + m[1] * 0.7152 + m[2] * 0.0722;
    };
    let h = c;
    for (let f = 0; f <= 0.9; f += 0.05) {
      h = d(f, a ? 255 : 0);
      const m = p(h);
      if (a ? (m + 0.05) / 0.05 >= 7 : 1.05 / (m + 0.05) >= 4.5) break;
    }
    Object.assign(l, {
      "--fp-primary": c,
      "--fp-on-primary": p(c) > 0.179 ? "#202124" : "#ffffff",
      "--fp-primary-soft": `color-mix(in srgb, ${c} 14%, ${i})`,
      "--fp-primary-ink": a ? d(0.5, 255) : d(0.35, 0),
      "--fp-action": h,
      "--fp-on-action": a ? "#101113" : "#ffffff"
    });
  }
  return /^#[\da-f]{6}$/i.test(t.selection) && (l["--fp-selection"] = t.selection), l["--fp-heading-color"] = t.mode === "colorful" ? l["--fp-primary-ink"] : l["--fp-ink"], l;
}
function Uu(t, n) {
  const r = t.regions[n];
  return {
    fontFamily: Jr[!r || r.inherit ? t.font : r.font] || (!r || r.inherit ? t.font : r.font),
    fontSize: r && !r.inherit ? r.fontSize : void 0,
    lineHeight: r && !r.inherit ? r.lineHeight : void 0
  };
}
function Sf({
  value: t,
  onChange: n,
  onReset: r,
  product: a = "brand",
  heading: i = !0,
  regions: l = [
    { id: "reading", label: "笔记阅读" },
    { id: "editor", label: "笔记编辑" },
    { id: "chat", label: "助手对话" }
  ]
}) {
  const [s, c] = k(
    () => typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches
  );
  Y(() => {
    if (typeof matchMedia > "u") return;
    const d = matchMedia("(prefers-color-scheme: dark)"), p = () => c(d.matches);
    return d.addEventListener("change", p), () => d.removeEventListener("change", p);
  }, []);
  const u = (d) => n({ ...t, ...d });
  return /* @__PURE__ */ e(
    "section",
    {
      className: "fp-workspace-form fp-appearance-workspace",
      "data-mode": t.mode,
      style: Hu(t, s, a),
      "aria-label": "外观设置",
      children: /* @__PURE__ */ o(
        ee,
        {
          title: i ? "外观" : void 0,
          description: i ? "让阅读、写作和对话保持适合自己的节奏。" : void 0,
          children: [
            /* @__PURE__ */ e(
              Ve,
              {
                label: "明暗主题",
                value: t.theme,
                onChange: (d) => u({ theme: d }),
                items: [
                  { id: "light", label: "浅色" },
                  { id: "dark", label: "深色" },
                  { id: "system", label: "跟随系统" }
                ]
              }
            ),
            /* @__PURE__ */ e(
              X,
              {
                label: "配色方式",
                value: t.mode,
                options: [
                  { value: "default", label: "产品默认" },
                  { value: "colorful", label: "内容彩色" },
                  { value: "custom", label: "自定义" }
                ],
                onChange: (d) => u({ mode: d })
              }
            ),
            /* @__PURE__ */ e(fe, { children: t.mode === "custom" && /* @__PURE__ */ e("div", { className: "fp-workspace-grid", children: ["lightAccent", "darkAccent", "selection"].map(
              (d, p) => /* @__PURE__ */ e(
                yl,
                {
                  label: ["白天主色", "夜间主色", "划词颜色"][p],
                  value: t[d],
                  onChange: (h) => u({ [d]: h, mode: "custom" })
                },
                d
              )
            ) }) }),
            /* @__PURE__ */ e(
              X,
              {
                label: "全局字体",
                value: t.font,
                options: Ha,
                onChange: (d) => u({ font: d })
              }
            ),
            /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "界面字号 · ",
                  t.uiFontSize ?? 14,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "界面字号", type: "range", min: "12", max: "20", step: "1", value: t.uiFontSize ?? 14, onChange: (d) => u({ uiFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整导航、按钮和设置中的文字大小。" })
              ] }),
              /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
                /* @__PURE__ */ o("span", { children: [
                  "正文字号 · ",
                  t.readingFontSize ?? 16,
                  " px"
                ] }),
                /* @__PURE__ */ e("input", { "aria-label": "正文字号", type: "range", min: "14", max: "28", step: "1", value: t.readingFontSize ?? 16, onChange: (d) => u({ readingFontSize: Number(d.target.value) }) }),
                /* @__PURE__ */ e("small", { children: "调整笔记、编辑器和 AI 对话中的正文大小。" })
              ] })
            ] }),
            /* @__PURE__ */ e("p", { className: "fp-workspace-type-preview", style: { fontSize: `${t.readingFontSize ?? 16}px` }, children: "从阅读到理解，把想法变成自己的笔记。" }),
            l.map((d) => {
              const p = t.regions[d.id] || {
                font: t.font,
                fontSize: 16,
                lineHeight: 1.9,
                inherit: !0
              }, h = (f) => u({
                regions: {
                  ...t.regions,
                  [d.id]: { ...p, ...f }
                }
              });
              return /* @__PURE__ */ o(ee, { title: d.label, children: [
                /* @__PURE__ */ e(
                  Ae,
                  {
                    label: `${d.label}跟随全局字体`,
                    checked: p.inherit,
                    onChange: (f) => h({ inherit: f })
                  }
                ),
                /* @__PURE__ */ o("div", { className: "fp-workspace-grid", children: [
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字体`,
                      value: p.font,
                      options: Ha,
                      disabled: p.inherit,
                      onChange: (f) => h({ font: f })
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}字号`,
                      value: p.fontSize,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        Number.isFinite(m) && m >= 10 && m <= 32 && h({ fontSize: m });
                      }
                    }
                  ),
                  /* @__PURE__ */ e(
                    X,
                    {
                      label: `${d.label}行高`,
                      value: p.lineHeight,
                      numeric: !0,
                      disabled: p.inherit,
                      onChange: (f) => {
                        const m = Number(f);
                        m >= 1.2 && m <= 2.5 && h({ lineHeight: m });
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ e(
                  "p",
                  {
                    className: "fp-workspace-type-preview",
                    style: Uu(t, d.id),
                    children: "从阅读到理解，把想法变成自己的笔记。"
                  }
                )
              ] }, d.id);
            }),
            /* @__PURE__ */ e(be, { confirm: "恢复产品默认外观？", onAction: r, children: "恢复默认外观" })
          ]
        }
      )
    }
  );
}
function Mf({
  records: t,
  onOpen: n,
  onClear: r,
  shortcuts: a,
  appearance: i
}) {
  const l = [...new Set(t.map((u) => u.subject))], s = t.reduce((u, d) => u + d.attempts, 0), c = t.length ? Math.round(t.reduce((u, d) => u + d.best, 0) / t.length) : 0;
  return /* @__PURE__ */ o("section", { className: "fp-workspace-form", "aria-label": "学习设置", children: [
    /* @__PURE__ */ o(
      ee,
      {
        title: "学习记录",
        description: `${t.length} 个章节 · 平均最佳分 ${c} · ${s} 次测验`,
        children: [
          l.map((u) => /* @__PURE__ */ e(ee, { title: u, children: /* @__PURE__ */ e("div", { className: "fp-workspace-item-list", children: t.filter((d) => d.subject === u).map((d) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(d.id), children: [
            /* @__PURE__ */ e("strong", { children: d.chapter }),
            /* @__PURE__ */ o("small", { children: [
              "上次 ",
              d.last,
              " 分 · 最佳 ",
              d.best,
              " 分 · ",
              d.attempts,
              " 次"
            ] })
          ] }, d.id)) }) }, u)),
          !t.length && /* @__PURE__ */ e("p", { children: "完成章节测验后，可以在这里查看学习记录。" }),
          /* @__PURE__ */ e(
            be,
            {
              disabled: !t.length,
              confirm: "清空全部测验成绩？题目和笔记会保留。",
              onAction: r,
              children: "清空测验成绩"
            }
          )
        ]
      }
    ),
    a && /* @__PURE__ */ e(ee, { title: "快捷键", children: a }),
    i
  ] });
}
function _u(t, n, r, a) {
  if (t.reduce((s, c) => s + c, 0) + Math.max(0, t.length - 1) * a <= n) return t.length;
  let i = r, l = 0;
  for (const s of t) {
    if (i + a + s > n) break;
    i += a + s, l++;
  }
  return l;
}
function wl({ actions: t, label: n = "操作", moreLabel: r = "更多操作", className: a = "", showLabels: i = !1 }) {
  const l = B(null), s = B(null), [c, u] = k(0), d = t.map((h) => h.id).join("\0");
  Ce(() => {
    const h = l.current, f = s.current;
    if (!h || !f) return;
    const m = () => {
      const g = getComputedStyle(h), y = parseFloat(g.columnGap) || 4, v = Array.from(f.querySelectorAll("[data-action-width]")).map((x) => x.getBoundingClientRect().width || 32), N = f.querySelector("[data-more-width]")?.getBoundingClientRect().width || 32;
      u(_u(v, h.clientWidth - (parseFloat(g.paddingLeft) || 0) - (parseFloat(g.paddingRight) || 0), N, y));
    };
    m();
    const b = typeof ResizeObserver > "u" ? null : new ResizeObserver(m);
    return b?.observe(h), b?.observe(f), document.fonts?.ready.then(m), () => b?.disconnect();
  }, [d, i]);
  const p = (h, f = !1) => /* @__PURE__ */ o("button", { type: "button", "data-action-width": f ? "" : void 0, "data-fp-tooltip": h.label, "aria-label": h.label, disabled: h.disabled, "data-danger": h.danger || void 0, onClick: f ? void 0 : h.onSelect, children: [
    h.icon,
    i && /* @__PURE__ */ e("span", { children: h.label })
  ] }, h.id);
  return /* @__PURE__ */ o("div", { ref: l, className: `fp-action-toolbar ${a}`, "data-show-labels": i || void 0, role: "toolbar", "aria-label": n, onKeyDown: (h) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(h.key)) return;
    const f = Array.from(l.current?.querySelectorAll(":scope > button:not(:disabled), :scope > .fp-dropdown > button:not(:disabled)") || []), m = f.indexOf(document.activeElement);
    m < 0 || (h.preventDefault(), f[h.key === "Home" ? 0 : h.key === "End" ? f.length - 1 : (m + (h.key === "ArrowRight" ? 1 : -1) + f.length) % f.length]?.focus());
  }, children: [
    t.slice(0, c).map((h) => p(h)),
    c < t.length && /* @__PURE__ */ e(et, { label: r, icon: /* @__PURE__ */ e(Ot, { size: 18 }), menu: !0, density: "compact", children: (h) => /* @__PURE__ */ e("div", { className: "fp-action-menu", children: t.slice(c).map((f) => /* @__PURE__ */ o("button", { role: "menuitem", type: "button", disabled: f.disabled, "data-danger": f.danger || void 0, onClick: () => {
      h(), f.onSelect();
    }, children: [
      f.icon,
      /* @__PURE__ */ e("span", { children: f.label })
    ] }, f.id)) }) }),
    /* @__PURE__ */ o("div", { ref: s, className: "fp-action-measure", "aria-hidden": "true", inert: !0, children: [
      t.map((h) => p(h, !0)),
      /* @__PURE__ */ e("button", { type: "button", "data-more-width": !0, children: /* @__PURE__ */ e(Ot, { size: 18 }) })
    ] })
  ] });
}
function Ef({
  anchor: t,
  open: n,
  onClose: r,
  children: a,
  label: i,
  id: l,
  role: s = "dialog",
  width: c,
  maxHeight: u = 320,
  className: d = "",
  initialFocus: p,
  autoFocus: h = s !== "listbox"
}) {
  const f = B(null), m = B(r);
  m.current = r;
  const [b, g] = k(!1), [y, w] = k({
    left: 8,
    top: 8,
    width: c || 240,
    maxHeight: u
  }), v = B(!1), N = Ut(t, n);
  return Ce(() => {
    v.current && !n && g(!0), v.current = n;
  }, [n]), Y(() => {
    if (!b) return;
    const x = setTimeout(() => g(!1), 120);
    return () => clearTimeout(x);
  }, [b]), Ce(() => {
    if (!n) return;
    const x = () => {
      const I = t.current?.getBoundingClientRect();
      if (!I) {
        m.current();
        return;
      }
      const L = Math.max(
        0,
        Math.min(c || Math.max(I.width, 240), window.innerWidth - 16)
      ), K = window.innerHeight - I.bottom - 16, S = I.top - 16, A = K < Math.min(f.current?.scrollHeight || u, 200) && S > K, D = Math.max(0, Math.min(u, A ? S : K));
      w({
        left: Math.max(8, Math.min(I.left, window.innerWidth - L - 8)),
        top: A ? Math.max(
          8,
          I.top - Math.min(f.current?.scrollHeight || D, D) - 8
        ) : I.bottom + 8,
        width: L,
        maxHeight: D
      });
    };
    x();
    const C = typeof ResizeObserver > "u" ? null : new ResizeObserver(x);
    return t.current && C?.observe(t.current), f.current && C?.observe(f.current), window.addEventListener("resize", x), window.addEventListener("scroll", x, !0), () => {
      C?.disconnect(), window.removeEventListener("resize", x), window.removeEventListener("scroll", x, !0);
    };
  }, [n, t, c, u]), Y(() => {
    if (!n) return;
    const x = requestAnimationFrame(() => {
      !h && !p?.current || (p?.current || f.current?.querySelector(
        'input,button,[tabindex="0"]'
      ) || f.current)?.focus({ preventScroll: !0 });
    }), C = (L) => {
      !f.current?.contains(L.target) && !t.current?.contains(L.target) && m.current();
    }, I = (L) => {
      L.key === "Escape" && (!L.target.closest?.("[data-fp-overlay]") || L.target.closest?.("[data-fp-overlay]") === f.current) && (L.preventDefault(), L.stopPropagation(), m.current(), t.current?.focus({ preventScroll: !0 }));
    };
    return document.addEventListener("pointerdown", C, !0), document.addEventListener("focusin", C, !0), document.addEventListener("keydown", I, !0), () => {
      cancelAnimationFrame(x), document.removeEventListener("pointerdown", C, !0), document.removeEventListener("focusin", C, !0), document.removeEventListener("keydown", I, !0);
    };
  }, [n, t, p, h]), !n && !b ? null : De(
    /* @__PURE__ */ e(
      "div",
      {
        ref: f,
        "data-fp-overlay": "",
        id: l,
        role: s,
        "aria-label": i,
        tabIndex: -1,
        "data-exiting": !n || void 0,
        "aria-hidden": !n || void 0,
        inert: !n,
        className: `fp-popup-panel fp-anchored-panel ${d}`,
        style: { ...N, position: "fixed", ...y, overflow: "auto" },
        onKeyDown: (x) => {
          if (s === "dialog" || x.target.closest("[data-fp-overlay]") !== f.current || x.target.matches("input,textarea"))
            return;
          const C = [
            ...x.currentTarget.querySelectorAll(
              '[role="menuitem"]:not(:disabled),[role="option"]:not(:disabled)'
            )
          ], I = C.indexOf(document.activeElement), L = x.key === "ArrowDown" ? (I + 1) % C.length : x.key === "ArrowUp" ? (I - 1 + C.length) % C.length : x.key === "Home" ? 0 : x.key === "End" ? C.length - 1 : -1;
          L >= 0 && (x.preventDefault(), x.stopPropagation(), C[L]?.focus());
        },
        children: a
      }
    ),
    t.current?.closest("[data-fp-overlay],dialog") || document.body
  );
}
function $f({ dark: t, onChange: n, disabled: r }) {
  return /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": t ? "切换为浅色" : "切换为深色", disabled: r, onClick: () => n(!t), children: t ? /* @__PURE__ */ e(io, { size: 19, "aria-hidden": "true" }) : /* @__PURE__ */ e(lo, { size: 19, "aria-hidden": "true" }) });
}
function zf({ name: t, detail: n, avatar: r, role: a, actions: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-share-member-row", children: [
    /* @__PURE__ */ e("span", { className: "fp-share-member-avatar", "aria-hidden": "true", children: r || t.slice(0, 1) }),
    /* @__PURE__ */ o("span", { className: "fp-share-member-identity", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-share-member-role", children: a }),
    i && /* @__PURE__ */ e("div", { className: "fp-share-member-actions", children: i })
  ] });
}
function Af({ items: t, value: n, onChange: r, onClose: a, children: i }) {
  const [l, s] = k("");
  return /* @__PURE__ */ o("div", { className: "fp-settings-layout", children: [
    /* @__PURE__ */ o("aside", { children: [
      /* @__PURE__ */ e("h2", { children: "设置" }),
      /* @__PURE__ */ o("label", { className: "fp-settings-search", children: [
        /* @__PURE__ */ e(We, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索设置", placeholder: "搜索设置", value: l, onChange: (c) => s(c.target.value) })
      ] }),
      /* @__PURE__ */ e("nav", { "aria-label": "设置分类", children: t.filter((c) => c.label.includes(l.trim())).map((c) => /* @__PURE__ */ o("button", { type: "button", "aria-current": n === c.id ? "page" : void 0, onClick: () => r(c.id), children: [
        c.icon,
        /* @__PURE__ */ e("span", { children: c.label })
      ] }, c.id)) })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-settings-page", children: [
      /* @__PURE__ */ o("header", { children: [
        /* @__PURE__ */ e("h2", { children: t.find((c) => c.id === n)?.label }),
        /* @__PURE__ */ e("button", { type: "button", className: "fp-theme-toggle", "aria-label": "关闭", onClick: a, children: /* @__PURE__ */ e(ge, { size: 20 }) })
      ] }),
      /* @__PURE__ */ e("div", { className: "fp-settings-page-content", children: i })
    ] })
  ] });
}
function If({ onContinue: t, onDiscard: n }) {
  const r = B(null), a = ve();
  return Y(() => {
    const i = document.activeElement;
    return r.current?.focus(), () => {
      i?.isConnected && i.focus();
    };
  }, []), /* @__PURE__ */ e("div", { className: "fp-discard-backdrop", children: /* @__PURE__ */ o("section", { className: "fp-discard-prompt", role: "alertdialog", "aria-modal": "true", "aria-label": "保存当前更改", "aria-describedby": a, children: [
    /* @__PURE__ */ e("h2", { children: "保留这次更改？" }),
    /* @__PURE__ */ e("p", { id: a, children: "更改尚未保存。你可以继续编辑，或放弃后关闭。" }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("button", { ref: r, type: "button", className: "fp-button fp-secondary", onClick: t, children: "继续编辑" }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-danger", onClick: n, children: "放弃更改" })
    ] })
  ] }) });
}
function Lf({ header: t, children: n, actions: r, onFinish: a }) {
  return /* @__PURE__ */ o("section", { className: "fp-card-editor-frame", "data-nested-editor-boundary": "", onKeyDownCapture: (i) => {
    a && !i.nativeEvent.isComposing && i.key === "Enter" && (i.ctrlKey || i.metaKey) && (i.preventDefault(), i.stopPropagation(), a());
  }, children: [
    /* @__PURE__ */ e("header", { children: t }),
    /* @__PURE__ */ e("div", { className: "fp-card-editor-content", children: n }),
    /* @__PURE__ */ e("footer", { children: r })
  ] });
}
function Tf({
  query: t,
  onQueryChange: n,
  onSearch: r,
  onOpen: a,
  placeholder: i = "搜索笔记与资料",
  debounceMs: l = 220
}) {
  const [s, c] = k([]), [u, d] = k(!1), [p, h] = k(""), [f, m] = k(0), [b, g] = k(0), y = B(0), w = B(null);
  Y(() => {
    const N = new AbortController(), x = ++y.current;
    if (c([]), m(0), h(""), d(!!t.trim()), !t.trim()) return () => N.abort();
    const C = setTimeout(() => {
      r(t.trim(), N.signal).then((I) => {
        !N.signal.aborted && x === y.current && c(I);
      }).catch(() => {
        N.signal.aborted || h("暂时无法搜索，请重试。");
      }).finally(() => {
        !N.signal.aborted && x === y.current && d(!1);
      });
    }, l);
    return () => {
      clearTimeout(C), N.abort();
    };
  }, [t, r, l, b]);
  const v = s.filter((N) => !N.disabled);
  return /* @__PURE__ */ o("section", { className: "fp-search-results", children: [
    /* @__PURE__ */ o("label", { className: "fp-search-query", children: [
      /* @__PURE__ */ e(We, { size: 17 }),
      /* @__PURE__ */ e(
        "input",
        {
          "aria-label": "搜索内容",
          placeholder: i,
          value: t,
          onChange: (N) => n(N.target.value),
          onKeyDown: (N) => {
            if (!N.nativeEvent.isComposing) {
              if (N.key === "ArrowDown" || N.key === "ArrowUp") {
                N.preventDefault();
                const x = (f + (N.key === "ArrowDown" ? 1 : -1) + Math.max(v.length, 1)) % Math.max(v.length, 1);
                m(x), w.current?.querySelectorAll("button[data-hit]")[x]?.scrollIntoView?.({ block: "nearest" });
              }
              N.key === "Enter" && v[f] && (N.preventDefault(), a(v[f]));
            }
          }
        }
      )
    ] }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("div", { ref: w, className: "fp-search-hits", "aria-busy": u, children: u ? /* @__PURE__ */ e("p", { role: "status", children: "正在搜索…" }) : p ? /* @__PURE__ */ o("p", { role: "alert", children: [
      p,
      /* @__PURE__ */ e("button", { type: "button", onClick: () => g((N) => N + 1), children: "重试" })
    ] }) : t.trim() ? s.length ? s.map((N) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "data-hit": N.disabled ? void 0 : "",
        "data-active": v[f]?.id === N.id || void 0,
        disabled: N.disabled,
        onClick: () => a(N),
        children: [
          N.icon,
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: N.title }),
            N.path && /* @__PURE__ */ e("small", { children: N.path }),
            N.excerpt && /* @__PURE__ */ e("span", { children: N.excerpt })
          ] })
        ]
      },
      N.id
    )) : /* @__PURE__ */ e("p", { children: "没有找到匹配的内容。" }) : /* @__PURE__ */ e("p", { children: "输入关键词查找内容。" }) }) })
  ] });
}
function Df({
  tabs: t,
  activeId: n,
  paneId: r = "main",
  onSelect: a,
  onClose: i,
  onMove: l,
  onSplit: s
}) {
  const c = B(null), u = (d, p) => {
    d.preventDefault();
    try {
      const h = JSON.parse(
        d.dataTransfer.getData("application/x-fiveplusone-tab")
      );
      typeof h.id == "string" && l?.(h.id, r, p);
    } catch {
    }
  };
  return /* @__PURE__ */ o(
    "div",
    {
      className: "fp-workspace-tabs",
      onDragOver: (d) => {
        l && d.dataTransfer.types.includes("application/x-fiveplusone-tab") && d.preventDefault();
      },
      onDrop: (d) => u(d, t.length),
      children: [
        /* @__PURE__ */ e(
          "div",
          {
            ref: c,
            role: "tablist",
            "aria-label": "打开的文档",
            onKeyDown: (d) => {
              const p = t.findIndex((f) => f.id === n);
              let h = p;
              if (d.key === "ArrowRight") h = (p + 1) % t.length;
              else if (d.key === "ArrowLeft")
                h = (p - 1 + t.length) % t.length;
              else if (d.key === "Home") h = 0;
              else if (d.key === "End") h = t.length - 1;
              else return;
              t[h] && (d.preventDefault(), a(t[h].id), c.current?.querySelectorAll("[role=tab]")[h]?.focus());
            },
            children: t.map((d, p) => /* @__PURE__ */ e(
              yt,
              {
                label: `${d.title}的操作`,
                items: [
                  {
                    id: "close",
                    label: "关闭",
                    disabled: d.closable === !1,
                    onSelect: () => i(d.id)
                  },
                  ...l ? [
                    {
                      id: "left",
                      label: "移到最前",
                      onSelect: () => l(d.id, r, 0)
                    }
                  ] : []
                ],
                children: /* @__PURE__ */ o(
                  "div",
                  {
                    className: "fp-workspace-tab",
                    "data-active": n === d.id || void 0,
                    draggable: !!l,
                    onDragStart: (h) => {
                      h.dataTransfer.setData(
                        "application/x-fiveplusone-tab",
                        JSON.stringify({ id: d.id, paneId: r })
                      ), h.dataTransfer.effectAllowed = "move";
                    },
                    onDrop: (h) => {
                      h.stopPropagation(), u(h, p);
                    },
                    children: [
                      /* @__PURE__ */ o(
                        "button",
                        {
                          type: "button",
                          role: "tab",
                          "aria-selected": n === d.id,
                          tabIndex: n === d.id ? 0 : -1,
                          onClick: () => a(d.id),
                          children: [
                            d.icon,
                            /* @__PURE__ */ e("span", { children: d.title }),
                            d.dirty && /* @__PURE__ */ e("span", { "aria-label": "尚未保存", className: "fp-tab-dirty", children: "•" })
                          ]
                        }
                      ),
                      d.closable !== !1 && /* @__PURE__ */ e(
                        "button",
                        {
                          type: "button",
                          "aria-label": `关闭${d.title}`,
                          onClick: () => i(d.id),
                          children: /* @__PURE__ */ e(ge, { size: 13 })
                        }
                      )
                    ]
                  }
                )
              },
              d.id
            ))
          }
        ),
        s && /* @__PURE__ */ e("button", { type: "button", "aria-label": "切换分屏", onClick: s, children: /* @__PURE__ */ e(oo, { size: 16 }) })
      ]
    }
  );
}
function Wu({ section: t }) {
  const [n, r] = k(
    t.defaultOpen ?? t.kind === "content"
  );
  return /* @__PURE__ */ o("section", { className: "fp-message-section", "data-status": t.status, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-expanded": n,
        onClick: () => r((a) => !a),
        children: [
          /* @__PURE__ */ e(
            ze,
            {
              size: 14,
              style: { transform: n ? "rotate(90deg)" : void 0 }
            }
          ),
          /* @__PURE__ */ e("strong", { children: t.label }),
          t.status && /* @__PURE__ */ e("small", { children: t.status === "running" ? "进行中" : t.status === "done" ? "已完成" : "需要处理" })
        ]
      }
    ),
    /* @__PURE__ */ e(Re, { isOpen: n, children: /* @__PURE__ */ e("div", { children: t.content }) })
  ] });
}
function Pf({
  sections: t,
  actions: n
}) {
  return /* @__PURE__ */ o("article", { className: "fp-message-content-view", children: [
    t.map((r) => /* @__PURE__ */ e(Wu, { section: r }, r.id)),
    n && /* @__PURE__ */ e("footer", { children: n })
  ] });
}
function Ff({
  title: t,
  description: n,
  kind: r = "文档",
  onOpen: a
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-artifact-card", onClick: a, children: [
    /* @__PURE__ */ e(Qe, { size: 24 }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("small", { children: r }),
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "↗" })
  ] });
}
function Of({
  title: t,
  children: n,
  onDownload: r,
  onSave: a,
  loading: i,
  error: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-artifact", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r && /* @__PURE__ */ e("button", { type: "button", onClick: r, children: "下载" }),
        a && /* @__PURE__ */ e(be, { disabled: i, onAction: a, children: "保存到资料" })
      ] })
    ] }),
    i ? /* @__PURE__ */ e("p", { role: "status", children: "正在打开内容…" }) : l ? /* @__PURE__ */ e("p", { role: "alert", children: l }) : /* @__PURE__ */ e("div", { className: "fp-artifact-content", children: n })
  ] });
}
function Rf({
  items: t,
  onToggle: n
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "学习助手能力" }),
    t.map((r) => /* @__PURE__ */ o("div", { className: "fp-skill-row", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: r.name }),
        /* @__PURE__ */ e("small", { children: r.description })
      ] }),
      /* @__PURE__ */ e(
        be,
        {
          disabled: r.disabled,
          onAction: () => n(r.id, !r.enabled),
          children: r.enabled ? "停用" : "启用"
        }
      )
    ] }, r.id))
  ] });
}
class Vu {
  nodes = [];
  links = [];
  heat = 1;
  byId = /* @__PURE__ */ new Map();
  reconcile(n, r) {
    const a = /* @__PURE__ */ new Map();
    n.forEach((l, s) => {
      if (a.has(l)) return;
      const c = s * 2.399963229728653, u = 24 * Math.sqrt(s + 1), d = this.byId.get(l) || { id: l, x: Math.cos(c) * u, y: Math.sin(c) * u, vx: 0, vy: 0, degree: 0 };
      d.degree = 0, a.set(l, d);
    }), this.byId = a, this.nodes = [...a.values()];
    const i = /* @__PURE__ */ new Set();
    this.links = [], r.forEach((l) => {
      const s = a.get(l.source), c = a.get(l.target), u = JSON.stringify([l.source, l.target].sort());
      !s || !c || s === c || i.has(u) || (i.add(u), s.degree++, c.degree++, this.links.push([s, c]));
    }), this.wake();
  }
  get(n) {
    return this.byId.get(n);
  }
  wake() {
    this.heat = 1;
  }
  pin(n, r, a) {
    const i = this.get(n);
    i && (i.fixed = { x: r, y: a }, i.x = r, i.y = a, i.vx = i.vy = 0, this.wake());
  }
  release(n) {
    const r = this.get(n);
    r && (delete r.fixed, this.wake());
  }
  step(n) {
    if (this.heat < 2e-3) return !1;
    const r = this.nodes, a = Math.max(0, n.repelForce) * 180, i = Math.max(0.15, this.heat);
    for (let c = 0; c < r.length; c++) for (let u = c + 1; u < r.length; u++) {
      const d = r[c], p = r[u];
      let h = p.x - d.x, f = p.y - d.y;
      Math.abs(h) + Math.abs(f) < 1e-3 && (h = 0.1 * Math.cos(c + u), f = 0.1 * Math.sin(c + u));
      const m = Math.sqrt(h * h + f * f), b = 16 * n.nodeSize, g = Math.min(8, a / Math.max(64, m * m) + Math.max(0, b - m) * 0.12) * i, y = h / m * g, w = f / m * g;
      d.vx -= y, d.vy -= w, p.vx += y, p.vy += w;
    }
    for (const [c, u] of this.links) {
      const d = u.x - c.x, p = u.y - c.y, h = Math.max(1, Math.hypot(d, p)), f = 74 + Math.min(40, (c.degree + u.degree) * 1.2), m = (h - f) * 0.025 * n.linkForce * i, b = d / h * m, g = p / h * m;
      c.vx += b / Math.sqrt(c.degree), c.vy += g / Math.sqrt(c.degree), u.vx -= b / Math.sqrt(u.degree), u.vy -= g / Math.sqrt(u.degree);
    }
    let l = 0, s = !1;
    for (const c of r) {
      if (c.fixed) {
        c.x = c.fixed.x, c.y = c.fixed.y, c.vx = c.vy = 0, s = !0;
        continue;
      }
      c.vx = Math.max(-14, Math.min(14, (c.vx - c.x * n.centerForce * 1e-3) * 0.82)), c.vy = Math.max(-14, Math.min(14, (c.vy - c.y * n.centerForce * 1e-3) * 0.82)), c.x += c.vx, c.y += c.vy, l += c.vx * c.vx + c.vy * c.vy;
    }
    return this.heat = s ? Math.max(0.35, this.heat * 0.985) : this.heat * (l / Math.max(1, r.length) < 2e-3 ? 0.85 : 0.995), !0;
  }
}
const Ua = { showArrows: !1, textOpacity: 1, nodeSize: 1, lineThickness: 1, centerForce: 0.5, repelForce: 9, linkForce: 0.8, colorGroups: [] }, vn = (t) => Math.max(0.08, Math.min(4, t)), dr = (t, n) => (4 + Math.min(5, Math.sqrt(t.degree) * 0.7)) * n;
function Bf({ nodes: t, edges: n, selectedId: r, onSelect: a, settings: i, onSettingsChange: l, onRefresh: s, onClose: c, loading: u, error: d }) {
  const [p, h] = k(Ua), [f, m] = k(""), [b, g] = k(!1), [y, w] = k(r || ""), [v, N] = k(""), [x, C] = k(!1), [I, L] = k(""), K = i || p, S = B(null), A = B(new Vu()), D = B({ x: 0, y: 0, zoom: 1 }), U = B({ x: 0, y: 0, zoom: 1 }), j = B({ width: 1, height: 1 }), T = B(!1), M = B(!1), R = B(!0), q = B({ nodes: t, settings: K, active: y, hovered: v, paused: x, query: f, onSelect: a });
  q.current = { nodes: t, settings: K, active: y, hovered: v, paused: x, query: f, onSelect: a };
  const F = () => {
    const W = A.current.nodes;
    if (!W.length) return;
    const G = Math.min(...W.map((O) => O.x)), ue = Math.max(...W.map((O) => O.x)), me = Math.min(...W.map((O) => O.y)), H = Math.max(...W.map((O) => O.y)), { width: V, height: oe } = j.current, _ = vn(Math.min((V - 100) / Math.max(120, ue - G), (oe - 140) / Math.max(120, H - me), 1.5));
    U.current = { x: -(G + ue) / 2 * _, y: -(me + H) / 2 * _, zoom: _ }, R.current = !0;
  }, E = B(F);
  E.current = F;
  const z = (W) => {
    M.current = !0;
    const G = U.current, ue = vn(G.zoom * W);
    U.current = { x: G.x * ue / G.zoom, y: G.y * ue / G.zoom, zoom: ue }, R.current = !0;
  }, $ = (W) => {
    w(W);
    const G = A.current.get(W);
    if (!G) return;
    M.current = !0;
    const ue = Math.max(0.8, U.current.zoom);
    U.current = { x: -G.x * ue, y: -G.y * ue, zoom: ue }, R.current = !0;
  }, P = (W) => {
    const G = { ...K, ...W };
    h(G), l?.(G), A.current.wake(), R.current = !0;
  };
  Y(() => {
    w(r || "");
  }, [r]), Y(() => {
    A.current.reconcile(t.map((W) => W.id), n), R.current = !0, !T.current && t.length && (M.current = !1, E.current()), T.current = t.length > 0;
  }, [t, n]), Y(() => {
    A.current.wake(), R.current = !0;
  }, [K, f, y, v, x]), Y(() => {
    const W = S.current;
    if (!W || typeof CanvasRenderingContext2D > "u") return;
    const G = W.getContext("2d");
    if (!G) {
      L("画布暂时无法显示，请通过搜索打开笔记。");
      return;
    }
    let ue = 0, me = 0, H = 0, V = !0, oe = "sans-serif", _ = { ink: "#202124", muted: "#747981", line: "#d5d8de", surface: "#fff", action: "#7255b4", groups: [] };
    const O = () => {
      const se = getComputedStyle(W), ae = (de, le) => se.getPropertyValue(de).trim() || le;
      oe = se.fontFamily, _ = { ink: ae("--fp-ink", _.ink), muted: ae("--fp-muted", _.muted), line: ae("--fp-line-strong", _.line), surface: ae("--fp-surface", _.surface), action: ae("--fp-primary", _.action), groups: [ae("--fp-primary", "#7255b4"), ae("--fp-success", "#368b75"), ae("--fp-warning", "#ae782f"), "#6d91b6", "#b67c96", "#8b94a8"] }, R.current = !0;
    };
    O();
    const Z = new MutationObserver(O);
    Z.observe(document.documentElement, { attributes: !0, attributeFilter: ["data-theme", "data-product", "class", "style"] });
    const we = () => {
      const se = W.getBoundingClientRect(), ae = Math.min(window.devicePixelRatio || 1, 2);
      j.current = { width: Math.max(1, se.width), height: Math.max(1, se.height) }, W.width = Math.round(j.current.width * ae), W.height = Math.round(j.current.height * ae), G.setTransform(ae, 0, 0, ae, 0, 0), R.current = !0, M.current || E.current();
    }, Me = new ResizeObserver(we);
    Me.observe(W), we();
    const Ee = (se) => {
      const ae = W.getBoundingClientRect();
      return { x: se.clientX - ae.left - j.current.width / 2, y: se.clientY - ae.top - j.current.height / 2 };
    }, qe = (se) => {
      const ae = D.current, de = { x: (se.x - ae.x) / ae.zoom, y: (se.y - ae.y) / ae.zoom };
      return A.current.nodes.reduce((le, Fe) => {
        const Ye = Math.hypot(Fe.x - de.x, Fe.y - de.y), Ke = Math.max(dr(Fe, q.current.settings.nodeSize), 12 / ae.zoom);
        return Ye <= Ke && (!le || Ye < Math.hypot(le.x - de.x, le.y - de.y)) ? Fe : le;
      }, void 0);
    }, Be = /* @__PURE__ */ new Map();
    let $e;
    const ea = (se) => {
      if (se.button !== 0) return;
      const ae = Ee(se);
      if (Be.set(se.pointerId, ae), W.setPointerCapture(se.pointerId), M.current = !0, N(""), Be.size > 1) {
        $e?.node && A.current.release($e.node), $e = void 0;
        return;
      }
      const de = qe(ae);
      $e = { id: se.pointerId, node: de?.id, start: ae, last: ae, moved: !1 }, de && A.current.pin(de.id, de.x, de.y), W.style.cursor = "grabbing";
    }, ta = (se) => {
      const ae = Ee(se), de = Be.get(se.pointerId);
      if (de && Be.size === 2) {
        const le = [...Be.entries()].find(([Ie]) => Ie !== se.pointerId)[1], Fe = Math.hypot(de.x - le.x, de.y - le.y), Ye = Math.hypot(ae.x - le.x, ae.y - le.y), Ke = D.current, ht = vn(Ke.zoom * Ye / Math.max(1, Fe)), xt = { x: (de.x + le.x) / 2, y: (de.y + le.y) / 2 }, pn = { x: (ae.x + le.x) / 2, y: (ae.y + le.y) / 2 };
        D.current = U.current = { x: pn.x - (xt.x - Ke.x) * ht / Ke.zoom, y: pn.y - (xt.y - Ke.y) * ht / Ke.zoom, zoom: ht }, Be.set(se.pointerId, ae), R.current = !0;
        return;
      }
      if (de && Be.set(se.pointerId, ae), $e && $e.id === se.pointerId) {
        if ($e.moved ||= Math.hypot(ae.x - $e.start.x, ae.y - $e.start.y) > 4, $e.node) {
          const le = D.current;
          A.current.pin($e.node, (ae.x - le.x) / le.zoom, (ae.y - le.y) / le.zoom);
        } else {
          const le = D.current;
          D.current = U.current = { ...le, x: le.x + ae.x - $e.last.x, y: le.y + ae.y - $e.last.y };
        }
        $e.last = ae, R.current = !0;
      } else if (!Be.size) {
        const le = qe(ae);
        N(le?.id || ""), W.style.cursor = "grab";
      }
    }, Nt = (se) => {
      Be.delete(se.pointerId), $e?.id === se.pointerId && ($e.node && A.current.release($e.node), !$e.moved && se.type !== "pointercancel" && w($e.node || ""), $e = void 0), W.hasPointerCapture(se.pointerId) && W.releasePointerCapture(se.pointerId), R.current = !0, W.style.cursor = "grab";
    }, na = () => {
      Be.size || N("");
    }, ra = (se) => {
      const ae = qe(Ee(se));
      ae && q.current.onSelect(ae.id);
    }, aa = (se) => {
      se.preventDefault(), M.current = !0;
      const ae = Ee(se), de = U.current, le = vn(de.zoom * Math.exp(-Math.max(-100, Math.min(100, se.deltaY)) * 2e-3));
      U.current = { x: ae.x - (ae.x - de.x) * le / de.zoom, y: ae.y - (ae.y - de.y) * le / de.zoom, zoom: le }, R.current = !0;
    };
    W.addEventListener("pointerdown", ea), W.addEventListener("pointermove", ta), W.addEventListener("pointerup", Nt), W.addEventListener("pointercancel", Nt), W.addEventListener("lostpointercapture", Nt), W.addEventListener("pointerleave", na), W.addEventListener("dblclick", ra), W.addEventListener("wheel", aa, { passive: !1 });
    const Cl = () => {
      const { width: se, height: ae } = j.current, de = D.current, { settings: le, active: Fe, hovered: Ye, query: Ke, nodes: ht } = q.current;
      G.clearRect(0, 0, se, ae);
      const xt = A.current, pn = new Map(ht.map((pe) => [pe.id, pe])), Ie = Ye || Fe, Ct = new Set(Ie ? [Ie] : []);
      if (Ie) for (const [pe, Ne] of xt.links)
        pe.id === Ie && Ct.add(Ne.id), Ne.id === Ie && Ct.add(pe.id);
      const Sl = new Set(Ke.trim() ? ht.filter((pe) => pe.label.toLocaleLowerCase().includes(Ke.trim().toLocaleLowerCase())).map((pe) => pe.id) : []), hn = (pe) => ({ x: pe.x * de.zoom + de.x + se / 2, y: pe.y * de.zoom + de.y + ae / 2 }), Qn = (pe) => {
        const Ne = hn(pe);
        return Ne.x > -30 && Ne.y > -30 && Ne.x < se + 30 && Ne.y < ae + 30;
      }, Ml = (pe) => Ie ? !Ct.has(pe) : Ke.trim() ? !Sl.has(pe) : !1;
      for (const [pe, Ne] of xt.links) {
        if (!Qn(pe) && !Qn(Ne)) continue;
        const He = hn(pe), Xe = hn(Ne), ft = Ie && (pe.id === Ie || Ne.id === Ie);
        if (G.globalAlpha = ft ? 0.8 : Ie || Ke.trim() ? 0.08 : 0.58, G.strokeStyle = ft ? _.action : _.line, G.lineWidth = le.lineThickness * (ft ? 1.4 : 0.7), G.beginPath(), G.moveTo(He.x, He.y), G.lineTo(Xe.x, Xe.y), G.stroke(), le.showArrows && (ft || de.zoom > 0.7)) {
          const mt = Math.atan2(Xe.y - He.y, Xe.x - He.x), _t = dr(Ne, le.nodeSize) * de.zoom + 3, St = Xe.x - Math.cos(mt) * _t, lt = Xe.y - Math.sin(mt) * _t;
          G.beginPath(), G.moveTo(St - Math.cos(mt - 0.5) * 5, lt - Math.sin(mt - 0.5) * 5), G.lineTo(St, lt), G.lineTo(St - Math.cos(mt + 0.5) * 5, lt - Math.sin(mt + 0.5) * 5), G.stroke();
        }
      }
      const El = [...new Set(ht.map((pe) => pe.kind).filter(Boolean))], $l = [...xt.nodes].sort((pe, Ne) => +(Ne.id === Ie) - +(pe.id === Ie) || Number(Ct.has(Ne.id)) - Number(Ct.has(pe.id)) || Ne.degree - pe.degree), Zn = [];
      for (const pe of $l) {
        if (!Qn(pe)) continue;
        const Ne = hn(pe), He = pn.get(pe.id), Xe = Math.max(2, dr(pe, le.nodeSize) * de.zoom), ft = Ml(pe.id), _t = le.colorGroups.find((rt) => rt.query.trim() && He?.label.includes(rt.query))?.color || (He?.kind ? _.groups[Math.max(0, El.indexOf(He.kind)) % _.groups.length] : _.action);
        if (G.globalAlpha = ft ? 0.18 : 1, G.fillStyle = _t, G.beginPath(), G.arc(Ne.x, Ne.y, Xe, 0, Math.PI * 2), G.fill(), pe.id === Ie && (G.strokeStyle = _t, G.lineWidth = 1.5, G.beginPath(), G.arc(Ne.x, Ne.y, Xe + 5, 0, Math.PI * 2), G.stroke()), ft || !He || !le.textOpacity || (Ie ? !Ct.has(pe.id) : de.zoom < 0.55 && Zn.length >= 12)) continue;
        const St = He.label.length > 22 ? He.label.slice(0, 21) + "…" : He.label;
        G.font = `${pe.id === Ie ? 600 : 400} 12px ${oe}`;
        const lt = G.measureText(St).width + 10, fn = 20, mn = Ne.x - lt / 2, Wt = Ne.y + Xe + 6;
        Zn.some((rt) => mn < rt.x + rt.w + 6 && mn + lt + 6 > rt.x && Wt < rt.y + rt.h + 3 && Wt + fn + 3 > rt.y) || (Zn.push({ x: mn, y: Wt, w: lt, h: fn }), G.globalAlpha = le.textOpacity * 0.94, G.fillStyle = _.surface, G.fillRect(mn, Wt, lt, fn), G.fillStyle = _.ink, G.textBaseline = "middle", G.textAlign = "center", G.fillText(St, Ne.x, Wt + fn / 2));
      }
      G.globalAlpha = 1;
    }, ia = (se) => {
      if (!V) return;
      const ae = Math.min(50, se - me);
      if (me = se, H += ae, document.hidden)
        H = 0;
      else {
        let de = !1;
        if (q.current.paused) H = 0;
        else for (; H >= 1e3 / 60; )
          de = A.current.step(q.current.settings) || de, H -= 1e3 / 60;
        !M.current && de && E.current();
        const le = D.current, Fe = U.current;
        if (Math.abs(le.x - Fe.x) + Math.abs(le.y - Fe.y) + Math.abs(le.zoom - Fe.zoom) > 0.01) {
          const Ye = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 1 : 0.2;
          D.current = { x: le.x + (Fe.x - le.x) * Ye, y: le.y + (Fe.y - le.y) * Ye, zoom: le.zoom + (Fe.zoom - le.zoom) * Ye }, de = !0;
        }
        (de || R.current) && (Cl(), R.current = !1);
      }
      ue = requestAnimationFrame(ia);
    };
    return ue = requestAnimationFrame(ia), () => {
      V = !1, cancelAnimationFrame(ue), Me.disconnect(), Z.disconnect(), W.removeEventListener("pointerdown", ea), W.removeEventListener("pointermove", ta), W.removeEventListener("pointerup", Nt), W.removeEventListener("pointercancel", Nt), W.removeEventListener("lostpointercapture", Nt), W.removeEventListener("pointerleave", na), W.removeEventListener("dblclick", ra), W.removeEventListener("wheel", aa);
    };
  }, []);
  const re = t.filter((W) => W.label.toLocaleLowerCase().includes(f.trim().toLocaleLowerCase())), ie = t.find((W) => W.id === y), ye = new Set(n.flatMap((W) => W.source === y ? [W.target] : W.target === y ? [W.source] : []).filter((W) => W !== y)), he = [...new Set(t.map((W) => W.kind).filter(Boolean))];
  return /* @__PURE__ */ o("section", { className: "fp-graph", "aria-label": "关系图谱", onKeyDown: (W) => {
    W.key === "Escape" && (b ? g(!1) : f ? m("") : y ? w("") : c?.());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-graph-toolbar", children: [
      /* @__PURE__ */ o("div", { className: "fp-graph-heading", children: [
        /* @__PURE__ */ e(ca, { size: 18 }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h3", { children: "关系图谱" }),
          /* @__PURE__ */ o("span", { children: [
            t.length,
            " 篇笔记 · ",
            n.length,
            " 条关联"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-graph-search", children: [
        /* @__PURE__ */ e(We, { size: 16 }),
        /* @__PURE__ */ e("input", { "aria-label": "搜索关联笔记", placeholder: "搜索笔记…", value: f, onChange: (W) => m(W.target.value) }),
        f && /* @__PURE__ */ e("button", { type: "button", "aria-label": "清空搜索", onClick: () => m(""), children: /* @__PURE__ */ e(ge, { size: 14 }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-actions", children: [
        /* @__PURE__ */ e("button", { type: "button", title: "适应画布", "aria-label": "适应画布", onClick: () => {
          M.current = !0, F();
        }, children: /* @__PURE__ */ e(Rn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": x ? "继续动态布局" : "暂停动态布局", title: x ? "继续动态布局" : "暂停动态布局", onClick: () => {
          C(!x), A.current.wake();
        }, children: x ? /* @__PURE__ */ e(tn, { size: 17 }) : /* @__PURE__ */ e(On, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "显示设置", title: "图谱设置", "aria-expanded": b, onClick: () => g(!b), children: /* @__PURE__ */ e(so, { size: 17 }) }),
        c && /* @__PURE__ */ e("button", { type: "button", title: "关闭图谱", "aria-label": "关闭图谱", onClick: c, children: /* @__PURE__ */ e(ge, { size: 19 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-graph-viewport", children: [
      /* @__PURE__ */ e("canvas", { ref: S, className: "fp-graph-canvas", tabIndex: 0, role: "img", "aria-label": "可拖动的笔记关系图；使用搜索选择笔记", onKeyDown: (W) => {
        W.key === "+" || W.key === "=" ? (W.preventDefault(), z(1.2)) : W.key === "-" ? (W.preventDefault(), z(1 / 1.2)) : W.key === "0" ? (W.preventDefault(), F()) : ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(W.key) ? (W.preventDefault(), M.current = !0, U.current = { ...U.current, x: U.current.x + (W.key === "ArrowLeft" ? 40 : W.key === "ArrowRight" ? -40 : 0), y: U.current.y + (W.key === "ArrowUp" ? 40 : W.key === "ArrowDown" ? -40 : 0) }, R.current = !0) : W.key === "Enter" && y && a(y);
      } }),
      u && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "status", children: [
        /* @__PURE__ */ o("div", { className: "fp-graph-skeleton", children: [
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {}),
          /* @__PURE__ */ e("i", {})
        ] }),
        /* @__PURE__ */ e("p", { children: "正在展开笔记关系…" })
      ] }),
      (d || I) && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: d || I }),
        s && /* @__PURE__ */ e("button", { type: "button", onClick: s, children: "重新加载" })
      ] }),
      !u && !d && !t.length && /* @__PURE__ */ o("div", { className: "fp-graph-placeholder", children: [
        /* @__PURE__ */ e(ca, { size: 32 }),
        /* @__PURE__ */ e("p", { children: "把笔记链接起来，知识会在这里连接成图。" })
      ] }),
      f.trim() && /* @__PURE__ */ o("nav", { className: "fp-graph-results", "aria-label": "选择关联笔记", children: [
        /* @__PURE__ */ e("small", { children: re.length ? `${re.length} 篇匹配的笔记` : "没有找到匹配的笔记" }),
        re.slice(0, 30).map((W) => /* @__PURE__ */ e("button", { type: "button", "aria-pressed": W.id === y, onClick: () => $(W.id), children: W.label }, W.id)),
        re.length > 30 && /* @__PURE__ */ e("small", { children: "继续输入可缩小范围" })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-graph-options", "data-open": b, inert: !b, "aria-hidden": !b, "aria-label": "图谱设置", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: "图谱设置" }),
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭设置", onClick: () => g(!1), children: /* @__PURE__ */ e(ge, { size: 16 }) })
        ] }),
        /* @__PURE__ */ e("p", { children: "拖动节点时，周围的笔记会随之调整。" }),
        /* @__PURE__ */ e(Zr, { label: "显示箭头", checked: K.showArrows, onChange: (W) => P({ showArrows: W.target.checked }) }),
        [["repelForce", "节点间距", 1, 20, 1], ["linkForce", "连线牵引", 0.1, 2, 0.1], ["centerForce", "中心吸引", 0, 2, 0.1], ["nodeSize", "节点大小", 0.5, 3, 0.1], ["lineThickness", "连线粗细", 0.5, 3, 0.1], ["textOpacity", "文字清晰度", 0, 1, 0.1]].map(([W, G, ue, me, H]) => /* @__PURE__ */ o("label", { className: "fp-graph-setting", children: [
          /* @__PURE__ */ o("span", { children: [
            G,
            /* @__PURE__ */ e("output", { children: K[W] })
          ] }),
          /* @__PURE__ */ e(gr, { "aria-label": G, min: ue, max: me, step: H, value: K[W], onChange: (V) => P({ [W]: Number(V.target.value) }) })
        ] }, W)),
        he.length > 0 && /* @__PURE__ */ o("div", { className: "fp-graph-group-legend", children: [
          /* @__PURE__ */ e("strong", { children: "笔记分组" }),
          he.map((W, G) => /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", { "data-color": G % 6 }),
            W
          ] }, W))
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-graph-color-groups", children: [
          /* @__PURE__ */ e("strong", { children: "关键词颜色" }),
          K.colorGroups.map((W, G) => /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("input", { className: "fp-pattern-input", "aria-label": `第 ${G + 1} 组关键词`, value: W.query, placeholder: "标题包含", onChange: (ue) => P({ colorGroups: K.colorGroups.map((me, H) => H === G ? { ...me, query: ue.target.value } : me) }) }),
            /* @__PURE__ */ e(yl, { label: `第 ${G + 1} 组颜色`, value: W.color, onChange: (ue) => P({ colorGroups: K.colorGroups.map((me, H) => H === G ? { ...me, color: ue } : me) }) }),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": `删除第 ${G + 1} 组`, onClick: () => P({ colorGroups: K.colorGroups.filter((ue, me) => me !== G) }), children: /* @__PURE__ */ e(ge, { size: 14 }) })
          ] }, G)),
          /* @__PURE__ */ o("button", { type: "button", onClick: () => P({ colorGroups: [...K.colorGroups, { query: "", color: "#7255b4" }] }), children: [
            /* @__PURE__ */ e(kn, { size: 14 }),
            "添加分组"
          ] })
        ] }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => {
          P(Ua), A.current.wake();
        }, children: [
          /* @__PURE__ */ e(Je, { size: 14 }),
          "恢复默认"
        ] }),
        s && /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: s, children: "刷新笔记关系" })
      ] }),
      ie && /* @__PURE__ */ o("div", { className: "fp-graph-inspector", children: [
        /* @__PURE__ */ e("button", { className: "fp-graph-inspector-close", type: "button", "aria-label": "取消选择", onClick: () => w(""), children: /* @__PURE__ */ e(ge, { size: 14 }) }),
        /* @__PURE__ */ o("small", { children: [
          ie.kind || "笔记",
          " · ",
          ye.size,
          " 篇关联"
        ] }),
        /* @__PURE__ */ e("strong", { children: ie.label }),
        /* @__PURE__ */ o("button", { type: "button", onClick: () => a(ie.id), children: [
          "打开笔记",
          /* @__PURE__ */ e(Dr, { size: 15 })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-graph-zoom", children: [
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "放大图谱", onClick: () => z(1.2), children: /* @__PURE__ */ e(kn, { size: 17 }) }),
        /* @__PURE__ */ e("button", { type: "button", "aria-label": "缩小图谱", onClick: () => z(1 / 1.2), children: /* @__PURE__ */ e(Ft, { size: 17 }) })
      ] }),
      /* @__PURE__ */ o("p", { className: "fp-graph-hint", children: [
        "拖动节点 · 滚轮缩放 · 双击打开笔记",
        x ? " · 布局已暂停" : ""
      ] })
    ] })
  ] });
}
function jf({
  title: t,
  children: n,
  tools: r,
  inspector: a,
  source: i,
  onSourceChange: l,
  onRun: s,
  onReset: c,
  onSave: u,
  loading: d,
  error: p
}) {
  const h = B(null), [f, m] = k(!1), [b, g] = k(!1), [y, w] = k("");
  return /* @__PURE__ */ o("section", { ref: h, className: "fp-workbench", "aria-label": t, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        r,
        i !== void 0 && /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            "aria-pressed": f,
            onClick: () => m((v) => !v),
            children: [
              f ? /* @__PURE__ */ e(ai, { size: 15 }) : /* @__PURE__ */ e(co, { size: 15 }),
              " ",
              f ? "查看内容" : "编辑源码"
            ]
          }
        ),
        a && /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-expanded": b,
            onClick: () => g((v) => !v),
            children: "参数"
          }
        ),
        c && /* @__PURE__ */ o("button", { type: "button", onClick: c, children: [
          /* @__PURE__ */ e(Je, { size: 15 }),
          "重置"
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "全屏查看",
            onClick: () => {
              if (!h.current?.requestFullscreen) {
                w("当前设备暂不支持全屏。");
                return;
              }
              h.current.requestFullscreen().catch(() => w("暂时无法进入全屏，请重试。"));
            },
            children: /* @__PURE__ */ e(Rn, { size: 15 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(Re, { isOpen: b, children: /* @__PURE__ */ e("div", { className: "fp-workbench-inspector", children: a }) }),
    /* @__PURE__ */ e("div", { className: "fp-workbench-stage", "aria-busy": d, children: d ? /* @__PURE__ */ e("p", { role: "status", children: "正在准备内容…" }) : f ? /* @__PURE__ */ o("label", { children: [
      "源码",
      /* @__PURE__ */ e(
        "textarea",
        {
          "aria-label": "内容源码",
          value: i,
          readOnly: !l,
          spellCheck: !1,
          onChange: (v) => l?.(v.target.value)
        }
      )
    ] }) : n }),
    (p || y) && /* @__PURE__ */ e("p", { role: p ? "alert" : "status", children: p || y }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      f && s && /* @__PURE__ */ e(be, { disabled: d, onAction: s, children: "运行" }),
      u && /* @__PURE__ */ e(be, { disabled: d, onAction: u, children: "保存到笔记" })
    ] })
  ] });
}
function qf({
  chapters: t,
  currentTime: n,
  onSeek: r,
  onAddNote: a
}) {
  const i = [...t].sort((s, c) => s.time - c.time), l = i.filter((s) => s.time <= n).at(-1)?.id;
  return /* @__PURE__ */ o("section", { className: "fp-classroom", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: "课堂章节" }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: () => a(n), children: "记录此刻" })
    ] }),
    i.length ? /* @__PURE__ */ e("ol", { children: i.map((s) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": l === s.id ? "step" : void 0,
        onClick: () => r(s.time),
        children: [
          /* @__PURE__ */ o("time", { children: [
            Math.floor(s.time / 60),
            ":",
            String(Math.floor(s.time % 60)).padStart(2, "0")
          ] }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: s.title }),
            s.detail && /* @__PURE__ */ e("small", { children: s.detail })
          ] })
        ]
      }
    ) }, s.id)) }) : /* @__PURE__ */ e("p", { children: "还没有课堂章节，可以在观看时添加笔记。" })
  ] });
}
function Kf({
  title: t,
  children: n,
  collapsed: r,
  onCollapsedChange: a,
  onClose: i
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-lecture-dock", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": !r,
          onClick: () => a(!r),
          children: r ? "展开播放器" : "收起播放器"
        }
      ),
      i && /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭播放器", onClick: i, children: "×" })
    ] }),
    /* @__PURE__ */ e(Re, { isOpen: !r, children: n })
  ] });
}
function Hf({
  items: t,
  onScoreChange: n,
  onComplete: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "答题复盘" }),
    /* @__PURE__ */ o("p", { children: [
      "已得 ",
      t.reduce((a, i) => a + i.awarded, 0),
      " /",
      " ",
      t.reduce((a, i) => a + i.maximum, 0),
      " 分"
    ] }),
    t.map((a) => /* @__PURE__ */ o("div", { className: "fp-scoring-item", children: [
      /* @__PURE__ */ e("strong", { children: a.title }),
      /* @__PURE__ */ o("span", { children: [
        a.awarded,
        " / ",
        a.maximum
      ] }),
      a.detail,
      a.subjective && /* @__PURE__ */ o("label", { children: [
        "自评得分",
        /* @__PURE__ */ e(
          "input",
          {
            "aria-label": `${a.title}自评得分`,
            type: "range",
            min: 0,
            max: a.maximum,
            step: a.maximum <= 10 ? 0.5 : 1,
            value: Math.max(0, Math.min(a.maximum, a.awarded)),
            onChange: (i) => n(a.id, Number(i.target.value))
          }
        )
      ] })
    ] }, a.id)),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(be, { onAction: r, children: "完成复盘" }) })
  ] });
}
function Uf({
  correct: t,
  total: n,
  score: r,
  maximum: a,
  onReview: i,
  onRetry: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "本次练习" }),
    /* @__PURE__ */ o("strong", { className: "fp-summary-value", children: [
      r,
      /* @__PURE__ */ o("small", { children: [
        " / ",
        a,
        " 分"
      ] })
    ] }),
    /* @__PURE__ */ o("p", { children: [
      n,
      " 道题中答对 ",
      t,
      " 道"
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
      /* @__PURE__ */ e("button", { type: "button", onClick: i, children: "查看解析" }),
      l && /* @__PURE__ */ e("button", { type: "button", onClick: l, children: "再练一次" })
    ] })
  ] });
}
function _f({
  options: t,
  defaultValue: n,
  ...r
}) {
  const [a, i] = k(
    String(n ?? t[0]?.value ?? "")
  ), l = String(r.value ?? a), s = B(null), c = B(null), [u, d] = k("");
  return /* @__PURE__ */ o("span", { ref: c, className: r.className, children: [
    /* @__PURE__ */ e(
      "select",
      {
        ...r,
        hidden: !0,
        onInvalid: (p) => {
          p.preventDefault(), d(p.currentTarget.validationMessage), c.current?.querySelector("button")?.focus(), r.onInvalid?.(p);
        },
        "aria-hidden": "true",
        tabIndex: -1,
        ref: s,
        value: l,
        onChange: (p) => {
          i(p.target.value), r.onChange?.(p);
        },
        children: t.map((p) => /* @__PURE__ */ e("option", { value: p.value, children: p.label }, p.value))
      }
    ),
    /* @__PURE__ */ e(
      ke,
      {
        label: r["aria-label"] || r.title || "选择选项",
        value: l,
        disabled: r.disabled,
        options: t,
        onChange: (p) => {
          i(p), d(""), s.current && (s.current.value = p, s.current.dispatchEvent(
            new Event("change", { bubbles: !0 })
          ));
        }
      }
    ),
    u && /* @__PURE__ */ e("span", { className: "fp-field-error", role: "alert", children: u })
  ] });
}
function Wf({
  label: t,
  options: n,
  value: r,
  onChange: a
}) {
  const i = ve(), [l, s] = k(!1), [c, u] = k(0), d = n.filter(
    (p) => p.toLowerCase().includes(r.toLowerCase())
  );
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: i, children: t }),
    /* @__PURE__ */ o("div", { className: "fp-combobox", children: [
      /* @__PURE__ */ e(
        "input",
        {
          id: i,
          className: "fp-input",
          role: "combobox",
          "aria-expanded": l,
          "aria-controls": i + "-options",
          "aria-autocomplete": "list",
          "aria-activedescendant": l && d.length ? i + "-" + c : void 0,
          value: r,
          onFocus: () => s(!0),
          onBlur: () => s(!1),
          onChange: (p) => {
            a(p.target.value), s(!0), u(0);
          },
          onKeyDown: (p) => {
            if (p.key === "Escape") {
              s(!1);
              return;
            }
            (p.key === "ArrowDown" || p.key === "ArrowUp") && (p.preventDefault(), s(!0), u(
              (h) => (h + (p.key === "ArrowDown" ? 1 : -1) + d.length) % Math.max(d.length, 1)
            )), p.key === "Enter" && l && d[c] && (p.preventDefault(), a(d[c]), s(!1));
          }
        }
      ),
      l && /* @__PURE__ */ o(
        "div",
        {
          id: i + "-options",
          className: "fp-combobox-options",
          role: "listbox",
          "aria-label": t,
          children: [
            d.map((p, h) => /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": h === c,
                id: i + "-" + h,
                tabIndex: -1,
                onMouseDown: (f) => f.preventDefault(),
                onClick: () => {
                  a(p), s(!1);
                },
                children: p
              },
              p
            )),
            !d.length && /* @__PURE__ */ e("p", { children: "没有匹配的选项" })
          ]
        }
      )
    ] })
  ] });
}
const Yu = "https://go.r-l.ink/ico";
function Vf({
  size: t = 32,
  decorative: n = !1
}) {
  return /* @__PURE__ */ e(
    "img",
    {
      src: Yu,
      alt: n ? "" : "五加一",
      width: t,
      height: t,
      className: "fp-brand-logo"
    }
  );
}
function Yf({ brand: t, identity: n, navigation: r, activeId: a, onNavigate: i, title: l, description: s, actions: c, footer: u, children: d }) {
  const [p, h] = k(!1), f = /* @__PURE__ */ e("nav", { className: "fp-account-nav", "aria-label": "账号功能", children: r.map((m) => /* @__PURE__ */ o("button", { type: "button", "aria-current": a === m.id ? "page" : void 0, onClick: () => {
    i(m.id), h(!1);
  }, children: [
    m.icon,
    /* @__PURE__ */ e("span", { children: m.label })
  ] }, m.id)) });
  return /* @__PURE__ */ o("div", { className: "fp-account-workspace", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#account-content", children: "跳到主要内容" }),
    /* @__PURE__ */ o("aside", { className: "fp-account-rail", children: [
      /* @__PURE__ */ e("div", { className: "fp-account-brand", children: t }),
      n && /* @__PURE__ */ e("div", { className: "fp-account-identity", children: n }),
      f,
      /* @__PURE__ */ e("div", { className: "fp-account-rail-footer", children: u })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-account-stage", children: [
      /* @__PURE__ */ o("header", { className: "fp-account-topbar", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e(te, { variant: "ghost", className: "fp-account-menu-button", "aria-label": "打开账号导航", onClick: () => h(!0), children: /* @__PURE__ */ e(rn, { size: 20 }) }),
          /* @__PURE__ */ e("span", { children: "账号中心" }),
          /* @__PURE__ */ e(ze, { size: 14 }),
          /* @__PURE__ */ e("strong", { children: l })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-account-topbar-actions", children: c })
      ] }),
      /* @__PURE__ */ o("main", { id: "account-content", className: "fp-account-page", children: [
        /* @__PURE__ */ o("header", { className: "fp-account-page-heading", children: [
          /* @__PURE__ */ e("h1", { children: l }),
          s && /* @__PURE__ */ e("p", { children: s })
        ] }),
        d
      ] })
    ] }),
    /* @__PURE__ */ o(ut, { open: p, drawer: !0, title: "账号中心", onClose: () => h(!1), children: [
      n,
      f,
      u
    ] })
  ] });
}
function Xf({ title: t, description: n, children: r, actions: a, className: i = "" }) {
  return /* @__PURE__ */ o("section", { className: "fp-account-panel " + i, children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h2", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      a
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-account-panel-body", children: r })
  ] });
}
function Gf({ label: t, value: n, description: r, icon: a, action: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-setting", children: [
    a && /* @__PURE__ */ e("span", { className: "fp-account-setting-icon", children: a }),
    /* @__PURE__ */ o("div", { className: "fp-account-setting-copy", children: [
      /* @__PURE__ */ e("h3", { children: t }),
      n && /* @__PURE__ */ e("div", { className: "fp-account-setting-value", children: n }),
      r && /* @__PURE__ */ e("p", { children: r })
    ] }),
    i && /* @__PURE__ */ e("div", { className: "fp-account-setting-action", children: i })
  ] });
}
function ur(t, n, r, a, i) {
  const l = Math.min(t, n) / Math.max(1, Math.min(4, r));
  return { x: (t - l) / 2 * (1 + Math.max(-1, Math.min(1, a))), y: (n - l) / 2 * (1 + Math.max(-1, Math.min(1, i))), size: l };
}
function Jf({ name: t, avatarUrl: n, onSave: r, onChooseLibrary: a, maxBytes: i = 5 * 1024 * 1024 }) {
  const [l, s] = k(!1), [c, u] = k(""), [d, p] = k(null), [h, f] = k(1), [m, b] = k({ x: 0, y: 0 }), [g, y] = k(""), [w, v] = k(!1), [N, x] = k(!1), C = B(null), I = B(null), L = B(null), K = B(void 0), S = B(!1);
  Y(() => {
    if (!c) {
      p(null);
      return;
    }
    const T = new Image();
    let M = !0;
    return x(!0), T.onload = () => {
      if (M) {
        if (T.naturalWidth * T.naturalHeight > 2e7) {
          y("图片尺寸过大，请选择较小的图片。"), x(!1);
          return;
        }
        p(T), x(!1);
      }
    }, T.onerror = () => {
      M && (y("无法读取这张图片，请重新选择。"), x(!1));
    }, T.src = c, () => {
      M = !1, URL.revokeObjectURL(c);
    };
  }, [c]), Y(() => {
    if (!d) return;
    const T = ur(d.naturalWidth, d.naturalHeight, h, m.x, m.y);
    for (const M of [I.current, L.current]) {
      if (!M) continue;
      const R = M.getContext("2d");
      R?.clearRect(0, 0, M.width, M.height), R?.drawImage(d, T.x, T.y, T.size, T.size, 0, 0, M.width, M.height);
    }
  }, [d, h, m, l]);
  function A(T) {
    if (y(""), T.size > i) {
      y("图片大小请控制在 5 MB 以内。");
      return;
    }
    if (!["image/jpeg", "image/png", "image/webp"].includes(T.type)) {
      y("请选择 JPG、PNG 或 WebP 图片。");
      return;
    }
    p(null), f(1), b({ x: 0, y: 0 }), u(URL.createObjectURL(T));
  }
  function D(T) {
    if (w || !K.current || !d) return;
    const M = T.currentTarget.getBoundingClientRect(), R = ur(d.naturalWidth, d.naturalHeight, h, 0, 0), q = (T.clientX - K.current.x) / M.width * R.size, F = (T.clientY - K.current.y) / M.height * R.size;
    b({ x: Math.max(-1, Math.min(1, K.current.ox - (d.naturalWidth > R.size ? q / ((d.naturalWidth - R.size) / 2) : 0))), y: Math.max(-1, Math.min(1, K.current.oy - (d.naturalHeight > R.size ? F / ((d.naturalHeight - R.size) / 2) : 0))) });
  }
  const U = () => {
    w || N || (s(!1), u(""), p(null), y(""));
  };
  async function j() {
    if (!(!d || S.current)) {
      S.current = !0, K.current = void 0, v(!0), y("");
      try {
        const T = document.createElement("canvas");
        T.width = T.height = 512;
        const M = ur(d.naturalWidth, d.naturalHeight, h, m.x, m.y);
        T.getContext("2d").drawImage(d, M.x, M.y, M.size, M.size, 0, 0, 512, 512);
        const R = await new Promise((q, F) => T.toBlob((E) => E ? q(E) : F(new Error("图片处理失败，请重新选择。")), "image/webp", 0.9));
        await r(new File([R], "avatar.webp", { type: "image/webp" })), s(!1), u(""), p(null);
      } catch (T) {
        y(T instanceof Error ? T.message : "头像上传失败，请重试。");
      } finally {
        S.current = !1, v(!1);
      }
    }
  }
  return /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ o("div", { className: "fp-avatar-editor-summary", children: [
      /* @__PURE__ */ e("span", { className: "fp-avatar-editor-current", children: n ? /* @__PURE__ */ e("img", { src: n, alt: "当前头像" }) : /* @__PURE__ */ e("span", { "aria-hidden": "true", children: t.slice(0, 1) }) }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ o(te, { variant: "secondary", onClick: () => s(!0), children: [
          /* @__PURE__ */ e(uo, { size: 16 }),
          "更换头像"
        ] }),
        /* @__PURE__ */ e("p", { children: "选择一张喜欢的图片作为头像。" })
      ] })
    ] }),
    /* @__PURE__ */ o(ut, { open: l, title: c ? "调整头像" : "更换头像", className: "fp-avatar-editor-dialog", onClose: U, dismissible: !w && !N, footer: /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: w || N, onClick: U, children: "取消" }),
      c && /* @__PURE__ */ e(te, { loading: w, disabled: !d || N, onClick: () => {
        j();
      }, children: w ? "正在上传…" : "保存头像" })
    ] }), children: [
      /* @__PURE__ */ e("input", { ref: C, className: "fp-avatar-file", type: "file", accept: "image/jpeg,image/png,image/webp", "aria-label": "选择本地头像图片", disabled: w || N, onChange: (T) => {
        const M = T.target.files?.[0];
        T.target.value = "", M && A(M);
      } }),
      g && /* @__PURE__ */ e("p", { className: "fp-account-feedback", role: "alert", children: g }),
      c ? /* @__PURE__ */ o("div", { className: "fp-avatar-crop-layout", children: [
        /* @__PURE__ */ o("div", { className: "fp-avatar-crop-controls", children: [
          /* @__PURE__ */ o("div", { className: "fp-avatar-crop-stage", "aria-busy": w || N, children: [
            /* @__PURE__ */ e("canvas", { ref: I, width: 512, height: 512, tabIndex: w ? -1 : 0, role: "img", "aria-label": "头像裁切区域，拖动图片或使用方向键调整位置", onPointerDown: (T) => {
              w || (T.currentTarget.setPointerCapture(T.pointerId), K.current = { x: T.clientX, y: T.clientY, ox: m.x, oy: m.y });
            }, onPointerMove: D, onPointerUp: () => {
              K.current = void 0;
            }, onPointerCancel: () => {
              K.current = void 0;
            }, onKeyDown: (T) => {
              if (w) return;
              const M = T.shiftKey ? 0.1 : 0.025, R = T.key;
              ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(R) && (T.preventDefault(), b((q) => ({ x: Math.max(-1, Math.min(1, q.x + (R === "ArrowLeft" ? -M : R === "ArrowRight" ? M : 0))), y: Math.max(-1, Math.min(1, q.y + (R === "ArrowUp" ? -M : R === "ArrowDown" ? M : 0))) })));
            } }),
            /* @__PURE__ */ e("div", { className: "fp-avatar-crop-guide" }),
            (w || N) && /* @__PURE__ */ o("div", { className: "fp-avatar-upload-overlay", role: "status", children: [
              /* @__PURE__ */ e(Hr, { size: 28 }),
              /* @__PURE__ */ e("strong", { children: w ? "正在上传头像…" : "正在读取图片…" })
            ] })
          ] }),
          /* @__PURE__ */ e("p", { children: "拖动图片调整位置，使用滑块缩放。" }),
          /* @__PURE__ */ o("label", { className: "fp-avatar-zoom", children: [
            /* @__PURE__ */ e(Ir, { size: 16 }),
            /* @__PURE__ */ e("input", { type: "range", "aria-label": "缩放头像", min: "1", max: "4", step: "0.01", value: h, disabled: w || N, onChange: (T) => f(Number(T.target.value)) }),
            /* @__PURE__ */ e(Ar, { size: 16 })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-avatar-crop-actions", children: [
            /* @__PURE__ */ e(te, { variant: "ghost", disabled: w || N, onClick: () => C.current?.click(), children: "重新选择" }),
            /* @__PURE__ */ o(te, { variant: "ghost", disabled: w || N, onClick: () => {
              f(1), b({ x: 0, y: 0 });
            }, children: [
              /* @__PURE__ */ e(Je, { size: 15 }),
              "重置"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ o("aside", { className: "fp-avatar-preview", children: [
          /* @__PURE__ */ e("p", { children: "头像预览" }),
          /* @__PURE__ */ e("canvas", { ref: L, width: 192, height: 192, "aria-label": "裁切后的圆形头像预览" }),
          /* @__PURE__ */ e("small", { children: "保存后将显示在你的五加一账号中" })
        ] })
      ] }) : /* @__PURE__ */ o("div", { className: "fp-avatar-sources", children: [
        /* @__PURE__ */ e("p", { children: "从设备上传，或使用五加一图床里的图片。" }),
        /* @__PURE__ */ o(te, { variant: "secondary", disabled: N, onClick: () => C.current?.click(), children: [
          /* @__PURE__ */ e(po, { size: 20 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "本地上传" }),
            /* @__PURE__ */ e("small", { children: "JPG、PNG、WebP · 最大 5 MB" })
          ] })
        ] }),
        a && /* @__PURE__ */ o(te, { variant: "secondary", loading: N, onClick: () => {
          x(!0), y(""), a().then((T) => {
            T && A(T);
          }).catch((T) => y(T instanceof Error ? T.message : "暂时无法打开图床，请重试。")).finally(() => x(!1));
        }, children: [
          /* @__PURE__ */ e(ho, { size: 20 }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "从五加一图床选择" }),
            /* @__PURE__ */ e("small", { children: "选择已有图片，也可以继续上传" })
          ] })
        ] })
      ] })
    ] })
  ] });
}
function Qf({
  renderRow: t,
  items: n,
  selectedId: r,
  onSelect: a,
  defaultExpanded: i = [],
  expandedIds: l,
  onExpandedChange: s,
  onToggle: c,
  onPrefetch: u,
  onOpen: d,
  onMiddleClick: p,
  onNodeDragStart: h,
  onNodeDragOver: f,
  onNodeDrop: m,
  namespace: b = "files",
  onRename: g,
  onRemove: y,
  onCreate: w,
  label: v = "文件目录"
}) {
  let [N, x] = k(new Set(i));
  const C = l === void 0 ? N : new Set(l);
  let I = B(null);
  const L = B(null);
  let [K, S] = k(null), A = [];
  function D(R) {
    R.forEach((q) => {
      A.push(q), C.has(q.id) && q.children && D(q.children);
    });
  }
  D(n);
  function U(R) {
    const q = new Set(C);
    q.has(R) ? q.delete(R) : q.add(R), l === void 0 && x(q), s?.([...q]), c?.(R, q.has(R));
  }
  function j(R) {
    S(R), requestAnimationFrame(
      () => I.current?.querySelector(`[data-node="${CSS.escape(R)}"]`)?.focus()
    );
  }
  function T(R, q) {
    let F = A.findIndex((E) => E.id === q.id);
    if ([
      "ArrowDown",
      "ArrowUp",
      "Home",
      "End",
      "ArrowRight",
      "ArrowLeft",
      "Enter",
      " "
    ].includes(R.key) && R.preventDefault(), R.key === "ArrowDown" && j(A[Math.min(A.length - 1, F + 1)].id), R.key === "ArrowUp" && j(A[Math.max(0, F - 1)].id), R.key === "Home" && j(A[0].id), R.key === "End" && j(A[A.length - 1].id), R.key === "ArrowRight" && q.kind === "folder" && (C.has(q.id) ? q.children?.[0] && j(q.children[0].id) : U(q.id)), R.key === "ArrowLeft")
      if (C.has(q.id)) U(q.id);
      else {
        let E = function($) {
          for (let P of $) {
            if (P.children?.some((ie) => ie.id === q.id)) return P;
            let re = P.children && E(P.children);
            if (re) return re;
          }
        }, z = E(n);
        z && j(z.id);
      }
    (R.key === "Enter" || R.key === " ") && (q.kind === "folder" ? U(q.id) : (a(q), d?.(q, R)));
  }
  function M(R, q = 0) {
    return R.map((F) => /* @__PURE__ */ e(yt, { tabIndex: -1, label: `${F.name}的操作`, onOpen: (E) => {
      L.current = E;
    }, items: [
      { id: "open", label: F.kind === "folder" ? C.has(F.id) ? "收起文件夹" : "展开文件夹" : "打开", onSelect: () => {
        F.kind === "folder" ? U(F.id) : (a(F), L.current && d?.(F, L.current));
      } },
      ...F.kind === "folder" && w ? [{ id: "create", label: "新建文件", onSelect: () => w(F) }] : [],
      ...g ? [{ id: "rename", label: "重命名", onSelect: () => g(F) }] : [],
      ...y ? [{ id: "remove", label: "移除", danger: !0, separator: !0, onSelect: () => y(F) }] : []
    ], children: /* @__PURE__ */ o("div", { role: "none", children: [
      /* @__PURE__ */ e(Xu, { node: F, renderRow: t, children: /* @__PURE__ */ o(
        "div",
        {
          role: "treeitem",
          "aria-level": q + 1,
          "aria-expanded": F.kind === "folder" ? C.has(F.id) : void 0,
          "aria-selected": r === F.id,
          tabIndex: (A.find((E) => E.id === K)?.id || A.find((E) => E.id === r)?.id || A[0]?.id) === F.id ? 0 : -1,
          "data-node": F.id,
          className: "fp-file-tree-row",
          style: { paddingLeft: 12 + q * 18 },
          onFocus: (E) => {
            E.target === E.currentTarget && (S(F.id), u?.(F));
          },
          onMouseEnter: () => u?.(F),
          draggable: !!h,
          onDragStart: (E) => {
            h?.(F, E);
            const z = document.createElement("div");
            z.className = "fp-file-drag-preview", z.textContent = F.name, document.body.appendChild(z), E.dataTransfer.setDragImage?.(z, 12, 18), setTimeout(() => z.remove(), 0);
          },
          onDragOver: m ? (E) => {
            f?.(F, E), !(f && !E.defaultPrevented) && (E.preventDefault(), E.stopPropagation(), E.currentTarget.dataset.dropTarget = "true");
          } : void 0,
          onDragLeave: (E) => {
            E.currentTarget.contains(E.relatedTarget) || delete E.currentTarget.dataset.dropTarget;
          },
          onDragEnd: () => I.current?.querySelectorAll("[data-drop-target]").forEach((E) => delete E.dataset.dropTarget),
          onDrop: m ? (E) => {
            E.preventDefault(), E.stopPropagation(), delete E.currentTarget.dataset.dropTarget, m(F, E);
          } : void 0,
          onAuxClick: (E) => {
            E.button === 1 && F.kind === "file" && p && (E.preventDefault(), p(F, E));
          },
          onKeyDown: (E) => T(E, F),
          onClick: (E) => {
            S(F.id), F.kind === "folder" ? U(F.id) : (a(F), d?.(F, E));
          },
          children: [
            F.kind === "folder" ? /* @__PURE__ */ o(Q, { children: [
              /* @__PURE__ */ e(
                ze,
                {
                  size: 13,
                  className: C.has(F.id) ? "is-expanded" : ""
                }
              ),
              C.has(F.id) ? /* @__PURE__ */ e(ii, { size: 16 }) : /* @__PURE__ */ e(Nn, { size: 16 })
            ] }) : /* @__PURE__ */ o(Q, { children: [
              /* @__PURE__ */ e("span", { style: { width: 13 } }),
              /* @__PURE__ */ e(Qe, { size: 16 })
            ] }),
            /* @__PURE__ */ e("span", { className: "fp-tree-name", title: F.name, children: F.name }),
            (g || y || F.kind === "folder" && w) && /* @__PURE__ */ e(
              "span",
              {
                onClick: (E) => E.stopPropagation(),
                onKeyDown: (E) => E.stopPropagation(),
                className: "fp-tree-actions",
                children: /* @__PURE__ */ e(
                  ki,
                  {
                    label: "操作",
                    icon: /* @__PURE__ */ e(Ot, { size: 16, "aria-hidden": "true" }),
                    items: [
                      ...F.kind === "folder" && w ? [{ label: "新建文件", onClick: () => w(F) }] : [],
                      ...g ? [{ label: "重命名", onClick: () => g(F) }] : [],
                      ...y ? [
                        {
                          label: "移除",
                          danger: !0,
                          onClick: () => y(F)
                        }
                      ] : []
                    ]
                  }
                )
              }
            )
          ]
        }
      ) }),
      F.kind === "folder" && /* @__PURE__ */ e(Re, { isOpen: C.has(F.id), children: /* @__PURE__ */ e("div", { role: "group", children: M(F.children || [], q + 1) }) })
    ] }) }, `${b}/${F.id}`));
  }
  return /* @__PURE__ */ o("div", { ref: I, className: "fp-file-tree", role: "tree", "aria-label": v, children: [
    M(n),
    !n.length && /* @__PURE__ */ e("p", { children: "还没有文件，添加资料后会显示在这里。" })
  ] });
}
function Xu({ node: t, renderRow: n, children: r }) {
  return /* @__PURE__ */ e(Q, { children: n ? n(t, r) : r });
}
const Zf = Tl(function({ panels: n, direction: r = "horizontal", persistenceKey: a, onLayout: i, className: l = "" }, s) {
  const c = B(null), u = B(/* @__PURE__ */ new Map());
  return Dl(s, () => ({
    getLayout: () => c.current?.getLayout() || [],
    setLayout: (d) => c.current?.setLayout(d),
    collapse: (d) => u.current.get(d)?.collapse(),
    expand: (d) => u.current.get(d)?.expand(),
    resize: (d, p) => u.current.get(d)?.resize(p),
    isCollapsed: (d) => u.current.get(d)?.isCollapsed() || !1
  }), []), /* @__PURE__ */ e(fs, { ref: c, direction: r, autoSaveId: a, onLayout: i, className: `fp-workspace-layout ${l}`, children: n.map((d, p) => /* @__PURE__ */ o(Wa, { children: [
    p > 0 && /* @__PURE__ */ e(ms, { className: "fp-workspace-divider", "aria-label": `调整${n[p - 1].label}与${d.label}` }),
    /* @__PURE__ */ e(
      bs,
      {
        ref: (h) => {
          h ? u.current.set(d.id, h) : u.current.delete(d.id);
        },
        id: d.id,
        order: p,
        defaultSize: d.defaultSize,
        minSize: d.minSize ?? 10,
        maxSize: d.maxSize,
        collapsible: d.collapsible,
        collapsedSize: d.collapsedSize ?? 0,
        onCollapse: d.onCollapse,
        onExpand: d.onExpand,
        children: /* @__PURE__ */ e("section", { className: "fp-workspace-pane", "aria-label": d.label, children: d.content })
      }
    )
  ] }, d.id)) });
});
function em({
  url: t,
  room: n,
  token: r,
  user: a,
  enabled: i = !0
}) {
  let [l, s] = k(null), [c, u] = k("connecting");
  return Y(() => {
    if (!i) return;
    let d = new vs.Doc(), p = new gs({
      url: t,
      name: n,
      document: d,
      token: r,
      onStatus: ({ status: h }) => u(h),
      onAuthenticationFailed: () => u("unauthorized")
    });
    return p.setAwarenessField("user", a), s({ document: d, provider: p }), () => {
      s(null), p.destroy(), d.destroy();
    };
  }, [t, n, r, i, a.id, a.name, a.color]), { session: l, status: c };
}
function tm({ user: t, status: n = "local", onChange: r, onMarkdownChange: a, ...i }) {
  const l = n === "local" ? "本地编辑" : n === "connected" ? "已连接" : n === "unauthorized" ? "需要重新登录" : n === "disconnected" ? "等待重新连接" : "正在连接";
  return /* @__PURE__ */ o("section", { className: "fp-collab-editor", children: [
    /* @__PURE__ */ o("header", { className: "fp-collab-presence", children: [
      /* @__PURE__ */ e("span", { style: { color: t.color }, children: "●" }),
      /* @__PURE__ */ e("span", { children: t.name }),
      /* @__PURE__ */ e("span", { children: i.editable === !1 ? "只读" : "可以编辑" }),
      /* @__PURE__ */ e("span", { role: "status", children: l })
    ] }),
    /* @__PURE__ */ e(Jn, { ...i, user: t, onChange: (s, c) => {
      r?.(c), a?.(s);
    } })
  ] });
}
function nm({ messages: t, isLoading: n = !1, error: r, onClearError: a, onFollowUpClick: i, followUpQuestions: l = [], bottomInset: s = 0, renderMessage: c, emptyState: u, hydrated: d = !0, sessionId: p = "default", scrollContainerRef: h, hasOlder: f, loadingOlder: m, onLoadOlder: b, virtualize: g = t.length > 30, estimateSize: y = 100, footer: w, loadingIndicator: v, className: N = "", style: x }) {
  const C = B(null), I = h || C, L = B(null), K = B(!0), [S, A] = k(!1), D = B(/* @__PURE__ */ new Map()), U = B(p), j = B(null), T = B({ first: t[0]?.id, height: 0, top: 0 }), M = yi({ count: t.length, getScrollElement: () => I.current, estimateSize: () => y, getItemKey: (F) => t[F].id, overscan: 5, enabled: g }), R = () => {
    const F = I.current;
    F && (F.scrollTop = F.scrollHeight, K.current = !0, A(!1));
  };
  Ce(() => {
    const F = I.current;
    if (F) {
      if (U.current !== p) {
        const E = T.current;
        D.current.set(U.current, { top: E.top, pinned: K.current }), U.current = p, j.current = null, T.current = { first: t[0]?.id, height: 0, top: 0 };
      }
      if (d) {
        if (j.current !== p) {
          const E = D.current.get(p);
          K.current = E?.pinned ?? !0, F.scrollTop = K.current ? F.scrollHeight : E?.top || 0, j.current = p;
        } else T.current.first && t[0]?.id !== T.current.first && !K.current ? F.scrollTop = T.current.top + F.scrollHeight - T.current.height : K.current && (F.scrollTop = F.scrollHeight);
        T.current = { first: t[0]?.id, height: F.scrollHeight, top: F.scrollTop }, A(!K.current);
      }
    }
  }, [t, p, d, s, n]), Ce(() => {
    const F = I.current, E = L.current;
    if (!F || !E || typeof ResizeObserver > "u") return;
    let z = 0;
    const $ = new ResizeObserver(() => {
      cancelAnimationFrame(z), z = requestAnimationFrame(() => {
        K.current && (F.scrollTop = F.scrollHeight), T.current.height = F.scrollHeight, T.current.top = F.scrollTop;
      });
    });
    return $.observe(E), $.observe(F), () => {
      $.disconnect(), cancelAnimationFrame(z);
    };
  }, [I]);
  const q = (F) => c ? c(F) : /* @__PURE__ */ e(Gu, { message: F });
  return /* @__PURE__ */ o("div", { className: `fp-message-list-container ${N}`, style: x, children: [
    /* @__PURE__ */ e(
      "div",
      {
        ref: I,
        className: "fp-message-list",
        role: "region",
        "aria-label": "对话记录",
        tabIndex: 0,
        onScroll: () => {
          const F = I.current;
          K.current = F.scrollHeight - F.scrollTop - F.clientHeight < 48, A(!K.current), T.current.top = F.scrollTop, T.current.height = F.scrollHeight, D.current.set(p, { top: F.scrollTop, pinned: K.current });
        },
        children: /* @__PURE__ */ o("div", { ref: L, className: "fp-message-list-content", style: { paddingBottom: Math.max(0, Number.isFinite(s) ? s : 0), overflowAnchor: "none" }, children: [
          f && /* @__PURE__ */ e("button", { type: "button", className: "fp-history-load", disabled: m, onClick: b, children: m ? "正在加载…" : "加载更早的消息" }),
          d ? t.length === 0 ? u : g ? /* @__PURE__ */ e("div", { style: { height: M.getTotalSize(), position: "relative" }, children: M.getVirtualItems().map((F) => /* @__PURE__ */ e("div", { "data-index": F.index, ref: M.measureElement, style: { position: "absolute", top: 0, left: 0, width: "100%", transform: `translateY(${F.start}px)` }, children: /* @__PURE__ */ e("div", { className: "fp-message-row", children: q(t[F.index]) }) }, F.key)) }) : t.map((F) => /* @__PURE__ */ e("div", { className: "fp-message-row", children: q(F) }, F.id)) : /* @__PURE__ */ e("p", { role: "status", children: "正在打开对话…" }),
          n && (v === void 0 ? /* @__PURE__ */ e("div", { className: "fp-message-loading", role: "status", children: "正在回复…" }) : v),
          w,
          l.length > 0 && /* @__PURE__ */ e("div", { className: "fp-follow-ups", "aria-label": "继续提问", children: l.map((F) => /* @__PURE__ */ e("button", { type: "button", onClick: () => i?.(F), children: F }, F)) })
        ] })
      }
    ),
    S && /* @__PURE__ */ o("button", { type: "button", className: "fp-message-latest", onClick: R, children: [
      /* @__PURE__ */ e(Qa, { size: 14, "aria-hidden": "true" }),
      "回到最新"
    ] }),
    r && /* @__PURE__ */ o("div", { className: "fp-message-error", role: "alert", children: [
      /* @__PURE__ */ e("span", { children: r }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "关闭" })
    ] })
  ] });
}
function Gu({ message: t }) {
  return /* @__PURE__ */ o("div", { className: `fp-message-bubble fp-message-${t.role}`, "data-role": t.role, children: [
    /* @__PURE__ */ e("div", { className: "fp-message-content", children: t.content }),
    t.timestamp && /* @__PURE__ */ e("time", { className: "fp-message-time", dateTime: t.timestamp.toISOString(), children: t.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) })
  ] });
}
function rm({
  inputProps: t,
  sendIcon: n,
  stopIcon: r,
  attachmentIcon: a,
  inputRef: i,
  value: l,
  onChange: s,
  onSend: c,
  onStop: u,
  isLoading: d,
  disabled: p,
  disabledReason: h,
  placeholder: f = "输入问题，或添加资料…",
  quotedText: m,
  onClearQuote: b,
  attachments: g = [],
  onRemoveAttachment: y,
  onFiles: w,
  accept: v,
  tools: N,
  footer: x,
  compact: C = !1,
  notice: I,
  onComposerInsetChange: L,
  sendOnEnter: K = !0
}) {
  const S = B(null), A = B(null), D = B(null), U = B(!1), j = B(!1), [T, M] = k(!1), [R, q] = k(""), E = !p && !(d || T) && !g.some(
    ($) => $.status === "uploading" || $.status === "error"
  ) && (!!l.trim() || g.length > 0);
  Ce(() => {
    const $ = A.current;
    if (!$) return;
    const P = $.cloneNode(!1);
    P.removeAttribute("id"), P.removeAttribute("aria-label"), P.setAttribute("aria-hidden", "true"), P.tabIndex = -1, P.value = l, Object.assign(P.style, {
      position: "absolute",
      visibility: "hidden",
      pointerEvents: "none",
      height: "0px",
      minHeight: "0px",
      width: `${$.getBoundingClientRect().width}px`,
      transition: "none"
    }), $.parentElement?.append(P);
    const re = Math.min(200, Math.max(48, P.scrollHeight));
    P.remove(), $.style.height = `${re}px`;
  }, [l]), Ce(() => {
    if (!S.current || !L) return;
    const $ = () => L(S.current?.getBoundingClientRect().height || 0);
    $();
    const P = typeof ResizeObserver > "u" ? null : new ResizeObserver($);
    return P?.observe(S.current), () => {
      P?.disconnect(), L(0);
    };
  }, [L]);
  async function z() {
    if (!(!E || j.current)) {
      j.current = !0, M(!0), q("");
      try {
        await c(l.trim());
      } catch ($) {
        q($ instanceof Error ? $.message : "发送失败，请重试");
      } finally {
        j.current = !1, M(!1);
      }
    }
  }
  return /* @__PURE__ */ o("div", { ref: S, className: "fp-chat-composer-wrap", children: [
    I,
    /* @__PURE__ */ o(
      "div",
      {
        className: `fp-chat-composer${C ? " fp-composer-compact" : ""}`,
        "data-disabled": p || void 0,
        onDragOver: ($) => {
          w && !p && $.preventDefault();
        },
        onDrop: ($) => {
          w && !p && $.dataTransfer.files.length && ($.preventDefault(), w(Array.from($.dataTransfer.files)));
        },
        children: [
          m && /* @__PURE__ */ o("div", { className: "fp-composer-quote", children: [
            /* @__PURE__ */ e(Za, { size: 14, "aria-hidden": "true" }),
            /* @__PURE__ */ e("span", { children: m }),
            b && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "移除引用",
                onClick: b,
                children: /* @__PURE__ */ e(ge, { size: 14 })
              }
            )
          ] }),
          g.length > 0 && /* @__PURE__ */ e("ul", { className: "fp-composer-attachments", "aria-label": "已添加的附件", children: g.map(($) => /* @__PURE__ */ o("li", { "data-status": $.status, children: [
            $.previewUrl ? /* @__PURE__ */ e("img", { src: $.previewUrl, alt: "" }) : $.status === "uploading" ? /* @__PURE__ */ e(Rt, { size: 16, className: "fp-spin" }) : /* @__PURE__ */ e(Qe, { size: 16 }),
            /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e("span", { children: $.name }),
              $.status === "uploading" && /* @__PURE__ */ e("small", { children: "正在上传" }),
              $.status === "error" && /* @__PURE__ */ e("small", { role: "alert", children: $.error || "上传失败，请重新添加" })
            ] }),
            y && /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": `移除${$.name}`,
                onClick: () => y($.id),
                children: /* @__PURE__ */ e(ge, { size: 14 })
              }
            )
          ] }, $.id)) }),
          /* @__PURE__ */ e(
            "textarea",
            {
              ...t,
              ref: ($) => {
                A.current = $, typeof i == "function" ? i($) : i && (i.current = $);
              },
              value: l,
              disabled: p,
              "aria-label": "消息",
              placeholder: h || f,
              rows: 2,
              onChange: ($) => s($.target.value),
              onCompositionStart: () => {
                U.current = !0;
              },
              onCompositionEnd: () => {
                U.current = !1;
              },
              onPaste: ($) => {
                if (t?.onPaste?.($), $.defaultPrevented) return;
                const P = Array.from($.clipboardData?.files || []);
                P.length && w && !p && ($.preventDefault(), w(P));
              },
              onKeyDown: ($) => {
                $.key === "Enter" && !$.shiftKey && !U.current && !$.nativeEvent.isComposing && $.keyCode !== 229 && (K || $.ctrlKey || $.metaKey) && ($.preventDefault(), z());
              }
            }
          ),
          /* @__PURE__ */ o("div", { className: "fp-composer-actions", children: [
            /* @__PURE__ */ o("div", { className: "fp-composer-tools", children: [
              w && /* @__PURE__ */ o(Q, { children: [
                /* @__PURE__ */ e(
                  "input",
                  {
                    ref: D,
                    type: "file",
                    multiple: !0,
                    accept: v,
                    hidden: !0,
                    onChange: ($) => {
                      const P = Array.from($.target.files || []);
                      P.length && w(P), $.target.value = "";
                    }
                  }
                ),
                /* @__PURE__ */ e(
                  "button",
                  {
                    type: "button",
                    className: "fp-composer-icon",
                    "aria-label": "添加附件",
                    "data-fp-tooltip": "添加附件",
                    disabled: p,
                    onClick: () => D.current?.click(),
                    children: a || /* @__PURE__ */ e(fr, { size: 17 })
                  }
                )
              ] }),
              N
            ] }),
            C && x && /* @__PURE__ */ e("div", { className: "fp-composer-inline-footer", children: x }),
            d && u ? /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "停止回复",
                "data-fp-tooltip": "停止回复",
                onClick: u,
                children: r || /* @__PURE__ */ e(Hn, { size: 14, fill: "currentColor" })
              }
            ) : /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-composer-send",
                "aria-label": "发送消息",
                "data-fp-tooltip": "发送消息 · Enter",
                disabled: !E,
                onClick: () => {
                  z();
                },
                children: T ? /* @__PURE__ */ e(Rt, { size: 16, className: "fp-spin" }) : n || /* @__PURE__ */ e(Pr, { size: 18 })
              }
            )
          ] }),
          !C && x && /* @__PURE__ */ e("div", { className: "fp-composer-footer", children: x })
        ]
      }
    ),
    (R || h) && /* @__PURE__ */ e(
      "p",
      {
        className: R ? "fp-error-text" : "fp-composer-hint",
        role: R ? "alert" : void 0,
        children: R || h
      }
    )
  ] });
}
function Ju({ members: t, roles: n, canManage: r = !1, busyIds: a = [], onRoleChange: i, onRemove: l, onInvite: s, defaultInviteRole: c, error: u }) {
  const [d, p] = k(""), [h, f] = k(c || n[0]?.value || ""), [m, b] = k(!1), [g, y] = k(""), [w, v] = k(""), N = B(!1), x = ve();
  return /* @__PURE__ */ o("section", { className: "fp-member-access", "aria-label": "成员与访问权限", children: [
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ e("ul", { className: "fp-access-members", children: t.map((C) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-access-avatar", "aria-hidden": "true", children: C.name.slice(0, 1) }),
      /* @__PURE__ */ o("span", { className: "fp-access-identity", children: [
        /* @__PURE__ */ e("strong", { children: C.name }),
        C.detail && /* @__PURE__ */ e("small", { children: C.detail })
      ] }),
      r && C.editable !== !1 && i ? /* @__PURE__ */ e(ke, { label: `${C.name}的权限`, value: C.role, disabled: a.includes(C.id), onChange: (I) => i(C.id, I), options: n }) : /* @__PURE__ */ e("span", { className: "fp-access-role", children: n.find((I) => I.value === C.role)?.label || C.role }),
      r && C.editable !== !1 && l && /* @__PURE__ */ e("button", { type: "button", className: "fp-access-remove", "aria-label": `移除${C.name}`, disabled: a.includes(C.id), onClick: () => l(C.id), children: /* @__PURE__ */ e(ge, { size: 15 }) })
    ] }, C.id)) }) }),
    !t.length && /* @__PURE__ */ e("p", { className: "fp-access-help", children: "还没有其他成员。" }),
    r && s && /* @__PURE__ */ o("form", { className: "fp-access-invite", onSubmit: async (C) => {
      if (C.preventDefault(), !(N.current || !d.trim() || !h)) {
        N.current = !0, b(!0), y(""), v("");
        try {
          await s(d.trim(), h), p(""), y("邀请已发送");
        } catch (I) {
          v(I instanceof Error ? I.message : "邀请未能发送，请重试");
        } finally {
          N.current = !1, b(!1);
        }
      }
    }, children: [
      /* @__PURE__ */ e("label", { htmlFor: x, children: "邀请成员" }),
      /* @__PURE__ */ o("div", { className: "fp-access-invite-fields", children: [
        /* @__PURE__ */ e("input", { id: x, type: "email", required: !0, placeholder: "输入邮箱地址", value: d, disabled: m, onChange: (C) => p(C.target.value) }),
        /* @__PURE__ */ e(ke, { label: "邀请权限", value: h, disabled: m, onChange: f, options: n }),
        /* @__PURE__ */ o("button", { type: "submit", disabled: m || !d.trim() || !h, children: [
          /* @__PURE__ */ e(fo, { size: 15, "aria-hidden": "true" }),
          m ? "正在邀请…" : "邀请"
        ] })
      ] }),
      n.find((C) => C.value === h)?.description && /* @__PURE__ */ e("p", { className: "fp-access-help", children: n.find((C) => C.value === h)?.description }),
      g && /* @__PURE__ */ e("p", { className: "fp-access-help", role: "status", children: g })
    ] }),
    (u || w) && /* @__PURE__ */ e("p", { className: "fp-error-text", role: "alert", children: u || w })
  ] });
}
function Qu({ onSearch: t, onPick: n, disabled: r, excludedIds: a = [], debounceMs: i = 250, onQueryChange: l }) {
  const [s, c] = k("user"), [u, d] = k(""), [p, h] = k([]), [f, m] = k(!1), [b, g] = k(0), [y, w] = k("idle"), [v, N] = k(""), x = B(null), C = B(null), I = B(null), L = B(t);
  L.current = t;
  const K = _n(), S = Ut(C, f), A = ve(), [D, U] = k({ left: 8, top: 8, width: 300, maxHeight: 280 }), j = p.filter((M) => !a.includes(M.id));
  Y(() => {
    f && I.current?.querySelector(`[id="${A}-${b}"]`)?.scrollIntoView?.({ block: "nearest" });
  }, [b, f, A]), Y(() => {
    const M = new AbortController();
    if (h([]), g(0), N(""), !u.trim() || r) {
      w("idle");
      return;
    }
    w("loading");
    const R = setTimeout(async () => {
      try {
        const q = await L.current(u.trim(), s, M.signal);
        M.signal.aborted || (h(q), w("ready"));
      } catch {
        M.signal.aborted || (N("暂时无法查找成员，请重试"), w("error"));
      }
    }, i);
    return () => {
      clearTimeout(R), M.abort();
    };
  }, [u, s, r, i]), Ce(() => {
    if (!f) return;
    const M = () => {
      const q = C.current?.getBoundingClientRect();
      if (!q) return;
      const F = window.innerHeight - q.bottom - 16, E = Math.min(280, Math.max(100, F < 160 ? q.top - 16 : F));
      U({ left: Math.max(8, Math.min(q.left, window.innerWidth - q.width - 8)), top: F < 160 ? Math.max(8, q.top - E - 6) : q.bottom + 6, width: Math.min(q.width, window.innerWidth - 16), maxHeight: E });
    }, R = (q) => {
      const F = q.target;
      !x.current?.contains(F) && !I.current?.contains(F) && m(!1);
    };
    return M(), document.addEventListener("pointerdown", R, !0), document.addEventListener("focusin", R, !0), window.addEventListener("resize", M), window.addEventListener("scroll", M, !0), () => {
      document.removeEventListener("pointerdown", R, !0), document.removeEventListener("focusin", R, !0), window.removeEventListener("resize", M), window.removeEventListener("scroll", M, !0);
    };
  }, [f]);
  const T = (M) => {
    M.disabled || (n(M, s), d(""), m(!1), C.current?.focus());
  };
  return /* @__PURE__ */ o("div", { className: "fp-member-search", ref: x, children: [
    /* @__PURE__ */ e("div", { className: "fp-member-search-kind", "aria-label": "搜索范围", children: ["user", "group"].map((M) => /* @__PURE__ */ o("button", { type: "button", disabled: r, "aria-pressed": s === M, onClick: () => {
      l?.("", M), c(M), d(""), m(!1), C.current?.focus();
    }, children: [
      s === M && /* @__PURE__ */ e(Wn.span, { className: "fp-choice-highlight", layoutId: `${A}-kind`, transition: { duration: K ? 0 : 0.18, ease: [0.2, 0, 0, 1] }, "aria-hidden": "true" }),
      M === "user" ? /* @__PURE__ */ e(mo, { size: 14 }) : /* @__PURE__ */ e(mr, { size: 14 }),
      /* @__PURE__ */ e("span", { children: M === "user" ? "用户" : "用户组" })
    ] }, M)) }),
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(We, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { ref: C, role: "combobox", "aria-label": "搜索成员", "aria-autocomplete": "list", "aria-expanded": f && !!u.trim(), "aria-controls": f && u.trim() ? A : void 0, "aria-activedescendant": f && j[b] ? `${A}-${b}` : void 0, disabled: r, placeholder: s === "user" ? "搜索姓名、账号或邮箱" : "搜索用户组名称", value: u, onFocus: () => m(!0), onChange: (M) => {
        l?.(M.target.value, s), d(M.target.value), m(!0);
      }, onKeyDown: (M) => {
        if (!M.nativeEvent.isComposing && (M.key === "Escape" && (M.preventDefault(), M.stopPropagation(), m(!1)), (M.key === "ArrowDown" || M.key === "ArrowUp") && (M.preventDefault(), m(!0), g((R) => {
          const q = M.key === "ArrowDown" ? 1 : -1;
          let F = R + q;
          for (; F >= 0 && F < j.length && j[F].disabled; ) F += q;
          return F >= 0 && F < j.length ? F : R;
        })), M.key === "Enter" && f)) {
          M.preventDefault();
          const R = j[b];
          R && T(R);
        }
      } }),
      y === "loading" && /* @__PURE__ */ e(Rt, { size: 15, className: "fp-spin", "aria-hidden": "true" })
    ] }),
    f && !r && u.trim() && De(/* @__PURE__ */ o("div", { ref: I, "data-fp-overlay": "", className: "fp-member-results fp-popup-panel", id: A, role: "listbox", "aria-label": "匹配成员", style: { ...S, position: "fixed", ...D, overflowY: "auto" }, children: [
      y === "loading" && /* @__PURE__ */ e("p", { role: "status", children: "正在查找…" }),
      y === "error" && /* @__PURE__ */ e("p", { role: "alert", children: v }),
      y === "ready" && !j.length && /* @__PURE__ */ e("p", { role: "status", children: "没有可添加的匹配成员" }),
      j.map((M, R) => /* @__PURE__ */ o("button", { type: "button", role: "option", "aria-selected": R === b, id: `${A}-${R}`, disabled: M.disabled, onMouseEnter: () => g(R), onMouseDown: (q) => q.preventDefault(), onClick: () => T(M), children: [
        /* @__PURE__ */ e("span", { className: "fp-member-result-avatar", "aria-hidden": "true", children: M.avatarUrl ? /* @__PURE__ */ e("img", { src: M.avatarUrl, alt: "" }) : M.name.slice(0, 1) }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: M.name }),
          M.detail && /* @__PURE__ */ e("small", { children: M.detail })
        ] }),
        /* @__PURE__ */ e("span", { className: "fp-member-result-action", children: "添加" })
      ] }, M.id))
    ] }), C.current?.closest("[data-fp-overlay],[role=dialog],dialog") || document.body)
  ] });
}
function Zu({ url: t, enabled: n, onEnabledChange: r, access: a, onAccessChange: i, options: l = [{ value: "read", label: "可以阅读" }, { value: "edit", label: "可以编辑" }], disabled: s, onCopy: c }) {
  const [u, d] = k(!1), [p, h] = k(!1), [f, m] = k(""), b = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-link", "aria-label": "链接分享", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e(gt, { size: 17 }),
        /* @__PURE__ */ e("strong", { children: "链接分享" })
      ] }),
      /* @__PURE__ */ e("button", { type: "button", role: "switch", "aria-checked": n, "aria-label": "开启链接分享", disabled: s || u, onClick: async () => {
        if (!b.current) {
          b.current = !0, d(!0), m("");
          try {
            await r(!n);
          } catch {
            m("分享设置未能保存，请重试");
          } finally {
            b.current = !1, d(!1);
          }
        }
      }, children: /* @__PURE__ */ e("span", { className: `fp-switch ${n ? "is-on" : ""}`, children: /* @__PURE__ */ e("i", {}) }) })
    ] }),
    /* @__PURE__ */ e("p", { children: n ? "拥有链接的人可以按以下权限访问。" : "开启后可通过链接邀请他人访问。" }),
    /* @__PURE__ */ e(Re, { isOpen: n, children: /* @__PURE__ */ o("div", { className: "fp-share-link-controls", children: [
      /* @__PURE__ */ e(ke, { label: "链接访问权限", value: a, onChange: i, options: l, disabled: s || u }),
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-secondary fp-sm", disabled: s || !t, onClick: async () => {
        if (t)
          try {
            c ? await c(t) : await navigator.clipboard.writeText(t), h(!0), m("");
          } catch {
            m("未能复制链接，请重试");
          }
      }, children: [
        p ? /* @__PURE__ */ e(Pe, { size: 14 }) : /* @__PURE__ */ e(Kn, { size: 14 }),
        "复制链接"
      ] })
    ] }) }),
    p && /* @__PURE__ */ e("span", { role: "status", className: "fp-sr-only", children: "链接已复制" }),
    f && /* @__PURE__ */ e("p", { role: "alert", children: f })
  ] });
}
function am({ items: t, selectedIds: n, onChange: r, onConfirm: a, loading: i, error: l, onSearch: s, onLoadMore: c, hasMore: u }) {
  const [d, p] = k(""), [h, f] = k(!1), [m, b] = k(""), g = B(!1), y = s ? t : t.filter((w) => w.name.toLowerCase().includes(d.trim().toLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-attachment-picker", "aria-label": "选择资料", children: [
    /* @__PURE__ */ o("div", { className: "fp-member-search-input", children: [
      /* @__PURE__ */ e(We, { size: 16 }),
      /* @__PURE__ */ e("input", { "aria-label": "搜索资料", placeholder: "搜索资料名称", value: d, onChange: (w) => {
        p(w.target.value), s?.(w.target.value);
      } })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-attachment-picker-list", "aria-busy": i, children: [
      y.map((w) => /* @__PURE__ */ o("button", { type: "button", role: "checkbox", "aria-checked": n.includes(w.id), disabled: w.disabled || h, onClick: () => r(n.includes(w.id) ? n.filter((v) => v !== w.id) : [...n, w.id]), children: [
        /* @__PURE__ */ e("span", { className: "fp-picker-check", children: n.includes(w.id) && /* @__PURE__ */ e(Pe, { size: 13 }) }),
        /* @__PURE__ */ e(Qe, { size: 18 }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("strong", { children: w.name }),
          w.detail && /* @__PURE__ */ e("small", { children: w.detail })
        ] })
      ] }, w.id)),
      i && /* @__PURE__ */ e("p", { role: "status", children: "正在查找资料…" }),
      !i && !y.length && /* @__PURE__ */ e("p", { children: "没有匹配的资料" }),
      u && c && /* @__PURE__ */ e("button", { type: "button", className: "fp-picker-load", disabled: i || h, onClick: c, children: "加载更多" })
    ] }),
    (l || m) && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: l || m }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ o("span", { children: [
        "已选择 ",
        n.length,
        " 项资料"
      ] }),
      /* @__PURE__ */ e("button", { type: "button", className: "fp-button fp-primary fp-sm", disabled: h || !n.length, onClick: async () => {
        if (!g.current) {
          g.current = !0, f(!0), b("");
          try {
            await a(n);
          } catch {
            b("未能添加资料，请重试");
          } finally {
            g.current = !1, f(!1);
          }
        }
      }, children: h ? "正在添加…" : "添加资料" })
    ] })
  ] });
}
function im({ tasks: t, onCancel: n, onRetry: r, onDismiss: a }) {
  return /* @__PURE__ */ e("section", { className: "fp-upload-queue", "aria-label": "上传资料", children: t.length ? /* @__PURE__ */ e("ul", { children: t.map((i) => /* @__PURE__ */ o("li", { "data-status": i.status, children: [
    /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: i.status === "done" ? /* @__PURE__ */ e(Pe, { size: 17 }) : /* @__PURE__ */ e(Qe, { size: 17 }) }),
    /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
      /* @__PURE__ */ e("strong", { children: i.name }),
      /* @__PURE__ */ e("span", { children: i.status === "error" ? i.error || "上传失败，请重试" : i.status === "done" ? "已添加" : i.status === "processing" ? "正在整理资料" : i.status === "waiting" ? "等待上传" : `正在上传 ${Math.round(Math.max(0, Math.min(100, i.progress || 0)))}%` }),
      i.status === "uploading" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${i.name}上传进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(Math.max(0, Math.min(100, i.progress || 0))), className: "fp-upload-progress", children: /* @__PURE__ */ e("i", { style: { width: `${Math.max(0, Math.min(100, i.progress || 0))}%` } }) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
      i.status === "error" && r && /* @__PURE__ */ e("button", { type: "button", "aria-label": `重试${i.name}`, onClick: () => r(i.id), children: /* @__PURE__ */ e(li, { size: 15 }) }),
      ["waiting", "uploading", "processing"].includes(i.status) && n && /* @__PURE__ */ e("button", { type: "button", "aria-label": `取消上传${i.name}`, onClick: () => n(i.id), children: /* @__PURE__ */ e(ge, { size: 15 }) }),
      ["done", "error"].includes(i.status) && a && /* @__PURE__ */ e("button", { type: "button", "aria-label": `移除记录${i.name}`, onClick: () => a(i.id), children: /* @__PURE__ */ e(ge, { size: 15 }) })
    ] })
  ] }, i.id)) }) : /* @__PURE__ */ e("p", { className: "fp-muted", children: "还没有上传任务" }) });
}
function lm({ editor: t, toolbar: n, children: r, className: a = "", contextMenu: i = !0 }) {
  const l = /* @__PURE__ */ e(pi, { editor: t });
  return /* @__PURE__ */ o("section", { className: `fp-markdown-editor fp-markdown-editor-surface ${a}`, "data-readonly": t && !t.isEditable || void 0, children: [
    n,
    i ? /* @__PURE__ */ e(Xi, { editor: t, children: l }) : l,
    r
  ] });
}
function om({ className: t = "", ...n }) {
  return /* @__PURE__ */ e("div", { ...n, className: `fp-conversation-viewport ${t}` });
}
const ep = {
  pending: /* @__PURE__ */ e(oi, { size: 14 }),
  running: /* @__PURE__ */ e(bo, { size: 14, className: "fp-spin" }),
  done: /* @__PURE__ */ e(Pe, { size: 14 }),
  error: /* @__PURE__ */ e(Fr, { size: 14 })
};
function sm({
  steps: t,
  streaming: n = !1,
  durationMs: r,
  defaultOpen: a = !0,
  title: i = "思考过程"
}) {
  const [l, s] = k(a || n), c = t.filter((d) => d.status === "done").length, u = t.some((d) => d.status === "error");
  return /* @__PURE__ */ o(
    "section",
    {
      className: "fp-trace",
      "data-streaming": n || void 0,
      "aria-label": i,
      children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-trace-head",
            "aria-expanded": l,
            onClick: () => s((d) => !d),
            children: [
              /* @__PURE__ */ e(ze, { size: 15, className: "fp-trace-chevron" }),
              /* @__PURE__ */ e("strong", { children: i }),
              /* @__PURE__ */ o("span", { className: "fp-trace-summary", children: [
                u ? "有步骤失败" : n ? "进行中" : `${c} / ${t.length} 步`,
                r ? ` · ${(r / 1e3).toFixed(1)}s` : ""
              ] })
            ]
          }
        ),
        /* @__PURE__ */ e("div", { className: "fp-trace-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("ol", { className: "fp-trace-steps", children: t.map((d) => /* @__PURE__ */ o("li", { "data-status": d.status, children: [
          /* @__PURE__ */ e("span", { className: "fp-trace-icon", "aria-hidden": "true", children: ep[d.status] }),
          /* @__PURE__ */ o("div", { className: "fp-trace-content", children: [
            /* @__PURE__ */ o("div", { className: "fp-trace-title", children: [
              d.title,
              d.meta && /* @__PURE__ */ e("span", { className: "fp-trace-meta", children: d.meta })
            ] }),
            d.detail && /* @__PURE__ */ e("p", { className: "fp-trace-detail fp-trace-commentary", children: d.detail })
          ] })
        ] }, d.id)) }) })
      ]
    }
  );
}
const tp = {
  excerpt: ["摘录 · 原文", "回顾 · 要点"],
  cloze: ["填空 · 回忆内容", "答案"],
  quiz: ["题目 · 先思考", "参考答案"],
  custom: ["正面", "背面"],
  qa: ["问题", "答案"]
};
function cm({
  kind: t = "qa",
  front: n,
  back: r,
  flipped: a,
  onFlip: i,
  explanation: l,
  className: s
}) {
  const c = ve(), [u, d] = tp[t];
  return /* @__PURE__ */ o("div", { className: `fp-flip ${s || ""}`, "data-flipped": a || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-flip-stage",
        onClick: i,
        "aria-pressed": a,
        "aria-describedby": c,
        "aria-label": a ? "翻回正面" : "翻开背面",
        children: [
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-front", "aria-hidden": a, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: u }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: n }),
            /* @__PURE__ */ e("span", { className: "fp-flip-hint", children: "点击翻面" })
          ] }),
          /* @__PURE__ */ o("div", { className: "fp-flip-face fp-flip-back", "aria-hidden": !a, children: [
            /* @__PURE__ */ e("span", { className: "fp-flip-label", children: d }),
            /* @__PURE__ */ e("div", { className: "fp-flip-content", children: r }),
            l && /* @__PURE__ */ e("p", { className: "fp-flip-explanation", children: l })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ o("span", { id: c, className: "fp-sr-only", children: [
      "按下空格或回车翻面，当前显示",
      a ? d : u,
      "。"
    ] })
  ] });
}
function dm({
  anchor: t,
  actions: n,
  onClose: r,
  preview: a
}) {
  const i = B(null), [l, s] = k(null);
  return Ce(() => {
    if (!t || !i.current) {
      s(null);
      return;
    }
    const c = i.current.getBoundingClientRect(), u = Math.max(
      8,
      Math.min(t.x - c.width / 2, window.innerWidth - c.width - 8)
    ), d = t.y - c.height - 8, p = d > 8 ? d : t.y + 12;
    s({ left: u, top: p });
  }, [t]), Y(() => {
    if (!t) return;
    const c = (d) => {
      d.key === "Escape" && r();
    }, u = (d) => {
      i.current?.contains(d.target) || r();
    };
    return document.addEventListener("keydown", c), document.addEventListener("pointerdown", u, !0), () => {
      document.removeEventListener("keydown", c), document.removeEventListener("pointerdown", u, !0);
    };
  }, [t, r]), !t || typeof window > "u" ? null : De(
    /* @__PURE__ */ o(
      "div",
      {
        ref: i,
        className: "fp-selection-toolbar",
        role: "toolbar",
        "aria-label": "选区操作",
        style: {
          left: l?.left ?? t.x,
          top: l?.top ?? t.y - 44,
          visibility: l ? "visible" : "hidden"
        },
        children: [
          a && /* @__PURE__ */ o("span", { className: "fp-selection-preview", title: a, children: [
            a.slice(0, 24),
            a.length > 24 ? "…" : ""
          ] }),
          n.map((c) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: "fp-selection-action",
              "data-danger": c.danger || void 0,
              onClick: () => {
                c.onClick(), r();
              },
              children: [
                c.icon,
                c.label
              ]
            },
            c.id
          ))
        ]
      }
    ),
    document.body
  );
}
function um({
  list: t,
  sync: n,
  resolve: r,
  intervalMs: a = 3e4,
  eventName: i = "fp-sync-change"
}) {
  const [l, s] = k([]), [c, u] = k(""), [d, p] = k(!1), h = xe(() => {
    t().then((b) => {
      s(b), u("");
    }).catch(() => u("暂时无法同步，内容仍保存在此设备"));
  }, [t]), f = xe(() => {
    n().then(h).catch(() => u("暂时无法同步，稍后将重试"));
  }, [n, h]);
  if (Y(() => {
    h(), f();
    const b = () => h(), g = () => f();
    window.addEventListener(i, b), window.addEventListener("online", g);
    const y = a > 0 ? setInterval(f, a) : void 0;
    return () => {
      y && clearInterval(y), window.removeEventListener(i, b), window.removeEventListener("online", g);
    };
  }, [h, f, a, i]), Y(() => {
    p(!1);
  }, [l.length]), !l.length || d) return null;
  const m = l.some((b) => b.conflict);
  return /* @__PURE__ */ o(
    "aside",
    {
      className: "fp-sync-status",
      "data-conflict": m || void 0,
      role: "status",
      "aria-live": "polite",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-sync-icon", "aria-hidden": "true", children: m ? /* @__PURE__ */ e(go, { size: 16 }) : /* @__PURE__ */ e(vo, { size: 16 }) }),
        /* @__PURE__ */ o("div", { className: "fp-sync-body", children: [
          /* @__PURE__ */ e("strong", { children: m ? "部分内容在其他设备上有更新" : "正在同步学习记录" }),
          /* @__PURE__ */ e("span", { children: m ? "选择要保留的版本，冲突解决后会继续同步。" : "未完成的内容已保存在本机。" }),
          l.filter((b) => b.conflict).map((b, g) => /* @__PURE__ */ o("div", { className: "fp-sync-actions", children: [
            /* @__PURE__ */ o("span", { className: "fp-sync-key", children: [
              "记录 ",
              g + 1
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !0).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "保留此设备版本"
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                onClick: () => r(b.key, !1).catch(
                  () => u("同步失败，请稍后重试")
                ),
                children: "采用云端版本"
              }
            )
          ] }, b.key)),
          c && /* @__PURE__ */ o("p", { className: "fp-sync-error", role: "alert", children: [
            /* @__PURE__ */ e(yo, { size: 13 }),
            " ",
            c
          ] })
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-sync-close",
            "aria-label": "收起同步提示",
            onClick: () => p(!0),
            children: /* @__PURE__ */ e(ge, { size: 14 })
          }
        )
      ]
    }
  );
}
function np(t) {
  return !t || t <= 0 ? "" : t >= 1e6 ? `${+(t / 1e6).toFixed(1)}M` : t >= 1e3 ? `${+(t / 1e3).toFixed(1)}K` : `${t}`;
}
function rp({
  value: t,
  onChange: n,
  groups: r,
  disabled: a,
  label: i = "选择模型"
}) {
  const l = r.flatMap((s) => s.models).find((s) => s.id === t);
  return /* @__PURE__ */ e("span", { className: "fp-model-selector", children: /* @__PURE__ */ e(
    et,
    {
      label: i,
      role: "listbox",
      disabled: a || !r.some((s) => s.models.length),
      className: "fp-model-selector-panel",
      trigger: /* @__PURE__ */ o(Q, { children: [
        l?.icon || /* @__PURE__ */ e(No, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l?.label || t || "选择模型" }),
        /* @__PURE__ */ e(qt, { size: 14, "aria-hidden": "true" })
      ] }),
      children: (s) => r.filter((c) => c.models.length).map((c) => /* @__PURE__ */ o(
        "div",
        {
          role: "group",
          "aria-label": c.name,
          className: "fp-model-group",
          children: [
            /* @__PURE__ */ e("div", { className: "fp-model-group-label", children: c.name }),
            c.models.map((u) => /* @__PURE__ */ o(
              "button",
              {
                type: "button",
                role: "option",
                "aria-selected": u.id === t,
                disabled: u.disabled,
                tabIndex: -1,
                className: "fp-model-item",
                onClick: () => {
                  s(), n(u.id);
                },
                children: [
                  /* @__PURE__ */ o("span", { className: "fp-model-item-copy", children: [
                    /* @__PURE__ */ o("span", { className: "fp-model-item-main", children: [
                      /* @__PURE__ */ o("span", { className: "fp-model-item-label", children: [
                        u.icon,
                        u.label
                      ] }),
                      /* @__PURE__ */ e("span", { className: "fp-model-item-context", children: np(u.contextWindow) })
                    ] }),
                    u.description && /* @__PURE__ */ e("span", { className: "fp-model-item-description", children: u.description }),
                    (u.supportsThinking || u.supportsVision || u.supportsTools) && /* @__PURE__ */ o("span", { className: "fp-model-capabilities", children: [
                      u.supportsThinking && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(wo, { size: 12, "aria-hidden": "true" }),
                        "推理"
                      ] }),
                      u.supportsVision && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(ai, { size: 12, "aria-hidden": "true" }),
                        "视觉"
                      ] }),
                      u.supportsTools && /* @__PURE__ */ o("span", { children: [
                        /* @__PURE__ */ e(ko, { size: 12, "aria-hidden": "true" }),
                        "工具"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ e(
                    Pe,
                    {
                      size: 16,
                      className: "fp-model-item-check",
                      "aria-hidden": "true",
                      style: {
                        visibility: u.id === t ? "visible" : "hidden"
                      }
                    }
                  )
                ]
              },
              u.id
            ))
          ]
        },
        c.name
      ))
    }
  ) });
}
function ap({
  balance: t,
  enabled: n = !0,
  isLoading: r = !1,
  onClick: a,
  label: i
}) {
  const l = i || (n ? t !== void 0 ? `${(t / 1e3).toLocaleString(void 0, { maximumFractionDigits: 3 })} 积分` : "积分" : "免费体验");
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-token-dashboard",
      onClick: a,
      disabled: r,
      "aria-label": "查看积分与会员",
      children: [
        /* @__PURE__ */ e(xo, { size: 16, "aria-hidden": "true" }),
        /* @__PURE__ */ e("span", { children: l })
      ]
    }
  );
}
function pm({
  apiEndpoint: t = "/api/me/credits",
  onClick: n
}) {
  const [r, a] = k(), [i, l] = k(!0), [s, c] = k(!0);
  return Y(() => {
    let u = !0;
    return fetch(t).then((d) => {
      if (!d.ok) throw new Error();
      return d.json();
    }).then((d) => {
      u && (a(d.wallet.balance), l(d.config.enabled), c(!1));
    }).catch(() => {
      u && c(!1);
    }), () => {
      u = !1;
    };
  }, [t]), /* @__PURE__ */ e(
    ap,
    {
      balance: r,
      enabled: i,
      isLoading: s,
      onClick: n
    }
  );
}
function hm({
  label: t,
  children: n,
  defaultOpen: r = !1,
  meta: a,
  className: i
}) {
  const [l, s] = k(r), c = ve();
  return /* @__PURE__ */ o("div", { className: `fp-collapsible ${i || ""}`, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-collapsible-head",
        "aria-expanded": l,
        "aria-controls": c,
        onClick: () => s((u) => !u),
        children: [
          /* @__PURE__ */ e(ze, { size: 14, className: "fp-collapsible-chevron" }),
          /* @__PURE__ */ e("span", { className: "fp-collapsible-label", children: t }),
          a != null && /* @__PURE__ */ e("span", { className: "fp-collapsible-meta", children: a })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { id: c, className: "fp-collapsible-body", inert: !l, "aria-hidden": !l, "data-open": l || void 0, children: /* @__PURE__ */ e("div", { className: "fp-collapsible-inner", children: n }) })
  ] });
}
function fm({
  items: t,
  onRemove: n,
  onOpen: r,
  size: a = 64
}) {
  return t.length ? /* @__PURE__ */ e("ul", { className: "fp-attachment-grid", "aria-label": "图片附件", children: t.map((i) => /* @__PURE__ */ o("li", { className: "fp-attachment", style: { width: a }, children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-thumb",
        style: { width: a, height: a },
        onClick: () => r?.(i),
        disabled: !r,
        "aria-label": i.name ? `查看 ${i.name}` : "查看附件",
        children: i.src ? /* @__PURE__ */ e("img", { src: i.src, alt: i.name || "" }) : /* @__PURE__ */ e("span", { className: "fp-attachment-placeholder", "aria-hidden": "true" })
      }
    ),
    n && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-attachment-remove",
        "aria-label": `移除${i.name || "附件"}`,
        onClick: () => n(i.id),
        children: /* @__PURE__ */ e(ge, { size: 12 })
      }
    )
  ] }, i.id)) }) : null;
}
const ip = {
  basic: "基础",
  medium: "中等",
  hard: "提高"
}, lp = "ABCDEFGHIJ";
function mm({
  index: t,
  total: n,
  kind: r = "单项选择",
  difficulty: a = "basic",
  prompt: i,
  options: l,
  selected: s,
  onSelect: c,
  mode: u = "answer",
  explanation: d,
  hint: p
}) {
  const h = Array.isArray(s) ? s : s ? [s] : [];
  return /* @__PURE__ */ o("article", { className: "fp-quiz", "data-mode": u, children: [
    /* @__PURE__ */ o("header", { className: "fp-quiz-meta", children: [
      /* @__PURE__ */ o("strong", { children: [
        "第 ",
        t + 1,
        " / ",
        n,
        " 题"
      ] }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: r }),
      /* @__PURE__ */ e("span", { className: "fp-quiz-chip", children: ip[a] })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-quiz-prompt", children: i }),
    /* @__PURE__ */ e("ol", { className: "fp-quiz-options", children: l.map((f, m) => {
      const b = h.includes(f.id), g = u === "review" && f.correct, y = u === "review" && b && !f.correct;
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-quiz-option",
          "data-selected": b || void 0,
          "data-correct": g || void 0,
          "data-wrong": y || void 0,
          "aria-pressed": b,
          disabled: u === "review" || !c,
          onClick: () => c?.(f.id),
          children: [
            /* @__PURE__ */ e("span", { className: "fp-quiz-letter", children: lp[m] }),
            /* @__PURE__ */ e("span", { className: "fp-quiz-text", children: f.text }),
            g && /* @__PURE__ */ e(Pe, { size: 16, "aria-label": "正确答案" }),
            y && /* @__PURE__ */ e(ge, { size: 16, "aria-label": "选择错误" })
          ]
        }
      ) }, f.id);
    }) }),
    u === "review" && d && /* @__PURE__ */ o("div", { className: "fp-quiz-explanation", children: [
      /* @__PURE__ */ e(da, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: d })
    ] }),
    p && /* @__PURE__ */ o("div", { className: "fp-quiz-hint", children: [
      /* @__PURE__ */ e(da, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: p })
    ] })
  ] });
}
function bm({
  url: t,
  reason: n,
  onForce: r,
  title: a = "无法内嵌该页面",
  actionLabel: i = "打开原页面"
}) {
  let l = t;
  try {
    l = new URL(t).host;
  } catch {
  }
  return /* @__PURE__ */ o("div", { className: "fp-embed-fallback", children: [
    /* @__PURE__ */ e("span", { className: "fp-embed-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(Co, { size: 26 }) }),
    /* @__PURE__ */ e("strong", { children: a }),
    /* @__PURE__ */ o("p", { children: [
      /* @__PURE__ */ e("span", { className: "fp-embed-host", children: l }),
      " ",
      "拒绝在当前窗口中显示（安全策略或访问受限）。请到原网站查看，以保留完整功能。"
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-embed-reason", children: n }),
    /* @__PURE__ */ o(
      "a",
      {
        className: "fp-button fp-primary",
        href: t,
        target: "_blank",
        rel: "noopener noreferrer",
        children: [
          /* @__PURE__ */ e(Kt, { size: 15, "aria-hidden": "true" }),
          i
        ]
      }
    ),
    r && /* @__PURE__ */ e("button", { type: "button", className: "fp-embed-force", onClick: r, children: "仍要尝试内嵌（可能显示空白）" })
  ] });
}
function op({ src: t, alt: n = "", onClose: r }) {
  const [a, i] = k(1), [l, s] = k({ x: 0, y: 0 }), [c, u] = k(!1), d = B({ x: 0, y: 0 }), p = B({ x: 0, y: 0 });
  Y(() => {
    if (!t) return;
    i(1), s({ x: 0, y: 0 });
    const f = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const m = (b) => {
      b.key === "Escape" && r(), (b.key === "+" || b.key === "=") && i((g) => Math.min(5, g * 1.2)), b.key === "-" && i((g) => Math.max(0.25, g / 1.2)), b.key === "0" && (i(1), s({ x: 0, y: 0 }));
    };
    return document.addEventListener("keydown", m), () => {
      document.body.style.overflow = f, document.removeEventListener("keydown", m);
    };
  }, [t, r]);
  const h = xe(() => {
    i(1), s({ x: 0, y: 0 });
  }, []);
  return !t || typeof window > "u" ? null : De(
    /* @__PURE__ */ o(
      "div",
      {
        className: "fp-lightbox",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": n || "图片预览",
        onWheel: (f) => {
          !f.ctrlKey && !f.metaKey || (f.preventDefault(), i((m) => Math.max(0.25, Math.min(5, m * (f.deltaY > 0 ? 0.9 : 1.1)))));
        },
        children: [
          /* @__PURE__ */ o("div", { className: "fp-lightbox-bar", children: [
            /* @__PURE__ */ o("span", { className: "fp-lightbox-zoom", children: [
              Math.round(a * 100),
              "%"
            ] }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "缩小",
                onClick: () => i((f) => Math.max(0.25, f / 1.2)),
                children: /* @__PURE__ */ e(Ir, { size: 17 })
              }
            ),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                "aria-label": "放大",
                onClick: () => i((f) => Math.min(5, f * 1.2)),
                children: /* @__PURE__ */ e(Ar, { size: 17 })
              }
            ),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "复位", onClick: h, children: /* @__PURE__ */ e(Je, { size: 17 }) }),
            /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭", onClick: r, children: /* @__PURE__ */ e(ge, { size: 18 }) })
          ] }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "fp-lightbox-stage",
              "data-dragging": c || void 0,
              onDoubleClick: () => a > 1 ? h() : i(2),
              onPointerDown: (f) => {
                f.button !== 0 || a <= 1 || (u(!0), d.current = { x: f.clientX, y: f.clientY }, p.current = { ...l }, f.currentTarget.setPointerCapture(f.pointerId));
              },
              onPointerMove: (f) => {
                c && s({
                  x: p.current.x + f.clientX - d.current.x,
                  y: p.current.y + f.clientY - d.current.y
                });
              },
              onPointerUp: () => u(!1),
              onPointerCancel: () => u(!1),
              children: /* @__PURE__ */ e(
                "img",
                {
                  src: t,
                  alt: n,
                  draggable: !1,
                  style: {
                    transform: `translate(${l.x}px, ${l.y}px) scale(${a})`,
                    transition: c ? "none" : "transform 160ms var(--fp-ease)"
                  }
                }
              )
            }
          ),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              className: "fp-lightbox-scrim",
              "aria-label": "关闭预览",
              onClick: r
            }
          )
        ]
      }
    ),
    document.body
  );
}
function gm({
  title: t,
  icon: n,
  summary: r,
  children: a,
  open: i,
  onToggle: l
}) {
  return /* @__PURE__ */ o("section", { className: "fp-settings-section", "data-open": i || void 0, children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-settings-head",
        "aria-expanded": i,
        "aria-label": t,
        onClick: l,
        children: [
          /* @__PURE__ */ e("span", { className: "fp-settings-icon", "aria-hidden": "true", children: n }),
          /* @__PURE__ */ o("span", { className: "fp-settings-titles", children: [
            /* @__PURE__ */ e("strong", { children: t }),
            r && /* @__PURE__ */ e("small", { children: r })
          ] }),
          /* @__PURE__ */ e(qt, { size: 16, className: "fp-settings-chevron" })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-settings-body", inert: !i, "aria-hidden": !i, children: /* @__PURE__ */ e("div", { className: "fp-settings-inner", children: a }) })
  ] });
}
function vm({
  subjectName: t = "学习",
  topic: n,
  prompts: r = [],
  onPrompt: a,
  icon: i,
  title: l,
  description: s
}) {
  return /* @__PURE__ */ o("div", { className: "fp-chat-empty", children: [
    /* @__PURE__ */ e("span", { className: "fp-chat-empty-icon", "aria-hidden": "true", children: i || /* @__PURE__ */ e(xn, { size: 22 }) }),
    /* @__PURE__ */ e("strong", { children: l || `我是你的${t}助教` }),
    /* @__PURE__ */ e("p", { children: s || "遇到不懂的概念随时问我，我可以解释公式、出题练习，或者帮你梳理知识点。" }),
    n && /* @__PURE__ */ o("span", { className: "fp-chat-empty-topic", children: [
      "当前学习 · ",
      n
    ] }),
    r.length > 0 && /* @__PURE__ */ o("div", { className: "fp-chat-prompts", children: [
      /* @__PURE__ */ e("span", { className: "fp-chat-prompts-label", children: "试试这样问我" }),
      r.map((c) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-chat-prompt",
          onClick: () => a?.(c),
          children: c
        },
        c
      ))
    ] })
  ] });
}
function _a(t) {
  try {
    return new URL(t).hostname.replace(/^www\./, "");
  } catch {
    return t;
  }
}
function ym({
  sources: t,
  label: n = "联网来源",
  cached: r,
  onOpen: a
}) {
  const [i, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-source-fold", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-head",
        "aria-expanded": i,
        onClick: () => l((s) => !s),
        children: [
          /* @__PURE__ */ e(ze, { size: 14, className: "fp-source-chevron" }),
          /* @__PURE__ */ e(So, { size: 15, "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { children: [
            n,
            " · ",
            t.length,
            " 条",
            r ? " · 缓存" : ""
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "fp-source-body", inert: !i, "aria-hidden": !i, "data-open": i || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-source-list", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-source-item",
        onClick: () => a?.(s),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-source-index", children: c + 1 }),
          /* @__PURE__ */ e("span", { className: "fp-source-title", children: s.title || _a(s.url) }),
          /* @__PURE__ */ o("span", { className: "fp-source-host", children: [
            /* @__PURE__ */ e(gt, { size: 12, "aria-hidden": "true" }),
            _a(s.url)
          ] })
        ]
      }
    ) }, `${s.url}:${c}`)) }) })
  ] }) : null;
}
function wm({
  groups: t,
  activeId: n,
  onSelect: r,
  onCreate: a,
  onDelete: i,
  onClose: l
}) {
  const [s, c] = k(t[0]?.id), [u, d] = k(null), p = t.find((h) => h.id === s) || t[0];
  return /* @__PURE__ */ o("div", { className: "fp-session-history", children: [
    /* @__PURE__ */ o("header", { className: "fp-session-history-head", children: [
      /* @__PURE__ */ e(jn, { size: 16, "aria-hidden": "true" }),
      /* @__PURE__ */ e("strong", { children: "历史记录" }),
      l && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-icon-button fp-sm",
          "aria-label": "关闭历史记录",
          onClick: l,
          children: /* @__PURE__ */ e(ge, { size: 16 })
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { className: "fp-session-tabs", role: "tablist", "aria-label": "记录类型", children: t.map((h) => /* @__PURE__ */ o(
      "button",
      {
        role: "tab",
        type: "button",
        "aria-selected": h.id === p?.id,
        onClick: () => c(h.id),
        children: [
          h.label,
          /* @__PURE__ */ e("span", { children: h.items.length })
        ]
      },
      h.id
    )) }),
    a && p && /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-session-create",
        onClick: () => a(p.id),
        children: [
          /* @__PURE__ */ e(kn, { size: 15, "aria-hidden": "true" }),
          "新建",
          p.label.replace(/记录$/, "")
        ]
      }
    ),
    /* @__PURE__ */ o("ul", { className: "fp-session-list", children: [
      (p?.items || []).map((h) => /* @__PURE__ */ o("li", { "data-active": h.id === n || void 0, children: [
        /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-session-item",
            onClick: () => r(p.id, h.id),
            "aria-current": h.id === n || void 0,
            children: [
              /* @__PURE__ */ e(Mo, { size: 15, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { children: [
                /* @__PURE__ */ e("strong", { children: h.title }),
                h.detail && /* @__PURE__ */ e("small", { children: h.detail })
              ] }),
              h.time && /* @__PURE__ */ e("time", { children: h.time })
            ]
          }
        ),
        i && (u === h.id ? /* @__PURE__ */ o("span", { className: "fp-session-confirm", children: [
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                i(p.id, h.id), d(null);
              },
              children: "删除"
            }
          ),
          /* @__PURE__ */ e("button", { type: "button", onClick: () => d(null), children: "取消" })
        ] }) : /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            className: "fp-session-delete",
            "aria-label": `删除 ${h.title}`,
            onClick: () => d(h.id),
            children: /* @__PURE__ */ e(Ht, { size: 14 })
          }
        ))
      ] }, h.id)),
      !p?.items.length && /* @__PURE__ */ e("li", { className: "fp-session-empty", children: "还没有记录，开始第一次对话吧。" })
    ] })
  ] });
}
function km({ mode: t = "login", title: n = "账号登录", icon: r = /* @__PURE__ */ e(bt, { size: 18 }), onClose: a, onBrowser: i, onReload: l, children: s, className: c, browserPending: u = !1 }) {
  return /* @__PURE__ */ e(xd, { children: /* @__PURE__ */ e(
    pl,
    {
      native: !0,
      title: n,
      icon: r,
      closeLabel: t === "task" ? "关闭授权窗口" : "取消登录",
      closeShortcut: "Esc",
      onClose: a,
      className: c,
      actions: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ o(te, { variant: "ghost", onClick: i, "aria-label": t === "task" ? "在浏览器中继续" : "在浏览器中继续登录", "data-fp-tooltip-side": "left", children: [
          /* @__PURE__ */ e(Kt, { size: 16 }),
          t === "task" ? "浏览器继续" : "浏览器登录"
        ] }),
        /* @__PURE__ */ e(te, { variant: "ghost", disabled: u, "aria-label": t === "task" ? "刷新授权信息" : "重新加载登录页", "data-fp-tooltip-side": "left", style: { width: 44, padding: 0 }, onClick: l, children: /* @__PURE__ */ e(qn, { size: 16 }) })
      ] }),
      children: u ? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: "请在浏览器中完成登录，完成后会自动返回。" }) : s ?? /* @__PURE__ */ e("div", { role: "status", style: { padding: 24, color: "var(--fp-muted)" }, children: t === "task" ? "正在读取授权信息…" : "正在打开登录页…" })
    }
  ) });
}
function Nm({
  label: t = "筛选",
  value: n,
  onChange: r,
  options: a = [],
  groups: i = [],
  disabled: l,
  id: s
}) {
  const c = ve();
  return /* @__PURE__ */ o("div", { className: "fp-filter", children: [
    t && /* @__PURE__ */ e("span", { id: s || c, className: "fp-filter-label", children: t }),
    /* @__PURE__ */ e(ke, { label: t || "筛选", value: n, onChange: r, disabled: l, options: [...a, ...i.flatMap((d) => d.options.map((p) => ({ ...p, group: d.label })))] })
  ] });
}
function xm({
  years: t,
  value: n,
  onChange: r,
  compact: a = !1,
  termLabel: i = "学期"
}) {
  const l = t.find((u) => u.id === n), s = Array.from(new Set(t.map((u) => u.grade))), c = l ? t.filter((u) => u.grade === l.grade) : [];
  return /* @__PURE__ */ o("div", { className: "fp-academic", "data-compact": a || void 0, children: [
    /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": "年级", children: s.map((u) => {
      const d = t.find((h) => h.grade === u), p = l?.grade === u;
      return /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-academic-btn",
          "aria-pressed": p,
          onClick: () => r(d.id),
          children: u
        },
        u
      );
    }) }),
    c.length > 1 && /* @__PURE__ */ e("div", { className: "fp-academic-row", role: "group", "aria-label": i, children: c.map((u) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-academic-btn fp-academic-term",
        "aria-pressed": u.id === n,
        onClick: () => r(u.id),
        children: u.term
      },
      u.id
    )) })
  ] });
}
function Cm({
  hits: t,
  label: n = "引用笔记",
  onOpen: r,
  action: a
}) {
  const [i, l] = k(!1);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-citation-list", children: [
    /* @__PURE__ */ o("header", { className: "fp-citation-head", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-citation-toggle",
          "aria-expanded": i,
          onClick: () => l((s) => !s),
          children: [
            /* @__PURE__ */ e(ze, { size: 14, className: "fp-citation-chevron" }),
            /* @__PURE__ */ e(Qe, { size: 15, "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { children: [
              n,
              " · ",
              t.length,
              " 条"
            ] })
          ]
        }
      ),
      a && /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: "fp-citation-action",
          onClick: a.onClick,
          children: a.label
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-citation-body", "data-open": i || void 0, children: /* @__PURE__ */ e("ul", { className: "fp-citation-hits", children: t.map((s, c) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-citation-hit",
        onClick: () => r?.(s),
        children: [
          /* @__PURE__ */ e("strong", { children: s.title }),
          /* @__PURE__ */ e("span", { children: s.path }),
          s.snippet && /* @__PURE__ */ e("small", { children: s.snippet })
        ]
      }
    ) }, `${s.path}:${c}`)) }) })
  ] }) : null;
}
const sp = {
  idle: "等待确认",
  approved: "已批准",
  running: "生成中",
  done: "已完成",
  cancelled: "已取消",
  error: "失败"
};
function Sm({
  title: t = "AI 生图",
  prompt: n,
  details: r = [],
  cost: a,
  status: i = "idle",
  onApprove: l,
  onCancel: s,
  children: c
}) {
  const u = i === "idle";
  return /* @__PURE__ */ o("section", { className: "fp-approval", "data-status": i, children: [
    /* @__PURE__ */ o("header", { className: "fp-approval-head", children: [
      /* @__PURE__ */ e("span", { className: "fp-approval-icon", "aria-hidden": "true", children: /* @__PURE__ */ e(xn, { size: 16 }) }),
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("span", { className: "fp-approval-status", children: sp[i] })
    ] }),
    n && /* @__PURE__ */ e("p", { className: "fp-approval-prompt", children: n }),
    r.length > 0 && /* @__PURE__ */ e("dl", { className: "fp-approval-details", children: r.map((d) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: d.label }),
      /* @__PURE__ */ e("dd", { children: d.value })
    ] }, d.label)) }),
    a && /* @__PURE__ */ e("p", { className: "fp-approval-cost", children: a }),
    u ? /* @__PURE__ */ o("div", { className: "fp-approval-actions", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-button fp-primary", onClick: l, children: [
        /* @__PURE__ */ e(Pe, { size: 15, "aria-hidden": "true" }),
        "批准并继续"
      ] }),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary",
          onClick: s,
          children: [
            /* @__PURE__ */ e(ge, { size: 15, "aria-hidden": "true" }),
            "取消"
          ]
        }
      )
    ] }) : c
  ] });
}
function kl(t, n = 0) {
  return t.flatMap((r) => [
    { node: r, depth: n },
    ...kl(r.children || [], n + 1)
  ]);
}
function Mm({
  items: t,
  activeId: n,
  onSelect: r,
  label: a = "目录",
  empty: i = "这篇内容还没有小节标题。"
}) {
  const l = kl(t);
  return l.length ? /* @__PURE__ */ e("nav", { className: "fp-toc", "aria-label": a, children: l.map(({ node: s, depth: c }) => {
    const u = s.level ?? 1;
    return /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-toc-row",
        "data-level": u,
        "data-active": s.id === n || void 0,
        style: { paddingLeft: 8 + c * 16 },
        title: s.text,
        "aria-current": s.id === n ? "location" : void 0,
        onClick: () => {
          r?.(s.id), document.getElementById(s.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
        },
        children: [
          u === 1 ? /* @__PURE__ */ e(Qe, { size: 14, "aria-hidden": "true" }) : /* @__PURE__ */ e("span", { className: "fp-toc-dot", "aria-hidden": "true" }),
          /* @__PURE__ */ e("span", { children: s.text })
        ]
      },
      s.id
    );
  }) }) : /* @__PURE__ */ e("p", { className: "fp-toc-empty", children: i });
}
const cp = {
  done: ct,
  draft: Eo,
  stub: oi
};
function Em({
  items: t,
  activeId: n,
  onSelect: r,
  label: a = "同目录内容"
}) {
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-siblings", "aria-label": a, children: [
    /* @__PURE__ */ e("header", { className: "fp-siblings-label", children: a }),
    /* @__PURE__ */ e("ul", { className: "fp-siblings-list", children: t.map((i) => {
      const l = cp[i.status ?? "stub"];
      return /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-sibling",
          "data-status": i.status ?? "stub",
          "aria-current": i.id === n ? "page" : void 0,
          onClick: () => r(i),
          children: [
            /* @__PURE__ */ e(l, { size: 14, className: "fp-sibling-icon", "aria-hidden": "true" }),
            /* @__PURE__ */ o("span", { className: "fp-sibling-text", children: [
              i.title,
              i.detail && /* @__PURE__ */ e("small", { children: i.detail })
            ] })
          ]
        }
      ) }, i.id);
    }) })
  ] }) : null;
}
function $m({
  steps: t,
  interactive: n = !1,
  label: r = "推导步骤"
}) {
  const [a, i] = k(0);
  if (!t.length) return null;
  const l = n ? [t[a]] : t;
  return /* @__PURE__ */ o("section", { className: "fp-formula", "aria-label": r, children: [
    /* @__PURE__ */ o("header", { className: "fp-formula-head", children: [
      /* @__PURE__ */ e(It, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ e("span", { children: r }),
      n && /* @__PURE__ */ o("span", { className: "fp-formula-count", children: [
        "第 ",
        a + 1,
        " / ",
        t.length,
        " 步"
      ] })
    ] }),
    /* @__PURE__ */ e("ol", { className: "fp-formula-list", children: l.map((s, c) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ e("span", { className: "fp-formula-index", children: n ? a + 1 : c + 1 }),
      /* @__PURE__ */ e("div", { className: "fp-formula-body", children: s })
    ] }, n ? a : c)) }),
    n && /* @__PURE__ */ o("div", { className: "fp-formula-nav", children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a === 0,
          onClick: () => i((s) => Math.max(0, s - 1)),
          children: [
            /* @__PURE__ */ e(Tr, { size: 14, "aria-hidden": "true" }),
            "上一步"
          ]
        }
      ),
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          className: "fp-button fp-secondary fp-sm",
          disabled: a === t.length - 1,
          onClick: () => i((s) => Math.min(t.length - 1, s + 1)),
          children: [
            "下一步",
            /* @__PURE__ */ e(ze, { size: 14, "aria-hidden": "true" })
          ]
        }
      )
    ] })
  ] });
}
const Nl = 320, Er = 170, Oe = { l: 30, r: 12, t: 14, b: 26 }, pr = Nl - Oe.l - Oe.r, At = Er - Oe.t - Oe.b;
function dp(t, n, r) {
  const a = Math.max(1e-6, r);
  return 1 / (a * Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * ((t - n) / a) ** 2);
}
function up(t, n) {
  if (n < 0 || n > t) return 0;
  let r = 1;
  for (let a = 1; a <= n; a++) r = r * (t - n + a) / a;
  return r;
}
function pp(t, n, r) {
  return up(n, t) * r ** t * (1 - r) ** (n - t);
}
function hp(t, n) {
  let r = 1;
  for (let a = 2; a <= t; a++) r *= a;
  return n ** t * Math.exp(-n) / r;
}
function zm({
  type: t,
  params: n = {},
  interactive: r = !1,
  height: a = 180,
  label: i
}) {
  const l = ve(), [s, c] = k(n.mu ?? 0), [u, d] = k(n.sigma ?? 1), [p, h] = k(n.n ?? 10), [f, m] = k(n.p ?? 0.5), [b, g] = k(n.lambda ?? 3), y = [];
  let w = [], v = 1;
  if (t === "normal") {
    const A = s - 4 * u, D = s + 4 * u, U = 120;
    for (let j = 0; j <= U; j++) {
      const T = A + (D - A) * j / U;
      y.push({ x: T, y: dp(T, s, u) });
    }
    v = Math.max(...y.map((j) => j.y)), w = [A, s - u, s, s + u, D];
  } else {
    const A = t === "binomial" ? p : Math.max(1, Math.round(b * 4));
    for (let D = 0; D <= A; D++) {
      const U = t === "binomial" ? pp(D, p, f) : hp(D, b);
      y.push({ x: D, y: U });
    }
    v = Math.max(...y.map((D) => D.y), 1e-9), w = [0, Math.round(A / 2), A];
  }
  const N = y[0].x, x = y[y.length - 1].x, C = (A) => Oe.l + (A - N) / (x - N || 1) * pr, I = (A) => Oe.t + At - A / v * At * 0.92, L = t === "normal" ? y.map((A, D) => `${D === 0 ? "M" : "L"}${C(A.x).toFixed(1)},${I(A.y).toFixed(1)}`).join(" ") : "", K = t === "normal" ? 0 : Math.max(4, pr / y.length - 4), S = /* @__PURE__ */ o(
    "svg",
    {
      viewBox: `0 0 ${Nl} ${Er}`,
      width: "100%",
      height: a,
      role: "img",
      "aria-labelledby": l,
      className: "fp-dist-chart",
      children: [
        /* @__PURE__ */ e("title", { id: l, children: i || (t === "normal" ? `正态分布 μ=${s} σ=${u}` : t === "binomial" ? `二项分布 n=${p} p=${f}` : `泊松分布 λ=${b}`) }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: Oe.l,
            y1: Oe.t + At,
            x2: Oe.l + pr,
            y2: Oe.t + At,
            className: "fp-dist-axis"
          }
        ),
        /* @__PURE__ */ e("line", { x1: Oe.l, y1: Oe.t, x2: Oe.l, y2: Oe.t + At, className: "fp-dist-axis" }),
        t === "normal" ? /* @__PURE__ */ e("path", { d: L, className: "fp-dist-line" }) : y.map((A, D) => /* @__PURE__ */ e(
          "rect",
          {
            x: C(A.x) - K / 2,
            y: I(A.y),
            width: K,
            height: Oe.t + At - I(A.y),
            rx: 2,
            className: "fp-dist-bar"
          },
          D
        )),
        w.map((A, D) => /* @__PURE__ */ e(
          "text",
          {
            x: C(A),
            y: Er - 8,
            textAnchor: "middle",
            className: "fp-dist-tick",
            children: Number.isInteger(A) ? A : A.toFixed(1)
          },
          D
        ))
      ]
    }
  );
  return r ? /* @__PURE__ */ o("div", { className: "fp-dist", children: [
    S,
    /* @__PURE__ */ e("div", { className: "fp-dist-controls", children: t === "normal" ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "均值 μ · ",
          s.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: -3,
            max: 3,
            step: 0.1,
            value: s,
            onChange: (A) => c(Number(A.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "标准差 σ · ",
          u.toFixed(1)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.3,
            max: 3,
            step: 0.1,
            value: u,
            onChange: (A) => d(Number(A.target.value))
          }
        )
      ] })
    ] }) : t === "binomial" ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "试验次数 n · ",
          p
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 1,
            max: 30,
            step: 1,
            value: p,
            onChange: (A) => h(Number(A.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        /* @__PURE__ */ o("span", { children: [
          "成功概率 p · ",
          f.toFixed(2)
        ] }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.05,
            max: 0.95,
            step: 0.05,
            value: f,
            onChange: (A) => m(Number(A.target.value))
          }
        )
      ] })
    ] }) : /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ o("span", { children: [
        "λ · ",
        b.toFixed(1)
      ] }),
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0.5,
          max: 10,
          step: 0.5,
          value: b,
          onChange: (A) => g(Number(A.target.value))
        }
      )
    ] }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-dist", children: S });
}
function Am({
  open: t,
  onClose: n,
  categories: r,
  title: a = "快捷键参考",
  footnote: i
}) {
  return Y(() => {
    if (!t) return;
    const l = (c) => {
      c.key === "Escape" && (c.preventDefault(), n());
    };
    document.addEventListener("keydown", l);
    const s = document.body.style.overflow;
    return document.body.style.overflow = "hidden", () => {
      document.removeEventListener("keydown", l), document.body.style.overflow = s;
    };
  }, [t, n]), !t || typeof window > "u" ? null : De(
    /* @__PURE__ */ e("div", { className: "fp-shortcut-scrim", onPointerDown: n, children: /* @__PURE__ */ o(
      "div",
      {
        className: "fp-shortcut",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": a,
        onPointerDown: (l) => l.stopPropagation(),
        children: [
          /* @__PURE__ */ o("header", { className: "fp-shortcut-head", children: [
            /* @__PURE__ */ e(ti, { size: 18, "aria-hidden": "true" }),
            /* @__PURE__ */ e("strong", { children: a }),
            /* @__PURE__ */ e(
              "button",
              {
                type: "button",
                className: "fp-icon-button fp-sm",
                "aria-label": "关闭快捷键参考",
                onClick: n,
                children: /* @__PURE__ */ e(ge, { size: 16 })
              }
            )
          ] }),
          /* @__PURE__ */ e("div", { className: "fp-shortcut-body", children: r.map((l) => /* @__PURE__ */ o("section", { className: "fp-shortcut-group", children: [
            /* @__PURE__ */ e("h3", { children: l.label }),
            /* @__PURE__ */ e("dl", { children: l.items.map((s) => /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ e("dt", { children: s.keys.split(" ").map((c, u) => /* @__PURE__ */ e("span", { className: "fp-kbd", children: c }, u)) }),
              /* @__PURE__ */ e("dd", { children: s.description })
            ] }, s.keys + s.description)) })
          ] }, l.id)) }),
          i && /* @__PURE__ */ e("footer", { className: "fp-shortcut-foot", children: i })
        ]
      }
    ) }),
    document.body
  );
}
function Im({
  items: t,
  value: n,
  onChange: r,
  label: a = "主导航",
  className: i = "",
  busy: l = !1
}) {
  return /* @__PURE__ */ e("nav", { className: `fp-bottom-nav ${i}`, "aria-label": a, "aria-busy": l, children: t.map((s) => {
    const c = s.id === n, u = s.href ? "a" : "button";
    return /* @__PURE__ */ o(
      u,
      {
        type: "button",
        href: s.href,
        "aria-disabled": s.disabled || void 0,
        className: "fp-bottom-nav-item",
        "aria-current": c ? "page" : void 0,
        onClick: (d) => {
          s.href && (d.metaKey || d.ctrlKey || d.shiftKey || d.altKey) || (d.preventDefault(), s.disabled || r(s.id));
        },
        children: [
          /* @__PURE__ */ e("span", { className: "fp-bottom-nav-indicator", "aria-hidden": "true" }),
          /* @__PURE__ */ o("span", { className: "fp-bottom-nav-icon", children: [
            s.icon,
            s.badge ? /* @__PURE__ */ e("span", { className: "fp-bottom-nav-badge", children: s.badge }) : null
          ] }),
          /* @__PURE__ */ e("span", { children: s.label })
        ]
      },
      s.id
    );
  }) });
}
const fp = 4;
function Lm({
  images: t,
  label: n = "笔记图片",
  size: r = 132,
  meta: a
}) {
  const i = B(null), l = B(null), [s, c] = k(null);
  return t.length ? /* @__PURE__ */ o("section", { className: "fp-gallery", children: [
    /* @__PURE__ */ o("header", { className: "fp-gallery-head", children: [
      /* @__PURE__ */ e($o, { size: 15, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        n,
        " · ",
        t.length,
        " 张"
      ] }),
      a && /* @__PURE__ */ e("small", { children: a })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        ref: i,
        className: "fp-gallery-strip",
        "data-dragging": l.current?.moved || void 0,
        onPointerDown: (u) => {
          const d = i.current;
          !d || u.button !== 0 || (l.current = { x: u.clientX, left: d.scrollLeft, moved: !1 });
        },
        onPointerMove: (u) => {
          const d = i.current, p = l.current;
          if (!d || !p) return;
          const h = u.clientX - p.x;
          !p.moved && Math.abs(h) >= fp && (p.moved = !0, d.setPointerCapture(u.pointerId)), p.moved && (d.scrollLeft = p.left - h);
        },
        onPointerUp: () => {
          l.current = null;
        },
        onPointerCancel: () => {
          l.current = null;
        },
        children: t.map((u, d) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            className: "fp-gallery-item",
            style: { width: r, height: r },
            onClick: () => {
              l.current?.moved || c(u);
            },
            children: [
              /* @__PURE__ */ e("img", { src: u.src, alt: u.alt || u.caption || `图片 ${d + 1}` }),
              u.caption && /* @__PURE__ */ e("span", { children: u.caption })
            ]
          },
          `${u.src}:${d}`
        ))
      }
    ),
    /* @__PURE__ */ e(
      op,
      {
        src: s?.src ?? null,
        alt: s?.alt || s?.caption,
        onClose: () => c(null)
      }
    )
  ] }) : null;
}
function Tm({
  windows: t,
  onSelect: n,
  max: r = 5,
  label: a = "已打开的窗口"
}) {
  const i = B(null), [l, s] = k(r);
  if (Ce(() => {
    const p = i.current;
    if (!p) return;
    const h = () => {
      p.clientWidth && s(
        Math.max(
          1,
          Math.min(r, Math.floor((p.clientWidth - 46) / 132))
        )
      );
    };
    if (h(), typeof ResizeObserver > "u") return;
    const f = new ResizeObserver(h);
    return f.observe(p), () => f.disconnect();
  }, [r, t.length]), !t.length) return null;
  const c = Math.max(1, Math.min(r, l)), u = t.slice(0, c), d = t.slice(c);
  return /* @__PURE__ */ o("div", { ref: i, className: "fp-taskbar", role: "toolbar", "aria-label": a, children: [
    u.map((p) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-taskbar-item",
        "aria-pressed": p.active,
        title: p.title,
        onClick: () => n(p.id),
        children: [
          /* @__PURE__ */ e("span", { className: "fp-taskbar-dot", "aria-hidden": "true" }),
          p.icon,
          /* @__PURE__ */ e("span", { className: "fp-taskbar-title", children: p.title })
        ]
      },
      p.id
    )),
    d.length > 0 && /* @__PURE__ */ e(
      et,
      {
        label: `还有 ${d.length} 个窗口`,
        menu: !0,
        trigger: /* @__PURE__ */ o("span", { children: [
          "+",
          d.length
        ] }),
        children: (p) => d.map((h) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            role: "menuitem",
            onClick: () => {
              p(), n(h.id);
            },
            children: [
              h.icon,
              h.title
            ]
          },
          h.id
        ))
      }
    )
  ] });
}
function Dm({ title: t, description: n, icon: r, className: a = "", ...i }) {
  return /* @__PURE__ */ o("button", { ...i, type: i.type || "button", className: `fp-navigation-card ${a}`, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-navigation-card-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-navigation-card-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("span", { children: n })
    ] }),
    /* @__PURE__ */ e(ze, { size: 17, "aria-hidden": "true" })
  ] });
}
function Pm({ title: t, description: n, eyebrow: r, art: a, footer: i, className: l = "", ...s }) {
  return /* @__PURE__ */ o("button", { ...s, type: s.type || "button", className: `fp-preview-card ${l}`, children: [
    /* @__PURE__ */ o("span", { className: "fp-preview-card-art", children: [
      /* @__PURE__ */ e("span", { className: "fp-preview-card-eyebrow", children: r }),
      a
    ] }),
    /* @__PURE__ */ o("span", { className: "fp-preview-card-copy", children: [
      /* @__PURE__ */ o("strong", { children: [
        t,
        /* @__PURE__ */ e(ze, { size: 17 })
      ] }),
      n && /* @__PURE__ */ e("span", { children: n }),
      i && /* @__PURE__ */ e("span", { className: "fp-preview-card-footer", children: i })
    ] })
  ] });
}
const mp = (t) => t === void 0 ? "—" : t < 1024 ? `${t} B` : t < 1048576 ? `${(t / 1024).toFixed(1)} KB` : `${(t / 1048576).toFixed(1)} MB`;
function bp({
  media: t = !1,
  defaultView: n = "list",
  showSearch: r = !0,
  availableActions: a = ["download", "share", "rename", "delete"],
  query: i,
  onQueryChange: l,
  items: s,
  folderId: c = null,
  onFolderChange: u,
  selectedIds: d,
  onSelectionChange: p,
  onOpen: h,
  onAction: f,
  onCreateFolder: m,
  onUpload: b,
  onMove: g,
  loading: y,
  error: w
}) {
  const v = B(null), N = B(null), [x, C] = k(null), [I, L] = k(1), [K, S] = k(n), [A, D] = k(""), [U, j] = k("name"), T = i ?? A, M = (H) => {
    D(H), l?.(H);
  }, R = s.find((H) => H.id === c), q = s.filter((H) => d.includes(H.id)), F = [];
  let E = R;
  const z = /* @__PURE__ */ new Set();
  for (; E && !z.has(E.id); )
    z.add(E.id), F.unshift(E), E = s.find((H) => H.id === E?.parentId);
  const $ = Ue(
    () => s.filter(
      (H) => (H.parentId || null) === c && H.name.toLowerCase().includes(T.toLowerCase())
    ).sort(
      (H, V) => H.kind !== V.kind ? H.kind === "folder" ? -1 : 1 : U === "name-desc" ? V.name.localeCompare(H.name, "zh-CN") : U === "modified-asc" ? (H.modifiedAt || "").localeCompare(V.modifiedAt || "") : U === "size-asc" ? (H.size || 0) - (V.size || 0) : U === "size" ? (V.size || 0) - (H.size || 0) : U === "modified" ? (V.modifiedAt || "").localeCompare(H.modifiedAt || "") : H.name.localeCompare(V.name, "zh-CN")
    ),
    [s, c, T, U]
  );
  Ce(() => {
    const H = N.current;
    if (!H) return;
    const V = () => L(Math.max(1, Math.floor((H.clientWidth - 8) / (t ? 228 : 148))));
    if (V(), typeof ResizeObserver > "u") return;
    const oe = new ResizeObserver(V);
    return oe.observe(H), () => oe.disconnect();
  }, [t]);
  const P = K === "list" ? 1 : I, re = yi({
    count: Math.ceil($.length / P),
    getScrollElement: () => N.current,
    estimateSize: () => K === "list" ? 52 : t ? 244 : 156,
    overscan: 8,
    initialRect: { width: 800, height: 480 }
  }), ie = $.length > 100, ye = re.getVirtualItems(), he = ie ? ye.flatMap(
    (H) => $.slice(H.index * P, (H.index + 1) * P)
  ) : $;
  Y(() => {
    re.scrollToOffset(0);
  }, [c, T, U, K]);
  const W = (H, V) => {
    const oe = /* @__PURE__ */ new Set();
    for (; V; ) {
      if (H.includes(V) || oe.has(V)) return !1;
      oe.add(V), V = s.find((_) => _.id === V)?.parentId || null;
    }
    return !0;
  }, G = (H, V = !1, oe = !1) => {
    if (V && v.current) {
      const _ = $.findIndex((Z) => Z.id === v.current), O = $.findIndex((Z) => Z.id === H);
      if (_ >= 0 && O >= 0) {
        p(
          $.slice(Math.min(_, O), Math.max(_, O) + 1).map((Z) => Z.id)
        );
        return;
      }
    }
    v.current = H, p(
      oe ? d.includes(H) ? d.filter((_) => _ !== H) : [...d, H] : [H]
    );
  }, ue = (H) => {
    H.kind === "folder" ? (u(H.id), p([]), M("")) : h(H);
  }, me = (H) => [
    {
      id: "open",
      label: "打开",
      icon: /* @__PURE__ */ e(Qe, { size: 15 }),
      disabled: H.length !== 1,
      onSelect: () => ue(H[0])
    },
    ...f ? [
      { id: "download", label: "下载", icon: /* @__PURE__ */ e(jt, { size: 15 }), disabled: H.some((V) => V.kind === "folder") },
      { id: "restore", label: "恢复", icon: /* @__PURE__ */ e(Je, { size: 15 }) },
      { id: "move", label: "移动到…", icon: /* @__PURE__ */ e(Io, { size: 15 }) },
      { id: "share", label: "分享", icon: /* @__PURE__ */ e(Lo, { size: 15 }) },
      {
        id: "rename",
        label: "重命名",
        icon: /* @__PURE__ */ e(Bn, { size: 15 }),
        disabled: H.length !== 1
      },
      {
        id: "delete",
        label: "移到回收站",
        icon: /* @__PURE__ */ e(Ht, { size: 15 }),
        danger: !0,
        separator: !0
      }
    ].filter((V) => a.includes(V.id)).map((V) => ({
      ...V,
      onSelect: () => f(
        V.id,
        H
      )
    })) : []
  ];
  return /* @__PURE__ */ o("section", { className: "fp-resource-explorer", "data-media": t || void 0, "aria-label": t ? "图片资源管理器" : "文件资源管理器", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("nav", { "aria-label": "文件路径", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              u(null), M("");
            },
            children: "全部文件"
          }
        ),
        F.map((H) => /* @__PURE__ */ o("span", { children: [
          " ",
          "/",
          " ",
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => {
                u(H.id), M("");
              },
              children: H.name
            }
          )
        ] }, H.id))
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-explorer-tools", children: [
        (m || q.length > 0) && /* @__PURE__ */ e(wl, { label: "资源操作", actions: [...m ? [{ id: "create", label: "新建文件夹", icon: /* @__PURE__ */ e(zo, { size: 17 }), onSelect: m }] : [], ...me(q).filter((H) => H.id !== "open" && q.length > 0).map((H) => ({ id: H.id, label: H.label, icon: H.icon, onSelect: () => H.onSelect?.(), disabled: H.disabled }))] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "返回上级",
            disabled: !c,
            onClick: () => u(R?.parentId || null),
            children: /* @__PURE__ */ e(Pr, { size: 16 })
          }
        ),
        r && /* @__PURE__ */ o("label", { className: "fp-explorer-search", children: [
          /* @__PURE__ */ e(We, { size: 15 }),
          /* @__PURE__ */ e(
            "input",
            {
              "aria-label": "搜索当前文件夹",
              placeholder: "搜索文件",
              value: T,
              onChange: (H) => M(H.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ e(
          ke,
          {
            label: "文件排序",
            value: U,
            onChange: j,
            options: [
              { value: "name", label: "名称 A → Z" },
              { value: "name-desc", label: "名称 Z → A" },
              { value: "modified", label: "修改时间：新到旧" },
              { value: "modified-asc", label: "修改时间：旧到新" },
              { value: "size", label: "大小：大到小" },
              { value: "size-asc", label: "大小：小到大" }
            ]
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "列表视图",
            "aria-pressed": K === "list",
            onClick: () => S("list"),
            children: /* @__PURE__ */ e(nn, { size: 16 })
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": "网格视图",
            "aria-pressed": K === "grid",
            onClick: () => S("grid"),
            children: /* @__PURE__ */ e(Ao, { size: 16 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e(
      yt,
      {
        label: "文件夹操作",
        items: [
          ...m ? [{ id: "new", label: "新建文件夹", onSelect: m }] : [],
          {
            id: "select-all",
            label: "全选",
            onSelect: () => p($.map((H) => H.id))
          },
          {
            id: "view",
            label: "视图",
            children: [
              {
                id: "list",
                label: "列表",
                checked: K === "list",
                onSelect: () => S("list")
              },
              {
                id: "grid",
                label: "网格",
                checked: K === "grid",
                onSelect: () => S("grid")
              }
            ]
          }
        ],
        children: /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o(
          "div",
          {
            ref: N,
            style: {
              position: "relative",
              maxHeight: 480,
              overflow: "auto",
              ...ie && K === "grid" ? {
                gridTemplateColumns: `repeat(${I},minmax(0,1fr))`,
                rowGap: 0
              } : {}
            },
            onPointerDown: (H) => {
              if (H.button !== 0 || H.pointerType === "touch" || H.target.closest(
                ".fp-explorer-item,button,input,label"
              ))
                return;
              const V = H.currentTarget.getBoundingClientRect(), oe = H.clientX - V.left + H.currentTarget.scrollLeft, _ = H.clientY - V.top + H.currentTarget.scrollTop;
              H.currentTarget.setPointerCapture(H.pointerId), C({ x: oe, y: _, left: oe, top: _, width: 0, height: 0 });
            },
            onPointerMove: (H) => {
              if (!x) return;
              const V = H.currentTarget.getBoundingClientRect(), oe = H.clientX - V.left + H.currentTarget.scrollLeft, _ = H.clientY - V.top + H.currentTarget.scrollTop, O = {
                ...x,
                left: Math.min(oe, x.x),
                top: Math.min(_, x.y),
                width: Math.abs(oe - x.x),
                height: Math.abs(_ - x.y)
              };
              C(O);
              const Z = Array.from(
                H.currentTarget.querySelectorAll(
                  "[data-resource-id]"
                )
              ).filter((we) => {
                const Me = we.getBoundingClientRect(), Ee = Me.left - V.left + H.currentTarget.scrollLeft, qe = Me.top - V.top + H.currentTarget.scrollTop;
                return Ee < O.left + O.width && Ee + Me.width > O.left && qe < O.top + O.height && qe + Me.height > O.top;
              }).map((we) => we.dataset.resourceId);
              p(Z);
            },
            onPointerUp: () => C(null),
            onPointerCancel: () => C(null),
            className: `fp-explorer-content fp-explorer-${K}`,
            "aria-busy": y,
            tabIndex: 0,
            onKeyDown: (H) => {
              H.target.closest("input") || ((H.ctrlKey || H.metaKey) && H.key.toLowerCase() === "a" && (H.preventDefault(), p($.map((V) => V.id))), H.key === "Escape" && p([]), H.key === "Delete" && q.length && f && a.includes("delete") && (H.preventDefault(), f("delete", q)));
            },
            onDragOver: (H) => {
              (b || g) && H.preventDefault();
            },
            onDrop: (H) => {
              if (H.preventDefault(), H.dataTransfer.files.length)
                b?.(Array.from(H.dataTransfer.files), c);
              else
                try {
                  const V = JSON.parse(
                    H.dataTransfer.getData(
                      "application/x-fiveplusone-resources"
                    )
                  );
                  Array.isArray(V) && V.every((oe) => typeof oe == "string") && W(V, c) && g?.(V, c);
                } catch {
                }
            },
            children: [
              w ? /* @__PURE__ */ e("p", { role: "alert", children: w }) : y ? /* @__PURE__ */ e(gl, { variant: "list", label: "正在加载文件" }) : $.length ? /* @__PURE__ */ o(Q, { children: [
                ie && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: ye[0]?.start || 0,
                      gridColumn: "1 / -1"
                    }
                  }
                ),
                he.map((H) => /* @__PURE__ */ e(
                  yt,
                  {
                    label: `${H.name}的操作`,
                    items: me(
                      d.includes(H.id) ? q : [H]
                    ),
                    children: /* @__PURE__ */ o(
                      "div",
                      {
                        className: "fp-explorer-item",
                        "data-resource-id": H.id,
                        style: ie ? {
                          height: K === "list" ? 52 : 148,
                          marginBottom: K === "grid" ? 8 : 0,
                          boxSizing: "border-box"
                        } : void 0,
                        "data-selected": d.includes(H.id) || void 0,
                        draggable: !!g,
                        onDragStart: (V) => {
                          V.dataTransfer.setData(
                            "application/x-fiveplusone-resources",
                            JSON.stringify(
                              d.includes(H.id) ? d : [H.id]
                            )
                          ), V.dataTransfer.effectAllowed = "move";
                        },
                        onDoubleClick: (V) => {
                          V.target.closest(
                            "button,input,label"
                          ) || ue(H);
                        },
                        onClick: (V) => {
                          V.target.closest(
                            "button,input,label"
                          ) || G(H.id, V.shiftKey, V.ctrlKey || V.metaKey);
                        },
                        onDragOver: (V) => {
                          H.kind === "folder" && g && (V.preventDefault(), V.stopPropagation());
                        },
                        onDrop: (V) => {
                          if (H.kind === "folder")
                            if (V.preventDefault(), V.stopPropagation(), V.dataTransfer.files.length)
                              b?.(Array.from(V.dataTransfer.files), H.id);
                            else
                              try {
                                const oe = JSON.parse(
                                  V.dataTransfer.getData(
                                    "application/x-fiveplusone-resources"
                                  )
                                );
                                Array.isArray(oe) && oe.every((_) => typeof _ == "string") && W(oe, H.id) && g?.(oe, H.id);
                              } catch {
                              }
                        },
                        children: [
                          /* @__PURE__ */ e(
                            Zr,
                            {
                              label: "",
                              "aria-label": `选择${H.name}`,
                              checked: d.includes(H.id),
                              onClick: (V) => {
                                V.shiftKey && (V.preventDefault(), G(H.id, !0));
                              },
                              onChange: () => G(H.id, !1, !0)
                            }
                          ),
                          /* @__PURE__ */ o(
                            "button",
                            {
                              type: "button",
                              className: "fp-explorer-name",
                              "aria-label": H.name,
                              onClick: (V) => {
                                V.shiftKey || V.ctrlKey || V.metaKey ? G(H.id, V.shiftKey, V.ctrlKey || V.metaKey) : ue(H);
                              },
                              children: [
                                H.thumbnailUrl ? /* @__PURE__ */ e("img", { src: H.thumbnailUrl, alt: "" }) : H.kind === "folder" ? /* @__PURE__ */ e(Nn, { size: K === "grid" ? 36 : 19 }) : /* @__PURE__ */ e(Qe, { size: K === "grid" ? 32 : 19 }),
                                /* @__PURE__ */ e("span", { children: H.name })
                              ]
                            }
                          ),
                          /* @__PURE__ */ e("small", { children: H.kind === "folder" ? "文件夹" : mp(H.size) }),
                          /* @__PURE__ */ e("time", { children: H.modifiedAt ? new Date(H.modifiedAt).toLocaleDateString(
                            "zh-CN"
                          ) : "" }),
                          /* @__PURE__ */ e(
                            ki,
                            {
                              label: `${H.name}的更多操作`,
                              icon: /* @__PURE__ */ e(Ot, { size: 16 }),
                              items: me(
                                d.includes(H.id) ? q : [H]
                              ).filter((V) => !V.disabled).map((V) => ({
                                label: V.label,
                                danger: V.danger,
                                onClick: () => V.onSelect?.()
                              }))
                            }
                          )
                        ]
                      }
                    )
                  },
                  H.id
                )),
                ie && /* @__PURE__ */ e(
                  "div",
                  {
                    "aria-hidden": "true",
                    style: {
                      height: Math.max(
                        0,
                        re.getTotalSize() - (ye.at(-1)?.end || 0)
                      ),
                      gridColumn: "1 / -1"
                    }
                  }
                )
              ] }) : /* @__PURE__ */ e("p", { className: "fp-explorer-empty", children: T ? "没有找到匹配的文件" : "文件夹还是空的" }),
              x && /* @__PURE__ */ e(
                "div",
                {
                  "aria-hidden": "true",
                  className: "fp-explorer-selection-box",
                  style: {
                    position: "absolute",
                    left: x.left,
                    top: x.top,
                    width: x.width,
                    height: x.height,
                    pointerEvents: "none"
                  }
                }
              )
            ]
          }
        ) })
      }
    ),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("span", { children: d.length ? `已选择 ${d.length} 项` : `${$.length} 项` }),
      d.length > 0 && /* @__PURE__ */ e("button", { type: "button", onClick: () => p([]), children: "取消选择" })
    ] })
  ] });
}
function Fm({
  items: t,
  selectedIds: n,
  onSelectionChange: r,
  onRestore: a,
  onDelete: i,
  loading: l,
  error: s
}) {
  const [c, u] = k(!1), [d, p] = k(""), h = B(!1), f = async (m, b = !1) => {
    if (!h.current) {
      h.current = !0, u(!0), p("");
      try {
        await (b ? i(m) : a(m));
      } finally {
        h.current = !1, u(!1);
      }
    }
  };
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "回收站" }),
        /* @__PURE__ */ e("small", { children: "还需要的资料可以恢复到原位置。" })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-pattern-actions", children: [
        /* @__PURE__ */ e(
          be,
          {
            disabled: c || !n.length,
            onAction: () => f(n),
            children: "恢复所选"
          }
        ),
        /* @__PURE__ */ e(
          be,
          {
            disabled: c || !n.length,
            confirm: "永久删除所选资料后将无法恢复，确认继续？",
            onAction: () => f(n, !0),
            children: "永久删除"
          }
        )
      ] })
    ] }),
    (s || d) && /* @__PURE__ */ e("p", { role: "alert", children: s || d }),
    l ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取回收站…" }) : t.length ? /* @__PURE__ */ e("ul", { children: t.map((m) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ e(
      yt,
      {
        disabled: c,
        items: [
          {
            id: "restore",
            label: "恢复",
            onSelect: () => {
              f([m.id]).catch(
                (b) => p(
                  b instanceof Error ? b.message : "暂时无法恢复，请重试。"
                )
              );
            }
          },
          {
            id: "select",
            label: "选择",
            onSelect: () => r([m.id])
          }
        ],
        children: /* @__PURE__ */ o("div", { className: "fp-recycle-row", children: [
          /* @__PURE__ */ e(
            Zr,
            {
              label: "",
              "aria-label": `选择${m.name}`,
              checked: n.includes(m.id),
              disabled: c,
              onChange: () => r(
                n.includes(m.id) ? n.filter((b) => b !== m.id) : [...n, m.id]
              )
            }
          ),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: m.name }),
            /* @__PURE__ */ e("small", { children: m.originalPath })
          ] }),
          /* @__PURE__ */ e("time", { children: m.deletedAt }),
          m.size && /* @__PURE__ */ e("small", { children: m.size })
        ] })
      }
    ) }, m.id)) }) : /* @__PURE__ */ e("p", { children: "回收站是空的。" })
  ] });
}
function Om({
  items: t,
  onReview: n,
  onPreview: r,
  loading: a,
  error: i
}) {
  const [l, s] = k("all"), c = t.filter(
    (u) => l === "all" || u.status === l
  );
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: "今日复习" }),
        /* @__PURE__ */ o("small", { children: [
          t.length,
          " 条学习记录"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: !c.length || a,
          onClick: () => n(c.map((u) => u.id)),
          children: "开始复习"
        }
      )
    ] }),
    /* @__PURE__ */ e(
      ke,
      {
        label: "复习范围",
        value: l,
        onChange: s,
        options: [
          { value: "all", label: "全部记录" },
          { value: "new", label: "初次学习" },
          { value: "learning", label: "正在巩固" },
          { value: "review", label: "定期复习" }
        ]
      }
    ),
    i && /* @__PURE__ */ e("p", { role: "alert", children: i }),
    a ? /* @__PURE__ */ e("p", { role: "status", children: "正在整理复习记录…" }) : /* @__PURE__ */ e("ul", { children: c.map((u) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-review-record",
        onClick: () => r(u.id),
        children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: u.title }),
            /* @__PURE__ */ o("small", { children: [
              u.subject,
              u.detail && ` · ${u.detail}`
            ] })
          ] }),
          /* @__PURE__ */ e("time", { children: u.due })
        ]
      }
    ) }, u.id)) }),
    !a && !c.length && /* @__PURE__ */ e("p", { children: "当前范围没有待复习的记录。" })
  ] });
}
function Rm({
  title: t,
  items: n,
  activeId: r,
  onNavigate: a,
  children: i,
  onSubmit: l,
  remainingLabel: s
}) {
  const c = n.filter((u) => u.answered).length;
  return /* @__PURE__ */ o("section", { className: "fp-quiz-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("span", { children: s || `已完成 ${c} / ${n.length} 题` })
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "题目导航", children: n.map((u) => /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        "aria-current": u.id === r ? "step" : void 0,
        "data-answered": u.answered || void 0,
        onClick: () => a(u.id),
        children: [
          u.label,
          u.flagged && /* @__PURE__ */ e("span", { "aria-label": "已标记", children: " ·" })
        ]
      },
      u.id
    )) }),
    /* @__PURE__ */ e(fe, { children: i }),
    /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: /* @__PURE__ */ e(
      be,
      {
        confirm: c < n.length ? `还有 ${n.length - c} 题未完成，仍要提交？` : "确认提交本次答题？",
        onAction: l,
        children: "提交答题"
      }
    ) })
  ] });
}
function Bm({
  items: t
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-selection-actions",
      role: "toolbar",
      "aria-label": "所选内容操作",
      children: t.map((n) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          disabled: n.disabled,
          onMouseDown: (r) => r.preventDefault(),
          onClick: n.onSelect,
          children: n.label
        },
        n.id
      ))
    }
  );
}
function jm({
  title: t,
  detail: n,
  value: r,
  onCancel: a,
  children: i
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", "aria-live": "polite", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      a && /* @__PURE__ */ e("button", { type: "button", onClick: a, children: "取消" })
    ] }),
    n && /* @__PURE__ */ e("p", { children: n }),
    /* @__PURE__ */ e(
      "progress",
      {
        "aria-label": t,
        max: 100,
        value: r === void 0 ? void 0 : Math.min(100, Math.max(0, r))
      }
    ),
    i
  ] });
}
function qm({
  title: t = "打开一份资料，开始学习",
  description: n = "可以从左侧选择笔记，也可以添加新的资料。",
  actions: r
}) {
  return /* @__PURE__ */ o("section", { className: "fp-workspace-empty", children: [
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r && /* @__PURE__ */ e("div", { className: "fp-pattern-actions", children: r })
  ] });
}
function Km({
  title: t,
  status: n,
  actions: r,
  trace: a,
  children: i,
  attachments: l
}) {
  const [s, c] = k(!1);
  return /* @__PURE__ */ o("section", { className: "fp-run-workspace", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h3", { children: t }),
        n && /* @__PURE__ */ e("p", { role: "status", children: n })
      ] }),
      r
    ] }),
    i,
    l && /* @__PURE__ */ e("aside", { "aria-label": "相关资料", children: l }),
    a && /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          "aria-expanded": s,
          onClick: () => c((u) => !u),
          children: "工作记录"
        }
      ),
      /* @__PURE__ */ e(Re, { isOpen: s, children: a })
    ] })
  ] });
}
function Hm({
  title: t,
  frames: n,
  time: r,
  duration: a,
  playing: i,
  onTimeChange: l,
  onPlayingChange: s,
  children: c
}) {
  return /* @__PURE__ */ o("section", { className: "fp-recording-playback", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("h3", { children: t }),
      /* @__PURE__ */ e("button", { type: "button", onClick: () => s(!i), children: i ? "暂停回放" : "播放回放" })
    ] }),
    /* @__PURE__ */ e("div", { children: c }),
    /* @__PURE__ */ o("label", { children: [
      "回放进度",
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: 0,
          max: Math.max(0, a),
          step: "0.1",
          value: Math.min(a, Math.max(0, r)),
          onChange: (u) => l(Number(u.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ e("nav", { "aria-label": "回放关键帧", children: n.map((u, d) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-current": n.filter((p) => p.time <= r).at(-1) === u ? "step" : void 0,
        onClick: () => l(u.time),
        children: u.label
      },
      d
    )) })
  ] });
}
function Um({
  title: t = "分享与协作",
  access: n,
  search: r,
  onAddMember: a,
  link: i,
  permissionSummary: l
}) {
  const [s, c] = k(!1), [u, d] = k(""), p = B(!1);
  return /* @__PURE__ */ o("section", { className: "fp-share-access-panel", "aria-busy": s, children: [
    /* @__PURE__ */ e("h3", { children: t }),
    l,
    n.canManage && /* @__PURE__ */ e(
      Qu,
      {
        ...r,
        disabled: s,
        excludedIds: n.members.map((h) => h.id),
        onPick: (h, f) => {
          p.current || (p.current = !0, c(!0), d(""), Promise.resolve().then(() => a(h, f)).catch(
            (m) => d(
              m instanceof Error ? m.message : "暂时无法添加成员，请重试。"
            )
          ).finally(() => {
            p.current = !1, c(!1);
          }));
        }
      }
    ),
    u && /* @__PURE__ */ e("p", { role: "alert", className: "fp-error-text", children: u }),
    /* @__PURE__ */ e(Ju, { ...n }),
    /* @__PURE__ */ e(Zu, { ...i, disabled: i.disabled || !n.canManage })
  ] });
}
function _m({
  models: t,
  modelId: n,
  onModelChange: r,
  thinking: a,
  thinkingOptions: i,
  onThinkingChange: l,
  webEnabled: s,
  onWebChange: c,
  disabled: u,
  quota: d,
  children: p
}) {
  return /* @__PURE__ */ o("section", { className: "fp-pattern-panel", children: [
    /* @__PURE__ */ e("h3", { children: "对话设置" }),
    /* @__PURE__ */ o("div", { className: "fp-chat-preferences", children: [
      /* @__PURE__ */ o("label", { children: [
        "使用模型",
        /* @__PURE__ */ e(
          rp,
          {
            groups: t,
            value: n,
            onChange: r,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ o("label", { children: [
        "思考方式",
        /* @__PURE__ */ e(
          ke,
          {
            label: "思考方式",
            value: a,
            options: i,
            onChange: l,
            disabled: u
          }
        )
      ] }),
      /* @__PURE__ */ e(
        xp,
        {
          label: "联网查找资料",
          checked: s,
          onChange: c,
          disabled: u
        }
      ),
      d,
      p
    ] })
  ] });
}
function Wm({
  explorer: t,
  preview: n,
  previewTitle: r = "资料预览",
  actions: a
}) {
  const [i, l] = k("files");
  return /* @__PURE__ */ o("section", { className: "fp-resource-workspace", children: [
    /* @__PURE__ */ e("div", { className: "fp-resource-mobile-switch", children: /* @__PURE__ */ e(
      Mp,
      {
        value: i,
        onChange: l,
        items: [
          { value: "files", label: "文件" },
          { value: "preview", label: r }
        ]
      }
    ) }),
    /* @__PURE__ */ o("div", { className: "fp-resource-workspace-panes", "data-pane": i, children: [
      /* @__PURE__ */ e("aside", { children: /* @__PURE__ */ e(
        bp,
        {
          ...t,
          onOpen: (s) => {
            t.onOpen(s), l("preview");
          }
        }
      ) }),
      /* @__PURE__ */ o("section", { "aria-label": r, children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("h3", { children: r }),
          a
        ] }),
        /* @__PURE__ */ e(fe, { children: n })
      ] })
    ] })
  ] });
}
function Vm(t, n) {
  const r = document.createElement("header");
  r.style.cssText = "position:fixed;inset:0 0 auto;height:36px;z-index:2147483647";
  const a = r.attachShadow({ mode: "open" });
  a.innerHTML = '<style>:host{color-scheme:inherit}nav{height:36px;display:flex;align-items:center;background:var(--window-bar-background,light-dark(#f5f3f8,#211f26));color:var(--window-bar-color,light-dark(#29252f,#e7e0ed));font:12px system-ui;user-select:none;-webkit-app-region:drag}span{flex:1;padding:0 12px;pointer-events:none}button{width:46px;height:36px;border:0;background:transparent;color:inherit;font:16px system-ui;-webkit-app-region:no-drag;cursor:default}button:hover{background:light-dark(#e2dfe7,#3c3844)}button:focus-visible{outline:2px solid #a78bfa;outline-offset:-3px}button:last-child:hover{background:#c42b1c;color:white}</style><nav aria-label="窗口"><button aria-label="课栈菜单">☰</button><span></span><button aria-label="最小化">−</button><button aria-label="最大化">□</button><button aria-label="关闭窗口">×</button></nav>', a.querySelector("span").textContent = n;
  const i = a.querySelectorAll("button");
  i[0].onclick = () => t.openMenu(), i[1].onclick = () => t.minimize(), i[2].onclick = () => t.toggleMaximize(), i[3].onclick = () => t.closeWindow();
  const l = (c) => {
    i[2].textContent = c.maximized ? "❐" : "□", i[2].setAttribute("aria-label", c.maximized ? "还原窗口" : "最大化"), r.hidden = c.fullscreen, document.documentElement.style.setProperty("--desktop-titlebar-height", c.fullscreen ? "0px" : "36px");
  };
  document.body.prepend(r);
  const s = t.onWindowState(l);
  return t.getWindowState().then(l), () => {
    s(), r.remove();
  };
}
function Ym({ maximized: t, fullscreen: n, onMinimize: r, onMaximize: a, onClose: i }) {
  return /* @__PURE__ */ o("div", { className: "fp-window-controls", role: "group", "aria-label": "窗口操作", children: [
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "最小化", onClick: r, children: /* @__PURE__ */ e(Ft, { size: 16 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": n ? "退出全屏" : t ? "还原窗口" : "最大化", onClick: a, children: t || n ? /* @__PURE__ */ e(Kn, { size: 14 }) : /* @__PURE__ */ e(Hn, { size: 14 }) }),
    /* @__PURE__ */ e("button", { type: "button", "aria-label": "关闭窗口", onClick: i, children: /* @__PURE__ */ e(ge, { size: 18 }) })
  ] });
}
function Xm({ enabled: t = !1, as: n = "header", children: r, className: a = "", ...i }) {
  return /* @__PURE__ */ e(n, { ...i, className: `${a}${t ? " fp-window-drag-region" : ""}`, children: r });
}
function Gm({ id: t, title: n, brand: r, icon: a, scenes: i, defaultSceneId: l }) {
  const s = ve(), c = t || s, [u, d] = k(l || i[0]?.id), p = i.find((h) => h.id === u) || i[0];
  return p ? /* @__PURE__ */ o(Dt, { className: "fp-product-preview", "aria-label": n, children: [
    /* @__PURE__ */ o("header", { children: [
      a || /* @__PURE__ */ e(To, { size: 22 }),
      /* @__PURE__ */ e("strong", { children: n }),
      r && /* @__PURE__ */ e("span", { children: r })
    ] }),
    /* @__PURE__ */ e(Ur, { id: c, label: "功能预览", items: i.map((h) => ({ value: h.id, label: h.label })), value: p.id, onChange: d }),
    /* @__PURE__ */ e(fe, { children: /* @__PURE__ */ o("div", { className: "fp-product-preview-panel", id: `${c}-panel-${p.id}`, role: "tabpanel", "aria-labelledby": `${c}-tab-${p.id}`, tabIndex: 0, children: [
      /* @__PURE__ */ e(Kr, { children: p.eyebrow }),
      /* @__PURE__ */ e("h3", { children: p.title }),
      /* @__PURE__ */ e("p", { children: p.description }),
      /* @__PURE__ */ o("div", { className: "fp-product-preview-callout", children: [
        /* @__PURE__ */ e(Pe, { size: 22 }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: p.callout.title }),
          /* @__PURE__ */ e("p", { children: p.callout.description })
        ] })
      ] }),
      p.metrics && /* @__PURE__ */ e("div", { className: "fp-product-preview-metrics", children: p.metrics.map((h) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { children: h.label }),
        /* @__PURE__ */ e("strong", { children: h.value }),
        h.note && /* @__PURE__ */ e("small", { children: h.note })
      ] }, h.label)) }),
      p.rows && /* @__PURE__ */ e("div", { className: "fp-product-preview-rows", children: p.rows.map((h) => /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: h.title }),
          /* @__PURE__ */ e("span", { children: h.detail })
        ] }),
        /* @__PURE__ */ e("span", { children: h.value })
      ] }, h.title)) }),
      /* @__PURE__ */ o("footer", { children: [
        /* @__PURE__ */ e("span", { children: p.footnote }),
        p.link && /* @__PURE__ */ o("a", { href: p.link.href, children: [
          p.link.label,
          /* @__PURE__ */ e(Un, { size: 16 })
        ] })
      ] })
    ] }, p.id) })
  ] }) : null;
}
function gp() {
  const t = () => Array.from(document.querySelectorAll(".VPNavBarMenuGroup")), n = (c) => c.querySelector(":scope > button"), r = (c) => {
    c.dataset.fpDismissed = "";
    const u = n(c);
    u?.getAttribute("aria-expanded") === "true" && u.click();
  }, a = (c) => {
    const u = c.target, d = u.closest(".VPNavBarMenuGroup");
    if (c.key === "Escape") {
      const p = t().filter((h) => n(h)?.getAttribute("aria-expanded") === "true" || h.matches(":hover"));
      if (!p.length) return;
      c.preventDefault(), c.stopPropagation(), p.forEach(r), d && n(d)?.focus();
    } else if (d && u.closest("button") === n(d) && ["Enter", " ", "ArrowDown", "ArrowUp"].includes(c.key) && (delete d.dataset.fpDismissed, c.key.startsWith("Arrow"))) {
      c.preventDefault();
      const p = n(d);
      p?.getAttribute("aria-expanded") !== "true" && p?.click(), queueMicrotask(() => {
        const h = d.querySelectorAll(".menu a[href]");
        (c.key === "ArrowUp" ? h[h.length - 1] : h[0])?.focus();
      });
    }
  }, i = (c) => {
    const u = c.target;
    t().forEach((d) => {
      d.contains(u) ? u.closest("button") === n(d) && delete d.dataset.fpDismissed : r(d);
    });
  }, l = (c) => {
    const u = c.target.closest(".VPNavBarMenuGroup");
    u && !(c.relatedTarget instanceof Node && u.contains(c.relatedTarget)) && delete u.dataset.fpDismissed;
  }, s = () => t().forEach((c) => {
    (n(c)?.getAttribute("aria-expanded") === "true" || c.matches(":hover")) && r(c);
  });
  return document.addEventListener("keydown", a, !0), document.addEventListener("pointerdown", i, !0), document.addEventListener("pointerover", l, !0), window.addEventListener("scroll", s, { passive: !0 }), () => {
    document.removeEventListener("keydown", a, !0), document.removeEventListener("pointerdown", i, !0), document.removeEventListener("pointerover", l, !0), window.removeEventListener("scroll", s), t().forEach((c) => delete c.dataset.fpDismissed);
  };
}
function Jm() {
  const t = gp(), n = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches, r = () => document.querySelector(".VPDoc .content, .VPPage");
  let a, i;
  const l = /* @__PURE__ */ new Map(), s = () => {
    for (const [u, d] of l) u.isConnected || (d.destroy(), l.delete(u));
    for (const u of document.querySelectorAll(".VPNavBarMenu,#VPSidebarNav"))
      l.has(u) || l.set(u, wi(u, u.matches(".VPNavBarMenu") ? { active: ".VPNavBarMenuLink.active,.VPNavBarMenuGroup.active", inset: 12 } : { active: ".VPSidebarItem.level-1.is-active > .item", surface: !0 }));
  }, c = () => {
    s(), i?.disconnect();
    const u = document.querySelectorAll("[data-fp-reveal]");
    if (n() || !("IntersectionObserver" in window)) {
      u.forEach((d) => {
        d.dataset.fpReveal = "visible";
      });
      return;
    }
    i = new IntersectionObserver((d) => {
      for (const p of d) p.isIntersecting && (p.target.dataset.fpReveal = "visible", i?.unobserve(p.target));
    }, { threshold: 0.08 }), u.forEach((d) => {
      d.dataset.fpReveal !== "visible" && i?.observe(d);
    });
  };
  return {
    begin() {
      a?.cancel(), n() || (a = r()?.animate([{ opacity: 1, transform: "translateY(0)" }, { opacity: 0.25, transform: "translateY(-6px)" }], { duration: 160, easing: "cubic-bezier(.4,0,1,1)" }));
    },
    complete() {
      a?.cancel(), n() || (a = r()?.animate([{ opacity: 0, transform: "translateY(12px)" }, { opacity: 1, transform: "translateY(0)" }], { duration: 440, easing: "cubic-bezier(.16,1,.3,1)" })), c();
    },
    reveal: c,
    destroy() {
      t(), a?.cancel(), i?.disconnect(), l.forEach((u) => u.destroy()), l.clear();
    }
  };
}
function Qm({ name: t, description: n, avatarUrl: r, items: a, onSelect: i, busy: l = !1 }) {
  const [s, c] = k(""), u = r && s !== r ? /* @__PURE__ */ e("img", { src: r, alt: "", referrerPolicy: "no-referrer", onError: () => c(r) }) : t.trim().slice(0, 1).toUpperCase() || "我";
  return /* @__PURE__ */ e("span", { className: "fp-account-menu-anchor", children: /* @__PURE__ */ e(et, { label: "账号与设置", menu: !0, className: "fp-account-menu", disabled: l, trigger: /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: u }), children: (d) => /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ o("div", { className: "fp-account-menu-identity", children: [
      /* @__PURE__ */ e("span", { className: "fp-account-avatar", "aria-hidden": "true", children: u }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: t }),
        n && /* @__PURE__ */ e("small", { children: n })
      ] })
    ] }),
    a.map((p) => /* @__PURE__ */ e("div", { className: p.separator ? "fp-account-menu-group" : void 0, children: /* @__PURE__ */ o("button", { type: "button", role: "menuitem", disabled: p.disabled, className: p.danger ? "fp-error-text" : void 0, onClick: () => {
      d(), i(p.id);
    }, children: [
      p.icon,
      /* @__PURE__ */ e("span", { children: p.label }),
      (p.detail || p.shortcut) && /* @__PURE__ */ e("small", { children: p.detail || p.shortcut })
    ] }) }, p.id))
  ] }) }) });
}
function Zm({ label: t, value: n, options: r, onChange: a }) {
  const i = ve();
  return /* @__PURE__ */ o("fieldset", { className: "fp-choice-cards", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    r.map((l) => /* @__PURE__ */ o("label", { "data-selected": n === l.value, "data-disabled": l.disabled || void 0, children: [
      /* @__PURE__ */ e("input", { type: "radio", name: i, value: l.value, checked: n === l.value, disabled: l.disabled, onChange: () => a(l.value) }),
      l.icon && /* @__PURE__ */ e("span", { className: "fp-choice-card-icon", "aria-hidden": "true", children: l.icon }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("strong", { children: l.title }),
        /* @__PURE__ */ e("small", { children: l.description })
      ] })
    ] }, l.value))
  ] });
}
function eb({ brand: t, headerActions: n, serviceName: r, request: a, completed: i, onDone: l, doneLabel: s = "返回应用", codeEntry: c, selectedIds: u = [], onSelectionChange: d, onApprove: p, onCancel: h, connections: f = [], onRevoke: m, loading: b, busy: g, error: y, onRetry: w }) {
  const [v, N] = k(""), x = Ue(() => a?.items.filter((D) => D.title.toLocaleLowerCase().includes(v.trim().toLocaleLowerCase())) || [], [v, a?.items]), C = new Set(u), I = x.length > 0 && x.every((D) => C.has(D.id)), L = a?.kind === "task", K = a?.kind === "change", S = L || K ? "内容" : "笔记本", A = () => d?.(I ? u.filter((D) => !x.some((U) => U.id === D)) : [.../* @__PURE__ */ new Set([...u, ...x.map((D) => D.id)])]);
  return /* @__PURE__ */ o("div", { className: "fp-application-access", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#access-main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-access-header", children: [
      /* @__PURE__ */ e("div", { children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "账号与外观", children: n })
    ] }),
    /* @__PURE__ */ e("main", { id: "access-main", className: a ? "fp-access-main" : "fp-access-main fp-access-management", children: b ? /* @__PURE__ */ o("section", { className: "fp-access-loading", role: "status", children: [
      /* @__PURE__ */ e(Hr, { size: 28 }),
      /* @__PURE__ */ e("h1", { children: "正在读取连接信息" }),
      /* @__PURE__ */ e("p", { children: "请稍候，马上就好。" })
    ] }) : i ? /* @__PURE__ */ o("section", { className: "fp-access-card fp-access-completed", role: "status", children: [
      /* @__PURE__ */ e(ct, { size: 40, "aria-hidden": "true" }),
      /* @__PURE__ */ e("h1", { children: i.title }),
      /* @__PURE__ */ e("p", { children: i.description }),
      l && /* @__PURE__ */ e(te, { onClick: l, children: s })
    ] }) : a ? /* @__PURE__ */ o("section", { className: "fp-access-card", "aria-labelledby": "access-title", children: [
      /* @__PURE__ */ o("header", { className: "fp-access-intro", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-symbols", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(bt, { size: 28 }) }),
          /* @__PURE__ */ e(Un, { size: 20 }),
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(gt, { size: 26 }) })
        ] }),
        /* @__PURE__ */ o("p", { className: "fp-eyebrow", children: [
          r,
          " · 应用授权"
        ] }),
        /* @__PURE__ */ e("h1", { id: "access-title", children: K ? `确认 ${a.name} 的修改？` : L ? `允许 ${a.name} 完成这项任务？` : `允许 ${a.name} 连接${r}？` }),
        /* @__PURE__ */ e("p", { children: a.purpose || (K ? "查看具体变更，确认后助手将继续执行。" : L ? "助手申请以下内容和操作，确认后即可继续。" : "选择允许访问的笔记本，让它在你指定的范围内提供帮助。") }),
        a.returnLabel && /* @__PURE__ */ o("p", { className: "fp-access-return", children: [
          "完成后返回 ",
          a.returnLabel
        ] })
      ] }),
      a.permissions.length > 0 && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ e("h2", { children: "允许的操作" }),
        /* @__PURE__ */ e("ul", { className: "fp-access-permissions", children: a.permissions.map((D) => /* @__PURE__ */ o("li", { children: [
          /* @__PURE__ */ e(ct, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("strong", { children: D.label }),
            D.description && /* @__PURE__ */ e("p", { children: D.description })
          ] })
        ] }, D.label)) })
      ] }),
      (!a.allowEmptySelection || a.items.length > 0) && /* @__PURE__ */ o("section", { className: "fp-access-section", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-section-heading", children: [
          /* @__PURE__ */ e("h2", { children: L ? "申请访问的内容" : K ? "本次修改" : "选择笔记本" }),
          /* @__PURE__ */ o("span", { role: "status", children: [
            "已选 ",
            u.length,
            " 项"
          ] })
        ] }),
        /* @__PURE__ */ o("label", { className: "fp-access-search", children: [
          /* @__PURE__ */ e(We, { size: 18, "aria-hidden": "true" }),
          /* @__PURE__ */ e("input", { className: "fp-input", "aria-label": `搜索${S}`, placeholder: `搜索${S}`, value: v, onChange: (D) => N(D.target.value) })
        ] }),
        a.items.length > 0 ? /* @__PURE__ */ o(Q, { children: [
          /* @__PURE__ */ o("div", { className: "fp-access-select", children: [
            /* @__PURE__ */ e("span", { children: v ? `找到 ${x.length} 项内容` : `只访问你选中的${S}` }),
            !K && /* @__PURE__ */ e(te, { variant: "ghost", disabled: g || !x.length, onClick: A, children: I ? "取消全选" : "全选" })
          ] }),
          /* @__PURE__ */ o("fieldset", { className: "fp-access-items", disabled: g, children: [
            /* @__PURE__ */ e("legend", { className: "fp-visually-hidden", children: "可访问的内容" }),
            x.map((D) => /* @__PURE__ */ o("label", { "data-selected": C.has(D.id), children: [
              /* @__PURE__ */ e("input", { type: "checkbox", disabled: K, checked: C.has(D.id), onChange: (U) => d?.(U.target.checked ? [...u, D.id] : u.filter((j) => j !== D.id)) }),
              /* @__PURE__ */ e(bt, { size: 19, "aria-hidden": "true" }),
              /* @__PURE__ */ o("span", { className: "fp-access-item-copy", children: [
                /* @__PURE__ */ e("strong", { children: D.title }),
                D.detail && /* @__PURE__ */ e("small", { children: D.detail }),
                D.permissions && /* @__PURE__ */ e("small", { children: D.permissions.join("、") })
              ] }),
              C.has(D.id) && /* @__PURE__ */ e(ct, { size: 18, "aria-hidden": "true" })
            ] }, D.id)),
            x.length === 0 && /* @__PURE__ */ e("p", { className: "fp-access-empty", children: "没有找到匹配的内容，试试其他名称。" })
          ] })
        ] }) : /* @__PURE__ */ o("p", { className: "fp-access-empty", children: [
          "当前没有可授权的内容，请先在",
          r,
          "取得访问权限。"
        ] })
      ] }),
      a.changes && /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: "查看正文变化" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: a.changes.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: a.changes.after })
          ] })
        ] })
      ] }),
      a.changeSet?.map((D, U) => /* @__PURE__ */ o("details", { className: "fp-access-diff", children: [
        /* @__PURE__ */ e("summary", { children: D.title }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改前" }),
            /* @__PURE__ */ e("pre", { children: D.before })
          ] }),
          /* @__PURE__ */ o("section", { children: [
            /* @__PURE__ */ e("h3", { children: "修改后" }),
            /* @__PURE__ */ e("pre", { children: D.after })
          ] })
        ] })
      ] }, U)),
      /* @__PURE__ */ o("aside", { className: "fp-access-notice", children: [
        /* @__PURE__ */ e(Or, { size: 21, "aria-hidden": "true" }),
        /* @__PURE__ */ e("p", { children: a.notice || "授权有效期为 30 天，包含所选笔记本中后续新增的内容。你可以随时在“外部连接”撤销访问。" })
      ] }),
      y && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        /* @__PURE__ */ e("p", { children: y }),
        w && /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: w, children: "重试" })
      ] }),
      /* @__PURE__ */ o("footer", { className: "fp-access-actions", children: [
        /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: h, children: "取消" }),
        /* @__PURE__ */ e(te, { "aria-label": K ? "确认修改" : L ? "同意并继续" : "允许连接", loading: g, disabled: b || !a.allowEmptySelection && !u.length, onClick: p, children: K ? "确认修改" : L ? "同意并继续" : "允许连接" })
      ] })
    ] }) : /* @__PURE__ */ o(Q, { children: [
      c && /* @__PURE__ */ o("form", { className: "fp-access-device-entry", onSubmit: (D) => {
        D.preventDefault(), c.onSubmit();
      }, children: [
        /* @__PURE__ */ e("label", { htmlFor: "access-device-code", children: "连接新设备" }),
        /* @__PURE__ */ e("p", { children: "输入终端中显示的设备代码。" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("input", { className: "fp-input", id: "access-device-code", value: c.value, onChange: (D) => c.onChange(D.target.value), placeholder: "ABCD-EFGH", autoComplete: "off", spellCheck: !1, maxLength: 9 }),
          /* @__PURE__ */ e(te, { type: "submit", disabled: c.value.replace(/-/g, "").trim().length !== 8, children: "继续" })
        ] })
      ] }),
      /* @__PURE__ */ o("header", { className: "fp-access-list-heading", children: [
        /* @__PURE__ */ e("span", { className: "fp-access-list-icon", children: /* @__PURE__ */ e(gt, { size: 28 }) }),
        /* @__PURE__ */ e("h1", { children: "已连接的应用" }),
        /* @__PURE__ */ o("p", { children: [
          "查看哪些应用可以访问你的",
          r,
          "内容，并随时管理连接。"
        ] })
      ] }),
      y && /* @__PURE__ */ o("div", { className: "fp-access-error", role: "alert", children: [
        y,
        w && /* @__PURE__ */ e(te, { variant: "secondary", onClick: w, children: "重试" })
      ] }),
      f.length ? /* @__PURE__ */ e("div", { className: "fp-access-connections", children: f.map((D) => /* @__PURE__ */ o("section", { className: "fp-access-connection", children: [
        /* @__PURE__ */ o("div", { className: "fp-access-connection-title", children: [
          /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(gt, { size: 22 }) }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("h2", { children: D.name }),
            /* @__PURE__ */ e("p", { "data-status": D.status, children: D.status === "active" ? "已连接" : D.status === "revoked" ? "已撤销" : "已过期" })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { children: D.permissions }),
        /* @__PURE__ */ e("p", { className: "fp-access-detail", children: D.detail }),
        D.status === "active" && /* @__PURE__ */ e(te, { variant: "secondary", disabled: g, onClick: () => m?.(D.id), children: "撤销连接" })
      ] }, D.id)) }) : !y && /* @__PURE__ */ o("section", { className: "fp-access-empty-state", children: [
        /* @__PURE__ */ e(bt, { size: 32 }),
        /* @__PURE__ */ e("h2", { children: "从第一个连接开始" }),
        /* @__PURE__ */ e("p", { children: "通过 CLI 或支持的 AI 助手发起连接，授权后会显示在这里。" })
      ] })
    ] }) })
  ] });
}
function tb({ brand: t, showStatusIcon: n = !0, preview: r, productIcon: a, headerActions: i, onDrag: l, phase: s, transitionKey: c, title: u, description: d, version: p, progress: h, progressLabel: f, detail: m, children: b, actions: g, footer: y }) {
  const w = s + ":" + (c || ""), v = B(null), N = B(w);
  Y(() => {
    if (N.current === w) return;
    N.current = w;
    const K = v.current;
    if (!K || typeof K.animate != "function" || window.matchMedia?.("(prefers-reduced-motion:reduce)").matches) return;
    const S = K.animate([{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }], { duration: 320, easing: "cubic-bezier(.22,1,.36,1)" });
    return () => S.cancel();
  }, [w]);
  const x = ["checking", "verifying", "installing"].includes(s), C = s === "downloading" && Number.isFinite(h), I = Math.max(0, Math.min(100, C ? h : 0)), L = f || (s === "checking" ? "正在连接下载服务" : s === "verifying" ? "正在检查文件完整性" : s === "installing" ? "正在安装到此电脑" : "正在下载");
  return /* @__PURE__ */ o("div", { className: "fp-installer", "data-phase": s, "data-preview": !!r, children: [
    /* @__PURE__ */ o("header", { onMouseDown: (K) => {
      K.target.closest("button,a,input") || l?.();
    }, children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: i })
    ] }),
    /* @__PURE__ */ o("main", { children: [
      r && /* @__PURE__ */ e("aside", { className: "fp-installer-preview", children: r }),
      /* @__PURE__ */ o("section", { ref: v, className: "fp-installer-content", children: [
        /* @__PURE__ */ o("div", { className: "fp-installer-heading", children: [
          n && /* @__PURE__ */ e("div", { className: "fp-installer-art", "aria-hidden": "true", children: s === "ready" && a ? a : x ? /* @__PURE__ */ e(Rt, { size: 28 }) : s === "done" ? /* @__PURE__ */ e(ct, { size: 28 }) : s === "error" || s === "confirm" ? /* @__PURE__ */ e(Rr, { size: 28 }) : s === "downloading" ? /* @__PURE__ */ e(Cn, { size: 28 }) : /* @__PURE__ */ e(Do, { size: 28 }) }),
          /* @__PURE__ */ o("div", { children: [
            p && /* @__PURE__ */ o("p", { className: "fp-installer-version", children: [
              "版本 ",
              p
            ] }),
            /* @__PURE__ */ e("h1", { children: u })
          ] })
        ] }),
        /* @__PURE__ */ e("p", { className: "fp-installer-description", role: s === "error" ? "alert" : "status", children: d }),
        (x || s === "downloading") && /* @__PURE__ */ o("div", { className: "fp-installer-progress", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ e("span", { children: L }),
            C && /* @__PURE__ */ o("strong", { children: [
              Math.round(I),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": s === "downloading" ? "安装文件下载进度" : L, "data-indeterminate": !C, "aria-valuenow": C ? I : void 0, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: C ? { width: `${I}%` } : void 0 }) })
        ] }),
        m && /* @__PURE__ */ e("p", { className: "fp-installer-detail", children: m }),
        b,
        /* @__PURE__ */ e("div", { className: "fp-installer-actions", children: g })
      ] })
    ] }),
    y && /* @__PURE__ */ e("footer", { children: y })
  ] });
}
function nb({ cards: t, activeId: n, onSelect: r }) {
  const a = t.find((d) => d.id === n) || t[0], i = B(a?.id), [l, s] = k();
  if (Y(() => {
    if (!a || i.current === a.id) return;
    s(i.current), i.current = a.id;
    const d = setTimeout(() => s(void 0), 650);
    return () => clearTimeout(d);
  }, [a?.id]), !a) return null;
  const c = t.find((d) => d.id === l), u = (d) => /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: d.label }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-feature-card-copy", children: [
      /* @__PURE__ */ e("h2", { children: d.title }),
      /* @__PURE__ */ e("p", { children: d.description })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-preview", children: d.children })
  ] });
  return /* @__PURE__ */ o("section", { className: "fp-feature-stack", "aria-label": "产品功能预览", children: [
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back", "aria-hidden": "true" }),
    /* @__PURE__ */ e("div", { className: "fp-feature-card-back fp-feature-card-back-second", "aria-hidden": "true" }),
    c && /* @__PURE__ */ e("article", { className: "fp-feature-card-out", "aria-hidden": "true", children: u(c) }, "out-" + c.id),
    /* @__PURE__ */ e("article", { className: "fp-feature-card-front", "data-motion": a.motion, "aria-label": a.title, children: u(a) }, a.id),
    /* @__PURE__ */ e("footer", { "aria-hidden": r ? void 0 : !0, role: r ? "group" : void 0, "aria-label": r ? "产品卡片切换" : void 0, children: t.map((d) => r ? /* @__PURE__ */ e("button", { type: "button", "aria-label": "查看" + d.label, "aria-pressed": d.id === a.id, onClick: () => r(d.id), children: /* @__PURE__ */ e("i", { "data-active": d.id === a.id, "aria-hidden": "true" }) }, d.id) : /* @__PURE__ */ e("i", { "data-active": d.id === a.id }, d.id)) })
  ] });
}
function rb({ brand: t, navigation: n, actions: r, groups: a, currentPath: i, outline: l = [], children: s, footer: c, wide: u = !1 }) {
  const d = B(null), [p, h] = k(!1);
  Y(() => {
    if (!p) return;
    const g = document.body.style.overflow;
    return document.body.style.overflow = "hidden", () => {
      document.body.style.overflow = g;
    };
  }, [p]);
  const f = a.filter((g) => g.prefix ? i.startsWith(g.prefix) : g.links.some((y) => y.href === i)), m = f.length ? f : a.filter((g) => !g.prefix), b = /* @__PURE__ */ e("nav", { "aria-label": "文档章节", children: m.map((g) => /* @__PURE__ */ o("section", { children: [
    /* @__PURE__ */ e("h2", { children: g.label }),
    g.links.map((y) => /* @__PURE__ */ e("a", { href: y.href, "aria-current": y.href === i ? "page" : void 0, children: y.label }, y.href))
  ] }, g.label)) });
  return /* @__PURE__ */ o("div", { className: "fp-docs", "data-wide": u || void 0, children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ o("header", { className: "fp-docs-header", children: [
      /* @__PURE__ */ e("div", { className: "fp-docs-brand", children: t }),
      /* @__PURE__ */ e("nav", { "aria-label": "主导航", children: n }),
      /* @__PURE__ */ o("div", { className: "fp-docs-actions", children: [
        r,
        /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "打开文档目录", className: "fp-docs-menu", onClick: () => {
          d.current?.showModal(), h(!0);
        }, children: /* @__PURE__ */ e(rn, { size: 20 }) })
      ] })
    ] }),
    /* @__PURE__ */ o("dialog", { ref: d, onClose: () => h(!1), className: "fp-docs-drawer", onClick: (g) => {
      g.target === g.currentTarget && d.current?.close();
    }, children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: "文档目录" }),
        /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "关闭文档目录", onClick: () => d.current?.close(), children: /* @__PURE__ */ e(ge, { size: 20 }) })
      ] }),
      /* @__PURE__ */ e("nav", { className: "fp-docs-section-nav", "aria-label": "选择文档分区", children: n }),
      b,
      l.length > 0 && /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ e("summary", { children: "本页目录" }),
        l.map((g) => /* @__PURE__ */ e("a", { href: g.href, onClick: () => d.current?.close(), children: g.label }, g.href))
      ] })
    ] }),
    !u && /* @__PURE__ */ o("div", { className: "fp-docs-mobile-bar", children: [
      /* @__PURE__ */ o(te, { variant: "ghost", onClick: () => {
        d.current?.showModal(), h(!0);
      }, children: [
        /* @__PURE__ */ e(rn, { size: 16 }),
        m[0]?.label || "文档目录"
      ] }),
      l.length > 0 && /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ o("summary", { children: [
          /* @__PURE__ */ e(nn, { size: 16 }),
          "本页目录"
        ] }),
        /* @__PURE__ */ e("nav", { children: l.map((g) => /* @__PURE__ */ e("a", { href: g.href, onClick: (y) => y.currentTarget.closest("details")?.removeAttribute("open"), children: g.label }, g.href)) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-docs-grid", children: [
      !u && /* @__PURE__ */ e("aside", { className: "fp-docs-sidebar", children: b }),
      /* @__PURE__ */ e("main", { id: "main", className: "fp-docs-main", children: s }),
      !u && l.length > 0 && /* @__PURE__ */ e("aside", { className: "fp-docs-outline", children: /* @__PURE__ */ o("nav", { "aria-label": "本页目录", children: [
        /* @__PURE__ */ e("strong", { children: "本页目录" }),
        l.map((g) => /* @__PURE__ */ e("a", { href: g.href, children: g.label }, g.href))
      ] }) })
    ] }),
    c && /* @__PURE__ */ e("footer", { className: "fp-docs-footer", children: c })
  ] });
}
function ab({ items: t, label: n = "浏览文档" }) {
  const [r, a] = k(""), i = t.filter((l) => (l.label + " " + (l.description || "")).toLocaleLowerCase().includes(r.trim().toLocaleLowerCase()));
  return /* @__PURE__ */ o("section", { className: "fp-docs-directory", "aria-label": n, children: [
    /* @__PURE__ */ o("label", { children: [
      n,
      /* @__PURE__ */ e("input", { type: "search", value: r, onChange: (l) => a(l.target.value), placeholder: "输入名称查找" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-docs-cards", children: i.map((l) => /* @__PURE__ */ o("a", { href: l.href, children: [
      /* @__PURE__ */ e("strong", { children: l.label }),
      l.description && /* @__PURE__ */ e("span", { children: l.description }),
      /* @__PURE__ */ e("span", { children: "阅读指南 →" })
    ] }, l.href)) }),
    !i.length && /* @__PURE__ */ e("p", { role: "status", children: "没有找到相关内容，请换个名称试试。" })
  ] });
}
function ib({ size: t = 32, decorative: n = !1, label: r = "AI 批改助手" }) {
  const a = ve();
  return /* @__PURE__ */ o("svg", { width: t, height: t, viewBox: "0 0 40 40", fill: "none", role: n ? void 0 : "img", "aria-hidden": n || void 0, "aria-labelledby": n ? void 0 : a, style: { flexShrink: 0 }, children: [
    !n && /* @__PURE__ */ e("title", { id: a, children: r }),
    /* @__PURE__ */ e("rect", { x: "2", y: "2", width: "36", height: "36", rx: "11", fill: "var(--fp-action,#13795B)" }),
    /* @__PURE__ */ e("path", { d: "M12 10h12l5 5v15H12V10Z", stroke: "var(--fp-on-action,#FFFFFF)", strokeWidth: "2", strokeLinejoin: "round" }),
    /* @__PURE__ */ e("path", { d: "M24 10v6h5M16 23l3 3 6-7", stroke: "var(--fp-on-action,#FFFFFF)", strokeWidth: "2.4", strokeLinecap: "round", strokeLinejoin: "round" }),
    /* @__PURE__ */ e("path", { d: "m31 3 1.5 3.5L36 8l-3.5 1.5L31 13l-1.5-3.5L26 8l3.5-1.5L31 3Z", fill: "#FD8B07", stroke: "var(--fp-bg,#FFFFFF)", strokeWidth: "1.2" })
  ] });
}
function vp(t, n) {
  const r = n.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return r.length ? t.map((a) => {
    const i = (a.title + " " + (a.heading || "")).toLocaleLowerCase(), l = a.text.toLocaleLowerCase(), s = r.reduce((c, u) => c + (i.includes(u) ? 30 : 0) + (l.includes(u) ? 1 : 0), 0);
    return { entry: a, score: s, match: r.every((c) => i.includes(c) || l.includes(c)) };
  }).filter((a) => a.match).sort((a, i) => i.score - a.score).slice(0, 30).map((a) => a.entry) : [];
}
function lb({ open: t, onClose: n, entries: r, loading: a, error: i, onRetry: l, initialQuery: s = "" }) {
  const c = B(null), u = B(null), [d, p] = k(s), [h, f] = k(0), m = Ue(() => vp(r, d), [r, d]);
  Y(() => {
    if (t)
      return c.current?.showModal(), u.current?.focus(), () => {
        c.current?.close();
      };
  }, [t]), Y(() => {
    f(0);
  }, [d]), Y(() => {
    s && p(s);
  }, [s]), Y(() => {
    c.current?.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: "nearest" });
  }, [h]);
  const b = (g) => {
    const y = d.trim();
    if (!y) return g;
    const w = g.toLocaleLowerCase().indexOf(y.toLocaleLowerCase());
    return w < 0 ? g : /* @__PURE__ */ o(Q, { children: [
      g.slice(0, w),
      /* @__PURE__ */ e("mark", { children: g.slice(w, w + y.length) }),
      g.slice(w + y.length)
    ] });
  };
  return /* @__PURE__ */ o("dialog", { ref: c, className: "fp-docs-search", "aria-label": "搜索文档", onClose: n, onClick: (g) => {
    g.target === g.currentTarget && n();
  }, children: [
    /* @__PURE__ */ o("div", { className: "fp-docs-search-field", children: [
      /* @__PURE__ */ e(We, { size: 22 }),
      /* @__PURE__ */ e("input", { ref: u, "aria-label": "搜索关键词", role: "combobox", "aria-expanded": !!m.length, "aria-controls": "docs-search-results", "aria-activedescendant": m.length ? "docs-result-" + h : void 0, autoComplete: "off", placeholder: "搜索教程、平台和常见问题", value: d, onChange: (g) => p(g.target.value), onKeyDown: (g) => {
        (g.key === "ArrowDown" || g.key === "ArrowUp") && (g.preventDefault(), f((y) => m.length ? (y + (g.key === "ArrowDown" ? 1 : -1) + m.length) % m.length : 0)), g.key === "Enter" && !g.nativeEvent.isComposing && m[h] && window.location.assign(m[h].url);
      } }),
      d && /* @__PURE__ */ e(te, { variant: "ghost", "aria-label": "清空搜索", onClick: () => {
        p(""), u.current?.focus();
      }, children: /* @__PURE__ */ e(ge, { size: 16 }) }),
      /* @__PURE__ */ e(te, { variant: "ghost", onClick: n, "aria-label": "关闭搜索", children: "关闭" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-docs-search-results", id: "docs-search-results", role: "listbox", "aria-label": "搜索结果", "aria-busy": a, children: i ? /* @__PURE__ */ o("div", { className: "fp-docs-search-empty", role: "alert", children: [
      "搜索暂时无法加载。",
      /* @__PURE__ */ e(te, { onClick: l, children: "重新加载" })
    ] }) : a ? /* @__PURE__ */ e("p", { className: "fp-docs-search-empty", role: "status", children: "正在准备搜索…" }) : d.trim() ? m.length ? m.map((g, y) => {
      const w = Math.max(0, g.text.toLocaleLowerCase().indexOf(d.trim().toLocaleLowerCase()) - 36);
      return /* @__PURE__ */ o("a", { role: "option", "aria-selected": y === h, id: "docs-result-" + y, className: "fp-docs-search-result", href: g.url, onMouseEnter: () => f(y), children: [
        /* @__PURE__ */ o("small", { children: [
          g.group,
          " / ",
          g.title
        ] }),
        /* @__PURE__ */ o("strong", { children: [
          /* @__PURE__ */ e("span", { children: b(g.heading || g.title) }),
          /* @__PURE__ */ e(Dr, { size: 16 })
        ] }),
        /* @__PURE__ */ e("span", { children: b(g.text.slice(w, w + 130)) })
      ] }, g.url);
    }) : /* @__PURE__ */ e("p", { className: "fp-docs-search-empty", role: "status", children: "没有找到相关内容，试试更简短的关键词。" }) : /* @__PURE__ */ o("div", { className: "fp-docs-search-empty", children: [
      /* @__PURE__ */ e("strong", { children: "你想了解什么？" }),
      /* @__PURE__ */ e("p", { children: "试试搜索「安装」「API 密钥」或你的阅卷平台。" }),
      /* @__PURE__ */ e("div", { children: ["安装", "API 密钥", "评分标准", "智学网"].map((g) => /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => {
        p(g), u.current?.focus();
      }, children: g }, g)) })
    ] }) }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("span", { role: "status", children: d.trim() && !a && !i ? `${m.length} 条相关结果` : "搜索全部文档" }),
      /* @__PURE__ */ e("span", { children: "↑ ↓ 选择 · Enter 打开 · Esc 关闭" })
    ] })
  ] });
}
function ob({ eyebrow: t, title: n, statement: r, description: a, actions: i, meta: l, preview: s, pattern: c = "CREATE" }) {
  return /* @__PURE__ */ o("section", { className: "fp-statement-hero", "data-layout": s ? "split" : "centered", children: [
    /* @__PURE__ */ e("div", { className: "fp-statement-pattern", "aria-hidden": "true", children: Array.from({ length: 4 }, (u, d) => /* @__PURE__ */ e("div", { children: Array.from({ length: 4 }, (p, h) => /* @__PURE__ */ e("span", { children: c }, h)) }, d)) }),
    /* @__PURE__ */ e("div", { className: "fp-statement-scan", "aria-hidden": "true" }),
    /* @__PURE__ */ o("div", { className: "fp-statement-copy", children: [
      /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      /* @__PURE__ */ e("p", { className: "fp-statement-subtitle", children: r }),
      /* @__PURE__ */ e("p", { className: "fp-statement-description", children: a }),
      /* @__PURE__ */ e("div", { className: "fp-statement-actions", children: i })
    ] }),
    l && /* @__PURE__ */ e("div", { className: "fp-statement-meta", "aria-label": "核心能力", children: l }),
    s && /* @__PURE__ */ e("div", { className: "fp-statement-preview", children: s })
  ] });
}
function sb({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-editorial-sections", children: t });
}
function cb({ kind: t, children: n, label: r }) {
  return /* @__PURE__ */ e("section", { className: "fp-editorial-panel" + (t ? " fp-editorial-panel--" + t : ""), "aria-label": r, children: n });
}
const Te = (t) => String(t).replace(/[&<>"']/g, (n) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[n]), hr = (t = []) => t.map((n) => `<span id="${Te(n)}" class="fp-release-anchor" aria-hidden="true"></span>`).join("");
function yp({ version: t, versionId: n, date: r, badge: a, description: i, groups: l, emptyMessage: s = "暂无新增更新", history: c = [], historyLabel: u = "历史稳定版本", anchors: d = [] }) {
  const p = l.filter((f) => f.items.length).map((f) => `<section class="fp-release-group"><h3>${Te(f.title)}</h3><ul>${f.items.map((m) => `<li${m.id ? ` id="${Te(m.id)}"` : ""}>${hr(m.aliases)}${Te(m.text)}</li>`).join("")}</ul></section>`).join(""), h = c.length ? `<details class="fp-release-archive"><summary>${Te(u)}<span>${c.length}</span></summary><div>${c.map((f) => `<details class="fp-release-history-item"${f.id ? ` id="${Te(f.id)}"` : ""}><summary><strong>v${Te(f.version)}</strong>${f.date ? `<time>${Te(f.date)}</time>` : ""}</summary>${hr(f.aliases)}<ul>${f.items.map((m) => `<li>${Te(m)}</li>`).join("")}</ul></details>`).join("")}</div></details>` : "";
  return `<article class="fp-release-notes">${hr(d)}<header><div><strong${n ? ` id="${Te(n)}"` : ""}>v${Te(t)}</strong><span class="fp-release-badge">${Te(a)}</span></div>${r ? `<time datetime="${Te(r)}">${Te(r)}</time>` : ""}<p>${Te(i)}</p></header><div class="fp-release-groups">${p || `<p class="fp-release-empty">${Te(s)}</p>`}</div>${h}</article>`;
}
function db(t) {
  return /* @__PURE__ */ e("div", { dangerouslySetInnerHTML: { __html: yp(t) } });
}
function ub({ variant: t = "primary", size: n = "md", className: r = "", ...a }) {
  return /* @__PURE__ */ e("a", { ...a, className: `fp-button fp-button-link fp-${t} fp-${n} ${r}` });
}
function pb({ brand: t, eyebrow: n, title: r, description: a, benefits: i = [], children: l, actions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-app-entry", children: [
    /* @__PURE__ */ o("section", { className: "fp-app-entry-story", children: [
      /* @__PURE__ */ e("div", { className: "fp-app-entry-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-app-entry-copy", children: [
        n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
        /* @__PURE__ */ e("h1", { children: r }),
        /* @__PURE__ */ e("p", { children: a }),
        /* @__PURE__ */ e("ul", { children: i.map((u) => /* @__PURE__ */ o("li", { children: [
          u.icon,
          /* @__PURE__ */ e("span", { children: u.label })
        ] }, u.label)) })
      ] }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-app-entry-panel", children: [
      s && /* @__PURE__ */ e("div", { className: "fp-app-entry-window", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-app-entry-content", children: l })
    ] })
  ] });
}
function hb({ brand: t, title: n, description: r, tone: a = "neutral", children: i, actions: l, headerActions: s, footer: c }) {
  return /* @__PURE__ */ o("main", { className: "fp-status-page", children: [
    /* @__PURE__ */ o("header", { className: "fp-status-page-header", children: [
      t,
      /* @__PURE__ */ e("div", { children: s })
    ] }),
    /* @__PURE__ */ o("section", { className: "fp-status-card", "data-tone": a, "aria-labelledby": "status-heading", children: [
      /* @__PURE__ */ e("div", { className: "fp-status-symbol", "aria-hidden": "true", children: a === "success" ? /* @__PURE__ */ e(ct, { size: 32 }) : a === "loading" ? /* @__PURE__ */ e(Rt, { size: 32 }) : /* @__PURE__ */ e(Rr, { size: 32 }) }),
      /* @__PURE__ */ e("h1", { id: "status-heading", children: n }),
      /* @__PURE__ */ e("p", { className: "fp-status-description", role: a === "error" ? "alert" : "status", children: r }),
      i,
      l && /* @__PURE__ */ e("div", { className: "fp-status-actions", children: l }),
      c && /* @__PURE__ */ e("footer", { children: c })
    ] })
  ] });
}
function fb({ brand: t, navigation: n, headerActions: r, eyebrow: a, title: i, description: l, actions: s, meta: c, preview: u, children: d, footer: p }) {
  return /* @__PURE__ */ o("div", { className: "fp-product-landing", children: [
    /* @__PURE__ */ e("a", { className: "fp-skip-link", href: "#main", children: "跳到主要内容" }),
    /* @__PURE__ */ e("header", { className: "fp-product-header", children: /* @__PURE__ */ o("div", { className: "fp-product-header-inner", children: [
      t,
      /* @__PURE__ */ e("nav", { "aria-label": "页面导航", children: n }),
      /* @__PURE__ */ e("div", { className: "fp-product-header-actions", children: r })
    ] }) }),
    /* @__PURE__ */ o("main", { id: "main", children: [
      /* @__PURE__ */ o("section", { className: "fp-product-hero", children: [
        /* @__PURE__ */ o("div", { className: "fp-product-hero-copy", children: [
          a && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: a }),
          /* @__PURE__ */ e("h1", { children: i }),
          /* @__PURE__ */ e("p", { className: "fp-product-description", children: l }),
          /* @__PURE__ */ e("div", { className: "fp-product-actions", children: s }),
          c && /* @__PURE__ */ e("div", { className: "fp-product-meta", children: c })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-product-preview", children: u })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("footer", { className: "fp-product-footer", children: p })
  ] });
}
function mb({ id: t, eyebrow: n, title: r, description: a, children: i }) {
  return /* @__PURE__ */ o("section", { id: t, className: "fp-product-section", children: [
    /* @__PURE__ */ o("header", { children: [
      n && /* @__PURE__ */ e("p", { className: "fp-eyebrow", children: n }),
      /* @__PURE__ */ e("h2", { children: r }),
      a && /* @__PURE__ */ e("p", { children: a })
    ] }),
    i
  ] });
}
function bb({ items: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-product-features", children: t.map((n) => /* @__PURE__ */ o("article", { children: [
    /* @__PURE__ */ e("div", { className: "fp-product-feature-icon", children: n.icon }),
    /* @__PURE__ */ e("h3", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function gb({ brand: t = "课栈笔记", label: n = "正在打开工作区", actions: r }) {
  return /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton", role: "status", "aria-label": n, "aria-busy": "true", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("div", { children: r })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-workspace-skeleton-body", children: [
      /* @__PURE__ */ o("aside", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] }),
      /* @__PURE__ */ o("section", { children: [
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {}),
        /* @__PURE__ */ e("i", {})
      ] })
    ] })
  ] });
}
function vb({ phase: t, title: n, description: r, currentVersion: a, version: i, notes: l, progress: s = 0, required: c = !1, compact: u = !1, actions: d }) {
  const p = Math.max(0, Math.min(100, Number.isFinite(s) ? s : 0));
  return /* @__PURE__ */ o("section", { className: "fp-update-panel", "data-phase": t, "data-compact": u || void 0, children: [
    /* @__PURE__ */ o("div", { className: "fp-update-art", "aria-hidden": "true", children: [
      /* @__PURE__ */ e("span", { children: ["checking", "preparing", "verifying", "installing"].includes(t) ? /* @__PURE__ */ e(Rt, { size: 34 }) : t === "error" ? /* @__PURE__ */ e(Rr, { size: 34 }) : t === "ready" || t === "current" ? /* @__PURE__ */ e(ct, { size: 34 }) : t === "downloading" ? /* @__PURE__ */ e(Cn, { size: 34 }) : /* @__PURE__ */ e(qn, { size: 34 }) }),
      /* @__PURE__ */ e("i", {}),
      /* @__PURE__ */ e("i", {})
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-update-heading", children: [
      c && /* @__PURE__ */ e("span", { className: "fp-update-required", children: "需要更新" }),
      /* @__PURE__ */ e("h3", { children: n }),
      /* @__PURE__ */ e("p", { role: t === "error" ? "alert" : "status", children: r })
    ] }),
    (a || i) && /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: a || "—" })
      ] }),
      i && /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e(Un, { size: 18, "aria-hidden": "true" }),
        /* @__PURE__ */ o("span", { children: [
          /* @__PURE__ */ e("small", { children: "最新版本" }),
          /* @__PURE__ */ e("strong", { children: i })
        ] })
      ] })
    ] }),
    l && /* @__PURE__ */ o("section", { className: "fp-update-notes", children: [
      /* @__PURE__ */ e("h4", { children: "本次更新" }),
      /* @__PURE__ */ e("p", { children: l })
    ] }),
    t === "downloading" && /* @__PURE__ */ o("div", { className: "fp-update-progress", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { children: "正在下载" }),
        /* @__PURE__ */ o("strong", { children: [
          Math.round(p),
          "%"
        ] })
      ] }),
      /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": "更新下载进度", "aria-valuenow": p, "aria-valuemin": 0, "aria-valuemax": 100, children: /* @__PURE__ */ e("i", { style: { width: `${p}%` } }) })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-update-actions", children: d })
  ] });
}
function yb({ tasks: t, title: n = "传输任务", variant: r = "panel", showHeader: a = !0, onCancel: i, onRetry: l, onDismiss: s, onOpen: c, onReveal: u, headerActions: d, collapsed: p = !1, onCollapsedChange: h }) {
  const f = t.filter((m) => m.status === "queued" || m.status === "active").length;
  return p ? /* @__PURE__ */ o(te, { className: "fp-transfer-summary", variant: "secondary", "aria-label": `展开${n}（${t.length}）`, "aria-expanded": !1, onClick: () => h?.(!1), children: [
    /* @__PURE__ */ e(Cn, { size: 17 }),
    /* @__PURE__ */ e("span", { children: f ? `${f} 项传输中` : `${t.length} 项传输记录` })
  ] }) : /* @__PURE__ */ o("section", { className: "fp-upload-queue fp-transfer-queue", "aria-label": n, "data-variant": r, children: [
    a && /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: n }),
        /* @__PURE__ */ e("span", { children: f ? `${f} 项进行中` : "传输记录" })
      ] }),
      d
    ] }),
    /* @__PURE__ */ e("ul", { children: t.map((m) => {
      const b = Math.max(0, Math.min(100, Number.isFinite(m.progress) ? m.progress : 0)), g = m.direction === "download" ? "下载" : "上传";
      return /* @__PURE__ */ o("li", { "data-status": m.status, children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", "aria-hidden": "true", children: m.status === "done" ? /* @__PURE__ */ e(Pe, { size: 17 }) : m.direction === "download" ? /* @__PURE__ */ e(Cn, { size: 17 }) : /* @__PURE__ */ e(Po, { size: 17 }) }),
        /* @__PURE__ */ o("div", { className: "fp-upload-info", children: [
          /* @__PURE__ */ e("strong", { title: m.name, children: m.name }),
          /* @__PURE__ */ e("span", { children: m.detail || (m.status === "queued" ? `等待${g}` : m.status === "done" ? `${g}完成` : m.status === "cancelled" ? "已取消" : m.status === "error" ? `${g}未完成` : `正在${g}${m.indeterminate ? "" : ` ${Math.round(b)}%`}`) }),
          m.status === "active" && /* @__PURE__ */ e("div", { role: "progressbar", "aria-label": `${m.name}${g}进度`, "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": m.indeterminate ? void 0 : b, className: "fp-upload-progress", "data-indeterminate": m.indeterminate, children: /* @__PURE__ */ e("i", { style: { width: m.indeterminate ? "40%" : `${b}%` } }) })
        ] }),
        /* @__PURE__ */ o("div", { className: "fp-upload-actions", children: [
          m.direction === "download" && m.status === "done" && /* @__PURE__ */ o(Q, { children: [
            c && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `打开 ${m.name}`, onClick: () => c(m), children: "打开" }),
            u && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `定位 ${m.name}`, onClick: () => u(m), children: /* @__PURE__ */ e(ii, { size: 15 }) })
          ] }),
          ["queued", "active"].includes(m.status) && m.cancellable !== !1 && i && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `取消${g} ${m.name}`, onClick: () => i(m), children: /* @__PURE__ */ e(ge, { size: 15 }) }),
          ["error", "cancelled"].includes(m.status) && m.retryable !== !1 && l && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `重试${g} ${m.name}`, onClick: () => l(m), children: /* @__PURE__ */ e(li, { size: 15 }) }),
          ["done", "error", "cancelled"].includes(m.status) && s && /* @__PURE__ */ e(te, { variant: "ghost", size: "sm", "aria-label": `移除记录 ${m.name}`, onClick: () => s(m), children: /* @__PURE__ */ e(ge, { size: 15 }) })
        ] })
      ] }, m.id);
    }) })
  ] });
}
function wb({ title: t, subtitle: n, leading: r, actions: a, onBack: i }) {
  return /* @__PURE__ */ o("header", { className: "fp-touch-header", children: [
    i ? /* @__PURE__ */ e("button", { type: "button", onClick: i, "aria-label": "返回", children: /* @__PURE__ */ e(Br, { size: 22 }) }) : r,
    /* @__PURE__ */ o("div", { className: "fp-touch-heading", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    a && /* @__PURE__ */ e("div", { className: "fp-touch-header-actions", children: a })
  ] });
}
function kb({ title: t, description: n, action: r, children: a }) {
  return /* @__PURE__ */ o("section", { className: "fp-touch-section", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("h2", { children: t }),
        n && /* @__PURE__ */ e("p", { children: n })
      ] }),
      r
    ] }),
    a
  ] });
}
function Nb({ items: t, label: n = "快捷操作" }) {
  return /* @__PURE__ */ e("div", { className: "fp-touch-actions", "aria-label": n, children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", disabled: r.disabled, onClick: r.onClick, children: [
    /* @__PURE__ */ e("span", { children: r.icon }),
    /* @__PURE__ */ e("strong", { children: r.label }),
    r.description && /* @__PURE__ */ e("small", { children: r.description })
  ] }, r.id)) });
}
function xb({ title: t, description: n, icon: r, trailing: a, onClick: i }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-touch-row", onClick: i, children: [
    r && /* @__PURE__ */ e("span", { className: "fp-touch-row-icon", children: r }),
    /* @__PURE__ */ o("span", { className: "fp-touch-row-copy", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      n && /* @__PURE__ */ e("small", { children: n })
    ] }),
    a || /* @__PURE__ */ e(ze, { size: 18, "aria-hidden": "true" })
  ] });
}
function Cb({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-mobile-notebook-grid", children: t });
}
function Sb({ title: t, description: n, icon: r, onClick: a }) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-mobile-notebook", onClick: a, children: [
    /* @__PURE__ */ e("span", { className: "fp-mobile-notebook-mark", "aria-hidden": "true", children: r }),
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("small", { children: n })
  ] });
}
function Mb({ mark: t, title: n, description: r, children: a, footer: i }) {
  return /* @__PURE__ */ o("main", { className: "fp-mobile-welcome", children: [
    /* @__PURE__ */ o("div", { className: "fp-mobile-welcome-content", children: [
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-mark", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      /* @__PURE__ */ e("p", { children: r }),
      /* @__PURE__ */ e("div", { className: "fp-mobile-welcome-actions", children: a })
    ] }),
    i && /* @__PURE__ */ e("footer", { children: i })
  ] });
}
function Eb({ state: t, time: n, busy: r, onStart: a, onPause: i, onFinish: l, onUpload: s, onAgain: c }) {
  const u = t === "recording" || t === "paused";
  return /* @__PURE__ */ o("section", { className: "fp-recorder", "aria-label": "课堂录音", "aria-busy": r, children: [
    /* @__PURE__ */ o("div", { className: "fp-recorder-status", role: "status", children: [
      t === "recording" && /* @__PURE__ */ e("i", {}),
      t === "idle" ? "准备记录课堂" : t === "paused" ? "已暂停" : t === "saved" ? "录音已保存" : "正在录音"
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-time", "aria-label": `录音时长 ${n}`, children: n }),
    /* @__PURE__ */ e("p", { children: t === "idle" ? "点击开始，记录课堂里的重点" : t === "saved" ? "已保存在手机，可以试听或上传到资源中心" : t === "paused" ? "继续录音，或结束并保存" : "锁屏或返回笔记后，录音仍会继续" }),
    /* @__PURE__ */ e("div", { className: "fp-recorder-controls", children: u ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: i, className: "fp-recorder-secondary", children: [
        t === "paused" ? /* @__PURE__ */ e(tn, { size: 24 }) : /* @__PURE__ */ e(On, { size: 24 }),
        /* @__PURE__ */ e("span", { children: t === "paused" ? "继续录音" : "暂停" })
      ] }),
      /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: l, className: "fp-recorder-finish", children: [
        /* @__PURE__ */ e(Hn, { size: 22 }),
        /* @__PURE__ */ e("span", { children: "结束并保存" })
      ] })
    ] }) : t === "saved" ? /* @__PURE__ */ o(Q, { children: [
      /* @__PURE__ */ e("span", { className: "fp-recorder-saved", children: /* @__PURE__ */ e(Pe, { size: 32 }) }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: s, className: "fp-recorder-primary", children: "上传录音" }),
      /* @__PURE__ */ e("button", { type: "button", disabled: r, onClick: c, children: "录制下一条" })
    ] }) : /* @__PURE__ */ o("button", { type: "button", disabled: r, onClick: a, className: "fp-recorder-start", children: [
      /* @__PURE__ */ e(Fo, { size: 30 }),
      /* @__PURE__ */ e("span", { children: "开始录音" })
    ] }) })
  ] });
}
function $b({ title: t, description: n, metrics: r, tables: a, loading: i, error: l, onRefresh: s, children: c, navigation: u, trend: d, personal: p = !1 }) {
  const h = ve().replaceAll(":", ""), f = d || [], m = Math.max(1, ...f.map((v) => v.value)), b = (v) => 48 + v * 744 / Math.max(1, f.length - 1), g = (v) => 190 - v / m * 154, y = f.map((v, N) => `${b(N)},${g(v.value)}`).join(" "), w = [Oo, jn, mr, ri, mr, ni];
  return /* @__PURE__ */ o("section", { className: "fp-analytics", "data-personal": p || void 0, children: [
    /* @__PURE__ */ o("header", { className: "fp-analytics-heading", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("span", { className: "fp-analytics-eyebrow", children: p ? "我的学习" : "运营分析" }),
        /* @__PURE__ */ e("h1", { children: t }),
        /* @__PURE__ */ e("p", { children: n })
      ] }),
      /* @__PURE__ */ o(te, { variant: "secondary", loading: i, onClick: s, "aria-label": "刷新数据", children: [
        /* @__PURE__ */ e(qn, { size: 16 }),
        "刷新数据"
      ] })
    ] }),
    u && /* @__PURE__ */ e("div", { className: "fp-analytics-navigation", children: u }),
    l && /* @__PURE__ */ e("p", { role: "alert", children: l }),
    r.length > 0 && /* @__PURE__ */ e("div", { className: "fp-analytics-metrics", children: r.map((v, N) => {
      const x = w[N % w.length];
      return /* @__PURE__ */ o(Dt, { children: [
        /* @__PURE__ */ o("div", { className: "fp-analytics-metric-label", children: [
          /* @__PURE__ */ e("span", { children: v.label }),
          /* @__PURE__ */ e(x, { size: 17, "aria-hidden": "true" })
        ] }),
        /* @__PURE__ */ e("strong", { children: typeof v.value == "number" ? v.value.toLocaleString("zh-CN") : v.value })
      ] }, v.label);
    }) }),
    d && /* @__PURE__ */ o(Dt, { className: "fp-analytics-trend", children: [
      /* @__PURE__ */ o("div", { className: "fp-analytics-panel-heading", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("h2", { children: p ? "使用时长趋势" : "活跃趋势" }),
          /* @__PURE__ */ e("p", { children: "观察每天的使用变化" })
        ] }),
        /* @__PURE__ */ o("span", { className: "fp-analytics-period", children: [
          "最近 ",
          f.length,
          " 天"
        ] })
      ] }),
      f.length ? /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e("div", { className: "fp-analytics-chart", role: "img", "aria-label": f.map((v) => p ? `${v.label}，有效使用${v.minutes}分钟` : `${v.label}，活跃${v.value}人，有效使用${v.minutes}分钟`).join("；"), children: /* @__PURE__ */ o("svg", { viewBox: "0 0 840 230", "aria-hidden": "true", children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ o("linearGradient", { id: h, x1: "0", y1: "0", x2: "0", y2: "1", children: [
            /* @__PURE__ */ e("stop", { offset: "0%", stopColor: "currentColor", stopOpacity: ".18" }),
            /* @__PURE__ */ e("stop", { offset: "100%", stopColor: "currentColor", stopOpacity: "0" })
          ] }) }),
          [0, 0.5, 1].map((v) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("line", { x1: "48", x2: "792", y1: g(m * v), y2: g(m * v), className: "fp-analytics-gridline" }),
            /* @__PURE__ */ e("text", { x: "36", y: g(m * v) + 4, textAnchor: "end", children: Number((m * v).toFixed(1)) })
          ] }, v)),
          /* @__PURE__ */ e("polygon", { points: `48,190 ${y} ${b(f.length - 1)},190`, fill: `url(#${h})` }),
          /* @__PURE__ */ e("polyline", { points: y, fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinejoin: "round", strokeLinecap: "round" }),
          f.map((v, N) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e("circle", { cx: b(N), cy: g(v.value), r: "4", fill: "var(--fp-surface)", stroke: "currentColor", strokeWidth: "2" }),
            (N === 0 || N === f.length - 1 || N % Math.ceil(f.length / 7) === 0 && N < f.length - 2) && /* @__PURE__ */ e("text", { x: b(N), y: "219", textAnchor: "middle", children: v.label.slice(5).replace("-", "/") })
          ] }, v.label))
        ] }) }),
        /* @__PURE__ */ o("div", { className: "fp-analytics-chart-footer", children: [
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("i", {}),
            p ? "每日有效使用（分钟）" : "每日活跃用户"
          ] }),
          /* @__PURE__ */ o("span", { children: [
            "累计有效使用 ",
            /* @__PURE__ */ e("strong", { children: f.reduce((v, N) => v + N.minutes, 0).toLocaleString("zh-CN") }),
            " 分钟"
          ] })
        ] })
      ] }) : /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示活跃趋势。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "fp-analytics-tables", children: a.map((v) => /* @__PURE__ */ o(Dt, { className: v.columns.length > 4 ? "fp-analytics-wide" : void 0, children: [
      /* @__PURE__ */ e("h2", { children: v.title }),
      /* @__PURE__ */ o("div", { className: "fp-analytics-table", tabIndex: 0, role: "region", "aria-label": v.title, children: [
        /* @__PURE__ */ o("table", { children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: v.columns.map((N) => /* @__PURE__ */ e("th", { children: N }, N)) }) }),
          /* @__PURE__ */ e("tbody", { children: v.rows.map((N, x) => /* @__PURE__ */ e("tr", { children: N.map((C, I) => /* @__PURE__ */ e("td", { children: C }, I)) }, x)) })
        ] }),
        !v.rows.length && /* @__PURE__ */ e("p", { children: "开始使用后，这里将展示统计结果。" })
      ] })
    ] }, v.title)) }),
    c
  ] });
}
function zb({ entries: t, directoryId: n, onNavigate: r, selectedId: a, onSelect: i, rootLabel: l = "全部位置", searchLabel: s = "搜索名称、拼音或英文", emptyLabel: c = "此文件夹为空", disabled: u = !1, preview: d, loading: p = !1, variant: h = "content" }) {
  const [f, m] = k(""), b = B(null), g = Ue(() => new Map(t.map((L) => [L.id, L])), [t]), y = (L) => {
    const K = [], S = /* @__PURE__ */ new Set();
    let A = g.get(L);
    for (; A && !S.has(A.id); )
      S.add(A.id), K.unshift(A), A = A.parentId ? g.get(A.parentId) : void 0;
    return K;
  }, w = y(n), v = t.filter((L) => !L.parentId && L.kind === "folder"), N = Ue(() => new Map(t.map((L) => [L.id, sn(L.label, L.description || "", L.keywords || "", ...y(L.id).map((K) => K.label))])), [t, g]), x = f.trim().toLowerCase(), C = t.filter((L) => x ? N.get(L.id)?.includes(x) : (L.parentId || "") === n), I = (L) => {
    m(""), r(L);
  };
  return /* @__PURE__ */ o("div", { className: "fp-resource-browser", "data-variant": h, "aria-busy": p, children: [
    h === "destination" && /* @__PURE__ */ o("div", { className: "fp-browser-destination-heading", children: [
      /* @__PURE__ */ e("span", { children: "选择保存位置" }),
      /* @__PURE__ */ e("small", { children: "打开文件夹，选择当前位置" })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-search", children: [
      /* @__PURE__ */ e(We, { size: 17, "aria-hidden": "true" }),
      /* @__PURE__ */ e("input", { type: "search", "aria-label": s, placeholder: s, value: f, disabled: u, onChange: (L) => m(L.target.value) })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-browser-body", children: [
      h === "content" && /* @__PURE__ */ o("nav", { className: "fp-browser-locations", "aria-label": "浏览位置", children: [
        /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": n ? void 0 : "location", onClick: () => I(""), children: l }),
        v.map((L) => /* @__PURE__ */ o("button", { type: "button", disabled: u || L.disabled, "aria-current": w[0]?.id === L.id ? "location" : void 0, onClick: () => I(L.id), children: [
          L.icon || /* @__PURE__ */ e(Nn, { size: 17 }),
          /* @__PURE__ */ e("span", { children: L.label })
        ] }, L.id))
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-browser-main", "aria-label": "文件夹内容", children: [
        h === "destination" && v.length > 1 && /* @__PURE__ */ e("div", { className: "fp-browser-root-choice", children: /* @__PURE__ */ e(ke, { label: "切换位置", value: w[0]?.id || "", onChange: I, options: [{ value: "", label: l }, ...v.map((L) => ({ value: L.id, label: L.label, disabled: L.disabled }))] }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-path", children: [
          /* @__PURE__ */ e("button", { type: "button", "aria-label": "返回上一级", disabled: u || !n, onClick: () => I(g.get(n)?.parentId || ""), children: /* @__PURE__ */ e(Pr, { size: 17 }) }),
          /* @__PURE__ */ o("nav", { "aria-label": "当前位置", children: [
            /* @__PURE__ */ e("button", { type: "button", disabled: u, onClick: () => I(""), children: l }),
            w.map((L) => /* @__PURE__ */ o("span", { children: [
              /* @__PURE__ */ e(ze, { size: 13 }),
              /* @__PURE__ */ e("button", { type: "button", disabled: u, "aria-current": L.id === n ? "location" : void 0, onClick: () => I(L.id), children: L.label })
            ] }, L.id))
          ] })
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-browser-list", ref: b, role: "group", "aria-label": x ? "搜索结果" : "可选内容", onKeyDown: (L) => {
          if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(L.key)) return;
          const K = Array.from(b.current?.querySelectorAll("button:not(:disabled)") || []), S = K.indexOf(document.activeElement);
          S < 0 || (L.preventDefault(), K[L.key === "Home" ? 0 : L.key === "End" ? K.length - 1 : Math.max(0, Math.min(K.length - 1, S + (L.key === "ArrowDown" ? 1 : -1)))]?.focus());
        }, children: p ? /* @__PURE__ */ e("p", { role: "status", children: "正在加载…" }) : C.length ? C.map((L) => /* @__PURE__ */ o("button", { className: "fp-browser-entry", type: "button", disabled: u || L.disabled, "aria-pressed": L.kind === "file" ? a === L.id : void 0, onClick: () => L.kind === "folder" ? I(L.id) : i(L.id), children: [
          /* @__PURE__ */ e("span", { className: "fp-browser-entry-icon", children: L.icon || (L.kind === "folder" ? /* @__PURE__ */ e(Nn, { size: 22 }) : /* @__PURE__ */ e(Ro, { size: 22 })) }),
          /* @__PURE__ */ o("span", { className: "fp-browser-entry-text", children: [
            /* @__PURE__ */ e("strong", { children: L.label }),
            (x || L.description || h === "destination") && /* @__PURE__ */ e("small", { children: x ? y(L.id).slice(0, -1).map((K) => K.label).join(" / ") : L.description || (L.kind === "folder" ? `${t.filter((K) => K.parentId === L.id && K.kind === "folder").length} 个文件夹` : "") })
          ] }),
          L.kind === "folder" && /* @__PURE__ */ e(ze, { size: 16 })
        ] }, L.id)) : /* @__PURE__ */ e("p", { role: "status", children: x ? "没有匹配的内容" : c }) }),
        /* @__PURE__ */ o("div", { className: "fp-browser-count", "aria-live": "polite", children: [
          C.length,
          " 项",
          x ? " · 搜索全部位置" : ""
        ] })
      ] }),
      d && /* @__PURE__ */ e("aside", { className: "fp-browser-preview", "aria-label": "所选内容", children: d })
    ] })
  ] });
}
function Ab({ brand: t, headerActions: n, items: r, value: a, onChange: i, onReturn: l, identity: s, children: c }) {
  const [u, d] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-console", children: [
    /* @__PURE__ */ o("header", { className: "fp-console-topbar", children: [
      /* @__PURE__ */ e("div", { className: "fp-console-brand", children: t }),
      /* @__PURE__ */ o("div", { className: "fp-console-top-actions", children: [
        /* @__PURE__ */ o(te, { variant: "ghost", onClick: l, children: [
          /* @__PURE__ */ e(Br, { size: 17 }),
          "返回工作区"
        ] }),
        n
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-console-body", children: [
      /* @__PURE__ */ o("div", { className: "fp-console-mobile-bar", children: [
        /* @__PURE__ */ o(te, { variant: "secondary", "aria-expanded": u, "aria-controls": "management-navigation", onClick: () => d(!u), children: [
          u ? /* @__PURE__ */ e(ge, { size: 18 }) : /* @__PURE__ */ e(rn, { size: 18 }),
          "管理导航"
        ] }),
        /* @__PURE__ */ e("span", { children: r.find((p) => p.id === a)?.label })
      ] }),
      /* @__PURE__ */ o("aside", { className: "fp-console-sidebar", "data-open": u, children: [
        /* @__PURE__ */ e("div", { className: "fp-console-sidebar-heading", children: "管理中心" }),
        /* @__PURE__ */ e("nav", { id: "management-navigation", "aria-label": "管理导航", children: r.map((p) => /* @__PURE__ */ o("button", { type: "button", "aria-current": a === p.id ? "page" : void 0, onClick: () => {
          i(p.id), d(!1);
        }, children: [
          p.icon,
          /* @__PURE__ */ e("span", { children: p.label })
        ] }, p.id)) }),
        s && /* @__PURE__ */ e("footer", { children: s })
      ] }),
      /* @__PURE__ */ e("main", { className: "fp-console-content", tabIndex: -1, children: c })
    ] })
  ] });
}
function Ib({ title: t, description: n, items: r, value: a, onChange: i, actions: l, status: s, children: c }) {
  return /* @__PURE__ */ o("section", { className: "fp-console-form", children: [
    /* @__PURE__ */ e("header", { children: /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h1", { children: t }),
      n && /* @__PURE__ */ e("p", { children: n })
    ] }) }),
    /* @__PURE__ */ e(Ur, { items: r, value: a, onChange: i }),
    /* @__PURE__ */ e("div", { className: "fp-console-form-body", children: c }),
    /* @__PURE__ */ o("footer", { children: [
      /* @__PURE__ */ e("div", { role: "status", "aria-live": "polite", children: s }),
      /* @__PURE__ */ e("div", { className: "fp-console-form-actions", children: l })
    ] })
  ] });
}
function Lb({ open: t, version: n, minimum: r, children: a, actions: i, updateContent: l }) {
  return /* @__PURE__ */ e(ut, { open: t, dismissible: !1, className: "fp-upgrade-dialog", title: "更新课栈，继续学习", onClose: () => {
  }, footer: i, children: l || /* @__PURE__ */ o("div", { className: "fp-upgrade-required", children: [
    /* @__PURE__ */ e("div", { className: "fp-upgrade-symbol", "aria-hidden": "true", children: /* @__PURE__ */ e(Dr, { size: 28 }) }),
    /* @__PURE__ */ e("p", { children: "当前版本需要升级，完成后即可继续使用。" }),
    /* @__PURE__ */ o("div", { className: "fp-update-versions", children: [
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "当前版本" }),
        /* @__PURE__ */ e("strong", { children: n || "—" })
      ] }),
      /* @__PURE__ */ e(Un, { size: 18, "aria-hidden": "true" }),
      /* @__PURE__ */ o("span", { children: [
        /* @__PURE__ */ e("small", { children: "最低支持版本" }),
        /* @__PURE__ */ e("strong", { children: r || "—" })
      ] })
    ] }),
    /* @__PURE__ */ e("p", { className: "fp-upgrade-hint", children: "升级前请保留正在编辑的内容。" }),
    a
  ] }) });
}
function Tb({ value: t, onChange: n, models: r, tools: a, syncStatus: i, providers: l, initialTab: s = "preferences", children: c }) {
  const [u, d] = k(s);
  Y(() => d(s), [s]);
  const p = r.filter((f) => f.type !== "image").map((f) => ({ value: f.id, label: f.label })), h = r.filter((f) => f.type === "image").map((f) => ({ value: f.id, label: f.label }));
  return /* @__PURE__ */ o("div", { className: "fp-assistant-preferences", children: [
    /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: i }),
    /* @__PURE__ */ e(Ve, { label: "AI 设置分类", value: u, onChange: d, density: "compact", items: [{ id: "preferences", label: "常用偏好" }, { id: "models", label: "模型与供应商" }, { id: "capabilities", label: "能力与备份" }] }),
    u === "preferences" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "常用偏好", children: [
      /* @__PURE__ */ o(ee, { title: "对话偏好", children: [
        /* @__PURE__ */ e(X, { label: "默认对话模型", value: t.selectedModelId, options: p, onChange: (f) => n("selectedModelId", f) }),
        /* @__PURE__ */ e(Ae, { label: "深度思考", description: "新对话默认开启深度思考。", checked: t.defaultThinking, onChange: (f) => n("defaultThinking", f) }),
        /* @__PURE__ */ e(X, { label: "默认思考力度", value: t.defaultThinkingEffort, options: [{ value: "low", label: "轻量" }, { value: "medium", label: "标准" }, { value: "high", label: "深入" }, { value: "max", label: "充分" }], onChange: (f) => n("defaultThinkingEffort", f) }),
        /* @__PURE__ */ e(Ae, { label: "联网搜索", description: "新对话默认启用联网搜索。", checked: t.defaultSearch, onChange: (f) => n("defaultSearch", f) })
      ] }),
      /* @__PURE__ */ e(ee, { title: "回答偏好", description: "告诉 AI 你的学习背景、称呼和回答习惯。", children: /* @__PURE__ */ e(X, { label: "希望 AI 记住的偏好", value: t.globalContext, multiline: !0, onChange: (f) => n("globalContext", f) }) })
    ] }),
    u === "models" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "模型与供应商", children: [
      l,
      /* @__PURE__ */ o(ee, { title: "摘录与划词助手", children: [
        /* @__PURE__ */ e(X, { label: "摘录模型", value: t.recordModelId, options: p, onChange: (f) => n("recordModelId", f) }),
        /* @__PURE__ */ e(X, { label: "划词助手模型", value: t.floatingChatModelId, options: [{ value: "", label: "跟随主对话" }, ...p], onChange: (f) => n("floatingChatModelId", f) })
      ] }),
      h.length > 0 && /* @__PURE__ */ o(ee, { title: "图片生成", children: [
        /* @__PURE__ */ e(X, { label: "默认生图模型", value: t.defaultImageModelId || "", options: [{ value: "", label: "自动选择" }, ...h], onChange: (f) => n("defaultImageModelId", f || null) }),
        /* @__PURE__ */ e(X, { label: "图片描述模型", value: t.imageModeTextModel, options: p, onChange: (f) => n("imageModeTextModel", f) }),
        /* @__PURE__ */ e(X, { label: "备用描述模型", value: t.imageModeTextModelFallback, options: p, onChange: (f) => n("imageModeTextModelFallback", f) })
      ] })
    ] }),
    u === "capabilities" && /* @__PURE__ */ o("div", { className: "fp-assistant-page", role: "tabpanel", "aria-label": "能力与备份", children: [
      /* @__PURE__ */ e(ee, { title: "助手能力", children: a.map((f) => /* @__PURE__ */ e(Ae, { label: f.label, description: f.desc, checked: !t.disabledTools.includes(f.name), onChange: (m) => n("disabledTools", m ? t.disabledTools.filter((b) => b !== f.name) : [...t.disabledTools, f.name]) }, f.name)) }),
      c
    ] })
  ] });
}
const wp = { name: "", baseUrl: "", protocol: "openai", apiKey: "", models: [] };
function Db({ items: t, loading: n, error: r, credentialNotice: a, imports: i = [], onImportSaved: l, onDiscover: s, onTest: c, onSave: u, onDelete: d }) {
  const [p, h] = k(), [f, m] = k(null), [b, g] = k(""), [y, w] = k(""), [v, N] = k(""), [x, C] = k(""), [I, L] = k([]), [K, S] = k(), A = !f || f.models.every((T) => Number.isInteger(T.contextK ?? 32) && (T.contextK ?? 32) >= 4 && (T.contextK ?? 32) <= 2048), D = (T) => {
    m((M) => M ? { ...M, ...T } : null), N(""), w("");
  }, U = (T) => {
    m(T ? { ...T, apiKey: "" } : { ...wp, models: [] }), L(T?.models || []), C(""), N(""), w(""), S(void 0), h(void 0);
  }, j = async (T, M) => {
    g(T), w("");
    try {
      await M();
    } catch (R) {
      w(R instanceof Error ? R.message : "操作未完成，请重试");
    } finally {
      g("");
    }
  };
  return /* @__PURE__ */ o("div", { className: "fp-provider-manager", children: [
    /* @__PURE__ */ e("p", { children: "连接你自己的 AI 服务。供应商和模型会同步到账号，在其他设备也可使用。" }),
    a && /* @__PURE__ */ o("aside", { className: "fp-provider-privacy", role: "note", "aria-label": "API Key 使用说明", children: [
      /* @__PURE__ */ e(Or, { size: 20, "aria-hidden": "true" }),
      /* @__PURE__ */ e("div", { children: a })
    ] }),
    n && /* @__PURE__ */ e("p", { role: "status", children: "正在读取供应商…" }),
    r && /* @__PURE__ */ e("p", { role: "alert", children: r }),
    i.length > 0 && !f && /* @__PURE__ */ o("section", { className: "fp-provider-imports", "aria-label": "此设备的旧配置", children: [
      /* @__PURE__ */ e("strong", { children: "此设备的旧配置" }),
      /* @__PURE__ */ e("p", { children: "检查并测试后保存到账号，即可在其他设备使用。" }),
      i.map((T) => /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: T.label }),
        /* @__PURE__ */ o(te, { variant: "secondary", disabled: !!b, onClick: () => {
          U(), m({ ...T.draft }), L(T.draft.models), h(T.id);
        }, children: [
          "检查并迁移 ",
          T.label
        ] })
      ] }, T.id))
    ] }),
    t.map((T) => /* @__PURE__ */ o("div", { className: "fp-provider-summary", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("strong", { children: T.name }),
        /* @__PURE__ */ o("small", { children: [
          T.models.length,
          " 个模型 · ",
          T.protocol === "anthropic" ? "Anthropic Messages" : T.protocol === "siliconflow" ? "SiliconFlow" : "OpenAI 兼容"
        ] })
      ] }),
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => U(T), children: "编辑" }),
      /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => S(T.id), children: "删除" }),
      K === T.id && /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e("span", { children: "删除此供应商？" }),
        /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => S(void 0), children: "取消" }),
        /* @__PURE__ */ e(te, { disabled: !!b, onClick: () => {
          j("delete", async () => {
            await d(T), S(void 0), f?.id === T.id && m(null);
          });
        }, children: "确认删除" })
      ] })
    ] }, T.id)),
    !f && /* @__PURE__ */ e(te, { variant: "secondary", onClick: () => U(), children: "添加供应商" }),
    f && /* @__PURE__ */ o("div", { className: "fp-provider-form", "aria-label": f.id ? "编辑供应商" : "添加供应商", children: [
      /* @__PURE__ */ e(X, { label: "供应商名称", value: f.name, disabled: !!b, onChange: (T) => D({ name: T }) }),
      /* @__PURE__ */ e(X, { label: "API 端点", hint: "填写 HTTPS 地址，例如 https://api.example.com/v1", value: f.baseUrl, disabled: !!b, onChange: (T) => {
        D({ baseUrl: T, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "协议", value: f.protocol, disabled: !!b, options: [{ value: "openai", label: "OpenAI 兼容" }, { value: "anthropic", label: "Anthropic Messages" }, { value: "siliconflow", label: "SiliconFlow" }], onChange: (T) => {
        D({ protocol: T, models: [] }), L([]);
      } }),
      /* @__PURE__ */ e(X, { label: "API Key", hint: f.id ? "留空沿用已保存的 Key。" : "Key 仅用于连接你的供应商，保存后不会再显示。", value: f.apiKey, secret: !0, disabled: !!b, onChange: (T) => D({ apiKey: T }) }),
      /* @__PURE__ */ e("div", { className: "fp-provider-actions", children: /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !f.baseUrl || !f.apiKey && !f.id, onClick: () => {
        j("discover", async () => {
          const T = await s(f);
          L(T), D({ models: [] }), w("已获取模型，请选择要添加的模型。");
        });
      }, children: b === "discover" ? "正在获取…" : "获取模型" }) }),
      I.length > 0 && /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ o("p", { "aria-live": "polite", children: [
          "已选择 ",
          f.models.length,
          " / 50 个模型"
        ] }),
        /* @__PURE__ */ e("div", { className: "fp-provider-models", role: "group", "aria-label": "选择模型", children: I.map((T) => /* @__PURE__ */ o("label", { children: [
          /* @__PURE__ */ e("input", { type: "checkbox", disabled: !!b || f.models.length >= 50 && !f.models.some((M) => M.id === T.id), checked: f.models.some((M) => M.id === T.id), onChange: (M) => D({ models: M.target.checked ? [...f.models, T] : f.models.filter((R) => R.id !== T.id) }) }),
          T.label || T.id
        ] }, T.id)) })
      ] }),
      f.models.length > 0 && /* @__PURE__ */ o("section", { className: "fp-provider-contexts", "aria-label": "模型能力设置", children: [
        /* @__PURE__ */ e("h3", { children: "模型能力与容量" }),
        /* @__PURE__ */ e("p", { children: "按供应商实际支持的能力分别设置每个模型。图片输入用于识别图片；工具调用用于读取资料、操作笔记等。1K 为 1000 tokens。" }),
        f.models.map((T) => /* @__PURE__ */ o("fieldset", { className: "fp-provider-context", children: [
          /* @__PURE__ */ e("legend", { children: T.label || T.id }),
          /* @__PURE__ */ e(Ae, { label: "支持图片输入", description: "允许在对话中上传图片供此模型识别。", checked: T.vision === !0, disabled: !!b, onChange: (M) => D({ models: f.models.map((R) => R.id === T.id ? { ...R, vision: M } : R) }) }),
          /* @__PURE__ */ e(Ae, { label: "启用工具调用", description: "允许此模型读取资料及执行你授权的笔记操作。", checked: T.tools === !0, disabled: !!b, onChange: (M) => D({ models: f.models.map((R) => R.id === T.id ? { ...R, tools: M } : R) }) }),
          /* @__PURE__ */ e(X, { label: "上下文容量（K）", numeric: !0, value: T.contextK ?? 32, disabled: !!b, hint: T.contextSource === "provider" ? "供应商提供的容量，可按实际限制调整。" : T.contextSource === "user" ? "手动设置的容量。" : T.contextSource === "default" || T.contextK === void 0 ? "供应商未提供容量，暂用保守默认值 32K，请按实际限制确认。" : "已保存的容量，请按供应商实际限制确认。", onChange: (M) => D({ models: f.models.map((R) => R.id === T.id ? { ...R, contextK: Number(M), contextSource: "user" } : R) }) }),
          (!Number.isInteger(T.contextK ?? 32) || (T.contextK ?? 32) < 4 || (T.contextK ?? 32) > 2048) && /* @__PURE__ */ e("p", { role: "alert", children: "请填写 4–2048 之间的整数。" })
        ] }, T.id))
      ] }),
      /* @__PURE__ */ o("details", { children: [
        /* @__PURE__ */ e("summary", { children: "手动添加模型" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e(X, { label: "模型 ID", value: x, hint: "供应商无法列出模型时，可填写模型 ID，多个模型用逗号或换行分隔。", multiline: !0, disabled: !!b, onChange: C }),
          /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !x.trim(), onClick: () => {
            const T = [...new Set(x.split(/[\n,，]/).map((R) => R.trim()).filter(Boolean))].map((R) => ({ id: R, label: R })), M = [...f.models, ...T.filter((R) => !f.models.some((q) => q.id === R.id))];
            L((R) => [...R, ...T.filter((q) => !R.some((F) => F.id === q.id))]), D({ models: M }), C("");
          }, children: "加入模型列表" })
        ] })
      ] }),
      /* @__PURE__ */ e("p", { children: "连接测试只检查所选第一个模型是否可访问，图片和工具能力请按供应商说明设置。测试及对话的费用由你的供应商收取。" }),
      /* @__PURE__ */ o("div", { className: "fp-provider-actions", children: [
        /* @__PURE__ */ e(te, { variant: "secondary", disabled: !!b || !A || !f.name.trim() || !f.models.length || f.models.length > 50, onClick: () => {
          j("test", async () => {
            N(await c(f)), w("连接成功，可以保存供应商。");
          });
        }, children: b === "test" ? "正在测试…" : "测试连接" }),
        /* @__PURE__ */ e(te, { disabled: !!b || !v || !A, onClick: () => {
          j("save", async () => {
            await u(f, v), p && l?.(p), h(void 0), m(null), N(""), w("供应商已保存，可在模型菜单中选择。");
          });
        }, children: b === "save" ? "正在保存…" : f.id ? "保存供应商" : "添加供应商" }),
        /* @__PURE__ */ e(te, { variant: "ghost", disabled: !!b, onClick: () => {
          m(null), h(void 0), N(""), w("");
        }, children: "取消" })
      ] })
    ] }),
    y && /* @__PURE__ */ e("p", { role: "status", "aria-live": "polite", children: y })
  ] });
}
function Pb({ items: t, onSelect: n, label: r = "相关设置" }) {
  return /* @__PURE__ */ e("nav", { className: "fp-settings-links", "aria-label": r, children: t.map((a) => /* @__PURE__ */ o("button", { type: "button", disabled: a.disabled, onClick: () => n(a.id), children: [
    a.icon && /* @__PURE__ */ e("span", { className: "fp-settings-link-icon", "aria-hidden": "true", children: a.icon }),
    /* @__PURE__ */ o("span", { className: "fp-settings-link-copy", children: [
      /* @__PURE__ */ e("strong", { children: a.label }),
      a.description && /* @__PURE__ */ e("small", { children: a.description })
    ] }),
    /* @__PURE__ */ e(ze, { size: 18, "aria-hidden": "true" })
  ] }, a.id)) });
}
function Fb({ metrics: t, description: n = "最近 30 天", loading: r, error: a, onRetry: i }) {
  return /* @__PURE__ */ o(ee, { title: "使用统计", description: n, children: [
    /* @__PURE__ */ e(Se, { error: a }),
    r ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取使用统计…" }) : /* @__PURE__ */ e("dl", { className: "fp-admin-metrics", children: t.map((l) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("dt", { children: l.label }),
      /* @__PURE__ */ e("dd", { children: l.value })
    ] }, l.label)) }),
    a && i && /* @__PURE__ */ e(te, { onClick: i, children: "重新读取" })
  ] });
}
function Ob({ items: t, loading: n, error: r, hasMore: a, onMore: i }) {
  return /* @__PURE__ */ o(ee, { title: "拥有的笔记本", children: [
    /* @__PURE__ */ e(Se, { error: r }),
    /* @__PURE__ */ e("ul", { className: "fp-admin-notebooks", children: t.map((l) => /* @__PURE__ */ e("li", { children: /* @__PURE__ */ o("div", { children: [
      l.href ? /* @__PURE__ */ e("a", { href: l.href, children: l.title }) : /* @__PURE__ */ e("strong", { children: l.title }),
      /* @__PURE__ */ o("small", { children: [
        l.noteCount,
        " 篇笔记 · 更新于 ",
        l.updatedAt
      ] })
    ] }) }, l.id)) }),
    n ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取笔记本…" }) : !t.length && !r ? /* @__PURE__ */ e("p", { children: "该用户尚未拥有笔记本。" }) : null,
    a && i && /* @__PURE__ */ e(te, { disabled: n, onClick: i, children: "加载更多笔记本" })
  ] });
}
function Rb({ entries: t, filters: n, onFiltersChange: r, actions: a, onSearch: i, onReset: l, onNext: s, onPrevious: c, canNext: u, canPrevious: d, loading: p, error: h }) {
  return /* @__PURE__ */ e("section", { className: "fp-workspace-form fp-admin-audit", children: /* @__PURE__ */ o(ee, { title: "审计日志", description: "查看平台操作的时间、操作者、对象与变更说明。", children: [
    /* @__PURE__ */ o("form", { className: "fp-admin-audit-filters", onSubmit: (f) => {
      f.preventDefault(), i();
    }, children: [
      /* @__PURE__ */ e(X, { label: "操作者", value: n.actor, onChange: (f) => r({ ...n, actor: f }) }),
      /* @__PURE__ */ e(X, { label: "操作", value: n.action, options: [{ value: "", label: "全部操作" }, ...a], onChange: (f) => r({ ...n, action: f }) }),
      /* @__PURE__ */ e(X, { label: "操作对象", value: n.target, onChange: (f) => r({ ...n, target: f }) }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "开始日期" }),
        /* @__PURE__ */ e(Ka, { className: "fp-input", "aria-label": "开始日期", value: n.from, onChange: (f) => r({ ...n, from: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("label", { className: "fp-workspace-field", children: [
        /* @__PURE__ */ e("span", { children: "结束日期" }),
        /* @__PURE__ */ e(Ka, { className: "fp-input", "aria-label": "结束日期", value: n.to, onChange: (f) => r({ ...n, to: f.target.value }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-actions", children: [
        /* @__PURE__ */ e(te, { type: "submit", disabled: p, children: "查询" }),
        /* @__PURE__ */ e(te, { type: "button", disabled: p, onClick: l, children: "重置筛选" })
      ] })
    ] }),
    /* @__PURE__ */ e(Se, { error: h }),
    p ? /* @__PURE__ */ e("p", { role: "status", children: "正在读取操作记录…" }) : /* @__PURE__ */ e("ol", { className: "fp-admin-audit-list", children: t.map((f) => /* @__PURE__ */ o("li", { children: [
      /* @__PURE__ */ o("div", { className: "fp-admin-audit-heading", children: [
        /* @__PURE__ */ e("strong", { children: f.action }),
        /* @__PURE__ */ e("time", { children: f.time })
      ] }),
      /* @__PURE__ */ o("p", { children: [
        /* @__PURE__ */ e("span", { children: f.actor }),
        /* @__PURE__ */ e("span", { "aria-hidden": "true", children: " → " }),
        /* @__PURE__ */ e("span", { children: f.target })
      ] }),
      f.summary && /* @__PURE__ */ e("p", { children: f.summary })
    ] }, f.id)) }),
    !p && !h && !t.length && /* @__PURE__ */ e("p", { children: "没有符合条件的操作记录。" }),
    /* @__PURE__ */ o("nav", { className: "fp-admin-audit-actions", "aria-label": "审计记录分页", children: [
      /* @__PURE__ */ e(te, { disabled: p || !d, onClick: c, children: "上一页" }),
      /* @__PURE__ */ e(te, { disabled: p || !u, onClick: s, children: "下一页" })
    ] })
  ] }) });
}
function Bb({ index: t, children: n, className: r = "", duration: a = 0.26, label: i }) {
  const [l, s] = k({ index: t, direction: 1, prior: null }), c = B(n), u = _n();
  l.index !== t && s({ index: t, direction: t > l.index ? 1 : -1, prior: { index: l.index, children: c.current } }), c.current = n, Y(() => {
    const p = setTimeout(() => s((h) => h.index === t && h.prior ? { ...h, prior: null } : h), u ? 0 : a * 1e3 + 30);
    return () => clearTimeout(p);
  }, [t, a, u]);
  const d = [...l.prior ? [{ ...l.prior, active: !1 }] : [], { index: t, children: n, active: !0 }];
  return /* @__PURE__ */ e("div", { className: `fp-slide-transition ${r}`, "data-direction": l.direction, "data-index": t, "aria-label": i, style: { position: "relative", height: "100%", width: "100%", minHeight: 0, minWidth: 0, overflow: "hidden" }, children: d.map((p) => /* @__PURE__ */ e(
    Wn.div,
    {
      "data-fp-slide-page": "",
      "data-active": p.active,
      inert: !p.active,
      "aria-hidden": !p.active || void 0,
      initial: p.active && l.prior && !u ? { x: `${l.direction * 100}%`, opacity: 0.35 } : !1,
      animate: { x: p.active || u ? 0 : `${-l.direction * 100}%`, opacity: p.active || u ? 1 : 0.35 },
      transition: { duration: u ? 0 : a, ease: [0.2, 0, 0, 1] },
      style: { position: "absolute", inset: 0, minWidth: 0, minHeight: 0, overflow: "hidden", pointerEvents: p.active ? "auto" : "none" },
      children: p.children
    },
    p.index
  )) });
}
function jb(t, n = !1) {
  if (t.isComposing || t.repeat || !(t.ctrlKey || t.metaKey)) return null;
  const r = t.key.toLowerCase();
  return !n && !t.altKey || n && t.altKey ? null : r === "n" && !t.shiftKey ? "new-note" : r === "w" && !t.shiftKey ? "close-tab" : r === "t" && t.shiftKey ? "reopen-tab" : !n && r === "arrowright" && !t.shiftKey ? "next-tab" : !n && r === "arrowleft" && !t.shiftKey ? "previous-tab" : n && r === "tab" ? t.shiftKey ? "previous-tab" : "next-tab" : !t.shiftKey && /^[1-9]$/.test(r) ? `tab-${Number(r)}` : null;
}
function qb(t) {
  const n = ve(), [r, a] = k("edit"), [i, l] = k("");
  Y(() => {
    a("edit"), l("");
  }, [t.sessionKey]);
  const s = t.mode === "create";
  return /* @__PURE__ */ o("section", { className: "fp-experiment", "aria-label": "实验编辑工作台", onKeyDown: (c) => {
    (c.ctrlKey || c.metaKey) && c.key.toLowerCase() === "s" && (c.preventDefault(), t.onSave());
  }, children: [
    /* @__PURE__ */ o("header", { className: "fp-experiment-header", children: [
      /* @__PURE__ */ o("button", { type: "button", className: "fp-experiment-back", onClick: t.onBack, children: [
        /* @__PURE__ */ e(Br, { size: 17 }),
        "我的实验"
      ] }),
      /* @__PURE__ */ e("span", { role: "status", className: "fp-experiment-save", children: t.saveStatus }),
      /* @__PURE__ */ e(wl, { label: "实验操作", actions: [
        { id: "save", label: "保存实验（Ctrl+S）", icon: /* @__PURE__ */ e(ei, { size: 18 }), onSelect: t.onSave },
        { id: "insert", label: "加入笔记", icon: /* @__PURE__ */ e(Bo, { size: 18 }), onSelect: t.onInsert, disabled: t.busy || !t.source.trim() },
        { id: "copy", label: "另存为新实验", icon: /* @__PURE__ */ e(Kn, { size: 18 }), onSelect: t.onDuplicate, disabled: t.busy || !t.source.trim() },
        { id: "download", label: "下载实验", icon: /* @__PURE__ */ e(jt, { size: 18 }), onSelect: t.onExport, disabled: !t.source.trim() }
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-experiment-layout", children: [
      /* @__PURE__ */ o("aside", { className: "fp-experiment-editor", children: [
        /* @__PURE__ */ e("label", { htmlFor: `${n}-title`, children: "实验名称" }),
        /* @__PURE__ */ e("input", { id: `${n}-title`, value: t.title, placeholder: "给实验起个名字", onChange: (c) => t.onTitleChange(c.target.value), maxLength: 100, disabled: t.busy }),
        /* @__PURE__ */ o("div", { className: "fp-experiment-tabs", role: "tablist", "aria-label": "实验编辑", onKeyDown: (c) => {
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(c.key)) return;
          c.preventDefault();
          const u = c.key === "Home" ? "edit" : c.key === "End" || r === "edit" ? "history" : "edit";
          a(u), c.currentTarget.querySelectorAll("[role=tab]")[u === "edit" ? 0 : 1]?.focus();
        }, children: [
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-edit-tab`, role: "tab", tabIndex: r === "edit" ? 0 : -1, "aria-selected": r === "edit", "aria-controls": `${n}-edit`, onClick: () => a("edit"), children: [
            /* @__PURE__ */ e(xn, { size: 16 }),
            s ? "创建实验" : "继续修改"
          ] }),
          /* @__PURE__ */ o("button", { type: "button", id: `${n}-history-tab`, role: "tab", tabIndex: r === "history" ? 0 : -1, "aria-selected": r === "history", "aria-controls": `${n}-history`, onClick: () => a("history"), children: [
            /* @__PURE__ */ e(jo, { size: 16 }),
            "版本记录"
          ] })
        ] }),
        r === "edit" ? /* @__PURE__ */ o("div", { id: `${n}-edit`, role: "tabpanel", "aria-labelledby": `${n}-edit-tab`, className: "fp-experiment-form", children: [
          t.modelSelector && /* @__PURE__ */ e("div", { className: "fp-experiment-model", children: t.modelSelector }),
          /* @__PURE__ */ e("label", { htmlFor: `${n}-prompt`, children: "描述你的想法" }),
          /* @__PURE__ */ e("textarea", { id: `${n}-prompt`, value: t.prompt, onChange: (c) => t.onPromptChange(c.target.value), disabled: t.busy, rows: 5, placeholder: s ? "例如：用滑块调整电荷大小，观察电场如何变化。" : "例如：保留现有图形，增加一个能调节距离的滑块。" }),
          /* @__PURE__ */ e("button", { type: "button", className: "fp-experiment-primary", onClick: t.busy ? t.onStop : t.onGenerate, disabled: !t.busy && (!t.prompt.trim() || t.canGenerate === !1), children: t.busy ? /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e(Hn, { size: 16 }),
            "停止生成"
          ] }) : /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e(xn, { size: 17 }),
            "生成实验"
          ] }) }),
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: s ? "描述想探索的概念和操作，AI 会为你创建实验。" : "描述要增加或调整的内容，AI 会基于当前实验修改。" }),
          /* @__PURE__ */ o("details", { children: [
            /* @__PURE__ */ e("summary", { children: "编辑实验源代码" }),
            /* @__PURE__ */ e("label", { htmlFor: `${n}-source`, children: "实验内容" }),
            /* @__PURE__ */ e("textarea", { id: `${n}-source`, "aria-label": "交互内容", value: t.source, onChange: (c) => t.onSourceChange(c.target.value), disabled: t.busy, rows: 14, spellCheck: !1 })
          ] })
        ] }) : /* @__PURE__ */ o("div", { id: `${n}-history`, role: "tabpanel", "aria-labelledby": `${n}-history-tab`, className: "fp-experiment-form", children: [
          /* @__PURE__ */ e("p", { className: "fp-experiment-hint", children: "恢复后会保留当前内容，方便再次找回。" }),
          t.versions?.length ? /* @__PURE__ */ o(Q, { children: [
            /* @__PURE__ */ e(ke, { label: "选择实验版本", value: i, onChange: l, options: t.versions.map((c) => ({ value: c.id, label: c.label })) }),
            /* @__PURE__ */ e("button", { type: "button", onClick: () => {
              t.onRestore?.(i), l("");
            }, disabled: !i || t.busy, children: "恢复此版本" })
          ] }) : /* @__PURE__ */ e("p", { children: "保存或完成一次修改后，可以在这里找回之前的内容。" })
        ] }),
        t.message && /* @__PURE__ */ e("p", { role: "status", className: "fp-experiment-message", children: t.message }),
        t.generationSummary && /* @__PURE__ */ e("div", { role: "status", className: "fp-experiment-hint", children: t.generationSummary })
      ] }),
      /* @__PURE__ */ o("section", { className: "fp-experiment-preview", "aria-label": "实验预览", children: [
        /* @__PURE__ */ o("header", { children: [
          /* @__PURE__ */ e("strong", { children: t.title || "未命名实验" }),
          /* @__PURE__ */ e("span", { children: "动手探索" })
        ] }),
        t.busy && /* @__PURE__ */ e("div", { className: "fp-experiment-progress", "aria-live": "polite", children: t.progress }),
        /* @__PURE__ */ e("div", { className: "fp-experiment-canvas", children: t.preview })
      ] })
    ] })
  ] });
}
function Kb({ steps: t, current: n }) {
  return /* @__PURE__ */ e("ol", { className: "fp-account-task-progress", "aria-label": "操作步骤", children: t.map((r, a) => /* @__PURE__ */ o("li", { "data-state": a < n ? "complete" : a === n ? "current" : "upcoming", "aria-current": a === n ? "step" : void 0, children: [
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: a < n ? /* @__PURE__ */ e(Pe, { size: 14 }) : a + 1 }),
    /* @__PURE__ */ e("strong", { children: r })
  ] }, r)) });
}
function kp({ label: t, hint: n, error: r, ...a }) {
  const i = ve(), l = a.id || i, s = l + "-help";
  return /* @__PURE__ */ o("div", { className: "fp-account-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: l, children: t }),
    /* @__PURE__ */ e("input", { ...a, id: l, "aria-invalid": !!r || void 0, "aria-describedby": n || r ? s : void 0 }),
    (r || n) && /* @__PURE__ */ o("p", { id: s, className: r ? "fp-account-field-error" : "fp-account-field-hint", role: r ? "alert" : void 0, children: [
      r && /* @__PURE__ */ e(Fr, { size: 15 }),
      /* @__PURE__ */ e("span", { children: r || n })
    ] })
  ] });
}
function Hb({ tone: t = "info", title: n, children: r, action: a }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-message", "data-tone": t, role: t === "error" ? "alert" : "status", children: [
    /* @__PURE__ */ e(t === "error" ? Fr : t === "success" ? ct : qo, { size: 19 }),
    /* @__PURE__ */ o("div", { children: [
      n && /* @__PURE__ */ e("strong", { children: n }),
      r && /* @__PURE__ */ e("div", { children: r }),
      a && /* @__PURE__ */ e("div", { className: "fp-account-message-action", children: a })
    ] })
  ] });
}
function Ub({ description: t }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-verification-intro", children: [
    /* @__PURE__ */ e("span", { children: /* @__PURE__ */ e(Or, { size: 22 }) }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { children: "确认是你本人" }),
      /* @__PURE__ */ e("p", { children: t || "完成一次验证，即可继续本次安全设置。" })
    ] })
  ] });
}
function _b({ value: t, onChange: n, onSend: r, busy: a = !1, sending: i = !1, sent: l = !1, remaining: s = 0, error: c, label: u = "邮箱验证码", destination: d }) {
  return /* @__PURE__ */ o("div", { className: "fp-account-code-field", children: [
    d && /* @__PURE__ */ o("p", { className: "fp-account-code-destination", children: [
      l ? "验证码已发送至" : "使用此邮箱接收验证码",
      /* @__PURE__ */ e("strong", { children: d })
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-account-code-controls", children: [
      /* @__PURE__ */ e(kp, { label: u, value: t, onChange: (p) => n(p.target.value.replace(/[^0-9]/g, "")), inputMode: "numeric", autoComplete: "one-time-code", maxLength: 6, required: !0, disabled: a, error: c, hint: l ? "请输入邮件中的 6 位验证码。" : "请先发送验证码。" }),
      /* @__PURE__ */ e(te, { variant: "secondary", loading: i, disabled: a || s > 0, onClick: r, "aria-label": s > 0 ? `${s} 秒后可以重新发送验证码` : l ? "重新发送验证码" : "发送验证码", children: i ? "正在发送…" : s > 0 ? `${s} 秒后重发` : l ? "重新发送" : "发送验证码" })
    ] })
  ] });
}
const xl = cn(null);
function Wb(t) {
  const n = Bt(xl), r = ve();
  Y(() => (n?.(r, t), () => n?.(r, !1)), [t, r, n]);
}
function Vb({ title: t, onClose: n, children: r, busy: a = !1 }) {
  const [i, l] = k({}), s = xe((c, u) => l((d) => d[c] === u ? d : { ...d, [c]: u }), []);
  return /* @__PURE__ */ e(ut, { open: !0, title: t, onClose: n, dismissible: !a && !Object.values(i).some(Boolean), className: "fp-account-task-dialog", children: /* @__PURE__ */ e(xl.Provider, { value: s, children: r }) });
}
function dt({
  label: t,
  children: n,
  ...r
}) {
  return /* @__PURE__ */ e(
    te,
    {
      variant: "ghost",
      ...r,
      className: _e("fp-icon-button", r.className),
      "aria-label": t,
      title: t,
      children: n
    }
  );
}
function Qr({
  className: t,
  ...n
}) {
  return /* @__PURE__ */ e("input", { ...n, className: _e("fp-input", t) });
}
function Np(t) {
  return /* @__PURE__ */ e("textarea", { ...t, className: _e("fp-input", t.className) });
}
function Yb({
  label: t,
  hint: n,
  error: r,
  children: a
}) {
  let i = ve();
  return /* @__PURE__ */ o("div", { className: "fp-field", children: [
    /* @__PURE__ */ e("label", { htmlFor: i, children: t }),
    Pt.cloneElement(a, {
      id: i,
      "aria-describedby": `${i}-help`,
      "aria-invalid": !!r
    }),
    (r || n) && /* @__PURE__ */ e("small", { id: `${i}-help`, className: r ? "fp-error-text" : "", children: r || n })
  ] });
}
function Zr({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "checkbox" }),
    t
  ] });
}
function Xb({
  label: t,
  ...n
}) {
  return /* @__PURE__ */ o("label", { className: "fp-check", children: [
    /* @__PURE__ */ e("input", { ...n, type: "radio" }),
    t
  ] });
}
function xp({
  label: t,
  checked: n,
  onChange: r,
  disabled: a
}) {
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      className: "fp-switch-label",
      role: "switch",
      "aria-checked": n,
      disabled: a,
      onClick: () => r(!n),
      children: [
        /* @__PURE__ */ e("span", { children: t }),
        /* @__PURE__ */ e("span", { className: _e("fp-switch", n && "is-on"), children: /* @__PURE__ */ e("i", {}) })
      ]
    }
  );
}
function Gb({
  label: t,
  min: n = 0,
  max: r = 100,
  step: a = 1,
  value: i,
  defaultValue: l,
  className: s,
  ...c
}) {
  let [u, d] = k(
    () => l === void 0 ? void 0 : Number(l)
  ), p = i !== void 0 ? Number(i) : u, h = Number(n), f = Number(r), m = p === void 0 || f === h ? 0 : (p - h) / (f - h) * 100;
  return /* @__PURE__ */ o("label", { className: _e("fp-slider", s), children: [
    t,
    /* @__PURE__ */ e(
      "input",
      {
        ...c,
        type: "range",
        min: n,
        max: r,
        step: a,
        value: i,
        defaultValue: l,
        onChange: (b) => {
          d(Number(b.target.value)), c.onChange?.(b);
        },
        style: {
          ...c.style,
          "--fp-slider-fill": `${Math.min(100, Math.max(0, m))}%`
        }
      }
    )
  ] });
}
function Cp({
  children: t,
  selected: n,
  onClick: r,
  onRemove: a
}) {
  return /* @__PURE__ */ o("span", { className: _e("fp-chip", n && "is-selected"), children: [
    /* @__PURE__ */ e("button", { type: "button", onClick: r, "aria-pressed": n, children: t }),
    a && /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        "aria-label": `移除 ${typeof t == "string" ? t : "项目"}`,
        onClick: a,
        children: "×"
      }
    )
  ] });
}
function Sp({
  name: t,
  src: n,
  size: r = 36
}) {
  return /* @__PURE__ */ e("span", { className: "fp-avatar", style: { width: r, height: r }, children: n ? /* @__PURE__ */ e("img", { src: n, alt: t }) : t.slice(0, 1) });
}
function Jb({ names: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-avatar-group", children: t.map((n) => /* @__PURE__ */ e(Sp, { name: n }, n)) });
}
function Qb() {
  return /* @__PURE__ */ e("hr", { className: "fp-divider" });
}
function Zb({
  title: t,
  children: n,
  tone: r = "accent"
}) {
  return /* @__PURE__ */ o(
    "div",
    {
      className: `fp-alert fp-tone-${r}`,
      role: r === "error" ? "alert" : "status",
      children: [
        /* @__PURE__ */ e("span", { className: "fp-alert-dot" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("strong", { children: t }),
          n && /* @__PURE__ */ e("p", { children: n })
        ] })
      ]
    }
  );
}
function eg({
  width: t = "100%",
  height: n = 16
}) {
  return /* @__PURE__ */ e("div", { className: "fp-skeleton", style: { width: t, height: n }, "aria-hidden": "true" });
}
function tg({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-progress-wrap", children: [
    n && /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ o("span", { children: [
        Math.round(t),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "fp-progress",
        role: "progressbar",
        "aria-label": n || "完成进度",
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": Math.min(100, Math.max(0, t)),
        children: /* @__PURE__ */ e("i", { style: { width: `${Math.min(100, Math.max(0, t))}%` } })
      }
    )
  ] });
}
function Mp(t) {
  return /* @__PURE__ */ e("div", { className: "fp-segmented", children: /* @__PURE__ */ e(Ur, { ...t }) });
}
function ng({
  items: t
}) {
  return /* @__PURE__ */ e("nav", { "aria-label": "当前位置", className: "fp-breadcrumbs", children: t.map((n, r) => /* @__PURE__ */ o(Pt.Fragment, { children: [
    r > 0 && /* @__PURE__ */ e("span", { children: "/" }),
    n.href ? /* @__PURE__ */ e("a", { href: n.href, children: n.label }) : /* @__PURE__ */ e("span", { "aria-current": "page", children: n.label })
  ] }, n.label)) });
}
function rg({
  page: t,
  total: n,
  onChange: r
}) {
  return /* @__PURE__ */ o("nav", { className: "fp-row", "aria-label": "分页", children: [
    /* @__PURE__ */ e(
      te,
      {
        variant: "secondary",
        size: "sm",
        disabled: t <= 1,
        onClick: () => r(t - 1),
        children: "上一页"
      }
    ),
    /* @__PURE__ */ o("span", { className: "fp-muted", children: [
      t,
      " / ",
      n
    ] }),
    /* @__PURE__ */ e(
      te,
      {
        variant: "secondary",
        size: "sm",
        disabled: t >= n,
        onClick: () => r(t + 1),
        children: "下一页"
      }
    )
  ] });
}
function ag({
  items: t,
  current: n
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-steps", children: t.map((r, a) => /* @__PURE__ */ o(
    "li",
    {
      "aria-current": a === n ? "step" : void 0,
      className: a <= n ? "is-active" : "",
      children: [
        /* @__PURE__ */ e("span", { children: a < n ? "✓" : a + 1 }),
        r
      ]
    },
    r
  )) });
}
function Ep({
  title: t,
  description: n,
  action: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-empty", children: [
    /* @__PURE__ */ e("div", { className: "fp-empty-symbol", children: "＋" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { children: n }),
    r
  ] });
}
function ig({
  message: t,
  onClose: n
}) {
  return Y(() => {
    let r = setTimeout(n, 4e3);
    return () => clearTimeout(r);
  }, [t, n]), /* @__PURE__ */ o("div", { className: "fp-toast", role: "status", children: [
    /* @__PURE__ */ e("span", { children: "✓" }),
    t,
    /* @__PURE__ */ e(dt, { label: "关闭提示", onClick: n, children: "×" })
  ] });
}
function lg({
  columns: t,
  rows: n,
  caption: r
}) {
  return /* @__PURE__ */ e("div", { className: "fp-table-scroll", children: /* @__PURE__ */ o("table", { className: "fp-table", children: [
    r && /* @__PURE__ */ e("caption", { children: r }),
    /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { children: t.map((a) => /* @__PURE__ */ e("th", { children: a }, a)) }) }),
    /* @__PURE__ */ e("tbody", { children: n.map((a, i) => /* @__PURE__ */ e("tr", { children: a.map((l, s) => /* @__PURE__ */ e("td", { children: l }, s)) }, i)) })
  ] }) });
}
function og({
  items: t
}) {
  return /* @__PURE__ */ e("dl", { className: "fp-descriptions", children: t.map((n) => /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ e("dt", { children: n.label }),
    /* @__PURE__ */ e("dd", { children: n.value })
  ] }, n.label)) });
}
function $p({
  items: t
}) {
  return /* @__PURE__ */ e("ol", { className: "fp-timeline", children: t.map((n) => /* @__PURE__ */ o("li", { children: [
    /* @__PURE__ */ e("strong", { children: n.title }),
    /* @__PURE__ */ e("p", { children: n.description })
  ] }, n.title)) });
}
function sg({
  label: t,
  value: n,
  detail: r
}) {
  return /* @__PURE__ */ o("div", { className: "fp-stat", children: [
    /* @__PURE__ */ e("span", { children: t }),
    /* @__PURE__ */ e("strong", { children: n }),
    r && /* @__PURE__ */ e("small", { children: r })
  ] });
}
function cg({
  onFiles: t,
  accept: n,
  multiple: r = !0
}) {
  let [a, i] = k([]);
  function l(s) {
    let c = Array.from(s || []);
    i(c.map((u) => u.name)), t(c);
  }
  return /* @__PURE__ */ o(
    "label",
    {
      className: "fp-upload",
      onDragOver: (s) => s.preventDefault(),
      onDrop: (s) => {
        s.preventDefault(), l(s.dataTransfer.files);
      },
      children: [
        /* @__PURE__ */ e("span", { className: "fp-upload-icon", children: "↥" }),
        /* @__PURE__ */ e("strong", { children: "选择文件，或拖放到这里" }),
        /* @__PURE__ */ e("small", { children: a.length ? a.join("、") : "资料会保留在你的设备上" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "file",
            accept: n,
            multiple: r,
            onChange: (s) => l(s.target.files)
          }
        )
      ]
    }
  );
}
function zp({
  value: t,
  onChange: n,
  placeholder: r = "搜索内容"
}) {
  return /* @__PURE__ */ o("div", { className: "fp-search-input", children: [
    /* @__PURE__ */ e("span", { "aria-hidden": "true", children: "⌕" }),
    /* @__PURE__ */ e(
      Qr,
      {
        "aria-label": r,
        placeholder: r,
        value: t,
        onChange: (a) => n(a.target.value)
      }
    ),
    t && /* @__PURE__ */ e(dt, { label: "清除搜索", onClick: () => n(""), children: "×" })
  ] });
}
function dg({
  value: t,
  onChange: n,
  min: r = 0,
  max: a = 100,
  label: i
}) {
  return /* @__PURE__ */ o("div", { className: "fp-number", children: [
    /* @__PURE__ */ e(
      dt,
      {
        label: `减少${i}`,
        disabled: t <= r,
        onClick: () => n(t - 1),
        children: "−"
      }
    ),
    /* @__PURE__ */ e(
      Qr,
      {
        "aria-label": i,
        type: "number",
        min: r,
        max: a,
        value: t,
        onChange: (l) => n(Math.min(a, Math.max(r, Number(l.target.value))))
      }
    ),
    /* @__PURE__ */ e(
      dt,
      {
        label: `增加${i}`,
        disabled: t >= a,
        onClick: () => n(t + 1),
        children: "＋"
      }
    )
  ] });
}
function ug({
  value: t,
  onChange: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-rating", role: "group", "aria-label": "评价", children: [1, 2, 3, 4, 5].map((r) => /* @__PURE__ */ e(
    "button",
    {
      type: "button",
      "aria-label": `${r} 星`,
      "aria-pressed": r === t,
      onClick: () => n(r),
      className: r <= t ? "is-active" : "",
      children: "★"
    },
    r
  )) });
}
function pg({ value: t, label: n }) {
  return /* @__PURE__ */ o("div", { className: "fp-meter", children: [
    /* @__PURE__ */ e("meter", { min: 0, max: 100, value: t, "aria-label": n }),
    /* @__PURE__ */ o("span", { children: [
      n,
      " · ",
      t,
      "%"
    ] })
  ] });
}
function hg({
  code: t,
  language: n = "tsx"
}) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-code", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e("span", { children: n }),
      /* @__PURE__ */ e(
        te,
        {
          size: "sm",
          variant: "ghost",
          onClick: async () => {
            try {
              await navigator.clipboard.writeText(t), a(!0), setTimeout(() => a(!1), 1800);
            } catch {
              a(!1);
            }
          },
          children: r ? "已复制" : "复制"
        }
      )
    ] }),
    /* @__PURE__ */ e("pre", { children: /* @__PURE__ */ e("code", { children: t }) })
  ] });
}
function fg({ children: t }) {
  return /* @__PURE__ */ e("kbd", { className: "fp-kbd", children: t });
}
function mg({
  children: t,
  ...n
}) {
  return /* @__PURE__ */ e("a", { ...n, className: _e("fp-link", n.className), children: t });
}
function bg({
  items: t
}) {
  return /* @__PURE__ */ e("div", { className: "fp-tree", children: t.map((n) => /* @__PURE__ */ e(Ap, { item: n }, n.label)) });
}
function Ap({
  item: t
}) {
  const [n, r] = Pt.useState(!0), a = Pt.useId();
  return t.children ? /* @__PURE__ */ o("div", { children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        className: "fp-tree-branch",
        "aria-expanded": n,
        "aria-controls": a,
        onClick: () => r((i) => !i),
        children: [
          /* @__PURE__ */ e(
            qt,
            {
              size: 14,
              style: { transform: n ? "rotate(0)" : "rotate(-90deg)" }
            }
          ),
          t.label
        ]
      }
    ),
    /* @__PURE__ */ e(Re, { isOpen: n, children: /* @__PURE__ */ e("div", { id: a, children: t.children.map((i) => /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: i }, i)) }) })
  ] }) : /* @__PURE__ */ e("div", { className: "fp-tree-leaf", children: t.label });
}
function gg({
  items: t,
  value: n,
  onChange: r
}) {
  return /* @__PURE__ */ e("nav", { className: "fp-navigation", children: t.map((a) => /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      "aria-current": n === a.value ? "page" : void 0,
      onClick: () => r(a.value),
      children: [
        a.icon,
        a.label
      ]
    },
    a.value
  )) });
}
function vg({ children: t }) {
  return /* @__PURE__ */ e("div", { className: "fp-toolbar", role: "group", "aria-label": "内容操作", children: t });
}
function yg({
  title: t,
  children: n
}) {
  return /* @__PURE__ */ o("aside", { className: "fp-callout", children: [
    /* @__PURE__ */ e("strong", { children: t }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function wg({
  title: t,
  detail: n,
  onClick: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-citation", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "↗" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] })
  ] });
}
function kg({
  role: t,
  children: n
}) {
  return /* @__PURE__ */ o("article", { className: `fp-message fp-message-${t}`, children: [
    /* @__PURE__ */ e("strong", { children: t === "user" ? "你" : "五加一 AI" }),
    /* @__PURE__ */ e("div", { children: n })
  ] });
}
function Ng({
  onSend: t,
  disabled: n = !1
}) {
  let [r, a] = k("");
  return /* @__PURE__ */ o(
    "form",
    {
      className: "fp-composer",
      onSubmit: (i) => {
        i.preventDefault(), r.trim() && (t(r.trim()), a(""));
      },
      children: [
        /* @__PURE__ */ e(
          Np,
          {
            "aria-label": "向 AI 提问",
            placeholder: "从一个想法开始…",
            value: r,
            onChange: (i) => a(i.target.value),
            disabled: n
          }
        ),
        /* @__PURE__ */ o("footer", { children: [
          /* @__PURE__ */ e("span", { children: "让想法继续生长" }),
          /* @__PURE__ */ e(te, { size: "sm", disabled: n || !r.trim(), type: "submit", children: "发送 ↑" })
        ] })
      ]
    }
  );
}
function xg({
  title: t,
  steps: n,
  running: r,
  onToggle: a
}) {
  return /* @__PURE__ */ o(Dt, { children: [
    /* @__PURE__ */ o("div", { className: "fp-between", children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e(Kr, { tone: r ? "accent" : "neutral", children: r ? "进行中" : "已暂停" })
    ] }),
    /* @__PURE__ */ e(
      $p,
      {
        items: n.map((i, l) => ({
          title: i,
          description: l === n.length - 1 ? r ? "正在进行" : "等待继续" : "已完成"
        }))
      }
    ),
    /* @__PURE__ */ e(te, { variant: "secondary", size: "sm", onClick: a, children: r ? "暂停整理" : "继续整理" })
  ] });
}
function Cg({
  title: t,
  description: n,
  onApply: r
}) {
  return /* @__PURE__ */ o(Dt, { children: [
    /* @__PURE__ */ e(Kr, { tone: "success", children: "已完成" }),
    /* @__PURE__ */ e("h3", { children: t }),
    /* @__PURE__ */ e("p", { className: "fp-muted", children: n }),
    /* @__PURE__ */ e(te, { onClick: r, children: "应用到笔记 ↗" })
  ] });
}
function Sg({
  name: t,
  detail: n,
  onOpen: r
}) {
  return /* @__PURE__ */ o("button", { type: "button", className: "fp-file-card", onClick: r, children: [
    /* @__PURE__ */ e("span", { children: "▤" }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: t }),
      /* @__PURE__ */ e("small", { children: n })
    ] }),
    /* @__PURE__ */ e("span", { children: "↗" })
  ] });
}
function Mg({
  eyebrow: t,
  title: n,
  description: r,
  action: a
}) {
  return /* @__PURE__ */ o("header", { className: "fp-page-header", children: [
    /* @__PURE__ */ o("div", { children: [
      t && /* @__PURE__ */ e("span", { className: "fp-eyebrow", children: t }),
      /* @__PURE__ */ e("h1", { children: n }),
      r && /* @__PURE__ */ e("p", { children: r })
    ] }),
    a
  ] });
}
function Eg({
  children: t,
  className: n,
  ...r
}) {
  return /* @__PURE__ */ e("div", { ...r, className: _e("fp-container", n), children: t });
}
function $g({
  children: t,
  gap: n,
  direction: r = "column"
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "flex",
        flexDirection: r,
        gap: n ?? (r === "row" ? 12 : 24),
        flexWrap: r === "row" ? "wrap" : void 0
      },
      children: t
    }
  );
}
function zg({
  children: t,
  minWidth: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      style: {
        display: "grid",
        gridTemplateColumns: `repeat(auto-fit,minmax(min(${n}px,100%),1fr))`,
        gap: 20
      },
      children: t
    }
  );
}
function Ag({
  children: t,
  height: n = 240
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "fp-scroll-area",
      tabIndex: 0,
      style: { maxHeight: n, overflow: "auto" },
      children: t
    }
  );
}
function Ig({
  children: t,
  ratio: n = 16 / 9
}) {
  return /* @__PURE__ */ e("div", { style: { aspectRatio: n, overflow: "hidden" }, children: t });
}
function Lg({
  label: t,
  options: n,
  value: r,
  onChange: a
}) {
  return /* @__PURE__ */ o("fieldset", { className: "fp-multiselect", children: [
    /* @__PURE__ */ e("legend", { children: t }),
    n.map((i) => /* @__PURE__ */ e(
      Cp,
      {
        selected: r.includes(i),
        onClick: () => a(
          r.includes(i) ? r.filter((l) => l !== i) : [...r, i]
        ),
        children: i
      },
      i
    ))
  ] });
}
function Tg({
  label: t = "密码",
  ...n
}) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o("div", { className: "fp-password", children: [
    /* @__PURE__ */ e(Qr, { ...n, "aria-label": t, type: r ? "text" : "password" }),
    /* @__PURE__ */ e(
      dt,
      {
        label: r ? "隐藏密码" : "显示密码",
        onClick: () => a(!r),
        type: "button",
        children: r ? "隐藏" : "显示"
      }
    )
  ] });
}
function Dg({
  children: t,
  onClose: n
}) {
  return /* @__PURE__ */ o("div", { className: "fp-banner", role: "status", children: [
    /* @__PURE__ */ e("span", { children: t }),
    n && /* @__PURE__ */ e(dt, { label: "关闭通知", onClick: n, children: "×" })
  ] });
}
function Pg({
  value: t,
  onChange: n
}) {
  let r = t ? /* @__PURE__ */ new Date(t + "T12:00:00") : /* @__PURE__ */ new Date(), [a, i] = k(
    new Date(r.getFullYear(), r.getMonth(), 1)
  ), l = a.getFullYear(), s = a.getMonth(), c = new Date(l, s, 1).getDay(), u = new Date(l, s + 1, 0).getDate();
  return /* @__PURE__ */ o("div", { className: "fp-calendar", children: [
    /* @__PURE__ */ o("header", { children: [
      /* @__PURE__ */ e(
        dt,
        {
          label: "上个月",
          onClick: () => i(new Date(l, s - 1, 1)),
          children: "‹"
        }
      ),
      /* @__PURE__ */ o("strong", { children: [
        l,
        " 年 ",
        s + 1,
        " 月"
      ] }),
      /* @__PURE__ */ e(
        dt,
        {
          label: "下个月",
          onClick: () => i(new Date(l, s + 1, 1)),
          children: "›"
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "fp-calendar-grid", children: [
      "日一二三四五六".split("").map((d) => /* @__PURE__ */ e("span", { children: d }, d)),
      Array.from({ length: c }, (d, p) => /* @__PURE__ */ e("span", {}, "s" + p)),
      Array.from({ length: u }, (d, p) => {
        let h = `${l}-${String(s + 1).padStart(2, "0")}-${String(p + 1).padStart(2, "0")}`;
        return /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            "aria-label": h,
            "aria-pressed": t === h,
            onClick: () => n(h),
            children: p + 1
          },
          h
        );
      })
    ] })
  ] });
}
function Fg({
  first: t,
  second: n
}) {
  let [r, a] = k(50), i = B(null);
  return /* @__PURE__ */ o(
    "div",
    {
      ref: i,
      className: "fp-resizable",
      style: {
        gridTemplateColumns: `minmax(0,${r}fr) 10px minmax(0,${100 - r}fr)`
      },
      children: [
        /* @__PURE__ */ e("div", { children: t }),
        /* @__PURE__ */ e(
          "div",
          {
            role: "separator",
            "aria-label": "调整面板宽度",
            "aria-orientation": "vertical",
            "aria-valuenow": Math.round(r),
            "aria-valuemin": 25,
            "aria-valuemax": 75,
            tabIndex: 0,
            onKeyDown: (l) => {
              ["ArrowLeft", "ArrowRight", "Home", "End"].includes(l.key) && (l.preventDefault(), a(
                l.key === "Home" ? 25 : l.key === "End" ? 75 : Math.max(
                  25,
                  Math.min(75, r + (l.key === "ArrowRight" ? 5 : -5))
                )
              ));
            },
            onPointerDown: (l) => {
              l.currentTarget.setPointerCapture(l.pointerId);
            },
            onPointerMove: (l) => {
              if (l.currentTarget.hasPointerCapture(l.pointerId)) {
                let s = i.current.getBoundingClientRect();
                a(
                  Math.max(
                    25,
                    Math.min(75, (l.clientX - s.left) / s.width * 100)
                  )
                );
              }
            }
          }
        ),
        /* @__PURE__ */ e("div", { children: n })
      ]
    }
  );
}
function Og({
  open: t,
  onClose: n,
  onConfirm: r,
  title: a,
  description: i
}) {
  return /* @__PURE__ */ e(
    ut,
    {
      open: t,
      onClose: n,
      title: a,
      footer: /* @__PURE__ */ o(Q, { children: [
        /* @__PURE__ */ e(te, { variant: "secondary", onClick: n, children: "取消" }),
        /* @__PURE__ */ e(te, { variant: "danger", onClick: r, children: "确认移除" })
      ] }),
      children: /* @__PURE__ */ e("p", { children: i })
    }
  );
}
function Rg({
  open: t,
  onClose: n,
  items: r
}) {
  let [a, i] = k(""), [l, s] = k(0), c = r.filter(
    (u) => u.label.toLowerCase().includes(a.toLowerCase())
  );
  return Y(() => {
    t && (i(""), s(0));
  }, [t]), /* @__PURE__ */ e(ut, { open: t, onClose: n, title: "快速前往", children: /* @__PURE__ */ o(
    "div",
    {
      onKeyDown: (u) => {
        u.key === "ArrowDown" && (u.preventDefault(), s((l + 1) % Math.max(1, c.length))), u.key === "ArrowUp" && (u.preventDefault(), s(
          (l - 1 + c.length) % Math.max(1, c.length)
        )), u.key === "Enter" && c[l] && (u.preventDefault(), c[l].onSelect(), n());
      },
      children: [
        /* @__PURE__ */ e(
          zp,
          {
            value: a,
            onChange: (u) => {
              i(u), s(0);
            },
            placeholder: "搜索页面与组件"
          }
        ),
        /* @__PURE__ */ o("div", { className: "fp-command-results", children: [
          c.map((u, d) => /* @__PURE__ */ o(
            "button",
            {
              type: "button",
              className: d === l ? "is-active" : "",
              onClick: () => {
                u.onSelect(), n();
              },
              children: [
                u.label,
                /* @__PURE__ */ e("span", { children: "↵" })
              ]
            },
            u.label
          )),
          !c.length && /* @__PURE__ */ e("p", { children: "没有匹配的结果，试试其他关键词。" })
        ] })
      ]
    }
  ) });
}
function Bg({
  items: t,
  onRead: n
}) {
  return /* @__PURE__ */ e("div", { className: "fp-notifications", children: t.map((r) => /* @__PURE__ */ o("button", { type: "button", onClick: () => n(r.id), children: [
    /* @__PURE__ */ e("span", { className: _e("fp-notification-dot", !r.read && "is-unread") }),
    /* @__PURE__ */ o("span", { children: [
      /* @__PURE__ */ e("strong", { children: r.title }),
      /* @__PURE__ */ e("small", { children: r.detail })
    ] }),
    /* @__PURE__ */ e("span", { children: r.read ? "已读" : "查看" })
  ] }, r.id)) });
}
function jg({
  items: t,
  label: n
}) {
  let r = Math.max(1, ...t.map((a) => a.value));
  return /* @__PURE__ */ o("figure", { className: "fp-chart", "aria-label": n, children: [
    /* @__PURE__ */ e("figcaption", { children: n }),
    t.map((a) => /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("span", { children: a.label }),
      /* @__PURE__ */ e("i", { style: { width: `${a.value / r * 70}%` } }),
      /* @__PURE__ */ e("strong", { children: a.value })
    ] }, a.label))
  ] });
}
function qg({ src: t, alt: n }) {
  let [r, a] = k(!1);
  return /* @__PURE__ */ o(Q, { children: [
    /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        className: "fp-image-button",
        onClick: () => a(!0),
        "aria-label": `放大${n}`,
        children: /* @__PURE__ */ e("img", { src: t, alt: n })
      }
    ),
    /* @__PURE__ */ e(ut, { open: r, onClose: () => a(!1), title: n, children: /* @__PURE__ */ e("img", { style: { width: "100%" }, src: t, alt: n }) })
  ] });
}
function Kg({
  title: t = "暂时无法显示内容",
  description: n,
  onRetry: r
}) {
  return /* @__PURE__ */ e(
    Ep,
    {
      title: t,
      description: n,
      action: /* @__PURE__ */ e(te, { onClick: r, children: "重新加载" })
    }
  );
}
function Hg({ children: t }) {
  return /* @__PURE__ */ e("footer", { className: "fp-footer", children: t });
}
function Ug({ children: t }) {
  return /* @__PURE__ */ e("span", { className: "fp-sr-only", children: t });
}
export {
  Ng as AIComposer,
  kg as AIMessage,
  xf as AISettingsWorkspace,
  xm as AcademicYearSwitcher,
  yh as Accordion,
  _b as AccountCodeField,
  Hb as AccountFeedback,
  kp as AccountField,
  af as AccountLayout,
  Qm as AccountMenu,
  Xf as AccountPanel,
  Gf as AccountSetting,
  Vb as AccountTaskDialog,
  Kb as AccountTaskProgress,
  Ub as AccountVerificationIntro,
  Yf as AccountWorkspace,
  wl as ActionToolbar,
  bl as AdministratorAccess,
  hf as AdministratorDirectory,
  sm as AgentTrace,
  Zb as Alert,
  $b as AnalyticsWorkspace,
  Ef as AnchoredPanel,
  fe as AnimatedSize,
  pb as AppEntryLayout,
  Sf as AppearanceWorkspace,
  eb as ApplicationAccess,
  Sm as ApprovalCard,
  Ff as ArtifactCard,
  Of as ArtifactPreview,
  Ig as AspectRatio,
  Tb as AssistantPreferences,
  be as AsyncAction,
  tl as Attachment,
  fm as AttachmentGrid,
  am as AttachmentPicker,
  Mn as AudioPlayer,
  Rb as AuditLogWorkspace,
  km as AuthenticationWindow,
  Sp as Avatar,
  Jf as AvatarEditor,
  Jb as AvatarGroup,
  Uh as BacklinksPanel,
  Kr as Badge,
  Dg as Banner,
  jg as BarChart,
  nf as Bookshelf,
  Im as BottomNav,
  Vf as BrandLogo,
  ng as Breadcrumbs,
  zu as BrowserPreferences,
  Iu as BrowserSurface,
  ef as BrowserWorkspace,
  te as Button,
  ub as ButtonLink,
  Pg as Calendar,
  yg as Callout,
  kr as CanvasBlockRenderer,
  bc as CanvasDiagnosticPanel,
  gc as CanvasRevisionPanel,
  jf as CanvasWorkbench,
  wf as CanvasWorkspace,
  ff as CapacityDirectory,
  ml as CapacityEditor,
  Rh as CapacityOverview,
  Dt as Card,
  $s as CardBodyBoundary,
  Lf as CardEditorFrame,
  ld as CauseEffect,
  rm as ChatComposer,
  vm as ChatEmptyState,
  _m as ChatPreferencesPanel,
  Zr as Checkbox,
  Cp as Chip,
  Zm as ChoiceCards,
  wg as Citation,
  Cm as CitationList,
  qf as ClassroomTimeline,
  hg as CodeBlock,
  tm as CollaborativeEditor,
  Re as CollapseTransition,
  hm as CollapsibleSection,
  yl as ColorPicker,
  Wf as Combobox,
  Rg as CommandMenu,
  kf as CommerceWorkspace,
  rd as CompareTable,
  nd as ConceptCard,
  Og as ConfirmDialog,
  Eg as Container,
  Nr as ContentImage,
  gl as ContentSkeleton,
  yt as ContextMenu,
  om as ConversationViewport,
  Vh as CourseContentWorkspace,
  Du as CreditAdjustment,
  Oh as CreditsOverview,
  Ka as DatePicker,
  od as Derivation,
  og as DescriptionList,
  ut as Dialog,
  Zi as DirectiveBlock,
  Ls as DirectiveFields,
  cf as DirectoryPicker,
  tf as DirectoryWorkspace,
  If as DiscardChangesPrompt,
  zm as DistributionChart,
  Qb as Divider,
  ab as DocumentationCards,
  rb as DocumentationLayout,
  lb as DocumentationSearch,
  wh as Drawer,
  ki as Dropdown,
  Xi as EditorContextMenu,
  Ud as EditorUniqueID,
  bm as EmbedFallback,
  Ep as EmptyState,
  Kg as ErrorState,
  Aa as EventCard,
  Mh as ExperimentLibrary,
  qb as ExperimentWorkbench,
  nb as FeatureCardStack,
  Yb as Field,
  sd as Figure,
  Sg as FileCard,
  Qf as FileTree,
  cg as FileUpload,
  Nm as FilterSelect,
  cm as FlipCard,
  Jh as FloatingWindow,
  bf as FollowUpQuestions,
  Hg as Footer,
  $m as FormulaSteps,
  Di as FunctionPlot,
  Bf as GraphView,
  zg as Grid,
  Lu as GroupEditor,
  ud as HistoryLocationMap,
  $h as HistoryMap,
  ys as HorizontalScrollbar,
  dt as IconButton,
  Ji as ImageConversion,
  Lm as ImageGallery,
  _h as ImagePasteOptions,
  qg as ImagePreview,
  Qh as ImportPanel,
  Qr as Input,
  tb as InstallerPanel,
  sf as InvitationList,
  fg as Kbd,
  td as KeyPoint,
  Zh as LazyVisible,
  cd as LearningAnimation,
  zi as LearningExperiment,
  Mf as LearningRecords,
  ku as LearningSourceView,
  Kf as LectureDock,
  wu as LectureWorkspace,
  Fh as LedgerView,
  mg as Link,
  lf as LoginForm,
  Ib as ManagementForm,
  Nu as ManagementTable,
  Ab as ManagementWorkspace,
  vt as MarkdownContent,
  Jn as MarkdownEditor,
  lm as MarkdownEditorSurface,
  ib as MarkerLogo,
  Ns as MediaControls,
  op as MediaLightbox,
  gr as MediaSlider,
  Ju as MemberAccess,
  Qu as MemberSearch,
  Eh as MemoryCard,
  _i as MermaidPreview,
  Gu as MessageBubble,
  Pf as MessageContentView,
  nm as MessageList,
  pg as Meter,
  Nb as MobileActionGrid,
  xb as MobileCollectionRow,
  wb as MobileHeader,
  Sb as MobileNotebookCard,
  Cb as MobileNotebookGrid,
  Eb as MobileRecorder,
  kb as MobileSection,
  rf as MobileTopBar,
  Mb as MobileWelcome,
  rp as ModelSelector,
  Lg as MultiSelect,
  Lh as NOTE_SCHEMA_VERSION,
  gg as Navigation,
  Dm as NavigationCard,
  Mu as NoteEditorWorkspace,
  zh as NoteLink,
  Bd as NoteToolbar,
  Kh as NotebookManagerWorkspace,
  xu as NotebookPublishing,
  Bg as NotificationList,
  dg as NumberInput,
  Mg as PageHeader,
  rg as Pagination,
  Tg as PasswordInput,
  ks as PdfPreview,
  Bh as PermissionSummary,
  df as PlanPicker,
  mf as PlatformReset,
  pf as PlatformWorkspace,
  Nh as Popover,
  et as Popup,
  Pm as PreviewCard,
  cb as ProductEditorialSection,
  sb as ProductEditorialSections,
  bb as ProductFeatures,
  fb as ProductLanding,
  Tu as ProductNavigation,
  Gm as ProductPreviewCard,
  mb as ProductSection,
  ob as ProductStatementHero,
  tg as Progress,
  Db as ProviderManager,
  mm as QuizQuestion,
  Hf as QuizScoring,
  Uf as QuizSummary,
  Rm as QuizWorkspace,
  Ha as READING_FONTS,
  Xb as Radio,
  ug as Rating,
  pd as ReadingTimeline,
  dd as RecallContent,
  Hm as RecordingPlayback,
  Fm as RecycleBin,
  db as ReleaseNotes,
  vf as ReleaseNotice,
  Fg as ResizablePanel,
  zb as ResourceBrowser,
  bp as ResourceExplorer,
  Cs as ResourcePreview,
  Wm as ResourceWorkspace,
  Cg as ResultCard,
  Om as ReviewDashboard,
  Km as RunWorkspace,
  Hh as SaveConflict,
  Ag as ScrollArea,
  zp as SearchInput,
  Tf as SearchResults,
  Mp as SegmentedControl,
  _f as Select,
  ke as SelectField,
  Bm as SelectionActions,
  dm as SelectionToolbar,
  wm as SessionHistory,
  jh as SettingsForm,
  Af as SettingsLayout,
  Pb as SettingsLinks,
  gm as SettingsSection,
  Ve as SettingsTabs,
  qh as SetupWizard,
  Um as ShareAccessPanel,
  Zu as ShareLink,
  zf as ShareMemberRow,
  gf as SharedReadingPage,
  Am as ShortcutHelp,
  Yh as ShortcutProvider,
  Gh as ShortcutSettings,
  Em as SiblingFiles,
  eg as Skeleton,
  Rf as SkillsPanel,
  Nf as SkillsWorkspace,
  Bb as SlideTransition,
  Gb as Slider,
  ym as SourceFold,
  Hr as Spinner,
  $g as Stack,
  sg as Stat,
  hb as StatusPage,
  ag as Steps,
  hu as SuggestionList,
  oc as SurfaceBoundary,
  Ti as SvgCanvas,
  xp as Switch,
  um as SyncStatus,
  lg as Table,
  Ur as Tabs,
  jm as TaskProgress,
  xg as TaskStatus,
  Np as Textarea,
  $f as ThemeToggle,
  Cf as TimePicker,
  $p as Timeline,
  ig as Toast,
  Mm as TocTree,
  ap as TokenDashboard,
  pm as TokenDashboardAuto,
  vg as Toolbar,
  Cd as Tooltip,
  xd as TooltipProvider,
  yb as TransferQueue,
  bg as Tree,
  vb as UpdatePanel,
  Lb as UpgradeRequiredDialog,
  Qi as UploadPlaceholder,
  im as UploadQueue,
  uf as UserDetailsWorkspace,
  Ob as UserNotebookList,
  of as UserProfile,
  fl as UserProfileEditor,
  Fb as UserUsageOverview,
  Ah as VennDiagram,
  Wh as VersionDiff,
  Su as VersionHistory,
  en as VideoPlayer,
  Yc as VisualCodeBlock,
  Ug as VisuallyHidden,
  pl as WindowChrome,
  Ym as WindowControls,
  Xm as WindowDragRegion,
  Tm as WindowTaskbar,
  qm as WorkspaceEmpty,
  Se as WorkspaceFeedback,
  X as WorkspaceField,
  Zf as WorkspaceLayout,
  it as WorkspaceSave,
  ee as WorkspaceSection,
  gb as WorkspaceSkeleton,
  Df as WorkspaceTabs,
  Ae as WorkspaceToggle,
  vs as Y,
  Ms as acknowledgeCardEdit,
  Hu as appearanceStyles,
  Ih as appendUploadPlaceholder,
  Gr as baseEditorExtensions,
  Dh as bindNestedMathEditor,
  qu as brandColor,
  Yu as brandLogoUrl,
  ur as calculateAvatarCrop,
  Sa as calculateTicks,
  Ni as cardEditRequested,
  bn as cardTypeForCommand,
  Ia as codeLanguageForCommand,
  Xr as compileMathExpr,
  Ch as configureEditorCommandUsage,
  Th as configureMathPreferences,
  sr as constrainWindowGeometry,
  Es as continueAfterCard,
  Jm as createDocumentationMotion,
  ju as createEditableAIModel,
  eu as createLazyMathExtensions,
  _e as cx,
  Ua as defaultGraphSettings,
  bd as deleteEditorBlock,
  Pa as documentToMarkdown,
  Mi as editorCommandFrequencies,
  Sh as editorCommandFrequency,
  yr as editorCommandUsageChanged,
  vr as editorCommandUsageKey,
  Yi as editorInsertCommands,
  sn as editorSearchText,
  Gs as getLearningExperiment,
  tr as insertDirectiveCard,
  Wi as insertMermaidCard,
  kh as learningAlpha,
  _r as learningExperiments,
  nl as markdownToDocument,
  xh as mergeEditorCommandUsage,
  Vm as mountWindowTitleBar,
  xr as moveEditorBlock,
  qi as nestedEditorNodeViewEvents,
  Fn as normalizeBrowserUrl,
  Si as notifyEditorCommandUsage,
  Ph as openActiveMathEditor,
  Ss as openEditorLink,
  Ei as parseDirectiveAttributes,
  $n as parseEditorCommandUsage,
  Bu as parseSkillFile,
  Ku as productThemes,
  vp as rankDocumentation,
  As as recordEditorCommandUse,
  yp as renderReleaseNotes,
  cr as replaceAIModelReferences,
  Uu as resolveContentTypography,
  uc as sanitizeSvg,
  kd as searchEditorCommands,
  ma as setDirectiveAttribute,
  Cr as tableSizeForCommand,
  Wb as useAccountTaskBusy,
  em as useCollaboration,
  gu as useMathEditor,
  yf as useReleaseUpdate,
  Xh as useShortcut,
  Le as useWorkspaceAction,
  nt as useWorkspaceDraft,
  ja as validateAISettings,
  Ou as validateCommerceSettings,
  _u as visibleActionCount,
  jb as workspaceTabShortcut
};
