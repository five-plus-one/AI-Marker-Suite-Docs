/** Keep the host's flyout state while supplying consistent dismissal behavior. */
export function mountDocumentationFlyouts(){
 const groups=()=>Array.from(document.querySelectorAll<HTMLElement>('.VPNavBarMenuGroup'));
 const trigger=(group:HTMLElement)=>group.querySelector<HTMLButtonElement>(':scope > button');
 const dismiss=(group:HTMLElement)=>{group.dataset.fpDismissed='';const button=trigger(group);if(button?.getAttribute('aria-expanded')==='true')button.click()};
 const key=(event:KeyboardEvent)=>{
  const target=event.target as HTMLElement,group=target.closest<HTMLElement>('.VPNavBarMenuGroup');
  if(event.key==='Escape'){
   const open=groups().filter(item=>trigger(item)?.getAttribute('aria-expanded')==='true'||item.matches(':hover'));
   if(!open.length)return;
   event.preventDefault();event.stopPropagation();open.forEach(dismiss);if(group)trigger(group)?.focus();
  }else if(group&&target.closest('button')===trigger(group)&&['Enter',' ','ArrowDown','ArrowUp'].includes(event.key)){
   delete group.dataset.fpDismissed;
   if(event.key.startsWith('Arrow')){event.preventDefault();const button=trigger(group);if(button?.getAttribute('aria-expanded')!=='true')button?.click();queueMicrotask(()=>{const links=group.querySelectorAll<HTMLAnchorElement>('.menu a[href]');(event.key==='ArrowUp'?links[links.length-1]:links[0])?.focus()})}
  }
 };
 const pointer=(event:PointerEvent)=>{const target=event.target as HTMLElement;groups().forEach(group=>{if(!group.contains(target))dismiss(group);else if(target.closest('button')===trigger(group))delete group.dataset.fpDismissed})};
 const enter=(event:PointerEvent)=>{const group=(event.target as HTMLElement).closest<HTMLElement>('.VPNavBarMenuGroup');if(group&&!(event.relatedTarget instanceof Node&&group.contains(event.relatedTarget)))delete group.dataset.fpDismissed};
 const scroll=()=>groups().forEach(group=>{if(trigger(group)?.getAttribute('aria-expanded')==='true'||group.matches(':hover'))dismiss(group)});
 document.addEventListener('keydown',key,true);document.addEventListener('pointerdown',pointer,true);document.addEventListener('pointerover',enter,true);window.addEventListener('scroll',scroll,{passive:true});
 return ()=>{document.removeEventListener('keydown',key,true);document.removeEventListener('pointerdown',pointer,true);document.removeEventListener('pointerover',enter,true);window.removeEventListener('scroll',scroll);groups().forEach(group=>delete group.dataset.fpDismissed)};
}
