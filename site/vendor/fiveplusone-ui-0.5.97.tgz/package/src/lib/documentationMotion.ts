import {mountSelectionIndicator} from './selectionMotion';
import {mountDocumentationFlyouts} from './documentationFlyouts';
/** Animate reading content while navigation, focus and URL handling stay with the host. */
export function createDocumentationMotion(){
 const destroyFlyouts=mountDocumentationFlyouts();
 const reduced=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const content=()=>document.querySelector<HTMLElement>('.VPDoc .content, .VPPage');
 let animation:Animation|undefined,observer:IntersectionObserver|undefined;
 const selections=new Map<HTMLElement,ReturnType<typeof mountSelectionIndicator>>();
 const syncSelections=()=>{
  for(const [host,motion]of selections)if(!host.isConnected){motion.destroy();selections.delete(host)}
  for(const host of document.querySelectorAll<HTMLElement>('.VPNavBarMenu,#VPSidebarNav')){
   if(!selections.has(host))selections.set(host,mountSelectionIndicator(host,host.matches('.VPNavBarMenu')?{active:'.VPNavBarMenuLink.active,.VPNavBarMenuGroup.active',inset:12}:{active:'.VPSidebarItem.level-1.is-active > .item',surface:true}));
  }
 };
 const reveal=()=>{
  syncSelections();
  observer?.disconnect();
  const elements=document.querySelectorAll<HTMLElement>('[data-fp-reveal]');
  if(reduced()||!('IntersectionObserver'in window)){elements.forEach(el=>{el.dataset.fpReveal='visible'});return}
  observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){(entry.target as HTMLElement).dataset.fpReveal='visible';observer?.unobserve(entry.target)}},{threshold:.08});
  elements.forEach(el=>{if(el.dataset.fpReveal!=='visible')observer?.observe(el)});
 };
 return {
  begin(){animation?.cancel();if(!reduced())animation=content()?.animate([{opacity:1,transform:'translateY(0)'},{opacity:.25,transform:'translateY(-6px)'}],{duration:160,easing:'cubic-bezier(.4,0,1,1)'})},
  complete(){animation?.cancel();if(!reduced())animation=content()?.animate([{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:440,easing:'cubic-bezier(.16,1,.3,1)'});reveal()},
  reveal,
  destroy(){destroyFlyouts();animation?.cancel();observer?.disconnect();selections.forEach(motion=>motion.destroy());selections.clear()}
 };
}
