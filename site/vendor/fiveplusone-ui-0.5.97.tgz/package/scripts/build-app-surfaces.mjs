import {build} from 'esbuild';
import {readFile} from 'node:fs/promises';
await build({entryPoints:['src/lib/AppSurfaces.tsx'],outfile:'dist-library/app-surfaces.js',bundle:true,format:'esm',platform:'neutral',jsx:'automatic',external:['react','react/jsx-runtime','react-dom','lucide-react'],minify:true});
const styles=await readFile('dist-library/app-surfaces.css','utf8');
for(const selector of ['.fp-account-avatar','.fp-account-menu-identity','.fp-account-menu-group','.fp-popup-panel','.fp-tooltip-bubble','.fp-docs-header','.fp-docs-drawer','.fp-docs-cards','.fp-product-preview','.fp-product-preview-panel','.fp-release-notes','.fp-release-group']){
 if(!styles.includes(selector))throw Error('Entry surface stylesheet is missing '+selector);
}
