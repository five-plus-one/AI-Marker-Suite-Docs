/** Keep the outer ProseMirror view from selecting or dragging a nested editor's card. */
export const nestedEditorNodeViewEvents = {
 stopEvent: ({event}:{event:Event}) => {
  const element=event.target instanceof Element?event.target:event.target instanceof globalThis.Node?event.target.parentElement:null;
  return !!element?.closest('[data-nested-editor-boundary]');
 },
};
