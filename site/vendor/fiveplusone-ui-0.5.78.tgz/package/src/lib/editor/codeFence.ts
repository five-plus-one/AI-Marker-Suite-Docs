import { InputRule, type Editor } from '@tiptap/core';
import type { NodeType } from '@tiptap/pm/model';
import { Plugin, PluginKey, TextSelection } from '@tiptap/pm/state';

const pendingFence = new PluginKey<number | null>('codeFence');
const languageToken = /^[a-zA-Z][a-zA-Z0-9_+#.-]*$/;

/** The third backtick opens the block; its optional language ends with Space or Enter. */
export function codeFenceInputRule(type: NodeType) {
  return new InputRule({
    find: /^```$/,
    handler: ({ state, range }) => {
      const start = state.doc.resolve(range.from);
      if (!start.node(-1).canReplaceWith(start.index(-1), start.indexAfter(-1), type)) return null;
      const tr = state.tr.delete(range.from, range.to).setBlockType(range.from, range.from, type);
      tr.setMeta(pendingFence, tr.selection.$from.before());
    },
  });
}

export function codeFencePlugin() {
  return new Plugin<number | null>({
    key: pendingFence,
    state: {
      init: () => null,
      apply(tr, position) {
        const explicit = tr.getMeta(pendingFence);
        if (explicit !== undefined) return explicit;
        if (position === null) return null;
        if (tr.selectionSet && !tr.docChanged) return null;
        const mapped = tr.mapping.map(position, -1), node = tr.doc.nodeAt(mapped);
        const { selection } = tr;
        if (node?.type.name !== 'codeBlock' || node.attrs.language || !selection.empty ||
            selection.$from.start() !== mapped + 1 || selection.$from.parentOffset !== node.content.size ||
            (node.textContent && !languageToken.test(node.textContent))) return null;
        return mapped;
      },
    },
  });
}

export function completeCodeFence(editor: Editor) {
  const position = pendingFence.getState(editor.state);
  if (position == null || !editor.isEditable || editor.view.composing) return false;
  const node = editor.state.doc.nodeAt(position);
  if (node?.type.name !== 'codeBlock' || (node.textContent && !languageToken.test(node.textContent))) return false;
  return editor.commands.command(({ tr }) => {
    const language = node.textContent || null;
    tr.delete(position + 1, position + node.nodeSize - 1);
    tr.setNodeMarkup(position, undefined, { ...node.attrs, language });
    tr.setSelection(TextSelection.create(tr.doc, position + 1)).setMeta(pendingFence, null);
    return true;
  });
}
