import type { Editor } from '@tiptap/core';
import { TextSelection } from '@tiptap/pm/state';
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';

const TAB_SIZE = 4;
type Edit = { from: number; to: number; text: string };

/** Edit complete lines; a selection ending at the next line's start excludes that line. */
export function codeIndentEdits(text: string, from: number, to: number, outdent = false, size = TAB_SIZE): Edit[] {
  const indent = ' '.repeat(size);
  if (from === to && !outdent) return [{ from, to, text: indent }];
  const first = text.slice(0, from).lastIndexOf('\n') + 1;
  const last = to > from && text[to - 1] === '\n' ? to - 1 : to;
  const edits: Edit[] = [];
  for (let start = first; start <= last;) {
    const length = text[start] === '\t' ? 1 : (text.slice(start).match(/^ */)?.[0].length || 0);
    if (!outdent) edits.push({ from: start, to: start, text: indent });
    else if (length) edits.push({ from: start, to: start + Math.min(length, size), text: '' });
    const next = text.indexOf('\n', start);
    if (next < 0) break;
    start = next + 1;
  }
  return edits;
}

export function mapCodeOffset(offset: number, edits: Edit[]) {
  let delta = 0;
  for (const edit of edits) {
    if (offset < edit.from) break;
    if (offset <= edit.to) return edit.from + delta + edit.text.length;
    delta += edit.text.length - (edit.to - edit.from);
  }
  return offset + delta;
}

export function indentCodeSelection(editor: Editor, outdent = false) {
  if (!editor.isEditable || editor.isDestroyed || editor.view.composing) return false;
  const { selection } = editor.state;
  if (!(selection instanceof TextSelection) || !selection.$from.sameParent(selection.$to) || selection.$from.parent.type.name !== 'codeBlock') return false;
  const start = selection.$from.start();
  const edits = codeIndentEdits(selection.$from.parent.textContent, selection.from - start, selection.to - start, outdent);
  return editor.commands.command(({ tr }) => {
    // Touch whitespace only so collaboration anchors and the block's identity survive.
    for (const edit of [...edits].reverse()) tr.insertText(edit.text, start + edit.from, start + edit.to);
    tr.setSelection(TextSelection.create(tr.doc,
      start + mapCodeOffset(selection.anchor - start, edits),
      start + mapCodeOffset(selection.head - start, edits)));
    if (edits.length) tr.scrollIntoView();
    return true;
  });
}

function newlineEdit(text: string, from: number, to: number): Edit {
  const start = text.slice(0, from).lastIndexOf('\n') + 1;
  const prefix = text.slice(start, from);
  const indent = prefix.match(/^[\t ]*/)?.[0] || '';
  // An empty indented last line drops indentation, preserving triple-Enter exit.
  if (from === to && to === text.length && prefix && prefix === indent) return { from: start, to, text: '\n' };
  return { from, to, text: `\n${indent}` };
}

export function continueCodeIndent(editor: Editor) {
  if (!editor.isEditable || editor.view.composing) return false;
  const { selection } = editor.state;
  if (!(selection instanceof TextSelection) || !selection.$from.sameParent(selection.$to) || selection.$from.parent.type.name !== 'codeBlock') return false;
  const start = selection.$from.start();
  const edit = newlineEdit(selection.$from.parent.textContent, selection.from - start, selection.to - start);
  return editor.commands.command(({ tr }) => {
    tr.insertText(edit.text, start + edit.from, start + edit.to);
    tr.setSelection(TextSelection.create(tr.doc, start + edit.from + edit.text.length)).scrollIntoView();
    return true;
  });
}

export function deleteCodeIndent(editor: Editor) {
  if (!editor.isEditable || editor.view.composing) return false;
  const { selection } = editor.state;
  if (!selection.empty || selection.$from.parent.type.name !== 'codeBlock') return false;
  const offset = selection.$from.parentOffset;
  const before = selection.$from.parent.textContent.slice(0, offset);
  const prefix = before.slice(before.lastIndexOf('\n') + 1);
  if (!prefix || !/^[\t ]+$/.test(prefix)) return false;
  const count = prefix.endsWith('\t') ? 1 : Math.min(prefix.match(/ +$/)?.[0].length || 0, (prefix.length - 1) % TAB_SIZE + 1);
  return editor.commands.deleteRange({ from: selection.from - count, to: selection.from });
}

/** Use the browser edit command to keep textarea edits in native undo history. */
export function editCodeTextarea(event: ReactKeyboardEvent<HTMLTextAreaElement>, onChange: (value: string) => void) {
  const input = event.currentTarget;
  if (input.readOnly || input.disabled || event.nativeEvent.isComposing || event.ctrlKey || event.metaKey || event.altKey) return false;
  const { value, selectionStart: from, selectionEnd: to, selectionDirection } = input;
  const edits = event.key === 'Tab' ? codeIndentEdits(value, from, to, event.shiftKey)
    : event.key === 'Enter' && !event.shiftKey ? [newlineEdit(value, from, to)] : null;
  if (!edits) return false;
  event.preventDefault();
  if (!edits.length) return true;
  let next = value;
  for (const edit of [...edits].reverse()) next = next.slice(0, edit.from) + edit.text + next.slice(edit.to);
  const first = edits[0].from, last = edits.at(-1)!.to;
  const replacement = next.slice(first, next.length - (value.length - last));
  const start = event.key === 'Enter' ? first + edits[0].text.length : mapCodeOffset(from, edits);
  const end = event.key === 'Enter' ? start : mapCodeOffset(to, edits);
  input.setSelectionRange(first, last);
  if (!document.execCommand?.('insertText', false, replacement)) onChange(next);
  input.setSelectionRange(start, end, selectionDirection);
  // Controlled updates may commit after this handler.
  requestAnimationFrame(() => { if (document.activeElement === input && input.value === next) input.setSelectionRange(start, end, selectionDirection); });
  return true;
}
