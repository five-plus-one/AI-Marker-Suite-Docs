export const editorCommandUsageKey = 'fp.editor.commands.v1';
export const editorCommandUsageChanged = 'fp:editor-command-usage';
export type EditorCommandUsage = Record<string, Record<string, number>>;
export type EditorCommandUsageStorage = { getItem(key:string):string|null; setItem(key:string,value:string):void; refresh?():Promise<unknown> };
let storage:EditorCommandUsageStorage|undefined;
let replica:string|undefined;
const valid=(key:string)=>/^[a-zA-Z0-9:_-]{1,80}$/.test(key)&&!['__proto__','constructor','prototype'].includes(key);
export function parseEditorCommandUsage(raw:string|null):EditorCommandUsage {
 const result:EditorCommandUsage=Object.create(null);
 try {
  const parsed=JSON.parse(raw||'null');if(parsed?.version!==1||!parsed.counts||typeof parsed.counts!=='object')return result;
  for(const [command,counts] of Object.entries(parsed.counts).slice(0,128)){
   if(!valid(command)||!counts||typeof counts!=='object')continue;
   const clean:Record<string,number>=Object.create(null);
   for(const [device,count] of Object.entries(counts).slice(0,256))if(valid(device)&&typeof count==='number'&&Number.isSafeInteger(count)&&count>0&&count<=1e9)clean[device]=count;
   result[command]=clean;
  }
 }catch{/* Fresh preferences start empty. */}
 return result;
}
export function mergeEditorCommandUsage(left:string|null,right:string|null):string {
 const result=parseEditorCommandUsage(left);
 for(const [command,counts] of Object.entries(parseEditorCommandUsage(right))){
  const merged=result[command]??=Object.create(null);
  for(const [device,count] of Object.entries(counts))merged[device]=Math.max(merged[device]||0,count);
 }
 return JSON.stringify({version:1,counts:result});
}
const host=()=>storage??(typeof window!=='undefined'?window.localStorage:undefined);
export function configureEditorCommandUsage(next?:EditorCommandUsageStorage){storage=next;notifyEditorCommandUsage();}
export function notifyEditorCommandUsage(){if(typeof window!=='undefined')window.dispatchEvent(new Event(editorCommandUsageChanged));}
export function editorCommandFrequencies(raw?:string|null):Record<string,number>{
 const counts:Record<string,number>=Object.create(null);
 try{for(const [id,devices] of Object.entries(parseEditorCommandUsage(raw===undefined?host()?.getItem(editorCommandUsageKey)??null:raw)))counts[id]=Object.values(devices).reduce((a,b)=>a+b,0);}catch{/* Storage may be unavailable. */}
 return counts;
}
export function editorCommandFrequency(command:string,raw?:string|null){return editorCommandFrequencies(raw)[command]||0;}
function replicaID(){
 if(replica)return replica;
 const key='fp.editor.command-device';
 try {replica=window.localStorage.getItem(key)||crypto.randomUUID();window.localStorage.setItem(key,replica);}catch{replica=crypto.randomUUID();}
 return replica;
}
export function recordEditorCommandUse(command:string){
 if(!valid(command)||typeof window==='undefined')return;
 const record=()=>{try{const target=host();if(!target)return;const counts=parseEditorCommandUsage(target.getItem(editorCommandUsageKey)),device=replicaID();const commands=counts[command]??=Object.create(null);commands[device]=Math.min(1e9,(commands[device]||0)+1);target.setItem(editorCommandUsageKey,JSON.stringify({version:1,counts}));notifyEditorCommandUsage();}catch{/* Insertion remains available when storage is full. */}};
 if(navigator.locks)void navigator.locks.request('fp-editor-command-usage',record).catch(()=>{});else record();
}
