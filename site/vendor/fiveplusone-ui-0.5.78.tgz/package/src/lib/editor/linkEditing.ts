/** Open an editor link through the host application while preserving ordinary text selection. */
export function openEditorLink(event: MouseEvent, open: (href:string,label:string)=>void) {
 const target=event.target instanceof Element?event.target:event.target instanceof Node?event.target.parentElement:null;
 const anchor=target?.closest<HTMLAnchorElement>('a[href]');
 if(!anchor)return false;
 let url:URL;try{url=new URL(anchor.href,window.location.href);}catch{return false;}
 if(!['http:','https:','mailto:','tel:'].includes(url.protocol))return false;
 event.preventDefault();event.stopPropagation();open(url.href,anchor.textContent||'');return true;
}
