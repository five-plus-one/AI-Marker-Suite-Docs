import {Extension,type Editor} from '@tiptap/core';
import {NodeSelection,Plugin,TextSelection} from '@tiptap/pm/state';
import type {Node as ProseNode} from '@tiptap/pm/model';
const requested=new WeakMap<Editor,string>();
export function cardEditRequested(editor:Editor,id:unknown){return typeof id==='string'&&requested.get(editor)===id;}
export function acknowledgeCardEdit(editor:Editor,id:unknown){if(cardEditRequested(editor,id))requested.delete(editor);}
export function insertDirectiveCard(editor:Editor,name='note'){
 if(!editor.isEditable)return false;
 const id=crypto.randomUUID();requested.set(editor,id);
 const result=editor.chain().focus().insertContent({type:'directiveBlock',attrs:{name,attributes:'',body:'',id}}).command(({tr})=>{
  let position:number|undefined;tr.doc.descendants((node,pos)=>{if(node.type.name==='directiveBlock'&&node.attrs.id===id){position=pos;return false;}});
  if(position===undefined)return false;tr.setSelection(NodeSelection.create(tr.doc,position));return true;
 }).run();
 if(!result)requested.delete(editor);
 return result;
}
export function continueAfterCard(editor:Editor,getPos:()=>number|undefined){
 if(!editor.isEditable||editor.isDestroyed)return false;
 const pos=getPos();if(pos===undefined)return false;
 const node=editor.state.doc.nodeAt(pos);if(node?.type.name!=='directiveBlock')return false;
 const after=pos+node.nodeSize;
 const result=editor.chain().command(({tr})=>{
  if(tr.doc.nodeAt(after)?.type.name!=='paragraph')tr.insert(after,editor.schema.nodes.paragraph.create());
  tr.setSelection(TextSelection.create(tr.doc,after+1)).setStoredMarks(null).scrollIntoView();return true;
 }).run();
 if(result)editor.view.focus();
 return result;
}
function cardCount(doc:ProseNode){let count=0;doc.descendants(node=>{if(node.type.name==='directiveBlock'){count++;return false;}});return count;}
/** Protect card-body editors at the document boundary, including pasted and dropped content. */
export const CardBodyBoundary=Extension.create({name:'cardBodyBoundary',addProseMirrorPlugins(){return[new Plugin({filterTransaction:(tr,state)=>!tr.docChanged||cardCount(tr.doc)<=cardCount(state.doc)})];}});
