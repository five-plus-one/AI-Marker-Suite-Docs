import { useId, type ReactNode } from 'react';
import { Activity, RefreshCw, Users, Monitor, Clock, CalendarDays } from 'lucide-react';
import { Button, Card } from './PageControls';
import './analytics-workspace.css';
export type AnalyticsTable = { title: string; columns: string[]; rows: ReactNode[][] };
export type AnalyticsTrend = { label: string; value: number; minutes: number };
export function AnalyticsWorkspace({ title, description, metrics, tables, loading, error, onRefresh, children, navigation, trend, personal = false }: {
 title: string; description: string; metrics: { label: string; value: ReactNode }[];
 tables: AnalyticsTable[]; loading?: boolean; error?: string; onRefresh: () => void; children?: ReactNode; navigation?: ReactNode; trend?: AnalyticsTrend[]; personal?: boolean;
}) {
 const gradient = useId().replaceAll(':','');
 const points = trend || [], max = Math.max(1,...points.map(p=>p.value));
 const x=(i:number)=>48+i*744/Math.max(1,points.length-1), y=(n:number)=>190-n/max*154;
 const line=points.map((p,i)=>`${x(i)},${y(p.value)}`).join(' ');
 const icons=[Activity,Clock,Users,CalendarDays,Users,Monitor];
 return <section className="fp-analytics" data-personal={personal||undefined}><header className="fp-analytics-heading"><div><span className="fp-analytics-eyebrow">{personal ? "我的学习" : "运营分析"}</span><h1>{title}</h1><p>{description}</p></div><Button variant="secondary" loading={loading} onClick={onRefresh} aria-label="刷新数据"><RefreshCw size={16}/>刷新数据</Button></header>
 {navigation && <div className="fp-analytics-navigation">{navigation}</div>}
 {error && <p role="alert">{error}</p>}
 {metrics.length>0 && <div className="fp-analytics-metrics">{metrics.map((m,i)=>{const Icon=icons[i%icons.length];return <Card key={m.label}><div className="fp-analytics-metric-label"><span>{m.label}</span><Icon size={17} aria-hidden="true"/></div><strong>{typeof m.value==='number'?m.value.toLocaleString('zh-CN'):m.value}</strong></Card>;})}</div>}
 {trend && <Card className="fp-analytics-trend"><div className="fp-analytics-panel-heading"><div><h2>{personal ? "使用时长趋势" : "活跃趋势"}</h2><p>观察每天的使用变化</p></div><span className="fp-analytics-period">最近 {points.length} 天</span></div>{points.length ? <><div className="fp-analytics-chart" role="img" aria-label={points.map(p=>personal ? `${p.label}，有效使用${p.minutes}分钟` : `${p.label}，活跃${p.value}人，有效使用${p.minutes}分钟`).join('；')}><svg viewBox="0 0 840 230" aria-hidden="true"><defs><linearGradient id={gradient} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="currentColor" stopOpacity=".18"/><stop offset="100%" stopColor="currentColor" stopOpacity="0"/></linearGradient></defs>{[0,.5,1].map(n=><g key={n}><line x1="48" x2="792" y1={y(max*n)} y2={y(max*n)} className="fp-analytics-gridline"/><text x="36" y={y(max*n)+4} textAnchor="end">{Number((max*n).toFixed(1))}</text></g>)}<polygon points={`48,190 ${line} ${x(points.length-1)},190`} fill={`url(#${gradient})`}/><polyline points={line} fill="none" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round"/>{points.map((p,i)=><g key={p.label}><circle cx={x(i)} cy={y(p.value)} r="4" fill="var(--fp-surface)" stroke="currentColor" strokeWidth="2"/>{(i===0||i===points.length-1||i%Math.ceil(points.length/7)===0&&i<points.length-2)&&<text x={x(i)} y="219" textAnchor="middle">{p.label.slice(5).replace('-','/')}</text>}</g>)}</svg></div><div className="fp-analytics-chart-footer"><span><i/>{personal ? "每日有效使用（分钟）" : "每日活跃用户"}</span><span>累计有效使用 <strong>{points.reduce((s,p)=>s+p.minutes,0).toLocaleString('zh-CN')}</strong> 分钟</span></div></>:<p>开始使用后，这里将展示活跃趋势。</p>}</Card>}
 <div className="fp-analytics-tables">{tables.map(table=><Card key={table.title} className={table.columns.length>4?'fp-analytics-wide':undefined}><h2>{table.title}</h2><div className="fp-analytics-table" tabIndex={0} role="region" aria-label={table.title}><table><thead><tr>{table.columns.map(c=><th key={c}>{c}</th>)}</tr></thead><tbody>{table.rows.map((row,i)=><tr key={i}>{row.map((cell,j)=><td key={j}>{cell}</td>)}</tr>)}</tbody></table>{!table.rows.length&&<p>开始使用后，这里将展示统计结果。</p>}</div></Card>)}</div>{children}</section>;
}

