import {useId,type ReactNode} from 'react';
export interface ChoiceCardOption {value:string;title:string;description:string;icon?:ReactNode;disabled?:boolean}
export function ChoiceCards({label,value,options,onChange}:{label:string;value:string;options:ChoiceCardOption[];onChange:(value:string)=>void}){
 const name=useId();
 return <fieldset className="fp-choice-cards"><legend>{label}</legend>{options.map(option=><label key={option.value} data-selected={value===option.value} data-disabled={option.disabled||undefined}><input type="radio" name={name} value={option.value} checked={value===option.value} disabled={option.disabled} onChange={()=>onChange(option.value)}/>{option.icon&&<span className="fp-choice-card-icon" aria-hidden="true">{option.icon}</span>}<span><strong>{option.title}</strong><small>{option.description}</small></span></label>)}</fieldset>;
}
