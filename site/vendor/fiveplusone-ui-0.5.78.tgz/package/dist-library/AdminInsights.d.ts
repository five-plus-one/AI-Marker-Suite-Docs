import type { ReactNode } from 'react';
export interface UserUsageMetric {
    label: string;
    value: ReactNode;
}
export interface ManagedUserNotebook {
    id: string;
    title: string;
    updatedAt: string;
    noteCount: number;
    href?: string;
}
export declare function UserUsageOverview({ metrics, description, loading, error, onRetry }: {
    metrics: UserUsageMetric[];
    description?: string;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
}): import("react").JSX.Element;
export declare function UserNotebookList({ items, loading, error, hasMore, onMore }: {
    items: ManagedUserNotebook[];
    loading?: boolean;
    error?: string;
    hasMore?: boolean;
    onMore?: () => void;
}): import("react").JSX.Element;
export interface AdminAuditEntry {
    id: string;
    actor: string;
    action: string;
    target: string;
    summary: string;
    time: string;
}
export interface AdminAuditFilters {
    actor: string;
    action: string;
    target: string;
    from: string;
    to: string;
}
export declare function AuditLogWorkspace({ entries, filters, onFiltersChange, actions, onSearch, onReset, onNext, onPrevious, canNext, canPrevious, loading, error }: {
    entries: AdminAuditEntry[];
    filters: AdminAuditFilters;
    onFiltersChange: (value: AdminAuditFilters) => void;
    actions: {
        value: string;
        label: string;
    }[];
    onSearch: () => void;
    onReset: () => void;
    onNext: () => void;
    onPrevious: () => void;
    canNext: boolean;
    canPrevious: boolean;
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
