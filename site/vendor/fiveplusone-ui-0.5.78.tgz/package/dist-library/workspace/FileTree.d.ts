import { type KeyboardEvent, type MouseEvent, type DragEvent, type ReactNode } from "react";
export type FileTreeNode = {
    id: string;
    name: string;
    kind: "folder" | "file";
    children?: FileTreeNode[];
    detail?: string;
};
export type FileTreeProps = {
    renderRow?: (node: FileTreeNode, row: ReactNode) => ReactNode;
    items: FileTreeNode[];
    selectedId?: string;
    onSelect: (item: FileTreeNode) => void;
    defaultExpanded?: string[];
    expandedIds?: readonly string[];
    onExpandedChange?: (ids: string[]) => void;
    onToggle?: (id: string, expanded: boolean) => void;
    onPrefetch?: (node: FileTreeNode) => void;
    /** Receives modifier keys for opening a tab or a split view. */
    onOpen?: (node: FileTreeNode, event: MouseEvent | KeyboardEvent) => void;
    onMiddleClick?: (node: FileTreeNode, event: MouseEvent) => void;
    onNodeDragStart?: (node: FileTreeNode, event: DragEvent) => void;
    onNodeDragOver?: (node: FileTreeNode, event: DragEvent) => void;
    onNodeDrop?: (node: FileTreeNode, event: DragEvent) => void;
    namespace?: string;
    onRename?: (node: FileTreeNode) => void;
    onRemove?: (node: FileTreeNode) => void;
    onCreate?: (parent: FileTreeNode) => void;
    label?: string;
};
export declare function FileTree({ renderRow, items, selectedId, onSelect, defaultExpanded, expandedIds, onExpandedChange, onToggle, onPrefetch, onOpen, onMiddleClick, onNodeDragStart, onNodeDragOver, onNodeDrop, namespace, onRename, onRemove, onCreate, label, }: FileTreeProps): import("react").JSX.Element;
