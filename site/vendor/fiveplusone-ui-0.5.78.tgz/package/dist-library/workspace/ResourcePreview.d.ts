import { type ReactNode } from "react";
import { type VideoPlayerProps } from "../VideoPlayer";
import { type AudioPlayerProps } from "../AudioPlayer";
export type PreviewResource = {
    name: string;
    url: string;
    mediaType?: string;
    bytes?: number;
    previewUrl?: string;
    downloadUrl?: string;
};
export declare function ResourcePreview({ resource, renderVideoExtra, videoProps, audioProps, }: {
    resource: PreviewResource;
    renderVideoExtra?: ReactNode;
    videoProps?: Omit<VideoPlayerProps, "src" | "title">;
    audioProps?: Omit<AudioPlayerProps, "src" | "title">;
}): import("react").JSX.Element;
