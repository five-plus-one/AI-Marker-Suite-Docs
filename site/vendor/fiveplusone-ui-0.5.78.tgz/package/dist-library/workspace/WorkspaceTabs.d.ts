import { type ReactNode } from "react";
export interface WorkspaceTab {
    id: string;
    title: string;
    icon?: ReactNode;
    dirty?: boolean;
    closable?: boolean;
}
export interface WorkspaceTabsProps {
    tabs: WorkspaceTab[];
    activeId?: string;
    paneId?: string;
    onSelect: (id: string) => void;
    onClose: (id: string) => void;
    onMove?: (id: string, targetPane: string, index: number) => void;
    onSplit?: () => void;
}
export declare function WorkspaceTabs({ tabs, activeId, paneId, onSelect, onClose, onMove, onSplit, }: WorkspaceTabsProps): import("react").JSX.Element;
