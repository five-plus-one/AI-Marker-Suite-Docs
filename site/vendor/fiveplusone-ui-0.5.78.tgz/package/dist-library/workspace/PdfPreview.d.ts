export default function PdfPreview({ url, name, downloadUrl, }: {
    url: string;
    name: string;
    downloadUrl?: string;
}): import("react").JSX.Element;
