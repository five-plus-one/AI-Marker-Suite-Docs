import { type CSSProperties, type RefObject } from "react";
/** Carry the anchor's product palette into a surface mounted outside its DOM scope. */
export declare function usePortalTheme(anchor: RefObject<HTMLElement | null>, open: boolean, source?: unknown): CSSProperties;
