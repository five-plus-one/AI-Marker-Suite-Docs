import { jsxs as n, jsx as l } from "react/jsx-runtime";
import { L as m } from "./LearningSelect-DSx2ZDO6.js";
import { useState as c, useId as x } from "react";
function g(e, o, r, t = 1) {
  const i = 89875517923e-1;
  return e === "sphere" ? r >= 0 && t > 0 ? i * o * 1e-9 * (r <= t ? r / t ** 3 : 1 / r ** 2) : NaN : e === "ring" ? t > 0 ? i * o * 1e-9 * r / (t * t + r * r) ** 1.5 : NaN : r > 0 ? e === "line" ? 2 * i * o * 1e-9 / r : i * o * 1e-9 / (r * r) * (e === "superposition" ? 2 : 1) : NaN;
}
function v() {
  const [e, o] = c("point"), [r, t] = c(5), [i, p] = c(1), [s, d] = c(1), h = x(), u = g(e, r, i, s);
  return /* @__PURE__ */ n(
    "section",
    {
      "aria-label": "静电场实验",
      className: "rounded-xl border border-[var(--line)] p-4",
      children: [
        /* @__PURE__ */ l("h3", { children: "从电荷到电场" }),
        /* @__PURE__ */ n("label", { children: [
          "选择情景",
          /* @__PURE__ */ n(
            m,
            {
              value: e,
              onChange: (a) => {
                o(a.target.value), i <= 0 && !["sphere", "ring"].includes(a.target.value) && p(0.1);
              },
              children: [
                /* @__PURE__ */ l("option", { value: "point", children: "点电荷与球对称场" }),
                /* @__PURE__ */ l("option", { value: "superposition", children: "两个同向等强电场叠加" }),
                /* @__PURE__ */ l("option", { value: "line", children: "无限长直线电荷" }),
                /* @__PURE__ */ l("option", { value: "sphere", children: "均匀带电实心球" }),
                /* @__PURE__ */ l("option", { value: "ring", children: "圆环轴线上电场" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ n("label", { className: "block my-3", children: [
          e === "line" ? "线密度 λ" : "电荷量 q",
          "：",
          r,
          " ",
          e === "line" ? "nC/m" : "nC",
          /* @__PURE__ */ l(
            "input",
            {
              "aria-label": "电荷参数",
              type: "range",
              min: "-10",
              max: "10",
              step: "0.5",
              value: r,
              onChange: (a) => t(Number(a.target.value))
            }
          )
        ] }),
        /* @__PURE__ */ n("label", { className: "block", children: [
          e === "ring" ? "轴向距离 z" : "距离 r",
          "：",
          i.toFixed(1),
          " m",
          /* @__PURE__ */ l(
            "input",
            {
              "aria-label": "距离",
              type: "range",
              min: e === "sphere" || e === "ring" ? 0 : 0.1,
              max: "3",
              step: "0.1",
              value: i,
              onChange: (a) => p(Number(a.target.value))
            }
          )
        ] }),
        (e === "sphere" || e === "ring") && /* @__PURE__ */ n("label", { className: "block my-3", children: [
          "半径 R：",
          s.toFixed(1),
          " m",
          /* @__PURE__ */ l(
            "input",
            {
              "aria-label": "半径",
              type: "range",
              min: "0.1",
              max: "3",
              step: "0.1",
              value: s,
              onChange: (a) => d(Number(a.target.value))
            }
          )
        ] }),
        /* @__PURE__ */ n("svg", { role: "img", "aria-label": "电场方向示意", viewBox: "0 0 400 130", children: [
          /* @__PURE__ */ l("defs", { children: /* @__PURE__ */ l(
            "marker",
            {
              id: h,
              markerWidth: "8",
              markerHeight: "8",
              refX: "7",
              refY: "4",
              orient: "auto",
              children: /* @__PURE__ */ l("path", { d: "M0 0L8 4L0 8", fill: "#7555b5" })
            }
          ) }),
          e === "ring" ? /* @__PURE__ */ l(
            "ellipse",
            {
              cx: "80",
              cy: "65",
              rx: "12",
              ry: "38",
              fill: "none",
              stroke: "#7555b5",
              strokeWidth: "4"
            }
          ) : /* @__PURE__ */ l(
            "circle",
            {
              cx: "80",
              cy: "65",
              r: e === "sphere" ? 35 : 20,
              fill: "#efe6ff"
            }
          ),
          /* @__PURE__ */ l("text", { x: "80", y: "71", textAnchor: "middle", children: r > 0 ? "+" : r < 0 ? "−" : "0" }),
          /* @__PURE__ */ l("circle", { cx: "300", cy: "65", r: "4", fill: "#555" }),
          u !== 0 && /* @__PURE__ */ l(
            "line",
            {
              x1: r < 0 ? 290 : 120,
              x2: r < 0 ? 200 : 290,
              y1: "65",
              y2: "65",
              stroke: "#7555b5",
              strokeWidth: "4",
              markerEnd: `url(#${h})`
            }
          ),
          /* @__PURE__ */ n("text", { x: "195", y: "105", textAnchor: "middle", children: [
            e === "ring" ? "z" : "r",
            " = ",
            i.toFixed(1),
            " m"
          ] })
        ] }),
        /* @__PURE__ */ n("p", { className: "text-xl font-semibold", children: [
          "E = ",
          u.toFixed(2),
          " N/C"
        ] }),
        /* @__PURE__ */ l("p", { children: e === "sphere" ? "均匀带电实心球：球内 E=kQr/R³，球外 E=kQ/r²。中心场为零；球面两式连续，在r=R取得最大场强。" : e === "ring" ? "圆环轴线：E=kQz/(R²+z²)^(3/2)。中心z=0时为零，z=R/√2时取得正半轴峰值；远处近似点电荷。" : e === "line" ? "E = λ/(2πε₀r)，这里假定直线无限长。距离加倍，场强减半。" : e === "superposition" ? "每个电场都是 kq/r²，这里设两场方向相同，E总 = 2kq/r²。一般情况必须按向量相加。" : "E = kq/r²。球对称电荷在球外也得到相同形式；高斯面面积为4πr²，通量为E·4πr²=q/ε₀。" }),
        /* @__PURE__ */ l("p", { children: "负号表示场指向电荷，正号表示背离电荷；先判断对称性与方向，再代入数值。" })
      ]
    }
  );
}
export {
  v as default,
  g as electricField
};
