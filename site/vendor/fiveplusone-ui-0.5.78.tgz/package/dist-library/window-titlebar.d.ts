export type WindowTitleBarHost = {
    minimize(): unknown;
    toggleMaximize(): unknown;
    closeWindow(): unknown;
    openMenu(): unknown;
    getWindowState(): Promise<{
        maximized: boolean;
        fullscreen: boolean;
    }>;
    onWindowState(callback: (state: {
        maximized: boolean;
        fullscreen: boolean;
    }) => void): () => void;
};
/** Mounts accessible desktop chrome; window privileges remain with the host. */
export declare function mountWindowTitleBar(host: WindowTitleBarHost, title: string): () => void;
