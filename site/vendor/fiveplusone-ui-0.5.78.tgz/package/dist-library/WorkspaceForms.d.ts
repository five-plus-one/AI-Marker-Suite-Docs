import { type ReactNode } from "react";
import { type SelectOption } from "./SelectField";
export declare function WorkspaceSection({ title, description, actions, children, }: {
    title?: string;
    description?: string;
    actions?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function WorkspaceField({ label, value, onChange, hint, options, multiline, secret, numeric, disabled, required, }: {
    label: string;
    value: string | number;
    onChange: (value: string) => void;
    hint?: string;
    options?: SelectOption[];
    multiline?: boolean;
    secret?: boolean;
    numeric?: boolean;
    disabled?: boolean;
    required?: boolean;
}): import("react").JSX.Element;
export declare function WorkspaceToggle({ label, checked, onChange, description, disabled, }: {
    label: string;
    checked: boolean;
    onChange: (checked: boolean) => void;
    description?: string;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function SettingsTabs({ label, value, onChange, items, density, }: {
    label: string;
    value: string;
    onChange: (id: string) => void;
    items: {
        id: string;
        label: string;
    }[];
    density?: "comfortable" | "compact";
}): import("react").JSX.Element;
export declare function useWorkspaceAction(): {
    busy: boolean;
    error: string;
    message: string;
    run: (work: () => Promise<void> | void, success?: string) => Promise<boolean>;
    setError: import("react").Dispatch<import("react").SetStateAction<string>>;
    setMessage: import("react").Dispatch<import("react").SetStateAction<string>>;
};
export declare function WorkspaceFeedback({ error, message, }: {
    error?: string;
    message?: string;
}): import("react").JSX.Element;
export declare function WorkspaceSave({ busy, dirty, onClick, label, }: {
    busy: boolean;
    dirty?: boolean;
    onClick: () => void;
    label?: string;
}): import("react").JSX.Element;
/** Parent updates replace a clean draft; pending edits survive background refreshes. */
export declare function useWorkspaceDraft<T>(value: T): {
    draft: T;
    setDraft: import("react").Dispatch<import("react").SetStateAction<T>>;
    dirty: boolean;
    accept: (next: T) => void;
};
