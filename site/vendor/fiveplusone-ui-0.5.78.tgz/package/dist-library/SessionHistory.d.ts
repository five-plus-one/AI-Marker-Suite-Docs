/** SessionHistory - 从课栈 chat/ChatHistoryOverlay 提取
 *
 * 对话历史面板：按类型分组，支持选择、删除（二次确认）与新建。
 */
export interface SessionItem {
    id: string;
    title: string;
    detail?: string;
    time?: string;
}
export interface SessionGroup {
    id: string;
    label: string;
    items: SessionItem[];
}
export interface SessionHistoryProps {
    groups: SessionGroup[];
    activeId?: string;
    onSelect: (groupId: string, sessionId: string) => void;
    onCreate?: (groupId: string) => void;
    onDelete?: (groupId: string, sessionId: string) => void;
    onClose?: () => void;
}
export declare function SessionHistory({ groups, activeId, onSelect, onCreate, onDelete, onClose, }: SessionHistoryProps): import("react").JSX.Element;
