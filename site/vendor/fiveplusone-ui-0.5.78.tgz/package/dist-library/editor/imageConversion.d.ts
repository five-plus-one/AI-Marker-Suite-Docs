import { Node } from "@tiptap/core";
export declare const ImageConversion: Node<any, any>;
