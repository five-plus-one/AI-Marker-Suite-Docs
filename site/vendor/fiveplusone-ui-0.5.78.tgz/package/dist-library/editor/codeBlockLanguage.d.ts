/** 代码块语言选项：下拉列表 + 从节点读语言的纯函数。 */
export type CodeBlockLanguageOption = {
    /** 展示名，例如 JavaScript */
    label: string;
    /** 写入 codeBlock.attrs.language / Markdown fence 的值 */
    value: string;
};
/** 工具栏/浮动条常用语言列表（顺序稳定，勿随意重排）。 */
export declare const CODE_BLOCK_LANGUAGES: readonly CodeBlockLanguageOption[];
/** 「无语言」时 attrs.language 的规范值。 */
export declare function emptyLanguage(): null;
/**
 * 从 ProseMirror 节点（或任意带 attrs.language 的对象）读出语言。
 * 空串 / 空白 / 非字符串一律归一为 null。
 */
export declare function languageFromNode(node: unknown): string | null;
/** 判断某语言值是否在常用列表中（下拉受控时用于保留未知语言）。 */
export declare function isKnownLanguage(value: string | null | undefined): boolean;
