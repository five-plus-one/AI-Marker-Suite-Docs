export type MathNodeHost = HTMLElement & {
    mathPosition: () => number | undefined;
};
type MathClick = (latex: string, position: number) => void;
export declare function createLazyMathExtensions(callbacks: {
    onInlineClick?: MathClick;
    onBlockClick?: MathClick;
}): import("@tiptap/core").Node<import("@tiptap/extension-mathematics").InlineMathOptions, any>[];
export {};
