export type MathSymbol = {
    id: string;
    category: string;
    categories: string[];
    label: string;
    latex: string;
    insert: string;
    aliases: string;
};
export declare const symbolCategories: readonly [readonly ["basic", "常用"], readonly ["letters", "字母"], readonly ["calculus", "微积分"], readonly ["discrete", "集合与逻辑"], readonly ["linear", "线性代数"], readonly ["probability", "概率统计"], readonly ["relations", "关系与运算"], readonly ["arrows", "箭头"], readonly ["greek", "希腊字母"], readonly ["accents", "修饰与括号"], readonly ["fonts", "数学字体"]];
export declare const mathCatalog: readonly MathSymbol[];
export declare function searchMathSymbols(query: string): MathSymbol[];
