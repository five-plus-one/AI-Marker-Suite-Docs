export declare const editorCommandUsageKey = "fp.editor.commands.v1";
export declare const editorCommandUsageChanged = "fp:editor-command-usage";
export type EditorCommandUsage = Record<string, Record<string, number>>;
export type EditorCommandUsageStorage = {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    refresh?(): Promise<unknown>;
};
export declare function parseEditorCommandUsage(raw: string | null): EditorCommandUsage;
export declare function mergeEditorCommandUsage(left: string | null, right: string | null): string;
export declare function configureEditorCommandUsage(next?: EditorCommandUsageStorage): void;
export declare function notifyEditorCommandUsage(): void;
export declare function editorCommandFrequencies(raw?: string | null): Record<string, number>;
export declare function editorCommandFrequency(command: string, raw?: string | null): number;
export declare function recordEditorCommandUse(command: string): void;
