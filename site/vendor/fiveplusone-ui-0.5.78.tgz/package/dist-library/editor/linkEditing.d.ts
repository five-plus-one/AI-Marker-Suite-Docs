/** Open an editor link through the host application while preserving ordinary text selection. */
export declare function openEditorLink(event: MouseEvent, open: (href: string, label: string) => void): boolean;
