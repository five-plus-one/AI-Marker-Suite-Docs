import type { Editor } from '@tiptap/core';
export declare function insertMermaidCard(editor: Editor): boolean;
