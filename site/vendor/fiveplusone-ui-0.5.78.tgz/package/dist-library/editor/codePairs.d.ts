import { Plugin } from '@tiptap/pm/state';
import type { Editor } from '@tiptap/core';
type PairEdit = {
    from: number;
    to: number;
    text: string;
    anchor: number;
    head: number;
};
/** A single typed symbol stays one undoable edit with its selection inside. */
export declare function codePairEdit(text: string, anchor: number, head: number, input: string, language?: string): PairEdit | null;
export declare function deleteCodePair(editor: Editor): boolean;
export declare function expandCodePair(editor: Editor): boolean;
export declare function codePairsPlugin(editor: Editor): Plugin<any>;
export {};
