import { Node } from "@tiptap/core";
import type { Editor, JSONContent } from "@tiptap/core";
export declare function appendUploadPlaceholder(editor: Editor, placeholder: JSONContent): boolean;
export declare const UploadPlaceholder: Node<any, any>;
