import { type ReactNode } from 'react';
export default function Tip({ tip, children }: {
    tip: string;
    children: ReactNode;
}): import("react").JSX.Element;
