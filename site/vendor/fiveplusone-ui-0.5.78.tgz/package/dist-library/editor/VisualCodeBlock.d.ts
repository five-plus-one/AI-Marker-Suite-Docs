export declare function MermaidPreview({ code }: {
    code: string;
}): import("react").JSX.Element;
export declare const VisualCodeBlock: import("@tiptap/core").Node<import("@tiptap/extension-code-block-lowlight").CodeBlockLowlightOptions, any>;
