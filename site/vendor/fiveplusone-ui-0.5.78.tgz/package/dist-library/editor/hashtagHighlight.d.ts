import { Extension } from "@tiptap/core";
export declare const HashtagHighlight: Extension<any, any>;
