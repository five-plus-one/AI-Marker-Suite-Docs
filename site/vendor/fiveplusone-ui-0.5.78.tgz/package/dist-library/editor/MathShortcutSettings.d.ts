import { type MathShortcut } from "./mathShortcuts";
export default function MathShortcutSettings({ rules, onSave, onClose }: {
    rules: MathShortcut[];
    onSave: (rules: MathShortcut[]) => void;
    onClose: () => void;
}): import("react").JSX.Element;
