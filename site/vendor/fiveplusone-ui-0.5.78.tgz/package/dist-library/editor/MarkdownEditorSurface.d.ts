import type { ReactNode } from "react";
import type { Editor } from "@tiptap/core";
export interface MarkdownEditorSurfaceProps {
    editor: Editor | null;
    toolbar?: ReactNode;
    children?: ReactNode;
    className?: string;
    contextMenu?: boolean;
}
/** A shared editing surface for applications that own document sessions and persistence. */
export declare function MarkdownEditorSurface({ editor, toolbar, children, className, contextMenu }: MarkdownEditorSurfaceProps): import("react").JSX.Element;
