import type { Editor } from "@tiptap/react";
import { type FormatPainterMode, type PainterMark } from "./formatPainter";
export default function NoteToolbar({ editor, onHistory, onAttachment, onVideo, onInteractive, onInsertCard, onMath, onSnapshot, onExport, formatPainterMode, onFormatPainterMode, formatPainterMarks, onFormatPainterMarks, hiddenActions }: {
    editor: Editor;
    onHistory: () => void;
    onAttachment: () => void;
    onVideo?: () => void;
    onInteractive?: () => void;
    onInsertCard: () => void;
    onMath: (display: boolean) => void;
    onSnapshot: () => void;
    onExport: () => void;
    formatPainterMode: FormatPainterMode;
    onFormatPainterMode: (mode: FormatPainterMode) => void;
    formatPainterMarks: PainterMark[];
    onFormatPainterMarks: (marks: PainterMark[]) => void;
    hiddenActions?: readonly string[];
}): import("react").JSX.Element;
