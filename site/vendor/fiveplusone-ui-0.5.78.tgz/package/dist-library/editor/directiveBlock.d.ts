import { Node } from "@tiptap/core";
export declare const DirectiveBlock: Node<any, any>;
export declare const DIRECTIVE_CARD_TYPES: readonly [readonly ["definition", "定义"], readonly ["theorem", "定理"], readonly ["example", "例题"], readonly ["insight", "直觉"], readonly ["pitfall", "易错点"], readonly ["note", "说明"], readonly ["tip", "技巧"], readonly ["memory", "记忆卡"], readonly ["derivation", "推导"], readonly ["timeline", "时间线"], readonly ["event", "事件"], readonly ["concept", "概念"], readonly ["compare", "对比"], readonly ["cause-effect", "因果"], readonly ["keypoint", "核心要点"], readonly ["interactive", "互动内容"], readonly ["video", "视频"], readonly ["figure", "图片"], readonly ["plot", "函数图"], readonly ["audio", "音频"], readonly ["historymap", "历史地图"], readonly ["learninganimation", "学习动画"], readonly ["attachment", "附件"]];
export declare function directiveTitleAttribute(name: string): "term" | "title" | "label" | "period";
export declare function readDirectiveTitle(attributes: string, name: string): string;
export declare function writeDirectiveTitle(attributes: string, name: string, title: string): string;
