import type { Editor } from "@tiptap/react";
export type FormatPainterMode = null | "once" | "locked";
declare const MARK_TYPES: readonly ["bold", "italic", "strike", "code", "underline"];
export type PainterMark = (typeof MARK_TYPES)[number];
/** 从当前选区抓取 marks；无选区时返回空数组。 */
export declare function captureMarks(editor: Editor): PainterMark[];
export declare function applyMarks(editor: Editor, marks: readonly PainterMark[], from: number, to: number): boolean;
export declare function toggleFormatPainterMode(mode: FormatPainterMode): FormatPainterMode;
export {};
