export declare function cancelFormulaTransition(target: HTMLElement): void;
/** Keeps the paragraph and its closing card in the same transition lifetime. */
export declare function animateFormulaTransition(target: HTMLElement, overlay: HTMLElement, before: number, after: number): void;
