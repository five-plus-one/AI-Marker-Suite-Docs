import { type RefObject } from 'react';
export declare function MathSuggestions({ anchor }: {
    anchor: RefObject<HTMLElement | null>;
}): import("react").JSX.Element;
