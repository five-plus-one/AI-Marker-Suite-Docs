import { Extension, type Editor } from '@tiptap/core';
export declare function cardEditRequested(editor: Editor, id: unknown): boolean;
export declare function acknowledgeCardEdit(editor: Editor, id: unknown): void;
export declare function insertDirectiveCard(editor: Editor, name?: string): boolean;
export declare function continueAfterCard(editor: Editor, getPos: () => number | undefined): boolean;
/** Protect card-body editors at the document boundary, including pasted and dropped content. */
export declare const CardBodyBoundary: Extension<any, any>;
