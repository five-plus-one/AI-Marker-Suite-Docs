export declare function parseDirectiveAttributes(value: string): Record<string, string>;
export declare function setDirectiveAttribute(value: string, key: string, next: string): string;
export declare function DirectiveFields({ name, value, onChange, disabled, }: {
    name: string;
    value: string;
    onChange: (value: string) => void;
    disabled?: boolean;
}): import("react").JSX.Element | null;
