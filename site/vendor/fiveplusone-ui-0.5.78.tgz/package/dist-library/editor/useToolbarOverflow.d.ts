export type ToolbarItem = {
    id: string;
    priority: number;
    width?: number;
    actions?: readonly unknown[];
};
/** Keep visual order stable while removing the least important groups first. */
export declare function partitionToolbarItems<T extends ToolbarItem>(items: readonly T[], available: number, width?: (item: T) => number, gap?: number): {
    visible: T[];
    overflow: T[];
};
export type ToolbarMode = "full" | "icons" | "group";
export declare function planToolbar<T extends ToolbarItem>(items: readonly T[], available: number, width: (item: T, mode: ToolbarMode) => number, overflowWidth?: number, gap?: number): {
    modes: Record<string, ToolbarMode>;
    visible: T[];
    overflow: T[];
};
export declare function useToolbarOverflow<T extends ToolbarItem>(items: readonly T[]): {
    hostRef: import("react").RefObject<HTMLDivElement | null>;
    measureRef: import("react").RefObject<HTMLDivElement | null>;
    modes: Record<string, ToolbarMode>;
    visible: T[];
    overflow: T[];
};
