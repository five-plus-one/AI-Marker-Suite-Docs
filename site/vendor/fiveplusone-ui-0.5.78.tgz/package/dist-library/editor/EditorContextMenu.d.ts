import { type ReactNode } from "react";
import type { Editor } from "@tiptap/core";
import { type ContextMenuItem } from "../ContextMenu";
/** Uses the editor selection rather than the menu's DOM focus for editing actions. */
export declare function EditorContextMenu({ editor, children, getExtraItems, }: {
    editor: Editor | null;
    children: ReactNode;
    getExtraItems?: (target: Element) => ContextMenuItem[];
}): import("react").JSX.Element;
