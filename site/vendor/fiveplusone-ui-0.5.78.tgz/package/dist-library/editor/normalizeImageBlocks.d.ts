import type { JSONContent } from '@tiptap/core';
/** Images are block nodes. Split legacy inline placements without discarding adjacent text. */
export declare function normalizeImageBlocks(document: JSONContent): JSONContent;
