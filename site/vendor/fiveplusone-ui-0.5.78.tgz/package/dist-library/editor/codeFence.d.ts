import { InputRule, type Editor } from '@tiptap/core';
import type { NodeType } from '@tiptap/pm/model';
import { Plugin } from '@tiptap/pm/state';
/** The third backtick opens the block; its optional language ends with Space or Enter. */
export declare function codeFenceInputRule(type: NodeType): InputRule;
export declare function codeFencePlugin(): Plugin<number | null>;
export declare function completeCodeFence(editor: Editor): boolean;
