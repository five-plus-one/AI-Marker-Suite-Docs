import { MarkdownManager } from "@tiptap/markdown";
import type { Extensions } from "@tiptap/core";
export declare const NOTE_ELEMENT_TYPES: string[];
export declare const NOTE_SCHEMA_VERSION = 2;
export declare function baseEditorExtensions(history?: boolean, math?: {
    onInlineClick?: (latex: string, position: number) => void;
    onBlockClick?: (latex: string, position: number) => void;
}, directiveExtension?: import("@tiptap/core").Node<any, any>, mathExtensions?: Extensions, attachmentExtension?: import("@tiptap/core").Node<any, any>, codeExtension?: import("@tiptap/core").Node<import("@tiptap/extension-code-block-lowlight").CodeBlockLowlightOptions, any>): (import("@tiptap/core").Node<import("@tiptap/extension-code-block-lowlight").CodeBlockLowlightOptions, any> | import("@tiptap/core").Node<any, any> | import("@tiptap/core").Node<{
    resolveUrl: (url: string) => string;
} & import("@tiptap/extension-image").ImageOptions, any> | import("@tiptap/core").Extension<import("@tiptap/extension-unique-id").UniqueIDOptions, any> | import("@tiptap/core").AnyExtension | import("@tiptap/core").Extension<import("@tiptap/starter-kit").StarterKitOptions, any> | import("@tiptap/core").Mark<import("@tiptap/extension-link").LinkOptions, any> | import("@tiptap/core").Mark<import("@tiptap/extension-text-style").TextStyleOptions, any> | import("@tiptap/core").Extension<import("@tiptap/extension-text-style").ColorOptions, any> | import("@tiptap/core").Mark<import("@tiptap/extension-highlight").HighlightOptions, any> | import("@tiptap/core").Extension<import("@tiptap/extension-table").TableKitOptions, any> | import("@tiptap/core").Extension<import("@tiptap/extension-mathematics").MathematicsOptions, any> | import("@tiptap/core").Extension<import("@tiptap/markdown").MarkdownExtensionOptions, import("@tiptap/markdown").MarkdownExtensionStorage>)[];
export declare function markdownToDocument(markdown: string): import("@tiptap/core").JSONContent;
export declare function documentToMarkdown(document: Parameters<MarkdownManager["serialize"]>[0]): string;
