/** EmbedFallback - 从课栈 browser/EmbedFallback 提取
 *
 * 当站点拒绝被内嵌时的回退界面：说明原因、提供打开原页面入口，
 * 并允许用户强制尝试内嵌。
 */
export interface EmbedFallbackProps {
    url: string;
    reason?: string;
    /** 强制内嵌回调 */
    onForce?: () => void;
    title?: string;
    actionLabel?: string;
}
export declare function EmbedFallback({ url, reason, onForce, title, actionLabel, }: EmbedFallbackProps): import("react").JSX.Element;
