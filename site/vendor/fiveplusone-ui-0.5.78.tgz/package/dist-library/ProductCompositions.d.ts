import { type ReactNode } from "react";
import { type MemberSearchProps, type MemberSearchResult, type MemberSearchKind } from "./MemberSearch";
import { type MemberAccessProps } from "./MemberAccess";
import { type ShareLinkProps } from "./ShareLink";
import { type ModelGroup } from "./ModelSelector";
import { type SelectOption } from "./SelectField";
import { type ResourceExplorerProps } from "./ResourceExplorer";
export interface ShareAccessPanelProps {
    title?: string;
    access: MemberAccessProps;
    search: Omit<MemberSearchProps, "onPick" | "excludedIds" | "disabled">;
    onAddMember: (member: MemberSearchResult, kind: MemberSearchKind) => Promise<void> | void;
    link: ShareLinkProps;
    permissionSummary?: ReactNode;
}
export declare function ShareAccessPanel({ title, access, search, onAddMember, link, permissionSummary, }: ShareAccessPanelProps): import("react").JSX.Element;
export interface ChatPreferencesPanelProps {
    models: ModelGroup[];
    modelId: string;
    onModelChange: (id: string) => void;
    thinking: string;
    thinkingOptions: SelectOption[];
    onThinkingChange: (value: string) => void;
    webEnabled: boolean;
    onWebChange: (value: boolean) => void;
    disabled?: boolean;
    quota?: ReactNode;
    children?: ReactNode;
}
export declare function ChatPreferencesPanel({ models, modelId, onModelChange, thinking, thinkingOptions, onThinkingChange, webEnabled, onWebChange, disabled, quota, children, }: ChatPreferencesPanelProps): import("react").JSX.Element;
export declare function ResourceWorkspace({ explorer, preview, previewTitle, actions, }: {
    explorer: ResourceExplorerProps;
    preview: ReactNode;
    previewTitle?: string;
    actions?: ReactNode;
}): import("react").JSX.Element;
