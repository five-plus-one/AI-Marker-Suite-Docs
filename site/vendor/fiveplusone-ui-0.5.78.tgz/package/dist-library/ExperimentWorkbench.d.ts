import { type ReactNode } from 'react';
import './experiment-workbench.css';
export interface ExperimentVersionOption {
    id: string;
    label: string;
}
export interface ExperimentWorkbenchProps {
    sessionKey?: string;
    mode?: 'create' | 'edit';
    generationSummary?: ReactNode;
    title: string;
    onTitleChange: (value: string) => void;
    prompt: string;
    onPromptChange: (value: string) => void;
    source: string;
    onSourceChange: (value: string) => void;
    preview: ReactNode;
    modelSelector?: ReactNode;
    busy?: boolean;
    progress?: ReactNode;
    canGenerate?: boolean;
    saveStatus: string;
    message?: string;
    versions?: ExperimentVersionOption[];
    onRestore?: (id: string) => void;
    onBack: () => void;
    onSave: () => void;
    onGenerate: () => void;
    onStop: () => void;
    onDuplicate: () => void;
    onExport: () => void;
    onInsert: () => void;
}
/** Controlled creation surface; the host owns durable saves and revision recovery. */
export declare function ExperimentWorkbench(p: ExperimentWorkbenchProps): import("react").JSX.Element;
