import type { ReactNode } from 'react';
import './settings-links.css';
export interface SettingsLinkItem {
    id: string;
    label: string;
    description?: string;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface SettingsLinksProps {
    items: SettingsLinkItem[];
    onSelect: (id: string) => void;
    label?: string;
}
/** Related settings destinations; routing remains with the host. */
export declare function SettingsLinks({ items, onSelect, label }: SettingsLinksProps): import("react").JSX.Element;
