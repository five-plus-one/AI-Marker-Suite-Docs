import { type ReactNode } from "react";
import { type MarkdownContentProps } from "./MarkdownContent";
import { type NoteEditorWorkspaceProps } from "./NoteEditorWorkspace";
export interface CourseExample {
    id: string;
    title: string;
    markdown: string;
}
export interface CourseContentWorkspaceProps extends Pick<NoteEditorWorkspaceProps, "document" | "onSave" | "autosaveDelay" | "versions" | "onRestore" | "editorProps" | "onExportDraft"> {
    subject?: string;
    summary?: string;
    examples?: CourseExample[];
    quiz?: ReactNode;
    readOnly?: boolean;
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    actions?: ReactNode;
    contentProps?: Omit<MarkdownContentProps, "markdown">;
    renderedContent?: ReactNode;
}
export declare function CourseContentWorkspace(props: CourseContentWorkspaceProps): import("react").JSX.Element;
