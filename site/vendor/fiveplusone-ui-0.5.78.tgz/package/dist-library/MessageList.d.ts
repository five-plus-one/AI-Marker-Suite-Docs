import { type ReactNode, type RefObject, type CSSProperties } from 'react';
export interface Message {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp?: Date;
}
export interface MessageListProps<T extends {
    id: string;
} = Message> {
    footer?: ReactNode;
    loadingIndicator?: ReactNode;
    className?: string;
    style?: CSSProperties;
    messages: T[];
    isLoading?: boolean;
    error?: string | null;
    onClearError?: () => void;
    onFollowUpClick?: (question: string) => void;
    followUpQuestions?: string[];
    bottomInset?: number;
    renderMessage?: (message: T) => ReactNode;
    emptyState?: ReactNode;
    hydrated?: boolean;
    /** Switch sessions with a stable component; offsets are restored per session. */
    sessionId?: string;
    scrollContainerRef?: RefObject<HTMLDivElement | null>;
    hasOlder?: boolean;
    loadingOlder?: boolean;
    onLoadOlder?: () => void;
    virtualize?: boolean;
    estimateSize?: number;
}
export declare function MessageList<T extends {
    id: string;
} = Message>({ messages, isLoading, error, onClearError, onFollowUpClick, followUpQuestions, bottomInset, renderMessage, emptyState, hydrated, sessionId, scrollContainerRef, hasOlder, loadingOlder, onLoadOlder, virtualize, estimateSize, footer, loadingIndicator, className, style }: MessageListProps<T>): import("react").JSX.Element;
export declare function MessageBubble({ message }: {
    message: Message;
}): import("react").JSX.Element;
