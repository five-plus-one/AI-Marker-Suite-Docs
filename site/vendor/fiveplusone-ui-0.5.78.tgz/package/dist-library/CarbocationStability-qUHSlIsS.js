import { jsxs as a, jsx as t } from "react/jsx-runtime";
import { memo as w, useState as u } from "react";
const y = [
  {
    key: "methyl",
    label: "甲基碳正离子",
    shortLabel: "甲基 CH₃⁺",
    adjacentMethyls: 0,
    hyperconjugationBonds: 0,
    stability: 1,
    formula: "CH₃⁺"
  },
  {
    key: "primary",
    label: "伯（1°）碳正离子",
    shortLabel: "伯 1°",
    adjacentMethyls: 1,
    hyperconjugationBonds: 3,
    stability: 2,
    formula: "CH₃–CH₂⁺"
  },
  {
    key: "secondary",
    label: "仲（2°）碳正离子",
    shortLabel: "仲 2°",
    adjacentMethyls: 2,
    hyperconjugationBonds: 6,
    stability: 3,
    formula: "(CH₃)₂CH⁺"
  },
  {
    key: "tertiary",
    label: "叔（3°）碳正离子",
    shortLabel: "叔 3°",
    adjacentMethyls: 3,
    hyperconjugationBonds: 9,
    stability: 4,
    formula: "(CH₃)₃C⁺"
  }
], O = [
  {
    key: "allyl",
    label: "烯丙基正离子",
    formula: "CH₂=CH–CH₂⁺",
    note: "正电荷通过 π 体系离域到两端碳，共振分散电荷。"
  },
  {
    key: "benzyl",
    label: "苄基正离子",
    formula: "C₆H₅–CH₂⁺",
    note: "正电荷离域进入苯环（邻、对位），多个共振式使其格外稳定。"
  }
], k = "#2563eb", v = "#dc2626", g = "#16a34a";
function N(o) {
  if (o <= 0) return [];
  const x = -90, h = [];
  for (let b = 0; b < o; b += 1)
    h.push(x + 360 / o * b);
  return h;
}
function A() {
  const [o, x] = u("tertiary"), [h, b] = u(!1), d = y.find((e) => e.key === o) ?? y[0], C = Math.max(...y.map((e) => e.stability)), c = 130, m = 120, f = 62, H = N(d.adjacentMethyls);
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-base font-semibold text-[var(--ink)]", children: "碳正离子稳定性：超共轭与诱导效应" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "点击下方任一碳正离子，观察其结构、参与 σ-p 超共轭的相邻 C–H σ 键数目， 以及稳定性排序。中心碳上连接的烷基越多，可超共轭的 C–H 键越多、诱导供电子越强， 正电荷越分散，离子越稳定。" }),
    /* @__PURE__ */ t("div", { className: "mt-4 flex flex-wrap gap-2", children: y.map((e) => {
      const r = e.key === o;
      return /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => x(e.key),
          className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition ${r ? "border-transparent bg-[var(--primary,#2563eb)] text-white shadow" : "border-[var(--line)] bg-[var(--bg-muted,#f8fafc)] text-[var(--ink)] hover:border-[var(--primary,#2563eb)]"}`,
          style: r ? { backgroundColor: k } : void 0,
          children: e.shortLabel
        },
        e.key
      );
    }) }),
    /* @__PURE__ */ a("div", { className: "mt-4 grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ a("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted,#f8fafc)] p-3", children: [
        /* @__PURE__ */ a("p", { className: "mb-1 text-sm font-medium text-[var(--ink)]", children: [
          d.label,
          "（",
          d.formula,
          "）"
        ] }),
        /* @__PURE__ */ a(
          "svg",
          {
            viewBox: "0 0 260 240",
            className: "h-56 w-full",
            role: "img",
            "aria-label": `${d.label}结构与超共轭 C-H 键`,
            children: [
              H.map((e, r) => {
                const n = e * Math.PI / 180, l = c + f * Math.cos(n), s = m + f * Math.sin(n), M = [0, 1, 2].map((i) => {
                  const p = n + (i - 1) * 0.55, j = l + 22 * Math.cos(p), S = s + 22 * Math.sin(p);
                  return { hx: j, hy: S, key: `${r}-${i}` };
                });
                return /* @__PURE__ */ a("g", { children: [
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: c,
                      y1: m,
                      x2: l,
                      y2: s,
                      stroke: "var(--ink)",
                      strokeWidth: 2
                    }
                  ),
                  /* @__PURE__ */ t(
                    "circle",
                    {
                      r: 14,
                      cx: l,
                      cy: s,
                      fill: "var(--bg-muted)",
                      stroke: "var(--ink)",
                      strokeWidth: 1.5
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: l,
                      y: s + 4,
                      textAnchor: "middle",
                      fontSize: 11,
                      fill: "var(--ink)",
                      children: "C"
                    }
                  ),
                  M.map((i) => /* @__PURE__ */ a("g", { children: [
                    /* @__PURE__ */ t(
                      "line",
                      {
                        x1: l,
                        y1: s,
                        x2: i.hx,
                        y2: i.hy,
                        stroke: g,
                        strokeWidth: 2,
                        strokeDasharray: "3 2"
                      }
                    ),
                    /* @__PURE__ */ t(
                      "text",
                      {
                        x: i.hx,
                        y: i.hy + 3,
                        textAnchor: "middle",
                        fontSize: 9,
                        fill: g,
                        children: "H"
                      }
                    )
                  ] }, i.key))
                ] }, `m-${r}`);
              }),
              /* @__PURE__ */ t(
                "circle",
                {
                  r: 20,
                  cx: c,
                  cy: m,
                  fill: "var(--bg-muted)",
                  stroke: v,
                  strokeWidth: 2.5
                }
              ),
              /* @__PURE__ */ t(
                "text",
                {
                  x: c,
                  y: m + 5,
                  textAnchor: "middle",
                  fontSize: 14,
                  fontWeight: 700,
                  fill: v,
                  children: "C⁺"
                }
              ),
              d.adjacentMethyls === 0 && N(3).map((e, r) => {
                const n = e * Math.PI / 180, l = c + 46 * Math.cos(n), s = m + 46 * Math.sin(n);
                return /* @__PURE__ */ a("g", { children: [
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: c,
                      y1: m,
                      x2: l,
                      y2: s,
                      stroke: "var(--ink)",
                      strokeWidth: 2
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: l,
                      y: s + 3,
                      textAnchor: "middle",
                      fontSize: 11,
                      fill: "var(--ink-soft)",
                      children: "H"
                    }
                  )
                ] }, `h0-${r}`);
              })
            ]
          }
        ),
        /* @__PURE__ */ a("p", { className: "text-xs text-[var(--ink-soft)]", children: [
          "高亮绿色虚线为参与 σ-p 超共轭的相邻 C–H σ 键：",
          /* @__PURE__ */ a("span", { className: "font-semibold text-[#16a34a]", children: [
            " ",
            d.hyperconjugationBonds,
            " 个"
          ] }),
          "（相邻甲基数 ",
          d.adjacentMethyls,
          "，每个甲基约贡献 3 个 C–H）。"
        ] })
      ] }),
      /* @__PURE__ */ a("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted,#f8fafc)] p-3", children: [
        /* @__PURE__ */ t("p", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "稳定性排序：叔 > 仲 > 伯 > 甲基" }),
        /* @__PURE__ */ t("div", { className: "space-y-2", children: [...y].sort((e, r) => r.stability - e.stability).map((e) => {
          const r = e.stability / C * 100, n = e.key === o;
          return /* @__PURE__ */ a("div", { children: [
            /* @__PURE__ */ a("div", { className: "flex items-center justify-between text-xs text-[var(--ink-soft)]", children: [
              /* @__PURE__ */ t(
                "span",
                {
                  className: n ? "font-semibold text-[var(--ink)]" : "",
                  children: e.shortLabel
                }
              ),
              /* @__PURE__ */ a("span", { children: [
                "超共轭 ",
                e.hyperconjugationBonds,
                " 个 C–H"
              ] })
            ] }),
            /* @__PURE__ */ t("div", { className: "mt-1 h-4 w-full overflow-hidden rounded bg-[var(--bg-elevated)] ring-1 ring-[var(--line)]", children: /* @__PURE__ */ t(
              "div",
              {
                className: "h-full rounded transition-all",
                style: {
                  width: `${r}%`,
                  backgroundColor: n ? v : k,
                  opacity: n ? 1 : 0.55
                }
              }
            ) })
          ] }, e.key);
        }) }),
        /* @__PURE__ */ t("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: "条越长代表越稳定（能量越低）。烷基越多 → 超共轭 C–H 越多、诱导供电子越强。" })
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] p-3 text-sm text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ t("p", { className: "font-medium text-[var(--ink)]", children: "为什么烷基越多越稳定？" }),
      /* @__PURE__ */ a("ul", { className: "mt-1 list-disc space-y-1 pl-5", children: [
        /* @__PURE__ */ a("li", { children: [
          /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "超共轭（σ-p 共轭）：" }),
          "相邻 C–H σ 键的成键电子与中心碳的空 p 轨道部分交盖，把电子密度送入空轨道， 分散正电荷。可超共轭的 C–H 越多，稳定化作用越强。"
        ] }),
        /* @__PURE__ */ a("li", { children: [
          /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "诱导效应：" }),
          "烷基相对 H 是供电子（+I）基团，沿 σ 键向缺电子的中心碳推送电子密度， 降低正电荷集中程度。"
        ] }),
        /* @__PURE__ */ a("li", { children: [
          "二者协同：叔（9 个 C–H、3 个烷基）> 仲（6、2）> 伯（3、1）> 甲基（0、0），故稳定性",
          " ",
          /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "叔 > 仲 > 伯 > 甲基" }),
          "。"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "mt-4", children: [
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: () => b((e) => !e),
          className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted,#f8fafc)] px-3 py-1.5 text-sm font-medium text-[var(--ink)] transition hover:border-[var(--primary,#2563eb)]",
          children: [
            h ? "− 隐藏" : "+ 加分项",
            "：共振稳定的碳正离子（烯丙基 / 苄基）"
          ]
        }
      ),
      h && /* @__PURE__ */ a("div", { className: "mt-3 grid gap-3 sm:grid-cols-2", children: [
        O.map((e) => /* @__PURE__ */ a(
          "div",
          {
            className: "rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] p-3",
            children: [
              /* @__PURE__ */ t("p", { className: "text-sm font-semibold text-[var(--ink)]", children: e.label }),
              /* @__PURE__ */ t("p", { className: "mt-0.5 font-mono text-sm text-[#dc2626]", children: e.formula }),
              /* @__PURE__ */ t("p", { className: "mt-1 text-xs text-[var(--ink-soft)]", children: e.note })
            ]
          },
          e.key
        )),
        /* @__PURE__ */ t("p", { className: "text-xs text-[var(--ink-soft)] sm:col-span-2", children: "共振离域比超共轭更有效：烯丙基/苄基正离子借助 π 体系把正电荷分摊到多个原子上， 因此通常比一般的仲、甚至叔碳正离子更稳定。" })
      ] })
    ] })
  ] });
}
const I = w(A);
export {
  I as default
};
