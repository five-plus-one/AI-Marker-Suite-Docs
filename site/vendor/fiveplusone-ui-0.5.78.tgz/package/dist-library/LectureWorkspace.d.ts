import { type AudioPlayerProps } from "./AudioPlayer";
import { type VideoPlayerProps } from "./VideoPlayer";
export interface LectureUtterance {
    id?: string;
    text: string;
    start: number;
    end: number;
    words?: {
        text: string;
        start: number;
        end: number;
    }[];
}
export interface LectureSection {
    id: string;
    title: string;
    start: number;
    markdown?: string;
}
export interface LectureWorkspaceProps {
    title: string;
    media: ({
        kind: "audio";
    } & AudioPlayerProps) | ({
        kind: "video";
    } & VideoPlayerProps);
    transcript: LectureUtterance[];
    chapters?: LectureSection[];
    notes: string;
    onNotesChange: (markdown: string) => void;
    onPositionChange?: (seconds: number) => void;
    onCite?: (reference: {
        title: string;
        time: number;
        text: string;
    }) => void;
}
export declare function LectureWorkspace({ title, media, transcript, chapters, notes, onNotesChange, onPositionChange, onCite, }: LectureWorkspaceProps): import("react").JSX.Element;
