import { jsxs as c, jsx as n } from "react/jsx-runtime";
import { memo as z, useState as S, useCallback as I, useMemo as C } from "react";
const E = "var(--accent)", G = "var(--fp-primary-soft)", w = "#ea580c", q = "#ea580c1f", H = "#0f766e", T = "#0f766e22", $ = "var(--line)", L = "var(--bg-muted)";
function D() {
  let t = 0, o = 0;
  for (; t === 0; ) t = Math.random();
  for (; o === 0; ) o = Math.random();
  return Math.sqrt(-2 * Math.log(t)) * Math.cos(2 * Math.PI * o);
}
function P() {
  let t = 0;
  for (; t === 0; ) t = Math.random();
  return -Math.log(t);
}
function R() {
  return Math.random();
}
function B(t) {
  if (t <= 0) return -1 / 0;
  if (t >= 1) return 1 / 0;
  if (t === 0.5) return 0;
  const o = 2.515517, s = 0.802853, m = 0.010328, a = 1.432788, x = 0.189269, u = 1308e-6, l = t < 0.5 ? t : 1 - t, e = Math.sqrt(-2 * Math.log(l)), d = e - (o + s * e + m * e * e) / (1 + a * e + x * e * e + u * e * e * e);
  return t < 0.5 ? -d : d;
}
function Y(t, o) {
  const s = [];
  for (let m = 0; m < o; m++)
    t === "normal" ? s.push(D()) : t === "uniform" ? s.push(R()) : s.push(P());
  return s.sort((m, a) => m - a);
}
function O(t) {
  const o = t.length;
  if (o === 0) return [];
  const s = t.reduce((a, x) => a + x, 0) / o, m = Math.sqrt(t.reduce((a, x) => a + (x - s) ** 2, 0) / o) || 1;
  return t.map((a, x) => {
    const u = (x + 1 - 0.375) / (o + 0.25);
    return {
      theoretical: B(u),
      sample: (a - s) / m,
      rank: x + 1
    };
  });
}
const _ = 300, F = 240, i = { top: 20, right: 20, bottom: 36, left: 42 };
function Q() {
  return _ - i.left - i.right;
}
function k() {
  return F - i.top - i.bottom;
}
function g(t, o, s) {
  return i.left + (t - o) / (s - o) * Q();
}
function y(t, o, s) {
  return i.top + k() - (t - o) / (s - o) * k();
}
const A = {
  normal: {
    label: "正态 N(0,1)",
    color: E,
    bg: G,
    desc: "点接近对角线 → 服从正态分布"
  },
  uniform: {
    label: "均匀 U(0,1)",
    color: H,
    bg: T,
    desc: "S 形弯曲 → 尾部轻于正态（尾巴短）"
  },
  exponential: {
    label: "指数 Exp(1)",
    color: w,
    bg: q,
    desc: "右端上翘 → 右偏分布（长右尾）"
  }
};
function X({
  sorted: t,
  dist: o,
  hoveredIdx: s,
  onHover: m
}) {
  const a = t.length;
  if (a === 0)
    return /* @__PURE__ */ n("div", { className: "h-16 flex items-center justify-center text-[12px] text-[var(--ink-soft)]", children: "点击「重新抽样」开始" });
  const x = t[0], u = t[a - 1], l = u - x || 1, e = A[o].color, d = Math.max(1, Math.floor(a / 80)), p = [];
  for (let h = 0; h < a; h += d) p.push({ i: h, v: t[h] });
  return /* @__PURE__ */ c("div", { className: "relative", style: { height: 52 }, children: [
    /* @__PURE__ */ n("div", { className: "absolute inset-0 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] overflow-hidden", children: p.map(({ i: h, v: r }) => {
      const N = (r - x) / l * 100, b = h / (a - 1 || 1) * 100, v = s !== null && Math.abs(h - s) <= d;
      return /* @__PURE__ */ n(
        "div",
        {
          className: "absolute bottom-0 transition-opacity",
          style: {
            left: `${b}%`,
            width: `${Math.max(1, 100 / p.length - 0.3)}%`,
            height: `${Math.max(4, N)}%`,
            background: e,
            opacity: v ? 1 : 0.55,
            minHeight: 2
          },
          onMouseEnter: () => m(h),
          onMouseLeave: () => m(null)
        },
        h
      );
    }) }),
    /* @__PURE__ */ c("div", { className: "absolute -bottom-5 left-0 right-0 flex justify-between text-[10px] text-[var(--ink-soft)] px-1", children: [
      /* @__PURE__ */ c("span", { children: [
        "x₍₁₎ = ",
        x.toFixed(3)
      ] }),
      /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "顺序统计量" }),
      /* @__PURE__ */ c("span", { children: [
        "x₍ₙ₎ = ",
        u.toFixed(3)
      ] })
    ] })
  ] });
}
function K({
  points: t,
  dist: o,
  hoveredIdx: s,
  onHover: m
}) {
  const a = A[o].color, x = t.map((r) => r.theoretical), u = t.map((r) => r.sample), l = Math.min(-2.5, Math.min(...x), Math.min(...u)), e = Math.max(2.5, Math.max(...x), Math.max(...u)), d = [-2, -1, 0, 1, 2], p = [-2, -1, 0, 1, 2], h = s !== null && t[s];
  return /* @__PURE__ */ c(
    "svg",
    {
      viewBox: `0 0 ${_} ${F}`,
      className: "w-full rounded-lg border border-[var(--line)]",
      style: { background: L },
      onMouseLeave: () => m(null),
      children: [
        d.map((r) => /* @__PURE__ */ n(
          "line",
          {
            x1: g(r, l, e),
            y1: i.top,
            x2: g(r, l, e),
            y2: i.top + k(),
            stroke: $,
            strokeWidth: 1
          },
          `vg${r}`
        )),
        p.map((r) => /* @__PURE__ */ n(
          "line",
          {
            x1: i.left,
            y1: y(r, l, e),
            x2: i.left + Q(),
            y2: y(r, l, e),
            stroke: $,
            strokeWidth: 1
          },
          `hg${r}`
        )),
        /* @__PURE__ */ n(
          "line",
          {
            x1: g(l, l, e),
            y1: y(l, l, e),
            x2: g(e, l, e),
            y2: y(e, l, e),
            stroke: "var(--ink-faint)",
            strokeWidth: 1.5,
            strokeDasharray: "5 3"
          }
        ),
        /* @__PURE__ */ n(
          "text",
          {
            x: g(e, l, e) - 4,
            y: y(e, l, e) + 12,
            fontSize: 9,
            fill: "var(--ink-faint)",
            textAnchor: "end",
            children: "y=x"
          }
        ),
        t.map((r, N) => {
          const b = g(r.theoretical, l, e), v = y(r.sample, l, e), f = N === s;
          return /* @__PURE__ */ n(
            "circle",
            {
              cx: b,
              cy: v,
              r: f ? 5 : t.length > 60 ? 2.5 : 3.5,
              fill: a,
              opacity: f ? 1 : 0.65,
              stroke: f ? "white" : "none",
              strokeWidth: 1.5,
              style: { cursor: "pointer" },
              onMouseEnter: () => m(N)
            },
            N
          );
        }),
        h && /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ n(
            "line",
            {
              x1: g(h.theoretical, l, e),
              y1: i.top,
              x2: g(h.theoretical, l, e),
              y2: i.top + k(),
              stroke: a,
              strokeWidth: 1,
              strokeDasharray: "3 2",
              opacity: 0.6
            }
          ),
          /* @__PURE__ */ n(
            "line",
            {
              x1: i.left,
              y1: y(h.sample, l, e),
              x2: i.left + Q(),
              y2: y(h.sample, l, e),
              stroke: a,
              strokeWidth: 1,
              strokeDasharray: "3 2",
              opacity: 0.6
            }
          ),
          (() => {
            const r = g(h.theoretical, l, e), N = y(h.sample, l, e), b = 108, v = 38, f = Math.min(r + 8, i.left + Q() - b - 4), M = Math.max(i.top + 4, N - v - 4);
            return /* @__PURE__ */ c("g", { children: [
              /* @__PURE__ */ n(
                "rect",
                {
                  x: f,
                  y: M,
                  width: b,
                  height: v,
                  rx: 5,
                  fill: "var(--bg-elevated)",
                  stroke: a,
                  strokeWidth: 1
                }
              ),
              /* @__PURE__ */ c(
                "text",
                {
                  x: f + 6,
                  y: M + 14,
                  fontSize: 10,
                  fill: a,
                  fontWeight: "700",
                  children: [
                    "x₍",
                    h.rank,
                    "₎ 理论: ",
                    h.theoretical.toFixed(3)
                  ]
                }
              ),
              /* @__PURE__ */ c(
                "text",
                {
                  x: f + 6,
                  y: M + 28,
                  fontSize: 10,
                  fill: "var(--ink-soft)",
                  children: [
                    "样本 Z: ",
                    h.sample.toFixed(3)
                  ]
                }
              )
            ] });
          })()
        ] }),
        /* @__PURE__ */ n(
          "line",
          {
            x1: i.left,
            y1: i.top,
            x2: i.left,
            y2: i.top + k(),
            stroke: "var(--line)",
            strokeWidth: 1.5
          }
        ),
        /* @__PURE__ */ n(
          "line",
          {
            x1: i.left,
            y1: i.top + k(),
            x2: i.left + Q(),
            y2: i.top + k(),
            stroke: "var(--line)",
            strokeWidth: 1.5
          }
        ),
        d.map((r) => /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ n(
            "line",
            {
              x1: g(r, l, e),
              y1: i.top + k(),
              x2: g(r, l, e),
              y2: i.top + k() + 4,
              stroke: "var(--line)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ n(
            "text",
            {
              x: g(r, l, e),
              y: i.top + k() + 14,
              fontSize: 9,
              textAnchor: "middle",
              fill: "var(--ink-soft)",
              children: r
            }
          )
        ] }, `xt${r}`)),
        p.map((r) => /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ n(
            "line",
            {
              x1: i.left - 4,
              y1: y(r, l, e),
              x2: i.left,
              y2: y(r, l, e),
              stroke: "var(--line)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ n(
            "text",
            {
              x: i.left - 6,
              y: y(r, l, e) + 3,
              fontSize: 9,
              textAnchor: "end",
              fill: "var(--ink-soft)",
              children: r
            }
          )
        ] }, `yt${r}`)),
        /* @__PURE__ */ n(
          "text",
          {
            x: i.left + Q() / 2,
            y: F - 2,
            fontSize: 10,
            textAnchor: "middle",
            fill: "var(--ink-soft)",
            fontWeight: "600",
            children: "理论正态分位数"
          }
        ),
        /* @__PURE__ */ n(
          "text",
          {
            x: 10,
            y: i.top + k() / 2,
            fontSize: 10,
            textAnchor: "middle",
            fill: "var(--ink-soft)",
            fontWeight: "600",
            transform: `rotate(-90, 10, ${i.top + k() / 2})`,
            children: "样本分位数 (Z)"
          }
        )
      ]
    }
  );
}
function U(t) {
  const o = t.length;
  if (o === 0) return null;
  const s = t.reduce((d, p) => d + p, 0) / o, m = t.reduce((d, p) => d + (p - s) ** 2, 0) / o, a = Math.sqrt(m), x = t[Math.floor(o * 0.25)], u = o % 2 === 0 ? (t[o / 2 - 1] + t[o / 2]) / 2 : t[Math.floor(o / 2)], l = t[Math.floor(o * 0.75)], e = o > 2 ? t.reduce((d, p) => d + ((p - s) / (a || 1)) ** 3, 0) / o : 0;
  return { mean: s, std: a, median: u, q1: x, q3: l, skewness: e };
}
function V(t) {
  if (t.length < 3) return 1;
  const o = t.map((e) => e.theoretical), s = t.map((e) => e.sample), m = o.reduce((e, d) => e + d, 0) / o.length, a = s.reduce((e, d) => e + d, 0) / s.length, x = o.reduce((e, d, p) => e + (d - m) * (s[p] - a), 0), u = Math.sqrt(o.reduce((e, d) => e + (d - m) ** 2, 0)), l = Math.sqrt(s.reduce((e, d) => e + (d - a) ** 2, 0));
  return u * l > 0 ? x / (u * l) : 1;
}
function Z() {
  const [t, o] = S("normal"), [s, m] = S(30), [a, x] = S([]), [u, l] = S(null), [e, d] = S(0), p = I(() => {
    x(Y(t, s)), d((f) => f + 1), l(null);
  }, [t, s]), h = C(() => O(a), [a]), r = C(() => U(a), [a]), N = C(() => V(h), [h]), b = A[t], v = N > 0.97;
  return /* @__PURE__ */ c("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "样本分位数与 Q-Q 图" }),
      /* @__PURE__ */ n("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: "从不同分布抽样，观察 Q-Q 图点是否沿对角线排列——这正是正态性检验的直觉。" })
    ] }),
    /* @__PURE__ */ c("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: [
      /* @__PURE__ */ c("div", { children: [
        /* @__PURE__ */ n("div", { className: "mb-2 text-[13px] font-semibold text-[var(--ink)]", children: "总体分布" }),
        /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-2", children: ["normal", "uniform", "exponential"].map(
          (f) => {
            const M = A[f], W = t === f;
            return /* @__PURE__ */ n(
              "button",
              {
                type: "button",
                onClick: () => {
                  o(f), x([]), d(0), l(null);
                },
                className: "rounded-lg px-3 py-1.5 text-[12px] font-medium transition-all",
                style: {
                  background: W ? M.color : "transparent",
                  color: W ? "white" : M.color,
                  border: `1.5px solid ${M.color}`
                },
                children: M.label
              },
              f
            );
          }
        ) })
      ] }),
      /* @__PURE__ */ c("div", { className: "space-y-1", children: [
        /* @__PURE__ */ c("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ n("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "样本量 n" }),
          /* @__PURE__ */ n(
            "span",
            {
              className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
              style: { background: b.bg, color: b.color },
              children: s
            }
          )
        ] }),
        /* @__PURE__ */ n(
          "input",
          {
            type: "range",
            min: 10,
            max: 100,
            step: 1,
            value: s,
            onChange: (f) => {
              m(Number(f.target.value)), x([]), d(0), l(null);
            },
            className: "w-full h-1.5 cursor-pointer",
            style: { accentColor: b.color }
          }
        ),
        /* @__PURE__ */ c("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ n("span", { children: "10" }),
          /* @__PURE__ */ n("span", { children: "100" })
        ] })
      ] }),
      /* @__PURE__ */ c(
        "button",
        {
          type: "button",
          onClick: p,
          className: "w-full rounded-lg py-2 text-[14px] font-bold text-white transition-opacity hover:opacity-90 active:scale-[0.98]",
          style: { background: b.color },
          children: [
            a.length === 0 ? "▶ 开始抽样" : "↻ 重新抽样",
            e > 0 && /* @__PURE__ */ c("span", { className: "ml-2 text-[11px] opacity-80 font-normal", children: [
              "（第 ",
              e,
              " 次）"
            ] })
          ]
        }
      )
    ] }),
    a.length > 0 && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ n("div", { className: "mb-3 text-[12px] font-semibold text-[var(--ink)]", children: "排序后样本（顺序统计量 x₍₁₎ ≤ x₍₂₎ ≤ … ≤ x₍ₙ₎）" }),
      /* @__PURE__ */ n(
        X,
        {
          sorted: a,
          dist: t,
          hoveredIdx: u,
          onHover: l
        }
      ),
      /* @__PURE__ */ n("div", { className: "mt-7" })
    ] }),
    a.length > 0 && /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ c("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ n("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "Q-Q 图（悬停查看分位数详情）" }),
        h.length > 0 && /* @__PURE__ */ c(
          "div",
          {
            className: "rounded-md px-2 py-0.5 text-[11px] font-mono font-bold",
            style: {
              background: v ? G : q,
              color: v ? E : w
            },
            children: [
              "相关系数 r = ",
              N.toFixed(4)
            ]
          }
        )
      ] }),
      /* @__PURE__ */ n(
        K,
        {
          points: h,
          dist: t,
          hoveredIdx: u,
          onHover: l
        }
      )
    ] }),
    a.length > 0 && /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg border-2 p-3 text-[12px] leading-relaxed",
        style: {
          borderColor: v ? E : w,
          background: v ? G : q
        },
        children: [
          /* @__PURE__ */ c("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ n("span", { className: "text-[15px]", children: v ? "[OK]" : "[X]" }),
            /* @__PURE__ */ n(
              "span",
              {
                className: "font-bold text-[13px]",
                style: { color: v ? E : w },
                children: v ? "点接近对角线 → 可能来自正态总体" : "点偏离对角线 → 不服从正态分布"
              }
            )
          ] }),
          /* @__PURE__ */ c("p", { style: { color: v ? "var(--accent)" : w }, children: [
            b.desc,
            "。",
            t === "uniform" && " 均匀分布尾部「截断」，没有极端值，所以 Q-Q 图两端向内弯曲。",
            t === "exponential" && " 指数分布右偏，有长右尾，样本最大值比正态分位数大很多，图形右端上翘。",
            t === "normal" && " 多次抽样重试，n 越大点越贴近 y=x 对角线。"
          ] })
        ]
      }
    ),
    r && /* @__PURE__ */ n("div", { className: "grid grid-cols-3 gap-2 sm:grid-cols-6", children: [
      {
        label: "均值 x̄",
        val: r.mean.toFixed(3),
        color: b.color,
        bg: b.bg
      },
      {
        label: "标准差 s",
        val: r.std.toFixed(3),
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      },
      {
        label: "中位数",
        val: r.median.toFixed(3),
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      },
      {
        label: "Q₁",
        val: r.q1.toFixed(3),
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      },
      {
        label: "Q₃",
        val: r.q3.toFixed(3),
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      },
      {
        label: "偏度",
        val: r.skewness.toFixed(3),
        color: Math.abs(r.skewness) > 0.5 ? w : H,
        bg: Math.abs(r.skewness) > 0.5 ? q : T
      }
    ].map(({ label: f, val: M, color: W, bg: j }) => /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg p-2 text-center",
        style: { background: j },
        children: [
          /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)]", children: f }),
          /* @__PURE__ */ n(
            "div",
            {
              className: "text-[14px] font-bold font-mono mt-0.5",
              style: { color: W },
              children: M
            }
          )
        ]
      },
      f
    )) }),
    /* @__PURE__ */ c("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1.5", children: [
      /* @__PURE__ */ c("p", { children: [
        /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "Q-Q 图的本质：" }),
        "将样本第 k 个顺序统计量 x₍ₖ₎ 与正态分布的第 k/(n+1) 分位数对比。若样本来自正态总体， 散点近似落在",
        " ",
        /* @__PURE__ */ n("span", { className: "font-mono", children: "y = x" }),
        " ",
        "对角线上；若有系统偏离，说明分布形态不同。"
      ] }),
      /* @__PURE__ */ c("p", { children: [
        /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "正态性检验的直觉：" }),
        "Shapiro-Wilk 检验、K-S 检验等都在量化这种偏离程度。 这里的 Q-Q 相关系数 r 越接近 1，越支持正态性。"
      ] }),
      /* @__PURE__ */ c("p", { children: [
        /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "提示：" }),
        "多点击「重新抽样」感受抽样随机性——n 小时点散漫，n=100 时规律清晰。"
      ] })
    ] })
  ] });
}
const et = z(Z);
export {
  et as default
};
