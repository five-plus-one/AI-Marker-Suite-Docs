import { jsxs as a, jsx as n } from "react/jsx-runtime";
import { L as x } from "./LearningSelect-DSx2ZDO6.js";
import { useState as b } from "react";
const m = ["a", "b", "c", "d"], g = [
  [0, 1],
  [0, 2],
  [0, 3],
  [1, 2],
  [1, 3],
  [2, 3]
];
function B(r) {
  const s = g.filter((e, i) => r & 1 << i), o = m.map(
    (e, i) => s.filter((d) => d.includes(i)).length
  ), t = [-1, -1, -1, -1];
  let h = !0, c = 0;
  for (let e = 0; e < 4; e++) {
    if (t[e] >= 0) continue;
    c++, t[e] = 0;
    const i = [e];
    for (let d = 0; d < i.length; d++) {
      const p = i[d];
      for (const u of s) {
        if (!u.includes(p)) continue;
        const f = u[0] === p ? u[1] : u[0];
        t[f] < 0 ? (t[f] = 1 - t[p], i.push(f)) : t[f] === t[p] && (h = !1);
      }
    }
  }
  let l = [];
  for (let e = 0; e < 1 << s.length; e++) {
    const i = s.filter((p, u) => e & 1 << u), d = i.flat();
    new Set(d).size === d.length && i.length > l.length && (l = i);
  }
  return { edges: s, degrees: o, colors: t, bipartite: h, components: c, matching: l };
}
function y({
  matching: r = !1
}) {
  const [s, o] = b(45), t = B(s), h = [
    [90, 60],
    [310, 60],
    [310, 230],
    [90, 230]
  ];
  return /* @__PURE__ */ a(
    "section",
    {
      "aria-label": r ? "图的匹配实验" : "图的度数与二染色实验",
      className: "rounded-xl border p-4 my-6",
      children: [
        /* @__PURE__ */ n("h3", { children: r ? "选边与最大匹配" : "改变边，观察图的性质" }),
        /* @__PURE__ */ n("p", { children: "点击边的开关，观察度数、连通分支和二染色如何一起变化。" }),
        /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-3", children: g.map(([c, l], e) => /* @__PURE__ */ a("label", { children: [
          /* @__PURE__ */ n(
            "input",
            {
              type: "checkbox",
              checked: !!(s & 1 << e),
              onChange: () => o(s ^ 1 << e)
            }
          ),
          " ",
          m[c],
          "—",
          m[l]
        ] }, e)) }),
        /* @__PURE__ */ a(
          "svg",
          {
            viewBox: "0 0 400 290",
            role: "img",
            "aria-label": "当前无向图",
            style: { width: "100%", maxHeight: 300 },
            children: [
              t.edges.map(([c, l]) => /* @__PURE__ */ n(
                "line",
                {
                  x1: h[c][0],
                  y1: h[c][1],
                  x2: h[l][0],
                  y2: h[l][1],
                  stroke: r && t.matching.some((e) => e[0] === c && e[1] === l) ? "#d87927" : "#8b79a5",
                  strokeWidth: r && t.matching.some((e) => e[0] === c && e[1] === l) ? 7 : 3
                },
                `${c}-${l}`
              )),
              h.map(([c, l], e) => /* @__PURE__ */ a("g", { children: [
                /* @__PURE__ */ n(
                  "circle",
                  {
                    cx: c,
                    cy: l,
                    r: 23,
                    fill: t.colors[e] ? "#f0c589" : "#cab5f0"
                  }
                ),
                /* @__PURE__ */ n("text", { x: c, y: l + 6, textAnchor: "middle", fill: "#252033", children: m[e] })
              ] }, e))
            ]
          }
        ),
        /* @__PURE__ */ a("p", { "aria-live": "polite", children: [
          "度数：",
          t.degrees.join("、"),
          "；度数和",
          " ",
          t.degrees.reduce((c, l) => c + l, 0),
          " = 2 × ",
          t.edges.length,
          "。连通分支：",
          t.components,
          "。"
        ] }),
        /* @__PURE__ */ n("p", { children: t.bipartite ? "可以二染色：每条边的两个端点颜色不同。" : "存在奇圈，当前图不能二染色。" }),
        r && /* @__PURE__ */ a("p", { children: [
          "橙色边是一组最大匹配，大小为 ",
          t.matching.length,
          "。每个顶点最多连接一条被选中的边。尝试只保留 a—b、b—c、c—d，比较中间一条与两端两条。"
        ] })
      ]
    }
  );
}
function S() {
  return /* @__PURE__ */ n(y, { matching: !0 });
}
function k() {
  const [r, s] = b(7), [o, t] = b(14), h = (l) => m.filter((e, i) => l & 1 << i), c = (l) => h(l).length;
  return /* @__PURE__ */ a("section", { "aria-label": "集合运算实验", className: "rounded-xl border p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "逐个元素检查集合运算" }),
    [
      ["A", r, s],
      ["B", o, t]
    ].map(([l, e, i]) => /* @__PURE__ */ a("div", { children: [
      String(l),
      "：",
      m.map((d, p) => /* @__PURE__ */ a("label", { className: "mx-2", children: [
        /* @__PURE__ */ n(
          "input",
          {
            type: "checkbox",
            checked: !!(Number(e) & 1 << p),
            onChange: () => i(Number(e) ^ 1 << p)
          }
        ),
        d
      ] }, d))
    ] }, String(l))),
    /* @__PURE__ */ a("table", { className: "w-full my-4", children: [
      /* @__PURE__ */ n("thead", { children: /* @__PURE__ */ a("tr", { children: [
        /* @__PURE__ */ n("th", { children: "元素" }),
        /* @__PURE__ */ n("th", { children: "属于 A" }),
        /* @__PURE__ */ n("th", { children: "属于 B" }),
        /* @__PURE__ */ n("th", { children: "A∪B" }),
        /* @__PURE__ */ n("th", { children: "A∩B" }),
        /* @__PURE__ */ n("th", { children: "A∖B" })
      ] }) }),
      /* @__PURE__ */ n("tbody", { children: m.map((l, e) => /* @__PURE__ */ n("tr", { children: [
        l,
        !!(r & 1 << e),
        !!(o & 1 << e),
        !!((r | o) & 1 << e),
        !!(r & o & 1 << e),
        !!(r & ~o & 1 << e)
      ].map((i, d) => /* @__PURE__ */ n("td", { children: typeof i == "boolean" ? i ? "是" : "否" : i }, d)) }, l)) })
    ] }),
    /* @__PURE__ */ a("p", { "aria-live": "polite", children: [
      "|A∪B| = ",
      c(r | o),
      " = ",
      c(r),
      " + ",
      c(o),
      " − ",
      c(r & o),
      "。交集中的元素在两次计数中重复了一次。"
    ] })
  ] });
}
function w() {
  const [r, s] = b(2), o = [1, 2, 3, 6];
  return /* @__PURE__ */ a("section", { "aria-label": "整除偏序实验", className: "rounded-xl border p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "整除关系中的上界与下界" }),
    /* @__PURE__ */ a("p", { children: [
      "集合为 ",
      "{1,2,3,6}",
      "，顺序 a≤b 表示 a 整除 b。选择一个元素，查看它与其他元素是否可比。"
    ] }),
    /* @__PURE__ */ n(
      x,
      {
        "aria-label": "选择元素",
        value: r,
        onChange: (t) => s(Number(t.target.value)),
        children: o.map((t) => /* @__PURE__ */ n("option", { children: t }, t))
      }
    ),
    /* @__PURE__ */ n("table", { className: "w-full my-4", children: /* @__PURE__ */ n("tbody", { children: o.map((t) => /* @__PURE__ */ a("tr", { children: [
      /* @__PURE__ */ n("th", { children: t }),
      /* @__PURE__ */ n("td", { children: r % t === 0 ? `${t} 是 ${r} 的下界` : t % r === 0 ? `${t} 是 ${r} 的上界` : "二者不可比" })
    ] }, t)) }) }),
    /* @__PURE__ */ n("p", { children: "2 与 3 的公共下界只有 1，公共上界只有 6，因此下确界为 1、上确界为 6。偏序允许不可比元素。" })
  ] });
}
export {
  y as GraphStructureLab,
  S as MatchingLab,
  w as OrderLab,
  k as SetCountingLab,
  B as graphFacts
};
