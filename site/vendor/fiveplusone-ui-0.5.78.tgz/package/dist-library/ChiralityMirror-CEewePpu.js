import { jsxs as r, jsx as e } from "react/jsx-runtime";
import { memo as u, useState as m } from "react";
import { motion as p } from "framer-motion";
const b = [
  { key: "a", x: 0, y: -52 },
  // 顶部
  { key: "b", x: 46, y: 26 },
  // 右下
  { key: "c", x: -46, y: 26 },
  // 左下
  { key: "d", x: 0, y: 14 }
  // 朝向观察者（中间偏下）
], k = {
  a: { label: "—H", color: "#94a3b8" },
  b: { label: "—Cl", color: "#22c55e" },
  c: { label: "—Br", color: "#a16207" },
  d: { label: "—F", color: "#3b82f6" }
}, v = {
  a: { label: "—H", color: "#94a3b8" },
  b: { label: "—Cl", color: "#22c55e" },
  c: { label: "—Br", color: "#a16207" },
  d: { label: "—H", color: "#94a3b8" }
};
function h({ groups: i, mirrored: a, rotation: s }) {
  const l = a ? -1 : 1;
  return /* @__PURE__ */ r(
    p.g,
    {
      animate: { rotate: s, scaleX: l },
      transition: { type: "tween", duration: 0.7, ease: "easeInOut" },
      style: { transformOrigin: "center", transformBox: "fill-box" },
      children: [
        b.map((t) => /* @__PURE__ */ e(
          "line",
          {
            x1: 0,
            y1: 0,
            x2: t.x,
            y2: t.y,
            stroke: "var(--ink-soft)",
            strokeWidth: 3,
            strokeLinecap: "round"
          },
          `bond-${t.key}`
        )),
        /* @__PURE__ */ e("circle", { cx: 0, cy: 0, r: 11, fill: "var(--ink)" }),
        /* @__PURE__ */ e(
          "text",
          {
            x: 0,
            y: 4,
            textAnchor: "middle",
            fontSize: 11,
            fill: "#ffffff",
            fontWeight: 700,
            children: "C"
          }
        ),
        b.map((t) => {
          const o = i[t.key];
          return /* @__PURE__ */ r("g", { children: [
            /* @__PURE__ */ e("circle", { cx: t.x, cy: t.y, r: 15, fill: o.color }),
            /* @__PURE__ */ e(
              "text",
              {
                x: t.x,
                y: t.y + 4,
                textAnchor: "middle",
                fontSize: 10,
                fill: "#ffffff",
                fontWeight: 700,
                transform: a ? `scale(-1,1) translate(${-2 * t.x},0)` : void 0,
                children: o.label
              }
            )
          ] }, `atom-${t.key}`);
        })
      ]
    }
  );
}
function N() {
  const [i, a] = m("chiral"), [s, c] = m(0), [d, l] = m(0), t = i === "chiral" ? k : v, o = i === "chiral", f = () => {
    c((n) => n + 120), l((n) => n + 1);
  }, g = () => {
    c(0), l(0);
  }, x = (n) => {
    a(n), c(0), l(0);
  }, y = o ? d === 0 ? "点击「旋转镜像」试着把右侧镜像转去与左侧原分子重叠。" : "无论怎么旋转，镜像都无法与原分子完全重叠 —— 这就是手性（对映异构体）。" : d === 0 ? "这里把 d 基团也换成 —H（两个相同基团）。试试旋转镜像。" : "因为存在对称面，旋转后镜像可以与原分子重叠 —— 这是非手性分子。";
  return /* @__PURE__ */ r("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-bold text-[var(--ink)]", children: "手性与镜像" }),
    /* @__PURE__ */ r("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: [
      "一个连有四个",
      /* @__PURE__ */ e("strong", { children: "不同" }),
      "基团的碳原子（手性碳），其分子与镜像无法通过旋转完全重叠， 如同左右手。这种「与镜像不可重叠」的性质称为",
      /* @__PURE__ */ e("strong", { children: "手性" }),
      "，对应一对",
      /* @__PURE__ */ e("strong", { children: "对映异构体" }),
      "。"
    ] }),
    /* @__PURE__ */ r("div", { className: "mt-4 flex flex-wrap gap-2", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => x("chiral"),
          className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors ${o ? "border-indigo-600 bg-indigo-600 text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)]"}`,
          children: "手性 (a,b,c,d 全不同)"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => x("achiral"),
          className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors ${o ? "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)]" : "border-indigo-600 bg-indigo-600 text-white"}`,
          children: "非手性 (含相同基团)"
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-2", children: /* @__PURE__ */ r(
      "svg",
      {
        viewBox: "0 0 360 200",
        className: "h-auto w-full",
        role: "img",
        "aria-label": "手性碳分子及其镜像",
        children: [
          /* @__PURE__ */ e("g", { transform: "translate(90,100)", children: /* @__PURE__ */ e(h, { groups: t, mirrored: !1, rotation: 0 }) }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: 180,
              y1: 20,
              x2: 180,
              y2: 180,
              stroke: "var(--ink-soft)",
              strokeWidth: 2,
              strokeDasharray: "6 6"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: 180,
              y: 16,
              textAnchor: "middle",
              fontSize: 11,
              fill: "var(--ink-soft)",
              children: "镜面"
            }
          ),
          /* @__PURE__ */ e("g", { transform: "translate(270,100)", children: /* @__PURE__ */ e(h, { groups: t, mirrored: !0, rotation: s }) }),
          /* @__PURE__ */ e(
            "text",
            {
              x: 90,
              y: 196,
              textAnchor: "middle",
              fontSize: 11,
              fill: "var(--ink)",
              fontWeight: 600,
              children: "原分子"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: 270,
              y: 196,
              textAnchor: "middle",
              fontSize: 11,
              fill: "var(--ink)",
              fontWeight: 600,
              children: "镜像"
            }
          )
        ]
      }
    ) }),
    /* @__PURE__ */ r("div", { className: "mt-3 flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: f,
          className: "rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-700",
          children: "旋转镜像 (+120°)"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: g,
          className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-1.5 text-sm font-medium text-[var(--ink)]",
          children: "复位"
        }
      ),
      /* @__PURE__ */ r("span", { className: "text-sm text-[var(--ink-soft)]", children: [
        "已旋转 ",
        d,
        " 次（当前 ",
        s % 360,
        "°）"
      ] })
    ] }),
    /* @__PURE__ */ e(
      "p",
      {
        className: `mt-3 rounded-lg border px-3 py-2 text-sm ${o ? "border-rose-500/30 bg-rose-500/10 text-[var(--md-sys-color-error)]" : "border-emerald-500/30 bg-emerald-500/10 text-[var(--color-success)]"}`,
        children: y
      }
    ),
    /* @__PURE__ */ r("div", { className: "mt-3 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 text-sm text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("p", { className: "font-semibold text-[var(--ink)]", children: "判定要点" }),
      /* @__PURE__ */ r("ul", { className: "mt-1 list-inside list-disc space-y-1", children: [
        /* @__PURE__ */ r("li", { children: [
          /* @__PURE__ */ e("strong", { children: "手性" }),
          " = 分子与其镜像",
          /* @__PURE__ */ e("strong", { children: "不能" }),
          "通过旋转、平移完全重叠。"
        ] }),
        /* @__PURE__ */ r("li", { children: [
          "根本原因：分子",
          /* @__PURE__ */ e("strong", { children: "缺乏对称面（σ）和对称中心（i）" }),
          "。四个基团全不同的碳为手性中心。"
        ] }),
        /* @__PURE__ */ r("li", { children: [
          "一旦出现",
          /* @__PURE__ */ e("strong", { children: "两个相同基团" }),
          "（如 a、d 同为 —H），分子产生对称面，镜像即可重叠，变为非手性。"
        ] })
      ] })
    ] })
  ] });
}
const S = u(N);
export {
  S as default
};
