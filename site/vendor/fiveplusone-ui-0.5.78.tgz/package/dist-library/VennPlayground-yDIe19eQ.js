import { jsxs as o, jsx as e, Fragment as j } from "react/jsx-runtime";
import { useState as w, useId as E, useCallback as K, memo as L } from "react";
import { Sliders as Y, GitMerge as q } from "lucide-react";
const J = {
  union: ["a", "b", "ab"],
  intersection: ["ab"],
  difference: ["a"],
  complement: ["out"],
  "symmetric-difference": ["a", "b"]
}, m = 280, v = 180, a = 95, l = 60;
function Q(i, s, c) {
  const r = Math.min(c, Math.min(i, s)), y = i + s - r, u = i - r, g = s - r, d = Math.max(0, 1 - y);
  return {
    a: i,
    b: s,
    ab: r,
    union: Number(y.toFixed(3)),
    onlyA: Number(u.toFixed(3)),
    onlyB: Number(g.toFixed(3)),
    neither: Number(d.toFixed(3))
  };
}
function U(i, s, c) {
  const r = Math.min(i, s), y = r > 0 ? Math.min(1, c / r) : 0, u = l * 1.6, g = l * 0.35, d = u - y * (u - g);
  return [m / 2 - d / 2, m / 2 + d / 2];
}
const M = (i) => Number(i.toFixed(2)), X = ({
  a: i = 0.6,
  b: s = 0.5,
  ab: c = 0.2,
  interactive: r = !1,
  onChange: y,
  highlightMode: u,
  highlightRegions: g
}) => {
  const [d, $] = w(i), [k, z] = w(s), [B, N] = w(Math.min(c, Math.min(i, s))), O = g || (u ? J[u] : null), A = (h) => !!O && O.includes(h), F = E().replace(/[:]/g, ""), C = `venn-${F}-only-a`, T = `venn-${F}-only-b`, D = `venn-${F}-ab`, G = `venn-${F}-out`, W = K(
    (h, n, t) => {
      y?.(M(h), M(n), M(t));
    },
    [y]
  ), H = (h) => {
    const n = h;
    let t = B, x = k;
    t > n && (t = n), n + x - t > 1 && (x = Math.max(t, Number((1 - n + t).toFixed(2)))), $(n), N(t), z(x), W(n, x, t);
  }, R = (h) => {
    const n = h;
    let t = B, x = d;
    t > n && (t = n), x + n - t > 1 && (x = Math.max(t, Number((1 - n + t).toFixed(2)))), z(n), N(t), $(x), W(x, n, t);
  }, I = (h) => {
    const n = Math.min(d, k), t = Math.min(h, n);
    N(t), W(d, k, t);
  }, f = Q(d, k, B), [b, p] = U(d, k, B), _ = {
    fontSize: "11px",
    fill: "var(--md-sys-color-on-surface-variant)"
  }, S = {
    fontSize: "11px",
    fontWeight: 600,
    fill: "var(--md-sys-color-on-surface)"
  };
  return /* @__PURE__ */ o(
    "div",
    {
      style: {
        padding: "0.85rem",
        borderRadius: "10px",
        border: "1px solid var(--md-sys-color-outline-variant)",
        background: "var(--md-sys-color-surface-container-high)"
      },
      children: [
        /* @__PURE__ */ o(
          "div",
          {
            style: {
              display: "flex",
              alignItems: "center",
              gap: "0.4rem",
              paddingBottom: "0.5rem",
              marginBottom: "0.5rem",
              borderBottom: "1px solid var(--md-sys-color-outline-variant)"
            },
            children: [
              r ? /* @__PURE__ */ e(Y, { size: 15, style: { color: "var(--md-sys-color-primary)" } }) : /* @__PURE__ */ e(
                q,
                {
                  size: 15,
                  style: { color: "var(--md-sys-color-primary)" }
                }
              ),
              /* @__PURE__ */ e(
                "span",
                {
                  style: {
                    fontWeight: 600,
                    fontSize: "0.82rem",
                    color: "var(--md-sys-color-on-surface)"
                  },
                  children: r ? "事件概率调节" : "维恩图"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ o(
          "svg",
          {
            viewBox: `0 0 ${m} ${v}`,
            style: {
              width: "100%",
              maxWidth: "320px",
              display: "block",
              margin: "0 auto"
            },
            children: [
              /* @__PURE__ */ e(
                "rect",
                {
                  x: "6",
                  y: "6",
                  width: m - 12,
                  height: v - 12,
                  rx: "8",
                  fill: "none",
                  stroke: "var(--md-sys-color-outline-variant)",
                  strokeDasharray: "4 2"
                }
              ),
              /* @__PURE__ */ e("text", { x: "12", y: "20", style: _, children: "Ω" }),
              /* @__PURE__ */ e(
                "circle",
                {
                  cx: b,
                  cy: a,
                  r: l,
                  fill: "var(--md-sys-color-primary)",
                  fillOpacity: "0.22",
                  stroke: "var(--md-sys-color-primary)",
                  strokeWidth: "1.5"
                }
              ),
              /* @__PURE__ */ e(
                "circle",
                {
                  cx: p,
                  cy: a,
                  r: l,
                  fill: "var(--md-sys-color-tertiary)",
                  fillOpacity: "0.22",
                  stroke: "var(--md-sys-color-tertiary)",
                  strokeWidth: "1.5"
                }
              ),
              O && /* @__PURE__ */ o(j, { children: [
                /* @__PURE__ */ o("defs", { children: [
                  /* @__PURE__ */ o("mask", { id: C, children: [
                    /* @__PURE__ */ e("rect", { x: "0", y: "0", width: m, height: v, fill: "white" }),
                    /* @__PURE__ */ e("circle", { cx: p, cy: a, r: l, fill: "black" })
                  ] }),
                  /* @__PURE__ */ o("mask", { id: T, children: [
                    /* @__PURE__ */ e("rect", { x: "0", y: "0", width: m, height: v, fill: "white" }),
                    /* @__PURE__ */ e("circle", { cx: b, cy: a, r: l, fill: "black" })
                  ] }),
                  /* @__PURE__ */ o("mask", { id: D, children: [
                    /* @__PURE__ */ e("rect", { x: "0", y: "0", width: m, height: v, fill: "black" }),
                    /* @__PURE__ */ e("circle", { cx: b, cy: a, r: l, fill: "white" })
                  ] }),
                  /* @__PURE__ */ o("mask", { id: G, children: [
                    /* @__PURE__ */ e("rect", { x: "0", y: "0", width: m, height: v, fill: "white" }),
                    /* @__PURE__ */ e("circle", { cx: b, cy: a, r: l, fill: "black" }),
                    /* @__PURE__ */ e("circle", { cx: p, cy: a, r: l, fill: "black" })
                  ] })
                ] }),
                A("out") && /* @__PURE__ */ e(
                  "rect",
                  {
                    x: "6",
                    y: "6",
                    width: m - 12,
                    height: v - 12,
                    rx: "8",
                    fill: "var(--md-sys-color-primary)",
                    fillOpacity: "0.42",
                    mask: `url(#${G})`
                  }
                ),
                A("a") && /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: b,
                    cy: a,
                    r: l,
                    fill: "var(--md-sys-color-primary)",
                    fillOpacity: "0.5",
                    mask: `url(#${C})`
                  }
                ),
                A("b") && /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: p,
                    cy: a,
                    r: l,
                    fill: "var(--md-sys-color-primary)",
                    fillOpacity: "0.5",
                    mask: `url(#${T})`
                  }
                ),
                A("ab") && /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: p,
                    cy: a,
                    r: l,
                    fill: "var(--md-sys-color-primary)",
                    fillOpacity: "0.6",
                    mask: `url(#${D})`
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: b - l * 0.55,
                  y: a - l * 0.45,
                  style: {
                    fontSize: "13px",
                    fontWeight: 700,
                    fill: "var(--md-sys-color-primary)"
                  },
                  children: "A"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: p + l * 0.4,
                  y: a - l * 0.45,
                  style: {
                    fontSize: "13px",
                    fontWeight: 700,
                    fill: "var(--md-sys-color-tertiary)"
                  },
                  children: "B"
                }
              ),
              /* @__PURE__ */ e("text", { x: b - l * 0.3, y: a + 4, style: S, children: f.onlyA.toFixed(2) }),
              /* @__PURE__ */ e("text", { x: (b + p) / 2 - 8, y: a + 4, style: S, children: f.ab.toFixed(2) }),
              /* @__PURE__ */ e("text", { x: p + l * 0.15, y: a + 4, style: S, children: f.onlyB.toFixed(2) }),
              /* @__PURE__ */ e("text", { x: m - 36, y: a + 4, style: S, children: f.neither.toFixed(2) })
            ]
          }
        ),
        /* @__PURE__ */ o(
          "div",
          {
            style: {
              marginTop: "0.5rem",
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "0.35rem 0.75rem",
              fontSize: "0.74rem",
              color: "var(--md-sys-color-on-surface-variant)"
            },
            children: [
              /* @__PURE__ */ o("div", { children: [
                "P(A) =",
                " ",
                /* @__PURE__ */ e(
                  "span",
                  {
                    style: { color: "var(--md-sys-color-primary)", fontWeight: 600 },
                    children: f.a.toFixed(2)
                  }
                )
              ] }),
              /* @__PURE__ */ o("div", { children: [
                "P(B) =",
                " ",
                /* @__PURE__ */ e(
                  "span",
                  {
                    style: { color: "var(--md-sys-color-tertiary)", fontWeight: 600 },
                    children: f.b.toFixed(2)
                  }
                )
              ] }),
              /* @__PURE__ */ o("div", { children: [
                "P(A∩B) =",
                " ",
                /* @__PURE__ */ e(
                  "span",
                  {
                    style: { fontWeight: 600, color: "var(--md-sys-color-on-surface)" },
                    children: f.ab.toFixed(2)
                  }
                )
              ] }),
              /* @__PURE__ */ o("div", { children: [
                "P(A∪B) =",
                " ",
                /* @__PURE__ */ e(
                  "span",
                  {
                    style: { fontWeight: 600, color: "var(--md-sys-color-on-surface)" },
                    children: f.union.toFixed(2)
                  }
                )
              ] })
            ]
          }
        ),
        r && /* @__PURE__ */ o(
          "div",
          {
            style: {
              marginTop: "0.6rem",
              paddingTop: "0.6rem",
              borderTop: "1px solid var(--md-sys-color-outline-variant)",
              display: "flex",
              flexDirection: "column",
              gap: "0.45rem",
              fontSize: "0.78rem"
            },
            children: [
              /* @__PURE__ */ e(
                P,
                {
                  label: "P(A)",
                  value: d,
                  color: "var(--md-sys-color-primary)",
                  onChange: H
                }
              ),
              /* @__PURE__ */ e(
                P,
                {
                  label: "P(B)",
                  value: k,
                  color: "var(--md-sys-color-tertiary)",
                  onChange: R
                }
              ),
              /* @__PURE__ */ e(
                P,
                {
                  label: "P(A∩B)",
                  value: B,
                  color: "var(--md-sys-color-secondary)",
                  onChange: I
                }
              )
            ]
          }
        )
      ]
    }
  );
}, P = ({ label: i, value: s, color: c, onChange: r }) => /* @__PURE__ */ o("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem" }, children: [
  /* @__PURE__ */ o(
    "span",
    {
      style: {
        width: "64px",
        color: "var(--md-sys-color-on-surface-variant)",
        flexShrink: 0
      },
      children: [
        i,
        " = ",
        s.toFixed(2)
      ]
    }
  ),
  /* @__PURE__ */ e(
    "input",
    {
      type: "range",
      min: "0",
      max: "1",
      step: "0.01",
      value: s,
      onChange: (y) => r(Number(y.target.value)),
      style: { flex: 1, accentColor: c }
    }
  )
] }), V = [
  {
    key: "A",
    label: "A",
    regions: ["a", "ab"],
    note: "事件 A 发生的所有样本点。"
  },
  {
    key: "B",
    label: "B",
    regions: ["b", "ab"],
    note: "事件 B 发生的所有样本点。"
  },
  {
    key: "union",
    label: "A ∪ B",
    regions: ["a", "b", "ab"],
    note: "和事件：A 与 B 至少一个发生。"
  },
  {
    key: "inter",
    label: "A ∩ B",
    regions: ["ab"],
    note: "积事件：A 与 B 同时发生。"
  },
  {
    key: "amb",
    label: "A − B",
    regions: ["a"],
    note: "差事件：A 发生且 B 不发生。"
  },
  {
    key: "bma",
    label: "B − A",
    regions: ["b"],
    note: "差事件：B 发生且 A 不发生。"
  },
  {
    key: "acomp",
    label: "Aᶜ",
    regions: ["b", "out"],
    note: "对立事件：A 不发生。"
  },
  {
    key: "sym",
    label: "A △ B",
    regions: ["a", "b"],
    note: "对称差：恰好一个发生（异或）。"
  },
  {
    key: "demorgan",
    label: "(A ∪ B)ᶜ",
    regions: ["out"],
    note: "德摩根律：(A∪B)ᶜ = Aᶜ ∩ Bᶜ，两者都不发生。"
  }
];
function Z() {
  const [i, s] = w("inter"), c = V.find((r) => r.key === i);
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e(X, { interactive: !0, highlightRegions: c.regions }),
    /* @__PURE__ */ e("div", { className: "mt-3 flex flex-wrap gap-1.5", children: V.map((r) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        onClick: () => s(r.key),
        className: "rounded-lg px-2.5 py-1 text-[13px] font-medium transition-colors " + (r.key === i ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
        children: r.label
      },
      r.key
    )) }),
    /* @__PURE__ */ o("p", { className: "mt-3 rounded-lg bg-[var(--bg-muted)] px-3 py-2 text-[13px] leading-relaxed text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: c.label }),
      " —",
      " ",
      c.note
    ] })
  ] });
}
const oe = L(Z);
export {
  oe as default
};
