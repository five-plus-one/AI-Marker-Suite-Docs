import { type ReactNode } from 'react';
import './management-workspace.css';
export interface ManagementItem {
    id: string;
    label: string;
    icon?: ReactNode;
    description?: string;
}
export interface ManagementWorkspaceProps {
    brand: ReactNode;
    headerActions?: ReactNode;
    items: ManagementItem[];
    value: string;
    onChange: (id: string) => void;
    onReturn: () => void;
    identity?: ReactNode;
    children: ReactNode;
}
export declare function ManagementWorkspace({ brand, headerActions, items, value, onChange, onReturn, identity, children }: ManagementWorkspaceProps): import("react").JSX.Element;
export declare function ManagementForm({ title, description, items, value, onChange, actions, status, children }: {
    title: string;
    description?: string;
    items: {
        value: string;
        label: string;
    }[];
    value: string;
    onChange: (id: string) => void;
    actions: ReactNode;
    status?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
