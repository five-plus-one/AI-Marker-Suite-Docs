import { type ReactNode } from "react";
export interface DirectoryUser {
    sub: string;
    name: string;
    email?: string;
    disabled?: boolean;
}
export interface DirectoryGroup {
    id: string;
    name: string;
    description: string;
    members: string[];
}
export interface DirectoryWorkspaceProps {
    users: DirectoryUser[];
    groups: DirectoryGroup[];
    protectedUserIds?: string[];
    onSaveUser: (user: DirectoryUser) => Promise<void> | void;
    onSaveGroup: (group: DirectoryGroup) => Promise<void> | void;
    onDeleteGroup: (id: string) => Promise<void> | void;
    renderUserDetails?: (user: DirectoryUser, close: () => void) => ReactNode;
    onRefresh?: () => Promise<void> | void;
    loading?: boolean;
    error?: string;
}
export declare function DirectoryWorkspace({ users, groups, protectedUserIds, onSaveUser, onSaveGroup, onDeleteGroup, renderUserDetails, onRefresh, loading, error, }: DirectoryWorkspaceProps): import("react").JSX.Element;
export declare function GroupEditor({ group, users, onSave, onDelete, onClose, }: {
    group: DirectoryGroup;
    users: DirectoryUser[];
    onSave: (group: DirectoryGroup) => Promise<void> | void;
    onDelete?: (id: string) => Promise<void> | void;
    onClose: () => void;
}): import("react").JSX.Element;
export declare function UserProfileEditor({ user, existing, protectedUser, onSave, emailEditable, onClose, }: {
    user: DirectoryUser;
    existing?: boolean;
    protectedUser?: boolean;
    onSave: (user: DirectoryUser) => Promise<void> | void;
    onClose?: () => void;
    emailEditable?: boolean;
}): import("react").JSX.Element;
export declare function CapacityEditor({ usedBytes, capacityBytes, onSave, }: {
    usedBytes: number;
    capacityBytes: number;
    onSave: (gigabytes: number, expectedBytes: number) => Promise<void> | void;
}): import("react").JSX.Element;
export declare function AdministratorAccess({ name, enabled, protectedUser, onSave, }: {
    name: string;
    enabled: boolean;
    protectedUser?: boolean;
    onSave: (enabled: boolean) => Promise<void> | void;
}): import("react").JSX.Element;
