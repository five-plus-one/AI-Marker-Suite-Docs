import { jsxs as s, jsx as t } from "react/jsx-runtime";
import { learningAlpha as G } from "./index.js";
import { memo as V, useState as S, useCallback as W } from "react";
const N = "var(--fp-primary)", U = "var(--fp-primary-soft)", B = "#ea580c", z = "#0f766e", O = "var(--line)", J = "var(--bg-muted)", K = 320, q = 200, k = 38, Q = 12, g = 14, Z = 30, A = K - k - Q, v = q - g - Z;
function ee() {
  let e = 0, n = 0;
  for (; e === 0; ) e = Math.random();
  for (; n === 0; ) n = Math.random();
  return Math.sqrt(-2 * Math.log(e)) * Math.cos(2 * Math.PI * n);
}
const P = {
  normal: {
    label: "标准正态 N(0,1)",
    shortLabel: "N(0,1)",
    sample: () => ee(),
    pdf: (e) => Math.exp(-e * e / 2) / Math.sqrt(2 * Math.PI),
    xMin: -3.5,
    xMax: 3.5,
    color: N
  },
  uniform: {
    label: "均匀 U(0,1)",
    shortLabel: "U(0,1)",
    sample: () => Math.random(),
    pdf: (e) => e >= 0 && e <= 1 ? 1 : 0,
    xMin: -0.2,
    xMax: 1.2,
    color: z
  },
  exponential: {
    label: "指数 Exp(1)",
    shortLabel: "Exp(1)",
    sample: () => -Math.log(1 - Math.random()),
    pdf: (e) => e >= 0 ? Math.exp(-e) : 0,
    xMin: -0.2,
    xMax: 4.5,
    color: B
  }
};
function T(e) {
  return Math.exp(-e * e / 2) / Math.sqrt(2 * Math.PI);
}
const I = {
  square: {
    label: "Y = X²",
    shortLabel: "X²",
    apply: (e) => e * e,
    theoreticalPdf: (e, n) => {
      if (e <= 0) return 0;
      if (n === "normal") {
        const r = Math.sqrt(e);
        return (T(r) + T(-r)) / (2 * r);
      }
      return n === "uniform" ? e > 1 ? 0 : 1 / (2 * Math.sqrt(e)) : n === "exponential" ? Math.exp(-Math.sqrt(e)) / (2 * Math.sqrt(e)) : 0;
    },
    yMin: (e) => 0,
    yMax: (e) => e === "normal" ? 9 : e === "uniform" ? 1.05 : 16,
    note: "折叠效应：±x 都映射到同一个 y=x²，PDF 是 X 两侧贡献之和除以变换斜率。"
  },
  abs: {
    label: "Y = |X|",
    shortLabel: "|X|",
    apply: (e) => Math.abs(e),
    theoreticalPdf: (e, n) => e < 0 ? 0 : n === "normal" ? 2 * T(e) : n === "uniform" ? e > 1 ? 0 : 1 : n === "exponential" ? Math.exp(-e) : 0,
    yMin: (e) => 0,
    yMax: (e) => e === "normal" ? 3.5 : e === "uniform" ? 1.2 : 4.5,
    note: "绝对值把负半轴「折叠」到正半轴，密度加倍（仅对称分布明显）。"
  },
  linear: {
    label: "Y = 2X + 1",
    shortLabel: "2X+1",
    apply: (e) => 2 * e + 1,
    theoreticalPdf: (e, n) => {
      const r = (e - 1) / 2;
      return P[n].pdf(r) / 2;
    },
    yMin: (e) => e === "normal" ? -6 : 0.8,
    yMax: (e) => e === "normal" ? 8 : e === "uniform" ? 3.2 : 10,
    note: "线性变换 Y=aX+b：PDF 形状不变，水平拉伸 a 倍，纵向压缩 1/a，保证面积=1。"
  },
  exp: {
    label: "Y = eˣ",
    shortLabel: "eˣ",
    apply: (e) => Math.exp(e),
    theoreticalPdf: (e, n) => {
      if (e <= 0) return 0;
      const r = Math.log(e);
      return P[n].pdf(r) / e;
    },
    yMin: (e) => 0,
    yMax: (e) => e === "normal" ? 8 : e === "uniform" ? Math.E + 0.2 : 6,
    note: "指数变换 Y=eˣ：将 X 拉伸到正半轴，产生「对数正态」等分布，右尾变厚。"
  }
};
function C(e, n, r) {
  return k + (e - n) / (r - n) * A;
}
function E(e, n) {
  return g + v - e / n * v;
}
function $(e, n, r = 5) {
  const f = (n - e) / (r - 1), c = [];
  for (let l = 0; l < r; l++)
    c.push(parseFloat((e + f * l).toFixed(2)));
  return c;
}
function te(e, n, r, i, f = 200) {
  const c = [];
  for (let l = 0; l <= f; l++) {
    const u = l / f, d = n + u * (r - n), m = e(d);
    if (!isFinite(m) || isNaN(m)) continue;
    const p = C(d, n, r), x = E(Math.min(m, i * 1.05), i);
    c.push(`${l === 0 ? "M" : "L"}${p.toFixed(1)},${x.toFixed(1)}`);
  }
  return c.join(" ");
}
function ne(e, n, r, i) {
  const f = [], c = (i - r) / n, l = new Array(n).fill(0);
  let u = 0;
  for (const d of e) {
    if (d < r || d > i) continue;
    const m = Math.min(Math.floor((d - r) / c), n - 1);
    l[m]++, u++;
  }
  for (let d = 0; d < n; d++)
    f.push({
      x0: r + d * c,
      x1: r + (d + 1) * c,
      density: u > 0 ? l[d] / (u * c) : 0
    });
  return f;
}
function H({
  title: e,
  xLabel: n,
  pdfFn: r,
  xMin: i,
  xMax: f,
  color: c,
  histBins: l,
  histColor: u = "#94a3b8",
  pdfMaxY: d
}) {
  let m = 0;
  const p = 200;
  for (let a = 0; a <= p; a++) {
    const h = i + a / p * (f - i), M = r(h);
    isFinite(M) && !isNaN(M) && (m = Math.max(m, M));
  }
  if (l)
    for (const a of l) m = Math.max(m, a.density);
  const x = (d ?? m * 1.15) || 1, X = te(r, i, f, x), w = $(i, f, 5), b = $(0, x, 4);
  return /* @__PURE__ */ s("div", { children: [
    /* @__PURE__ */ t("div", { className: "mb-1 text-center text-[11px] font-semibold text-[var(--ink-soft)]", children: e }),
    /* @__PURE__ */ s("svg", { viewBox: `0 0 ${K} ${q}`, className: "w-full", children: [
      /* @__PURE__ */ t(
        "rect",
        {
          x: k,
          y: g,
          width: A,
          height: v,
          fill: J,
          stroke: O
        }
      ),
      b.map((a) => {
        const h = E(a, x);
        return /* @__PURE__ */ s("g", { children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: k,
              y1: h,
              x2: k + A,
              y2: h,
              stroke: O,
              strokeDasharray: "3 2"
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: k - 4,
              y: h + 3,
              fontSize: "9",
              textAnchor: "end",
              fill: "var(--ink-faint)",
              children: a.toFixed(a < 1 ? 1 : 0)
            }
          )
        ] }, a);
      }),
      w.map((a) => {
        const h = C(a, i, f);
        return /* @__PURE__ */ s("g", { children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: h,
              y1: g + v,
              x2: h,
              y2: g + v + 4,
              stroke: "var(--ink-faint)"
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: h,
              y: g + v + 13,
              fontSize: "9",
              textAnchor: "middle",
              fill: "var(--ink-faint)",
              children: Math.abs(a) < 1e-3 ? "0" : a.toFixed(1)
            }
          )
        ] }, a);
      }),
      /* @__PURE__ */ t(
        "text",
        {
          x: k + A / 2,
          y: q - 2,
          fontSize: "10",
          textAnchor: "middle",
          fill: "var(--ink-faint)",
          children: n
        }
      ),
      /* @__PURE__ */ t(
        "text",
        {
          x: 9,
          y: g + v / 2,
          fontSize: "9",
          textAnchor: "middle",
          fill: "var(--ink-faint)",
          transform: `rotate(-90,9,${g + v / 2})`,
          children: "密度"
        }
      ),
      l && l.map((a, h) => {
        const M = C(a.x0, i, f), D = C(a.x1, i, f), L = E(Math.min(a.density, x * 1.05), x), Y = g + v - L;
        return Y <= 0 ? null : /* @__PURE__ */ t(
          "rect",
          {
            x: M + 0.5,
            y: L,
            width: Math.max(D - M - 1, 0),
            height: Y,
            fill: u,
            opacity: 0.45
          },
          h
        );
      }),
      X && /* @__PURE__ */ t("path", { d: X, fill: "none", stroke: c, strokeWidth: "2" })
    ] })
  ] });
}
function j({ active: e, onClick: n, color: r = N, children: i }) {
  return /* @__PURE__ */ t(
    "button",
    {
      type: "button",
      onClick: n,
      className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors",
      style: e ? { background: r, color: "#fff" } : { background: "var(--bg-muted)", color: "var(--ink-soft)" },
      children: i
    }
  );
}
function re() {
  const [e, n] = S("normal"), [r, i] = S("square"), [f, c] = S([]), [l, u] = S(0), [d, m] = S(!1), p = P[e], x = I[r], X = W(() => {
    m(!0);
    const o = 1e4, y = [];
    for (let F = 0; F < o; F++)
      y.push(p.sample());
    c(y), u(o), m(!1);
  }, [p]);
  function w() {
    c([]), u(0);
  }
  const b = f.map(x.apply), a = x.yMin(e), h = x.yMax(e), D = b.length > 0 ? ne(b, 50, a, h) : void 0, L = (o) => x.theoreticalPdf(o, e), Y = p.pdf, _ = b.length > 0 ? b.reduce((o, y) => o + y, 0) / b.length : null, R = b.length > 0 && _ !== null ? b.reduce((o, y) => o + (y - _) ** 2, 0) / b.length : null;
  return /* @__PURE__ */ s("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ s("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "随机变量函数的分布" }),
      /* @__PURE__ */ t("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: "选择 X 的分布和变换 g，左图为 X 的 PDF，右图为 Y=g(X) 的理论曲线与模拟直方图叠加。" })
    ] }),
    /* @__PURE__ */ s("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ s("div", { children: [
        /* @__PURE__ */ t("div", { className: "mb-1.5 text-[12px] font-semibold text-[var(--ink)]", children: "X 的分布" }),
        /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-1.5", children: Object.keys(P).map((o) => /* @__PURE__ */ t(
          j,
          {
            active: e === o,
            onClick: () => {
              n(o), c([]), u(0);
            },
            color: P[o].color,
            children: P[o].shortLabel
          },
          o
        )) })
      ] }),
      /* @__PURE__ */ s("div", { children: [
        /* @__PURE__ */ t("div", { className: "mb-1.5 text-[12px] font-semibold text-[var(--ink)]", children: "变换 Y = g(X)" }),
        /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-1.5", children: Object.keys(I).map((o) => /* @__PURE__ */ t(
          j,
          {
            active: r === o,
            onClick: () => {
              i(o), c([]), u(0);
            },
            children: I[o].label
          },
          o
        )) })
      ] })
    ] }),
    /* @__PURE__ */ s("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] p-2", children: /* @__PURE__ */ t(
        H,
        {
          title: `X ~ ${p.label}`,
          xLabel: "x",
          pdfFn: Y,
          xMin: p.xMin,
          xMax: p.xMax,
          color: p.color
        }
      ) }),
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] p-2", children: /* @__PURE__ */ t(
        H,
        {
          title: `Y = ${x.label} 的分布`,
          xLabel: "y",
          pdfFn: L,
          xMin: a,
          xMax: h,
          color: N,
          histBins: D,
          histColor: "#6366f1"
        }
      ) })
    ] }),
    /* @__PURE__ */ s(
      "div",
      {
        className: "rounded-lg border px-3 py-2.5 text-[12px] leading-relaxed",
        style: {
          borderColor: G(N, "44"),
          background: U
        },
        children: [
          /* @__PURE__ */ t("span", { className: "font-semibold", style: { color: N }, children: "变换原理：" }),
          /* @__PURE__ */ s("span", { className: "text-[var(--ink-soft)]", children: [
            " ",
            x.note
          ] })
        ]
      }
    ),
    /* @__PURE__ */ s("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: X,
          disabled: d,
          className: "rounded-lg px-4 py-1.5 text-[13px] font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50",
          style: { background: N },
          children: d ? "模拟中…" : "模拟 10000 次"
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: w,
          className: "rounded-lg bg-[var(--bg-muted)] px-3 py-1.5 text-[13px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)]",
          children: "清除"
        }
      ),
      l > 0 && /* @__PURE__ */ s("span", { className: "text-[12px] text-[var(--ink-soft)]", children: [
        "已采样",
        " ",
        /* @__PURE__ */ t("b", { className: "text-[var(--ink)]", children: l.toLocaleString() }),
        " ",
        "个点"
      ] })
    ] }),
    l > 0 && _ !== null && R !== null && /* @__PURE__ */ t("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      { label: "X 分布", val: p.shortLabel, color: p.color },
      { label: "变换 g", val: x.shortLabel, color: N },
      {
        label: "Y 均值（模拟）",
        val: _.toFixed(4),
        color: z
      },
      {
        label: "Y 方差（模拟）",
        val: R.toFixed(4),
        color: B
      }
    ].map(({ label: o, val: y, color: F }) => /* @__PURE__ */ s(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: { background: G(F, "18") },
        children: [
          /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: o }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "mt-0.5 font-mono text-[14px] font-bold",
              style: { color: F },
              children: y
            }
          )
        ]
      },
      o
    )) }),
    /* @__PURE__ */ s("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
      /* @__PURE__ */ t("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "变量变换公式（连续情形）" }),
      /* @__PURE__ */ t("div", { className: "font-mono text-[11px] leading-loose", children: "若 Y = g(X)，g 严格单调，则：" }),
      /* @__PURE__ */ t("div", { className: "font-mono text-[11px] leading-loose", children: "f_Y(y) = f_X(g⁻¹(y)) · |d/dy g⁻¹(y)|" }),
      /* @__PURE__ */ t("div", { className: "font-mono text-[11px] leading-loose", children: "非单调时（如 Y=X²）：对每个反函数分支分别求和。" })
    ] }),
    /* @__PURE__ */ s("div", { className: "flex flex-wrap gap-4 text-[11px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ s("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "div",
          {
            className: "h-[3px] w-6 rounded-full",
            style: { background: N }
          }
        ),
        /* @__PURE__ */ t("span", { children: "理论 PDF 曲线" })
      ] }),
      /* @__PURE__ */ s("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "div",
          {
            className: "h-4 w-4 rounded-sm opacity-50",
            style: { background: "#6366f1" }
          }
        ),
        /* @__PURE__ */ t("span", { children: "模拟频率直方图（10000次）" })
      ] })
    ] })
  ] });
}
const se = V(re);
export {
  se as default
};
