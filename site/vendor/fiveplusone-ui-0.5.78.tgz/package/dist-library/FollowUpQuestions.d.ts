export declare function FollowUpQuestions({ questions, onSelect, sourceCount, onOpenSources, title, }: {
    questions: string[];
    onSelect: (question: string) => void;
    sourceCount?: number;
    onOpenSources?: () => void;
    title?: string;
}): import("react").JSX.Element;
