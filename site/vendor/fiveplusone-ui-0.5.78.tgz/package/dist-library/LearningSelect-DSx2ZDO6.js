import { jsx as n } from "react/jsx-runtime";
import { useState as L, Children as C, isValidElement as E } from "react";
import { SelectField as j } from "./index.js";
function T({
  children: s,
  value: a,
  defaultValue: p,
  onChange: i,
  "aria-label": c,
  title: u,
  disabled: f,
  className: g,
  style: m,
  id: v
}) {
  const [S, b] = L(String(p ?? "")), t = [], l = (r, o) => C.forEach(r, (e) => {
    E(e) && (e.type === "option" ? t.push({
      value: String(e.props.value ?? e.props.children ?? ""),
      label: String(e.props.children ?? e.props.value ?? ""),
      disabled: e.props.disabled,
      group: o
    }) : l(e.props.children, e.props.label || o));
  });
  l(s);
  const d = a === void 0 ? S || t[0]?.value || "" : String(a);
  return /* @__PURE__ */ n(
    "span",
    {
      id: v,
      className: `fp-learning-select ${g || ""}`,
      style: m,
      children: /* @__PURE__ */ n(
        j,
        {
          label: c || u || "选择实验条件",
          value: d,
          disabled: f,
          options: t,
          onChange: (r) => {
            b(r), i?.({
              target: { value: r },
              currentTarget: { value: r }
            });
          }
        }
      )
    }
  );
}
export {
  T as L
};
