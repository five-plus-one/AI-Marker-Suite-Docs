import { type InputHTMLAttributes, type RefAttributes } from 'react';
type StyledInputProps = InputHTMLAttributes<HTMLInputElement> & RefAttributes<HTMLInputElement> & {
    wrapperClassName?: string;
};
export declare function DatePicker({ className, wrapperClassName, ...props }: StyledInputProps): import("react").JSX.Element;
export declare function TimePicker({ className, wrapperClassName, ...props }: StyledInputProps): import("react").JSX.Element;
export declare function ColorPicker({ label, value, onChange, disabled }: {
    label: string;
    value: string;
    onChange: (value: string) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
export {};
