const {contextBridge,ipcRenderer}=require('electron');
const read=name=>process.argv.find(value=>value.startsWith(name))?.slice(name.length);
const channel=read('--fp-auth-channel='),shell=read('--fp-auth-shell=');
if(process.isMainFrame&&channel&&shell&&location.protocol==='file:'&&location.href===decodeURIComponent(shell)){
 contextBridge.exposeInMainWorld('authWindow',{
  close:()=>ipcRenderer.send(channel,'close'),continueBrowser:()=>ipcRenderer.send(channel,'browser'),reload:()=>ipcRenderer.send(channel,'reload'),
  onTheme:callback=>{const listener=(_event,theme)=>{if(theme==='dark'||theme==='light')callback(theme);};ipcRenderer.on(channel+':theme',listener);return()=>ipcRenderer.removeListener(channel+':theme',listener);},
  onBrowserState:callback=>{const listener=(_event,waiting)=>{if(typeof waiting==='boolean')callback(waiting);};ipcRenderer.on(channel+':browser',listener);return()=>ipcRenderer.removeListener(channel+':browser',listener);},
 });
}
