'use strict';

const escapeXML = value => String(value).replace(/[<>&"']/g, character => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[character]));

/** Native OS presentation only. The host verifies ownership, lifetime and consent. */
function createAuthorizationNotifications({Notification, title, body, toProtocol, onActivate, onChange = () => {}, onError = () => {}, now = Date.now}) {
  const pending = new Map(), seen = new Map(), notifications = new Map();
  let disposed = false, visibleRequest;
  function remove(id) {
    pending.delete(id);
    const notification = notifications.get(id);
    notifications.delete(id);
    notification?.close();
  }
  function prune() {
    for (const [id, item] of pending) if (item.expiresAt * 1000 <= now()) remove(id);
    for (const [id, expires] of seen) if (expires * 1000 <= now()) seen.delete(id);
  }
  function activate(id) {
    prune();
    const item = pending.get(id);
    if (!disposed && item) Promise.resolve().then(() => onActivate(item)).catch(onError);
  }
  function notify(item) {
    if (disposed || !item || typeof item.id !== 'string' || !Number.isFinite(item.expiresAt) || item.expiresAt * 1000 <= now()) return;
    prune();
    if (!pending.has(item.id) && pending.size >= 100) return;
    pending.set(item.id, {...item});
    onChange();
    if (item.id === visibleRequest) { seen.set(item.id, item.expiresAt); return; }
    if (seen.has(item.id)) return;
    seen.set(item.id, item.expiresAt);
    try {
      if (!Notification.isSupported()) return;
      const protocol = toProtocol(item);
      const link = new URL(protocol);
      if (link.protocol === 'http:' || link.protocol === 'https:' || link.protocol === 'file:' || !link.hostname || link.username || link.password) throw Error('Expected an application protocol link');
      const notification = new Notification({title, body, silent: false, toastXml: `<toast activationType="protocol" launch="${escapeXML(protocol)}"><visual><binding template="ToastGeneric"><text>${escapeXML(title)}</text><text>${escapeXML(body)}</text></binding></visual></toast>`});
      notifications.set(item.id, notification);
      notification.on('click', () => activate(item.id));
      notification.on('failed', (_event, error) => onError(error || Error('Native notification unavailable')));
      notification.show();
    } catch (error) { onError(error); }
  }
  return {
    notify,
    reconcile(items) {
      if (disposed) return;
      const current = new Set(items.map(item => item.id));
      for (const id of pending.keys()) if (!current.has(id)) remove(id);
      for (const item of items) notify(item);
      prune(); onChange();
    },
    setVisibleRequest(id) {
      visibleRequest = id;
      const notification = notifications.get(id);
      notifications.delete(id);
      notification?.close();
      const item = pending.get(id);
      if (item) seen.set(id, item.expiresAt);
    },
    pending() { prune(); return [...pending.values()].map(item => ({...item})); },
    open: activate,
    clear() { visibleRequest=undefined;for (const id of pending.keys()) remove(id); seen.clear(); onChange(); },
    dispose() { disposed = true; this.clear(); },
  };
}
module.exports = {createAuthorizationNotifications};
