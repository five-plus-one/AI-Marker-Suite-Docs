/** 笔记内容块 - 从课栈 shared/directives 提取
 *
 * KeyPoint / ConceptCard / CompareTable / CauseEffect / Derivation
 * 都是正文中的语义块。它们共享容器与折叠逻辑，这里合并在一个模块，
 * 避免为每种块重复实现一份展开/收起。
 */
import { type ReactNode } from "react";
export interface KeyPointProps {
    label?: string;
    children: ReactNode;
}
export declare function KeyPoint({ label, children }: KeyPointProps): import("react").JSX.Element;
export interface ConceptCardProps {
    term: string;
    children: ReactNode;
    defaultOpen?: boolean;
}
export declare function ConceptCard({ term, children, defaultOpen, }: ConceptCardProps): import("react").JSX.Element;
export interface CompareTableProps {
    title?: string;
    children: ReactNode;
}
export declare function CompareTable({ title, children }: CompareTableProps): import("react").JSX.Element;
export type CauseEffectKind = "cause" | "effect" | "result";
export interface CauseEffectItem {
    kind?: CauseEffectKind;
    text: ReactNode;
}
export interface CauseEffectProps {
    /** 简洁写法：按顺序排列的链条 */
    items?: CauseEffectItem[];
    /** 段落写法：每行以「因：」「影响：」「结果：」开头 */
    text?: string;
    children?: ReactNode;
}
export declare function CauseEffect({ items, text, children }: CauseEffectProps): import("react").JSX.Element;
export interface DerivationProps {
    label?: string;
    children: ReactNode;
    defaultOpen?: boolean;
}
export declare function Derivation({ label, children, defaultOpen, }: DerivationProps): import("react").JSX.Element;
