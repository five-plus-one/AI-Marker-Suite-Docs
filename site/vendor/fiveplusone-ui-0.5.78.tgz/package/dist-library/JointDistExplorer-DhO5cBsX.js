import { jsxs as a, jsx as t } from "react/jsx-runtime";
import { learningAlpha as G } from "./index.js";
import { memo as Q, useState as L } from "react";
const g = "var(--fp-primary)", _ = "var(--fp-primary-soft)", T = "var(--fp-primary)";
function I(i) {
  return `color-mix(in srgb, var(--fp-primary) ${Math.round(12 + Math.max(0, Math.min(1, i)) * 88)}%, var(--fp-surface))`;
}
const F = [
  [0.1, 0.08, 0.06],
  [0.12, 0.18, 0.1],
  [0.08, 0.14, 0.14]
], W = ["x₁", "x₂", "x₃"], z = ["y₁", "y₂", "y₃"];
function U(i) {
  let c = 0;
  for (const l of i) for (const f of l) c += Math.max(0, f);
  return c === 0 ? i.map((l) => l.map(() => 1 / 9)) : i.map((l) => l.map((f) => Math.max(0, f) / c));
}
function Z(i) {
  return i.map((c) => c.reduce((l, f) => l + f, 0));
}
function j(i) {
  const c = i[0].length;
  return Array.from(
    { length: c },
    (l, f) => i.reduce((E, y) => E + y[f], 0)
  );
}
function $(i) {
  return i.toFixed(4);
}
function tt() {
  return Array.from(
    { length: 3 },
    () => Array.from({ length: 3 }, () => Math.random())
  );
}
const H = {
  uniform: {
    label: "均匀分布",
    raw: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1]
    ]
  },
  diag: {
    label: "对角线（X=Y 相关）",
    raw: [
      [9, 1, 0],
      [1, 9, 1],
      [0, 1, 9]
    ]
  },
  corner: {
    label: "角落集中",
    raw: [
      [8, 1, 1],
      [1, 1, 1],
      [1, 1, 6]
    ]
  },
  custom: { label: "自定义", raw: null }
};
function et() {
  const [i, c] = L(F), [l, f] = L(null), [E, y] = L("custom"), [N, k] = L(""), [d, o] = L(null), s = U(i), m = Z(s), x = j(s), S = Math.max(...s.flatMap((n) => n));
  function M(n, r, C) {
    k(C), o([n, r]);
    const w = parseFloat(C);
    if (!isNaN(w) && w >= 0) {
      const X = i.map(
        (Y, q) => Y.map((K, O) => q === n && O === r ? w : K)
      );
      c(X), y("custom");
    }
  }
  function R(n, r) {
    o([n, r]), k(i[n][r].toString());
  }
  function P() {
    o(null), k("");
  }
  function B(n) {
    y(n);
    const r = H[n];
    r.raw && c(r.raw.map((C) => [...C]));
  }
  function D() {
    c(tt()), y("custom");
  }
  function J() {
    c(F.map((n) => [...n])), y("custom");
  }
  const V = l !== null ? {
    i: l[0],
    j: l[1],
    val: s[l[0]][l[1]]
  } : null;
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ a("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "联合分布律探索器" }),
      /* @__PURE__ */ t("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "编辑 3×3 联合概率表，实时查看热力图与边缘分布。悬停格子查看精确概率值。" })
    ] }),
    /* @__PURE__ */ a("div", { className: "flex flex-wrap gap-1.5 items-center", children: [
      /* @__PURE__ */ t("span", { className: "text-[12px] text-[var(--ink-soft)] mr-1", children: "预设：" }),
      ["uniform", "diag", "corner"].map((n) => /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => B(n),
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (E === n ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak,#ede9fe)]"),
          children: H[n].label
        },
        n
      )),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: D,
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak,#ede9fe)] transition-colors",
          children: "随机"
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: J,
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line,#e9ebf2)] transition-colors",
          children: "重置"
        }
      )
    ] }),
    /* @__PURE__ */ a("div", { className: "flex flex-col gap-4 sm:flex-row sm:gap-6", children: [
      /* @__PURE__ */ a("div", { className: "flex-shrink-0", children: [
        /* @__PURE__ */ t("p", { className: "text-[11px] text-[var(--ink-soft)] mb-2", children: "输入任意正数（自动归一化）" }),
        /* @__PURE__ */ a("div", { className: "grid grid-cols-4 gap-1 mb-1", children: [
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)] flex items-end justify-center pb-1", children: "X↓ Y→" }),
          z.map((n) => /* @__PURE__ */ t(
            "div",
            {
              className: "text-center text-[12px] font-semibold text-[var(--ink)]",
              children: n
            },
            n
          ))
        ] }),
        i.map((n, r) => /* @__PURE__ */ a("div", { className: "grid grid-cols-4 gap-1 mb-1", children: [
          /* @__PURE__ */ t("div", { className: "flex items-center justify-center text-[12px] font-semibold text-[var(--ink)]", children: W[r] }),
          n.map((C, w) => {
            const X = d !== null && d[0] === r && d[1] === w;
            return /* @__PURE__ */ t(
              "input",
              {
                type: "number",
                min: "0",
                step: "0.01",
                value: X ? N : C.toFixed(2),
                onChange: (Y) => M(r, w, Y.target.value),
                onFocus: () => R(r, w),
                onBlur: P,
                className: "w-full rounded-md border border-[var(--line)] bg-[var(--bg-muted)] px-1.5 py-1.5 text-center text-[13px] font-mono text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)] transition-colors",
                style: { width: "72px" }
              },
              w
            );
          })
        ] }, r)),
        /* @__PURE__ */ a("div", { className: "mt-2 text-[11px] text-[var(--ink-soft)]", children: [
          "输入合计：",
          /* @__PURE__ */ t("span", { className: "font-mono font-semibold text-[var(--ink)]", children: i.flatMap((n) => n).reduce((n, r) => n + Math.max(0, r), 0).toFixed(4) }),
          "（归一化后 = 1）"
        ] })
      ] }),
      /* @__PURE__ */ t("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ t(
        at,
        {
          p: s,
          pX: m,
          pY: x,
          maxP: S,
          hoveredCell: l,
          setHoveredCell: f,
          hovered: V
        }
      ) })
    ] }),
    /* @__PURE__ */ a("div", { className: "grid grid-cols-2 gap-3", children: [
      /* @__PURE__ */ a("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5", children: [
        /* @__PURE__ */ t("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "X 的边缘分布 P(X=xᵢ)" }),
        /* @__PURE__ */ t("div", { className: "flex gap-2", children: m.map((n, r) => /* @__PURE__ */ a("div", { className: "flex-1 text-center", children: [
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)]", children: W[r] }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "mt-1 rounded-md py-1 text-[13px] font-mono font-bold",
              style: { background: _, color: g },
              children: $(n)
            }
          )
        ] }, r)) })
      ] }),
      /* @__PURE__ */ a("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5", children: [
        /* @__PURE__ */ t("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "Y 的边缘分布 P(Y=yⱼ)" }),
        /* @__PURE__ */ t("div", { className: "flex gap-2", children: x.map((n, r) => /* @__PURE__ */ a("div", { className: "flex-1 text-center", children: [
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)]", children: z[r] }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "mt-1 rounded-md py-1 text-[13px] font-mono font-bold",
              style: { background: _, color: T },
              children: $(n)
            }
          )
        ] }, r)) })
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
      /* @__PURE__ */ a("div", { children: [
        /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "边缘分布公式：" }),
        "  ",
        /* @__PURE__ */ t("span", { className: "font-mono", children: "P(X=xᵢ) = Σⱼ p(xᵢ, yⱼ)" }),
        "，",
        /* @__PURE__ */ t("span", { className: "font-mono", children: "P(Y=yⱼ) = Σᵢ p(xᵢ, yⱼ)" })
      ] }),
      /* @__PURE__ */ a("div", { children: [
        /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "联合分布完备性：" }),
        "  ",
        /* @__PURE__ */ t("span", { className: "font-mono", children: "Σᵢ Σⱼ p(xᵢ, yⱼ) = 1" }),
        "。修改任意格子，边缘分布自动随之更新。"
      ] })
    ] })
  ] });
}
const e = 56, u = 28, v = 20, p = 10, A = 36, b = 46, h = 3, nt = u + h * e + p + b + 4, rt = v + h * e + p + b + 4;
function at({
  p: i,
  pX: c,
  pY: l,
  maxP: f,
  hoveredCell: E,
  setHoveredCell: y,
  hovered: N
}) {
  const k = Math.max(...c, ...l, 0.01);
  return /* @__PURE__ */ a("div", { children: [
    /* @__PURE__ */ t(
      "div",
      {
        className: "mb-2 h-7 rounded-md px-3 flex items-center text-[12px] font-mono",
        style: {
          background: N ? _ : "transparent",
          color: N ? g : "transparent",
          border: N ? `1px solid ${G(g, "40")}` : "1px solid transparent",
          transition: "all 0.15s"
        },
        children: N ? `P(X=${W[N.i]}, Y=${z[N.j]}) = ${$(N.val)}` : "悬停格子查看精确概率"
      }
    ),
    /* @__PURE__ */ a(
      "svg",
      {
        viewBox: `0 0 ${nt} ${rt}`,
        className: "w-full max-w-[320px]",
        style: { userSelect: "none" },
        onMouseLeave: () => y(null),
        children: [
          z.map((d, o) => /* @__PURE__ */ t(
            "text",
            {
              x: u + o * e + e / 2,
              y: v - 5,
              textAnchor: "middle",
              fontSize: "12",
              fontWeight: "600",
              fill: "var(--ink-soft)",
              children: d
            },
            o
          )),
          W.map((d, o) => /* @__PURE__ */ t(
            "text",
            {
              x: u - 5,
              y: v + o * e + e / 2 + 4,
              textAnchor: "end",
              fontSize: "12",
              fontWeight: "600",
              fill: "var(--ink-soft)",
              children: d
            },
            o
          )),
          i.map(
            (d, o) => d.map((s, m) => {
              const x = u + m * e, S = v + o * e, M = f > 0 ? s / f : 0, R = E !== null && E[0] === o && E[1] === m, P = I(M), B = M > 0.55 ? "var(--fp-on-primary)" : g;
              return /* @__PURE__ */ a("g", { children: [
                /* @__PURE__ */ t(
                  "rect",
                  {
                    x: x + 1,
                    y: S + 1,
                    width: e - 2,
                    height: e - 2,
                    rx: "6",
                    fill: P,
                    stroke: R ? g : "transparent",
                    strokeWidth: R ? 2 : 0,
                    style: { cursor: "pointer", transition: "stroke 0.1s" },
                    onMouseEnter: () => y([o, m])
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: x + e / 2,
                    y: S + e / 2 - 3,
                    textAnchor: "middle",
                    fontSize: "11",
                    fontWeight: "700",
                    fill: B,
                    style: { pointerEvents: "none" },
                    children: $(s)
                  }
                ),
                /* @__PURE__ */ t(
                  "rect",
                  {
                    x: x + 6,
                    y: S + e / 2 + 8,
                    width: (e - 12) * M,
                    height: 4,
                    rx: "2",
                    fill: M > 0.55 ? "rgba(255,255,255,0.6)" : `${G(g, "50")}`,
                    style: { pointerEvents: "none" }
                  }
                ),
                /* @__PURE__ */ t(
                  "rect",
                  {
                    x: x + 6,
                    y: S + e / 2 + 8,
                    width: e - 12,
                    height: 4,
                    rx: "2",
                    fill: "none",
                    stroke: M > 0.55 ? "rgba(255,255,255,0.3)" : `${G(g, "30")}`,
                    strokeWidth: "1",
                    style: { pointerEvents: "none" }
                  }
                )
              ] }, `${o}-${m}`);
            })
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: u + h * e + p + b / 2,
              y: v - 5,
              textAnchor: "middle",
              fontSize: "10",
              fill: "var(--ink-faint)",
              children: "P(X)"
            }
          ),
          c.map((d, o) => {
            const s = v + o * e, m = k > 0 ? d / k * A : 0, x = u + h * e + p;
            return /* @__PURE__ */ a("g", { children: [
              /* @__PURE__ */ t(
                "rect",
                {
                  x: x + 2,
                  y: s + (e - 20) / 2,
                  width: A,
                  height: 20,
                  rx: "4",
                  fill: _
                }
              ),
              /* @__PURE__ */ t(
                "rect",
                {
                  x: x + 2,
                  y: s + (e - 20) / 2,
                  width: m,
                  height: 20,
                  rx: "4",
                  fill: g,
                  style: { transition: "width 0.3s" }
                }
              ),
              /* @__PURE__ */ t(
                "text",
                {
                  x: x + A / 2 + 2,
                  y: s + e / 2 + 4,
                  textAnchor: "middle",
                  fontSize: "10",
                  fontWeight: "700",
                  fill: m > A * 0.5 ? "#fff" : g,
                  style: { pointerEvents: "none" },
                  children: $(d)
                }
              )
            ] }, o);
          }),
          /* @__PURE__ */ t(
            "text",
            {
              x: u - 5,
              y: v + h * e + p + b / 2 + 4,
              textAnchor: "end",
              fontSize: "10",
              fill: "var(--ink-faint)",
              children: "P(Y)"
            }
          ),
          l.map((d, o) => {
            const s = u + o * e, m = k > 0 ? d / k * A : 0, x = v + h * e + p;
            return /* @__PURE__ */ a("g", { children: [
              /* @__PURE__ */ t(
                "rect",
                {
                  x: s + (e - 20) / 2,
                  y: x + 2,
                  width: 20,
                  height: A,
                  rx: "4",
                  fill: _
                }
              ),
              /* @__PURE__ */ t(
                "rect",
                {
                  x: s + (e - 20) / 2,
                  y: x + 2,
                  width: 20,
                  height: m,
                  rx: "4",
                  fill: T,
                  style: { transition: "height 0.3s" }
                }
              ),
              /* @__PURE__ */ t(
                "text",
                {
                  x: s + e / 2,
                  y: x + A / 2 + 6,
                  textAnchor: "middle",
                  fontSize: "10",
                  fontWeight: "700",
                  fill: m > A * 0.5 ? "#fff" : T,
                  style: { pointerEvents: "none" },
                  children: $(d)
                }
              )
            ] }, o);
          }),
          /* @__PURE__ */ t(
            "rect",
            {
              x: u + h * e + p + 2,
              y: v + h * e + p + 2,
              width: b - 4,
              height: b - 4,
              rx: "6",
              fill: g
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: u + h * e + p + b / 2,
              y: v + h * e + p + b / 2 - 2,
              textAnchor: "middle",
              fontSize: "9",
              fill: "#fff",
              children: "ΣΣ"
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: u + h * e + p + b / 2,
              y: v + h * e + p + b / 2 + 10,
              textAnchor: "middle",
              fontSize: "11",
              fontWeight: "800",
              fill: "#fff",
              children: "1.00"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ a("div", { className: "mt-2 flex items-center gap-2", children: [
      /* @__PURE__ */ t("span", { className: "text-[10px] text-[var(--ink-soft)]", children: "低" }),
      /* @__PURE__ */ t(
        "div",
        {
          className: "flex-1 h-2.5 rounded-full",
          style: {
            background: `linear-gradient(to right, ${I(0)}, ${I(0.33)}, ${I(0.66)}, ${I(1)})`
          }
        }
      ),
      /* @__PURE__ */ t("span", { className: "text-[10px] text-[var(--ink-soft)]", children: "高" }),
      /* @__PURE__ */ t("span", { className: "text-[10px] text-[var(--ink-soft)] ml-1", children: "概率密度" })
    ] })
  ] });
}
const st = Q(et);
export {
  st as default
};
