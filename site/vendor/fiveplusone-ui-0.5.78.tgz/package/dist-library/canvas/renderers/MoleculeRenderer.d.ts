import type { CanvasBlock, MoleculeCanvasBlock } from "../engines/types";
export declare const MoleculeRenderContext: import("react").Context<((source: string, options: {
    width: number;
    height: number;
    signal: AbortSignal;
}) => Promise<string>) | null>;
export declare function MoleculeRenderer({ block, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: {
    block: MoleculeCanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => Promise<void> | void;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}): import("react").JSX.Element;
