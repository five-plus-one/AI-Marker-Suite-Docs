import { type ReactNode } from "react";
/** A stable portal target preserves the view while moving between inline and full screen. */
export declare function CanvasFullscreenPortal({ open, onExit, children, label, }: {
    open: boolean;
    onExit: () => void;
    children: ReactNode;
    label?: string;
}): import("react").JSX.Element;
