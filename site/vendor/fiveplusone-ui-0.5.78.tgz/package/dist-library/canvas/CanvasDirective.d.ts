interface NodeProps {
    node?: {
        properties?: Record<string, unknown>;
    };
    children?: React.ReactNode;
}
/**
 * Container `:::canvas` directive — wraps multiple `::plot` children
 * in a shared SvgCanvas with unified axes.
 */
export declare function CanvasDirective({ node, children }: NodeProps): import("react").JSX.Element;
export {};
