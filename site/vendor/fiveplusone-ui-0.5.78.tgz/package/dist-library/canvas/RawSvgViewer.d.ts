import type { CanvasBlock } from "./engines/types";
export interface RawSvgViewerProps {
    /** SVG markup, with or without an <svg> root. */
    svg: string;
    title?: string;
    width?: number;
    height?: number;
    sourceSvg?: string;
    topic?: string;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
/**
 * Compatibility wrapper for older call sites that pass raw SVG strings.
 * All rendering, diagnostics, and AI revision UI live in RawSvgRenderer/CanvasFrame.
 */
export declare function RawSvgViewer({ svg, title, width, height, sourceSvg, topic, onRevisionAccepted, }: RawSvgViewerProps): import("react").JSX.Element;
