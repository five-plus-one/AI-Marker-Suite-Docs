export declare function useCanvasFullscreen(): {
    fullscreen: boolean;
    toggle: () => void;
    exit: () => void;
};
