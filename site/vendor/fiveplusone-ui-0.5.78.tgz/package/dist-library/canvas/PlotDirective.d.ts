interface NodeProps {
    node?: {
        properties?: Record<string, unknown>;
    };
    children?: React.ReactNode;
}
/**
 * Standalone `::plot` directive — renders a single function plot
 * wrapped in its own SvgCanvas.
 */
export declare function PlotDirective({ node }: NodeProps): import("react").JSX.Element | null;
export {};
