/**
 * Sanitize AI-generated SVG content to prevent XSS.
 * Optionally adapts hardcoded black/white colors to theme-aware tokens.
 */
export declare function sanitizeSvg(raw: string, themeAdapt?: boolean): string;
