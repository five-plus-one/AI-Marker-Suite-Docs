export type PlotDiagnostic = {
    ok: true;
    normalizedFn: string;
    sampledPoints: number;
} | {
    ok: false;
    reason: 'empty-fn' | 'unsupported-syntax' | 'no-finite-samples' | 'empty-path';
    normalizedFn: string;
    message: string;
};
interface PlotNormalizeOptions {
    mu?: number;
    sigma?: number;
}
interface PlotDiagnoseOptions extends PlotNormalizeOptions {
    xmin?: number;
    xmax?: number;
    samples?: number;
}
export declare function normalizePlotExpression(expr: string, options?: PlotNormalizeOptions): string;
export declare function diagnosePlotExpression(expr: string, options?: PlotDiagnoseOptions): PlotDiagnostic;
export {};
