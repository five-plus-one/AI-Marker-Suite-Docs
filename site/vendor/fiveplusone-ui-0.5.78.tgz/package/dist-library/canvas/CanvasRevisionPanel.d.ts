import type { CanvasBlock } from "./engines/types";
export interface CanvasRevisionPanelProps {
    block?: CanvasBlock;
    topic?: string;
    busy?: boolean;
    error?: string | null;
    onCancel: () => void;
    onSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function CanvasRevisionPanel({ busy, error, onCancel, onSubmit, }: CanvasRevisionPanelProps): import("react").JSX.Element;
