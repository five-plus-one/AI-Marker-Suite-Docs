import type { ReactNode } from 'react';
export interface CollapseTransitionProps {
    isOpen: boolean;
    children: ReactNode;
    duration?: number;
    easing?: string;
}
/** Grid interpolation follows dynamic content and reverses smoothly during rapid toggles. */
export declare function CollapseTransition({ isOpen, children, duration, easing }: CollapseTransitionProps): import("react").JSX.Element;
