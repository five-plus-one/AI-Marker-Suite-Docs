import { type ReactNode } from "react";
import { type NavigationItem } from "./WorkspaceNavigation";
export interface AccountLayoutProps {
    title: string;
    navigation: NavigationItem[];
    activeId: string;
    onNavigate: (id: string) => void;
    profile?: ReactNode;
    children: ReactNode;
}
export declare function AccountLayout({ title, navigation, activeId, onNavigate, profile, children, }: AccountLayoutProps): import("react").JSX.Element;
export declare function LoginForm({ onLogin, heading, description, alternate, }: {
    onLogin: (account: string, password: string) => Promise<void> | void;
    heading?: string;
    description?: string;
    alternate?: ReactNode;
}): import("react").JSX.Element;
export interface ProfileDetail {
    label: string;
    value: ReactNode;
}
export declare function UserProfile({ name, avatarUrl, description, details, actions, }: {
    name: string;
    avatarUrl?: string;
    description?: string;
    details: ProfileDetail[];
    actions?: ReactNode;
}): import("react").JSX.Element;
export declare function CreditAdjustment({ name, balance, onSubmit, }: {
    name: string;
    balance: number;
    onSubmit: (amount: number, reason: string) => Promise<void> | void;
}): import("react").JSX.Element;
export interface Invitation {
    id: string;
    name: string;
    from: string;
    role: string;
    date?: string;
}
export declare function InvitationList({ items, onRespond, loading, error, }: {
    items: Invitation[];
    onRespond: (id: string, accept: boolean) => Promise<void> | void;
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
export interface DirectoryOption {
    id: string;
    name: string;
    parentId?: string | null;
    disabled?: boolean;
}
export declare function DirectoryPicker({ items, value, onChange, label, onConfirm, }: {
    items: DirectoryOption[];
    value: string;
    onChange: (id: string) => void;
    label?: string;
    onConfirm?: () => Promise<void> | void;
}): import("react").JSX.Element;
export interface CommercePlan {
    id: string;
    name: string;
    price: string;
    description: string;
    features: string[];
    current?: boolean;
    disabled?: boolean;
}
export declare function PlanPicker({ plans, onSelect, }: {
    plans: CommercePlan[];
    onSelect: (id: string) => void;
}): import("react").JSX.Element;
