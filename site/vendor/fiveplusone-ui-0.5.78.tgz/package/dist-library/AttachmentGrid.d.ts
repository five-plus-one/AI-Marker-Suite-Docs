/** AttachmentGrid - 从课栈 chat/AttachmentThumbnails 提取
 *
 * 图片附件缩略图网格：输入区可删除，历史消息只读。
 * 缺失图片显示占位块，点击可放大（由外部传 onOpen 决定）。
 */
export interface AttachmentItem {
    id: string;
    /** 图片地址；缺失时显示占位 */
    src?: string;
    name?: string;
}
export interface AttachmentGridProps {
    items: AttachmentItem[];
    /** 提供时显示删除按钮 */
    onRemove?: (id: string) => void;
    /** 点击缩略图 */
    onOpen?: (item: AttachmentItem) => void;
    /** 缩略图边长（px） */
    size?: number;
}
export declare function AttachmentGrid({ items, onRemove, onOpen, size, }: AttachmentGridProps): import("react").JSX.Element | null;
