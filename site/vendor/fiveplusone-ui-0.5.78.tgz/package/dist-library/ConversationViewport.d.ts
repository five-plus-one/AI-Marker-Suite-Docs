import type { HTMLAttributes, RefAttributes } from "react";
/** A shared conversation surface for hosts that own virtual scrolling and stream recovery. */
export declare function ConversationViewport({ className, ...props }: HTMLAttributes<HTMLDivElement> & RefAttributes<HTMLDivElement>): import("react").JSX.Element;
