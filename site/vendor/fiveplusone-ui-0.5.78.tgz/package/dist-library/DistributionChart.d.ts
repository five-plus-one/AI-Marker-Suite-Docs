/** DistributionChart - 从课栈 visualizations/primitives/DistributionChart 提取
 *
 * 概率分布示意图：正态、二项、泊松。坐标轴与刻度清晰，
 * 交互模式下可通过滑块改变参数。SVG 绘制，随容器宽度缩放。
 */
export type DistributionKind = "normal" | "binomial" | "poisson";
export interface DistributionChartProps {
    type: DistributionKind;
    /** 初始参数 */
    params?: {
        mu?: number;
        sigma?: number;
        n?: number;
        p?: number;
        lambda?: number;
    };
    /** 允许调整参数 */
    interactive?: boolean;
    height?: number;
    label?: string;
}
export declare function DistributionChart({ type, params, interactive, height, label, }: DistributionChartProps): import("react").JSX.Element;
