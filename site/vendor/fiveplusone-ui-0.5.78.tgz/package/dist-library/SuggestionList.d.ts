import { type ReactNode, type RefObject } from 'react';
export type SuggestionItem = {
    id: string;
    label: string;
    detail?: string;
    preview?: ReactNode;
};
/** A compact completion surface that keeps focus in the input being edited. */
export declare function SuggestionList({ anchor, items, activeId, onSelect, label }: {
    anchor: RefObject<HTMLElement | null>;
    items: SuggestionItem[];
    activeId?: string;
    onSelect: (id: string) => void;
    label?: string;
}): import("react").ReactPortal | null;
