import { jsxs as a, jsx as t } from "react/jsx-runtime";
import { memo as he, useState as S, useCallback as me } from "react";
const w = "var(--accent)", fe = "var(--fp-primary-soft)", Y = [
  "#5b46e5",
  "#0891b2",
  "#0f766e",
  "#ca8a04",
  "#dc2626",
  "#7c3aed",
  "#0369a1",
  "#065f46",
  "#92400e",
  "#991b1b",
  "#6d28d9",
  "#0e7490",
  "#166534",
  "#a16207",
  "#b91c1c",
  "#4338ca",
  "#155e75",
  "#14532d",
  "#78350f",
  "#7f1d1d"
], y = "#f59e0b", q = "#fef9c366", T = 20, m = 520, _ = 180, d = 46, M = 12, p = 12, Z = 28, ee = m - d - M, R = _ - p - Z, P = 130, J = P - p - Z;
function L(i, l) {
  if (i === "bernoulli") {
    const n = l;
    return {
      name: `伯努利(p=${n.toFixed(2)})`,
      mean: n,
      variance: n * (1 - n),
      sample: () => Math.random() < n ? 1 : 0
    };
  }
  if (i === "uniform") {
    const n = 2 * l;
    return {
      name: `均匀(0,${n.toFixed(1)})`,
      mean: l,
      variance: n * n / 12,
      sample: () => Math.random() * n
    };
  }
  return {
    name: `指数(λ=${(1 / l).toFixed(2)})`,
    mean: l,
    variance: l * l,
    sample: () => -l * Math.log(1 - Math.random())
  };
}
function pe(i, l, n) {
  const c = te(l, n);
  let s = 0, x = 0;
  const r = [];
  for (let u = 1; u <= c[c.length - 1]; u++)
    s += i.sample(), u === c[x] && (r.push(s / u), x++);
  return r;
}
function te(i, l) {
  const n = [];
  for (let c = 0; c < l; c++) {
    const s = c / (l - 1), x = Math.max(1, Math.round(Math.exp(s * Math.log(i))));
    (n.length === 0 || n[n.length - 1] !== x) && n.push(x);
  }
  return n;
}
const A = 60;
function O(i, l) {
  return d + i / (l - 1) * ee;
}
function K(i, l, n, c, s) {
  const x = (i - l) / (n - l);
  return s + c * (1 - x);
}
function V(i) {
  return i.length === 0 ? "" : i.map(([l, n], c) => `${c === 0 ? "M" : "L"}${l.toFixed(1)},${n.toFixed(1)}`).join(" ");
}
function Q(i, l, n) {
  return Math.min(1, i / (n * l * l));
}
function X({
  label: i,
  value: l,
  min: n,
  max: c,
  step: s,
  fmt: x,
  onChange: r,
  color: u
}) {
  return /* @__PURE__ */ a("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ t("span", { className: "w-28 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: i }),
    /* @__PURE__ */ t(
      "input",
      {
        type: "range",
        min: n,
        max: c,
        step: s,
        value: l,
        onChange: (v) => r(Number(v.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: u ?? w }
      }
    ),
    /* @__PURE__ */ t(
      "span",
      {
        className: "w-16 shrink-0 rounded-md px-2 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: fe, color: u ?? w },
        children: x(l)
      }
    )
  ] });
}
function ue() {
  const [i, l] = S("bernoulli"), [n, c] = S(0.5), [s, x] = S(300), [r, u] = S(0.15), [v, z] = S([]), [D, ne] = S(0), [k, W] = S(!1), C = {
    bernoulli: {
      min: 0.05,
      max: 0.95,
      step: 0.05,
      label: "参数 p",
      fmt: (e) => e.toFixed(2)
    },
    uniform: {
      min: 0.5,
      max: 3,
      step: 0.1,
      label: "均值 μ",
      fmt: (e) => e.toFixed(1)
    },
    exponential: {
      min: 0.5,
      max: 3,
      step: 0.1,
      label: "均值 μ",
      fmt: (e) => e.toFixed(1)
    }
  }[i], ae = me(() => {
    const e = L(i, n), o = [];
    for (let h = 0; h < T; h++)
      o.push(pe(e, s, A));
    z(o), ne(e.mean), W(!0);
  }, [i, n, s]), N = L(i, n), b = D || N.mean, le = Math.sqrt(N.variance), B = Math.max(3 * le, 2 * r, 0.5), ie = N.mean - B, oe = N.mean + B, F = (e) => K(e, ie, oe, R, p), se = (e) => O(e, A), $ = F(b - r), E = F(b + r), G = [], re = B / 2;
  for (let e = -2; e <= 2; e++)
    G.push(b + e * re);
  const H = (e) => K(e, 0, 1, J, p), j = k && v.length > 0 ? Array.from({ length: A }, (e, o) => v.filter((g) => {
    const f = g[o];
    return f !== void 0 && Math.abs(f - D) > r;
  }).length / v.length) : [], ce = te(s, A).map(
    (e) => Q(N.variance, r, e)
  ), I = Q(N.variance, r, s), U = (k && v.length > 0 ? v.map((e) => e[e.length - 1]).filter((e) => e !== void 0) : []).filter(
    (e) => Math.abs(e - D) > r
  ).length;
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ a("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "大数定律模拟器" }),
      /* @__PURE__ */ a("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: [
        "模拟 ",
        T,
        " 条样本均值 X̄ₙ 折线，观察「n 越大，超出 ε 带的比例趋向 0」。"
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ a("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ t("span", { className: "w-28 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: "选分布" }),
        /* @__PURE__ */ t("div", { className: "flex gap-1.5", children: ["bernoulli", "uniform", "exponential"].map(
          (e) => /* @__PURE__ */ t(
            "button",
            {
              type: "button",
              onClick: () => {
                l(e), c(e === "bernoulli" ? 0.5 : 1), W(!1), z([]);
              },
              className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (e === i ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-elevated)] border border-[var(--line)] text-[var(--ink-soft)] hover:border-[var(--accent)]"),
              children: e === "bernoulli" ? "伯努利" : e === "uniform" ? "均匀" : "指数"
            },
            e
          )
        ) })
      ] }),
      /* @__PURE__ */ t(
        X,
        {
          label: C.label,
          value: n,
          min: C.min,
          max: C.max,
          step: C.step,
          fmt: C.fmt,
          onChange: (e) => {
            c(e), W(!1), z([]);
          },
          color: w
        }
      ),
      /* @__PURE__ */ t(
        X,
        {
          label: "最大 n",
          value: s,
          min: 10,
          max: 1e3,
          step: 10,
          fmt: (e) => String(e),
          onChange: (e) => {
            x(e), W(!1), z([]);
          },
          color: "#0891b2"
        }
      ),
      /* @__PURE__ */ t(
        X,
        {
          label: "误差 ε",
          value: r,
          min: 0.05,
          max: 0.5,
          step: 0.05,
          fmt: (e) => e.toFixed(2),
          onChange: (e) => {
            u(e);
          },
          color: y
        }
      ),
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: ae,
          className: "w-full rounded-lg bg-[var(--accent)] py-1.5 text-[13px] font-bold text-white hover:opacity-90 transition-opacity",
          children: [
            "模拟 ",
            T,
            " 条 X̄ₙ 折线"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-3 text-[12px]", children: [
      { label: "分布", val: L(i, n).name },
      { label: "均值 μ", val: L(i, n).mean.toFixed(4) },
      {
        label: "方差 σ²",
        val: L(i, n).variance.toFixed(4)
      },
      {
        label: "切比雪夫上界 P(|X̄ₙ-μ|>ε)",
        val: I < 1e-3 ? "<0.001" : I.toFixed(4)
      }
    ].map(({ label: e, val: o }) => /* @__PURE__ */ a(
      "div",
      {
        className: "rounded-lg bg-[var(--bg-muted)] px-3 py-1.5",
        children: [
          /* @__PURE__ */ a("span", { className: "text-[var(--ink-soft)]", children: [
            e,
            ": "
          ] }),
          /* @__PURE__ */ t("span", { className: "font-mono font-bold text-[var(--ink)]", children: o })
        ]
      },
      e
    )) }),
    /* @__PURE__ */ a("div", { children: [
      /* @__PURE__ */ a("div", { className: "mb-1 text-[12px] font-semibold text-[var(--ink)]", children: [
        "样本均值 X̄ₙ 折线（对数 n 轴）",
        k && /* @__PURE__ */ a("span", { className: "ml-2 font-normal text-[var(--ink-soft)]", children: [
          "— n=",
          s,
          " 处超出 ε 带:",
          " ",
          /* @__PURE__ */ a("b", { style: { color: U > 0 ? "#dc2626" : "#0f766e" }, children: [
            U,
            "/",
            T
          ] })
        ] })
      ] }),
      /* @__PURE__ */ a(
        "svg",
        {
          viewBox: `0 0 ${m} ${_}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { background: "var(--bg-muted)" },
          children: [
            /* @__PURE__ */ t(
              "rect",
              {
                x: d,
                y: Math.min(E, $),
                width: ee,
                height: Math.abs($ - E),
                fill: q
              }
            ),
            G.map((e) => {
              const o = F(e), h = Math.abs(e - b) < 1e-9, g = Math.abs(e - (b + r)) < 1e-9, f = Math.abs(e - (b - r)) < 1e-9;
              return /* @__PURE__ */ a("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: d,
                    y1: o,
                    x2: m - M,
                    y2: o,
                    stroke: h ? "var(--accent)" : g || f ? y : "var(--line)",
                    strokeDasharray: h ? "5 3" : g || f ? "4 3" : void 0,
                    strokeWidth: h || g || f ? 1.2 : 1
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: d - 4,
                    y: o + 3,
                    fontSize: "9",
                    textAnchor: "end",
                    fill: "var(--ink-faint)",
                    children: e.toFixed(2)
                  }
                )
              ] }, e);
            }),
            /* @__PURE__ */ a(
              "text",
              {
                x: m - M - 2,
                y: F(b) - 3,
                fontSize: "9",
                textAnchor: "end",
                fill: w,
                children: [
                  "μ=",
                  b.toFixed(3)
                ]
              }
            ),
            E > p + 6 && /* @__PURE__ */ t(
              "text",
              {
                x: d + 4,
                y: E - 2,
                fontSize: "9",
                fill: y,
                children: "μ+ε"
              }
            ),
            $ < p + R - 4 && /* @__PURE__ */ t(
              "text",
              {
                x: d + 4,
                y: $ + 9,
                fontSize: "9",
                fill: y,
                children: "μ-ε"
              }
            ),
            /* @__PURE__ */ t("text", { x: d, y: _ - 4, fontSize: "9", fill: "var(--ink-faint)", children: "n=1" }),
            /* @__PURE__ */ a(
              "text",
              {
                x: m - M,
                y: _ - 4,
                fontSize: "9",
                textAnchor: "end",
                fill: "var(--ink-faint)",
                children: [
                  "n=",
                  s
                ]
              }
            ),
            k && v.map((e, o) => {
              const h = e.map((de, xe) => [
                se(xe),
                F(de)
              ]), g = e[e.length - 1], f = g !== void 0 && Math.abs(g - D) > r;
              return /* @__PURE__ */ t(
                "path",
                {
                  d: V(h),
                  fill: "none",
                  stroke: f ? "#dc2626" : Y[o % Y.length],
                  strokeWidth: f ? 1.5 : 1,
                  opacity: f ? 0.85 : 0.55
                },
                o
              );
            }),
            !k && /* @__PURE__ */ t(
              "text",
              {
                x: m / 2,
                y: _ / 2,
                textAnchor: "middle",
                fontSize: "12",
                fill: "var(--ink-faint)",
                children: "点击「模拟」开始"
              }
            ),
            /* @__PURE__ */ t(
              "line",
              {
                x1: d,
                y1: p,
                x2: d,
                y2: p + R,
                stroke: "var(--line)"
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ a("div", { children: [
      /* @__PURE__ */ a("div", { className: "mb-1 text-[12px] font-semibold text-[var(--ink)]", children: [
        "超出 ε 带折线比例 vs n",
        /* @__PURE__ */ t("span", { className: "ml-1 font-normal text-[var(--ink-soft)]", children: "（橙色=实验值，虚线=切比雪夫上界）" })
      ] }),
      /* @__PURE__ */ a(
        "svg",
        {
          viewBox: `0 0 ${m} ${P}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { background: "var(--bg-muted)" },
          children: [
            [0, 0.25, 0.5, 0.75, 1].map((e) => {
              const o = H(e);
              return /* @__PURE__ */ a("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: d,
                    y1: o,
                    x2: m - M,
                    y2: o,
                    stroke: e === 0 ? "var(--accent)" : "var(--line)",
                    strokeDasharray: e === 0 ? "4 3" : void 0,
                    strokeWidth: e === 0 ? 1.2 : 1
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: d - 4,
                    y: o + 3,
                    fontSize: "9",
                    textAnchor: "end",
                    fill: "var(--ink-faint)",
                    children: e
                  }
                )
              ] }, e);
            }),
            /* @__PURE__ */ t(
              "text",
              {
                x: m - M - 2,
                y: H(0) - 3,
                fontSize: "9",
                textAnchor: "end",
                fill: w,
                children: "趋向 0"
              }
            ),
            /* @__PURE__ */ t("text", { x: d, y: P - 4, fontSize: "9", fill: "var(--ink-faint)", children: "n=1" }),
            /* @__PURE__ */ a(
              "text",
              {
                x: m - M,
                y: P - 4,
                fontSize: "9",
                textAnchor: "end",
                fill: "var(--ink-faint)",
                children: [
                  "n=",
                  s
                ]
              }
            ),
            /* @__PURE__ */ t(
              "path",
              {
                d: V(
                  ce.map(
                    (e, o) => [O(o, A), H(Math.min(1, e))]
                  )
                ),
                fill: "none",
                stroke: y,
                strokeWidth: 1.5,
                strokeDasharray: "5 3",
                opacity: 0.9
              }
            ),
            k && j.length > 0 && (() => {
              const e = j.map((o, h) => [
                O(h, A),
                H(o)
              ]);
              return /* @__PURE__ */ t(
                "path",
                {
                  d: V(e),
                  fill: "none",
                  stroke: "#f97316",
                  strokeWidth: 2,
                  opacity: 0.9
                }
              );
            })(),
            !k && /* @__PURE__ */ t(
              "text",
              {
                x: m / 2,
                y: P / 2,
                textAnchor: "middle",
                fontSize: "12",
                fill: "var(--ink-faint)",
                children: "模拟后显示"
              }
            ),
            /* @__PURE__ */ t(
              "line",
              {
                x1: d,
                y1: p,
                x2: d,
                y2: p + J,
                stroke: "var(--line)"
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ a("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-loose text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ t("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "切比雪夫不等式上界" }),
      /* @__PURE__ */ t("div", { className: "font-mono text-[12px]", children: "P(|X̄ₙ − μ| > ε) ≤ σ² / (n·ε²)" }),
      /* @__PURE__ */ a("div", { className: "font-mono text-[11px] mt-0.5 text-[var(--ink-soft)]", children: [
        "= ",
        /* @__PURE__ */ t("span", { style: { color: "#0891b2", fontWeight: 700 }, children: N.variance.toFixed(4) }),
        " / (",
        /* @__PURE__ */ t("span", { style: { color: "#0891b2", fontWeight: 700 }, children: s }),
        " × ",
        /* @__PURE__ */ a("span", { style: { color: y, fontWeight: 700 }, children: [
          r.toFixed(2),
          "²"
        ] }),
        ") = ",
        /* @__PURE__ */ t("span", { style: { color: w, fontWeight: 700 }, children: I < 1e-4 ? "<0.0001" : I.toFixed(4) })
      ] }),
      /* @__PURE__ */ a("div", { className: "mt-1 text-[11px]", children: [
        "当 n → ∞ 时，上界 → 0，即",
        " ",
        /* @__PURE__ */ t("b", { className: "text-[var(--ink)]", children: "弱大数定律" }),
        "：X̄ₙ 依概率收敛到 μ。"
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "flex flex-wrap gap-3 text-[11px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ a("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-2 w-6 rounded-full",
            style: { background: w, opacity: 0.6 }
          }
        ),
        /* @__PURE__ */ t("span", { children: "未超出 ε 带的折线" })
      ] }),
      /* @__PURE__ */ a("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-2 w-6 rounded-full",
            style: { background: "#dc2626" }
          }
        ),
        /* @__PURE__ */ t("span", { children: "超出 ε 带的折线（在 n=nMax 时）" })
      ] }),
      /* @__PURE__ */ a("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-3 w-6 rounded",
            style: {
              background: q,
              border: `1px dashed ${y}`
            }
          }
        ),
        /* @__PURE__ */ t("span", { children: "ε 带（μ±ε）" })
      ] }),
      /* @__PURE__ */ a("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t("svg", { width: "24", height: "8", style: { display: "inline-block" }, children: /* @__PURE__ */ t(
          "line",
          {
            x1: "0",
            y1: "4",
            x2: "24",
            y2: "4",
            stroke: y,
            strokeWidth: "1.5",
            strokeDasharray: "4 2"
          }
        ) }),
        /* @__PURE__ */ t("span", { children: "切比雪夫上界" })
      ] }),
      /* @__PURE__ */ a("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-2 w-6 rounded-full",
            style: { background: "#f97316" }
          }
        ),
        /* @__PURE__ */ t("span", { children: "实验超出比例" })
      ] })
    ] })
  ] });
}
const ke = he(ue);
export {
  ke as default
};
