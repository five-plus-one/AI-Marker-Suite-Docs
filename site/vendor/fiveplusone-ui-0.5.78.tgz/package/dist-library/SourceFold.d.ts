/** SourceFold - 从课栈 chat/WebSourceFold 提取
 *
 * 可折叠的参考资料列表：显示条数与来源，展开后逐条列出标题与站点。
 */
export interface SourceItem {
    url: string;
    title?: string;
    detail?: string;
}
export interface SourceFoldProps {
    sources: SourceItem[];
    label?: string;
    /** 是否命中缓存 */
    cached?: boolean;
    onOpen?: (source: SourceItem) => void;
}
export declare function SourceFold({ sources, label, cached, onOpen, }: SourceFoldProps): import("react").JSX.Element | null;
