import { type ReactNode } from 'react';
export interface SlideTransitionProps {
    index: number;
    children: ReactNode;
    className?: string;
    duration?: number;
    label?: string;
}
/** Ordered content slides in navigation direction while the viewport remains stable. */
export declare function SlideTransition({ index, children, className, duration, label }: SlideTransitionProps): import("react").JSX.Element;
