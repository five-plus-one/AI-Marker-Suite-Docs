import { type ReactNode } from 'react';
export interface BrowserEntry {
    id: string;
    parentId?: string;
    label: string;
    kind: 'folder' | 'file';
    description?: string;
    keywords?: string;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface ResourceBrowserProps {
    entries: BrowserEntry[];
    directoryId: string;
    onNavigate: (id: string) => void;
    selectedId?: string;
    onSelect: (id: string) => void;
    rootLabel?: string;
    searchLabel?: string;
    emptyLabel?: string;
    disabled?: boolean;
    preview?: ReactNode;
    loading?: boolean;
    variant?: 'content' | 'destination';
}
/** A controlled browser for choosing library content or a destination directory. */
export declare function ResourceBrowser({ entries, directoryId, onNavigate, selectedId, onSelect, rootLabel, searchLabel, emptyLabel, disabled, preview, loading, variant }: ResourceBrowserProps): import("react").JSX.Element;
