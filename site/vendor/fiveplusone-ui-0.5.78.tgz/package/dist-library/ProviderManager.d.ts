import { type ReactNode } from 'react';
export interface PersonalProviderModel {
    id: string;
    label?: string;
    registryId?: string;
    tools?: boolean;
    vision?: boolean;
    contextK?: number;
    contextSource?: 'provider' | 'user' | 'default';
}
export interface PersonalProviderDraft {
    id?: string;
    revision?: number;
    name: string;
    baseUrl: string;
    protocol: 'openai' | 'anthropic' | 'siliconflow';
    apiKey: string;
    models: PersonalProviderModel[];
}
export interface PersonalProviderItem extends Omit<PersonalProviderDraft, 'apiKey'> {
    id: string;
    revision: number;
    keyConfigured: boolean;
}
export interface PersonalProviderImport {
    id: string;
    label: string;
    draft: PersonalProviderDraft;
}
export interface ProviderManagerProps {
    items: PersonalProviderItem[];
    loading?: boolean;
    error?: string;
    credentialNotice?: ReactNode;
    imports?: PersonalProviderImport[];
    onImportSaved?: (id: string) => void;
    onDiscover: (draft: PersonalProviderDraft) => Promise<PersonalProviderModel[]>;
    onTest: (draft: PersonalProviderDraft) => Promise<string>;
    onSave: (draft: PersonalProviderDraft, proof: string) => Promise<void>;
    onDelete: (item: PersonalProviderItem) => Promise<void>;
}
/** Credential input stays in the editing session; the host owns requests and storage. */
export declare function ProviderManager({ items, loading, error, credentialNotice, imports, onImportSaved, onDiscover, onTest, onSave, onDelete }: ProviderManagerProps): import("react").JSX.Element;
