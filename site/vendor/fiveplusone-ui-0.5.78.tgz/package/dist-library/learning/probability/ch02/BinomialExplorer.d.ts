declare function BinomialExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof BinomialExplorerBase>;
export default _default;
