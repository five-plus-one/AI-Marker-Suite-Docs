declare function FuncDistDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof FuncDistDemoBase>;
export default _default;
