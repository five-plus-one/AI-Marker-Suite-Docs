declare function StatisticCalculatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof StatisticCalculatorBase>;
export default _default;
