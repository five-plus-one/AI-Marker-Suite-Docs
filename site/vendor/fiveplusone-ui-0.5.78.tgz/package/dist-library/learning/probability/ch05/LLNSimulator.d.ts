declare function LLNSimulatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof LLNSimulatorBase>;
export default _default;
