export declare function diskSlice(x: number): {
    x: number;
    halfLength: number;
    length: number;
    marginal: number;
    density: number;
};
export declare function ontoCount(n: number, m: number): number;
export declare function occupancyModel(n: number, m: number): {
    total: number;
    same: number;
    different: number | null;
    counts: {
        people: number;
        count: number;
    }[];
};
export declare function fraction(a: number, b: number): string;
export declare function DiskConditionalLab(): import("react").JSX.Element;
export declare function OccupancyLab(): import("react").JSX.Element;
