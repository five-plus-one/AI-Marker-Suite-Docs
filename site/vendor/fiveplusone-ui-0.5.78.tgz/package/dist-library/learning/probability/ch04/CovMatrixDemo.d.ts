declare function CovMatrixDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CovMatrixDemoBase>;
export default _default;
