declare function VarianceExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof VarianceExplorerBase>;
export default _default;
