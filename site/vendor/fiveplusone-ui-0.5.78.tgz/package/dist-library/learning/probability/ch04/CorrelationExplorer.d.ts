declare function CorrelationExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CorrelationExplorerBase>;
export default _default;
