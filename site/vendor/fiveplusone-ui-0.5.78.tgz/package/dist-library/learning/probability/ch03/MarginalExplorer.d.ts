declare function MarginalExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof MarginalExplorerBase>;
export default _default;
