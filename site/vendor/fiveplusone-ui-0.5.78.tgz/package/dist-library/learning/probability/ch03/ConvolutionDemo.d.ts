declare function ConvolutionDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ConvolutionDemoBase>;
export default _default;
