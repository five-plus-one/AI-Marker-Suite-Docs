declare function ErrorTypeDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ErrorTypeDemoBase>;
export default _default;
