declare function HypTestDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof HypTestDemoBase>;
export default _default;
