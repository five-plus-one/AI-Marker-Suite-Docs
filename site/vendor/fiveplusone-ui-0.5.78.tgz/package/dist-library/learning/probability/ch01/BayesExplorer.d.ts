declare function BayesExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof BayesExplorerBase>;
export default _default;
