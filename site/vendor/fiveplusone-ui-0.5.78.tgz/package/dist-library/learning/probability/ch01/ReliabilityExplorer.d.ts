declare function ReliabilityExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ReliabilityExplorerBase>;
export default _default;
