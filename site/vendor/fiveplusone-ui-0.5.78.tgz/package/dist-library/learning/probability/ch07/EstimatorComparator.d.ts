declare function EstimatorComparatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof EstimatorComparatorBase>;
export default _default;
