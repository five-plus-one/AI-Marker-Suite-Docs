declare function MLEExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof MLEExplorerBase>;
export default _default;
