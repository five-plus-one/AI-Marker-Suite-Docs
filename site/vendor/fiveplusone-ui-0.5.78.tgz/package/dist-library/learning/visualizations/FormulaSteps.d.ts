import React from "react";
import "katex/dist/katex.min.css";
export interface FormulaStepsProps {
    /** 每个元素是一步（可能含 LaTeX，使用 $...$ 或 $$...$$） */
    steps: string[];
    /** 默认 false（静态模式：展示完整列表） */
    interactive?: boolean;
}
/**
 * FormulaSteps 原语：用 KaTeX 渲染含 LaTeX 的公式推导步骤。
 * - 静态模式：编号步骤列表，全部展示
 * - 交互模式：上一步/下一步导航，当前步骤高亮
 */
export declare const FormulaSteps: React.FC<FormulaStepsProps>;
