import { type SelectHTMLAttributes } from "react";
export declare function LearningSelect({ children, value, defaultValue, onChange, "aria-label": label, title, disabled, className, style, id, }: SelectHTMLAttributes<HTMLSelectElement>): import("react").JSX.Element;
