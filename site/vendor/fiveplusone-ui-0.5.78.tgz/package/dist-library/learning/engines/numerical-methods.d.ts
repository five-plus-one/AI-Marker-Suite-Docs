export declare function areaError(a: number, b: number, ea: number, eb: number): {
    nominal: number;
    linear: number;
    exact: number;
    low: number;
    high: number;
};
export declare const classroomPolynomial: (x: number) => number;
/** k is the number of completed bracket updates, before evaluating its midpoint. */
export declare function bisectionSteps(updates: number): {
    k: number;
    a: number;
    b: number;
    mid: number;
    value: number;
    bound: number;
}[];
export declare function fixedPointSteps(kind: 'sqrt' | 'slow', count: number): {
    L: number;
    root: number;
    rows: {
        k: number;
        previous: number;
        x: number;
        step: number;
        bound: number;
        error: number;
    }[];
};
