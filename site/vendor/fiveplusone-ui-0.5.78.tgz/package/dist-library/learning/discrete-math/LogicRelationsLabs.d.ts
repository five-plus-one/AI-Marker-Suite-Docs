export declare function TruthTableLab(): import("react").JSX.Element;
export declare function QuantifierScopeLab(): import("react").JSX.Element;
export declare function RelationPropertyLab(): import("react").JSX.Element;
export declare function FunctionMappingLab(): import("react").JSX.Element;
