export declare function graphFacts(mask: number): {
    edges: number[][];
    degrees: number[];
    colors: number[];
    bipartite: boolean;
    components: number;
    matching: number[][];
};
export declare function GraphStructureLab({ matching, }: {
    matching?: boolean;
}): import("react").JSX.Element;
export declare function MatchingLab(): import("react").JSX.Element;
export declare function SetCountingLab(): import("react").JSX.Element;
export declare function OrderLab(): import("react").JSX.Element;
