declare function ChiralityMirrorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ChiralityMirrorBase>;
export default _default;
