declare function CarbonylAdditionBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CarbonylAdditionBase>;
export default _default;
