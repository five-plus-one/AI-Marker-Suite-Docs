declare function CarbocationStabilityBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CarbocationStabilityBase>;
export default _default;
