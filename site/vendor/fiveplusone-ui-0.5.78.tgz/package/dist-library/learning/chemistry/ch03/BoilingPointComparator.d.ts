declare function BoilingPointComparatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof BoilingPointComparatorBase>;
export default _default;
