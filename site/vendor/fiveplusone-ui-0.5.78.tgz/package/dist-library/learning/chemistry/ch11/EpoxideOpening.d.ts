declare function EpoxideOpeningBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof EpoxideOpeningBase>;
export default _default;
