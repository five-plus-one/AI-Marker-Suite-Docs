declare function SN1SN2CompareBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof SN1SN2CompareBase>;
export default _default;
