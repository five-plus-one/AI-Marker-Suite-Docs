export declare function electricField(mode: string, charge: number, distance: number, radius?: number): number;
export default function ElectrostaticsLab(): import("react").JSX.Element;
