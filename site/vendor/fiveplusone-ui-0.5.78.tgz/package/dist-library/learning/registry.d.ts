import { type ComponentType } from "react";
type SubjectId = string;
export interface InteractiveMeta {
    id: string;
    subjectId: SubjectId;
    chapterId: string;
    sectionId: string;
    title: string;
    description?: string;
    Component: ComponentType<Record<string, never>>;
}
/**
 * 交互组件注册表。每个条目以 id 唯一标识，可被笔记内 ::interactive{id=...}
 * 内联引用，也会出现在右侧「可交互」Tab 中。后续 SOP 子智能体在此追加条目。
 */
export declare const learningExperiments: InteractiveMeta[];
export declare function getInteractive(id?: string | null): InteractiveMeta | undefined;
export declare function getInteractivesForSection(subjectId: SubjectId, chapterId: string, sectionId: string): InteractiveMeta[];
export {};
