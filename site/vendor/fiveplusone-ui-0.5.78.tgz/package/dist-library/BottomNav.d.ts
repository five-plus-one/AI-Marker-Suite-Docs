/** BottomNav - 从课栈 layout/MobileBottomNav 提取
 *
 * 移动端底部导航：图标 + 文字，当前项有顶部指示条，
 * 自动避让 iOS 安全区。
 */
import type { ReactNode } from "react";
export interface BottomNavItem {
    id: string;
    label: string;
    icon: ReactNode;
    /** 角标数字 */
    badge?: number;
    href?: string;
    disabled?: boolean;
}
export interface BottomNavProps {
    items: BottomNavItem[];
    value: string;
    onChange: (id: string) => void;
    label?: string;
    className?: string;
    busy?: boolean;
}
export declare function BottomNav({ items, value, onChange, label, className, busy, }: BottomNavProps): import("react").JSX.Element;
