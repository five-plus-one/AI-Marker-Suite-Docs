import { jsxs as n, jsx as e } from "react/jsx-runtime";
import { memo as ce, useState as L } from "react";
const f = "var(--accent)", B = "var(--fp-primary-soft)", g = "#0f766e", V = "color-mix(in srgb, #d1fae5 24%, var(--fp-surface))", M = "#dc2626", $ = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))";
function F(r) {
  const o = [
    0,
    -39.69683028665376,
    220.9460984245205,
    -275.9285104469687,
    138.357751867269,
    -30.66479806614716,
    2.506628277459239
  ], t = [
    -54.47609879822406,
    161.5858368580409,
    -155.6989798598866,
    66.80131188771972,
    -13.28068155288572
  ], c = [
    -0.007784894002430293,
    -0.3223964580411365,
    -2.400758277161838,
    -2.549732539343734,
    4.374664141464968,
    2.938163982698783
  ], s = [
    0.007784695709041462,
    0.3224671290700398,
    2.445134137142996,
    3.754408661907416
  ], b = 0.02425, N = 1 - b;
  let l;
  if (r < b)
    return l = Math.sqrt(-2 * Math.log(r)), (((((c[0] * l + c[1]) * l + c[2]) * l + c[3]) * l + c[4]) * l + c[5]) / ((((s[0] * l + s[1]) * l + s[2]) * l + s[3]) * l + 1);
  if (r <= N) {
    l = r - 0.5;
    const d = l * l;
    return (((((o[1] * d + o[2]) * d + o[3]) * d + o[4]) * d + o[5]) * d + o[6]) * l / (((((t[0] * d + t[1]) * d + t[2]) * d + t[3]) * d + t[4]) * d + 1);
  } else
    return l = Math.sqrt(-2 * Math.log(1 - r)), -(((((c[0] * l + c[1]) * l + c[2]) * l + c[3]) * l + c[4]) * l + c[5]) / ((((s[0] * l + s[1]) * l + s[2]) * l + s[3]) * l + 1);
}
function ie(r, o) {
  if (o >= 200) return F(r);
  const t = F(r), c = (t * t * t + t) / (4 * o), s = (5 * t * t * t * t * t + 16 * t * t * t + 3 * t) / (96 * o * o), b = (3 * t * t * t * t * t * t * t + 19 * t * t * t * t * t + 17 * t * t * t - 15 * t) / (384 * o * o * o);
  return t + c + s + b;
}
function de() {
  const r = Math.random(), o = Math.random();
  return Math.sqrt(-2 * Math.log(Math.max(r, 1e-15))) * Math.cos(2 * Math.PI * o);
}
const H = 0, O = 1, Q = 200;
function v(r) {
  return (r * 100).toFixed(1) + "%";
}
function ee({
  label: r,
  value: o,
  display: t,
  min: c,
  max: s,
  step: b,
  onChange: N
}) {
  return /* @__PURE__ */ n("div", { className: "space-y-1", children: [
    /* @__PURE__ */ n("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: r }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
          style: { background: B, color: f },
          children: t
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: c,
        max: s,
        step: b,
        value: o,
        onChange: (l) => N(Number(l.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: f }
      }
    )
  ] });
}
function xe() {
  const [r, o] = L(0.95), [t, c] = L(20), [s, b] = L(!0), [N, l] = L([]), d = 1 - r, te = F(1 - d / 2), ne = ie(1 - d / 2, t - 1), _ = s ? te : ne;
  function P(a) {
    const u = [];
    for (let x = 0; x < a; x++) {
      let h = 0, E = 0;
      for (let K = 0; K < t; K++) {
        const D = H + O * de();
        h += D, E += D * D;
      }
      const k = h / t, T = Math.sqrt((E - t * k * k) / (t - 1)), j = s ? O / Math.sqrt(t) : T / Math.sqrt(t), q = k - _ * j, J = k + _ * j;
      u.push({ mean: k, lo: q, hi: J, covers: q <= H && H <= J });
    }
    l((x) => {
      const h = [...x, ...u];
      return h.length > Q ? h.slice(h.length - Q) : h;
    });
  }
  function A() {
    l([]);
  }
  const i = N.length, w = N.filter((a) => a.covers).length, W = i > 0 ? w / i : 0, C = r, I = i > 0 ? W - C : 0, U = 50, X = N.slice(-U), R = 480, G = Math.max(160, X.length * 10 + 40), p = 80, ae = 20, m = 24, le = 20, z = R - p - ae, S = G - m - le, Y = -3.5, se = 3.5, y = (a) => p + (a - Y) / (se - Y) * z, re = (a) => m + S - (a + 0.5) / Math.max(X.length, 1) * S, Z = y(H), oe = [-3, -2, -1, 0, 1, 2, 3];
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "置信区间捕获率可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: "每次模拟从 N(0,1) 中抽取样本，构造置信区间。 绿色区间覆盖真值 μ=0，红色未覆盖。 反复点击「模拟 50 次」，观察实际覆盖率是否趋近声称的 1−α。" })
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: [
      /* @__PURE__ */ e(
        ee,
        {
          label: "置信水平 1−α",
          value: r,
          display: v(r),
          min: 0.8,
          max: 0.99,
          step: 0.01,
          onChange: (a) => {
            o(a), A();
          }
        }
      ),
      /* @__PURE__ */ e(
        ee,
        {
          label: "样本量 n",
          value: t,
          display: String(t),
          min: 5,
          max: 50,
          step: 1,
          onChange: (a) => {
            c(a), A();
          }
        }
      ),
      /* @__PURE__ */ n("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "区间类型" }),
        /* @__PURE__ */ e("div", { className: "flex rounded-lg overflow-hidden border border-[var(--line)]", children: [
          { label: "Z 区间（σ 已知）", val: !0 },
          { label: "t 区间（σ 未知）", val: !1 }
        ].map((a) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => {
              b(a.val), A();
            },
            className: "px-3 py-1.5 text-[12px] font-medium transition-colors",
            style: {
              background: s === a.val ? f : "transparent",
              color: s === a.val ? "white" : "var(--ink-soft)"
            },
            children: a.label
          },
          String(a.val)
        )) }),
        /* @__PURE__ */ n("span", { className: "text-[11px] text-[var(--ink-soft)] ml-1", children: [
          "临界值 ",
          s ? "z" : "t",
          /* @__PURE__ */ e("sub", { children: s ? "α/2" : `α/2,${t - 1}` }),
          " = ",
          /* @__PURE__ */ e("b", { className: "font-mono text-[var(--ink)]", children: _.toFixed(4) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-2 items-center", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => P(50),
          className: "rounded-lg px-4 py-2 text-[13px] font-semibold text-white transition-opacity hover:opacity-90",
          style: { background: f },
          children: "模拟 50 次"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => P(1),
          className: "rounded-lg px-4 py-2 text-[13px] font-semibold text-white transition-opacity hover:opacity-90",
          style: { background: g },
          children: "模拟 1 次"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: A,
          className: "rounded-lg px-4 py-2 text-[13px] font-medium text-[var(--ink-soft)] bg-[var(--bg-muted)] hover:bg-[var(--line)] transition-colors",
          children: "清除重置"
        }
      ),
      i > 0 && /* @__PURE__ */ n("span", { className: "text-[12px] text-[var(--ink-soft)] ml-1", children: [
        "已累积 ",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)] font-mono", children: i }),
        " ",
        "次（最多显示末 50 条）"
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "flex gap-4 items-start", children: [
      /* @__PURE__ */ e("div", { className: "flex-1 min-w-0", children: i === 0 ? /* @__PURE__ */ e(
        "div",
        {
          className: "flex items-center justify-center rounded-lg border border-dashed border-[var(--line)] text-[13px] text-[var(--ink-soft)]",
          style: { height: 200 },
          children: "点击「模拟 50 次」开始可视化"
        }
      ) : /* @__PURE__ */ n(
        "svg",
        {
          viewBox: `0 0 ${R} ${G}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { maxHeight: 400, display: "block" },
          children: [
            /* @__PURE__ */ e(
              "rect",
              {
                x: 0,
                y: 0,
                width: R,
                height: G,
                fill: "var(--bg-muted)"
              }
            ),
            /* @__PURE__ */ e(
              "rect",
              {
                x: p,
                y: m,
                width: z,
                height: S,
                fill: "var(--bg-elevated)",
                stroke: "var(--line)"
              }
            ),
            oe.map((a) => /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: y(a),
                  y1: m,
                  x2: y(a),
                  y2: m + S,
                  stroke: "var(--line)",
                  strokeWidth: 1,
                  strokeDasharray: a === 0 ? void 0 : "3 3"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: y(a),
                  y: m + S + 14,
                  textAnchor: "middle",
                  fontSize: 9,
                  fill: "var(--ink-faint)",
                  children: a
                }
              )
            ] }, a)),
            /* @__PURE__ */ e(
              "text",
              {
                x: p - 8,
                y: m - 8,
                fontSize: 9,
                fill: "var(--ink-faint)",
                textAnchor: "end",
                children: "第 k 次"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: R / 2,
                y: G - 4,
                fontSize: 9,
                fill: "var(--ink-faint)",
                textAnchor: "middle",
                children: "样本均值 x̄"
              }
            ),
            X.map((a, u) => {
              const x = re(u), h = Math.max(y(a.lo), p), E = Math.min(y(a.hi), p + z), k = Math.max(
                p,
                Math.min(y(a.mean), p + z)
              ), T = a.covers ? g : M, j = a.covers ? V : $, q = Math.max(0, i - U) + u + 1;
              return /* @__PURE__ */ n("g", { children: [
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: p - 4,
                    y: x + 3,
                    textAnchor: "end",
                    fontSize: 7,
                    fill: "var(--ink-faint)",
                    children: q
                  }
                ),
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: h,
                    y: x - 3,
                    width: Math.max(0, E - h),
                    height: 6,
                    fill: j,
                    stroke: T,
                    strokeWidth: 0.8,
                    opacity: 0.85,
                    rx: 1
                  }
                ),
                /* @__PURE__ */ e("circle", { cx: k, cy: x, r: 2, fill: T })
              ] }, u);
            }),
            /* @__PURE__ */ e(
              "line",
              {
                x1: Z,
                y1: m - 4,
                x2: Z,
                y2: m + S + 4,
                stroke: f,
                strokeWidth: 2,
                strokeDasharray: "5 3"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: Z + 4,
                y: m - 6,
                fontSize: 9,
                fill: f,
                fontWeight: "bold",
                children: "μ=0"
              }
            )
          ]
        }
      ) }),
      /* @__PURE__ */ n("div", { className: "flex-shrink-0 w-44 space-y-3", children: [
        /* @__PURE__ */ n(
          "div",
          {
            className: "rounded-lg p-3 text-center",
            style: { background: B },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)] leading-snug mb-1", children: "声称置信水平" }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "text-[22px] font-extrabold font-mono",
                  style: { color: f },
                  children: v(C)
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ n(
          "div",
          {
            className: "rounded-lg p-3 text-center",
            style: {
              background: i === 0 ? "var(--bg-muted)" : Math.abs(I) < 0.05 ? V : $
            },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)] leading-snug mb-1", children: "实际覆盖率" }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "text-[22px] font-extrabold font-mono",
                  style: {
                    color: i === 0 ? "var(--ink-faint)" : Math.abs(I) < 0.05 ? g : M
                  },
                  children: i === 0 ? "—" : v(W)
                }
              ),
              i > 0 && /* @__PURE__ */ n("div", { className: "text-[11px] text-[var(--ink-soft)] mt-1", children: [
                w,
                " / ",
                i
              ] })
            ]
          }
        ),
        i > 0 && /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] p-2.5 space-y-1.5", children: [
          /* @__PURE__ */ n("div", { className: "flex justify-between text-[11px]", children: [
            /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "覆盖" }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "font-semibold font-mono",
                style: { color: g },
                children: w
              }
            )
          ] }),
          /* @__PURE__ */ n("div", { className: "flex justify-between text-[11px]", children: [
            /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "未覆盖" }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "font-semibold font-mono",
                style: { color: M },
                children: i - w
              }
            )
          ] }),
          /* @__PURE__ */ n("div", { className: "flex justify-between text-[11px]", children: [
            /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "偏差" }),
            /* @__PURE__ */ n(
              "span",
              {
                className: "font-semibold font-mono",
                style: { color: Math.abs(I) < 0.03 ? g : M },
                children: [
                  I >= 0 ? "+" : "",
                  v(I)
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] p-2.5 space-y-1.5", children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] font-semibold text-[var(--ink-soft)] mb-1", children: "图例" }),
          [
            { color: g, bg: V, label: "覆盖 μ" },
            { color: M, bg: $, label: "未覆盖 μ" },
            { color: f, bg: B, label: "真值 μ=0" }
          ].map(({ color: a, bg: u, label: x }) => /* @__PURE__ */ n(
            "div",
            {
              className: "flex items-center gap-1.5 text-[11px] text-[var(--ink-soft)]",
              children: [
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "inline-block h-2.5 w-5 rounded-sm flex-shrink-0",
                    style: { background: u, border: `1.5px solid ${a}` }
                  }
                ),
                /* @__PURE__ */ e("span", { children: x })
              ]
            },
            x
          ))
        ] })
      ] })
    ] }),
    i > 0 && /* @__PURE__ */ n("div", { className: "space-y-1", children: [
      /* @__PURE__ */ n("div", { className: "flex justify-between text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ n("span", { style: { color: g }, children: [
          "已覆盖 ",
          w,
          " 次"
        ] }),
        /* @__PURE__ */ n("span", { style: { color: M }, children: [
          "未覆盖 ",
          i - w,
          " 次"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "div",
        {
          className: "h-4 w-full rounded-full overflow-hidden flex",
          style: { background: $, border: `1px solid ${M}` },
          children: /* @__PURE__ */ e(
            "div",
            {
              className: "h-full rounded-full transition-all duration-300",
              style: {
                width: `${W * 100}%`,
                background: g
              }
            }
          )
        }
      ),
      /* @__PURE__ */ n("div", { className: "relative h-3", style: { marginTop: -2 }, children: [
        /* @__PURE__ */ e(
          "div",
          {
            className: "absolute top-0 w-px h-3",
            style: {
              left: `${C * 100}%`,
              background: f
            }
          }
        ),
        /* @__PURE__ */ n(
          "div",
          {
            className: "absolute top-2 text-[9px] font-mono font-bold",
            style: {
              left: `${C * 100}%`,
              transform: "translateX(-50%)",
              color: f,
              whiteSpace: "nowrap"
            },
            children: [
              "目标 ",
              v(C)
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "space-y-2", children: [
      /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-2", children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: s ? "Z 区间（σ = 1 已知）" : "t 区间（σ 未知，用 S 估计）" }),
        /* @__PURE__ */ e("div", { className: "font-mono text-[12px]", children: s ? "CI = [x̄ − z_{α/2}·σ/√n,  x̄ + z_{α/2}·σ/√n]" : "CI = [x̄ − t_{α/2,n−1}·S/√n,  x̄ + t_{α/2,n−1}·S/√n]" }),
        /* @__PURE__ */ n("div", { className: "font-mono text-[11px] leading-loose", children: [
          /* @__PURE__ */ n("span", { children: [
            "α = 1 − ",
            v(r),
            " = ",
            v(d),
            "，"
          ] }),
          /* @__PURE__ */ n("span", { children: [
            s ? "z" : "t",
            /* @__PURE__ */ e("sub", { children: s ? "α/2" : `α/2,${t - 1}` }),
            " = ",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: _.toFixed(4) })
          ] }),
          /* @__PURE__ */ n("span", { children: [
            "，n = ",
            t
          ] })
        ] })
      ] }),
      /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "核心直觉：" }),
        "「95% 置信区间」的含义",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "不是" }),
        "「μ 以 95% 的概率落在某个区间里」—— μ 是固定的，区间是随机的。正确理解是：",
        /* @__PURE__ */ n("b", { className: "text-[var(--ink)]", children: [
          "反复抽样构造的区间，约有 ",
          v(r),
          " 覆盖真值 μ"
        ] }),
        "。 多次点击模拟，你会看到实际覆盖率收敛到 ",
        v(r),
        "。",
        !s && /* @__PURE__ */ n("span", { className: "block mt-1", children: [
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "t 区间" }),
          "：σ 未知时用样本标准差 S 代替， 临界值换为 t 分位数（自由度 df=n−1）。n 较小时 t 分布比正态更胖尾， 区间更宽——这正是对不确定性的保守补偿。"
        ] }),
        s && /* @__PURE__ */ n("span", { className: "block mt-1", children: [
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "Z 区间" }),
          "：σ 已知时，标准误 σ/√n 是确定的， 用标准正态分位数 z",
          /* @__PURE__ */ e("sub", { children: "α/2" }),
          " 即可。n 越大，区间越窄，估计越精确。"
        ] })
      ] })
    ] })
  ] });
}
const fe = ce(xe);
export {
  fe as default
};
