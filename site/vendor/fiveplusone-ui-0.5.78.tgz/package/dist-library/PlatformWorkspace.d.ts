import { type DirectoryUser } from "./DirectoryWorkspace";
export interface PlatformService {
    id: string;
    name: string;
    baseUrl: string;
    apiKey: string;
    keyConfigured?: boolean;
    enabled: boolean;
    models: string[];
}
export interface PlatformPreferences {
    siteName: string;
    accountName: string;
    supportUrl: string;
    providers: PlatformService[];
    documentProcessing: {
        quark: {
            apiKey: string;
            keyConfigured?: boolean;
            scene: "general-ocr" | "formula-recognition" | "table-recognition";
            pagesPerRequest: number;
            enabled: boolean;
        };
    };
}
export declare function PlatformWorkspace({ value, onSave, onConfigureStorage, }: {
    value: PlatformPreferences;
    onSave: (next: PlatformPreferences) => Promise<PlatformPreferences | void> | PlatformPreferences | void;
    onConfigureStorage?: () => void;
}): import("react").JSX.Element;
export declare function AdministratorDirectory({ users, enabledIds, protectedIds, onSave, }: {
    users: DirectoryUser[];
    enabledIds: string[];
    protectedIds: string[];
    onSave: (id: string, enabled: boolean) => Promise<void> | void;
}): import("react").JSX.Element;
export declare function CapacityDirectory({ entries, onSave, }: {
    entries: {
        id: string;
        name: string;
        used: number;
        capacity: number;
    }[];
    onSave: (id: string, gigabytes: number, expectedBytes: number) => Promise<void> | void;
}): import("react").JSX.Element;
export declare function PlatformReset({ canReset, confirmation, onReset, }: {
    canReset: boolean;
    confirmation?: string;
    onReset: () => Promise<void> | void;
}): import("react").JSX.Element;
