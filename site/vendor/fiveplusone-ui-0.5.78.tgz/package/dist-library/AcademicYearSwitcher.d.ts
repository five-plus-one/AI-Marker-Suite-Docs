/** AcademicYearSwitcher - 从课栈 layout/AcademicYearSwitcher 提取
 *
 * 两级选择：先选年级，再选学期。可作为年级筛选、学期切换等通用场景。
 */
export interface AcademicYear {
    id: string;
    grade: string;
    term: string;
    label: string;
}
export interface AcademicYearSwitcherProps {
    years: AcademicYear[];
    value: string;
    onChange: (id: string) => void;
    /** 紧凑模式只显示文字 */
    compact?: boolean;
    /** 学期标签，默认「学期」。 */
    termLabel?: string;
}
export declare function AcademicYearSwitcher({ years, value, onChange, compact, termLabel, }: AcademicYearSwitcherProps): import("react").JSX.Element;
