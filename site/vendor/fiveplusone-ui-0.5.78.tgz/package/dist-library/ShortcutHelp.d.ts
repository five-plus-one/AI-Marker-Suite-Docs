/** ShortcutHelp - 从课栈 keyboard/ShortcutHelpOverlay 提取
 *
 * 快捷键参考面板：按分类列出组合键与说明，点击遮罩或 Esc 关闭。
 * 同时提供 useShortcutHelp 需要的受控开关。
 */
import { type ReactNode } from "react";
export interface ShortcutItem {
    /** 组合键，例如 "Ctrl K" 或 "⌘ K" */
    keys: string;
    description: string;
}
export interface ShortcutCategory {
    id: string;
    label: string;
    items: ShortcutItem[];
}
export interface ShortcutHelpProps {
    open: boolean;
    onClose: () => void;
    categories: ShortcutCategory[];
    title?: string;
    /** 面板底部附加说明 */
    footnote?: ReactNode;
}
export declare function ShortcutHelp({ open, onClose, categories, title, footnote, }: ShortcutHelpProps): import("react").ReactPortal | null;
