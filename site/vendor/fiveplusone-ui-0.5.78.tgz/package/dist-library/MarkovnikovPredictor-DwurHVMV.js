import { jsxs as o, jsx as e, Fragment as P } from "react/jsx-runtime";
import { memo as E, useState as u } from "react";
const v = [
  {
    id: "propene",
    name: "丙烯",
    formula: "CH₃CH=CH₂",
    c1: {
      label: "CH₃CH",
      hydrogens: 1,
      cationClassIfPositive: "secondary"
    },
    c2: {
      label: "CH₂",
      hydrogens: 2,
      cationClassIfPositive: "primary"
    }
  },
  {
    id: "isobutylene",
    name: "2-甲基丙烯（异丁烯）",
    formula: "(CH₃)₂C=CH₂",
    c1: {
      label: "(CH₃)₂C",
      hydrogens: 0,
      cationClassIfPositive: "tertiary"
    },
    c2: {
      label: "CH₂",
      hydrogens: 2,
      cationClassIfPositive: "primary"
    }
  },
  {
    id: "but-1-ene",
    name: "1-丁烯",
    formula: "CH₃CH₂CH=CH₂",
    c1: {
      label: "CH₃CH₂CH",
      hydrogens: 1,
      cationClassIfPositive: "secondary"
    },
    c2: {
      label: "CH₂",
      hydrogens: 2,
      cationClassIfPositive: "primary"
    }
  },
  {
    id: "2-methylbut-2-ene",
    name: "2-甲基-2-丁烯",
    formula: "(CH₃)₂C=CHCH₃",
    c1: {
      label: "(CH₃)₂C",
      hydrogens: 0,
      cationClassIfPositive: "tertiary"
    },
    c2: {
      label: "CHCH₃",
      hydrogens: 1,
      cationClassIfPositive: "secondary"
    }
  }
], p = [
  { id: "hbr", name: "HBr", x: "Br", peroxideEffect: !0 },
  { id: "hcl", name: "HCl", x: "Cl", peroxideEffect: !1 },
  { id: "hi", name: "HI", x: "I", peroxideEffect: !1 }
], g = {
  primary: "伯碳正离子 (1°)",
  secondary: "仲碳正离子 (2°)",
  tertiary: "叔碳正离子 (3°)"
}, B = {
  primary: 1,
  secondary: 2,
  tertiary: 3
}, t = "var(--accent)";
function O(a) {
  const m = {
    hOn: "c1",
    cationCarbon: a.c2,
    hCarbon: a.c1,
    cationClass: a.c2.cationClassIfPositive
  }, c = {
    hOn: "c2",
    cationCarbon: a.c1,
    hCarbon: a.c2,
    cationClass: a.c1.cationClassIfPositive
  };
  return { pathA: m, pathB: c };
}
function $(a, m, c) {
  const C = c === "c1" ? `C(${m})` : "CH", n = c === "c2" ? `C(${m})` : "CH", x = a.c1.label.replace(/C$/, C).replace(/CH$/, C), s = a.c2.label.replace(/C$/, n).replace(/CH₂$/, "CH").replace(/CH$/, n);
  return `${x}—${s}`;
}
function S() {
  const [a, m] = u(v[0].id), [c, C] = u(p[0].id), [n, x] = u(!1), s = v.find((r) => r.id === a) ?? v[0], f = p.find((r) => r.id === c) ?? p[0], { pathA: i, pathB: h } = O(s), d = B[i.cationClass] >= B[h.cationClass] ? i : h, y = d === i ? h : i, b = n && f.peroxideEffect, A = (b ? y : d).cationCarbon === s.c1 ? "c1" : "c2", H = $(s, f.x, A), w = n && !f.peroxideEffect;
  function k(r, l, N) {
    const I = r === d;
    return /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg border p-3",
        style: {
          borderColor: N ? t : "var(--line)",
          background: N ? "var(--accent-weak)" : "var(--bg-muted)"
        },
        children: [
          /* @__PURE__ */ e(
            "div",
            {
              className: "mb-1 text-sm font-semibold",
              style: { color: "var(--ink)" },
              children: l
            }
          ),
          /* @__PURE__ */ o("div", { className: "text-xs", style: { color: "var(--ink-soft)" }, children: [
            "H⁺ 加到",
            " ",
            /* @__PURE__ */ e("span", { className: "font-mono", children: r.hOn === "c1" ? s.c1.label : s.c2.label })
          ] }),
          /* @__PURE__ */ o("div", { className: "mt-1 text-sm", style: { color: "var(--ink)" }, children: [
            "→ 生成",
            " ",
            /* @__PURE__ */ e("span", { className: "font-semibold", children: g[r.cationClass] })
          ] }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "mt-1 text-xs",
              style: { color: I ? t : "var(--ink-soft)" },
              children: I ? "更稳定（超共轭 / 诱导效应更强）" : "较不稳定"
            }
          )
        ]
      }
    );
  }
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-bold", style: { color: "var(--ink)" }, children: "马氏规则加成预测" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm", style: { color: "var(--ink-soft)" }, children: "选择不对称烯烃与卤化氢 HX，比较两条加成路径所生成碳正离子的稳定性， 判定主产物。马氏规则：H 加到含氢较多的双键碳，X 加到含氢较少的碳， 生成更稳定的碳正离子。开启“过氧化物存在”后，HBr 走自由基加成生成反马氏产物。" }),
    /* @__PURE__ */ o("div", { className: "mt-4 grid gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e(
          "label",
          {
            className: "block text-xs font-medium",
            style: { color: "var(--ink-soft)" },
            children: "选择烯烃"
          }
        ),
        /* @__PURE__ */ e("div", { className: "mt-1 flex flex-wrap gap-2", children: v.map((r) => {
          const l = r.id === a;
          return /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => m(r.id),
              className: "rounded-lg border px-2 py-1 text-xs transition-colors",
              style: {
                borderColor: l ? t : "var(--line)",
                background: l ? t : "var(--bg-muted)",
                color: l ? "white" : "var(--ink)"
              },
              children: r.name
            },
            r.id
          );
        }) })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e(
          "label",
          {
            className: "block text-xs font-medium",
            style: { color: "var(--ink-soft)" },
            children: "选择卤化氢 HX"
          }
        ),
        /* @__PURE__ */ e("div", { className: "mt-1 flex flex-wrap gap-2", children: p.map((r) => {
          const l = r.id === c;
          return /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => C(r.id),
              className: "rounded-lg border px-3 py-1 text-xs font-mono transition-colors",
              style: {
                borderColor: l ? t : "var(--line)",
                background: l ? t : "var(--bg-muted)",
                color: l ? "white" : "var(--ink)"
              },
              children: r.name
            },
            r.id
          );
        }) })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "mt-4 flex items-center gap-3", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          role: "switch",
          "aria-checked": n,
          onClick: () => x((r) => !r),
          className: "relative h-6 w-11 rounded-full transition-colors",
          style: { background: n ? t : "var(--line)" },
          children: /* @__PURE__ */ e(
            "span",
            {
              className: "absolute top-0.5 h-5 w-5 rounded-full bg-[var(--fp-surface)] transition-transform",
              style: {
                transform: n ? "translateX(22px)" : "translateX(2px)"
              }
            }
          )
        }
      ),
      /* @__PURE__ */ e("span", { className: "text-sm", style: { color: "var(--ink)" }, children: "过氧化物存在（ROOR，自由基引发剂）" })
    ] }),
    w && /* @__PURE__ */ o(
      "div",
      {
        className: "mt-2 rounded-lg border px-3 py-2 text-xs",
        style: {
          borderColor: "#f59e0b",
          background: "rgba(245,158,11,0.08)",
          color: "var(--color-warning)"
        },
        children: [
          "注意：过氧化物效应（反马氏自由基加成）仅对 ",
          /* @__PURE__ */ e("strong", { children: "HBr" }),
          " 适用。",
          f.name,
          " 仍按马氏规则进行离子型加成，开关不影响产物。"
        ]
      }
    ),
    /* @__PURE__ */ e(
      "div",
      {
        className: "mt-4 rounded-lg border p-3",
        style: { borderColor: "var(--line)", background: "var(--bg-muted)" },
        children: /* @__PURE__ */ o(
          "svg",
          {
            viewBox: "0 0 480 70",
            className: "w-full",
            role: "img",
            "aria-label": "加成反应总览",
            children: [
              /* @__PURE__ */ e(
                "text",
                {
                  x: "8",
                  y: "40",
                  fontSize: "16",
                  fontFamily: "monospace",
                  fill: "var(--ink)",
                  children: s.formula
                }
              ),
              /* @__PURE__ */ e("text", { x: "170", y: "40", fontSize: "16", fill: "var(--ink-soft)", children: "+" }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: "190",
                  y: "40",
                  fontSize: "16",
                  fontFamily: "monospace",
                  fill: "var(--ink)",
                  children: f.name
                }
              ),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: "250",
                  y1: "35",
                  x2: "320",
                  y2: "35",
                  stroke: t,
                  strokeWidth: "2"
                }
              ),
              /* @__PURE__ */ e("polygon", { points: "320,35 312,31 312,39", fill: t }),
              b && /* @__PURE__ */ e("text", { x: "252", y: "26", fontSize: "11", fill: t, children: "ROOR" }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: "330",
                  y: "40",
                  fontSize: "16",
                  fontFamily: "monospace",
                  fill: t,
                  children: H
                }
              )
            ]
          }
        )
      }
    ),
    b ? /* @__PURE__ */ o(
      "div",
      {
        className: "mt-4 rounded-lg border p-3",
        style: { borderColor: t, background: "rgba(37,99,235,0.06)" },
        children: [
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-sm font-semibold",
              style: { color: "var(--ink)" },
              children: "自由基链式加成机理（过氧化物效应）"
            }
          ),
          /* @__PURE__ */ o(
            "ul",
            {
              className: "mt-1 list-disc pl-5 text-xs",
              style: { color: "var(--ink-soft)" },
              children: [
                /* @__PURE__ */ e("li", { children: "过氧化物受热分解产生自由基，夺取 H—Br 生成 Br·。" }),
                /* @__PURE__ */ e("li", { children: "Br· 先加到双键上含氢较多的碳，生成更稳定的碳自由基（取向与 H⁺ 相反）。" }),
                /* @__PURE__ */ e("li", { children: "该碳自由基再夺取 H 完成链增长，结果 Br 加到含氢较多的碳 → 反马氏产物。" })
              ]
            }
          )
        ]
      }
    ) : /* @__PURE__ */ o("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
      k(i, "路径 A", i === d),
      k(h, "路径 B", h === d)
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "mt-4 rounded-lg border p-3",
        style: { borderColor: t, background: "rgba(37,99,235,0.06)" },
        children: [
          /* @__PURE__ */ e("div", { className: "text-sm font-semibold", style: { color: t }, children: b ? "主产物（反马氏，自由基加成）" : "主产物（马氏规则，离子型加成）" }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "mt-1 font-mono text-base",
              style: { color: "var(--ink)" },
              children: H
            }
          ),
          /* @__PURE__ */ e(
            "p",
            {
              className: "mt-2 text-xs leading-relaxed",
              style: { color: "var(--ink-soft)" },
              children: b ? /* @__PURE__ */ o(P, { children: [
                "在过氧化物存在下，",
                f.name,
                " 通过自由基链式机理加成：Br 加到含氢",
                /* @__PURE__ */ e("strong", { children: "较多" }),
                "的碳上，与马氏规则相反，故得到反马氏产物。 （此效应仅对 HBr 成立；HCl 键太强、HI 键太弱，均无过氧化物效应。）"
              ] }) : /* @__PURE__ */ o(P, { children: [
                "比较两条路径：",
                d === i ? "路径 A" : "路径 B",
                " ",
                "生成",
                g[d.cationClass],
                "，比",
                y === i ? "路径 A" : "路径 B",
                " 的",
                g[y.cationClass],
                "更稳定。 因此 H⁺ 优先加到含氢",
                /* @__PURE__ */ e("strong", { children: "较多" }),
                "的碳，X⁻ 加到含氢",
                /* @__PURE__ */ e("strong", { children: "较少" }),
                "的碳， 符合马氏规则，生成更稳定碳正离子对应的主产物。"
              ] })
            }
          )
        ]
      }
    )
  ] });
}
const F = E(S);
export {
  F as default
};
