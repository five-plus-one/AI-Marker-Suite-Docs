import { jsxs as o, jsx as e, Fragment as V } from "react/jsx-runtime";
import { memo as B, useState as C } from "react";
const N = "var(--fp-primary)", p = "#dc2626", Y = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", j = "#0f766e", T = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", q = "var(--line)", z = 480, F = 200, g = 44, v = 24, w = z - 2 * g, P = F - 2 * v;
function X(t) {
  const d = [
    0.9999999999998099,
    676.5203681218851,
    -1259.1392167224028,
    771.3234287776531,
    -176.6150291621406,
    12.507343278686905,
    -0.13857109526572012,
    9984369578019572e-21,
    15056327351493116e-23
  ];
  if (t < 0.5) return Math.PI / (Math.sin(Math.PI * t) * X(1 - t));
  t -= 1;
  let l = d[0];
  for (let c = 1; c < 9; c++) l += d[c] / (t + c);
  const n = t + 7 + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(n, t + 0.5) * Math.exp(-n) * l;
}
function R(t) {
  return Math.log(Math.abs(X(t)));
}
function G(t, a) {
  if (t <= 0) return 0;
  const d = a / 2, l = (d - 1) * Math.log(t) - t / 2 - d * Math.log(2) - R(d);
  return Math.exp(l);
}
function Q(t, a) {
  if (a < 0 || a === 0) return 0;
  if (a < t + 1) {
    let d = 1 / t, l = d;
    for (let n = 1; n <= 300 && (d *= a / (t + n), l += d, !(Math.abs(d) < Math.abs(l) * 1e-12)); n++)
      ;
    return l * Math.exp(-a + t * Math.log(a) - R(t));
  } else {
    let d = 1e-30, l = d, n = 1 - (t + 1 + a);
    Math.abs(n) < 1e-30 && (n = 1e-30), n = 1 / n, d = n;
    for (let c = 1; c <= 300; c++) {
      const r = c * (t - c), h = -(t + 2 * c + 1 - a);
      n = h + r * n, l = h + r / l, Math.abs(n) < 1e-30 && (n = 1e-30), Math.abs(l) < 1e-30 && (l = 1e-30), n = 1 / n;
      const i = n * l;
      if (d *= i, Math.abs(i - 1) < 1e-12) break;
    }
    return 1 - Math.exp(-a + t * Math.log(a) - R(t)) / d;
  }
}
function L(t, a) {
  return t <= 0 ? 0 : Q(a / 2, t / 2);
}
function A(t, a) {
  if (t <= 0) return 0;
  if (t >= 1) return 1 / 0;
  const d = a, l = 2 * a;
  let n = Math.max(0.01, d + Math.sqrt(l) * (t > 0.5 ? 2 : -2)), c = 0, r = Math.max(100, a * 5);
  for (; L(r, a) < t; ) r *= 2;
  for (let h = 0; h < 120; h++) {
    const i = (c + r) / 2;
    if (L(i, a) < t ? c = i : r = i, r - c < 1e-9) break;
  }
  return n = (c + r) / 2, n;
}
function Z(t, a, d, l, n) {
  const c = a - 1, r = c * t / d;
  let h, i, f;
  if (l === "left")
    h = L(r, c), i = 0, f = A(n, c);
  else if (l === "right")
    h = 1 - L(r, c), i = A(1 - n, c), f = 1 / 0;
  else {
    const s = L(r, c), y = 1 - L(r, c);
    h = 2 * Math.min(s, y), i = A(n / 2, c), f = A(1 - n / 2, c);
  }
  const u = l === "left" ? r < f : l === "right" ? r > i : r < i || r > f;
  return {
    chi2Stat: r,
    df: c,
    pValue: Math.max(0, Math.min(1, h)),
    criticalLow: i,
    criticalHigh: f,
    reject: u
  };
}
function J(t, a, d, l) {
  const c = [];
  for (let r = 0; r <= 300; r++) {
    const h = t + r / 300 * (a - t), i = G(h, d), f = g + (h - t) / (a - t) * w, u = F - v - i / l * P * 0.88;
    c.push(`${r === 0 ? "M" : "L"}${f.toFixed(2)},${u.toFixed(2)}`);
  }
  return c.join(" ");
}
function _(t, a, d, l, n, c) {
  const r = Math.max(d, t), h = Math.min(l, a);
  if (r >= h) return "";
  const i = (x) => g + (x - t) / (a - t) * w, f = (x) => F - v - x / c * P * 0.88, u = F - v, s = 200, y = [`M${i(r).toFixed(2)},${u}`];
  for (let x = 0; x <= s; x++) {
    const $ = r + x / s * (h - r), S = G($, n);
    y.push(`L${i($).toFixed(2)},${f(S).toFixed(2)}`);
  }
  return y.push(`L${i(h).toFixed(2)},${u}`, "Z"), y.join(" ");
}
function D({
  label: t,
  value: a,
  min: d,
  max: l,
  step: n,
  onChange: c,
  unit: r
}) {
  return /* @__PURE__ */ o("div", { className: "space-y-0.5", children: [
    /* @__PURE__ */ e("label", { className: "block text-[12px] font-semibold text-[var(--ink)]", children: t }),
    /* @__PURE__ */ o("div", { className: "flex items-center gap-1", children: [
      /* @__PURE__ */ e(
        "input",
        {
          type: "number",
          value: a,
          min: d,
          max: l,
          step: n,
          onChange: (h) => {
            const i = parseFloat(h.target.value);
            isNaN(i) || c(Math.min(l, Math.max(d, i)));
          },
          className: "w-full rounded-md border border-[var(--line)] bg-[var(--bg-elevated)] px-2 py-1 text-[13px] font-mono text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent"
        }
      ),
      r && /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)] whitespace-nowrap", children: r })
    ] })
  ] });
}
function O({
  label: t,
  value: a,
  min: d,
  max: l,
  step: n,
  onChange: c,
  fmt: r,
  color: h
}) {
  const i = r ? r(a) : String(a);
  return /* @__PURE__ */ o("div", { className: "space-y-1", children: [
    /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: t }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded px-2 py-0.5 text-[12px] font-mono font-bold",
          style: {
            background: (h ?? N) + "22",
            color: h ?? N
          },
          children: i
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: d,
        max: l,
        step: n,
        value: a,
        onChange: (f) => c(Number(f.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: h ?? N }
      }
    )
  ] });
}
function K({ result: t, tail: a }) {
  const { chi2Stat: d, df: l, criticalLow: n, criticalHigh: c } = t, r = Math.max(l - 2, 0.1), h = Math.max(
    A(0.999, l),
    d * 1.1,
    c * 1.1,
    2
  ), i = 0, f = G(r, l), u = f > 0 ? f : 1, s = (k) => g + (Math.max(i, Math.min(h, k)) - i) / (h - i) * w, y = (k) => F - v - k / u * P * 0.88, x = F - v, $ = J(i, h, l, u), S = a === "left" || a === "two" ? _(i, h, i, n, l, u) : "", m = a === "right" || a === "two" ? _(i, h, c, h, l, u) : "", b = s(d), M = y(G(Math.max(0.01, Math.min(h, d)), l)), H = t.reject ? p : N, I = l <= 10 ? 2 : l <= 30 ? 5 : l <= 60 ? 10 : 20, E = [];
  for (let k = 0; k <= h; k += I) E.push(k);
  return /* @__PURE__ */ o(
    "svg",
    {
      viewBox: `0 0 ${z} ${F}`,
      className: "w-full rounded-lg border border-[var(--line)]",
      children: [
        /* @__PURE__ */ e(
          "rect",
          {
            x: g,
            y: v,
            width: w,
            height: P,
            fill: "var(--bg-muted)",
            stroke: q
          }
        ),
        E.map((k) => {
          const W = s(k);
          return W < g || W > g + w ? null : /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: W,
                y1: x,
                x2: W,
                y2: x + 3,
                stroke: "var(--ink-faint)"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: W,
                y: x + 12,
                fontSize: "8",
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                children: k
              }
            )
          ] }, k);
        }),
        S && /* @__PURE__ */ e("path", { d: S, fill: p, opacity: 0.2 }),
        m && /* @__PURE__ */ e("path", { d: m, fill: p, opacity: 0.2 }),
        /* @__PURE__ */ e("path", { d: $, fill: "none", stroke: N, strokeWidth: "2" }),
        (a === "left" || a === "two") && isFinite(n) && n > 0 && /* @__PURE__ */ o(V, { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: s(n),
              y1: v,
              x2: s(n),
              y2: x,
              stroke: p,
              strokeDasharray: "4 3",
              strokeWidth: "1.4"
            }
          ),
          /* @__PURE__ */ o(
            "text",
            {
              x: s(n) - 4,
              y: v + 14,
              fontSize: "8",
              textAnchor: "end",
              fill: p,
              fontWeight: "bold",
              children: [
                "χ²α/2=",
                n.toFixed(3)
              ]
            }
          )
        ] }),
        (a === "right" || a === "two") && isFinite(c) && /* @__PURE__ */ o(V, { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: s(c),
              y1: v,
              x2: s(c),
              y2: x,
              stroke: p,
              strokeDasharray: "4 3",
              strokeWidth: "1.4"
            }
          ),
          /* @__PURE__ */ o(
            "text",
            {
              x: s(c) + 4,
              y: v + 14,
              fontSize: "8",
              textAnchor: "start",
              fill: p,
              fontWeight: "bold",
              children: [
                "χ²1-α",
                a === "two" ? "/2" : "",
                "=",
                c.toFixed(3)
              ]
            }
          )
        ] }),
        isFinite(d) && d >= 0 && b >= g && b <= g + w && /* @__PURE__ */ o(V, { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: b,
              y1: v,
              x2: b,
              y2: x,
              stroke: H,
              strokeWidth: "2.2"
            }
          ),
          /* @__PURE__ */ e("circle", { cx: b, cy: M, r: "4.5", fill: H }),
          /* @__PURE__ */ e(
            "polygon",
            {
              points: `${b},${x - 6} ${b - 5},${x + 4} ${b + 5},${x + 4}`,
              fill: H
            }
          ),
          /* @__PURE__ */ o(
            "text",
            {
              x: Math.min(Math.max(b, g + 20), g + w - 20),
              y: v + 24,
              fontSize: "9",
              textAnchor: "middle",
              fill: H,
              fontWeight: "bold",
              children: [
                "χ²=",
                d.toFixed(3)
              ]
            }
          )
        ] }),
        (a === "left" || a === "two") && S && /* @__PURE__ */ e(
          "text",
          {
            x: g + 6,
            y: v + P * 0.55,
            fontSize: "8",
            fill: p,
            opacity: 0.9,
            children: "拒绝域"
          }
        ),
        (a === "right" || a === "two") && m && /* @__PURE__ */ e(
          "text",
          {
            x: g + w - 6,
            y: v + P * 0.55,
            fontSize: "8",
            textAnchor: "end",
            fill: p,
            opacity: 0.9,
            children: "拒绝域"
          }
        ),
        /* @__PURE__ */ o(
          "text",
          {
            x: g + w / 2,
            y: F - 1,
            fontSize: "9",
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            children: [
              "χ²(",
              l,
              ") 统计量"
            ]
          }
        )
      ]
    }
  );
}
function U({ s2: t, n: a, sigma02: d, tail: l, alpha: n, result: c }) {
  const [r, h] = C(!1), { df: i, chi2Stat: f, pValue: u, criticalLow: s, criticalHigh: y, reject: x } = c;
  return /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden", children: [
    /* @__PURE__ */ o(
      "button",
      {
        type: "button",
        onClick: () => h((S) => !S),
        className: "flex w-full items-center justify-between px-4 py-2.5 bg-[var(--bg-muted)] text-left",
        children: [
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "推导步骤展开" }),
          /* @__PURE__ */ e("span", { className: "text-[16px] text-[var(--ink-soft)]", children: r ? "▲" : "▼" })
        ]
      }
    ),
    r && /* @__PURE__ */ o("div", { className: "px-4 py-3 space-y-3 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 1：建立假设" }),
        /* @__PURE__ */ o("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "H₀: σ² = σ₀² = ",
          d,
          "　",
          "|",
          "　",
          l === "left" ? "H₁: σ² < σ₀²" : l === "right" ? "H₁: σ² > σ₀²" : "H₁: σ² ≠ σ₀²"
        ] })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 2：确认检验条件" }),
        /* @__PURE__ */ o("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "正态总体，方差待检验",
          `
`,
          "在 H₀ 下，统计量 χ² = (n−1)S²/σ₀² 服从 χ²(n−1)",
          `
`,
          "自由度 df = n − 1 = ",
          a,
          " − 1 = ",
          i
        ] })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 3：计算 χ² 统计量" }),
        /* @__PURE__ */ o("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "χ² = (n−1) × S² / σ₀²",
          `
`,
          "　　",
          "= ",
          i,
          " × ",
          t,
          " / ",
          d,
          `
`,
          "　　",
          "= ",
          (i * t).toFixed(4),
          " / ",
          d,
          `
`,
          "　　",
          "=",
          " ",
          /* @__PURE__ */ e("span", { style: { color: N, fontWeight: 700 }, children: f.toFixed(4) })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 4：确定临界值与拒绝域" }),
        /* @__PURE__ */ o("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "显著性水平 α = ",
          n,
          "，df = ",
          i,
          `
`,
          l === "left" && `拒绝域：χ² < χ²α(${i}) = ${y.toFixed(4)}（左尾）`,
          l === "right" && `拒绝域：χ² > χ²1-α(${i}) = ${s.toFixed(4)}（右尾）`,
          l === "two" && `拒绝域：χ² < ${s.toFixed(4)} 或 χ² > ${y.toFixed(4)}（双尾）`
        ] })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 5：计算 p 值" }),
        /* @__PURE__ */ o("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          l === "left" && `p = P(χ²(${i}) ≤ ${f.toFixed(4)}) = `,
          l === "right" && `p = P(χ²(${i}) ≥ ${f.toFixed(4)}) = `,
          l === "two" && `p = 2 × min{P(χ²(${i}) ≤ χ²), P(χ²(${i}) ≥ χ²)} = `,
          /* @__PURE__ */ e("span", { style: { color: N, fontWeight: 700 }, children: u.toFixed(4) })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 6：作出结论" }),
        /* @__PURE__ */ e(
          "div",
          {
            className: "rounded px-3 py-2 font-semibold",
            style: {
              background: x ? Y : T,
              color: x ? p : j
            },
            children: x ? `p = ${u.toFixed(4)} < α = ${n}，拒绝 H₀，认为方差与 σ₀² 有显著差异` : `p = ${u.toFixed(4)} ≥ α = ${n}，不拒绝 H₀，无证据表明方差有显著变化`
          }
        )
      ] })
    ] })
  ] });
}
function ee() {
  const [t, a] = C(1.44), [d, l] = C(16), [n, c] = C(1), [r, h] = C("two"), [i, f] = C(0.05), s = d >= 2 && t > 0 && n > 0 ? Z(t, d, n, r, i) : null, y = [
    { key: "left", label: "左尾", h1: "H₁: σ² < σ₀²" },
    { key: "two", label: "双尾", h1: "H₁: σ² ≠ σ₀²" },
    { key: "right", label: "右尾", h1: "H₁: σ² > σ₀²" }
  ], x = [0.01, 0.05, 0.1], $ = s ? Math.min(s.pValue, 1) * 100 : 0, S = i * 100;
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "正态总体方差假设检验（χ² 检验）" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "输入样本方差 S²、样本量 n、原假设方差 σ₀²，实时计算 χ² 统计量与检验结论。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2 text-[12px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "统计量：" }),
      /* @__PURE__ */ e("span", { className: "font-mono ml-1", children: "χ² = (n−1)S² / σ₀²" }),
      /* @__PURE__ */ e("span", { className: "ml-2 text-[11px]", children: "在 H₀ 下服从 χ²(n−1)" })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] p-3 space-y-3", children: [
      /* @__PURE__ */ o("div", { className: "grid grid-cols-3 gap-3", children: [
        /* @__PURE__ */ e(
          D,
          {
            label: "样本方差 S²",
            value: t,
            min: 1e-3,
            max: 100,
            step: 0.01,
            onChange: a
          }
        ),
        /* @__PURE__ */ e(
          D,
          {
            label: "假设方差 σ₀²",
            value: n,
            min: 1e-3,
            max: 100,
            step: 0.01,
            onChange: c
          }
        ),
        /* @__PURE__ */ e(
          D,
          {
            label: "样本量 n",
            value: d,
            min: 2,
            max: 500,
            step: 1,
            onChange: l
          }
        )
      ] }),
      /* @__PURE__ */ e(
        O,
        {
          label: "S²/σ₀² 比值（快速调整）",
          value: parseFloat((t / n).toFixed(3)),
          min: 0.05,
          max: 10,
          step: 0.05,
          onChange: (m) => a(parseFloat((m * n).toFixed(4))),
          fmt: (m) => `${m.toFixed(2)}x`
        }
      ),
      /* @__PURE__ */ e(
        O,
        {
          label: "样本量 n（快速调整）",
          value: d,
          min: 2,
          max: 100,
          step: 1,
          onChange: l,
          fmt: (m) => `n = ${m}, df = ${m - 1}`
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "grid grid-cols-2 gap-3", children: [
      /* @__PURE__ */ o("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "检验方向" }),
        /* @__PURE__ */ e("div", { className: "flex flex-col gap-1", children: y.map(({ key: m, label: b, h1: M }) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            onClick: () => h(m),
            className: `rounded-lg px-3 py-1.5 text-left text-[12px] font-medium transition-colors ${r === m ? "text-white" : "bg-[var(--bg-elevated)] border border-[var(--line)] text-[var(--ink-soft)] hover:bg-[var(--bg-muted)]"}`,
            style: r === m ? { background: N } : {},
            children: [
              /* @__PURE__ */ e("span", { className: "font-semibold", children: b }),
              /* @__PURE__ */ e("span", { className: "ml-2 font-mono text-[11px] opacity-80", children: M })
            ]
          },
          m
        )) })
      ] }),
      /* @__PURE__ */ o("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "显著性水平 α" }),
        /* @__PURE__ */ e("div", { className: "flex flex-col gap-1", children: x.map((m) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            onClick: () => f(m),
            className: `rounded-lg px-3 py-1.5 text-[12px] font-mono font-semibold transition-colors ${i === m ? "text-white" : "bg-[var(--bg-elevated)] border border-[var(--line)] text-[var(--ink-soft)] hover:bg-[var(--bg-muted)]"}`,
            style: i === m ? { background: N } : {},
            children: [
              "α = ",
              m
            ]
          },
          m
        )) }),
        /* @__PURE__ */ o("div", { className: "rounded-md bg-[var(--bg-muted)] px-2 py-1.5 text-[11px] leading-snug text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "当前参数" }),
          /* @__PURE__ */ e("br", {}),
          "S² / σ₀² = ",
          n > 0 ? (t / n).toFixed(3) : "—",
          /* @__PURE__ */ e("br", {}),
          "df = n−1 = ",
          d - 1,
          s && /* @__PURE__ */ o(V, { children: [
            /* @__PURE__ */ e("br", {}),
            "χ² =",
            " ",
            /* @__PURE__ */ e(
              "span",
              {
                className: "font-bold",
                style: { color: s.reject ? p : N },
                children: s.chi2Stat.toFixed(4)
              }
            )
          ] })
        ] })
      ] })
    ] }),
    s && /* @__PURE__ */ e(K, { result: s, tail: r }),
    s && /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-3",
        style: {
          borderColor: s.reject ? p : j,
          background: s.reject ? Y : T
        },
        children: [
          /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "text-[14px] font-bold",
                style: { color: s.reject ? p : j },
                children: s.reject ? "拒绝 H₀" : "不拒绝 H₀"
              }
            ),
            /* @__PURE__ */ e(
              "span",
              {
                className: "rounded-full px-3 py-0.5 text-[12px] font-bold text-white",
                style: { background: s.reject ? p : j },
                children: s.reject ? "方差显著变化" : "方差无显著变化"
              }
            )
          ] }),
          /* @__PURE__ */ e("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
            {
              label: "χ² 统计量",
              val: s.chi2Stat.toFixed(4),
              color: s.reject ? p : N
            },
            {
              label: "p 值",
              val: s.pValue < 1e-4 ? "< 0.0001" : s.pValue.toFixed(4),
              color: s.pValue < i ? p : j
            },
            {
              label: r === "left" ? "左临界值 χ²α" : r === "right" ? "右临界值 χ²1-α" : "临界值（双）",
              val: r === "left" ? s.criticalHigh.toFixed(4) : r === "right" ? s.criticalLow.toFixed(4) : `${s.criticalLow.toFixed(3)} / ${s.criticalHigh.toFixed(3)}`,
              color: p
            },
            {
              label: "自由度 df",
              val: String(s.df),
              color: N
            }
          ].map(({ label: m, val: b, color: M }) => /* @__PURE__ */ o(
            "div",
            {
              className: "rounded-lg bg-[var(--fp-surface)] bg-opacity-70 p-2 text-center",
              children: [
                /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: m }),
                /* @__PURE__ */ e(
                  "div",
                  {
                    className: "text-[13px] font-extrabold font-mono mt-0.5 break-all",
                    style: { color: M },
                    children: b
                  }
                )
              ]
            },
            m
          )) }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[12px] leading-relaxed",
              style: { color: s.reject ? p : j },
              children: s.reject ? /* @__PURE__ */ o(V, { children: [
                "在 α = ",
                i,
                " 水平下，p = ",
                s.pValue.toFixed(4),
                " <",
                " ",
                i,
                "， 有统计上的显著证据拒绝 H₀，认为总体方差与 σ₀² =",
                " ",
                n,
                " 有显著差异。"
              ] }) : /* @__PURE__ */ o(V, { children: [
                "在 α = ",
                i,
                " 水平下，p = ",
                s.pValue.toFixed(4),
                " ≥ ",
                i,
                "， 没有足够证据拒绝 H₀，无法认为总体方差与 σ₀² = ",
                n,
                " ",
                "有显著差异。"
              ] })
            }
          )
        ]
      }
    ),
    s && /* @__PURE__ */ o("div", { className: "space-y-1", children: [
      /* @__PURE__ */ o("div", { className: "flex items-center justify-between text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "p 值直观位置" }),
        /* @__PURE__ */ o("span", { style: { color: p }, children: [
          "α = ",
          i
        ] })
      ] }),
      /* @__PURE__ */ o(
        "div",
        {
          className: "relative h-5 w-full rounded-full overflow-hidden",
          style: { background: T },
          children: [
            /* @__PURE__ */ e(
              "div",
              {
                className: "absolute top-0 h-full w-0.5",
                style: { left: `${S}%`, background: p, zIndex: 2 }
              }
            ),
            /* @__PURE__ */ e(
              "div",
              {
                className: "h-full rounded-full transition-all duration-300",
                style: {
                  width: `${$}%`,
                  background: s.reject ? p : j,
                  opacity: 0.55
                }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ o("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "0" }),
        /* @__PURE__ */ o("span", { style: { color: p }, children: [
          "α = ",
          i
        ] }),
        /* @__PURE__ */ e("span", { children: "1" })
      ] })
    ] }),
    s && /* @__PURE__ */ e(
      U,
      {
        s2: t,
        n: d,
        sigma02: n,
        tail: r,
        alpha: i,
        result: s
      }
    ),
    /* @__PURE__ */ o("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "典型场景快速加载" }),
      /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-1.5", children: [
        {
          label: "方差增大（右尾）",
          s2: 2,
          n: 20,
          sigma02: 1,
          tail: "right",
          desc: "S²=2, n=20, σ₀²=1"
        },
        {
          label: "方差缩小（左尾）",
          s2: 0.3,
          n: 16,
          sigma02: 1,
          tail: "left",
          desc: "S²=0.3, n=16, σ₀²=1"
        },
        {
          label: "双侧检验（无差异）",
          s2: 1.1,
          n: 30,
          sigma02: 1,
          tail: "two",
          desc: "S²=1.1, n=30, σ₀²=1"
        },
        {
          label: "小样本强信号",
          s2: 5,
          n: 8,
          sigma02: 1,
          tail: "two",
          desc: "S²=5, n=8, σ₀²=1"
        }
      ].map(
        ({ label: m, s2: b, n: M, sigma02: H, tail: I, desc: E }) => /* @__PURE__ */ o(
          "button",
          {
            type: "button",
            onClick: () => {
              a(b), l(M), c(H), h(I);
            },
            className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-2.5 py-1.5 text-left text-[11px] hover:border-[var(--accent)] hover:bg-[var(--accent)] hover:text-white transition-colors",
            children: [
              /* @__PURE__ */ e("div", { className: "font-semibold", children: m }),
              /* @__PURE__ */ e("div", { className: "opacity-70 font-mono", children: E })
            ]
          },
          m
        )
      ) })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "核心思想：" }),
      "方差检验的关键是统计量",
      " ",
      /* @__PURE__ */ e("span", { className: "font-mono text-[var(--ink)]", children: "χ² = (n−1)S²/σ₀²" }),
      " 在 H₀ 为真时服从 χ² 分布。χ² 分布是非负的、右偏分布，均值为 df，方差为 2·df。 当 S² 比 σ₀² 大得多时，χ² 值会落入右侧拒绝域；比 σ₀² 小得多时落入左侧。 增大样本量 n 使分布更集中（均值不变，但峰更尖），临界值之间差距缩小，检验功效提升。"
    ] })
  ] });
}
const ie = B(ee);
export {
  ie as default
};
