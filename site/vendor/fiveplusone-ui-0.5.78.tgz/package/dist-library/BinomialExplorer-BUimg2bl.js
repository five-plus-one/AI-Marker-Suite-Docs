import { jsxs as i, jsx as e, Fragment as X } from "react/jsx-runtime";
import { memo as H, useState as P, useMemo as D } from "react";
const b = "var(--fp-primary)", N = "var(--fp-primary-soft)", v = "#0d9488", A = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", _ = "var(--line)";
function w(o) {
  let n = 0;
  for (let t = 2; t <= o; t++) n += Math.log(t);
  return n;
}
function R(o, n, t) {
  if (t < 0 || t > o) return 0;
  if (n === 0) return t === 0 ? 1 : 0;
  if (n === 1) return t === o ? 1 : 0;
  const s = w(o) - w(t) - w(o - t) + t * Math.log(n) + (o - t) * Math.log(1 - n);
  return Math.exp(s);
}
function $(o, n) {
  if (n < 0) return 0;
  const t = -o + n * Math.log(o) - w(n);
  return Math.exp(t);
}
function B({
  label: o,
  value: n,
  min: t,
  max: s,
  step: a,
  displayValue: d,
  color: r,
  bgColor: p,
  onChange: u
}) {
  return /* @__PURE__ */ i("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ i("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: o }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
          style: { background: p, color: r },
          children: d
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: t,
        max: s,
        step: a,
        value: n,
        onChange: (g) => u(Number(g.target.value)),
        className: "w-full h-1.5 cursor-pointer rounded-full",
        style: { accentColor: r }
      }
    ),
    /* @__PURE__ */ i("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("span", { children: t }),
      /* @__PURE__ */ e("span", { children: s })
    ] })
  ] });
}
const E = 480, T = 200, f = 42, z = 16, m = 16, V = 36;
function L({ data: o, mean: n, color: t, label: s }) {
  const a = E - f - z, d = T - m - V, r = o.length, p = Math.max(...o.map((l) => l.p), 1e-3), u = Math.max(2, a / r * 0.72), g = a / r, C = D(() => [0, 0.25, 0.5, 0.75, 1].map((x) => +(p * x).toFixed(4)).filter((x) => x <= p + 1e-3), [p]), F = (l) => f + (l + 0.5) * g, M = (l) => m + d - l / p * d, k = f + n / (r - 1) * a;
  return /* @__PURE__ */ i(
    "svg",
    {
      viewBox: `0 0 ${E} ${T}`,
      className: "w-full rounded-lg",
      style: { maxHeight: 220 },
      "aria-label": s,
      children: [
        /* @__PURE__ */ e(
          "rect",
          {
            x: f,
            y: m,
            width: a,
            height: d,
            fill: "var(--bg-elevated)",
            stroke: _,
            rx: 2
          }
        ),
        C.map((l) => {
          const x = M(l);
          return /* @__PURE__ */ i("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: f,
                y1: x,
                x2: f + a,
                y2: x,
                stroke: _,
                strokeDasharray: "3 3"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: f - 5,
                y: x + 3,
                fontSize: 9,
                textAnchor: "end",
                fill: "var(--ink-faint)",
                children: l < 0.01 ? l.toExponential(1) : l.toFixed(3)
              }
            )
          ] }, l);
        }),
        n >= 0 && n <= r - 1 && /* @__PURE__ */ i(X, { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: k,
              y1: m,
              x2: k,
              y2: m + d,
              stroke: t,
              strokeWidth: 1.5,
              strokeDasharray: "5 3",
              opacity: 0.7
            }
          ),
          /* @__PURE__ */ i(
            "text",
            {
              x: k + 3,
              y: m + 10,
              fontSize: 9,
              fill: t,
              fontWeight: "600",
              children: [
                "μ=",
                n.toFixed(2)
              ]
            }
          )
        ] }),
        o.map(({ k: l, p: x }) => {
          const S = F(l) - u / 2, c = x / p * d, h = m + d - c;
          return /* @__PURE__ */ e("g", { children: /* @__PURE__ */ e(
            "rect",
            {
              x: S,
              y: h,
              width: u,
              height: c,
              fill: t,
              rx: 1.5,
              opacity: 0.85,
              children: /* @__PURE__ */ i("title", { children: [
                "P(X=",
                l,
                ") = ",
                x.toFixed(6)
              ] })
            }
          ) }, l);
        }),
        o.map(({ k: l }) => {
          const x = r <= 15 ? 1 : r <= 25 ? 2 : 5;
          return l % x !== 0 && l !== r - 1 ? null : /* @__PURE__ */ e(
            "text",
            {
              x: F(l),
              y: m + d + 14,
              fontSize: 9,
              textAnchor: "middle",
              fill: "var(--ink-faint)",
              children: l
            },
            l
          );
        }),
        /* @__PURE__ */ e(
          "text",
          {
            x: f + a / 2,
            y: T - 2,
            fontSize: 10,
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            children: "k（X 的取值）"
          }
        ),
        /* @__PURE__ */ e(
          "text",
          {
            x: 9,
            y: m + d / 2,
            fontSize: 9,
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            transform: `rotate(-90, 9, ${m + d / 2})`,
            children: "P(X=k)"
          }
        )
      ]
    }
  );
}
function y({ label: o, value: n, color: t, bg: s }) {
  return /* @__PURE__ */ i("div", { className: "rounded-lg p-3 text-center", style: { background: s }, children: [
    /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)] leading-snug", children: o }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "mt-1 text-[18px] font-extrabold font-mono",
        style: { color: t },
        children: n
      }
    )
  ] });
}
function W() {
  const [o, n] = P("binomial"), [t, s] = P(10), [a, d] = P(0.5), [r, p] = P(3), u = D(() => Array.from({ length: t + 1 }, (c, h) => ({
    k: h,
    p: R(t, a, h)
  })), [t, a]), g = t * a, C = t * a * (1 - a), F = Math.sqrt(C), M = Math.max(
    20,
    Math.ceil(r + 4 * Math.sqrt(r) + 2)
  ), k = D(() => Array.from({ length: M + 1 }, (c, h) => ({
    k: h,
    p: $(r, h)
  })), [r, M]), l = r, x = r, S = Math.sqrt(r);
  return /* @__PURE__ */ i("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ i("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "二项 / 泊松分布探索器" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "拖动滑块实时调参，直观感受参数如何改变分布的形状、中心与离散程度。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "flex rounded-lg overflow-hidden border border-[var(--line)] w-fit", children: [
      { key: "binomial", label: "二项分布 B(n, p)" },
      { key: "poisson", label: "泊松分布 P(λ)" }
    ].map(({ key: c, label: h }) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        onClick: () => n(c),
        className: "px-4 py-2 text-[13px] font-semibold transition-colors " + (o === c ? "text-white" : "text-[var(--ink-soft)] bg-[var(--bg-muted)] hover:bg-[var(--line)]"),
        style: o === c ? { background: c === "binomial" ? b : v } : void 0,
        children: h
      },
      c
    )) }),
    o === "binomial" && /* @__PURE__ */ i(X, { children: [
      /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: [
        /* @__PURE__ */ e(
          B,
          {
            label: "试验次数 n",
            value: t,
            min: 1,
            max: 30,
            step: 1,
            displayValue: String(t),
            color: b,
            bgColor: N,
            onChange: (c) => s(c)
          }
        ),
        /* @__PURE__ */ e(
          B,
          {
            label: "成功概率 p",
            value: a,
            min: 0,
            max: 1,
            step: 0.01,
            displayValue: a.toFixed(2),
            color: b,
            bgColor: N,
            onChange: (c) => d(c)
          }
        )
      ] }),
      /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-2.5 text-[12px] text-[var(--ink-soft)] leading-loose font-mono", children: [
        "P(X=k) = C(n,k)·p^k·(1−p)^(n−k)",
        /* @__PURE__ */ e("span", { className: "ml-2 text-[var(--ink-soft)]", children: "k = 0,1,…,n" })
      ] }),
      /* @__PURE__ */ e(
        L,
        {
          data: u,
          mean: g,
          color: b,
          label: `二项分布 B(${t},${a.toFixed(2)}) 分布律柱状图`
        }
      ),
      /* @__PURE__ */ i("div", { className: "grid grid-cols-3 gap-2", children: [
        /* @__PURE__ */ e(
          y,
          {
            label: "均值 E(X) = np",
            value: g.toFixed(3),
            color: b,
            bg: N
          }
        ),
        /* @__PURE__ */ e(
          y,
          {
            label: "方差 D(X) = np(1−p)",
            value: C.toFixed(3),
            color: b,
            bg: N
          }
        ),
        /* @__PURE__ */ e(
          y,
          {
            label: "标准差 σ = √(np(1−p))",
            value: F.toFixed(3),
            color: b,
            bg: N
          }
        )
      ] }),
      /* @__PURE__ */ e(j, { n: t, p: a, mean: g })
    ] }),
    o === "poisson" && /* @__PURE__ */ i(X, { children: [
      /* @__PURE__ */ e("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: /* @__PURE__ */ e(
        B,
        {
          label: "平均发生次数 λ",
          value: r,
          min: 0.1,
          max: 15,
          step: 0.1,
          displayValue: r.toFixed(1),
          color: v,
          bgColor: A,
          onChange: (c) => p(c)
        }
      ) }),
      /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-2.5 text-[12px] text-[var(--ink-soft)] leading-loose font-mono", children: [
        "P(X=k) = e^(−λ) · λ^k / k!",
        /* @__PURE__ */ e("span", { className: "ml-2 text-[var(--ink-soft)]", children: "k = 0,1,2,…" })
      ] }),
      /* @__PURE__ */ e(
        L,
        {
          data: k,
          mean: l,
          color: v,
          label: `泊松分布 P(λ=${r.toFixed(1)}) 分布律柱状图`
        }
      ),
      /* @__PURE__ */ i("div", { className: "grid grid-cols-3 gap-2", children: [
        /* @__PURE__ */ e(
          y,
          {
            label: "均值 E(X) = λ",
            value: l.toFixed(3),
            color: v,
            bg: A
          }
        ),
        /* @__PURE__ */ e(
          y,
          {
            label: "方差 D(X) = λ",
            value: x.toFixed(3),
            color: v,
            bg: A
          }
        ),
        /* @__PURE__ */ e(
          y,
          {
            label: "标准差 σ = √λ",
            value: S.toFixed(3),
            color: v,
            bg: A
          }
        )
      ] }),
      /* @__PURE__ */ e(I, { lambda: r })
    ] }),
    /* @__PURE__ */ e(q, { tab: o, n: t, p: a, lambda: r })
  ] });
}
function j({ n: o, p: n, mean: t }) {
  const s = Math.abs(n - 0.5) < 0.05, a = n > 0.5, d = n < 0.5;
  let r = "";
  s ? r = "p ≈ 0.5 时分布近似对称（钟形）。" : a ? r = "p > 0.5 时分布左偏（重心靠右），众数在均值右侧。" : d && (r = "p < 0.5 时分布右偏（重心靠左），众数在均值左侧。");
  const p = o >= 20 && n >= 0.1 && n <= 0.9;
  return /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
    /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "直觉：" }),
    /* @__PURE__ */ i("span", { children: [
      "B(",
      o,
      ", ",
      n.toFixed(2),
      ") 的均值为",
      " ",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: t.toFixed(2) }),
      "，即「平均成功次数」。",
      r && " " + r,
      p && " n 较大且 p 适中时，二项分布近似正态分布（中心极限定理）。"
    ] })
  ] });
}
function I({ lambda: o }) {
  const n = o < 1, t = o > 8;
  let s = "";
  return n ? s = "λ 很小时，P(X=0) 很大——事件极少发生，绝大多数时间次数为 0。" : t ? s = "λ 较大时，泊松分布趋近正态分布，形状越来越对称。" : s = "泊松分布的均值与方差相等，都等于 λ——这是泊松分布的标志性性质。", /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
    /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "直觉：" }),
    /* @__PURE__ */ i("span", { children: [
      s,
      " ",
      "泊松分布常用于「单位时间内随机事件发生次数」的建模（如呼叫中心来电、放射性衰变等）。"
    ] })
  ] });
}
function q({
  tab: o,
  n,
  p: t,
  lambda: s
}) {
  const a = n * t, d = o === "binomial" && n >= 20 && t <= 0.1 && Math.abs(a - s) < 0.5, r = o === "poisson" && n >= 20 && t <= 0.1 && Math.abs(a - s) < 0.5;
  return !d && !r ? /* @__PURE__ */ i("div", { className: "rounded-lg border border-dashed border-[var(--line)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
    /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "极限定理：" }),
    "当 n 很大、p 很小且 np = λ 保持不变时，",
    /* @__PURE__ */ e("span", { className: "font-mono", children: " B(n, p) → P(λ)" }),
    "（泊松极限）。 尝试设 n=30, p=0.1，再与 P(λ=3) 对比！"
  ] }) : /* @__PURE__ */ i(
    "div",
    {
      className: "rounded-lg border border-dashed px-3 py-2.5 text-[12px] leading-relaxed",
      style: { borderColor: b, background: N, color: b },
      children: [
        /* @__PURE__ */ e("span", { className: "font-bold", children: "极限定理验证中！" }),
        " 当前 np =",
        " ",
        a.toFixed(2),
        "，接近泊松参数 λ=",
        s.toFixed(1),
        "。 切换到另一个 Tab，你会发现两张图形状几乎一致——这就是「泊松极限定理」的直观体现。"
      ]
    }
  );
}
const K = H(W);
export {
  K as default
};
