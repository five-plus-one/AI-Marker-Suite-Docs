import { type ReactNode, type Ref, type TextareaHTMLAttributes } from "react";
export interface ComposerAttachment {
    id: string;
    name: string;
    status?: "uploading" | "ready" | "error";
    previewUrl?: string;
    error?: string;
}
export interface ChatComposerProps {
    inputProps?: Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, "value" | "onChange" | "ref" | "disabled">;
    sendIcon?: ReactNode;
    stopIcon?: ReactNode;
    attachmentIcon?: ReactNode;
    inputRef?: Ref<HTMLTextAreaElement>;
    value: string;
    onChange: (value: string) => void;
    onSend: (value: string) => void | Promise<void>;
    onStop?: () => void;
    isLoading?: boolean;
    disabled?: boolean;
    disabledReason?: string;
    placeholder?: string;
    quotedText?: string;
    onClearQuote?: () => void;
    attachments?: ComposerAttachment[];
    onRemoveAttachment?: (id: string) => void;
    onFiles?: (files: File[]) => void;
    accept?: string;
    /** Model, thinking, search, context usage and product actions. */
    tools?: ReactNode;
    /** Model and account information, kept separate from message actions. */
    footer?: ReactNode;
    compact?: boolean;
    notice?: ReactNode;
    onComposerInsetChange?: (height: number) => void;
    sendOnEnter?: boolean;
}
/** Controlled draft and upload state allow each workspace to retain its own input. */
export declare function ChatComposer({ inputProps, sendIcon, stopIcon, attachmentIcon, inputRef, value, onChange, onSend, onStop, isLoading, disabled, disabledReason, placeholder, quotedText, onClearQuote, attachments, onRemoveAttachment, onFiles, accept, tools, footer, compact, notice, onComposerInsetChange, sendOnEnter, }: ChatComposerProps): import("react").JSX.Element;
