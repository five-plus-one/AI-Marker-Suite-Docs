import { type ReactNode } from "react";
export interface SearchHit {
    id: string;
    title: string;
    path?: string;
    excerpt?: ReactNode;
    icon?: ReactNode;
    disabled?: boolean;
}
export interface SearchResultsProps {
    query: string;
    onQueryChange: (query: string) => void;
    onSearch: (query: string, signal: AbortSignal) => Promise<SearchHit[]>;
    onOpen: (hit: SearchHit) => void;
    placeholder?: string;
    debounceMs?: number;
}
export declare function SearchResults({ query, onQueryChange, onSearch, onOpen, placeholder, debounceMs, }: SearchResultsProps): import("react").JSX.Element;
