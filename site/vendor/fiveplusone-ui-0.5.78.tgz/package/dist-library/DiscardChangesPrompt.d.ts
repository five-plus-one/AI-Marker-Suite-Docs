export declare function DiscardChangesPrompt({ onContinue, onDiscard }: {
    onContinue: () => void;
    onDiscard: () => void;
}): import("react").JSX.Element;
