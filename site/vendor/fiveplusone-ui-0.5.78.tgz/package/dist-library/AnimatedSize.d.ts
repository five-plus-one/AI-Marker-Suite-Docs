import { type ReactNode } from 'react';
/** Measures intrinsic content, including async loads, without animating the content itself. */
export declare function AnimatedSize({ children, initialHeight, className }: {
    children: ReactNode;
    initialHeight?: number;
    className?: string;
}): import("react").JSX.Element;
