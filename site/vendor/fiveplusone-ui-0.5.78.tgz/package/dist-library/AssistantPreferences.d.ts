import { type ReactNode } from 'react';
export interface AssistantPreferenceValues {
    selectedModelId: string;
    recordModelId: string;
    floatingChatModelId: string;
    defaultImageModelId: string | null;
    imageModeTextModel: string;
    imageModeTextModelFallback: string;
    defaultThinking: boolean;
    defaultThinkingEffort: string;
    defaultSearch: boolean;
    disabledTools: string[];
    globalContext: string;
}
export interface AssistantPreferencesProps {
    value: AssistantPreferenceValues;
    onChange: <K extends keyof AssistantPreferenceValues>(key: K, value: AssistantPreferenceValues[K]) => void;
    models: {
        id: string;
        label: string;
        type?: string;
    }[];
    tools: {
        name: string;
        label: string;
        desc: string;
    }[];
    syncStatus: string;
    providers?: ReactNode;
    initialTab?: 'preferences' | 'models' | 'capabilities';
    children?: ReactNode;
}
/** Account-scoped assistant preferences. Persistence and model availability belong to the host. */
export declare function AssistantPreferences({ value, onChange, models, tools, syncStatus, providers, initialTab, children }: AssistantPreferencesProps): import("react").JSX.Element;
