import type { ReactNode } from 'react';
export interface AuthenticationWindowProps {
    mode?: 'login' | 'task';
    title?: string;
    icon?: ReactNode;
    onClose: () => void;
    onBrowser: () => void;
    onReload: () => void;
    children?: ReactNode;
    className?: string;
    browserPending?: boolean;
}
/** Shared frame for a host-controlled, isolated authorization view. */
export declare function AuthenticationWindow({ mode, title, icon, onClose, onBrowser, onReload, children, className, browserPending }: AuthenticationWindowProps): import("react").JSX.Element;
