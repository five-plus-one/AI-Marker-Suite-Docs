import { jsxs as s, jsx as e, Fragment as w } from "react/jsx-runtime";
import { learningAlpha as W } from "./index.js";
import { memo as q, useState as R, useCallback as B } from "react";
const S = "var(--fp-primary)", J = "var(--fp-primary-soft)", v = "#f97316", X = "#dc2626", O = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", I = "#0f766e", K = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", N = 480, G = 200, y = 36, P = 16, d = 18, Q = 32, E = N - y - P, j = G - d - Q, m = -6, k = 6;
function V(t) {
  return Math.exp(-0.5 * t * t) / Math.sqrt(2 * Math.PI);
}
function _(t, n) {
  return n <= 0 ? 0 : V(t / n) / n;
}
function ee(t) {
  const n = 1 / (1 + 0.2316419 * Math.abs(t)), o = n * (0.31938153 + n * (-0.356563782 + n * (1.781477937 + n * (-1.821255978 + n * 1.330274429)))), l = 1 - V(t) * o;
  return t >= 0 ? l : 1 - l;
}
function te(t, n) {
  return n <= 0 || t <= 0 ? 0 : 2 * (1 - ee(t / n));
}
function ne(t, n) {
  return t <= 0 ? 1 : Math.min(1, n * n / (t * t));
}
function h(t) {
  return y + (t - m) / (k - m) * E;
}
function M(t, n) {
  return d + j - t / n * j;
}
function ie(t, n, o = 300) {
  const x = [];
  for (let l = 0; l <= o; l++) {
    const a = m + l / o * (k - m), i = _(a, t), r = h(a), f = M(i, n);
    x.push(`${l === 0 ? "M" : "L"}${r.toFixed(2)},${f.toFixed(2)}`);
  }
  return x.join(" ");
}
function oe(t, n, o, x = 200) {
  const l = M(0, o), a = [], i = [], r = Math.floor(x * ((-n - m) / (k - m)));
  if (n < -m) {
    const f = h(m);
    i.push(`M${f.toFixed(2)},${l.toFixed(2)}`);
    for (let p = 0; p <= r; p++) {
      const L = m + p / r * (-n - m), b = _(L, t), F = h(L), c = M(b, o);
      i.push(`L${F.toFixed(2)},${c.toFixed(2)}`);
    }
    const $ = h(-n);
    i.push(`L${$.toFixed(2)},${l.toFixed(2)}`), i.push("Z"), a.push(i.join(" "));
  }
  if (n < k) {
    const f = Math.floor(x * ((k - n) / (k - m))), $ = h(n), p = [];
    p.push(`M${$.toFixed(2)},${l.toFixed(2)}`);
    for (let b = 0; b <= f; b++) {
      const F = n + b / f * (k - n), c = _(F, t), A = h(F), D = M(c, o);
      p.push(`L${A.toFixed(2)},${D.toFixed(2)}`);
    }
    const L = h(k);
    p.push(`L${L.toFixed(2)},${l.toFixed(2)}`), p.push("Z"), a.push(p.join(" "));
  }
  return a.join(" ");
}
function H(t) {
  return t >= 1 ? "100.00%" : t < 1e-4 ? "< 0.01%" : (t * 100).toFixed(2) + "%";
}
function z({
  label: t,
  sub: n,
  value: o,
  min: x,
  max: l,
  step: a,
  display: i,
  color: r,
  onChange: f
}) {
  return /* @__PURE__ */ s("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ s("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ s("div", { children: [
        /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: t }),
        /* @__PURE__ */ e("span", { className: "ml-1.5 text-[11px] text-[var(--ink-soft)]", children: n })
      ] }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
          style: { background: W(r, "22"), color: r },
          children: i
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: x,
        max: l,
        step: a,
        value: o,
        onChange: ($) => f(Number($.target.value)),
        className: "w-full h-1.5 cursor-pointer rounded-full",
        style: { accentColor: r }
      }
    )
  ] });
}
function T({
  label: t,
  formula: n,
  value: o,
  color: x,
  bg: l,
  isRatio: a,
  ratio: i
}) {
  const r = a && i !== void 0 ? i >= 100 ? "极松" : i >= 10 ? "很松" : i >= 3 ? "较松" : i >= 1.5 ? "稍松" : "接近紧" : null, f = i !== void 0 ? i >= 10 ? X : i >= 3 ? "#ea580c" : i >= 1.5 ? "#ca8a04" : I : void 0;
  return /* @__PURE__ */ s(
    "div",
    {
      className: "flex items-center justify-between rounded-lg px-3 py-2.5",
      style: { background: l },
      children: [
        /* @__PURE__ */ s("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: t }),
          /* @__PURE__ */ e("div", { className: "mt-0.5 font-mono text-[11px] text-[var(--ink-soft)]", children: n })
        ] }),
        /* @__PURE__ */ s("div", { className: "ml-3 flex flex-col items-end", children: [
          /* @__PURE__ */ e("span", { className: "font-mono text-[15px] font-bold", style: { color: x }, children: o }),
          r && f && /* @__PURE__ */ e(
            "span",
            {
              className: "mt-0.5 text-[10px] font-semibold",
              style: { color: f },
              children: r
            }
          )
        ] })
      ]
    }
  );
}
function se() {
  const [t, n] = R(1), [o, x] = R(2), l = te(o, t), a = ne(o, t), i = l > 0 ? a / l : a > 0 ? 1 / 0 : 1, r = Math.max(_(0, t) * 1.15, 0.02), f = B((u) => n(u), []), $ = B((u) => x(u), []), p = ie(t, r), L = oe(t, o, r), b = h(o), F = h(-o), c = M(0, r), A = M(_(0, t), r), D = Math.min(b + 2, N - P - 10), Y = [-4, -2, 0, 2, 4], U = parseFloat((r * 0.8).toFixed(1)), g = a >= 1;
  return /* @__PURE__ */ s("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ s("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "切比雪夫不等式演示" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "调整 ε 和 σ，实时对比正态分布的真实尾部概率与切比雪夫上界，感受不等式的松紧程度。 μ = 0 固定，X ∼ N(0, σ²)。" })
    ] }),
    /* @__PURE__ */ s("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: [
      /* @__PURE__ */ e(
        z,
        {
          label: "标准差 σ",
          sub: "控制分布宽窄",
          value: t,
          min: 0.5,
          max: 3,
          step: 0.05,
          display: t.toFixed(2),
          color: S,
          onChange: f
        }
      ),
      /* @__PURE__ */ e(
        z,
        {
          label: "偏差阈值 ε",
          sub: "P(|X| ≥ ε) 的临界距离",
          value: o,
          min: 0.1,
          max: 5,
          step: 0.05,
          display: o.toFixed(2),
          color: v,
          onChange: $
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden", children: /* @__PURE__ */ s(
      "svg",
      {
        viewBox: `0 0 ${N} ${G}`,
        className: "w-full",
        style: { maxHeight: 220 },
        children: [
          /* @__PURE__ */ e(
            "rect",
            {
              x: y,
              y: d,
              width: E,
              height: j,
              fill: "var(--bg-muted)"
            }
          ),
          /* @__PURE__ */ e("path", { d: L, fill: v, fillOpacity: 0.28 }),
          /* @__PURE__ */ e("path", { d: p, fill: "none", stroke: S, strokeWidth: "2" }),
          o < k && /* @__PURE__ */ s(w, { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: b,
                y1: d,
                x2: b,
                y2: c,
                stroke: v,
                strokeWidth: "1.5",
                strokeDasharray: "4 3"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: D,
                y: d + 10,
                fontSize: "10",
                fill: v,
                fontWeight: "600",
                children: "+ε"
              }
            )
          ] }),
          -o > m && /* @__PURE__ */ s(w, { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: F,
                y1: d,
                x2: F,
                y2: c,
                stroke: v,
                strokeWidth: "1.5",
                strokeDasharray: "4 3"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: Math.max(F - 14, y),
                y: d + 10,
                fontSize: "10",
                fill: v,
                fontWeight: "600",
                children: "−ε"
              }
            )
          ] }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: h(0),
              y1: A,
              x2: h(0),
              y2: c,
              stroke: "var(--ink-faint)",
              strokeWidth: "1",
              strokeDasharray: "3 3"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: h(0) - 2,
              y: d + 10,
              fontSize: "9",
              fill: "var(--ink-faint)",
              textAnchor: "middle",
              children: "μ=0"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: y,
              y1: c,
              x2: N - P,
              y2: c,
              stroke: "var(--line)",
              strokeWidth: "1"
            }
          ),
          Y.map((u) => {
            const C = h(u);
            return C < y || C > N - P ? null : /* @__PURE__ */ s("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: C,
                  y1: c,
                  x2: C,
                  y2: c + 4,
                  stroke: "var(--ink-faint)",
                  strokeWidth: "1"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: C,
                  y: c + 13,
                  fontSize: "9",
                  textAnchor: "middle",
                  fill: "var(--ink-faint)",
                  children: u
                }
              )
            ] }, u);
          }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: y,
              y1: d,
              x2: y,
              y2: c,
              stroke: "var(--line)",
              strokeWidth: "1"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: y - 4,
              y: d + 4,
              fontSize: "9",
              textAnchor: "end",
              fill: "var(--ink-faint)",
              children: U
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: y - 4,
              y: c,
              fontSize: "9",
              textAnchor: "end",
              fill: "var(--ink-faint)",
              children: "0"
            }
          ),
          /* @__PURE__ */ e(
            "rect",
            {
              x: N - P - 110,
              y: d + 2,
              width: "10",
              height: "10",
              fill: v,
              fillOpacity: 0.55,
              rx: "2"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: N - P - 97,
              y: d + 10,
              fontSize: "9",
              fill: v,
              children: "P(|X| ≥ ε)区域"
            }
          ),
          /* @__PURE__ */ e(
            "rect",
            {
              x: N - P - 110,
              y: d + 15,
              width: "10",
              height: "3",
              fill: S,
              rx: "1"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: N - P - 97,
              y: d + 24,
              fontSize: "9",
              fill: S,
              children: "N(0, σ²) 曲线"
            }
          )
        ]
      }
    ) }),
    /* @__PURE__ */ s("div", { className: "space-y-2", children: [
      /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink-soft)] px-1 mb-1", children: "数值对比" }),
      /* @__PURE__ */ e(
        T,
        {
          label: "真实尾部概率",
          formula: `P(|X| ≥ ${o.toFixed(2)}) = 2·Φ(−${o.toFixed(2)}/${t.toFixed(2)})`,
          value: H(l),
          color: v,
          bg: "#fff7ed"
        }
      ),
      /* @__PURE__ */ e(
        T,
        {
          label: "切比雪夫上界",
          formula: `σ²/ε² = ${t.toFixed(2)}²/${o.toFixed(2)}² = ${(t * t).toFixed(3)}/${(o * o).toFixed(3)}`,
          value: g ? "1（无约束）" : H(a),
          color: X,
          bg: O
        }
      ),
      /* @__PURE__ */ e(
        T,
        {
          label: "松紧比（上界 / 真实）",
          formula: "= 切比雪夫上界 ÷ P(|X| ≥ ε)",
          value: isFinite(i) ? g ? "∞（上界=1）" : i.toFixed(2) + " 倍" : "∞（上界=1，无约束）",
          color: !isFinite(i) || g || i >= 10 ? X : i >= 3 ? "#ea580c" : i >= 1.5 ? "#ca8a04" : I,
          bg: !isFinite(i) || g || i >= 10 ? O : i >= 3 ? "#fff7ed" : i >= 1.5 ? "#fefce8" : K,
          isRatio: !0,
          ratio: isFinite(i) && !g ? i : 999
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "rounded-lg border px-3 py-2.5 text-[12px] leading-relaxed",
        style: {
          borderColor: g ? "#fca5a5" : W(S, "55"),
          background: g ? "#fff5f5" : W(J, "99")
        },
        children: g ? /* @__PURE__ */ s(w, { children: [
          /* @__PURE__ */ e("span", { className: "font-bold", style: { color: X }, children: "上界 = 1（无意义）：" }),
          /* @__PURE__ */ s("span", { className: "text-[var(--ink-soft)]", children: [
            " ",
            '当 ε ≤ σ 时，σ²/ε² ≥ 1，而概率本身 ≤ 1，所以切比雪夫上界退化为平凡约束"≤ 1"。 尝试增大 ε（或减小 σ），让 ε 超过 σ，使不等式产生真正的约束力。'
          ] })
        ] }) : /* @__PURE__ */ s(w, { children: [
          /* @__PURE__ */ e("span", { className: "font-bold", style: { color: S }, children: "直觉：" }),
          /* @__PURE__ */ s("span", { className: "text-[var(--ink-soft)]", children: [
            " ",
            "切比雪夫不等式对",
            /* @__PURE__ */ e("b", { children: "任意分布" }),
            "成立，无需知道具体形态，因此上界很宽松。 对正态分布而言，实际尾概率以指数速度衰减，比 1/ε² 快得多。 当前上界是真实概率的",
            " ",
            /* @__PURE__ */ s("b", { style: { color: X }, children: [
              isFinite(i) ? i.toFixed(1) : "∞",
              " 倍"
            ] }),
            '——这就是"松紧程度"。',
            isFinite(i) && i < 2 && /* @__PURE__ */ s("span", { style: { color: I }, children: [
              " ",
              "此时 ε/σ ≈ ",
              (o / t).toFixed(1),
              "，比值接近 1，不等式相对较紧。"
            ] })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ s("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] text-[var(--ink-soft)] space-y-1.5", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "切比雪夫不等式" }),
      /* @__PURE__ */ e("div", { className: "font-mono", children: "P(|X − μ| ≥ ε) ≤ Var(X) / ε²" }),
      /* @__PURE__ */ s("div", { className: "font-mono", children: [
        "    ",
        "= σ² / ε²",
        " = ",
        /* @__PURE__ */ e("span", { style: { color: S }, children: t.toFixed(2) }),
        "²",
        " / ",
        /* @__PURE__ */ e("span", { style: { color: v }, children: o.toFixed(2) }),
        "²",
        " = ",
        /* @__PURE__ */ e("span", { className: "font-bold", style: { color: X }, children: g ? "1.0000（上截断）" : a.toFixed(4) })
      ] }),
      /* @__PURE__ */ s("p", { className: "text-[11px] pt-1 leading-relaxed", children: [
        "不等式对任意（方差有限的）分布均成立，不依赖分布形态。 正态分布因其指数衰减尾部，真实概率远小于上界。",
        /* @__PURE__ */ s("b", { className: "text-[var(--ink)]", children: [
          " ",
          "ε 越大（相对于 σ），不等式越宽松。"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ s("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ e("div", { className: "text-[11px] font-medium text-[var(--ink-soft)]", children: "快捷探索" }),
      /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-1.5", children: [
        { label: "1σ 范围", sigma: 1, eps: 1 },
        { label: "2σ 范围", sigma: 1, eps: 2 },
        { label: "3σ 范围", sigma: 1, eps: 3 },
        { label: "上界≈真实", sigma: 1, eps: 0.5 },
        { label: "宽分布", sigma: 2.5, eps: 2 }
      ].map(({ label: u, sigma: C, eps: Z }) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => {
            n(C), x(Z);
          },
          className: "rounded-lg bg-[var(--bg-muted)] px-2.5 py-1 text-[12px] font-medium text-[var(--ink-soft)] hover:bg-[var(--accent)] hover:text-white transition-colors",
          children: u
        },
        u
      )) })
    ] })
  ] });
}
const ce = q(se);
export {
  ce as default
};
