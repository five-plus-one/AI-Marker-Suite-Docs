/** ContentImage - 从课栈 shared/ContentImage 提取
 *
 * 正文图片：加载失败时显示占位说明；有标题时包在 figure 中作为图注。
 */
import { type ImgHTMLAttributes } from "react";
export interface ContentImageProps extends ImgHTMLAttributes<HTMLImageElement> {
    /** 图注，存在时使用 figure 包裹 */
    title?: string;
}
export declare function ContentImage({ src, alt, title, onError, ...rest }: ContentImageProps): import("react").JSX.Element;
