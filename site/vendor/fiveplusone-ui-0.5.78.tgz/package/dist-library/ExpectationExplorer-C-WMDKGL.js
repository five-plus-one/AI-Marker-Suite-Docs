import { jsxs as c, jsx as e } from "react/jsx-runtime";
import { memo as et, useState as $, useRef as ot, useCallback as nt } from "react";
const u = "var(--fp-primary)", D = "var(--fp-primary-soft)", X = "#dc2626", G = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", w = "var(--bg-muted)", T = "var(--line)", b = "var(--ink)", m = "var(--ink-soft)", I = 560, z = 260, p = 210, _ = p - 4, B = 160, g = 50, A = I - 30, O = A - g, S = -4, R = 10, lt = 15;
function F(n) {
  return g + (n - S) / (R - S) * O;
}
function rt(n) {
  const r = (n - g) / O * (R - S) + S;
  return Math.round(Math.min(R, Math.max(S, r)));
}
function L(n) {
  return n * B;
}
function ct(n) {
  const r = _ - n;
  return Math.min(0.99, Math.max(0.01, r / B));
}
function st() {
  const l = [];
  for (let a = 0; a <= 4; a++) {
    const h = dt(4, a);
    l.push({ x: a, p: h * Math.pow(0.5, a) * Math.pow(1 - 0.5, 4 - a) });
  }
  return l;
}
function it() {
  const r = [];
  for (let l = 0; l <= 4; l++)
    r.push({
      x: l,
      p: Math.pow(2, l) * Math.exp(-2) / pt(l)
    });
  return r;
}
function at() {
  const r = [];
  for (let l = 1; l <= 5; l++)
    r.push({ x: l, p: 0.5 * Math.pow(1 - 0.5, l - 1) });
  return r;
}
function dt(n, r) {
  if (r > n) return 0;
  if (r === 0 || r === n) return 1;
  let l = 1, a = 1;
  for (let h = 0; h < r; h++)
    l *= n - h, a *= h + 1;
  return l / a;
}
function pt(n) {
  let r = 1;
  for (let l = 2; l <= n; l++) r *= l;
  return r;
}
const H = [
  { x: 0, p: 0.1 },
  { x: 2, p: 0.3 },
  { x: 4, p: 0.3 },
  { x: 6, p: 0.2 },
  { x: 8, p: 0.1 }
];
function xt(n) {
  const r = n.reduce((d, i) => d + i.p, 0), l = n.reduce((d, i) => d + i.x * i.p, 0) / (r || 1), a = n.reduce((d, i) => d + i.x * i.x * i.p, 0) / (r || 1), h = a - l * l;
  return { sumP: r, ex: l, ex2: a, variance: h };
}
function v(n, r = 4) {
  return n.toFixed(r);
}
function ft() {
  const [n, r] = $(H), [l, a] = $(null), h = ot(null), { sumP: d, ex: i, ex2: W, variance: M } = xt(n), C = Math.abs(d - 1) < 5e-3, P = nt(
    (t, o) => {
      const s = h.current;
      if (!s) return [0, 0];
      const x = s.getBoundingClientRect(), y = I / x.width, f = z / x.height;
      return [(t - x.left) * y, (o - x.top) * f];
    },
    []
  );
  function V(t, o) {
    t.preventDefault(), t.currentTarget.setPointerCapture(t.pointerId);
    const [s] = P(t.clientX, t.clientY);
    a({ kind: "x", idx: o, startSvgX: s, startX: n[o].x });
  }
  function K(t, o) {
    t.preventDefault(), t.currentTarget.setPointerCapture(t.pointerId);
    const [, s] = P(t.clientX, t.clientY);
    a({ kind: "p", idx: o, startSvgY: s, startP: n[o].p });
  }
  function j(t) {
    if (!l) return;
    t.preventDefault();
    const [o, s] = P(t.clientX, t.clientY);
    r((x) => {
      const y = x.map((f) => ({ ...f }));
      if (l.kind === "x") {
        const f = rt(o);
        new Set(
          x.map((Z, tt) => tt === l.idx ? -999 : Z.x)
        ).has(f) || (y[l.idx].x = f);
      } else {
        const f = ct(s);
        y[l.idx].p = f;
      }
      return y;
    });
  }
  function Y() {
    a(null);
  }
  function U() {
    r(H.map((t) => ({ ...t })));
  }
  function J(t) {
    r({
      binomial: st,
      poisson: it,
      geometric: at
    }[t]());
  }
  function q() {
    d <= 0 || r((t) => t.map((o) => ({ ...o, p: o.p / d })));
  }
  const Q = F(i), N = Math.max(g - 2, Math.min(A + 2, Q)), k = ["#5b46e5", "#0f766e", "#d97706", "#dc2626", "#7c3aed"];
  return /* @__PURE__ */ c(
    "div",
    {
      className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4",
      style: { fontFamily: "system-ui, sans-serif" },
      children: [
        /* @__PURE__ */ c("div", { className: "mb-3", children: [
          /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold", style: { color: b }, children: "期望：加权重心探索器" }),
          /* @__PURE__ */ c("p", { className: "mt-0.5 text-[12px]", style: { color: m }, children: [
            "拖动柱子底部圆点调整 ",
            /* @__PURE__ */ e("b", { children: "x 取值" }),
            "，拖动柱顶圆点调整",
            /* @__PURE__ */ e("b", { children: "概率高度" }),
            "， 观察期望「重心 ▽」如何移动。"
          ] })
        ] }),
        /* @__PURE__ */ c(
          "svg",
          {
            ref: h,
            viewBox: `0 0 ${I} ${z}`,
            className: "w-full select-none rounded-lg border",
            style: {
              borderColor: T,
              background: w,
              touchAction: "none",
              maxHeight: 280
            },
            onPointerMove: j,
            onPointerUp: Y,
            onPointerLeave: Y,
            children: [
              [0.25, 0.5, 0.75, 1].map((t) => {
                const o = _ - L(t);
                return /* @__PURE__ */ c("g", { children: [
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: g,
                      y1: o,
                      x2: A,
                      y2: o,
                      stroke: t === 1 ? "#c4b5fd" : "var(--line)",
                      strokeDasharray: t < 1 ? "4 3" : "none",
                      strokeWidth: t === 1 ? 1.5 : 1
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: g - 6,
                      y: o + 3.5,
                      fontSize: "10",
                      textAnchor: "end",
                      fill: m,
                      children: t
                    }
                  )
                ] }, t);
              }),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: g - 8,
                  y1: p,
                  x2: A + 8,
                  y2: p,
                  stroke: b,
                  strokeWidth: 1.5
                }
              ),
              Array.from({ length: lt }, (t, o) => o + S).map(
                (t) => {
                  const o = F(t), s = t % 2 === 0;
                  return /* @__PURE__ */ c("g", { children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: o,
                        y1: p,
                        x2: o,
                        y2: p + (s ? 6 : 3),
                        stroke: b,
                        strokeWidth: 1
                      }
                    ),
                    s && /* @__PURE__ */ e(
                      "text",
                      {
                        x: o,
                        y: p + 17,
                        fontSize: "10",
                        textAnchor: "middle",
                        fill: m,
                        children: t
                      }
                    )
                  ] }, t);
                }
              ),
              n.map((t, o) => {
                const s = F(t.x), x = L(t.p), y = _ - x, f = k[o % k.length];
                return /* @__PURE__ */ c("g", { children: [
                  /* @__PURE__ */ e(
                    "rect",
                    {
                      x: s - 14,
                      y,
                      width: 28,
                      height: x,
                      fill: f,
                      opacity: 0.75,
                      rx: 3
                    }
                  ),
                  x > 18 && /* @__PURE__ */ e(
                    "text",
                    {
                      x: s,
                      y: y + 13,
                      fontSize: "10",
                      textAnchor: "middle",
                      fill: "white",
                      fontWeight: "600",
                      children: t.p.toFixed(2)
                    }
                  ),
                  /* @__PURE__ */ c(
                    "text",
                    {
                      x: s,
                      y: p - 10,
                      fontSize: "10",
                      textAnchor: "middle",
                      fill: f,
                      fontWeight: "700",
                      children: [
                        "x=",
                        t.x
                      ]
                    }
                  ),
                  /* @__PURE__ */ e(
                    "circle",
                    {
                      cx: s,
                      cy: y,
                      r: 7,
                      fill: f,
                      stroke: "white",
                      strokeWidth: 2,
                      style: { cursor: "ns-resize" },
                      onPointerDown: (E) => K(E, o)
                    }
                  ),
                  /* @__PURE__ */ e(
                    "circle",
                    {
                      cx: s,
                      cy: p + 2,
                      r: 6,
                      fill: "white",
                      stroke: f,
                      strokeWidth: 2.5,
                      style: { cursor: "ew-resize" },
                      onPointerDown: (E) => V(E, o)
                    }
                  )
                ] }, o);
              }),
              isFinite(i) && /* @__PURE__ */ c("g", { children: [
                /* @__PURE__ */ e(
                  "line",
                  {
                    x1: N,
                    y1: p - 6,
                    x2: N,
                    y2: p + 22,
                    stroke: u,
                    strokeWidth: 2,
                    strokeDasharray: "5 3"
                  }
                ),
                /* @__PURE__ */ e(
                  "polygon",
                  {
                    points: `${N - 7},${p + 22} ${N + 7},${p + 22} ${N},${p + 33}`,
                    fill: u
                  }
                ),
                /* @__PURE__ */ c(
                  "text",
                  {
                    x: N,
                    y: p + 44,
                    fontSize: "11",
                    textAnchor: "middle",
                    fill: u,
                    fontWeight: "700",
                    children: [
                      "E[X]=",
                      i.toFixed(2)
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: g - 6,
                  y: _ - B - 6,
                  fontSize: "10",
                  textAnchor: "end",
                  fill: m,
                  children: "p"
                }
              ),
              /* @__PURE__ */ e("text", { x: A, y: 22, fontSize: "10", textAnchor: "end", fill: m, children: "● 拖柱顶调概率 · 拖底圆调取值" })
            ]
          }
        ),
        !C && /* @__PURE__ */ c(
          "div",
          {
            className: "mt-2 flex items-center gap-2 rounded-lg border px-3 py-2 text-[12px] font-semibold",
            style: { borderColor: X, background: G, color: X },
            children: [
              /* @__PURE__ */ e("span", { children: "[!]" }),
              /* @__PURE__ */ c("span", { children: [
                "概率之和 = ",
                d.toFixed(4),
                "（应 = 1）。点击「归一化」自动修正，否则下方统计量仅供参考。"
              ] }),
              /* @__PURE__ */ e(
                "button",
                {
                  type: "button",
                  onClick: q,
                  className: "ml-auto rounded-md px-2 py-0.5 text-[11px] font-bold",
                  style: { background: X, color: "white" },
                  children: "归一化"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ e("div", { className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
          {
            label: "E[X]（期望）",
            val: v(i, 4),
            color: u,
            bg: D
          },
          {
            label: "E[X²]（二阶矩）",
            val: v(W, 4),
            color: "#0f766e",
            bg: "#ccfbf1"
          },
          {
            label: "E[X]²",
            val: v(i * i, 4),
            color: "#d97706",
            bg: "#fef3c7"
          },
          {
            label: "D[X] = E[X²]−E[X]²",
            val: v(M, 4),
            color: M < 0 ? X : "#7c3aed",
            bg: M < 0 ? G : "#f3e8ff"
          }
        ].map(({ label: t, val: o, color: s, bg: x }) => /* @__PURE__ */ c(
          "div",
          {
            className: "rounded-lg p-2.5 text-center",
            style: { background: x },
            children: [
              /* @__PURE__ */ e(
                "div",
                {
                  className: "text-[10px] leading-snug",
                  style: { color: m },
                  children: t
                }
              ),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "mt-0.5 font-mono text-[15px] font-extrabold",
                  style: { color: s },
                  children: o
                }
              )
            ]
          },
          t
        )) }),
        /* @__PURE__ */ c(
          "div",
          {
            className: "mt-3 rounded-lg px-4 py-3 text-[12px] leading-loose",
            style: { background: w },
            children: [
              /* @__PURE__ */ e("div", { className: "mb-1 text-[13px] font-semibold", style: { color: b }, children: "加权平均公式（实时数值代入）" }),
              /* @__PURE__ */ c("div", { className: "font-mono", style: { color: m }, children: [
                "E[X] = Σ x·p(x) = ",
                n.map((t, o) => /* @__PURE__ */ c("span", { children: [
                  /* @__PURE__ */ c(
                    "span",
                    {
                      style: { color: k[o % k.length], fontWeight: 700 },
                      children: [
                        "(",
                        t.x,
                        ")×",
                        t.p.toFixed(3)
                      ]
                    }
                  ),
                  o < n.length - 1 && " + "
                ] }, o))
              ] }),
              /* @__PURE__ */ c("div", { className: "mt-0.5 font-mono", children: [
                "         =",
                " ",
                /* @__PURE__ */ e("span", { style: { color: u, fontWeight: 700 }, children: v(i, 4) }),
                !C && /* @__PURE__ */ c("span", { style: { color: X }, children: [
                  " ",
                  "（∑p = ",
                  d.toFixed(3),
                  " ≠ 1，实为加权均值）"
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ e("div", { className: "mt-3 overflow-x-auto", children: /* @__PURE__ */ c("table", { className: "w-full min-w-[360px] border-collapse text-[12px]", children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ e("tr", { style: { background: w }, children: ["质量块", "取值 x", "概率 p(x)", "x·p(x)", "x²·p(x)"].map(
            (t) => /* @__PURE__ */ e(
              "th",
              {
                className: "px-2 py-1.5 text-left font-semibold",
                style: {
                  color: m,
                  borderBottom: `1px solid ${T}`
                },
                children: t
              },
              t
            )
          ) }) }),
          /* @__PURE__ */ c("tbody", { children: [
            n.map((t, o) => {
              const s = k[o % k.length];
              return /* @__PURE__ */ c(
                "tr",
                {
                  style: { borderBottom: `1px solid ${T}` },
                  children: [
                    /* @__PURE__ */ e("td", { className: "px-2 py-1.5", children: /* @__PURE__ */ e(
                      "span",
                      {
                        className: "inline-block h-3 w-3 rounded-sm",
                        style: { background: s, verticalAlign: "middle" }
                      }
                    ) }),
                    /* @__PURE__ */ e(
                      "td",
                      {
                        className: "px-2 py-1.5 font-mono font-bold",
                        style: { color: s },
                        children: t.x
                      }
                    ),
                    /* @__PURE__ */ e("td", { className: "px-2 py-1.5 font-mono", style: { color: b }, children: t.p.toFixed(4) }),
                    /* @__PURE__ */ e("td", { className: "px-2 py-1.5 font-mono", style: { color: b }, children: (t.x * t.p).toFixed(4) }),
                    /* @__PURE__ */ e("td", { className: "px-2 py-1.5 font-mono", style: { color: b }, children: (t.x * t.x * t.p).toFixed(4) })
                  ]
                },
                o
              );
            }),
            /* @__PURE__ */ c("tr", { style: { background: D }, children: [
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1.5 font-bold",
                  style: { color: u },
                  colSpan: 2,
                  children: "合计"
                }
              ),
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1.5 font-mono font-bold",
                  style: { color: C ? u : X },
                  children: d.toFixed(4)
                }
              ),
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1.5 font-mono font-bold",
                  style: { color: u },
                  children: v(i * d, 4)
                }
              ),
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1.5 font-mono font-bold",
                  style: { color: u },
                  children: v(W * d, 4)
                }
              )
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ c("div", { className: "mt-3 flex flex-wrap gap-2", children: [
          /* @__PURE__ */ e(
            "span",
            {
              className: "self-center text-[11px] font-semibold",
              style: { color: m },
              children: "预设分布："
            }
          ),
          [
            { key: "binomial", label: "二项 B(4, 0.5)" },
            { key: "poisson", label: "泊松 P(2)" },
            { key: "geometric", label: "几何 G(0.5)" }
          ].map(({ key: t, label: o }) => /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => J(t),
              className: "rounded-lg px-3 py-1 text-[12px] font-medium",
              style: { background: D, color: u },
              children: o
            },
            t
          )),
          /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: U,
              className: "ml-auto rounded-lg px-3 py-1 text-[12px] font-medium",
              style: {
                background: w,
                color: m,
                border: `1px solid ${T}`
              },
              children: "重置"
            }
          )
        ] }),
        /* @__PURE__ */ c(
          "div",
          {
            className: "mt-3 rounded-lg px-3 py-2.5 text-[12px] leading-relaxed",
            style: { background: w, borderLeft: `3px solid ${u}` },
            children: [
              /* @__PURE__ */ e("span", { className: "font-semibold", style: { color: b }, children: "直觉要点：" }),
              /* @__PURE__ */ c("span", { style: { color: m }, children: [
                " ",
                "E[X] 就是「各取值按概率加权的重心」——把概率想象成质量，重心 ▽ 总在最重的一侧偏移。 方差 D[X] = E[X²] − (E[X])² 度量了质量块围绕重心的分散程度。 注意 E[X²] ≥ (E[X])²（Jensen 不等式），因此 D[X] ≥ 0。"
              ] })
            ]
          }
        )
      ]
    }
  );
}
const mt = et(ft);
export {
  mt as default
};
