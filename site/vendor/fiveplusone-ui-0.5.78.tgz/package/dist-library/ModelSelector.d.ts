import type { ReactNode } from "react";
export interface ModelInfo {
    icon?: ReactNode;
    id: string;
    label: string;
    /** Context window in tokens, for example 128_000. */
    contextWindow?: number;
    supportsThinking?: boolean;
    supportsVision?: boolean;
    supportsTools?: boolean;
    description?: string;
    disabled?: boolean;
}
export interface ModelGroup {
    name: string;
    models: ModelInfo[];
}
export interface ModelSelectorProps {
    value: string;
    onChange: (modelId: string) => void;
    groups: ModelGroup[];
    disabled?: boolean;
    label?: string;
}
export declare function formatContextWindow(tokens?: number): string;
export declare function ModelSelector({ value, onChange, groups, disabled, label, }: ModelSelectorProps): import("react").JSX.Element;
