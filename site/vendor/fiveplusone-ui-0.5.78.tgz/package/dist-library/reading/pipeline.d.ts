import { type Options } from 'rehype-sanitize';
import type { Root } from 'hast';
export declare const readingSchema: Options;
/** Color-only inline formatting is retained before the HTML sanitizer runs. */
export declare function readingStyles(): (tree: Root) => void;
export declare function readingHeadingIds(): (tree: Root) => void;
