export interface MarkerLogoProps {
    size?: number;
    decorative?: boolean;
    label?: string;
}
/** A graded page and a spark, drawn for small navigation and application icons. */
export declare function MarkerLogo({ size, decorative, label }: MarkerLogoProps): import("react").JSX.Element;
