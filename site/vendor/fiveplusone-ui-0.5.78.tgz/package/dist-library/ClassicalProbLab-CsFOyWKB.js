import { jsxs as n, jsx as t } from "react/jsx-runtime";
import { memo as K, useState as p } from "react";
function E(a) {
  const s = {};
  for (let l = 1; l <= 6; l++)
    for (let u = 1; u <= 6; u++) {
      const i = l + u;
      s[i] = (s[i] ?? 0) + 1;
    }
  const x = 36;
  return {
    key: "dice",
    name: "掷两骰子之和",
    description: '两颗公平骰子，样本空间共 36 个等可能点。选定一个目标"和"，观察该和出现的理论概率与试验频率是否趋近。',
    outcomes: Array.from({ length: 11 }, (l, u) => {
      const i = u + 2;
      return {
        label: String(i),
        count: s[i] ?? 0,
        total: x,
        color: i === a ? "#5b46e5" : "#c4b5fd"
      };
    }),
    targetLabel: `和 = ${a}`
  };
}
function I(a, s) {
  return {
    key: "balls",
    name: "摸球",
    description: `袋中共 ${a} 球，其中 ${s} 个红球、${a - s} 个白球。随机摸 1 球（等可能），有利事件为摸到红球。`,
    outcomes: [
      { label: "红球", count: s, total: a, color: "#5b46e5" },
      { label: "白球", count: a - s, total: a, color: "#c4b5fd" }
    ],
    targetLabel: "摸到红球"
  };
}
function J(a, s) {
  let x = 0;
  for (let f = 0; f < a; f++) {
    const l = Math.floor(Math.random() * 6) + 1, u = Math.floor(Math.random() * 6) + 1;
    l + u === s && x++;
  }
  return x;
}
function Q(a, s, x) {
  let f = 0;
  for (let l = 0; l < a; l++)
    Math.floor(Math.random() * s) < x && f++;
  return f;
}
const $ = 340, H = 180, r = 36, O = 14, c = 16, U = 36, v = $ - r - O, d = H - c - U;
function X() {
  const [a, s] = p("dice"), [x, f] = p(7), [l, u] = p(10), [i, L] = p(3), [F, V] = p(200), [P, T] = p(null), [w, _] = p(0), [b, z] = p([]);
  function Y() {
    const e = F;
    let o;
    if (a === "dice")
      o = J(e, x);
    else {
      const g = Math.min(i, l);
      o = Q(e, l, g);
    }
    const A = w + e, k = (P ?? 0) + o;
    T(k), _(A), z((g) => {
      const C = [...g, k / A];
      return C.length > 300 ? C.slice(C.length - 300) : C;
    });
  }
  function S() {
    T(null), _(0), z([]);
  }
  const y = a === "dice" ? E(x) : I(l, Math.min(i, l)), M = y.outcomes.find((e) => e.color === "#5b46e5"), m = M.count / M.total, h = w > 0 ? (P ?? 0) / w : null, B = y.outcomes.length, D = Math.min(36, v / B * 0.55), R = v / B, q = 1, N = (e) => c + (1 - e / q) * d, j = (e) => r + (b.length <= 1 ? 0 : e / (b.length - 1) * v), G = b.length > 1 ? b.map(
    (e, o) => `${o === 0 ? "M" : "L"}${j(o).toFixed(1)},${N(e).toFixed(1)}`
  ).join(" ") : "", W = N(m);
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ n("div", { className: "mb-3 flex flex-wrap items-center justify-between gap-2", children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-semibold text-[var(--ink)]", children: "古典概型实验室" }),
      /* @__PURE__ */ t("div", { className: "flex gap-1.5", children: ["dice", "balls"].map((e) => /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => {
            s(e), S();
          },
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (a === e ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
          children: e === "dice" ? "骰子之和" : "摸球"
        },
        e
      )) })
    ] }),
    /* @__PURE__ */ t("p", { className: "mb-3 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: y.description }),
    /* @__PURE__ */ t("div", { className: "mb-3 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2", children: a === "dice" ? /* @__PURE__ */ n("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ t("span", { className: "text-[12px] font-medium text-[var(--ink-soft)]", children: "目标和：" }),
      /* @__PURE__ */ t(
        "input",
        {
          type: "range",
          min: 2,
          max: 12,
          value: x,
          onChange: (e) => {
            f(Number(e.target.value)), S();
          },
          className: "h-1.5 flex-1 cursor-pointer accent-[var(--accent)]",
          style: { minWidth: 80 }
        }
      ),
      /* @__PURE__ */ t("span", { className: "w-5 text-center text-[13px] font-bold text-[var(--ink)]", children: x }),
      /* @__PURE__ */ n("span", { className: "text-[12px] text-[var(--ink-soft)]", children: [
        "理论概率 ",
        /* @__PURE__ */ n("b", { className: "font-mono text-[var(--accent)]", children: [
          M.count,
          "/36 ≈ ",
          m.toFixed(4)
        ] })
      ] })
    ] }) : /* @__PURE__ */ n("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ n("label", { className: "text-[12px] font-medium text-[var(--ink-soft)]", children: [
        "总球数 ",
        /* @__PURE__ */ t(
          "input",
          {
            type: "range",
            min: 2,
            max: 20,
            value: l,
            onChange: (e) => {
              const o = Number(e.target.value);
              u(o), i > o && L(o), S();
            },
            className: "mx-1.5 h-1.5 w-20 cursor-pointer accent-[var(--accent)]"
          }
        ),
        /* @__PURE__ */ t("b", { className: "text-[var(--ink)]", children: l })
      ] }),
      /* @__PURE__ */ n("label", { className: "text-[12px] font-medium text-[var(--ink-soft)]", children: [
        "红球数 ",
        /* @__PURE__ */ t(
          "input",
          {
            type: "range",
            min: 0,
            max: l,
            value: i,
            onChange: (e) => {
              L(Number(e.target.value)), S();
            },
            className: "mx-1.5 h-1.5 w-20 cursor-pointer accent-[var(--accent)]"
          }
        ),
        /* @__PURE__ */ t("b", { className: "text-[var(--ink)]", children: i })
      ] }),
      /* @__PURE__ */ n("span", { className: "text-[12px] text-[var(--ink-soft)]", children: [
        "理论概率 ",
        /* @__PURE__ */ n("b", { className: "font-mono text-[var(--accent)]", children: [
          i,
          "/",
          l,
          " ≈ ",
          m.toFixed(4)
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ n("div", { className: "mb-3 grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ n("div", { children: [
        /* @__PURE__ */ t("p", { className: "mb-1 text-[11px] text-[var(--ink-soft)]", children: "理论概率分布（各结果占比）" }),
        /* @__PURE__ */ n(
          "svg",
          {
            viewBox: `0 0 ${$} ${H}`,
            className: "w-full rounded-lg bg-[var(--bg-muted)]",
            children: [
              /* @__PURE__ */ t(
                "line",
                {
                  x1: r,
                  y1: c,
                  x2: r,
                  y2: c + d,
                  stroke: "var(--line)",
                  strokeWidth: 1
                }
              ),
              /* @__PURE__ */ t(
                "line",
                {
                  x1: r,
                  y1: c + d,
                  x2: $ - O,
                  y2: c + d,
                  stroke: "var(--line)",
                  strokeWidth: 1
                }
              ),
              [0, 0.1, 0.2, 0.3].map((e) => {
                const o = c + d - e * d * (a === "dice" ? 3.33 : 1);
                return o < c ? null : /* @__PURE__ */ n("g", { children: [
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: r - 3,
                      y1: o,
                      x2: r,
                      y2: o,
                      stroke: "var(--line)"
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: r - 5,
                      y: o + 3,
                      fontSize: 8,
                      textAnchor: "end",
                      fill: "var(--ink-faint)",
                      children: e.toFixed(1)
                    }
                  )
                ] }, e);
              }),
              y.outcomes.map((e, o) => {
                const A = e.count / e.total, k = A * d * (a === "dice" ? 3.33 : 1), g = r + R * o + R / 2;
                return /* @__PURE__ */ n("g", { children: [
                  /* @__PURE__ */ t(
                    "rect",
                    {
                      x: g - D / 2,
                      y: c + d - k,
                      width: D,
                      height: k,
                      rx: 3,
                      fill: e.color,
                      opacity: 0.85
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: g,
                      y: c + d + 12,
                      fontSize: a === "dice" ? 7.5 : 10,
                      textAnchor: "middle",
                      fill: "var(--ink-faint)",
                      children: e.label
                    }
                  ),
                  e.color === "#5b46e5" && /* @__PURE__ */ n(
                    "text",
                    {
                      x: g,
                      y: c + d - k - 4,
                      fontSize: 8,
                      textAnchor: "middle",
                      fill: "#5b46e5",
                      fontWeight: "700",
                      children: [
                        (A * 100).toFixed(1),
                        "%"
                      ]
                    }
                  )
                ] }, e.label);
              }),
              /* @__PURE__ */ n(
                "text",
                {
                  x: r + v / 2,
                  y: c - 3,
                  fontSize: 9,
                  textAnchor: "middle",
                  fill: "var(--ink-faint)",
                  children: [
                    y.name,
                    " — 理论分布"
                  ]
                }
              )
            ]
          }
        )
      ] }),
      /* @__PURE__ */ n("div", { children: [
        /* @__PURE__ */ n("p", { className: "mb-1 text-[11px] text-[var(--ink-soft)]", children: [
          "频率收敛曲线（",
          y.targetLabel,
          "）"
        ] }),
        /* @__PURE__ */ n(
          "svg",
          {
            viewBox: `0 0 ${$} ${H}`,
            className: "w-full rounded-lg bg-[var(--bg-muted)]",
            children: [
              /* @__PURE__ */ t(
                "rect",
                {
                  x: r,
                  y: c,
                  width: v,
                  height: d,
                  fill: "var(--bg-muted)",
                  stroke: "var(--line)"
                }
              ),
              /* @__PURE__ */ t(
                "line",
                {
                  x1: r,
                  y1: W,
                  x2: r + v,
                  y2: W,
                  stroke: "#5b46e5",
                  strokeWidth: 1.2,
                  strokeDasharray: "5 3",
                  opacity: 0.7
                }
              ),
              /* @__PURE__ */ n(
                "text",
                {
                  x: r + v - 2,
                  y: W - 4,
                  fontSize: 8,
                  textAnchor: "end",
                  fill: "#5b46e5",
                  children: [
                    "理论 ",
                    m.toFixed(3)
                  ]
                }
              ),
              [0, 0.5, 1].map((e) => /* @__PURE__ */ n("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: r - 3,
                    y1: N(e),
                    x2: r,
                    y2: N(e),
                    stroke: "var(--line)"
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: r - 5,
                    y: N(e) + 3,
                    fontSize: 8,
                    textAnchor: "end",
                    fill: "var(--ink-faint)",
                    children: e
                  }
                )
              ] }, e)),
              G && /* @__PURE__ */ t(
                "path",
                {
                  d: G,
                  fill: "none",
                  stroke: "#5b46e5",
                  strokeWidth: 1.8
                }
              ),
              b.length === 0 && /* @__PURE__ */ t(
                "text",
                {
                  x: r + v / 2,
                  y: c + d / 2,
                  fontSize: 11,
                  textAnchor: "middle",
                  fill: "#c4b5fd",
                  children: "按下「运行」开始模拟"
                }
              ),
              b.length > 0 && /* @__PURE__ */ t(
                "circle",
                {
                  cx: j(b.length - 1),
                  cy: N(b[b.length - 1]),
                  r: 3.5,
                  fill: "#5b46e5"
                }
              )
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "mb-3 grid grid-cols-3 gap-2 text-center text-[12px]", children: [
      /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-2 py-2", children: [
        /* @__PURE__ */ t("div", { className: "text-[var(--ink-soft)]", children: "有利 / 总数" }),
        /* @__PURE__ */ n("div", { className: "font-mono font-bold text-[var(--ink)]", children: [
          M.count,
          " / ",
          M.total
        ] })
      ] }),
      /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-2 py-2", children: [
        /* @__PURE__ */ t("div", { className: "text-[var(--ink-soft)]", children: "理论概率" }),
        /* @__PURE__ */ t("div", { className: "font-mono font-bold text-[var(--accent)]", children: m.toFixed(4) })
      ] }),
      /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-2 py-2", children: [
        /* @__PURE__ */ n("div", { className: "text-[var(--ink-soft)]", children: [
          "试验频率",
          w > 0 && /* @__PURE__ */ n("span", { className: "ml-1 text-[10px]", children: [
            "(",
            w,
            "次)"
          ] })
        ] }),
        /* @__PURE__ */ t(
          "div",
          {
            className: "font-mono font-bold " + (h === null ? "text-[var(--ink-soft)]" : Math.abs(h - m) < 0.02 ? "text-[var(--color-success)]" : "text-[var(--color-warning)]"),
            children: h !== null ? h.toFixed(4) : "—"
          }
        )
      ] })
    ] }),
    h !== null && /* @__PURE__ */ n("div", { className: "mb-3 rounded-lg bg-[var(--bg-muted)] px-3 py-1.5 text-[12px]", children: [
      /* @__PURE__ */ t("span", { className: "text-[var(--ink-soft)]", children: "|频率 − 理论概率| = " }),
      /* @__PURE__ */ t(
        "span",
        {
          className: "font-mono font-bold " + (Math.abs(h - m) < 0.01 ? "text-[var(--color-success)]" : Math.abs(h - m) < 0.05 ? "text-[var(--color-warning)]" : "text-[var(--md-sys-color-error)]"),
          children: Math.abs(h - m).toFixed(4)
        }
      ),
      /* @__PURE__ */ t("span", { className: "ml-2 text-[var(--ink-soft)]", children: Math.abs(h - m) < 0.01 ? "[OK] 非常接近，大数定律在起作用！" : Math.abs(h - m) < 0.05 ? "↗ 继续增加试验次数，误差会缩小" : "→ 试验次数较少，误差较大，请继续运行" })
    ] }),
    /* @__PURE__ */ n("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ n("div", { className: "flex flex-1 items-center gap-2 text-[12px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ t("span", { className: "shrink-0", children: "每次运行：" }),
        /* @__PURE__ */ t(
          "input",
          {
            type: "range",
            min: 10,
            max: 5e3,
            step: 10,
            value: F,
            onChange: (e) => V(Number(e.target.value)),
            className: "h-1.5 flex-1 cursor-pointer accent-[var(--accent)]",
            style: { minWidth: 60 }
          }
        ),
        /* @__PURE__ */ t("span", { className: "w-14 text-right font-mono font-bold text-[var(--ink)]", children: F.toLocaleString() })
      ] }),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: Y,
          className: "rounded-lg bg-[var(--accent)] px-4 py-1.5 text-[13px] font-semibold text-white hover:opacity-90 active:scale-95 transition-transform",
          children: "运行"
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: S,
          className: "rounded-lg bg-[var(--bg-muted)] px-3 py-1.5 text-[13px] text-[var(--ink-soft)] hover:bg-[var(--line)] transition-colors",
          children: "重置"
        }
      )
    ] }),
    /* @__PURE__ */ n("p", { className: "mt-3 rounded-lg bg-[var(--bg-muted)] px-3 py-2 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "古典概型要点" }),
      "：样本空间有限且每个基本事件 ",
      /* @__PURE__ */ t("b", { children: "等可能" }),
      "发生，有利事件的概率 = 有利结果数 ÷ 总结果数。多次重复试验后， 频率会稳定收敛到理论概率（大数定律）。调整参数或切换场景，感受等可能结构的普适性。"
    ] })
  ] });
}
const te = K(X);
export {
  te as default
};
