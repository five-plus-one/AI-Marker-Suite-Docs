const fs = require('node:fs');
const path = require('node:path');
function normalizeAppearance(value) {
 if (!value || !['light', 'dark'].includes(value.theme)) return undefined;
 return {version: 1, preference: ['light', 'dark', 'system'].includes(value.preference) ? value.preference : value.theme, theme: value.theme};
}
function saveAppearance(file, value) {
 const appearance = normalizeAppearance(value);
 if (!appearance) return undefined;
 const body = JSON.stringify(appearance) + '\n';
 try { if (fs.readFileSync(file, 'utf8') === body) return appearance; } catch {}
 fs.mkdirSync(path.dirname(file), {recursive: true});
 const temporary = file + '.' + process.pid + '.tmp';
 try { fs.writeFileSync(temporary, body, {mode: 0o600}); fs.renameSync(temporary, file); }
 finally { try { fs.unlinkSync(temporary); } catch {} }
 return appearance;
}
module.exports = {normalizeAppearance, saveAppearance};
