import { jsxs as n, jsx as e } from "react/jsx-runtime";
import { memo as y, useState as v } from "react";
const p = [
  {
    id: "cucl",
    reagent: "CuCl",
    condition: "Cu(I) 催化",
    reactionName: "桑德迈尔反应",
    product: "C₆H₅Cl",
    productLabel: "氯苯",
    category: "sandmeyer",
    description: "桑德迈尔反应：芳基重氮盐与 CuCl 作用，重氮基 −N₂⁺ 被 −Cl 取代生成氯苯，放出 N₂。",
    angle: -90
  },
  {
    id: "cubr",
    reagent: "CuBr",
    condition: "Cu(I) 催化",
    reactionName: "桑德迈尔反应",
    product: "C₆H₅Br",
    productLabel: "溴苯",
    category: "sandmeyer",
    description: "桑德迈尔反应：与 CuBr 作用，−N₂⁺ 被 −Br 取代生成溴苯，并放出 N₂。",
    angle: -50
  },
  {
    id: "cucn",
    reagent: "CuCN",
    condition: "Cu(I) 催化",
    reactionName: "桑德迈尔反应",
    product: "C₆H₅CN",
    productLabel: "苯甲腈",
    category: "sandmeyer",
    description: "桑德迈尔反应：与 CuCN 作用，−N₂⁺ 被 −CN 取代生成苯甲腈，可进一步制备羧酸。",
    angle: -10
  },
  {
    id: "ki",
    reagent: "KI",
    condition: "无需催化，微热",
    reactionName: "卤代（碘代）",
    product: "C₆H₅I",
    productLabel: "碘苯",
    category: "iodo",
    description: "与 KI 共热即可，无需铜盐催化，−N₂⁺ 被 −I 取代生成碘苯，放出 N₂。",
    angle: 30
  },
  {
    id: "hbf4",
    reagent: "HBF₄",
    condition: "生成重氮氟硼酸盐后加热",
    reactionName: "席曼反应",
    product: "C₆H₅F",
    productLabel: "氟苯",
    category: "schiemann",
    description: "席曼反应（Balz–Schiemann）：重氮盐与 HBF₄ 生成 ArN₂⁺BF₄⁻ 沉淀，加热分解得氟苯，放出 N₂ 和 BF₃。",
    angle: 70
  },
  {
    id: "h3po2",
    reagent: "H₃PO₂",
    condition: "次磷酸还原",
    reactionName: "还原脱重氮基",
    product: "C₆H₆",
    productLabel: "苯",
    category: "reduction",
    description: "次磷酸 H₃PO₂（或乙醇）作还原剂，−N₂⁺ 被 −H 取代生成苯，用于从芳环上去除原有取代基（定位后脱去氨基）。",
    angle: 130
  },
  {
    id: "h2o",
    reagent: "H₂O",
    condition: "稀硫酸中加热水解",
    reactionName: "水解",
    product: "C₆H₅OH",
    productLabel: "苯酚",
    category: "hydrolysis",
    description: "在稀硫酸中加热，重氮盐水解，−N₂⁺ 被 −OH 取代生成苯酚，并放出 N₂。",
    angle: 180
  },
  {
    id: "coupling",
    reagent: "酚 / 芳胺",
    condition: "弱碱/弱酸性，低温偶联",
    reactionName: "偶联反应",
    product: "Ar−N=N−Ar′",
    productLabel: "偶氮化合物（偶氮染料）",
    category: "coupling",
    description: "偶联反应：重氮盐作为亲电试剂进攻酚或芳胺的对位（或邻位），生成含 −N=N− 的偶氮化合物，是合成偶氮染料的关键步骤。",
    angle: 230
  }
], f = {
  sandmeyer: "#2563eb",
  iodo: "#0891b2",
  schiemann: "#7c3aed",
  reduction: "#16a34a",
  hydrolysis: "#ea580c",
  coupling: "#db2777"
}, N = 560, c = N / 2, m = 52, u = 62, b = 30, g = 200;
function s(i, d) {
  const o = i * Math.PI / 180;
  return {
    x: c + d * Math.cos(o),
    y: c + d * Math.sin(o)
  };
}
function C() {
  const [i, d] = v(null), o = p.find((t) => t.id === i) ?? null;
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "重氮盐转化网络" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "中心为芳基重氮盐 ArN₂⁺（如苯重氮盐 C₆H₅N₂⁺）。点击周围的试剂，查看它经由哪种反应转化为相应产物。" }),
    /* @__PURE__ */ n("div", { className: "mt-4 flex flex-col gap-4 lg:flex-row", children: [
      /* @__PURE__ */ e("div", { className: "flex-1", children: /* @__PURE__ */ n(
        "svg",
        {
          viewBox: `0 0 ${N} ${N}`,
          className: "h-auto w-full select-none",
          role: "img",
          "aria-label": "重氮盐转化网络图",
          children: [
            /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e(
              "marker",
              {
                id: "diazo-arrow",
                viewBox: "0 0 10 10",
                refX: "9",
                refY: "5",
                markerWidth: "7",
                markerHeight: "7",
                orient: "auto-start-reverse",
                children: /* @__PURE__ */ e("path", { d: "M0,0 L10,5 L0,10 z", fill: "currentColor" })
              }
            ) }),
            p.map((t) => {
              const r = t.id === i, a = f[t.category], l = s(t.angle, g), x = s(t.angle, m + 4), h = s(t.angle, g - u - 4);
              return /* @__PURE__ */ n(
                "g",
                {
                  style: { color: a },
                  className: "cursor-pointer",
                  onClick: () => d(t.id),
                  children: [
                    /* @__PURE__ */ e(
                      "line",
                      {
                        x1: x.x,
                        y1: x.y,
                        x2: h.x,
                        y2: h.y,
                        stroke: a,
                        strokeWidth: r ? 3.5 : 1.5,
                        strokeOpacity: i === null ? 0.4 : r ? 1 : 0.12,
                        markerEnd: "url(#diazo-arrow)"
                      }
                    ),
                    r ? /* @__PURE__ */ e(
                      "text",
                      {
                        x: s(t.angle, (m + g - u) / 2).x,
                        y: s(t.angle, (m + g - u) / 2).y - 6,
                        textAnchor: "middle",
                        fontSize: "12",
                        fontWeight: 700,
                        fill: a,
                        children: t.reactionName
                      }
                    ) : null,
                    /* @__PURE__ */ e(
                      "ellipse",
                      {
                        cx: l.x,
                        cy: l.y,
                        rx: u,
                        ry: b,
                        fill: r ? a : "var(--bg-muted)",
                        stroke: a,
                        strokeWidth: r ? 2.5 : 1.5,
                        fillOpacity: r ? 1 : 0.6,
                        strokeOpacity: i === null || r ? 1 : 0.3
                      }
                    ),
                    /* @__PURE__ */ e(
                      "text",
                      {
                        x: l.x,
                        y: l.y - 4,
                        textAnchor: "middle",
                        fontSize: "13",
                        fontWeight: 700,
                        fill: r ? "#ffffff" : "var(--ink)",
                        fillOpacity: i === null || r ? 1 : 0.4,
                        children: t.product
                      }
                    ),
                    /* @__PURE__ */ e(
                      "text",
                      {
                        x: l.x,
                        y: l.y + 12,
                        textAnchor: "middle",
                        fontSize: "11",
                        fill: r ? "#ffffff" : "var(--ink-soft)",
                        fillOpacity: i === null || r ? 1 : 0.4,
                        children: t.productLabel
                      }
                    )
                  ]
                },
                t.id
              );
            }),
            /* @__PURE__ */ e(
              "circle",
              {
                cx: c,
                cy: c,
                r: m,
                fill: "var(--accent)",
                stroke: "var(--bg-elevated)",
                strokeWidth: 3
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: c,
                y: c - 4,
                textAnchor: "middle",
                fontSize: "18",
                fontWeight: 800,
                fill: "var(--accent-ink)",
                children: "ArN₂⁺"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: c,
                y: c + 16,
                textAnchor: "middle",
                fontSize: "11",
                fill: "var(--accent-ink)",
                fillOpacity: 0.85,
                children: "芳基重氮盐"
              }
            )
          ]
        }
      ) }),
      /* @__PURE__ */ n("div", { className: "flex w-full flex-col gap-3 lg:w-72", children: [
        /* @__PURE__ */ e("div", { className: "grid grid-cols-2 gap-2", children: p.map((t) => {
          const r = t.id === i, a = f[t.category];
          return /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: () => d(t.id),
              className: "rounded-lg border px-2 py-2 text-left text-sm transition-colors",
              style: {
                borderColor: r ? a : "var(--line)",
                backgroundColor: r ? a : "var(--bg-muted)",
                color: r ? "var(--fp-on-primary)" : "var(--ink)"
              },
              children: [
                /* @__PURE__ */ e("span", { className: "block font-semibold", children: t.reagent }),
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "block text-xs",
                    style: {
                      color: r ? "rgba(255,255,255,0.85)" : "var(--ink-soft)"
                    },
                    children: t.condition
                  }
                )
              ]
            },
            t.id
          );
        }) }),
        /* @__PURE__ */ e("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: o ? /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-sm font-semibold",
              style: { color: f[o.category] },
              children: o.reactionName
            }
          ),
          /* @__PURE__ */ n("div", { className: "mt-1 text-sm text-[var(--ink)]", children: [
            "ArN₂⁺  ",
            /* @__PURE__ */ e("span", { className: "font-semibold", children: o.reagent }),
            " → ",
            /* @__PURE__ */ n("span", { className: "font-semibold", children: [
              o.product,
              "（",
              o.productLabel,
              "）"
            ] })
          ] }),
          /* @__PURE__ */ e("p", { className: "mt-2 text-xs leading-relaxed text-[var(--ink-soft)]", children: o.description })
        ] }) : /* @__PURE__ */ e("p", { className: "text-xs leading-relaxed text-[var(--ink-soft)]", children: "点击任一试剂按钮（或图中产物），高亮对应的转化路径并查看反应名称与说明。" }) })
      ] })
    ] })
  ] });
}
const H = y(C);
export {
  H as default
};
