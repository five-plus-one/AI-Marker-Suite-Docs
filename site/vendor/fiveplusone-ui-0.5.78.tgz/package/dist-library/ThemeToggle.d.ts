export interface ThemeToggleProps {
    dark: boolean;
    onChange: (dark: boolean) => void;
    disabled?: boolean;
}
/** A single action for the next appearance; system preference belongs in full settings. */
export declare function ThemeToggle({ dark, onChange, disabled }: ThemeToggleProps): import("react").JSX.Element;
