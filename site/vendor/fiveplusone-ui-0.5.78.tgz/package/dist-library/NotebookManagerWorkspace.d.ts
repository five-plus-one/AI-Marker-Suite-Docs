import { type PublishedNotebook, type NotebookDraft, type NotebookPublishingProps, type NotebookRelease } from "./NotebookPublishing";
export interface ManagedNotebookDraft extends NotebookDraft {
    notebookId?: string;
}
export interface NotebookManagerWorkspaceProps {
    notebooks: PublishedNotebook[];
    drafts: ManagedNotebookDraft[];
    versions?: Record<string, NotebookRelease[]>;
    loading?: boolean;
    error?: string;
    onPrepare: NotebookPublishingProps["onPrepare"];
    onPublish: NotebookPublishingProps["onPublish"];
    onSetSource?: (notebookId: string, input: {
        sourcePrefix: string;
        syncMode: "review" | "auto";
    }) => Promise<void> | void;
    onRestore?: (notebookId: string, releaseId: string, expectedRelease: string) => Promise<void> | void;
    onLoadVersions?: (notebookId: string) => Promise<void> | void;
    onRefresh?: () => Promise<void> | void;
    resolveResourceUrl?: NotebookPublishingProps["resolveResourceUrl"];
}
export declare function NotebookManagerWorkspace({ notebooks, drafts, versions, loading, error, onPrepare, onPublish, onSetSource, onRestore, onLoadVersions, onRefresh, resolveResourceUrl, }: NotebookManagerWorkspaceProps): import("react").JSX.Element;
