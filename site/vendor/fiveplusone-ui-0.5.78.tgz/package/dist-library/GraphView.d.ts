export interface GraphNode {
    id: string;
    label: string;
    kind?: string;
}
export interface GraphEdge {
    source: string;
    target: string;
}
export interface GraphSettings {
    showArrows: boolean;
    textOpacity: number;
    nodeSize: number;
    lineThickness: number;
    centerForce: number;
    repelForce: number;
    linkForce: number;
    colorGroups: {
        query: string;
        color: string;
    }[];
}
export declare const defaultGraphSettings: GraphSettings;
export interface GraphViewProps {
    nodes: GraphNode[];
    edges: GraphEdge[];
    selectedId?: string;
    onSelect: (id: string) => void;
    settings?: GraphSettings;
    onSettingsChange?: (settings: GraphSettings) => void;
    onRefresh?: () => void;
    onClose?: () => void;
    loading?: boolean;
    error?: string;
}
/** A live force-directed canvas, with an accessible search and note inspector. */
export declare function GraphView({ nodes, edges, selectedId, onSelect, settings: controlled, onSettingsChange, onRefresh, onClose, loading, error }: GraphViewProps): import("react").JSX.Element;
