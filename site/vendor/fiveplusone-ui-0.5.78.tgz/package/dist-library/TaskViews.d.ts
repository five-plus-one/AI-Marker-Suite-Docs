import { type ReactNode } from "react";
export interface RecycledItem {
    id: string;
    name: string;
    originalPath: string;
    deletedAt: string;
    size?: string;
}
export declare function RecycleBin({ items, selectedIds, onSelectionChange, onRestore, onDelete, loading, error, }: {
    items: RecycledItem[];
    selectedIds: string[];
    onSelectionChange: (ids: string[]) => void;
    onRestore: (ids: string[]) => Promise<void> | void;
    onDelete: (ids: string[]) => Promise<void> | void;
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
export interface ReviewRecord {
    id: string;
    title: string;
    subject?: string;
    due: string;
    status: "new" | "learning" | "review";
    detail?: string;
}
export declare function ReviewDashboard({ items, onReview, onPreview, loading, error, }: {
    items: ReviewRecord[];
    onReview: (ids: string[]) => void;
    onPreview: (id: string) => void;
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
export interface QuizNavigationItem {
    id: string;
    label: string;
    answered: boolean;
    flagged?: boolean;
}
export declare function QuizWorkspace({ title, items, activeId, onNavigate, children, onSubmit, remainingLabel, }: {
    title: string;
    items: QuizNavigationItem[];
    activeId: string;
    onNavigate: (id: string) => void;
    children: ReactNode;
    onSubmit: () => Promise<void> | void;
    remainingLabel?: string;
}): import("react").JSX.Element;
export declare function SelectionActions({ items, }: {
    items: {
        id: string;
        label: string;
        onSelect: () => void;
        disabled?: boolean;
    }[];
}): import("react").JSX.Element;
export declare function TaskProgress({ title, detail, value, onCancel, children, }: {
    title: string;
    detail?: string;
    value?: number;
    onCancel?: () => void;
    children?: ReactNode;
}): import("react").JSX.Element;
export declare function WorkspaceEmpty({ title, description, actions, }: {
    title?: string;
    description?: string;
    actions?: ReactNode;
}): import("react").JSX.Element;
export declare function RunWorkspace({ title, status, actions, trace, children, attachments, }: {
    title: string;
    status?: string;
    actions?: ReactNode;
    trace?: ReactNode;
    children: ReactNode;
    attachments?: ReactNode;
}): import("react").JSX.Element;
export interface RecordingFrame {
    time: number;
    label: string;
}
export declare function RecordingPlayback({ title, frames, time, duration, playing, onTimeChange, onPlayingChange, children, }: {
    title: string;
    frames: RecordingFrame[];
    time: number;
    duration: number;
    playing: boolean;
    onTimeChange: (time: number) => void;
    onPlayingChange: (playing: boolean) => void;
    children: ReactNode;
}): import("react").JSX.Element;
