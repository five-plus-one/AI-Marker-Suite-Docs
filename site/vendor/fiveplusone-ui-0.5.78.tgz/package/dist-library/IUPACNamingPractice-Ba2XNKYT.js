import { jsxs as o, jsx as t } from "react/jsx-runtime";
import { memo as S, useState as f } from "react";
const s = "var(--fp-primary)", A = "var(--fp-primary-soft)", y = "#b45309", c = [
  {
    id: "2-methylbutane",
    label: "丁烷主链 + 1 个甲基",
    mainChainLength: 4,
    parentName: "丁烷",
    substituents: [{ position: 2, name: "甲基" }],
    systematicName: "2-甲基丁烷",
    steps: [
      "① 选最长碳链：找出含碳最多的连续碳链，共 4 个碳，作为主链，词根为「丁烷」。",
      "② 编号：从靠近取代基的一端开始编号，使取代基位号最小。本例从右端编号，甲基落在 2 号碳（左端编号会得到 3 号，故选 2 号）。",
      "③ 列取代基：2 号碳上有 1 个甲基，记作「2-甲基」。",
      "④ 组合：取代基位号-取代基名 + 主链名 = 2-甲基丁烷。"
    ]
  },
  {
    id: "23-dimethylpentane",
    label: "戊烷主链 + 2 个甲基",
    mainChainLength: 5,
    parentName: "戊烷",
    substituents: [
      { position: 2, name: "甲基" },
      { position: 3, name: "甲基" }
    ],
    systematicName: "2,3-二甲基戊烷",
    steps: [
      "① 选最长碳链：最长连续碳链含 5 个碳，主链词根为「戊烷」。",
      "② 编号：从靠近取代基的一端编号，使位号组 (2,3) 最小（另一端编号为 (3,4)，较大）。",
      "③ 列取代基：2 号与 3 号碳各有 1 个甲基，相同取代基合并并用「二」表示倍数，记作「2,3-二甲基」。",
      "④ 组合：位号按从小到大排列，组合成 2,3-二甲基戊烷。"
    ]
  },
  {
    id: "3-ethyl-2-methylhexane",
    label: "己烷主链 + 1 个乙基 + 1 个甲基",
    mainChainLength: 6,
    parentName: "己烷",
    substituents: [
      { position: 2, name: "甲基" },
      { position: 3, name: "乙基" }
    ],
    systematicName: "3-乙基-2-甲基己烷",
    steps: [
      "① 选最长碳链：最长连续碳链含 6 个碳，主链词根为「己烷」。",
      "② 编号：从靠近取代基的一端编号，使位号组 (2,3) 最小。",
      "③ 列取代基：2 号碳上有甲基，3 号碳上有乙基。",
      "④ 组合：不同取代基按汉字（或英文字母）顺序排列，「乙基」先于「甲基」，故写成 3-乙基-2-甲基己烷。"
    ]
  },
  {
    id: "224-trimethylpentane",
    label: "戊烷主链 + 3 个甲基（异辛烷）",
    mainChainLength: 5,
    parentName: "戊烷",
    substituents: [
      { position: 2, name: "甲基" },
      { position: 2, name: "甲基" },
      { position: 4, name: "甲基" }
    ],
    systematicName: "2,2,4-三甲基戊烷",
    steps: [
      "① 选最长碳链：最长连续碳链含 5 个碳，主链词根为「戊烷」。",
      "② 编号：从靠近取代基的一端编号，使位号组 (2,2,4) 最小（另一端为 (2,4,4)，较大）。",
      "③ 列取代基：2 号碳上有 2 个甲基、4 号碳上有 1 个甲基，共 3 个甲基，用「三」表示倍数，记作「2,2,4-三甲基」。",
      "④ 组合：2,2,4-三甲基戊烷（即俗称的「异辛烷」）。"
    ]
  },
  {
    id: "3-methylhexane",
    label: "己烷主链 + 1 个甲基",
    mainChainLength: 6,
    parentName: "己烷",
    substituents: [{ position: 3, name: "甲基" }],
    systematicName: "3-甲基己烷",
    steps: [
      "① 选最长碳链：最长连续碳链含 6 个碳，主链词根为「己烷」。",
      "② 编号：从两端分别编号，靠近取代基一端使甲基位于 3 号碳（另一端为 4 号，较大），故取 3 号。",
      "③ 列取代基：3 号碳上有 1 个甲基，记作「3-甲基」。",
      "④ 组合：3-甲基己烷。"
    ]
  }
], v = 56, P = 70, U = 110;
function $(a) {
  const m = 40 + a * v, r = a % 2 === 0 ? U : P;
  return { x: m, y: r };
}
function w() {
  const [a, m] = f(c[0].id), [r, b] = f(!1), i = c.find((e) => e.id === a) ?? c[0], d = Array.from(
    { length: i.mainChainLength },
    (e, n) => $(n)
  ), C = d.map((e) => `${e.x},${e.y}`).join(" "), u = 40 + (i.mainChainLength - 1) * v + 40, g = 180;
  function N(e) {
    m(e), b(!1);
  }
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-lg font-semibold", style: { color: "var(--ink)" }, children: "IUPAC 命名练习器" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm", style: { color: "var(--ink-soft)" }, children: "选择一个支链烷烃结构，观察它的碳骨架，再点击「显示命名步骤」逐步推导其 IUPAC 系统名。换不同结构反复练习，掌握「选主链 → 编号 → 列取代基 → 组合」的命名套路。" }),
    /* @__PURE__ */ t("div", { className: "mt-4 flex flex-wrap gap-2", children: c.map((e) => {
      const n = e.id === a;
      return /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => N(e.id),
          className: "rounded-lg border px-3 py-1.5 text-sm transition-colors",
          style: {
            borderColor: n ? s : "var(--line)",
            backgroundColor: n ? s : "var(--bg-muted)",
            color: n ? "var(--fp-on-primary)" : "var(--ink)"
          },
          children: e.label
        },
        e.id
      );
    }) }),
    /* @__PURE__ */ t("div", { className: "mt-4 overflow-x-auto rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: /* @__PURE__ */ o(
      "svg",
      {
        width: u,
        height: g,
        viewBox: `0 0 ${u} ${g}`,
        role: "img",
        "aria-label": `${i.label} 的碳骨架示意图`,
        children: [
          /* @__PURE__ */ t(
            "polyline",
            {
              points: C,
              fill: "none",
              stroke: s,
              strokeWidth: 3,
              strokeLinejoin: "round",
              strokeLinecap: "round"
            }
          ),
          i.substituents.map((e, n) => {
            const l = d[e.position - 1], x = i.substituents.filter(
              (L) => L.position === e.position
            ), k = (x.indexOf(e) - (x.length - 1) / 2) * 22, h = l.x + k, p = l.y - 40;
            return /* @__PURE__ */ o("g", { children: [
              /* @__PURE__ */ t(
                "line",
                {
                  x1: l.x,
                  y1: l.y,
                  x2: h,
                  y2: p,
                  stroke: y,
                  strokeWidth: 2.5,
                  strokeLinecap: "round"
                }
              ),
              /* @__PURE__ */ t("circle", { cx: h, cy: p, r: 4, fill: y }),
              /* @__PURE__ */ t(
                "text",
                {
                  x: h,
                  y: p - 8,
                  textAnchor: "middle",
                  fontSize: 12,
                  fill: y,
                  fontWeight: 600,
                  children: e.name
                }
              )
            ] }, `${e.position}-${e.name}-${n}`);
          }),
          d.map((e, n) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ t(
              "circle",
              {
                cx: e.x,
                cy: e.y,
                r: 5,
                fill: A,
                stroke: s,
                strokeWidth: 1.5
              }
            ),
            /* @__PURE__ */ o(
              "text",
              {
                x: e.x,
                y: e.y + 24,
                textAnchor: "middle",
                fontSize: 12,
                fill: "var(--ink-soft)",
                children: [
                  "C",
                  n + 1
                ]
              }
            )
          ] }, `carbon-${n}`))
        ]
      }
    ) }),
    /* @__PURE__ */ o("div", { className: "mt-4 flex items-center gap-3", children: [
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => b((e) => !e),
          className: "rounded-lg px-4 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90",
          style: { backgroundColor: s },
          children: r ? "隐藏命名步骤" : "显示命名步骤"
        }
      ),
      /* @__PURE__ */ o("span", { className: "text-sm", style: { color: "var(--ink-soft)" }, children: [
        "主链 ",
        i.mainChainLength,
        " 个碳 · 取代基",
        " ",
        i.substituents.length,
        " 个"
      ] })
    ] }),
    r && /* @__PURE__ */ o("div", { className: "mt-4 space-y-3", children: [
      /* @__PURE__ */ t("ol", { className: "space-y-2", children: i.steps.map((e, n) => /* @__PURE__ */ t(
        "li",
        {
          className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 text-sm leading-relaxed",
          style: { color: "var(--ink)" },
          children: e
        },
        n
      )) }),
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg border-2 p-4 text-center",
          style: {
            borderColor: s,
            backgroundColor: "rgba(20, 184, 166, 0.12)"
          },
          children: [
            /* @__PURE__ */ t("div", { className: "text-xs", style: { color: "var(--ink-soft)" }, children: "正确的 IUPAC 系统名" }),
            /* @__PURE__ */ t(
              "div",
              {
                className: "mt-1 text-xl font-bold tracking-wide",
                style: { color: s },
                children: i.systematicName
              }
            )
          ]
        }
      )
    ] })
  ] });
}
const O = S(w);
export {
  O as default
};
