import type { ReactNode } from 'react';
export interface TransferTask {
    id: string;
    name: string;
    direction: 'upload' | 'download';
    status: 'queued' | 'active' | 'done' | 'error' | 'cancelled';
    progress?: number;
    detail?: string;
    indeterminate?: boolean;
    cancellable?: boolean;
    retryable?: boolean;
}
export interface TransferQueueProps {
    tasks: TransferTask[];
    title?: string;
    variant?: 'panel' | 'page';
    showHeader?: boolean;
    onCancel?: (task: TransferTask) => void;
    onRetry?: (task: TransferTask) => void;
    onDismiss?: (task: TransferTask) => void;
    onOpen?: (task: TransferTask) => void;
    onReveal?: (task: TransferTask) => void;
    headerActions?: ReactNode;
    collapsed?: boolean;
    onCollapsedChange?: (collapsed: boolean) => void;
}
export declare function TransferQueue({ tasks, title, variant, showHeader, onCancel, onRetry, onDismiss, onOpen, onReveal, headerActions, collapsed, onCollapsedChange }: TransferQueueProps): import("react").JSX.Element;
