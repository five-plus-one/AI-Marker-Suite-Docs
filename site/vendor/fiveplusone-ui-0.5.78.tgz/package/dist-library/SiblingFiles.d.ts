/** SiblingFiles - 从课栈 layout/SiblingFilesPanel 提取
 *
 * 同级内容快速切换：列出同一分类下的条目，带完成状态图标。
 * 适合"上一篇 / 下一篇"式的浏览，而不必回到文件树。
 */
export type SiblingStatus = "done" | "draft" | "stub";
export interface SiblingItem {
    id: string;
    title: string;
    status?: SiblingStatus;
    detail?: string;
}
export interface SiblingFilesProps {
    items: SiblingItem[];
    activeId?: string | null;
    onSelect: (item: SiblingItem) => void;
    label?: string;
}
export declare function SiblingFiles({ items, activeId, onSelect, label, }: SiblingFilesProps): import("react").JSX.Element | null;
