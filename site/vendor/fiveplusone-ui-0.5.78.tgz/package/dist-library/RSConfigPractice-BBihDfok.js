import { jsxs as r, jsx as t } from "react/jsx-runtime";
import { memo as S, useState as v } from "react";
const C = [
  {
    id: "glyceraldehyde",
    name: "D-甘油醛 (D-glyceraldehyde)",
    centerLabel: "C2 手性碳",
    substituents: [
      { label: "—OH", firstAtom: "O", atomicNumber: 8 },
      { label: "—CHO (醛基)", firstAtom: "C", atomicNumber: 6 },
      { label: "—CH₂OH", firstAtom: "C", atomicNumber: 6 },
      { label: "—H", firstAtom: "H", atomicNumber: 1 }
    ],
    answer: "R",
    note: "OH(O=8) 最高；CHO 与 CH₂OH 首原子同为 C，比较其连接原子：CHO 接 (O,O,H) 高于 CH₂OH 接 (O,H,H)，故 CHO>CH₂OH；H 最低。D-甘油醛构型为 R。"
  },
  {
    id: "lactic-acid",
    name: "L-乳酸 (L-lactic acid)",
    centerLabel: "C2 手性碳",
    substituents: [
      { label: "—OH", firstAtom: "O", atomicNumber: 8 },
      { label: "—COOH (羧基)", firstAtom: "C", atomicNumber: 6 },
      { label: "—CH₃", firstAtom: "C", atomicNumber: 6 },
      { label: "—H", firstAtom: "H", atomicNumber: 1 }
    ],
    answer: "S",
    note: "OH(O=8) 最高；COOH 与 CH₃ 首原子同为 C，COOH 接 (O,O,O) 远高于 CH₃ 接 (H,H,H)，故 COOH>CH₃；H 最低。L-乳酸构型为 S。"
  },
  {
    id: "bromochlorofluoromethane",
    name: "溴氯氟甲烷 (CHBrClF)",
    centerLabel: "中心 C 手性碳",
    substituents: [
      { label: "—Br", firstAtom: "Br", atomicNumber: 35 },
      { label: "—Cl", firstAtom: "Cl", atomicNumber: 17 },
      { label: "—F", firstAtom: "F", atomicNumber: 9 },
      { label: "—H", firstAtom: "H", atomicNumber: 1 }
    ],
    answer: "R",
    note: "四个取代基首原子各不相同，直接按原子序数排：Br(35)>Cl(17)>F(9)>H(1)。此处展示的对映体 a→b→c 顺时针，构型为 R。"
  },
  {
    id: "bromochloroiodomethane",
    name: "溴氯碘甲烷 (CHBrClI)",
    centerLabel: "中心 C 手性碳",
    substituents: [
      { label: "—I", firstAtom: "I", atomicNumber: 53 },
      { label: "—Br", firstAtom: "Br", atomicNumber: 35 },
      { label: "—Cl", firstAtom: "Cl", atomicNumber: 17 },
      { label: "—H", firstAtom: "H", atomicNumber: 1 }
    ],
    answer: "S",
    note: "首原子各异，按原子序数排：I(53)>Br(35)>Cl(17)>H(1)。此处展示的对映体 a→b→c 逆时针，构型为 S。"
  }
];
function R(o) {
  return [...o.substituents].sort((m, a) => a.atomicNumber - m.atomicNumber);
}
const H = ["a", "b", "c", "d"], i = [
  "var(--primary, #2563eb)",
  "#0891b2",
  "#d97706",
  "var(--ink-soft)"
];
function $() {
  const [o, m] = v(0), [a, b] = v(0), [h, f] = v(null), n = C[o], s = R(n);
  function x(e) {
    m(e), b(0), f(null);
  }
  function g() {
    b((e) => e < 3 ? e + 1 : e);
  }
  function A() {
    b((e) => e > 0 ? e - 1 : e);
  }
  const y = h !== null && h === n.answer, c = 170, d = 150, N = [
    { x: c, y: d - 90 },
    // 顶部 — a
    { x: c + 88, y: d + 60 },
    // 右下 — b
    { x: c - 88, y: d + 60 }
    // 左下 — c
  ], u = { x: c, y: d + 105 };
  function p(e) {
    return a === 0 ? !0 : a === 1 ? e === 0 : a !== 2;
  }
  return /* @__PURE__ */ r("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "R / S 构型判定练习" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "选一个手性分子，按顺序规则给四个基团排优先级 a>b>c>d，把最小基团 d 朝后，再看 a→b→c 是顺时针（R）还是逆时针（S）。" }),
    /* @__PURE__ */ t("div", { className: "mt-4 flex flex-wrap gap-2", children: C.map((e, l) => /* @__PURE__ */ t(
      "button",
      {
        type: "button",
        onClick: () => x(l),
        className: "rounded-lg border px-3 py-1.5 text-sm transition-colors " + (l === o ? "border-transparent bg-[var(--primary,#2563eb)] text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)] hover:border-[var(--ink-soft)]"),
        children: e.name
      },
      e.id
    )) }),
    /* @__PURE__ */ r("div", { className: "mt-4 grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-2", children: /* @__PURE__ */ r(
        "svg",
        {
          viewBox: "0 0 340 300",
          className: "h-auto w-full",
          role: "img",
          "aria-label": `${n.name} 的手性碳四面体示意`,
          children: [
            /* @__PURE__ */ t(
              "line",
              {
                x1: c,
                y1: d,
                x2: u.x,
                y2: u.y,
                stroke: "var(--ink-soft)",
                strokeWidth: 2,
                strokeDasharray: "5 4"
              }
            ),
            N.map((e, l) => /* @__PURE__ */ t(
              "line",
              {
                x1: c,
                y1: d,
                x2: e.x,
                y2: e.y,
                stroke: p(l) ? i[l] : "var(--line)",
                strokeWidth: p(l) ? 3.5 : 2
              },
              `bond-${l}`
            )),
            a === 3 && /* @__PURE__ */ r("g", { children: [
              /* @__PURE__ */ t(
                "path",
                {
                  d: L(c, d, 58, n.answer),
                  fill: "none",
                  stroke: "var(--primary,#2563eb)",
                  strokeWidth: 3,
                  markerEnd: "url(#arrowHead)"
                }
              ),
              /* @__PURE__ */ t("defs", { children: /* @__PURE__ */ t(
                "marker",
                {
                  id: "arrowHead",
                  markerWidth: "8",
                  markerHeight: "8",
                  refX: "4",
                  refY: "4",
                  orient: "auto",
                  children: /* @__PURE__ */ t("path", { d: "M0,0 L8,4 L0,8 Z", fill: "var(--primary,#2563eb)" })
                }
              ) })
            ] }),
            /* @__PURE__ */ t(
              "circle",
              {
                cx: c,
                cy: d,
                r: 16,
                fill: "var(--bg-elevated)",
                stroke: "var(--ink)",
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: c,
                y: d + 4,
                textAnchor: "middle",
                fontSize: 13,
                fontWeight: 600,
                fill: "var(--ink)",
                children: "C"
              }
            ),
            N.map((e, l) => {
              const w = s[l], k = p(l);
              return /* @__PURE__ */ r("g", { children: [
                /* @__PURE__ */ t(
                  "circle",
                  {
                    cx: e.x,
                    cy: e.y,
                    r: 18,
                    fill: k ? i[l] : "var(--bg-elevated)",
                    stroke: i[l],
                    strokeWidth: 2
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: e.x,
                    y: e.y + 4,
                    textAnchor: "middle",
                    fontSize: 13,
                    fontWeight: 700,
                    fill: k ? "white" : i[l],
                    children: H[l]
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: e.x,
                    y: e.y - 26,
                    textAnchor: "middle",
                    fontSize: 12,
                    fill: "var(--ink)",
                    children: w.label
                  }
                )
              ] }, `v-${l}`);
            }),
            /* @__PURE__ */ t(
              "circle",
              {
                cx: u.x,
                cy: u.y,
                r: 18,
                fill: a === 2 ? i[3] : "var(--bg-elevated)",
                stroke: i[3],
                strokeWidth: 2,
                strokeDasharray: a === 2 ? "0" : "4 3"
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: u.x,
                y: u.y + 4,
                textAnchor: "middle",
                fontSize: 13,
                fontWeight: 700,
                fill: a === 2 ? "white" : i[3],
                children: "d"
              }
            ),
            /* @__PURE__ */ r(
              "text",
              {
                x: u.x,
                y: u.y + 34,
                textAnchor: "middle",
                fontSize: 12,
                fill: "var(--ink-soft)",
                children: [
                  s[3].label,
                  "（朝后）"
                ]
              }
            )
          ]
        }
      ) }),
      /* @__PURE__ */ r("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] p-3", children: [
          /* @__PURE__ */ r("div", { className: "text-xs font-medium uppercase tracking-wide text-[var(--ink-soft)]", children: [
            n.name,
            " · ",
            n.centerLabel
          ] }),
          /* @__PURE__ */ r("div", { className: "mt-2 min-h-[150px] text-sm text-[var(--ink)]", children: [
            a === 0 && /* @__PURE__ */ r("div", { children: [
              /* @__PURE__ */ t("p", { className: "font-semibold", children: "第 ① 步：按顺序规则排优先级" }),
              /* @__PURE__ */ t("p", { className: "mt-1 text-[var(--ink-soft)]", children: "比较每个取代基第一个原子的原子序数，越大优先级越高。" }),
              /* @__PURE__ */ t("ol", { className: "mt-2 space-y-1", children: s.map((e, l) => /* @__PURE__ */ r("li", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ t(
                  "span",
                  {
                    className: "inline-flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold text-white",
                    style: { backgroundColor: i[l] },
                    children: H[l]
                  }
                ),
                /* @__PURE__ */ r("span", { children: [
                  e.label,
                  /* @__PURE__ */ r("span", { className: "text-[var(--ink-soft)]", children: [
                    " ",
                    "（首原子 ",
                    e.firstAtom,
                    "，序数 ",
                    e.atomicNumber,
                    "）"
                  ] })
                ] })
              ] }, e.label)) }),
              /* @__PURE__ */ t("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: "优先级：a > b > c > d" })
            ] }),
            a === 1 && /* @__PURE__ */ r("div", { children: [
              /* @__PURE__ */ t("p", { className: "font-semibold", children: "第 ① 步小结：a 最高、d 最低" }),
              /* @__PURE__ */ r("p", { className: "mt-1", children: [
                "最高优先级",
                " ",
                /* @__PURE__ */ r("strong", { style: { color: i[0] }, children: [
                  "a = ",
                  s[0].label
                ] }),
                "，最低优先级",
                " ",
                /* @__PURE__ */ r("strong", { style: { color: i[3] }, children: [
                  "d = ",
                  s[3].label
                ] }),
                "。"
              ] }),
              /* @__PURE__ */ t("p", { className: "mt-2 text-[var(--ink-soft)]", children: n.note })
            ] }),
            a === 2 && /* @__PURE__ */ r("div", { children: [
              /* @__PURE__ */ t("p", { className: "font-semibold", children: "第 ② 步：把最小基团 d 朝后" }),
              /* @__PURE__ */ r("p", { className: "mt-1", children: [
                "将",
                " ",
                /* @__PURE__ */ r("strong", { style: { color: i[3] }, children: [
                  "d = ",
                  s[3].label
                ] }),
                " ",
                "放到远离观察者的方向（图中虚线键，现已高亮）。"
              ] }),
              /* @__PURE__ */ t("p", { className: "mt-2 text-[var(--ink-soft)]", children: "这样剩下的 a、b、c 都朝向观察者，方便判断旋转方向。" })
            ] }),
            a === 3 && /* @__PURE__ */ r("div", { children: [
              /* @__PURE__ */ t("p", { className: "font-semibold", children: "第 ③ 步：看 a→b→c 的旋向" }),
              /* @__PURE__ */ r("p", { className: "mt-1", children: [
                "沿 a → b → c 画箭头：",
                /* @__PURE__ */ t("strong", { children: n.answer === "R" ? " 顺时针 ⟳ → R 构型" : " 逆时针 ⟲ → S 构型" }),
                "。"
              ] }),
              /* @__PURE__ */ r("div", { className: "mt-3", children: [
                /* @__PURE__ */ t("p", { className: "text-[var(--ink-soft)]", children: "先猜猜看：" }),
                /* @__PURE__ */ t("div", { className: "mt-1 flex gap-2", children: ["R", "S"].map((e) => /* @__PURE__ */ r(
                  "button",
                  {
                    type: "button",
                    onClick: () => f(e),
                    className: "rounded-lg border px-4 py-1.5 text-sm font-semibold transition-colors " + (h === e ? "border-transparent bg-[var(--primary,#2563eb)] text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)] hover:border-[var(--ink-soft)]"),
                    children: [
                      e,
                      " 构型"
                    ]
                  },
                  e
                )) }),
                h !== null && /* @__PURE__ */ t(
                  "p",
                  {
                    className: "mt-2 text-sm font-semibold",
                    style: { color: y ? "#16a34a" : "#dc2626" },
                    children: y ? `正确！${n.name} 是 ${n.answer} 构型。` : `再想想～正确答案是 ${n.answer} 构型。`
                  }
                )
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ r("div", { className: "mt-3 flex items-center justify-between", children: [
          /* @__PURE__ */ t(
            "button",
            {
              type: "button",
              onClick: A,
              disabled: a === 0,
              className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-1.5 text-sm text-[var(--ink)] transition-colors hover:border-[var(--ink-soft)] disabled:cursor-not-allowed disabled:opacity-40",
              children: "上一步"
            }
          ),
          /* @__PURE__ */ t("div", { className: "flex gap-1.5", children: [0, 1, 2, 3].map((e) => /* @__PURE__ */ t(
            "span",
            {
              className: "h-2 w-2 rounded-full",
              style: {
                backgroundColor: e === a ? "var(--primary,#2563eb)" : "var(--line)"
              }
            },
            e
          )) }),
          /* @__PURE__ */ t(
            "button",
            {
              type: "button",
              onClick: g,
              disabled: a === 3,
              className: "rounded-lg border border-transparent bg-[var(--primary,#2563eb)] px-3 py-1.5 text-sm font-semibold text-white transition-colors hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40",
              children: "下一步"
            }
          )
        ] })
      ] })
    ] })
  ] });
}
function L(o, m, a, b) {
  const f = b === "R" ? 130 : -310, n = O(o, m, a, -90), s = O(o, m, a, f), x = b === "R" ? 1 : 0;
  return `M ${n.x} ${n.y} A ${a} ${a} 0 0 ${x} ${s.x} ${s.y}`;
}
function O(o, m, a, b) {
  const h = b * Math.PI / 180;
  return { x: o + a * Math.cos(h), y: m + a * Math.sin(h) };
}
const W = S($);
export {
  W as default
};
