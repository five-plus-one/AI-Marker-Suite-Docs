import { type SelectHTMLAttributes } from "react";
export declare function Select({ options, defaultValue, ...props }: SelectHTMLAttributes<HTMLSelectElement> & {
    options: {
        value: string;
        label: string;
    }[];
}): import("react").JSX.Element;
export declare function Combobox({ label, options, value, onChange, }: {
    label: string;
    options: string[];
    value: string;
    onChange: (value: string) => void;
}): import("react").JSX.Element;
