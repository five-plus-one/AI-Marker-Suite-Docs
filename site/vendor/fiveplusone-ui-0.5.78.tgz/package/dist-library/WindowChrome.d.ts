/** WindowChrome - 从课栈 window/WindowChrome 提取
 *
 * 浮动窗口标题栏：标题在左，附加操作和窗口控制在右。
 * 仅作为视觉外壳，窗口拖拽通过 onDragStart 交给调用方。
 */
import type { PointerEvent, ReactNode } from "react";
export interface WindowChromeProps {
    title: string;
    icon?: ReactNode;
    onClose: () => void;
    onMinimize?: () => void;
    onFullscreen?: () => void;
    isFullscreen?: boolean;
    children: ReactNode;
    onDragStart?: (event: PointerEvent<HTMLElement>) => void;
    /** 标题栏右侧附加操作 */
    actions?: ReactNode;
    className?: string;
    /** Fill a frameless native window; the host owns its content view. */
    native?: boolean;
    closeLabel?: string;
    closeShortcut?: string;
}
export declare function WindowChrome({ title, icon, onClose, onMinimize, onFullscreen, isFullscreen, children, onDragStart, actions, className, native, closeLabel, closeShortcut, }: WindowChromeProps): import("react").JSX.Element;
