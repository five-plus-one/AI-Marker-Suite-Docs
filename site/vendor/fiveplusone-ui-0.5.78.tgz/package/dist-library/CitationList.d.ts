/** CitationList - 从课栈 chat/NoteCitationCard 提取
 *
 * AI 回答中引用笔记时的折叠列表：显示条数与路径，展开后可逐条打开。
 */
export interface CitationHit {
    title: string;
    path: string;
    snippet?: string;
}
export interface CitationListProps {
    hits: CitationHit[];
    label?: string;
    onOpen?: (hit: CitationHit) => void;
    /** 顶部附加操作，例如「查看全部」。 */
    action?: {
        label: string;
        onClick: () => void;
    };
}
export declare function CitationList({ hits, label, onOpen, action, }: CitationListProps): import("react").JSX.Element | null;
