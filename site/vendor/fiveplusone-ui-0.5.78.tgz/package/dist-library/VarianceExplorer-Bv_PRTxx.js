import { jsxs as n, jsx as e, Fragment as ce } from "react/jsx-runtime";
import { learningAlpha as de } from "./index.js";
import { memo as xe, useState as $, useCallback as he } from "react";
const c = "#5b46e5", D = "color-mix(in srgb, #ede9fe 24%, var(--fp-surface))", W = "#8b5cf6", m = "#ea580c", L = "color-mix(in srgb, #ffedd5 24%, var(--fp-surface))", S = "#f97316", q = "var(--line)", J = 560, K = 210, E = 36, pe = 14, B = 16, me = 36, O = J - E - pe, G = K - B - me;
function T(l, d, o) {
  const b = 1 / (o * Math.sqrt(2 * Math.PI)), r = Math.exp(-0.5 * ((l - d) / o) ** 2);
  return b * r;
}
const X = -5, F = 5;
function h(l) {
  return E + (l - X) / (F - X) * O;
}
function j(l, d) {
  return B + G - l / d * G;
}
function Z(l, d, o, b = 320) {
  const r = [];
  for (let g = 0; g <= b; g++) {
    const s = X + g / b * (F - X), u = T(s, l, d), f = h(s).toFixed(2), C = j(u, o).toFixed(2);
    r.push(`${g === 0 ? "M" : "L"}${f},${C}`);
  }
  return r.join(" ");
}
function P(l, d, o, b, r = 160) {
  const g = l - b * d, s = l + b * d, u = Math.max(g, X), f = Math.min(s, F);
  if (u >= f) return "";
  const C = [];
  for (let w = 0; w <= r; w++) {
    const N = u + w / r * (f - u), R = T(N, l, d), y = h(N).toFixed(2), _ = j(R, o).toFixed(2);
    C.push(`${w === 0 ? "M" : "L"}${y},${_}`);
  }
  const i = j(0, o).toFixed(2), I = h(f).toFixed(2), p = h(u).toFixed(2);
  return `${C.join(" ")} L${I},${i} L${p},${i} Z`;
}
function Y({
  label: l,
  value: d,
  min: o,
  max: b,
  step: r,
  display: g,
  onChange: s,
  color: u
}) {
  return /* @__PURE__ */ n("div", { className: "flex flex-col gap-0.5", children: [
    /* @__PURE__ */ n("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: l }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded px-1.5 py-0.5 text-[12px] font-mono font-bold",
          style: { background: de(u, "22"), color: u },
          children: g
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: o,
        max: b,
        step: r,
        value: d,
        onChange: (f) => s(Number(f.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: u }
      }
    )
  ] });
}
function k({ label: l, value: d, color: o, bg: b }) {
  return /* @__PURE__ */ n("div", { className: "rounded-lg p-2 text-center", style: { background: b }, children: [
    /* @__PURE__ */ e("div", { className: "text-[10px] leading-snug text-[var(--ink-soft)]", children: l }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "mt-0.5 font-mono text-[15px] font-extrabold",
        style: { color: o },
        children: d
      }
    )
  ] });
}
function be() {
  const [l, d] = $(0), [o, b] = $(1), [r, g] = $(1.5), [s, u] = $(1.8), [f, C] = $(1), [i, I] = $(!0), [p, w] = $(2), [N, R] = $(1), y = o ** 2, _ = s ** 2, V = p ** 2 * y, Q = Math.abs(p) * o, ee = p * l + N, te = T(l, l, o), ne = T(r, r, s), M = Math.max(te, i ? ne : 0) * 1.12, U = [-4, -3, -2, -1, 0, 1, 2, 3, 4], A = j(0, M), le = Z(l, o, M), oe = Z(r, s, M), ae = P(l, o, M, 1), re = P(l, o, M, 2), se = P(r, s, M, 1), ie = P(r, s, M, 2), z = h(l), H = h(r), t = he((a, v = 3) => a.toFixed(v), []);
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "方差与分布扩散度可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "独立调整两个正态分布的均值 μ 和标准差 σ，观察曲线形状与扩散度的变化。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden bg-[var(--bg-muted)]", children: /* @__PURE__ */ n("svg", { viewBox: `0 0 ${J} ${K}`, className: "w-full", children: [
      /* @__PURE__ */ e(
        "rect",
        {
          x: E,
          y: B,
          width: O,
          height: G,
          fill: "var(--bg-muted)"
        }
      ),
      U.map((a) => /* @__PURE__ */ e(
        "line",
        {
          x1: h(a),
          y1: B,
          x2: h(a),
          y2: B + G,
          stroke: a === 0 ? "var(--ink-faint)" : q,
          strokeWidth: a === 0 ? 1.2 : 0.8,
          strokeDasharray: a === 0 ? void 0 : "3 3"
        },
        a
      )),
      f >= 2 && /* @__PURE__ */ n(ce, { children: [
        /* @__PURE__ */ e("path", { d: re, fill: c, opacity: 0.1 }),
        i && /* @__PURE__ */ e("path", { d: ie, fill: m, opacity: 0.1 })
      ] }),
      /* @__PURE__ */ e("path", { d: ae, fill: c, opacity: 0.18 }),
      i && /* @__PURE__ */ e("path", { d: se, fill: m, opacity: 0.18 }),
      /* @__PURE__ */ e(
        "line",
        {
          x1: z,
          y1: B,
          x2: z,
          y2: A,
          stroke: c,
          strokeWidth: 1.5,
          strokeDasharray: "5 3"
        }
      ),
      i && /* @__PURE__ */ e(
        "line",
        {
          x1: H,
          y1: B,
          x2: H,
          y2: A,
          stroke: m,
          strokeWidth: 1.5,
          strokeDasharray: "5 3"
        }
      ),
      i && /* @__PURE__ */ e("path", { d: oe, fill: "none", stroke: S, strokeWidth: 2.2 }),
      /* @__PURE__ */ e("path", { d: le, fill: "none", stroke: W, strokeWidth: 2.5 }),
      /* @__PURE__ */ e(
        "line",
        {
          x1: E,
          y1: A,
          x2: E + O,
          y2: A,
          stroke: "var(--ink-faint)",
          strokeWidth: 1
        }
      ),
      U.map((a) => /* @__PURE__ */ n("g", { children: [
        /* @__PURE__ */ e(
          "line",
          {
            x1: h(a),
            y1: A,
            x2: h(a),
            y2: A + 4,
            stroke: "var(--ink-faint)",
            strokeWidth: 1
          }
        ),
        /* @__PURE__ */ e(
          "text",
          {
            x: h(a),
            y: A + 13,
            fontSize: "9",
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            children: a
          }
        )
      ] }, a)),
      /* @__PURE__ */ n(
        "text",
        {
          x: z + 3,
          y: B + 10,
          fontSize: "10",
          fill: c,
          fontWeight: 700,
          children: [
            "μA=",
            t(l, 1)
          ]
        }
      ),
      i && /* @__PURE__ */ n(
        "text",
        {
          x: H + 3,
          y: B + 22,
          fontSize: "10",
          fill: m,
          fontWeight: 700,
          children: [
            "μB=",
            t(r, 1)
          ]
        }
      ),
      (() => {
        const a = h(Math.max(l - o, X)), v = h(Math.min(l + o, F)), x = A - 6;
        return v - a < 10 ? null : /* @__PURE__ */ n("g", { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: a,
              y1: x,
              x2: v,
              y2: x,
              stroke: c,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: a,
              y1: x - 3,
              x2: a,
              y2: x + 3,
              stroke: c,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: v,
              y1: x - 3,
              x2: v,
              y2: x + 3,
              stroke: c,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: (a + v) / 2,
              y: x - 4,
              fontSize: "8.5",
              textAnchor: "middle",
              fill: c,
              children: "±1σA"
            }
          )
        ] });
      })(),
      i && (() => {
        const a = h(Math.max(r - s, X)), v = h(Math.min(r + s, F)), x = A - 18;
        return v - a < 10 ? null : /* @__PURE__ */ n("g", { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: a,
              y1: x,
              x2: v,
              y2: x,
              stroke: m,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: a,
              y1: x - 3,
              x2: a,
              y2: x + 3,
              stroke: m,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: v,
              y1: x - 3,
              x2: v,
              y2: x + 3,
              stroke: m,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: (a + v) / 2,
              y: x - 4,
              fontSize: "8.5",
              textAnchor: "middle",
              fill: m,
              children: "±1σB"
            }
          )
        ] });
      })()
    ] }) }),
    /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-2 items-center", children: [
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: () => C(f === 1 ? 2 : 1),
          className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (f === 2 ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"),
          children: [
            f === 2 ? "显示 ±2σ" : "显示 ±1σ",
            " 区间"
          ]
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => I(!i),
          className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (i ? "bg-[#ffedd5] text-[#c2410c]" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"),
          children: i ? "隐藏分布 B" : "显示分布 B"
        }
      ),
      /* @__PURE__ */ e("span", { className: "ml-auto text-[11px] text-[var(--ink-soft)]", children: "阴影面积：±1σ ≈ 68.3%，±2σ ≈ 95.4%" })
    ] }),
    /* @__PURE__ */ n("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ n(
        "div",
        {
          className: "rounded-lg border-2 p-3 space-y-3",
          style: { borderColor: c, background: D + "55" },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[13px] font-bold", style: { color: c }, children: "分布 A（蓝色）" }),
            /* @__PURE__ */ e(
              Y,
              {
                label: "均值 μA",
                value: l,
                min: -3,
                max: 3,
                step: 0.1,
                display: t(l, 1),
                onChange: d,
                color: c
              }
            ),
            /* @__PURE__ */ e(
              Y,
              {
                label: "标准差 σA",
                value: o,
                min: 0.3,
                max: 3,
                step: 0.05,
                display: t(o, 2),
                onChange: b,
                color: W
              }
            ),
            /* @__PURE__ */ n("div", { className: "grid grid-cols-3 gap-1.5 pt-1", children: [
              /* @__PURE__ */ e(
                k,
                {
                  label: "E[X] = μ",
                  value: t(l, 2),
                  color: c,
                  bg: D
                }
              ),
              /* @__PURE__ */ e(
                k,
                {
                  label: "D[X] = σ²",
                  value: t(y, 3),
                  color: W,
                  bg: D
                }
              ),
              /* @__PURE__ */ e(
                k,
                {
                  label: "σ（标准差）",
                  value: t(o, 3),
                  color: "#7c3aed",
                  bg: D
                }
              )
            ] })
          ]
        }
      ),
      /* @__PURE__ */ n(
        "div",
        {
          className: "rounded-lg border-2 p-3 space-y-3 transition-opacity",
          style: {
            borderColor: m,
            background: L + "55",
            opacity: i ? 1 : 0.4
          },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[13px] font-bold", style: { color: m }, children: "分布 B（橙色）" }),
            /* @__PURE__ */ e(
              Y,
              {
                label: "均值 μB",
                value: r,
                min: -3,
                max: 3,
                step: 0.1,
                display: t(r, 1),
                onChange: g,
                color: m
              }
            ),
            /* @__PURE__ */ e(
              Y,
              {
                label: "标准差 σB",
                value: s,
                min: 0.3,
                max: 3,
                step: 0.05,
                display: t(s, 2),
                onChange: u,
                color: S
              }
            ),
            /* @__PURE__ */ n("div", { className: "grid grid-cols-3 gap-1.5 pt-1", children: [
              /* @__PURE__ */ e(
                k,
                {
                  label: "E[X] = μ",
                  value: t(r, 2),
                  color: m,
                  bg: L
                }
              ),
              /* @__PURE__ */ e(
                k,
                {
                  label: "D[X] = σ²",
                  value: t(_, 3),
                  color: S,
                  bg: L
                }
              ),
              /* @__PURE__ */ e(
                k,
                {
                  label: "σ（标准差）",
                  value: t(s, 3),
                  color: "#b45309",
                  bg: L
                }
              )
            ] })
          ]
        }
      )
    ] }),
    i && /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "对比分析：" }),
      o < s ? `分布 A（σ=${t(o, 2)}）比分布 B（σ=${t(s, 2)}）更集中，方差更小（${t(y, 3)} < ${t(_, 3)}），曲线更高更窄。` : o > s ? `分布 A（σ=${t(o, 2)}）比分布 B（σ=${t(s, 2)}）更分散，方差更大（${t(y, 3)} > ${t(_, 3)}），曲线更矮更宽。` : `两分布标准差相同（σ=${t(o, 2)}），形状完全一致，仅均值（${t(l, 1)} vs ${t(r, 1)}）不同，曲线只是平移关系。`
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 space-y-3", children: [
      /* @__PURE__ */ e("div", { className: "text-[13px] font-bold text-[var(--ink)]", children: "线性变换性质验算：D(aX + b) = a²·D(X)" }),
      /* @__PURE__ */ n("p", { className: "text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
        "对分布 A 做变换 Y = aX + b，调整 a、b 观察方差的变化——",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: " b 的平移完全不影响方差" }),
        "， 只有系数 a 的平方决定方差的缩放比。"
      ] }),
      /* @__PURE__ */ n("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ n("div", { className: "space-y-1", children: [
          /* @__PURE__ */ n("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "系数 a" }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "rounded px-1.5 py-0.5 text-[12px] font-mono font-bold",
                style: { background: D, color: c },
                children: t(p, 1)
              }
            )
          ] }),
          /* @__PURE__ */ e(
            "input",
            {
              type: "range",
              min: -3,
              max: 3,
              step: 0.1,
              value: p,
              onChange: (a) => w(Number(a.target.value)),
              className: "w-full h-1.5 cursor-pointer",
              style: { accentColor: c }
            }
          )
        ] }),
        /* @__PURE__ */ n("div", { className: "space-y-1", children: [
          /* @__PURE__ */ n("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "平移 b" }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "rounded px-1.5 py-0.5 text-[12px] font-mono font-bold",
                style: { background: q, color: "var(--ink-soft)" },
                children: t(N, 1)
              }
            )
          ] }),
          /* @__PURE__ */ e(
            "input",
            {
              type: "range",
              min: -4,
              max: 4,
              step: 0.1,
              value: N,
              onChange: (a) => R(Number(a.target.value)),
              className: "w-full h-1.5 cursor-pointer",
              style: { accentColor: "#64748b" }
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-elevated)] border border-[var(--line)] px-3 py-2.5 font-mono text-[12px] leading-loose text-[var(--ink-soft)] space-y-0.5", children: [
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "text-[var(--ink)]", children: "X" }),
          " ~ N(",
          /* @__PURE__ */ e("span", { style: { color: c }, children: t(l, 2) }),
          ", ",
          /* @__PURE__ */ e("span", { style: { color: W }, children: t(o, 3) }),
          ")",
          "，D[X] =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: W, fontWeight: 700 }, children: t(y, 4) })
        ] }),
        /* @__PURE__ */ e("div", { children: /* @__PURE__ */ n("span", { className: "text-[var(--ink)]", children: [
          "Y = ",
          t(p, 1),
          "X + ",
          t(N, 1)
        ] }) }),
        /* @__PURE__ */ n("div", { children: [
          "E[Y] = a·μ + b = ",
          t(p, 1),
          "×",
          t(l, 2),
          " + ",
          t(N, 1),
          " =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: m, fontWeight: 700 }, children: t(ee, 4) })
        ] }),
        /* @__PURE__ */ n("div", { children: [
          "D[Y] = a²·D[X] = ",
          t(p, 1),
          "² × ",
          t(y, 4),
          " =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: S, fontWeight: 700 }, children: t(V, 4) })
        ] }),
        /* @__PURE__ */ n("div", { children: [
          "σ[Y] = |a|·σ[X] = |",
          t(p, 1),
          "| × ",
          t(o, 4),
          " =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: "#b45309", fontWeight: 700 }, children: t(Q, 4) })
        ] })
      ] }),
      /* @__PURE__ */ n(
        "div",
        {
          className: "rounded-lg border-l-4 pl-3 py-1.5 text-[12px] text-[var(--ink-soft)] leading-relaxed",
          style: { borderColor: W, background: D },
          children: [
            /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "关键洞察：" }),
            "平移 b = ",
            t(N, 1),
            " 改变了均值，但方差",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: " 不变" }),
            '——方差度量的是"离散程度"， 整体移动不影响数据之间的相对距离。 而缩放 a = ',
            t(p, 1),
            " ",
            "让方差变为原来的",
            /* @__PURE__ */ n("b", { style: { color: W }, children: [
              " ",
              t(p ** 2, 3)
            ] }),
            " 倍。"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ n("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      /* @__PURE__ */ e(
        k,
        {
          label: "D[X_A] = σA²",
          value: t(y, 4),
          color: W,
          bg: D
        }
      ),
      i && /* @__PURE__ */ e(
        k,
        {
          label: "D[X_B] = σB²",
          value: t(_, 4),
          color: S,
          bg: L
        }
      ),
      /* @__PURE__ */ e(
        k,
        {
          label: "D[aX+b]",
          value: t(V, 4),
          color: m,
          bg: L
        }
      ),
      /* @__PURE__ */ e(
        k,
        {
          label: "a²·D[X_A]",
          value: t(p ** 2 * y, 4),
          color: c,
          bg: D
        }
      )
    ] })
  ] });
}
const ge = xe(be);
export {
  ge as default
};
