/** SelectionToolbar - 从课栈 notes/SelectionPopover 提取
 *
 * 划词后出现的浮动工具栏：靠近选区显示，支持键盘焦点，
 * 点击外部或按 Esc 收起，位置在视口内自动收敛。
 */
import { type ReactNode } from "react";
export interface SelectionAction {
    id: string;
    label: string;
    icon?: ReactNode;
    onClick: () => void;
    /** 危险操作用不同颜色 */
    danger?: boolean;
}
export interface SelectionToolbarProps {
    /** 选区矩形（来自 window.getSelection().getRangeAt(0).getBoundingClientRect()） */
    anchor: {
        x: number;
        y: number;
        width?: number;
    } | null;
    actions: SelectionAction[];
    onClose: () => void;
    /** 选中文本预览，显示在工具栏左侧 */
    preview?: string;
}
export declare function SelectionToolbar({ anchor, actions, onClose, preview, }: SelectionToolbarProps): import("react").ReactPortal | null;
