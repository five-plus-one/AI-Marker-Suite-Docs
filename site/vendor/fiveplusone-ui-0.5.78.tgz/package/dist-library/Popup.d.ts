import { type ReactNode } from "react";
export interface PopupProps {
    label: string;
    triggerRole?: "combobox";
    triggerId?: string;
    children: (close: () => void) => ReactNode;
    menu?: boolean;
    icon?: ReactNode;
    trigger?: ReactNode;
    disabled?: boolean;
    className?: string;
    role?: "menu" | "dialog" | "listbox";
    onOpenChange?: (open: boolean) => void;
    density?: "comfortable" | "compact";
}
/** Anchored surface with dismissal, keyboard navigation and viewport bounds. */
export declare function Popup({ label, triggerRole, triggerId, children, menu, icon, trigger: triggerContent, disabled, className, role: suppliedRole, onOpenChange, density, }: PopupProps): import("react").JSX.Element;
export declare function Dropdown({ label, items, icon, }: {
    label: string;
    icon?: ReactNode;
    items: {
        label: string;
        onClick: () => void;
        danger?: boolean;
    }[];
}): import("react").JSX.Element;
export declare function Popover({ label, children, }: {
    label: string;
    children: ReactNode;
}): import("react").JSX.Element;
