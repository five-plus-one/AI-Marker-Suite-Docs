export type WorkspaceTabAction = 'new-note' | 'close-tab' | 'next-tab' | 'previous-tab' | 'reopen-tab' | `tab-${number}`;
export type WorkspaceKeyInput = {
    key: string;
    ctrlKey?: boolean;
    metaKey?: boolean;
    altKey?: boolean;
    shiftKey?: boolean;
    isComposing?: boolean;
    repeat?: boolean;
};
/** Native clients own reserved keys; browser clients retain explicit alternatives. */
export declare function workspaceTabShortcut(input: WorkspaceKeyInput, native?: boolean): WorkspaceTabAction | null;
