import { type ReactNode } from 'react';
export type TooltipSide = 'top' | 'bottom' | 'left' | 'right';
/** One immediate, themed hint layer for controls, including legacy native titles. */
export declare function TooltipProvider({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function Tooltip({ text, children, side }: {
    text: string;
    children: ReactNode;
    side?: TooltipSide;
}): import("react").JSX.Element;
