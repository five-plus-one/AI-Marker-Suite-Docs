/** ImageGallery - 从课栈 chat/ImageStrip + NoteImageGallery 提取
 *
 * 横向图片画廊：可拖动滚动，点击打开灯箱查看大图。
 * 合并了两个原始组件的职责：拖动容器与图片列表。
 */
export interface GalleryImage {
    src: string;
    alt?: string;
    caption?: string;
}
export interface ImageGalleryProps {
    images: GalleryImage[];
    label?: string;
    /** 每张缩略图的边长 */
    size?: number;
    /** 顶栏右侧附加信息，例如检索词 */
    meta?: string;
}
export declare function ImageGallery({ images, label, size, meta, }: ImageGalleryProps): import("react").JSX.Element | null;
