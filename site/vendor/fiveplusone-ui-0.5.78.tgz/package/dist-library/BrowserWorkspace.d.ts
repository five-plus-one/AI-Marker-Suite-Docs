import { type ReactNode } from "react";
import { type BrowserBookmark } from "./BrowserPreferences";
export interface BrowserWorkspaceProps {
    url: string;
    onNavigate: (url: string) => void;
    children: ReactNode;
    homeUrl?: string;
    canBack?: boolean;
    canForward?: boolean;
    onBack?: () => void;
    onForward?: () => void;
    onRefresh?: () => void;
    onOpenExternal?: (url: string) => void;
    loading?: boolean;
    error?: string;
    viewport?: "desktop" | "mobile";
    onViewportChange?: (viewport: "desktop" | "mobile") => void;
    bookmarks?: BrowserBookmark[];
    onAddBookmark?: (bookmark: Omit<BrowserBookmark, "id">) => Promise<void> | void;
    onRemoveBookmark?: (id: string) => Promise<void> | void;
    onHomeChange?: (url: string) => Promise<void> | void;
}
export declare function BrowserWorkspace({ url, onNavigate, children, homeUrl, canBack, canForward, onBack, onForward, onRefresh, onOpenExternal, loading, error, viewport, onViewportChange, bookmarks, onAddBookmark, onRemoveBookmark, onHomeChange, }: BrowserWorkspaceProps): import("react").JSX.Element;
