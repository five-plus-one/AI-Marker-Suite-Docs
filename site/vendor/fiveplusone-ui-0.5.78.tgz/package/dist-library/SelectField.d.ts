export interface SelectOption {
    value: string;
    label: string;
    description?: string;
    disabled?: boolean;
    group?: string;
    color?: string;
    fontFamily?: string;
}
export interface SelectFieldProps {
    value: string;
    onChange: (value: string) => void;
    options: SelectOption[];
    label: string;
    id?: string;
    disabled?: boolean;
    placeholder?: string;
    className?: string;
    searchable?: boolean;
}
/** A themed single selection surface with shared dismissal and keyboard behavior. */
export declare function SelectField({ value, onChange, options, label, id, disabled, placeholder, className, searchable }: SelectFieldProps): import("react").JSX.Element;
