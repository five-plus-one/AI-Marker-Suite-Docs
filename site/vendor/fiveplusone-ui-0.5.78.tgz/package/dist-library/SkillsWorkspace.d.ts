export interface EditableSkill {
    id: string;
    name: string;
    description: string;
    content: string;
    pinned: boolean;
}
export interface SkillsWorkspaceProps {
    skills: EditableSkill[];
    maxSkills?: number;
    maxFileBytes?: number;
    onSave: (skills: EditableSkill[]) => Promise<void> | void;
    onExport?: (skill: EditableSkill) => void;
}
export declare function parseSkillFile(raw: string, filename: string): Omit<EditableSkill, "id" | "pinned">;
export declare function SkillsWorkspace({ skills, maxSkills, maxFileBytes, onSave, onExport, }: SkillsWorkspaceProps): import("react").JSX.Element;
