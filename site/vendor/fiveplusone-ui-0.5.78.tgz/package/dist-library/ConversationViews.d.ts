import { type ReactNode } from "react";
export interface MessageSection {
    id: string;
    label: string;
    content: ReactNode;
    kind?: "thinking" | "action" | "source" | "content";
    status?: "running" | "done" | "error";
    defaultOpen?: boolean;
}
export declare function MessageContentView({ sections, actions, }: {
    sections: MessageSection[];
    actions?: ReactNode;
}): import("react").JSX.Element;
export declare function ArtifactCard({ title, description, kind, onOpen, }: {
    title: string;
    description?: string;
    kind?: string;
    onOpen: () => void;
}): import("react").JSX.Element;
export declare function ArtifactPreview({ title, children, onDownload, onSave, loading, error, }: {
    title: string;
    children: ReactNode;
    onDownload?: () => void;
    onSave?: () => Promise<void> | void;
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
export interface SkillItem {
    id: string;
    name: string;
    description: string;
    enabled: boolean;
    disabled?: boolean;
}
export declare function SkillsPanel({ items, onToggle, }: {
    items: SkillItem[];
    onToggle: (id: string, enabled: boolean) => Promise<void> | void;
}): import("react").JSX.Element;
