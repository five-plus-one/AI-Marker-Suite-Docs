export interface PublishedNotebook {
    id: string;
    title: string;
    sourcePrefix: string;
    currentRelease: string;
    syncMode: "review" | "auto";
    checkedAt?: string;
}
export interface NotebookDraft {
    id: string;
    title: string;
    sections: number;
    resources: number;
    structureChanged: boolean;
    items: {
        id: string;
        title: string;
        kind: string;
        content: string;
    }[];
}
export interface NotebookRelease {
    id: string;
    createdAt: string;
    label?: string;
}
export interface NotebookPublishingProps {
    notebook?: PublishedNotebook;
    drafts?: NotebookDraft[];
    versions?: NotebookRelease[];
    onPrepare: (input: {
        notebookId?: string;
        sourcePrefix: string;
        manifest?: unknown;
    }) => Promise<NotebookDraft>;
    onPublish: (draftId: string, expectedRelease?: string) => Promise<void> | void;
    onSetSource?: (input: {
        sourcePrefix: string;
        syncMode: "review" | "auto";
    }) => Promise<void> | void;
    onRestore?: (releaseId: string, expectedRelease: string) => Promise<void> | void;
    onLoadVersions?: () => Promise<void> | void;
    onRefresh?: () => Promise<void> | void;
    resolveResourceUrl?: (url: string) => string;
}
export declare function NotebookPublishing(props: NotebookPublishingProps): import("react").JSX.Element;
