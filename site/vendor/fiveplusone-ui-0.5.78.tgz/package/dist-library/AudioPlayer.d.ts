import { type Ref } from "react";
export interface AudioPlayerProps {
    audioRef?: Ref<HTMLAudioElement>;
    onSeek?: (seconds: number) => void;
    onPlaybackRateChange?: (rate: number) => void;
    src: string;
    title?: string;
    startAt?: number;
    onTimeUpdate?: (seconds: number) => void;
    onEnded?: () => void;
    resolveSource?: (src: string, signal: AbortSignal) => Promise<string>;
}
/** Audio controls share the workspace keyboard and theme conventions. */
export declare function AudioPlayer({ src, title, startAt, onTimeUpdate, onEnded, resolveSource, audioRef, onSeek, onPlaybackRateChange, }: AudioPlayerProps): import("react").JSX.Element;
