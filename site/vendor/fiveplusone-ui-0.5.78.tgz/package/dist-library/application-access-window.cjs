const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {randomUUID}=require('node:crypto');

// First-party task consent shares the host session; the frame has an isolated bridge.
function createApplicationAccessWindow({BrowserWindow,WebContentsView,session,ipcMain,parent,contentSession,url,origin,icon,theme='light',workArea,onBrowser,onLogin,onClose}){
 const target=new URL(url);if(target.protocol!=='https:'||target.origin!==origin||target.pathname!=='/connections')throw Error('授权地址无效');
 const channel='fiveplusone:access-window:'+randomUUID(),local=pathToFileURL(path.join(__dirname,'oauth-window-shell.html'));local.search=new URLSearchParams({theme,title:'任务授权',product:'kezhan',mode:'task'}).toString();
 const width=Math.min(820,workArea?.width||820),height=Math.min(800,workArea?.height||800);
 const frameSession=session.fromPartition(channel);frameSession.setPermissionRequestHandler?.((_wc,_p,reply)=>reply(false));frameSession.setPermissionCheckHandler?.(()=>false);
 const popup=new BrowserWindow({parent,modal:true,width,height,minWidth:Math.min(420,width),minHeight:Math.min(520,height),frame:false,show:false,title:'任务授权',icon,webPreferences:{session:frameSession,preload:path.join(__dirname,'oauth-window-preload.cjs'),additionalArguments:['--fp-auth-shell='+encodeURIComponent(local.href),'--fp-auth-channel='+channel],contextIsolation:true,nodeIntegration:false,sandbox:true}});
 const view=new WebContentsView({webPreferences:{session:contentSession,contextIsolation:true,nodeIntegration:false,sandbox:true}});popup.contentView.addChildView(view);
 let disposed=false;const backdrop='fp-access-backdrop-'+randomUUID();
 const background=()=>{if(!parent.webContents.isDestroyed())void parent.webContents.executeJavaScript(`(()=>{if(document.getElementById(${JSON.stringify(backdrop)}))return;const n=document.createElement('div');n.id=${JSON.stringify(backdrop)};n.setAttribute('aria-hidden','true');n.style.cssText='position:fixed;inset:0;z-index:2147483647;backdrop-filter:blur(5px);background:rgba(0,0,0,.16);pointer-events:auto';document.documentElement.append(n)})()`).catch(()=>{})};
 const layout=()=>{if(disposed)return;const {width,height}=popup.getContentBounds();view.setBounds({x:1,y:55,width:Math.max(1,width-2),height:Math.max(1,height-56)})};
 const dispose=()=>{if(disposed)return;disposed=true;ipcMain.removeListener(channel,action);parent.removeListener('closed',dispose);parent.webContents.removeListener('dom-ready',background);if(!parent.webContents.isDestroyed())void parent.webContents.executeJavaScript(`document.getElementById(${JSON.stringify(backdrop)})?.remove()`).catch(()=>{});if(!view.webContents.isDestroyed())view.webContents.close();if(!popup.isDestroyed())popup.destroy();onClose?.()};
 const focus=()=>{if(disposed)return;if(parent.isMinimized())parent.restore();parent.show();popup.show();popup.focus();view.webContents.focus()};
 const setTheme=value=>{if(disposed)return;const next=value==='dark'?'dark':'light';popup.webContents.send(channel+':theme',next);void view.webContents.executeJavaScript(`document.documentElement.dataset.theme=${JSON.stringify(next)}`).catch(()=>{})};
 const action=(event,command)=>{if(disposed||event.sender!==popup.webContents||event.senderFrame!==popup.webContents.mainFrame||event.senderFrame.url!==local.href)return;if(command==='close')dispose();if(command==='reload')view.webContents.reload();if(command==='browser')onBrowser?.()};
 const navigate=(event,raw)=>{try{const u=new URL(raw);if(u.origin===origin&&u.pathname==='/connections')return;event.preventDefault();if(u.origin===origin&&u.pathname==='/'){dispose();return}if(u.origin===origin&&u.pathname==='/api/auth/login'){dispose();onLogin?.()}}catch{event.preventDefault()}};
 ipcMain.on(channel,action);view.webContents.on('will-navigate',navigate);view.webContents.on('will-redirect',navigate);view.webContents.setWindowOpenHandler(()=>({action:'deny'}));popup.webContents.on('will-navigate',e=>e.preventDefault());popup.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 for(const wc of [view.webContents,popup.webContents])wc.on('before-input-event',(event,input)=>{if(input.type==='keyDown'&&input.key==='Escape'){event.preventDefault();dispose()}});
 popup.on('close',event=>{event.preventDefault();dispose()});popup.on('resize',layout);popup.once('ready-to-show',focus);parent.once('closed',dispose);parent.webContents.on('dom-ready',background);popup.setMenu(null);layout();background();
 popup.webContents.once('did-finish-load',()=>setTheme(theme));view.webContents.on('did-finish-load',()=>setTheme(theme));void popup.loadURL(local.href);void view.webContents.loadURL(target.href).catch(()=>{});
 return {focus,dispose,setTheme};
}
module.exports={createApplicationAccessWindow};
