import { jsxs as i, jsx as e, Fragment as U } from "react/jsx-runtime";
import { memo as fe, useState as g, useRef as ne, useCallback as Y } from "react";
const b = "var(--fp-primary)", pe = "var(--fp-primary-soft)", L = "#0d9488", D = "#ea580c", be = "#a78bfa", ge = 0.35, H = 520, oe = 220, y = 46, ve = 18, v = 18, ye = 36, $ = H - y - ve, X = oe - v - ye;
function C(n, o, l) {
  return Math.max(o, Math.min(l, n));
}
function z(n, o, l) {
  const r = (n - o) / l;
  return Math.exp(-0.5 * r * r) / (l * Math.sqrt(2 * Math.PI));
}
function q(n, o) {
  return n < 0 ? 0 : o * Math.exp(-o * n);
}
function K(n, o, l) {
  return n < o || n > l ? 0 : 1 / (l - o);
}
function Me(n, o, l, r) {
  const h = (l - o) / 500;
  let a = 0;
  for (let d = 0; d <= 500; d++) {
    const x = o + d * h;
    let u = 0;
    n === "uniform" ? u = K(x, r.ua, r.ub) : n === "exponential" ? u = q(x, r.lam) : u = z(x, r.mu, r.sigma), a += d === 0 || d === 500 ? u * 0.5 : u;
  }
  return C(a * h, 0, 1);
}
function k(n, o) {
  return y + (n - o.xMin) / (o.xMax - o.xMin) * $;
}
function T(n, o) {
  return v + X - n / o.yMax * X;
}
function Ne(n, o) {
  return o.xMin + (n - y) / $ * (o.xMax - o.xMin);
}
function Fe(n, o, l) {
  const c = [];
  for (let h = 0; h <= 300; h++) {
    const a = o.xMin + h / 300 * (o.xMax - o.xMin);
    let d = 0;
    n === "uniform" ? d = K(a, l.ua, l.ub) : n === "exponential" ? d = q(a, l.lam) : d = z(a, l.mu, l.sigma), d = C(d, 0, o.yMax);
    const x = k(a, o), u = T(d, o);
    c.push(`${h === 0 ? "M" : "L"}${x.toFixed(2)},${u.toFixed(2)}`);
  }
  return c.join(" ");
}
function ke(n, o, l, r, c) {
  const a = [], d = T(0, r);
  a.push(`M${k(o, r).toFixed(2)},${d.toFixed(2)}`);
  for (let x = 0; x <= 200; x++) {
    const u = o + x / 200 * (l - o);
    let f = 0;
    n === "uniform" ? f = K(u, c.ua, c.ub) : n === "exponential" ? f = q(u, c.lam) : f = z(u, c.mu, c.sigma), f = C(f, 0, r.yMax);
    const _ = k(u, r), B = T(f, r);
    a.push(`L${_.toFixed(2)},${B.toFixed(2)}`);
  }
  return a.push(`L${k(l, r).toFixed(2)},${d.toFixed(2)}`), a.push("Z"), a.join(" ");
}
function F({
  label: n,
  value: o,
  min: l,
  max: r,
  step: c,
  onChange: h,
  fmt: a,
  color: d
}) {
  const x = a ? a(o) : o.toFixed(2);
  return /* @__PURE__ */ i("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ e("span", { className: "w-20 shrink-0 text-right text-[12px] text-[var(--ink-soft)]", children: n }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: l,
        max: r,
        step: c,
        value: o,
        onChange: (u) => h(Number(u.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: d ?? b }
      }
    ),
    /* @__PURE__ */ e(
      "span",
      {
        className: "w-14 shrink-0 rounded px-1 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: (d ?? b) + "22", color: d ?? b },
        children: x
      }
    )
  ] });
}
function Pe({ lam: n }) {
  const [o, l] = g(1), [r, c] = g(2), h = Math.exp(-n * o), a = Math.exp(-n * (o + r)), d = h > 0 ? a / h : 0, x = Math.exp(-n * r), u = Math.abs(d - x) < 1e-9;
  return /* @__PURE__ */ i("div", { className: "mt-3 rounded-lg border border-[var(--line)] bg-emerald-500/10 p-3 space-y-3", children: [
    /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[#0f766e]", children: "无记忆性验证" }),
    /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed", children: "指数分布有「无记忆性」：已知 X > s，额外再等 t 的概率，等同于从头等 t。 即 P(X > s+t | X > s) = P(X > t)。" }),
    /* @__PURE__ */ i("div", { className: "grid grid-cols-2 gap-2", children: [
      /* @__PURE__ */ e(
        F,
        {
          label: "s =",
          value: o,
          min: 0.1,
          max: 5,
          step: 0.1,
          onChange: l,
          fmt: (f) => f.toFixed(1),
          color: L
        }
      ),
      /* @__PURE__ */ e(
        F,
        {
          label: "t =",
          value: r,
          min: 0.1,
          max: 5,
          step: 0.1,
          onChange: c,
          fmt: (f) => f.toFixed(1),
          color: D
        }
      )
    ] }),
    /* @__PURE__ */ i("div", { className: "rounded bg-[var(--bg-elevated)] px-3 py-2 text-[12px] space-y-1 font-mono", children: [
      /* @__PURE__ */ i("div", { children: [
        "P(X > s) = e",
        /* @__PURE__ */ e("sup", { children: "−λs" }),
        " =",
        " ",
        /* @__PURE__ */ e("span", { style: { color: L }, children: h.toFixed(6) })
      ] }),
      /* @__PURE__ */ i("div", { children: [
        "P(X > s+t) = e",
        /* @__PURE__ */ e("sup", { children: "−λ(s+t)" }),
        " =",
        " ",
        /* @__PURE__ */ e("span", { style: { color: b }, children: a.toFixed(6) })
      ] }),
      /* @__PURE__ */ i("div", { className: "border-t border-[var(--line)] pt-1 mt-1", children: [
        "P(X > s+t | X > s) = ",
        a.toFixed(6),
        " /",
        " ",
        h.toFixed(6),
        " =",
        " ",
        /* @__PURE__ */ e("span", { className: "font-bold", style: { color: D }, children: d.toFixed(6) })
      ] }),
      /* @__PURE__ */ i("div", { children: [
        "P(X > t) = e",
        /* @__PURE__ */ e("sup", { children: "−λt" }),
        " =",
        " ",
        /* @__PURE__ */ e("span", { className: "font-bold", style: { color: D }, children: x.toFixed(6) })
      ] }),
      /* @__PURE__ */ e(
        "div",
        {
          className: "rounded px-2 py-1 text-center font-bold",
          style: {
            background: u ? "rgba(16,185,129,0.12)" : "rgba(244,63,94,0.12)",
            color: u ? "var(--color-success)" : "var(--md-sys-color-error)"
          },
          children: u ? "[OK] 两者完全相等，无记忆性成立！" : "数值偏差过大"
        }
      )
    ] })
  ] });
}
function Xe() {
  const [n, o] = g("normal"), [l, r] = g(1), [c, h] = g(5), [a, d] = g(1), [x, u] = g(0), [f, _] = g(1), [B, A] = g(-1), [ie, w] = g(1), S = ne(null), Z = ne(null), [E, J] = g(!1), G = { ua: l, ub: c, lam: a, mu: x, sigma: f }, s = (() => {
    if (n === "uniform") {
      const m = Math.min(l, c) - 0.5, p = Math.max(l, c) + 0.5, j = c - l > 0 ? 1 / (c - l) * 1.5 : 2;
      return { xMin: m, xMax: p, yMax: j };
    }
    if (n === "exponential") {
      const m = Math.max(6 / a, 0.5), p = a * 1.4;
      return { xMin: 0, xMax: m, yMax: p };
    }
    const t = 4 * f;
    return {
      xMin: x - t,
      xMax: x + t,
      yMax: z(x, x, f) * 1.4
    };
  })(), M = C(B, s.xMin, s.xMax), N = C(ie, s.xMin, s.xMax), O = Math.min(M, N), R = Math.max(M, N), le = Me(n, O, R, G), ae = Fe(n, s, G), Q = O < R ? ke(n, O, R, s, G) : "";
  function se(t) {
    const m = Z.current;
    if (!m) return 0;
    const p = m.getBoundingClientRect(), j = "touches" in t ? t.touches[0]?.clientX ?? 0 : t.clientX, he = H / p.width;
    return (j - p.left) * he;
  }
  const ee = Y(
    (t) => (m) => {
      m.preventDefault(), S.current = t;
    },
    []
  ), re = Y(
    (t) => {
      if (!S.current) return;
      const m = se(t), p = C(
        Ne(m, s),
        s.xMin,
        s.xMax
      );
      S.current === "a" ? A(parseFloat(p.toFixed(3))) : w(parseFloat(p.toFixed(3)));
    },
    [s]
  ), te = Y(() => {
    S.current = null;
  }, []);
  function ce() {
    const m = [];
    for (let p = 0; p <= 5; p++)
      m.push(
        s.xMin + p / 5 * (s.xMax - s.xMin)
      );
    return m;
  }
  function de() {
    return [s.yMax * 0.5, s.yMax];
  }
  const I = k(M, s), W = k(N, s), P = T(0, s), V = {
    uniform: {
      name: "均匀分布 U(a,b)",
      formula: `U(${l.toFixed(1)}, ${c.toFixed(1)})`,
      color: L
    },
    exponential: {
      name: "指数分布 Exp(λ)",
      formula: `Exp(λ=${a.toFixed(2)})`,
      color: D
    },
    normal: {
      name: "正态分布 N(μ,σ²)",
      formula: `N(${x.toFixed(1)}, ${f.toFixed(2)}²)`,
      color: b
    }
  }, xe = ["uniform", "exponential", "normal"], me = {
    uniform: "均匀分布",
    exponential: "指数分布",
    normal: "正态分布"
  };
  function ue(t) {
    o(t), J(!1), t === "uniform" ? (A(1.5), w(3.5)) : t === "exponential" ? (A(0.5), w(2)) : (A(-1), w(1));
  }
  return /* @__PURE__ */ i("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ i("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "连续分布密度函数探索器" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "切换分布、调节参数，拖动区间端点，实时观察概率密度函数与 P(a ≤ X ≤ b) 的面积。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "flex gap-1.5 rounded-lg bg-[var(--bg-muted)] p-1", children: xe.map((t) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        onClick: () => ue(t),
        className: "flex-1 rounded-md py-1 text-[12px] font-semibold transition-all " + (n === t ? "bg-[var(--bg-elevated)] shadow text-[var(--ink)]" : "text-[var(--ink-soft)] hover:text-[var(--ink)]"),
        children: me[t]
      },
      t
    )) }),
    /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-2.5", children: [
      n === "uniform" && /* @__PURE__ */ i(U, { children: [
        /* @__PURE__ */ e(
          F,
          {
            label: "下限 a =",
            value: l,
            min: -4,
            max: 4,
            step: 0.1,
            onChange: (t) => r(Math.min(t, c - 0.2)),
            fmt: (t) => t.toFixed(1),
            color: L
          }
        ),
        /* @__PURE__ */ e(
          F,
          {
            label: "上限 b =",
            value: c,
            min: -4,
            max: 4,
            step: 0.1,
            onChange: (t) => h(Math.max(t, l + 0.2)),
            fmt: (t) => t.toFixed(1),
            color: L
          }
        ),
        /* @__PURE__ */ i("p", { className: "text-[11px] text-[var(--ink-soft)]", children: [
          "f(x) = 1/(b−a) = ",
          (1 / Math.max(c - l, 0.01)).toFixed(4),
          "，在 [",
          l.toFixed(1),
          ", ",
          c.toFixed(1),
          "] 上常数，区间外为 0。"
        ] })
      ] }),
      n === "exponential" && /* @__PURE__ */ i(U, { children: [
        /* @__PURE__ */ e(
          F,
          {
            label: "λ =",
            value: a,
            min: 0.2,
            max: 5,
            step: 0.1,
            onChange: d,
            fmt: (t) => t.toFixed(2),
            color: D
          }
        ),
        /* @__PURE__ */ i("p", { className: "text-[11px] text-[var(--ink-soft)]", children: [
          "f(x) = λe",
          /* @__PURE__ */ e("sup", { children: "−λx" }),
          "，均值 = 1/λ = ",
          (1 / a).toFixed(3),
          "，方差 = 1/λ² = ",
          (1 / (a * a)).toFixed(3)
        ] })
      ] }),
      n === "normal" && /* @__PURE__ */ i(U, { children: [
        /* @__PURE__ */ e(
          F,
          {
            label: "μ =",
            value: x,
            min: -3,
            max: 3,
            step: 0.1,
            onChange: u,
            fmt: (t) => t.toFixed(1),
            color: b
          }
        ),
        /* @__PURE__ */ e(
          F,
          {
            label: "σ =",
            value: f,
            min: 0.2,
            max: 3,
            step: 0.05,
            onChange: _,
            fmt: (t) => t.toFixed(2),
            color: "#7c3aed"
          }
        ),
        /* @__PURE__ */ i("p", { className: "text-[11px] text-[var(--ink-soft)]", children: [
          "f(x) = (2πσ²)^(−1/2) · exp(−(x−μ)²/2σ²)，峰值 =",
          " ",
          z(x, x, f).toFixed(4)
        ] })
      ] })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "rounded-lg border border-[var(--line)] overflow-hidden",
        style: { background: "var(--bg-elevated)" },
        children: /* @__PURE__ */ i(
          "svg",
          {
            ref: Z,
            viewBox: `0 0 ${H} ${oe}`,
            className: "w-full select-none",
            style: {
              cursor: S.current ? "col-resize" : "default",
              touchAction: "none"
            },
            onMouseMove: re,
            onMouseUp: te,
            onMouseLeave: te,
            children: [
              /* @__PURE__ */ e(
                "rect",
                {
                  x: y,
                  y: v,
                  width: $,
                  height: X,
                  fill: "var(--bg-muted)",
                  stroke: "var(--line)"
                }
              ),
              de().map((t) => {
                const m = T(t, s);
                return /* @__PURE__ */ i("g", { children: [
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: y,
                      y1: m,
                      x2: y + $,
                      y2: m,
                      stroke: "var(--line)",
                      strokeDasharray: "4 3"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: y - 5,
                      y: m + 3,
                      fontSize: "10",
                      textAnchor: "end",
                      fill: "var(--ink-faint)",
                      children: t.toFixed(2)
                    }
                  )
                ] }, t);
              }),
              ce().map((t) => {
                const m = k(t, s);
                return /* @__PURE__ */ i("g", { children: [
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: m,
                      y1: v,
                      x2: m,
                      y2: v + X,
                      stroke: "var(--line)"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: m,
                      y: v + X + 13,
                      fontSize: "10",
                      textAnchor: "middle",
                      fill: "var(--ink-faint)",
                      children: t.toFixed(1)
                    }
                  )
                ] }, t);
              }),
              Q && /* @__PURE__ */ e("path", { d: Q, fill: be, fillOpacity: ge }),
              /* @__PURE__ */ e(
                "path",
                {
                  d: ae,
                  fill: "none",
                  stroke: V[n].color,
                  strokeWidth: "2.2",
                  strokeLinejoin: "round"
                }
              ),
              [M, N].map((t, m) => {
                const p = k(t, s);
                return /* @__PURE__ */ e(
                  "line",
                  {
                    x1: p,
                    y1: v,
                    x2: p,
                    y2: P,
                    stroke: "#7c3aed",
                    strokeWidth: "1.5",
                    strokeDasharray: "5 3",
                    opacity: 0.7
                  },
                  m
                );
              }),
              /* @__PURE__ */ i("g", { style: { cursor: "col-resize" }, onMouseDown: ee("a"), children: [
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: I,
                    cy: P - 1,
                    r: 7,
                    fill: b,
                    opacity: 0.9
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: I,
                    y: P - 1 + 4,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: "white",
                    fontWeight: "bold",
                    children: "a"
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: I,
                    y: P + 24,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: b,
                    children: M.toFixed(2)
                  }
                )
              ] }),
              /* @__PURE__ */ i("g", { style: { cursor: "col-resize" }, onMouseDown: ee("b"), children: [
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: W,
                    cy: P - 1,
                    r: 7,
                    fill: "#7c3aed",
                    opacity: 0.9
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: W,
                    y: P - 1 + 4,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: "white",
                    fontWeight: "bold",
                    children: "b"
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: W,
                    y: P + 24,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: "#7c3aed",
                    children: N.toFixed(2)
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: y - 5,
                  y: v - 5,
                  fontSize: "10",
                  fill: "var(--ink-faint)",
                  textAnchor: "end",
                  children: "f(x)"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: y + $,
                  y: v + X + 28,
                  fontSize: "10",
                  fill: "var(--ink-faint)",
                  textAnchor: "end",
                  children: "x"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: y + 8,
                  y: v + 14,
                  fontSize: "11",
                  fill: V[n].color,
                  fontWeight: "600",
                  children: V[n].formula
                }
              )
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ i("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      /* @__PURE__ */ i(
        "div",
        {
          className: "col-span-2 sm:col-span-2 rounded-lg border-2 p-3 text-center",
          style: { borderColor: b, background: pe },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)]", children: "P(a ≤ X ≤ b) — 紫色面积" }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[28px] font-extrabold font-mono mt-0.5",
                style: { color: b },
                children: le.toFixed(6)
              }
            ),
            /* @__PURE__ */ i("div", { className: "text-[11px] text-[var(--ink-soft)] mt-0.5", children: [
              "[",
              Math.min(M, N).toFixed(3),
              ",",
              " ",
              Math.max(M, N).toFixed(3),
              "]"
            ] })
          ]
        }
      ),
      /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] p-3 text-center", children: [
        /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "端点 a" }),
        /* @__PURE__ */ e(
          "div",
          {
            className: "text-[18px] font-extrabold font-mono mt-0.5",
            style: { color: b },
            children: M.toFixed(3)
          }
        ),
        /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "拖动蓝点" })
      ] }),
      /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] p-3 text-center", children: [
        /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "端点 b" }),
        /* @__PURE__ */ e(
          "div",
          {
            className: "text-[18px] font-extrabold font-mono mt-0.5",
            style: { color: "#7c3aed" },
            children: N.toFixed(3)
          }
        ),
        /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "拖动紫点" })
      ] })
    ] }),
    /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-2.5", children: [
      /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "精调区间端点（也可直接拖动图上圆点）" }),
      /* @__PURE__ */ e(
        F,
        {
          label: "端点 a =",
          value: M,
          min: s.xMin,
          max: s.xMax,
          step: 0.01,
          onChange: (t) => A(t),
          fmt: (t) => t.toFixed(2),
          color: b
        }
      ),
      /* @__PURE__ */ e(
        F,
        {
          label: "端点 b =",
          value: N,
          min: s.xMin,
          max: s.xMax,
          step: 0.01,
          onChange: (t) => w(t),
          fmt: (t) => t.toFixed(2),
          color: "#7c3aed"
        }
      )
    ] }),
    /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
      n === "uniform" && /* @__PURE__ */ i("p", { children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "均匀分布：" }),
        "密度函数为常数，面积 = 长度 × 高度 = (b−a) × 1/(B−A)。全区间积分恒为 1。"
      ] }),
      n === "exponential" && /* @__PURE__ */ i("p", { children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "指数分布：" }),
        "常用于描述等待时间/寿命，λ 越大衰减越快。P(X > t) = e",
        /* @__PURE__ */ e("sup", { children: "−λt" }),
        "。 唯一具有「无记忆性」的连续分布。"
      ] }),
      n === "normal" && /* @__PURE__ */ i("p", { children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "正态分布：" }),
        "钟形曲线，μ 控制中心，σ 控制胖瘦。P(μ−σ ≤ X ≤ μ+σ) ≈ 68.3%， P(μ−2σ ≤ X ≤ μ+2σ) ≈ 95.4%。"
      ] })
    ] }),
    n === "exponential" && /* @__PURE__ */ i("div", { children: [
      /* @__PURE__ */ i(
        "button",
        {
          type: "button",
          onClick: () => J((t) => !t),
          className: "rounded-lg px-3 py-1.5 text-[12px] font-semibold transition-all " + (E ? "bg-[#0d9488] text-white" : "bg-teal-500/10 text-[#0f766e] hover:bg-[#0d9488] hover:text-white"),
          children: [
            E ? "收起" : "展开",
            " 无记忆性验证"
          ]
        }
      ),
      E && /* @__PURE__ */ e(Pe, { lam: a })
    ] })
  ] });
}
const we = fe(Xe);
export {
  we as default
};
