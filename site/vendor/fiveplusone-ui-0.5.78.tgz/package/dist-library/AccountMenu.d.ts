import type { ReactNode } from 'react';
import './account-menu.css';
export interface AccountMenuItem {
    id: string;
    label: string;
    icon?: ReactNode;
    detail?: string;
    shortcut?: string;
    separator?: boolean;
    danger?: boolean;
    disabled?: boolean;
}
export declare function AccountMenu({ name, description, items, onSelect, busy }: {
    name: string;
    description?: string;
    items: AccountMenuItem[];
    onSelect: (id: string) => void;
    busy?: boolean;
}): import("react").JSX.Element;
