/** Animate reading content while navigation, focus and URL handling stay with the host. */
export declare function createDocumentationMotion(): {
    begin(): void;
    complete(): void;
    reveal: () => void;
    destroy(): void;
};
