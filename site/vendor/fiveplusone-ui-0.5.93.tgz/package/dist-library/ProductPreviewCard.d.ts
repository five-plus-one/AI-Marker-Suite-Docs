import { type ReactNode } from 'react';
export interface ProductPreviewScene {
    id: string;
    label: string;
    eyebrow: string;
    title: string;
    description: string;
    callout: {
        title: string;
        description: string;
    };
    metrics?: {
        label: string;
        value: string;
        note?: string;
    }[];
    rows?: {
        title: string;
        detail: string;
        value: string;
    }[];
    footnote: string;
    link?: {
        label: string;
        href: string;
    };
}
export interface ProductPreviewCardProps {
    id?: string;
    title: string;
    brand?: string;
    icon?: ReactNode;
    scenes: ProductPreviewScene[];
    defaultSceneId?: string;
}
/** A product scene stays readable while tabs introduce the next part of the workflow. */
export declare function ProductPreviewCard({ id: providedId, title, brand, icon, scenes, defaultSceneId }: ProductPreviewCardProps): import("react").JSX.Element | null;
