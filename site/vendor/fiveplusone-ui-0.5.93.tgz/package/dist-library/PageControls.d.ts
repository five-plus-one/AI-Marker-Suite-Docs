import React, { type ReactNode, type ButtonHTMLAttributes, type HTMLAttributes } from 'react';
export declare const cx: (...s: (string | false | undefined)[]) => string;
export declare function Button({ variant, size, loading, multiline, children, className, title, type, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "primary" | "secondary" | "ghost" | "danger";
    size?: "sm" | "md" | "lg";
    loading?: boolean;
    multiline?: boolean;
}): React.JSX.Element;
export declare function Badge({ children, tone, }: {
    children: ReactNode;
    tone?: "neutral" | "success" | "warning" | "error" | "accent";
}): React.JSX.Element;
export declare function Card({ children, className, ...p }: HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export declare function Spinner({ size }: {
    size?: number;
}): React.JSX.Element;
export declare function Tabs({ items, value, onChange, id, label, }: {
    items: {
        value: string;
        label: string;
    }[];
    value: string;
    onChange: (v: string) => void;
    id?: string;
    label?: string;
}): React.JSX.Element;
export declare function Accordion({ items, }: {
    items: {
        title: string;
        content: ReactNode;
    }[];
}): React.JSX.Element;
